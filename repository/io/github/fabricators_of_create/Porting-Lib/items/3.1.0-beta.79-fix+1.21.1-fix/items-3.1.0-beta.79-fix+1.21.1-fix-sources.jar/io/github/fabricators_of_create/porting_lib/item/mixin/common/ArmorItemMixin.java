package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.item.extensions.EquipmentItem;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_2342;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1738.class)
public abstract class ArmorItemMixin {
	@Inject(method = "dispenseArmor", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;split(I)Lnet/minecraft/world/item/ItemStack;", ordinal = 0), cancellable = true)
	private static void port_lib$checkCanEntityEquipArmor(class_2342 blockSource, class_1799 armorItem, CallbackInfoReturnable<Boolean> cir, @Local class_1304 slot, @Local class_1309 entity) {
		if (armorItem.method_7909() instanceof EquipmentItem equipmentItem && !equipmentItem.canEquip(armorItem, slot, entity)) {
			cir.setReturnValue(false);
		}
	}
}
