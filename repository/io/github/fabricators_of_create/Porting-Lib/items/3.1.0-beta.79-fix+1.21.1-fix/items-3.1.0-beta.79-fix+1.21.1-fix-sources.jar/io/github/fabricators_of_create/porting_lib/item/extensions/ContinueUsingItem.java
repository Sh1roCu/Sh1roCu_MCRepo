package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1799;

public interface ContinueUsingItem {
	/**
	 * Called while an item is in 'active' use to determine if usage should
	 * continue. Allows items to continue being used while sustaining damage, for
	 * example.
	 *
	 * @param oldStack the previous 'active' stack
	 * @param newStack the stack currently in the active hand
	 * @return true to set the new stack to active and continue using it
	 */
	default boolean canContinueUsing(class_1799 oldStack, class_1799 newStack) {
		if (oldStack == newStack) {
			return true;
		} else {
			return !oldStack.method_7960() && !newStack.method_7960() && class_1799.method_7984(newStack, oldStack);
		}
	}
}
