package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.fabricmc.fabric.api.item.v1.CustomDamageHandler;
import net.fabricmc.fabric.api.item.v1.FabricItem;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;

public interface CustomDamageItem {
	/**
	 * Reduce the durability of this item by the amount given.
	 * This can be used to e.g. consume power from NBT before durability.
	 *
	 * @param stack    The itemstack to damage
	 * @param amount   The amount to damage
	 * @param entity   The entity damaging the item
	 * @param onBroken The on-broken callback from vanilla
	 * @return The amount of damage to pass to the vanilla logic
	 * @apiNote Try to use {@link FabricItem.Settings#customDamage(CustomDamageHandler)} instead where possible.
	 */
	default <T extends class_1309> int damageItem(class_1799 stack, int amount, @Nullable T entity, Consumer<class_1792> onBroken) {
		return amount;
	}
}
