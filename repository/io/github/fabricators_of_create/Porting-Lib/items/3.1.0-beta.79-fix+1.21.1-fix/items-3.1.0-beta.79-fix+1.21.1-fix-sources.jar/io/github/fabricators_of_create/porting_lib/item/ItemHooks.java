package io.github.fabricators_of_create.porting_lib.item;

import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.Set;
import net.minecraft.class_1299;
import net.minecraft.class_1772;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1812;
import net.minecraft.class_1826;
import net.minecraft.class_1833;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class ItemHooks {
	/**
	 * Used as the default implementation of {@link io.github.fabricators_of_create.porting_lib.item.extensions.CreatorModIdItem#getCreatorModId}. Call that method instead.
	 */
	@Nullable
	public static String getDefaultCreatorModId(class_1799 itemStack) {
		class_1792 item = itemStack.method_7909();
		class_2960 registryName = class_7923.field_41178.method_10221(item);
		String modId = registryName == null ? null : registryName.method_12836();
		if ("minecraft".equals(modId)) {
			if (item instanceof class_1772) {
				Set<class_6880<class_1887>> enchantments = itemStack.method_57825(class_9334.field_49643, class_9304.field_49385).method_57534();
				if (enchantments.size() == 1) {
					class_6880<class_1887> enchantmentHolder = enchantments.iterator().next();
					Optional<class_5321<class_1887>> key = enchantmentHolder.method_40230();
					if (key.isPresent()) {
						return key.get().method_29177().method_12836();
					}
				}
			} else if (item instanceof class_1812 || item instanceof class_1833) {
				class_1844 potionContents = itemStack.method_57825(class_9334.field_49651, class_1844.field_49274);
				Optional<class_6880<class_1842>> potionType = potionContents.comp_2378();
				Optional<class_5321<class_1842>> key = potionType.flatMap(class_6880::method_40230);
				if (key.isPresent()) {
					return key.get().method_29177().method_12836();
				}
			} else if (item instanceof class_1826 spawnEggItem) {
				Optional<class_5321<class_1299<?>>> key = class_7923.field_41177.method_29113(spawnEggItem.method_8015(itemStack));
				if (key.isPresent()) {
					return key.get().method_29177().method_12836();
				}
			}
		}
		return modId;
	}
}
