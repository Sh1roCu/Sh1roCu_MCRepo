package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_970;
import org.jetbrains.annotations.Nullable;

/**
 * An Armor Item with custom logic for getting the texture.
 */
public interface ArmorTextureItem {
	/**
	 * Called by {@link class_970#method_4169(class_4587, class_4597, class_1309, class_1304, int, class_572)} to determine the armor texture that
	 * should be use for the currently equipped item. This will only be called on
	 * instances of ItemArmor.
	 *
	 * Returning null from this function will use the default value.
	 *
	 * @param stack      ItemStack for the equipped armor
	 * @param entity     The entity wearing the armor
	 * @param slot       The slot the armor is in
	 * @param layer      The armor layer
	 * @param innerModel Whether the inner model is used
	 * @return Path of texture to bind, or null to use default
	 */
	@Nullable
	default class_2960 getArmorTexture(class_1799 stack, class_1297 entity, class_1304 slot, class_1741.class_9196 layer, boolean innerModel) {
		return null;
	}
}
