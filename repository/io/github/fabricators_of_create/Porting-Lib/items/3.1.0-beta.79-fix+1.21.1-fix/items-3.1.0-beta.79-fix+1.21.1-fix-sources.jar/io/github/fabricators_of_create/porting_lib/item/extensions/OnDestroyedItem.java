package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1282;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public interface OnDestroyedItem {
	/**
	 * Called when an item entity for this stack is destroyed. Note: The {@link class_1799} can be retrieved from the item entity.
	 *
	 * @param itemEntity   The item entity that was destroyed.
	 * @param damageSource Damage source that caused the item entity to "die".
	 */
	default void onDestroyed(class_1542 itemEntity, class_1282 damageSource) {
		((class_1792) this).method_33261(itemEntity);
	}
}
