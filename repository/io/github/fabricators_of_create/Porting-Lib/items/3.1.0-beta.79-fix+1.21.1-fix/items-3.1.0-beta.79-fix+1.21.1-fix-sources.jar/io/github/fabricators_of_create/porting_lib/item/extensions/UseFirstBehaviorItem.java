package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1838;

public interface UseFirstBehaviorItem {
	/**
	 * This is called when the item is used, before the block is activated.
	 *
	 * @return Return PASS to allow vanilla handling, any other to skip normal code.
	 */
	default class_1269 onItemUseFirst(class_1799 stack, class_1838 context) {
		return class_1269.field_5811;
	}
}
