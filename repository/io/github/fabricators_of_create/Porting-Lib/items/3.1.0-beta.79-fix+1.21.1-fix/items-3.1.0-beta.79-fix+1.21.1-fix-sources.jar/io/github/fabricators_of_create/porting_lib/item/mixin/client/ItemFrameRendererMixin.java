package io.github.fabricators_of_create.porting_lib.item.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.item.extensions.CustomMapItem;
import net.minecraft.class_1533;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_897;
import net.minecraft.class_915;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_915.class)
public abstract class ItemFrameRendererMixin<T extends class_1533> extends class_897<T> {
	protected ItemFrameRendererMixin(class_5618 context) {
		super(context);
	}

	@WrapOperation(
			method = "getFrameModelResourceLoc",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;is(Lnet/minecraft/world/item/Item;)Z")
	)
	private boolean port_lib$customMapsAreMaps(class_1799 instance, class_1792 item, Operation<Boolean> original) {
		if (item instanceof CustomMapItem)
			return true;
		return original.call(instance, item);
	}
}
