package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import io.github.fabricators_of_create.porting_lib.item.extensions.EquipmentItem;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = "net.minecraft.world.inventory.ArmorSlot")
public abstract class ArmorSlotMixin {
	@Shadow
	@Final
	private class_1304 slot;

	@Shadow
	@Final
	private class_1309 owner;

	@Inject(method = "mayPlace", at = @At("HEAD"), cancellable = true)
	private void port_lib$checkCanEquipItem(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
		if (stack.method_7909() instanceof EquipmentItem equipmentItem) {
			cir.setReturnValue(equipmentItem.canEquip(stack, slot, owner));
		}
	}
}
