package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1665;
import net.minecraft.class_1799;

public interface CustomArrowItem {
	default class_1665 customArrow(class_1665 arrow, class_1799 projectileStack, class_1799 weaponStack) {
		return arrow;
	}
}
