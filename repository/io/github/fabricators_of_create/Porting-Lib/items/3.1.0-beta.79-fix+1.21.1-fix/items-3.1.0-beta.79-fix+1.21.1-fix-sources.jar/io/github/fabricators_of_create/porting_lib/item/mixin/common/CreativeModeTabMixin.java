package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import javax.annotation.Nullable;
import net.minecraft.class_1761;
import org.spongepowered.asm.mixin.Mixin;

import io.github.fabricators_of_create.porting_lib.item.extensions.CreativeModeTabExt;
import io.github.fabricators_of_create.porting_lib.item.itemgroup.PortingLibCreativeTab;

@Mixin(class_1761.class)
public class CreativeModeTabMixin implements CreativeModeTabExt {
	@Nullable
	private PortingLibCreativeTab.TabData porting$data;

	@Override
	public void setPortingData(PortingLibCreativeTab.TabData data) {
		this.porting$data = data;
	}

	@Override
	public PortingLibCreativeTab.TabData getPortingTabData() {
		return this.porting$data;
	}
}
