package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import io.github.fabricators_of_create.porting_lib.item.extensions.CustomArrowItem;
import io.github.fabricators_of_create.porting_lib.item.extensions.InfiniteArrowItem;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1811.class)
public class ProjectileWeaponItemMixin {
	@ModifyExpressionValue(method = "useAmmo", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;hasInfiniteMaterials()Z"))
	private static boolean checkInfiniteAmmo(boolean original, class_1799 p_331207_, class_1799 p_331434_, class_1309 p_330302_, boolean p_330934_) {
		return (original || (p_331434_.method_7909() instanceof InfiniteArrowItem ai && ai.isInfinite(p_331434_, p_331207_, p_330302_)));
	}

	@ModifyReturnValue(method = "createProjectile", at = @At("RETURN"))
	private class_1676 customArrow(class_1676 original, class_1937 level, class_1309 livingEntity, class_1799 itemStack, class_1799 itemStack2) {
		if (this instanceof CustomArrowItem arrowItem && original instanceof class_1665 arrow)
			return arrowItem.customArrow(arrow, itemStack, itemStack2);
		return original;
	}
}
