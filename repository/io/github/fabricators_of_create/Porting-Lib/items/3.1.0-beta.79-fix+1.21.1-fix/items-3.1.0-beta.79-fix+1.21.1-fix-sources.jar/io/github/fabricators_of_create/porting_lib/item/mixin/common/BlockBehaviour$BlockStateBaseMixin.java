package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import io.github.fabricators_of_create.porting_lib.item.extensions.BlockUseBypassingItem;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_9062;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class_4971.class)
public abstract class BlockBehaviour$BlockStateBaseMixin {

	@Inject(at = @At("HEAD"), method = "useItemOn", cancellable = true)
	private void use(class_1799 itemStack, class_1937 level, class_1657 player, class_1268 interactionHand, class_3965 blockHitResult, CallbackInfoReturnable<class_9062> cir) {
		class_1792 held = player.method_5998(interactionHand).method_7909();
		class_2338 pos = blockHitResult.method_17777();
		if (held instanceof BlockUseBypassingItem bypassing) {
			if (bypassing.shouldBypass(level.method_8320(pos), pos, level, player, interactionHand)) cir.setReturnValue(class_9062.field_47731);
		} else if (held instanceof class_1747 blockItem && blockItem.method_7711() instanceof BlockUseBypassingItem bypassing) {
			if (bypassing.shouldBypass(level.method_8320(pos), pos, level, player, interactionHand)) cir.setReturnValue(class_9062.field_47731);
		}
	}
}
