package io.github.fabricators_of_create.porting_lib.item.extensions;

import java.util.Optional;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_6880;
import net.minecraft.class_6885;

public interface CustomSupportsEnchantItem {
	/**
	 * Checks if an item should be treated as a primary item for a given enchantment.
	 * <p>
	 * Primary items are those that are able to receive the enchantment during enchanting,
	 * either from the enchantment table or other random enchantment mechanisms.
	 * As a special case, books are primary items for every enchantment.
	 * <p>
	 * Other application mechanisms, such as the anvil, check {@link #supportsEnchantment(class_1799, class_6880)} instead.
	 * If you want those mechanisms to be able to apply an enchantment, you will need to add your item to the relevant tag or override that method.
	 *
	 * @param stack       the item stack to be enchanted
	 * @param enchantment the enchantment to be applied
	 * @return true if this item should be treated as a primary item for the enchantment
	 *
	 * @see #supportsEnchantment(class_1799, class_6880)
	 */
	default boolean isPrimaryItemFor(class_1799 stack, class_6880<class_1887> enchantment) {
		if (stack.method_7909() == class_1802.field_8529) {
			return true;
		}
		Optional<class_6885<class_1792>> primaryItems = enchantment.comp_349().comp_2687().comp_2507();
		return this.supportsEnchantment(stack, enchantment) && (primaryItems.isEmpty() || stack.method_53187(primaryItems.get()));
	}

	/**
	 * Checks if the provided enchantment is applicable to the passed item stack.
	 * <p>
	 * By default, this checks if the {@link class_1887.class_9427#comp_2506()} contains this item,
	 * special casing enchanted books as they may receive any enchantment.
	 * <p>
	 * Overriding this method allows for dynamic logic that would not be possible using the tag system.
	 *
	 * @param stack       the item stack to be enchanted
	 * @param enchantment the enchantment to be applied
	 * @return true if this item can accept the enchantment
	 *
	 * @see #isPrimaryItemFor(class_1799, class_6880)
	 */
	default boolean supportsEnchantment(class_1799 stack, class_6880<class_1887> enchantment) {
		return stack.method_31574(class_1802.field_8598) || enchantment.comp_349().method_60046(stack);
	}
}
