package io.github.fabricators_of_create.porting_lib.item.injects;

import io.github.fabricators_of_create.porting_lib.item.extensions.DamageableItem;
import net.minecraft.class_1799;
import net.minecraft.class_9334;

public interface ItemStackInjection {
	/**
	 * Determines if an item is reparable, used by Repair recipes and Grindstone.
	 *
	 * @return True if reparable
	 */
	default boolean isRepairable() {
		var stack = (class_1799) this;
		if (stack.method_7909() instanceof DamageableItem repairableItem) {
			return repairableItem.isRepairable(stack);
		}
		return ((ItemInjection) stack.method_7909()).port_lib$canRepair() && stack.method_57826(class_9334.field_50072);
	}
}
