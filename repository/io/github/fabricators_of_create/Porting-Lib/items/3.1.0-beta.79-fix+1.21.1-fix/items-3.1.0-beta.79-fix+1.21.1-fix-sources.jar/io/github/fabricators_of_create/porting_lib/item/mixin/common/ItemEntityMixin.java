package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.item.extensions.EntityTickListenerItem;

import io.github.fabricators_of_create.porting_lib.item.extensions.OnDestroyedItem;
import net.minecraft.class_1282;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1542.class)
public abstract class ItemEntityMixin {
	@Shadow
	public abstract class_1799 getItem();

	@Inject(method = "tick()V", at = @At("HEAD"), cancellable = true)
	public void onHeadTick(CallbackInfo ci) {
		class_1799 stack = getItem();
		if (stack.method_7909() instanceof EntityTickListenerItem listener && listener.onEntityItemUpdate(stack, (class_1542) (Object) this)) {
			ci.cancel();
		}
	}

	@WrapOperation(method = "hurt", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;onDestroyed(Lnet/minecraft/world/entity/item/ItemEntity;)V"))
	private void onDestroyed(class_1799 instance, class_1542 itemEntity, Operation<Void> original, class_1282 source) {
		if (instance.method_7909() instanceof OnDestroyedItem onDestroyedItem) {
			onDestroyedItem.onDestroyed(itemEntity, source);
		} else {
			original.call(instance, itemEntity);
		}
	}
}
