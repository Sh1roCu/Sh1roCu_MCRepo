package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.item.extensions.CustomPickupBucketSoundItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Optional;
import net.minecraft.class_1755;
import net.minecraft.class_2263;
import net.minecraft.class_2680;
import net.minecraft.class_3414;

@Mixin(class_1755.class)
public abstract class BucketItemMixin {
	@WrapOperation(method = "use", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/BucketPickup;getPickupSound()Ljava/util/Optional;"))
	private Optional<class_3414> port_lib$tryUseCustomPickupSound(class_2263 instance, Operation<Optional<class_3414>> original, @Local class_2680 state) {
		if (instance instanceof CustomPickupBucketSoundItem pickupBucketSoundItem) {
			return pickupBucketSoundItem.getPickupSound(state);
		}

		return original.call(instance);
	}
}
