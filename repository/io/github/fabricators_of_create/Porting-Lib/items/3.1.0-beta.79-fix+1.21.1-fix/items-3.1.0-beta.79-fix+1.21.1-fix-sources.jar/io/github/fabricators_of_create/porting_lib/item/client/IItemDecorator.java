package io.github.fabricators_of_create.porting_lib.item.client;

import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * An ItemDecorator that is used to render something on specific items, when the DurabilityBar and StackCount is rendered.
 * Add it to an item using {@linkplain RegisterItemDecorationsEvent#register(ItemLike, IItemDecorator)}.
 */
public interface IItemDecorator {
	/**
	 * Is called after {@linkplain class_332#method_51432(class_327, class_1799, int, int, String)} is done rendering.
	 * The StackCount is rendered at blitOffset+200 so use the blitOffset with caution.
	 * <p>
	 * The RenderState during this call will be: enableTexture, enableDepthTest, enableBlend and defaultBlendFunc
	 * @return true if you have modified the RenderState and it has to be reset for other ItemDecorators
	 */
	default boolean render(class_332 guiGraphics, class_327 font, class_1799 stack, int xOffset, int yOffset) {
		return false;
	}
}
