package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;


public interface ArmorTickListeningItem {
	/**
	 * Called to tick armor in the armor slot. Override to do something
	 *
	 * @param stack The stack
	 * @param level The level object
	 * @param player The player wearing the armor
	 */
	void onArmorTick(class_1799 stack, class_1937 level, class_1657 player);
}
