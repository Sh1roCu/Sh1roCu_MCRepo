package io.github.fabricators_of_create.porting_lib.item.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;

import io.github.fabricators_of_create.porting_lib.item.extensions.ArmorTextureItem;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_2960;

public class ItemClientHooks {
	public static class_2960 getArmorTexture(class_1297 entity, class_1799 armor, class_1741.class_9196 layer, boolean innerModel, class_1304 slot) {
		return getArmorTexture(entity, armor, layer, innerModel, slot, op -> ((class_1741.class_9196) op[0]).method_56693((boolean) op[1]));
	}

	public static class_2960 getArmorTexture(class_1297 entity, class_1799 armor, class_1741.class_9196 layer, boolean innerModel, class_1304 slot, Operation<class_2960> original) {
		class_2960 result = null;
		if (armor.method_7909() instanceof ArmorTextureItem armorTextureItem)
			result = armorTextureItem.getArmorTexture(armor, entity, slot, layer, innerModel);
		return result != null ? result : original.call(layer, innerModel);
	}
}
