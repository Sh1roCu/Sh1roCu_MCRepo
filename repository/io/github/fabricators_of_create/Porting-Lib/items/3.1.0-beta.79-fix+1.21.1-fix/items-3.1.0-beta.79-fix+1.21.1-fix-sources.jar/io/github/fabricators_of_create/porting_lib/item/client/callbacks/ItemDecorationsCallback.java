package io.github.fabricators_of_create.porting_lib.item.client.callbacks;

import io.github.fabricators_of_create.porting_lib.item.client.IItemDecorator;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1792;
import java.util.List;
import java.util.Map;

public interface ItemDecorationsCallback {
	/**
	 * Allows users to register custom {@linkplain IItemDecorator IItemDecorator} to Items.
	 */
	Event<ItemDecorationsCallback> EVENT = EventFactory.createArrayBacked(ItemDecorationsCallback.class, itemDecorationsCallbacks -> decorators -> {
		for (ItemDecorationsCallback callback : itemDecorationsCallbacks)
			callback.registerDecorators(decorators);
	});

	void registerDecorators(Map<class_1792, List<IItemDecorator>> decorators);
}
