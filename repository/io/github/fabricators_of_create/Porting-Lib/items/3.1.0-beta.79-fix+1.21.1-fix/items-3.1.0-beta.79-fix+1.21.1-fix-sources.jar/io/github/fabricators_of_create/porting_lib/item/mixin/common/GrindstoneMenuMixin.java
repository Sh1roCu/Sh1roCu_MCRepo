package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1799;
import net.minecraft.class_3803;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_3803.class)
public class GrindstoneMenuMixin {
	@WrapOperation(method = "mergeItems", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;isDamageableItem()Z", ordinal = 0))
	private boolean isRepairable(class_1799 instance, Operation<Boolean> original) {
		return original.call(instance) || instance.isRepairable();
	}

	@WrapWithCondition(method = "mergeItems", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;setDamageValue(I)V"))
	private boolean checkRepairable(class_1799 instance, int damage) {
		return instance.isRepairable(); // Different from forge because forge still mutates the stack then sets the damage back for some reason
	}
}
