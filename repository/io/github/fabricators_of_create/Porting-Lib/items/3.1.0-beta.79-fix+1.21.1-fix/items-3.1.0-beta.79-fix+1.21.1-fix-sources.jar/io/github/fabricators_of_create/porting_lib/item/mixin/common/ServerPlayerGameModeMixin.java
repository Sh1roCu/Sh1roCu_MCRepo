package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.item.extensions.SneakBypassUseItem;
import io.github.fabricators_of_create.porting_lib.item.extensions.UseFirstBehaviorItem;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2694;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import net.minecraft.class_3468;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3225.class)
public class ServerPlayerGameModeMixin {
	@Inject(
			method = "useItemOn",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/server/level/ServerPlayer;getMainHandItem()Lnet/minecraft/world/item/ItemStack;"
			),
			cancellable = true
	)
	public void onItemFirstUse(class_3222 player, class_1937 level, class_1799 stack, class_1268 hand, class_3965 hit, CallbackInfoReturnable<class_1269> cir) {
		class_1799 heldItem = player.method_5998(hand);
		if (heldItem.method_7909() instanceof UseFirstBehaviorItem useFirst) {
			class_1838 ctx = new class_1838(player, hand, hit);
			class_2338 pos = ctx.method_8037();
			class_2694 block = new class_2694(ctx.method_8045(), pos, false);
			if (!player.method_31549().field_7476 && !heldItem.method_57357(block)) {
				cir.setReturnValue(class_1269.field_5811);
			} else {
				class_1792 item = heldItem.method_7909();
				class_1269 result = useFirst.onItemUseFirst(heldItem, ctx);
				if (result.method_36360()) {
					player.method_7259(class_3468.field_15372.method_14956(item));
				}

				if (result != class_1269.field_5811) {
					cir.setReturnValue(result);
				}
			}
		}
	}

	@ModifyVariable(method = "useItemOn", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;copy()Lnet/minecraft/world/item/ItemStack;"), ordinal = 1)
	private boolean checkShouldSneakBypassUse(boolean original, @Local(argsOnly = true) class_3222 player, @Local(argsOnly = true) class_1937 level, @Local class_2338 pos) {
		return original && !(
				(player.method_6047().method_7909() instanceof SneakBypassUseItem mainBypassUseItem
						&& mainBypassUseItem.doesSneakBypassUse(player.method_6047(), level, pos, player))
				&&
				(player.method_6079().method_7909() instanceof SneakBypassUseItem offhandBypassUseItem
						&& offhandBypassUseItem.doesSneakBypassUse(player.method_6079(), level, pos, player))
		);
	}
}
