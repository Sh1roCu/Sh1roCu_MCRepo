package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_1799;

public interface ShieldBlockItem {
	/**
	 * Can this Item disable a shield
	 *
	 * @param stack    The ItemStack
	 * @param shield   The shield in question
	 * @param entity   The LivingEntity holding the shield
	 * @param attacker The LivingEntity holding the ItemStack
	 * @return True if this ItemStack can disable the shield in question.
	 */
	default boolean canDisableShield(class_1799 stack, class_1799 shield, class_1309 entity, class_1309 attacker) {
		return this instanceof class_1743;
	}
}
