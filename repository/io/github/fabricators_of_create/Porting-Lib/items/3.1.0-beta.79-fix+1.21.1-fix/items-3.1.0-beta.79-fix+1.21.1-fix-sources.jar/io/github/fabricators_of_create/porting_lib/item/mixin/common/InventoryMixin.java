package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import io.github.fabricators_of_create.porting_lib.item.extensions.ArmorTickListeningItem;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1661.class)
public class InventoryMixin {
	@Shadow
	@Final
	public class_1657 player;

	@Inject(method = "tick", at = @At("HEAD"))
	private void inventoryTick(CallbackInfo ci) {
		player.method_5661().forEach(stack -> {
			if(stack.method_7909() instanceof ArmorTickListeningItem item) {
				item.onArmorTick(stack, player.method_37908(), player);
			}
		});
	}
}
