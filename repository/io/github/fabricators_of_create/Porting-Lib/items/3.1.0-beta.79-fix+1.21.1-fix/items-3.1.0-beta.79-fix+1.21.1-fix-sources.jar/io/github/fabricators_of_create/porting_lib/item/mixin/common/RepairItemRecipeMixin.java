package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1799;
import net.minecraft.class_4317;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_4317.class)
public class RepairItemRecipeMixin {
	@ModifyReturnValue(method = "canCombine", at = @At("RETURN"))
	private static boolean checkRepairable(boolean original, class_1799 itemStack, class_1799 itemStack2) {
		return original && itemStack.isRepairable() && itemStack2.isRepairable();
	}
}
