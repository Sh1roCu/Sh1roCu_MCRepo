package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.item.extensions.CustomFuelItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2591;
import net.minecraft.class_2609;
import net.minecraft.class_2680;
import net.minecraft.class_3956;

@Mixin(class_2609.class)
public abstract class AbstractFurnaceBlockEntityMixin {
	@Unique private class_3956<?> recipeType;

	@Inject(method = "<init>", at = @At("TAIL"))
	private void port_lib$storeRecipeType(class_2591<?> type, class_2338 pos, class_2680 blockState, class_3956<?> recipeType, CallbackInfo ci) {
		this.recipeType = recipeType;
	}

	@WrapOperation(method = "getBurnDuration", at = @At(value = "INVOKE", target = "Ljava/util/Map;getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", ordinal = 0))
	private <K, V> V port_lib$tryUseCustomFuel(Map<K, V> instance, Object key, V defaultValue, Operation<V> original, @Local(argsOnly = true) class_1799 stack) {
		if (stack.method_7909() instanceof CustomFuelItem fuelItem) {
			return (V) (Object) fuelItem.getBurnTime(stack, this.recipeType); // yes, I understand that this is an unsafe cast. but the return type is in fact an int.
		}

		return original.call(instance, key, defaultValue);
	}

	@Inject(method = "isFuel", at = @At("HEAD"), cancellable = true)
	private static void port_lib$checkIsCustomFuel(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
		if (stack.method_7909() instanceof CustomFuelItem fuelItem) {
			cir.setReturnValue(fuelItem.getBurnTime(stack, null) > 0);
		}
	}

	@WrapOperation(method = "canPlaceItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/entity/AbstractFurnaceBlockEntity;isFuel(Lnet/minecraft/world/item/ItemStack;)Z"))
	private boolean port_lib$checkIsCustomFuel(class_1799 stack, Operation<Boolean> original) {
		if (stack.method_7909() instanceof CustomFuelItem fuelItem) {
			return fuelItem.getBurnTime(stack, this.recipeType) > 0;
		}

		return original.call(stack);
	}
}
