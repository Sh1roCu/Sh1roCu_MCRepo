package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1799;

public interface ReequipAnimationItem {
	default boolean shouldCauseReequipAnimation(class_1799 oldStack, class_1799 newStack, boolean slotChanged) {
		return !oldStack.equals(newStack);
	}
}
