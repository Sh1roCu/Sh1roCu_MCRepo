package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.item.extensions.CustomSupportsEnchantItem;
import net.minecraft.class_1706;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1706.class)
public abstract class AnvilMenuMixin {
	@WrapOperation(method = "createResult", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/enchantment/Enchantment;canEnchant(Lnet/minecraft/world/item/ItemStack;)Z"))
	private boolean port_lib$checkItemSupportsEnchantment(class_1887 instance, class_1799 stack, Operation<Boolean> original, @Local class_6880<class_1887> holder) {
		if (stack.method_7909() instanceof CustomSupportsEnchantItem supportsEnchantItem) {
			return supportsEnchantItem.supportsEnchantment(stack, holder);
		}

		return original.call(instance, stack);
	}
}
