package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1792;
import net.minecraft.class_1799;

public interface CustomEnchantmentValueItem {
	/**
	 * ItemStack sensitive version of {@link class_1792#method_7837()}.
	 *
	 * @param stack The ItemStack
	 * @return the enchantment value
	 */
	int getEnchantmentValue(class_1799 stack);
}
