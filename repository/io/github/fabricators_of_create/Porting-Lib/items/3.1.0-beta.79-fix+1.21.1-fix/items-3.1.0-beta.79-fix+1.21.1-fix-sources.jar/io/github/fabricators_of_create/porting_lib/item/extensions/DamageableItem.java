package io.github.fabricators_of_create.porting_lib.item.extensions;

import io.github.fabricators_of_create.porting_lib.item.injects.ItemInjection;
import net.minecraft.class_1799;
import net.minecraft.class_9334;

public interface DamageableItem {

	/**
	 * Called by CraftingManager to determine if an item is repairable.
	 *
	 * @return True if reparable
	 */
	default boolean isRepairable(class_1799 stack) {
		return ((ItemInjection) this).port_lib$canRepair() && isDamageable(stack);
	}

	/**
	 * Used to test if this item can be damaged, but with the ItemStack in question.
	 * Please note that in some cases no ItemStack is available, so the stack-less method will be used.
	 *
	 * @param stack ItemStack in the Chest slot of the entity.
	 */
	default boolean isDamageable(class_1799 stack) {
		return stack.method_57826(class_9334.field_50072);
	}
}
