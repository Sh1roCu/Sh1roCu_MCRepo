package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import io.github.fabricators_of_create.porting_lib.item.extensions.ContinueUsingItem;
import io.github.fabricators_of_create.porting_lib.item.extensions.EntitySwingListenerItem;

import io.github.fabricators_of_create.porting_lib.item.extensions.EquipmentItem;

import io.github.fabricators_of_create.porting_lib.item.extensions.ShieldBlockItem;
import io.github.fabricators_of_create.porting_lib.item.extensions.UsingTickItem;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

@SuppressWarnings("ConstantConditions")
@Mixin(value = class_1309.class, priority = 500)
public abstract class LivingEntityMixin extends class_1297 {
	@Shadow
	public abstract class_1799 getItemInHand(class_1268 interactionHand);

	@Shadow
	protected class_1799 useItem;

	@Shadow
	protected int useItemRemaining;

	@Shadow
	public abstract class_1268 getUsedItemHand();

	@Shadow
	@NotNull
	public abstract class_1799 method_59958();

	public LivingEntityMixin(class_1299<?> entityType, class_1937 world) {
		super(entityType, world);
	}

	@Inject(method = "swing(Lnet/minecraft/world/InteractionHand;Z)V", at = @At("HEAD"), cancellable = true)
	private void swingHand(class_1268 hand, boolean bl, CallbackInfo ci) {
		class_1799 stack = getItemInHand(hand);
		if (!stack.method_7960() && stack.method_7909() instanceof EntitySwingListenerItem listener && listener.onEntitySwing(stack, (class_1309) (Object) this))
			ci.cancel();
	}

	@Inject(method = "getEquipmentSlotForItem", at = @At("HEAD"), cancellable = true)
	private void getSlotForItemStack(class_1799 itemStack, CallbackInfoReturnable<class_1304> cir) {
		if (itemStack.method_7909() instanceof EquipmentItem equipment) {
			class_1304 slot = equipment.getEquipmentSlot(itemStack);

			if (slot != null) {
				cir.setReturnValue(slot);
			}
		}
	}

	@Inject(method = "updatingUsingItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getItemInHand(Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/item/ItemStack;", shift = Shift.AFTER, ordinal = 1))
	public void onUsingTick(CallbackInfo ci) {
		if (useItem.method_7909() instanceof UsingTickItem usingTickItem) {
			if (!this.useItem.method_7960()) {
				if (useItemRemaining > 0)
					usingTickItem.onUsingTick(useItem, (class_1309) (Object) this, useItemRemaining);
			}
		}
	}

	@ModifyExpressionValue(method = "updatingUsingItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;isSameItem(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;)Z"))
	public boolean canContinueUsing(boolean original) {
		if (useItem.method_7909() instanceof ContinueUsingItem continueUsingItem) {
			class_1799 to = this.getItemInHand(this.getUsedItemHand());
			if (!useItem.method_7960() && !to.method_7960())
			{
				return continueUsingItem.canContinueUsing(useItem, to);
			}
			return false;
		}
		return original;
	}

	@ModifyReturnValue(method = "canDisableShield", at = @At("RETURN"))
	private boolean canDisableShieldItem(boolean original) {
		if (!original) {
			class_1799 weapon = method_59958();
			if (weapon.method_7909() instanceof ShieldBlockItem shieldBlockItem)
				return shieldBlockItem.canDisableShield(weapon, this.useItem, (class_1309) (Object) this, (class_1309) (Object) this);
		}
		return original;
	}
}
