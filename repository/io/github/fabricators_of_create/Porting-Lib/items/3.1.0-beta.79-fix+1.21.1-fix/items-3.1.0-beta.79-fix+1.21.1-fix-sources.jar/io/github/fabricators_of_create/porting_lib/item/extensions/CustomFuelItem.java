package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_3956;
import org.jetbrains.annotations.Nullable;

public interface CustomFuelItem {
	/**
	 * @return The fuel burn time for this item stack in a furnace. Return 0 to make
	 *         it not act as a fuel. Return -1 to let the default vanilla logic decide.
	 * @apiNote You should try to use {@link FuelRegistry#add} where possible, as this method is primarily for items that require
	 * 			the usage of {@link class_3956}.
	 */
	default int getBurnTime(class_1799 stack, @Nullable class_3956<?> recipeType) {
		Integer fuel = FuelRegistry.INSTANCE.get((class_1935) this);
		return fuel == null ? 0 : fuel;
	}
}
