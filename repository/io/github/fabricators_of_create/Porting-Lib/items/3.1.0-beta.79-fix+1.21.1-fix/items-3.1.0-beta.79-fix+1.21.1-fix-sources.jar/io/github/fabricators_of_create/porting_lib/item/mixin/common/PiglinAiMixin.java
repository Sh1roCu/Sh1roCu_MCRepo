package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import io.github.fabricators_of_create.porting_lib.item.extensions.PiglinsNeutralItem;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4838;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4838.class)
public class PiglinAiMixin {
	@Inject(method = "isWearingGold", at = @At("HEAD"), cancellable = true)
	private static void isNeutralItem(class_1309 entity, CallbackInfoReturnable<Boolean> cir) {
		for(class_1799 armor : entity.method_5661()) {
			if(armor.method_7909() instanceof PiglinsNeutralItem piglinsNeutralItem) {
				cir.setReturnValue(piglinsNeutralItem.makesPiglinsNeutral(armor, entity));
				return;
			}
		}
	}
}
