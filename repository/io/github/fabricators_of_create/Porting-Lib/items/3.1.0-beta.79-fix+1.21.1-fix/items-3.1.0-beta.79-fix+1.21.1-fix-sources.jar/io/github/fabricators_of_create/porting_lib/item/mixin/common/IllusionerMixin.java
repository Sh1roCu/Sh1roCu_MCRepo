package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.item.extensions.CustomArrowItem;
import net.minecraft.class_1581;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1581.class)
public class IllusionerMixin {
	@ModifyVariable(method = "performRangedAttack", at = @At(value = "STORE", ordinal = 0), index = 5)
	private class_1665 modifyCustomArrow(class_1665 value, @Local(index = 3) class_1799 weaponStack, @Local(index = 4) class_1799 projectileStack) {
		if (weaponStack.method_7909() instanceof CustomArrowItem bowItem)
			return bowItem.customArrow(value, projectileStack, weaponStack);
		return value;
	}
}
