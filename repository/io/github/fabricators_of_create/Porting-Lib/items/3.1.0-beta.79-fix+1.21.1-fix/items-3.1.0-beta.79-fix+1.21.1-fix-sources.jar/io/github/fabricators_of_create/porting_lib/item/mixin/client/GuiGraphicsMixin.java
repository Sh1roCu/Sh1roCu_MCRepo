package io.github.fabricators_of_create.porting_lib.item.mixin.client;

import io.github.fabricators_of_create.porting_lib.item.client.ItemDecoratorHandler;
import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_332.class)
public class GuiGraphicsMixin {
	@Inject(
			method = "renderItemDecorations(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;IILjava/lang/String;)V",
			at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V", shift = At.Shift.AFTER)
	)
	private void renderCustomItemDecorations(class_327 textRenderer, class_1799 stack, int x, int y, String countOverride, CallbackInfo ci) {
		ItemDecoratorHandler.of(stack).render((class_332) (Object) this, textRenderer, stack, x, y);
	}
}
