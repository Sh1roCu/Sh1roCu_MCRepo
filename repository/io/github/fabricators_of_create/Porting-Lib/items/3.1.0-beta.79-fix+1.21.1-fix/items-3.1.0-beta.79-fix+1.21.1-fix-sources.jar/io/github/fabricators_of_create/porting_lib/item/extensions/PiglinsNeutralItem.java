package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1740;
import net.minecraft.class_1799;

public interface PiglinsNeutralItem {
	/**
	 * Called by Piglins to check if a given item prevents hostility on sight. If this is true the Piglins will be neutral to the entity wearing this item, and will not
	 * attack on sight. Note: This does not prevent Piglins from becoming hostile due to other actions, nor does it make Piglins that are already hostile stop being so.
	 *
	 * @param wearer The entity wearing this ItemStack
	 *
	 * @return True if piglins are neutral to players wearing this item in an armor slot
	 */
	default boolean makesPiglinsNeutral(class_1799 stack, class_1309 wearer) {
		return stack.method_7909() instanceof class_1738 && ((class_1738) stack.method_7909()).method_7686() == class_1740.field_7895;
	}
}
