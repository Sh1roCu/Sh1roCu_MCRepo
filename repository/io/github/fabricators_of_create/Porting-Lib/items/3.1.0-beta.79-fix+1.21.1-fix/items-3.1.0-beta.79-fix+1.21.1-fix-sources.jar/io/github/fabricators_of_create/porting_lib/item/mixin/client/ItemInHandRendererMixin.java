package io.github.fabricators_of_create.porting_lib.item.mixin.client;

import javax.annotation.Nonnull;
import net.minecraft.class_1799;
import net.minecraft.class_746;
import net.minecraft.class_759;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.item.extensions.ReequipAnimationItem;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public abstract class ItemInHandRendererMixin {
	@Shadow
	private class_1799 mainHandItem;
	@Shadow
	private class_1799 offHandItem;

	@Unique
	private static int port_lib$mainHandSlot = 0;

	@Inject(
			method = "tick",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/player/LocalPlayer;getAttackStrengthScale(F)F",
					shift = At.Shift.AFTER
			)
	)
	public void tick(CallbackInfo ci, @Local class_746 clientPlayerEntity, @Local(ordinal = 0) class_1799 itemStack, @Local(ordinal = 1) class_1799 itemStack2) {
		if (!port_lib$shouldCauseReequipAnimation(mainHandItem, itemStack, clientPlayerEntity.method_31548().field_7545)) {
			mainHandItem = itemStack;
		}

		if (!port_lib$shouldCauseReequipAnimation(offHandItem, itemStack2, -1)) {
			offHandItem = itemStack2;
		}
	}

	private static boolean port_lib$shouldCauseReequipAnimation(@Nonnull class_1799 from, @Nonnull class_1799 to, int slot) {
		if (!from.method_7960() && !to.method_7960()) {
			boolean changed = false;
			if (slot != -1) {
				changed = slot != port_lib$mainHandSlot;
				port_lib$mainHandSlot = slot;
			}

			if (from.method_7909() instanceof ReequipAnimationItem handler) {
				return handler.shouldCauseReequipAnimation(from, to, changed);
			}
		}
		return true;
	}
}
