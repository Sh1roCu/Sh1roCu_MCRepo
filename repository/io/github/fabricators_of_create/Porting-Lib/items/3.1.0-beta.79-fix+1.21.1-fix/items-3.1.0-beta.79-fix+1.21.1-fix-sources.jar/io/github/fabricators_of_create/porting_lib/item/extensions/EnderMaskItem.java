package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1560;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2246;

public interface EnderMaskItem {
	/**
	 * Whether this Item can be used to hide player head for enderman.
	 *
	 * @param stack          the ItemStack
	 * @param player         The player watching the enderman
	 * @param endermanEntity The enderman that the player look
	 * @return true if this Item can be used to hide player head for enderman
	 */
	default boolean isEnderMask(class_1799 stack, class_1657 player, class_1560 endermanEntity) {
		return stack.method_7909() == class_2246.field_10147.method_8389();
	}
}
