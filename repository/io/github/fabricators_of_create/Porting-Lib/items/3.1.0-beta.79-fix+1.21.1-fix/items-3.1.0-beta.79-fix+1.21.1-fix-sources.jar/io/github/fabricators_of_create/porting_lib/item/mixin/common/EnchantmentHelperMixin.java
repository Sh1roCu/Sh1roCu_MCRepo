package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.item.extensions.CustomEnchantmentValueItem;
import io.github.fabricators_of_create.porting_lib.item.extensions.CustomSupportsEnchantItem;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1890.class)
public abstract class EnchantmentHelperMixin {
	@WrapOperation(method = "method_60143", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/enchantment/Enchantment;isPrimaryItem(Lnet/minecraft/world/item/ItemStack;)Z"))
	private static boolean port_lib$tryCheckIsPrimaryItem(class_1887 instance, class_1799 stack, Operation<Boolean> original, @Local(argsOnly = true) class_6880<class_1887> holder) {
		if (stack.method_7909() instanceof CustomSupportsEnchantItem supportsEnchantItem) {
			return supportsEnchantItem.isPrimaryItemFor(stack, holder);
		}

		return original.call(instance, stack);
	}

	@WrapOperation(method = {"getEnchantmentCost", "selectEnchantment"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/Item;getEnchantmentValue()I"))
	private static int port_lib$tryUseStackAwareEnchantmentValue(class_1792 instance, Operation<Integer> original, @Local(argsOnly = true) class_1799 stack) {
		if (instance instanceof CustomEnchantmentValueItem enchantmentValueItem) {
			return enchantmentValueItem.getEnchantmentValue(stack);
		}

		return original.call(instance);
	}
}
