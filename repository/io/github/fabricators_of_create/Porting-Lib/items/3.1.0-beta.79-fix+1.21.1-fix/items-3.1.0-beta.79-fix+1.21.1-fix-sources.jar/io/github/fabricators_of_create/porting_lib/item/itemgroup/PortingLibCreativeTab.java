package io.github.fabricators_of_create.porting_lib.item.itemgroup;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_1761;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import io.github.fabricators_of_create.porting_lib.item.extensions.CreativeModeTabExt;

public class PortingLibCreativeTab {
	public static PortingLibCreativeTabBuilder builder() {
		return new PortingLibCreativeTabBuilder();
	}

	public static class PortingLibCreativeTabBuilder extends class_1761.class_7913 {
		public static final class_2960 CREATIVE_TABS_LOCATION = class_2960.method_60656("textures/gui/container/creative_inventory/tabs.png");

		private boolean hasDisplayName = false;
		private class_2960 tabsImage = CREATIVE_TABS_LOCATION;
		private int labelColor = 4210752;
		private int slotColor = -2130706433;
		private final List<class_2960> tabsBefore = new ArrayList<>();
		private final List<class_2960> tabsAfter = new ArrayList<>();

		public PortingLibCreativeTabBuilder() {
			// Set when building.
			super(null, -1);
		}

		@Override
		public PortingLibCreativeTabBuilder method_47321(class_2561 displayName) {
			hasDisplayName = true;
			return (PortingLibCreativeTabBuilder) super.method_47321(displayName);
		}

		@Override
		public class_1761 method_47324() {
			if (!hasDisplayName) {
				throw new IllegalStateException("No display name set for ItemGroup");
			}

			class_1761 tab = super.method_47324();
			((CreativeModeTabExt) tab).setPortingData(new TabData(tabsImage, labelColor, slotColor, tabsBefore, tabsAfter));
			return tab;
		}

		/**
		 * Sets the image of the tab to a custom resource location, instead of an item's texture.
		 */
		public PortingLibCreativeTabBuilder withTabsImage(class_2960 tabsImage) {
			this.tabsImage = tabsImage;
			return this;
		}

		/**
		 * Sets the color of the tab label.
		 */
		public PortingLibCreativeTabBuilder withLabelColor(int labelColor) {
			this.labelColor = labelColor;
			return this;
		}

		/**
		 * Sets the color of tab's slots.
		 */
		public PortingLibCreativeTabBuilder withSlotColor(int slotColor) {
			this.slotColor = slotColor;
			return this;
		}

		/** Define tabs that should come <i>before</i> this tab. This tab will be placed <strong>after</strong> the {@code tabs}. **/
		public PortingLibCreativeTabBuilder withTabsBefore(class_2960... tabs) {
			this.tabsBefore.addAll(List.of(tabs));
			return this;
		}

		/** Define tabs that should come <i>after</i> this tab. This tab will be placed <strong>before</strong> the {@code tabs}.**/
		public PortingLibCreativeTabBuilder withTabsAfter(class_2960... tabs) {
			this.tabsAfter.addAll(List.of(tabs));
			return this;
		}

		/** Define tabs that should come <i>before</i> this tab. This tab will be placed <strong>after</strong> the {@code tabs}. **/
		@SafeVarargs
		public final PortingLibCreativeTabBuilder withTabsBefore(class_5321<class_1761>... tabs) {
			Stream.of(tabs).map(class_5321::method_29177).forEach(this.tabsBefore::add);
			return this;
		}

		/** Define tabs that should come <i>after</i> this tab. This tab will be placed <strong>before</strong> the {@code tabs}.**/
		@SafeVarargs
		public final PortingLibCreativeTabBuilder withTabsAfter(class_5321<class_1761>... tabs) {
			Stream.of(tabs).map(class_5321::method_29177).forEach(this.tabsAfter::add);
			return this;
		}
	}

	public record TabData(class_2960 tabsImage, int labelColor, int slotColor, List<class_2960> tabsBefore, List<class_2960> tabsAfter) {}
}
