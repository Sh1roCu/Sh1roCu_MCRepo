package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1542;
import net.minecraft.class_1799;

public interface EntityTickListenerItem {
	boolean onEntityItemUpdate(class_1799 stack, class_1542 entity);
}
