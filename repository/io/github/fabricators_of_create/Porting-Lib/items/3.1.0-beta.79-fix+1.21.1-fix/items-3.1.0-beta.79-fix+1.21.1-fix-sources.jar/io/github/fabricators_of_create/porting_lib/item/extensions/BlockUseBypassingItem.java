package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface BlockUseBypassingItem {
	boolean shouldBypass(class_2680 state, class_2338 pos, class_1937 level, class_1657 player, class_1268 hand);
}
