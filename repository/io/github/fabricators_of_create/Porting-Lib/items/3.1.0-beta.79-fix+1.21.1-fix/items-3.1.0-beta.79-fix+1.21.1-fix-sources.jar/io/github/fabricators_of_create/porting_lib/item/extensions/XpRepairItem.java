package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1799;

public interface XpRepairItem {
	/**
	 * Determines the amount of durability the mending enchantment
	 * will repair, on average, per point of experience.
	 */
	default float getXpRepairRatio(class_1799 stack) {
		return 2f;
	}
}
