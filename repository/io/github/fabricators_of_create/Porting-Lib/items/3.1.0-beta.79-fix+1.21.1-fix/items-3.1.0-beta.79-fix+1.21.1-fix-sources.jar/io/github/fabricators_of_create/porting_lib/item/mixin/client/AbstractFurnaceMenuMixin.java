package io.github.fabricators_of_create.porting_lib.item.mixin.client;

import io.github.fabricators_of_create.porting_lib.item.extensions.CustomFuelItem;
import net.minecraft.class_1720;
import net.minecraft.class_1799;
import net.minecraft.class_1874;
import net.minecraft.class_3956;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1720.class)
public abstract class AbstractFurnaceMenuMixin {
	@Shadow
	@Final
	private class_3956<? extends class_1874> recipeType;

	@Inject(method = "isFuel", at = @At("HEAD"), cancellable = true)
	private void port_lib$tryUseCustomFuelItem(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
		if (stack.method_7909() instanceof CustomFuelItem fuelItem) {
			cir.setReturnValue(fuelItem.getBurnTime(stack, this.recipeType) > 0);
		}
	}
}
