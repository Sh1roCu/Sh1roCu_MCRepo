package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1309;
import net.minecraft.class_1799;

public interface UsingTickItem {
	/**
	 * Called each tick while using an item.
	 *
	 * @param stack  The Item being used
	 * @param player The Player using the item
	 * @param count  The amount of time in tick the item has been used for
	 *               continuously
	 */
	default void onUsingTick(class_1799 stack, class_1309 player, int count) {}
}
