package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.item.extensions.CustomDamageItem;
import io.github.fabricators_of_create.porting_lib.item.injects.ItemStackInjection;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.function.Consumer;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

@Mixin(class_1799.class)
public abstract class ItemStackMixin implements ItemStackInjection {
	@Shadow
	public abstract class_1792 getItem();

	@ModifyVariable(method = "hurtAndBreak(ILnet/minecraft/server/level/ServerLevel;Lnet/minecraft/server/level/ServerPlayer;Ljava/util/function/Consumer;)V", at = @At("HEAD"), argsOnly = true)
	private int port_lib$tryUseCustomDamage(int value, @Local(argsOnly = true) class_3222 entity, @Local(argsOnly = true) Consumer<class_1792> onBroken) {
		if (this.getItem() instanceof CustomDamageItem customDamageItem) {
			return customDamageItem.damageItem((class_1799) (Object) this, value, entity, onBroken);
		}

		return value;
	}
}
