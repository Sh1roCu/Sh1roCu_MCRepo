package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import io.github.fabricators_of_create.porting_lib.item.injects.ItemContainerContentsInjection;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_9288;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_9288.class)
public abstract class ItemContainerContentsMixin implements ItemContainerContentsInjection {
	@Shadow
	@Final
	private class_2371<class_1799> items;

	@Override
	public int port_lib$getSlots() {
		return items.size();
	}

	@Override
	public class_1799 port_lib$getStackInSlot(int slot) {
		port_lib$validateSlotIndex(slot);
		return items.get(slot).method_7972();
	}

	@Unique
	private void port_lib$validateSlotIndex(int slot) {
		if (slot < 0 || slot >= port_lib$getSlots()) {
			throw new UnsupportedOperationException("Slot " + slot + " not in valid range - [0," + port_lib$getSlots() + ")");
		}
	}
}
