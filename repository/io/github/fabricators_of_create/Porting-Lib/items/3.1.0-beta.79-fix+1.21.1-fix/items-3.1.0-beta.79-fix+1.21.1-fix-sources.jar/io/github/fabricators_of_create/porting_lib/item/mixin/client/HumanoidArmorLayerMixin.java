package io.github.fabricators_of_create.porting_lib.item.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.item.client.ItemClientHooks;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_572;
import net.minecraft.class_970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_970.class)
public abstract class HumanoidArmorLayerMixin extends class_3887<class_1309, class_572<class_1309>> {
	public HumanoidArmorLayerMixin(class_3883<class_1309, class_572<class_1309>> renderer) {
		super(renderer);
	}

	@WrapOperation(method = "renderArmorPiece", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ArmorMaterial$Layer;texture(Z)Lnet/minecraft/resources/ResourceLocation;"))
	public<T extends class_1309, A extends class_572<T>> class_2960 fixArmorTextures(class_1741.class_9196 instance, boolean innerTexture, Operation<class_2960> original, @Local(argsOnly = true) T entity, @Local(argsOnly = true) class_1304 slot, @Local(ordinal = 0) class_1799 stack) {
		return ItemClientHooks.getArmorTexture(entity, stack, instance, innerTexture, slot, original);
	}
}
