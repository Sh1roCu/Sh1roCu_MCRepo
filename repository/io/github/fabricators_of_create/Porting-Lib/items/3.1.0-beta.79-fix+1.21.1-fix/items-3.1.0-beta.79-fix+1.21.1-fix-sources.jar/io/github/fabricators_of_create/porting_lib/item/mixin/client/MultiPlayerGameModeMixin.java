package io.github.fabricators_of_create.porting_lib.item.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyReceiver;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.item.extensions.BlockUseBypassingItem;
import io.github.fabricators_of_create.porting_lib.item.extensions.SneakBypassUseItem;
import io.github.fabricators_of_create.porting_lib.item.extensions.UseFirstBehaviorItem;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2694;
import net.minecraft.class_3468;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public class MultiPlayerGameModeMixin {
	@ModifyReceiver(method = "performUseItemOn", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;useItemOn(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/world/phys/BlockHitResult;)Lnet/minecraft/world/ItemInteractionResult;"))
	public class_2680 bypassBlockUse(class_2680 instance, class_1799 itemStack, class_1937 level, class_1657 player, class_1268 hand, class_3965 blockHitResult) {
		class_1792 held = player.method_5998(hand).method_7909();
		if (held instanceof BlockUseBypassingItem bypassing) {
			if (bypassing.shouldBypass(level.method_8320(blockHitResult.method_17777()), blockHitResult.method_17777(), level, player, hand))
				return class_2246.field_10499.method_9564();
		} else if (held instanceof class_1747 blockItem && blockItem.method_7711() instanceof BlockUseBypassingItem bypassing) {
			if (bypassing.shouldBypass(level.method_8320(blockHitResult.method_17777()), blockHitResult.method_17777(), level, player, hand)) return class_2246.field_10499.method_9564();
		}
		return instance;
	}

	@Inject(method = "performUseItemOn",at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;getMainHandItem()Lnet/minecraft/world/item/ItemStack;"), cancellable = true)
	public void useItemOn(class_746 player, class_1268 hand, class_3965 hit, CallbackInfoReturnable<class_1269> cir) {
		class_1799 heldItem = player.method_5998(hand);
		if (heldItem.method_7909() instanceof UseFirstBehaviorItem useFirst) {
			class_1838 ctx = new class_1838(player, hand, hit);
			class_2338 pos = ctx.method_8037();
			class_2694 block = new class_2694(ctx.method_8045(), pos, false);
			if (!player.method_31549().field_7476 && !heldItem.method_57357(block)) {
				cir.setReturnValue(class_1269.field_5811);
			} else {
				class_1792 item = heldItem.method_7909();
				class_1269 result = useFirst.onItemUseFirst(heldItem, ctx);
				if (result.method_36360()) {
					player.method_7259(class_3468.field_15372.method_14956(item));
				}

				if (result != class_1269.field_5811) {
					cir.setReturnValue(result);
				}
			}
		}
	}

	@WrapOperation(method = "performUseItemOn", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;isEmpty()Z"), slice = @Slice(to = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;isSecondaryUseActive()Z")))
	private boolean checkDoesSneakBypassUse(class_1799 instance, Operation<Boolean> original, @Local(argsOnly = true) class_746 player, @Local class_2338 pos) {
		if (instance.method_7909() instanceof SneakBypassUseItem bypassUseItem)
			return bypassUseItem.doesSneakBypassUse(instance, player.method_37908(), pos, player);

		return original.call(instance);
	}
}
