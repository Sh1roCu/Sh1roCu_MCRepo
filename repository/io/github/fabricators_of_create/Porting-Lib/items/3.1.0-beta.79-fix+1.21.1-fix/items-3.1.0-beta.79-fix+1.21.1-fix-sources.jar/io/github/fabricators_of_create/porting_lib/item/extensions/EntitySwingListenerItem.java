package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1309;
import net.minecraft.class_1799;

public interface EntitySwingListenerItem {
	boolean onEntitySwing(class_1799 stack, class_1309 entity);
}
