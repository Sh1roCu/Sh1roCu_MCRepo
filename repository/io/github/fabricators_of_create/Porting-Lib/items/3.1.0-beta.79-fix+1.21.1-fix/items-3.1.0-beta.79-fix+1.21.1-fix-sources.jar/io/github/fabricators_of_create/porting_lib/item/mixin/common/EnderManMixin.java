package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.item.extensions.EnderMaskItem;
import net.minecraft.class_1560;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1560.class)
public abstract class EnderManMixin {
	@WrapOperation(method = "isLookingAtMe", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;is(Lnet/minecraft/world/item/Item;)Z", ordinal = 0))
	private boolean port_lib$checkIsEndermanMask(class_1799 instance, class_1792 item, Operation<Boolean> original, @Local(argsOnly = true) class_1657 player) {
		if (instance.method_7909() instanceof EnderMaskItem enderMaskItem) {
			return enderMaskItem.isEnderMask(instance, player, (class_1560) (Object) this);
		}

		return original.call(instance, item);
	}
}
