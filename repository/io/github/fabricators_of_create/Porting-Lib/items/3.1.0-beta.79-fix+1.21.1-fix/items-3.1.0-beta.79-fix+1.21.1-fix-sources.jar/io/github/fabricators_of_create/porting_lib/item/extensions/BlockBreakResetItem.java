package io.github.fabricators_of_create.porting_lib.item.extensions;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import net.minecraft.class_1799;
import net.minecraft.class_9323;
import net.minecraft.class_9331;
import net.minecraft.class_9334;

public interface BlockBreakResetItem {
	/**
	 * Called when the player is mining a block and the item in their hand changes.
	 * Allows to not reset block breaking if only NBT or similar changes.
	 *
	 * @param oldStack The old stack that was used for mining. Item in players main
	 *                 hand
	 * @param newStack The new stack
	 * @return True to reset block break progress
	 */
	default boolean shouldCauseBlockBreakReset(class_1799 oldStack, class_1799 newStack) {
		if (!newStack.method_31574(oldStack.method_7909()))
			return true;

		if (!newStack.method_7963() || !oldStack.method_7963())
			return !class_1799.method_31577(newStack, oldStack);

		class_9323 newComponents = newStack.method_57353();
		class_9323 oldComponents = oldStack.method_57353();

		if (newComponents.method_57837() || oldComponents.method_57837())
			return !(newComponents.method_57837() && oldComponents.method_57837());

		Set<class_9331<?>> newKeys = new HashSet<>(newComponents.method_57831());
		Set<class_9331<?>> oldKeys = new HashSet<>(oldComponents.method_57831());

		newKeys.remove(class_9334.field_49629);
		oldKeys.remove(class_9334.field_49629);

		if (!newKeys.equals(oldKeys))
			return true;

		return !newKeys.stream().allMatch(key -> Objects.equals(newComponents.method_57829(key), oldComponents.method_57829(key)));
	}
}
