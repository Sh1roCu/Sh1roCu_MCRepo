package io.github.fabricators_of_create.porting_lib.item.extensions;

import java.util.Optional;
import net.minecraft.class_2263;
import net.minecraft.class_2680;
import net.minecraft.class_3414;

public interface CustomPickupBucketSoundItem {
	/**
	 * State sensitive variant of {@link class_2263#method_32351()}.
	 *
	 * Override to change the pickup sound based on the {@link class_2680} of the object being picked up.
	 *
	 * @param state State
	 *
	 * @return Sound event for pickup sound or empty if there isn't a pickup sound.
	 */
	Optional<class_3414> getPickupSound(class_2680 state);
}
