package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_4538;

public interface SneakBypassUseItem {
	/**
	 *
	 * Should this item, when held, allow sneak-clicks to pass through to the
	 * underlying block?
	 *
	 * @param level  The level
	 * @param pos    Block position in level
	 * @param player The Player that is wielding the item
	 */
	default boolean doesSneakBypassUse(class_1799 stack, class_4538 level, class_2338 pos, class_1657 player) {
		return false;
	}
}
