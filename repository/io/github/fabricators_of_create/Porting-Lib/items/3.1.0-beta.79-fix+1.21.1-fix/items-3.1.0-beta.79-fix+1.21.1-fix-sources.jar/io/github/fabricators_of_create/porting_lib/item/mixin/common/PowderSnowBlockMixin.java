package io.github.fabricators_of_create.porting_lib.item.mixin.common;

import io.github.fabricators_of_create.porting_lib.item.extensions.WalkOnSnowItem;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_5635;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5635.class)
public class PowderSnowBlockMixin {
	@Inject(method = "canEntityWalkOnPowderSnow", at = @At(value = "RETURN", ordinal = 1), cancellable = true)
	private static void canWalkOnSnow(class_1297 entity, CallbackInfoReturnable<Boolean> cir) {
		if (entity instanceof class_1309 livingEntity && livingEntity.method_6118(class_1304.field_6166).method_7909() instanceof WalkOnSnowItem walkOnSnowItem)
			cir.setReturnValue(walkOnSnowItem.canWalkOnPowderedSnow(livingEntity.method_6118(class_1304.field_6166), livingEntity));
	}
}
