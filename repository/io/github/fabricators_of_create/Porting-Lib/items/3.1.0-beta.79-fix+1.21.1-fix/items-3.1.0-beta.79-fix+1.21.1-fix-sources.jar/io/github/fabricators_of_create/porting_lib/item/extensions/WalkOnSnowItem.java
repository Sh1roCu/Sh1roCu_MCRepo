package io.github.fabricators_of_create.porting_lib.item.extensions;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public interface WalkOnSnowItem {
	/**
	 * Called by the powdered snow block to check if a living entity wearing this can walk on the snow, granting the same behavior as leather boots.
	 * Only affects items worn in the boots slot.
	 *
	 * @param stack  Stack instance
	 * @param wearer The entity wearing this ItemStack
	 *
	 * @return True if the entity can walk on powdered snow
	 */
	default boolean canWalkOnPowderedSnow(class_1799 stack, class_1309 wearer) {
		return stack.method_31574(class_1802.field_8370);
	}
}
