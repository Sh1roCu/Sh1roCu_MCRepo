package io.github.fabricators_of_create.porting_lib.core.util;

import com.mojang.datafixers.util.Function7;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_1923;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_5321;
import net.minecraft.class_9139;

public final class PortingLibStreamCodecs {
	public static final class_9139<class_2540, byte[]> UNBOUNDED_BYTE_ARRAY = new class_9139<>() {
		public byte[] decode(class_2540 buf) {
			return buf.method_10795();
		}

		public void encode(class_2540 buf, byte[] data) {
			buf.method_10813(data);
		}
	};

	public static final class_9139<class_2540, class_1923> CHUNK_POS = new class_9139<>() {
		@Override
		public class_1923 decode(class_2540 buf) {
			return buf.method_36133();
		}

		@Override
		public void encode(class_2540 buf, class_1923 pos) {
			buf.method_36130(pos);
		}
	};

	public static <B, V> class_9139<B, V> lazy(Supplier<class_9139<B, V>> streamCodecSupplier) {
		return new LazyStreamCodec<>(streamCodecSupplier);
	}

	private static class LazyStreamCodec<B, V> implements class_9139<B, V> {
		private final Lazy<class_9139<B, V>> delegate;

		public LazyStreamCodec(Supplier<class_9139<B, V>> streamCodecSupplier) {
			delegate = Lazy.of(streamCodecSupplier);
		}

		@Override
		public void encode(B buf, V value) {
			delegate.get().encode(buf, value);
		}

		@Override
		public V decode(B buf) {
			return delegate.get().decode(buf);
		}
	}

	public static <B extends class_2540, V extends Enum<V>> class_9139<B, V> enumCodec(Class<V> enumClass) {
		return new class_9139<>() {
			@Override
			public V decode(B buf) {
				return buf.method_10818(enumClass);
			}

			@Override
			public void encode(B buf, V value) {
				buf.method_10817(value);
			}
		};
	}

	/**
	 * Creates a stream codec to encode and decode a {@link class_5321} that identifies a registry.
	 */
	public static <B extends class_2540> class_9139<B, class_5321<? extends class_2378<?>>> registryKey() {
		return new class_9139<>() {
			@Override
			public class_5321<? extends class_2378<?>> decode(B buf) {
				return class_5321.method_29180(buf.method_10810());
			}

			@Override
			public void encode(B buf, class_5321<? extends class_2378<?>> value) {
				buf.method_10812(value.method_29177());
			}
		};
	}

	/**
	 * Similar to {@link class_9139#method_56431(Object)}, but without checks for the value to be encoded.
	 */
	public static <B, V> class_9139<B, V> uncheckedUnit(final V defaultValue) {
		return new class_9139<>() {
			@Override
			public V decode(B buf) {
				return defaultValue;
			}

			@Override
			public void encode(B buf, V value) {}
		};
	}

	public static <B, C, T1, T2, T3, T4, T5, T6, T7> class_9139<B, C> composite(
			final class_9139<? super B, T1> codec1,
			final Function<C, T1> getter1,
			final class_9139<? super B, T2> codec2,
			final Function<C, T2> getter2,
			final class_9139<? super B, T3> codec3,
			final Function<C, T3> getter3,
			final class_9139<? super B, T4> codec4,
			final Function<C, T4> getter4,
			final class_9139<? super B, T5> codec5,
			final Function<C, T5> getter5,
			final class_9139<? super B, T6> codec6,
			final Function<C, T6> getter6,
			final class_9139<? super B, T7> codec7,
			final Function<C, T7> getter7,
			final Function7<T1, T2, T3, T4, T5, T6, T7, C> p_331335_) {
		return new class_9139<>() {
			@Override
			public C decode(B p_330310_) {
				T1 t1 = codec1.decode(p_330310_);
				T2 t2 = codec2.decode(p_330310_);
				T3 t3 = codec3.decode(p_330310_);
				T4 t4 = codec4.decode(p_330310_);
				T5 t5 = codec5.decode(p_330310_);
				T6 t6 = codec6.decode(p_330310_);
				T7 t7 = codec7.decode(p_330310_);
				return p_331335_.apply(t1, t2, t3, t4, t5, t6, t7);
			}

			@Override
			public void encode(B p_332052_, C p_331912_) {
				codec1.encode(p_332052_, getter1.apply(p_331912_));
				codec2.encode(p_332052_, getter2.apply(p_331912_));
				codec3.encode(p_332052_, getter3.apply(p_331912_));
				codec4.encode(p_332052_, getter4.apply(p_331912_));
				codec5.encode(p_332052_, getter5.apply(p_331912_));
				codec6.encode(p_332052_, getter6.apply(p_331912_));
				codec7.encode(p_332052_, getter7.apply(p_331912_));
			}
		};
	}
}
