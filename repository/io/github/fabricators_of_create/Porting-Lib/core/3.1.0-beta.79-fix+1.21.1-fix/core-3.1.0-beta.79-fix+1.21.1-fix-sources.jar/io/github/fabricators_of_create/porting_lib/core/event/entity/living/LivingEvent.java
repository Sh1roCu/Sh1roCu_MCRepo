package io.github.fabricators_of_create.porting_lib.core.event.entity.living;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.EntityEvent;
import net.minecraft.class_1309;

/**
 * LivingEvent is fired whenever an event involving a {@link class_1309} occurs.<br>
 * If a method utilizes this {@link BaseEvent} as its parameter, the method will
 * receive every child event of this class.<br>
 * <br>
 **/
public abstract class LivingEvent extends EntityEvent {
	private final class_1309 livingEntity;

	public LivingEvent(class_1309 entity) {
		super(entity);
		livingEntity = entity;
	}

	@Override
	public class_1309 getEntity() {
		return livingEntity;
	}
}
