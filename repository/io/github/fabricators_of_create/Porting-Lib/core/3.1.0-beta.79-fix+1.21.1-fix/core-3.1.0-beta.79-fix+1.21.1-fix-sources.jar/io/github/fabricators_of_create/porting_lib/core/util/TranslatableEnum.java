package io.github.fabricators_of_create.porting_lib.core.util;

import net.minecraft.class_2561;

/**
 * An enum value that can be be translated.
 */
public interface TranslatableEnum {
	/**
	 * {@return the translated name of this value}
	 * Defaults to a {@linkplain class_2561#method_43470(String) literal component} with the {@link Enum#name() enum name};
	 */
	default class_2561 getTranslatedName() {
		return class_2561.method_43470(((Enum<?>) this).name());
	}
}
