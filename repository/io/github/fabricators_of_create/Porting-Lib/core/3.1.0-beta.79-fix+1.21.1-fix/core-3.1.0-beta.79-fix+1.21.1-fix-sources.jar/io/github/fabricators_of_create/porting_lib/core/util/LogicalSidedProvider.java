package io.github.fabricators_of_create.porting_lib.core.util;

import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;

import net.fabricmc.api.EnvType;
import net.minecraft.class_1255;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_3738;
import net.minecraft.server.MinecraftServer;

public class LogicalSidedProvider<T> {
	public static final LogicalSidedProvider<class_1255<? super class_3738>> WORKQUEUE = new LogicalSidedProvider<>(Supplier::get, Supplier::get);
	public static final LogicalSidedProvider<Optional<class_1937>> CLIENTWORLD = new LogicalSidedProvider<>((c)-> Optional.of(c.get().field_1687), (s)->Optional.empty());

	private static Supplier<class_310> client;
	private static Supplier<MinecraftServer> server;

	// INTERNAL, DO  NOT CALL
	public static void setClient(Supplier<class_310> client) {
		LogicalSidedProvider.client = client;
	}
	public static void setServer(Supplier<MinecraftServer> server)
	{
		LogicalSidedProvider.server = server;
	}

	private LogicalSidedProvider(Function<Supplier<class_310>, T> clientSide, Function<Supplier<MinecraftServer>, T> serverSide) {
		this.clientSide = clientSide;
		this.serverSide = serverSide;
	}

	private final Function<Supplier<class_310>, T> clientSide;
	private final Function<Supplier<MinecraftServer>, T> serverSide;

	public T get(final EnvType side) {
		return side==EnvType.CLIENT ? clientSide.apply(client) : serverSide.apply(server);
	}
}

