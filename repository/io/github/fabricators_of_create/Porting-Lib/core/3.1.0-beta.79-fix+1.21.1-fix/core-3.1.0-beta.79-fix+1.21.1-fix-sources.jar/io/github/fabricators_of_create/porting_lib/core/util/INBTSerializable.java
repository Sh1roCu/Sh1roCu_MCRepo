package io.github.fabricators_of_create.porting_lib.core.util;

import net.minecraft.class_2520;
import net.minecraft.class_7225;
import org.jetbrains.annotations.UnknownNullability;

/**
 * An interface designed to unify various things in the Minecraft
 * code base that can be serialized to and from a NBT tag.
 */
public interface INBTSerializable<T extends class_2520> {
	@UnknownNullability
	T serializeNBT(class_7225.class_7874 provider);

	void deserializeNBT(class_7225.class_7874 provider, T nbt);
}
