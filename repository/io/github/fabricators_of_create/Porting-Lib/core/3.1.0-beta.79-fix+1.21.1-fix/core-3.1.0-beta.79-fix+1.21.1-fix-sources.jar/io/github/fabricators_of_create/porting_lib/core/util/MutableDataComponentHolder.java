package io.github.fabricators_of_create.porting_lib.core.util;

import java.util.function.BiFunction;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import net.minecraft.class_9322;
import net.minecraft.class_9323;
import net.minecraft.class_9326;
import net.minecraft.class_9331;
import org.jetbrains.annotations.Nullable;

public interface MutableDataComponentHolder extends class_9322 {
	/**
	 * Sets a data component.
	 */
	@Nullable
	<T> T set(class_9331<? super T> componentType, @Nullable T value);

	/**
	 * Sets a data component.
	 */
	@Nullable
	default <T> T set(Supplier<? extends class_9331<? super T>> componentType, @Nullable T value) {
		return set(componentType.get(), value);
	}

	/**
	 * Updates a data component if it exists, using an additional {@code updateContext}.
	 */
	@Nullable
	default <T, U> T update(class_9331<T> componentType, T value, U updateContext, BiFunction<T, U, T> updater) {
		return set(componentType, updater.apply(method_57825(componentType, value), updateContext));
	}

	/**
	 * Updates a data component if it exists, using an additional {@code updateContext}.
	 */
	@Nullable
	default <T, U> T update(Supplier<? extends class_9331<T>> componentType, T value, U updateContext, BiFunction<T, U, T> updater) {
		return update(componentType.get(), value, updateContext, updater);
	}

	/**
	 * Updates a data component if it exists.
	 */
	@Nullable
	default <T> T update(class_9331<T> componentType, T value, UnaryOperator<T> updater) {
		return set(componentType, updater.apply(method_57825(componentType, value)));
	}

	/**
	 * Updates a data component if it exists.
	 */
	@Nullable
	default <T> T update(Supplier<? extends class_9331<T>> componentType, T value, UnaryOperator<T> updater) {
		return update(componentType.get(), value, updater);
	}

	/**
	 * Removes a data component.
	 */
	@Nullable
	<T> T remove(class_9331<? extends T> componentType);

	/**
	 * Removes a data component.
	 */
	@Nullable
	default <T> T remove(Supplier<? extends class_9331<? extends T>> componentType) {
		return remove(componentType.get());
	}

	/**
	 * Copies all data components from {@code src}
	 *
	 * @implNote This will clear any components if the requested {@code src} holder does not contain a matching value.
	 */
	default void copyFrom(class_9322 src, class_9331<?>... componentTypes) {
		for (var componentType : componentTypes) {
			copyFrom(componentType, src);
		}
	}

	/**
	 * Copies all data components from {@code src}
	 *
	 * @implNote This will clear any components if the requested {@code src} holder does not contain a matching value.
	 */
	default void copyFrom(class_9322 src, Supplier<? extends class_9331<?>>... componentTypes) {
		for (var componentType : componentTypes) {
			copyFrom(componentType.get(), src);
		}
	}

	/**
	 * Applies a set of component changes to this stack.
	 */
	void applyComponents(class_9326 patch);

	/**
	 * Applies a set of component changes to this stack.
	 */
	void applyComponents(class_9323 components);

	private <T> void copyFrom(class_9331<T> componentType, class_9322 src) {
		set(componentType, src.method_57824(componentType));
	}
}
