package io.github.fabricators_of_create.porting_lib.core;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Core constants and utils.
 */
public class PortingLib {
	public static final String ID = "porting_lib";
	public static final String NEO_ID = "neoforge";
	public static final String NAME = "Porting Lib";
	public static final Logger LOGGER = LoggerFactory.getLogger(NAME);
	public static final boolean DEBUG = FabricLoader.getInstance().isDevelopmentEnvironment()
			|| Boolean.getBoolean("portingLib.debug");

	public static class_2960 id(String path) {
		return class_2960.method_60655(ID, path);
	}

	public static <T> class_5321<class_2378<T>> key(String path) {
		return class_5321.method_29180(id(path));
	}

	public static class_2960 neo(String path) {
		return class_2960.method_60655(NEO_ID, path);
	}

	public static RuntimeException createMixinException(String extension) {
		return new UnsupportedOperationException("Implementation does not support extension: " + extension);
	}
}
