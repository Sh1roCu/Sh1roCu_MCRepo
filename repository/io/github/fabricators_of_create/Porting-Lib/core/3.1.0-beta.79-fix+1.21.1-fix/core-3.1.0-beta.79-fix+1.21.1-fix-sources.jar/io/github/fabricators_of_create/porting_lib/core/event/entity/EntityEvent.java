package io.github.fabricators_of_create.porting_lib.core.event.entity;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import net.minecraft.class_1297;

/**
 * EntityEvent is fired when an event involving any Entity occurs.<br>
 * If a method utilizes this {@link BaseEvent} as its parameter, the method will
 * receive every child event of this class.<br>
 * <br>
 * {@link #entity} contains the entity that caused this event to occur.<br>
 * <br>
 **/
public abstract class EntityEvent extends BaseEvent {
	private final class_1297 entity;

	public EntityEvent(class_1297 entity) {
		this.entity = entity;
	}

	public class_1297 getEntity() {
		return entity;
	}
}
