package io.github.fabricators_of_create.porting_lib.core.event.entity.player;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.living.LivingEvent;
import net.minecraft.class_1657;

/**
 * PlayerEvent is fired whenever an event involving a {@link class_1657} occurs. <br>
 * If a method utilizes this {@link BaseEvent} as its parameter, the method will
 * receive every child event of this class.<br>
 * <br>
 **/
public abstract class PlayerEvent extends LivingEvent {
	private final class_1657 player;

	public PlayerEvent(class_1657 player) {
		super(player);
		this.player = player;
	}

	@Override
	public class_1657 getEntity() {
		return player;
	}
}
