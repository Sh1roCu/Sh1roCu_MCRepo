package io.github.fabricators_of_create.porting_lib.brewing;

import io.github.fabricators_of_create.porting_lib.brewing.ext.PotionBrewingBuilderExt;
import net.minecraft.class_1799;

/**
 * Interface for more flexible brewing recipes.
 *
 * <p>Register using {@link RegisterBrewingRecipesEvent} and {@link PotionBrewingBuilderExt#addRecipe(IBrewingRecipe)}.
 */
public interface IBrewingRecipe {
	/**
	 * Returns true is the passed ItemStack is an input for this recipe. "Input"
	 * being the item that goes in one of the three bottom slots of the brewing
	 * stand (e.g: water bottle)
	 */
	boolean isInput(class_1799 input);

	/**
	 * Returns true if the passed ItemStack is an ingredient for this recipe.
	 * "Ingredient" being the item that goes in the top slot of the brewing
	 * stand (e.g: nether wart)
	 */
	boolean isIngredient(class_1799 ingredient);

	/**
	 * Returns the output when the passed input is brewed with the passed
	 * ingredient. Empty if invalid input or ingredient.
	 */
	class_1799 getOutput(class_1799 input, class_1799 ingredient);
}
