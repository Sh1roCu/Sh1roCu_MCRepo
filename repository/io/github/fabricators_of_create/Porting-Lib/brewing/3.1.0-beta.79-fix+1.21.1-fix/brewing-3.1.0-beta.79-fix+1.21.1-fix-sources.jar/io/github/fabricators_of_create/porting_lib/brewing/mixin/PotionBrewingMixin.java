package io.github.fabricators_of_create.porting_lib.brewing.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.brewing.BrewingRecipe;
import io.github.fabricators_of_create.porting_lib.brewing.BrewingRecipeRegistry;
import io.github.fabricators_of_create.porting_lib.brewing.IBrewingRecipe;
import io.github.fabricators_of_create.porting_lib.brewing.RegisterBrewingRecipesEvent;
import io.github.fabricators_of_create.porting_lib.brewing.ext.PotionBrewingBuilderExt;
import io.github.fabricators_of_create.porting_lib.brewing.ext.PotionBrewingExt;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1845;
import net.minecraft.class_1856;
import net.minecraft.class_7699;

@Mixin(class_1845.class)
public abstract class PotionBrewingMixin implements PotionBrewingExt {
	@Shadow
	protected abstract boolean isContainer(class_1799 itemStack);

	private BrewingRecipeRegistry porting_lib$registry;

	@Inject(method = "<init>", at = @At("TAIL"))
	private void createEmptyRegistry(final CallbackInfo ci) {
		this.porting_lib$registry = new BrewingRecipeRegistry(List.of()); // Create an empty builder in case a mod doesn't use the builder
	}

	@Override
	public boolean isInput(class_1799 stack) {
		return this.porting_lib$registry.isValidInput(stack) || isContainer(stack);
	}

	@Override
	public List<IBrewingRecipe> getRecipes() {
		return porting_lib$registry.recipes();
	}

	@Override
	public void setBrewingRegistry(BrewingRecipeRegistry registry) {
		this.porting_lib$registry = registry;
	}

	@Inject(method = "hasMix", at = @At("HEAD"), cancellable = true)
	private void checkMixRegistry(class_1799 container, class_1799 mix, CallbackInfoReturnable<Boolean> cir) {
		if (porting_lib$registry.hasOutput(container, mix)) cir.setReturnValue(true);
	}

	@Inject(method = "mix", at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/item/ItemStack;getOrDefault(Lnet/minecraft/core/component/DataComponentType;Ljava/lang/Object;)Ljava/lang/Object;"
	), cancellable = true)
	private void doMix(class_1799 itemStack, class_1799 itemStack2, CallbackInfoReturnable<class_1799> cir) {
		var customMix = porting_lib$registry.getOutput(itemStack2, itemStack); // Parameters are swapped compared to what vanilla passes!
		if (!customMix.method_7960()) cir.setReturnValue(customMix);
	}

	@Inject(method = "bootstrap", at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/item/alchemy/PotionBrewing;addVanillaMixes(Lnet/minecraft/world/item/alchemy/PotionBrewing$Builder;)V",
			shift = At.Shift.AFTER
	))
	private static void fireRegisterEvent(class_7699 featureFlagSet, CallbackInfoReturnable<class_1845> cir, @Local class_1845.class_9665 builder) {
		new RegisterBrewingRecipesEvent(builder).sendEvent();
	}

	@Inject(method = "isIngredient", at = @At("HEAD"), cancellable = true)
	private void checkRegistryForValidIngredient(class_1799 itemStack, CallbackInfoReturnable<Boolean> cir) {
		if (this.porting_lib$registry.isValidIngredient(itemStack))
			cir.setReturnValue(true);
	}

	@Mixin(value = class_1845.class_9665.class, priority = 300)
	public static class BuilderMixin implements PotionBrewingBuilderExt {
		private final List<IBrewingRecipe> porting_lib$recipes = new ArrayList<>();

		@Override
		public void addRecipe(class_1856 input, class_1856 ingredient, class_1799 output) {
			addRecipe(new BrewingRecipe(input, ingredient, output));
		}

		@Override
		public void addRecipe(IBrewingRecipe recipe) {
			this.porting_lib$recipes.add(recipe);
		}

		@ModifyReturnValue(method = "build", at = @At("RETURN"))
		private class_1845 addCustomRecipes(class_1845 original) {
			original.setBrewingRegistry(new BrewingRecipeRegistry(porting_lib$recipes));
			return original;
		}
	}
}
