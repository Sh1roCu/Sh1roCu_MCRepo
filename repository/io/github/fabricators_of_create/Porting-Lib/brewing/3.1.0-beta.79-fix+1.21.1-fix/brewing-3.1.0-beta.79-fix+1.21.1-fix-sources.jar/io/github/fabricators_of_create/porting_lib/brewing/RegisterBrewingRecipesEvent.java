package io.github.fabricators_of_create.porting_lib.brewing;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1845;
import org.jetbrains.annotations.ApiStatus;

public class RegisterBrewingRecipesEvent extends BaseEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (Callback callback : callbacks)
			callback.onRegisterBrewingRecipes(event);
	});

	private final class_1845.class_9665 builder;

	@ApiStatus.Internal
	public RegisterBrewingRecipesEvent(class_1845.class_9665 builder) {
		this.builder = builder;
	}

	public class_1845.class_9665 getBuilder() {
		return builder;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onRegisterBrewingRecipes(this);
	}

	public interface Callback {
		void onRegisterBrewingRecipes(RegisterBrewingRecipesEvent event);
	}
}
