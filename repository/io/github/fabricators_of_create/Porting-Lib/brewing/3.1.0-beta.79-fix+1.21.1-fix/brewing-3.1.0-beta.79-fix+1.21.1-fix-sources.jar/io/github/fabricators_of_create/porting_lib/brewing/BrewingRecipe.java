package io.github.fabricators_of_create.porting_lib.brewing;

import net.minecraft.class_1799;
import net.minecraft.class_1856;

public class BrewingRecipe implements IBrewingRecipe {
	private final class_1856 input;
	private final class_1856 ingredient;
	private final class_1799 output;

	public BrewingRecipe(class_1856 input, class_1856 ingredient, class_1799 output) {
		this.input = input;
		this.ingredient = ingredient;
		this.output = output;
	}

	@Override
	public boolean isInput(class_1799 stack) {
		return this.input.method_8093(stack);
	}

	@Override
	public class_1799 getOutput(class_1799 input, class_1799 ingredient) {
		return isInput(input) && isIngredient(ingredient) ? getOutput().method_7972() : class_1799.field_8037;
	}

	public class_1856 getInput() {
		return input;
	}

	public class_1856 getIngredient() {
		return ingredient;
	}

	public class_1799 getOutput() {
		return output;
	}

	@Override
	public boolean isIngredient(class_1799 ingredient) {
		return this.ingredient.method_8093(ingredient);
	}
}
