package io.github.fabricators_of_create.porting_lib.brewing;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1845;
import org.jetbrains.annotations.ApiStatus;

/**
 * Starting from 1.20.5 this is used to hold {@link IBrewingRecipe}s inside of {@link class_1845}.
 * For queries, use the vanilla {@link class_1845}.
 * For registration, use {@link RegisterBrewingRecipesEvent}.
 */
@ApiStatus.Internal
public record BrewingRecipeRegistry(List<IBrewingRecipe> recipes) {
	/**
	 * Returns the output ItemStack obtained by brewing the passed input and
	 * ingredient.
	 */
	public class_1799 getOutput(class_1799 input, class_1799 ingredient) {
		if (input.method_7960() || input.method_7947() != 1) return class_1799.field_8037;
		if (ingredient.method_7960()) return class_1799.field_8037;

		for (IBrewingRecipe recipe : recipes) {
			class_1799 output = recipe.getOutput(input, ingredient);
			if (!output.method_7960()) {
				return output;
			}
		}
		return class_1799.field_8037;
	}

	/**
	 * Returns true if the passed input and ingredient have an output
	 */
	public boolean hasOutput(class_1799 input, class_1799 ingredient) {
		return !getOutput(input, ingredient).method_7960();
	}

	/**
	 * Returns true if the passed ItemStack is a valid ingredient for any of the
	 * recipes in the registry.
	 */
	public boolean isValidIngredient(class_1799 stack) {
		if (stack.method_7960()) return false;

		for (IBrewingRecipe recipe : recipes) {
			if (recipe.isIngredient(stack)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Returns true if the passed ItemStack is a valid input for any of the
	 * recipes in the registry.
	 */
	public boolean isValidInput(class_1799 stack) {
		for (IBrewingRecipe recipe : recipes) {
			if (recipe.isInput(stack)) {
				return true;
			}
		}
		return false;
	}
}
