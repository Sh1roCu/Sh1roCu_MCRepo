package io.github.fabricators_of_create.porting_lib.chunk.loading.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;

import com.llamalad7.mixinextras.sugar.ref.LocalRef;

import io.github.fabricators_of_create.porting_lib.chunk.loading.extensions.ServerChunkCacheExtension;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Iterator;
import java.util.List;
import net.minecraft.class_1923;
import net.minecraft.class_2818;
import net.minecraft.class_3204;
import net.minecraft.class_3215;
import net.minecraft.class_3230;

@Mixin(class_3215.class)
public class ServerChunkCacheMixin implements ServerChunkCacheExtension {
	@Shadow
	@Final
	private class_3204 distanceManager;

	@Override
	public <T> void addRegionTicket(class_3230<T> pType, class_1923 pPos, int pDistance, T pValue, boolean forceTicks) {
		this.distanceManager.method_17291(pType, pPos, pDistance, pValue, forceTicks);
	}

	@Override
	public <T> void removeRegionTicket(class_3230<T> pType, class_1923 pPos, int pDistance, T pValue, boolean forceTicks) {
		this.distanceManager.method_17292(pType, pPos, pDistance, pValue, forceTicks);
	}

	@Inject(method = "tickChunks", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/chunk/LevelChunk;getPos()Lnet/minecraft/world/level/ChunkPos;"))
	private void checkForcedTicks(CallbackInfo ci, @Local(index = 14) class_2818 levelChunk, @Share("force_ticks") LocalRef<Boolean> forceTicks) {
		forceTicks.set(this.distanceManager.shouldForceTicks(levelChunk.method_12004().method_8324()));
	}

	@ModifyExpressionValue(method = "tickChunks", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ChunkMap;anyPlayerCloseEnoughForSpawning(Lnet/minecraft/world/level/ChunkPos;)Z"))
	private boolean shouldForce(boolean original, @Share("force_ticks") LocalRef<Boolean> forceTicks) {
		if (forceTicks.get())
			return true;
		return original;
	}

	@ModifyExpressionValue(method = "tickChunks", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;isNaturalSpawningAllowed(Lnet/minecraft/world/level/ChunkPos;)Z"))
	private boolean shouldForce2(boolean original, @Share("force_ticks") LocalRef<Boolean> forceTicks) {
		if (forceTicks.get())
			return true;
		return original;
	}
}
