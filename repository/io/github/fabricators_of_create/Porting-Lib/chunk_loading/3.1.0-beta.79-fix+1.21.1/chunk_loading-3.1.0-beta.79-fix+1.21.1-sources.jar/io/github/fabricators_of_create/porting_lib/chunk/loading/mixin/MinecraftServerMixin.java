package io.github.fabricators_of_create.porting_lib.chunk.loading.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.chunk.loading.ForcedChunkManager;
import net.minecraft.class_1932;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

@Mixin(MinecraftServer.class)
public class MinecraftServerMixin {
	@ModifyExpressionValue(method = "prepareLevels", at = @At(value = "INVOKE", target = "Lit/unimi/dsi/fastutil/longs/LongIterator;hasNext()Z"))
	private boolean reinstatePersistentChunks(boolean original, @Local(index = 8) class_3218 serverLevel2, @Local(index = 9) class_1932 forcedChunksSavedData) {
		if (!original) // a bit of a hack honestly but avoids us having to make a custom Injection Point
			ForcedChunkManager.reinstatePersistentChunks(serverLevel2, forcedChunksSavedData);
		return original;
	}
}
