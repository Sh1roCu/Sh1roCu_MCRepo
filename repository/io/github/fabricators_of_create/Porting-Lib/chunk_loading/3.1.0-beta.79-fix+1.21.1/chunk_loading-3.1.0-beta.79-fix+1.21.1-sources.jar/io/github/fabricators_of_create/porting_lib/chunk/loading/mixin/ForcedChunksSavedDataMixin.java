package io.github.fabricators_of_create.porting_lib.chunk.loading.mixin;

import io.github.fabricators_of_create.porting_lib.chunk.loading.ForcedChunkManager;
import io.github.fabricators_of_create.porting_lib.chunk.loading.extensions.ForcedChunksSavedDataExtension;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;
import net.minecraft.class_1932;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_7225;

@Mixin(class_1932.class)
public class ForcedChunksSavedDataMixin implements ForcedChunksSavedDataExtension {
	// Neo: Keep track of forced loaded chunks caused by entities or blocks.
	private final ForcedChunkManager.TicketTracker<class_2338> port_lib$blockForcedChunks = new ForcedChunkManager.TicketTracker<>();
	private final ForcedChunkManager.TicketTracker<UUID> port_lib$entityForcedChunks = new ForcedChunkManager.TicketTracker<>();

	@Inject(method = "load", at = @At("RETURN"))
	private static void readForgeForcedChunks(class_2487 tag, class_7225.class_7874 provider, CallbackInfoReturnable<class_1932> cir) {
		class_1932 data = cir.getReturnValue();
		ForcedChunkManager.readModForcedChunks(tag, data.getBlockForcedChunks(), data.getEntityForcedChunks());
	}

	@Inject(method = "save", at = @At("TAIL"))
	private void saveForgeForcedChunks(class_2487 tag, class_7225.class_7874 provider, CallbackInfoReturnable<class_2487> cir) {
		ForcedChunkManager.writeModForcedChunks(tag, getBlockForcedChunks(), getEntityForcedChunks());
	}

	@Override
	public ForcedChunkManager.TicketTracker<class_2338> getBlockForcedChunks() {
		return this.port_lib$blockForcedChunks;
	}

	@Override
	public ForcedChunkManager.TicketTracker<UUID> getEntityForcedChunks() {
		return this.port_lib$entityForcedChunks;
	}
}
