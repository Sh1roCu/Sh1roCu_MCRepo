package io.github.fabricators_of_create.porting_lib.chunk.loading.extensions;

import net.minecraft.class_1923;
import net.minecraft.class_3230;

public interface DistanceManagerExtension {
	default <T> void addRegionTicket(class_3230<T> pType, class_1923 pPos, int pDistance, T pValue, boolean forceTicks) {
		throw new RuntimeException();
	}

	default <T> void removeRegionTicket(class_3230<T> pType, class_1923 pPos, int pDistance, T pValue, boolean forceTicks) {
		throw new RuntimeException();
	}

	default boolean shouldForceTicks(long chunkPos) {
		throw new RuntimeException();
	}
}
