package io.github.fabricators_of_create.porting_lib.chunk.loading;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Function;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.class_18;
import net.minecraft.class_1923;
import net.minecraft.class_1932;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3230;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.ApiStatus;

@ParametersAreNonnullByDefault
public class ForcedChunkManager {
	private static final Logger LOGGER = LogManager.getLogger();
	static final class_3230<TicketOwner<class_2338>> BLOCK = class_3230.method_14291("neoforge:block", Comparator.comparing(info -> info));
	static final class_3230<TicketOwner<class_2338>> BLOCK_TICKING = class_3230.method_14291("neoforge:block_ticking", Comparator.comparing(info -> info));
	static final class_3230<TicketOwner<UUID>> ENTITY = class_3230.method_14291("neoforge:entity", Comparator.comparing(info -> info));
	static final class_3230<TicketOwner<UUID>> ENTITY_TICKING = class_3230.method_14291("neoforge:entity_ticking", Comparator.comparing(info -> info));

	private static final Map<class_2960, TicketController> controllers = new HashMap<>();

	public static void registerController(TicketController controller) {
		if (controllers.containsKey(controller.id())) {
			throw new IllegalArgumentException("Attempted to register two controllers with the same ID " + controller.id());
		}
		controllers.put(controller.id(), controller);
	}

	/**
	 * Checks if a level has any forced chunks. Mainly used for seeing if a level should continue ticking with no players in it.
	 */
	public static boolean hasForcedChunks(class_3218 level) {
		class_1932 data = level.method_17983().method_20786(new class_18.class_8645<>(class_1932::new, class_1932::method_32350, null), "chunks");
		if (data == null) return false;
		return !data.method_8375().isEmpty() || !data.getBlockForcedChunks().isEmpty() || !data.getEntityForcedChunks().isEmpty();
	}

	/**
	 * Forces a chunk to be loaded for the given mod with the given "owner".
	 *
	 * @param add {@code true} to force the chunk, {@code false} to unforce the chunk.
	 *
	 * @implNote Based on {@link class_3218#method_17988(int, int, boolean)}
	 */
	static <T extends Comparable<? super T>> boolean forceChunk(class_3218 level, class_2960 id, T owner, int chunkX, int chunkZ, boolean add, boolean ticking,
																class_3230<TicketOwner<T>> type, Function<class_1932, TicketTracker<T>> ticketGetter) {
		if (!controllers.containsKey(id)) {
			throw new IllegalArgumentException("Controller with ID " + id + " is not registered!");
		}

		class_1932 saveData = level.method_17983().method_17924(class_1932.method_52570(), "chunks");
		class_1923 pos = new class_1923(chunkX, chunkZ);
		long chunk = pos.method_8324();
		TicketTracker<T> tickets = ticketGetter.apply(saveData);
		TicketOwner<T> ticketOwner = new TicketOwner<>(id, owner);
		boolean success;
		if (add) {
			success = tickets.add(ticketOwner, chunk, ticking);
			if (success)
				level.method_8497(chunkX, chunkZ);
		} else {
			success = tickets.remove(ticketOwner, chunk, ticking);
		}
		if (success) {
			saveData.method_78(true);
			forceChunk(level, pos, type, ticketOwner, add, ticking);
		}
		return success;
	}

	/**
	 * Adds/Removes a ticket from the level's chunk provider with the proper levels to match the forced chunks.
	 *
	 * @param add     {@code true} to force the chunk, {@code false} to unforce the chunk.
	 * @param ticking {@code true} to make the chunk receive full chunk ticks even if there is no player nearby.
	 *
	 * @implNote We use distance 2 for what we pass, as when using register/releaseTicket the ticket's level is set to 33 - distance and the level that forced chunks use
	 *           is 31.
	 */
	private static <T extends Comparable<? super T>> void forceChunk(class_3218 level, class_1923 pos, class_3230<TicketOwner<T>> type, TicketOwner<T> owner, boolean add,
																	 boolean ticking) {
		if (add)
			level.method_14178().method_17297(type, pos, 2, owner, ticking);
		else
			level.method_14178().method_17300(type, pos, 2, owner, ticking);
	}

	/**
	 * Reinstates NeoForge's forced chunks when vanilla initially loads a level and reinstates their forced chunks. This method also will validate all the forced
	 * chunks with the registered {@link LoadingValidationCallback}s.
	 */
	@ApiStatus.Internal
	public static void reinstatePersistentChunks(class_3218 level, class_1932 saveData) {
		final var controllers = ForcedChunkManager.controllers.entrySet().stream()
				.filter(c -> c.getValue().callback() != null)
				.toList();

		if (!controllers.isEmpty()) {
			//If we have any callbacks, gather all owned tickets by controller for both blocks and entities
			final Map<class_2960, Map<class_2338, TicketSet>> blockTickets = gatherTicketsById(saveData.getBlockForcedChunks());
			final Map<class_2960, Map<UUID, TicketSet>> entityTickets = gatherTicketsById(saveData.getEntityForcedChunks());
			//Fire the callbacks allowing them to remove any tickets they don't want anymore
			controllers.forEach((value) -> {
				boolean hasBlockTicket = blockTickets.containsKey(value.getKey());
				boolean hasEntityTicket = entityTickets.containsKey(value.getKey());
				if (hasBlockTicket || hasEntityTicket) {
					Map<class_2338, TicketSet> ownedBlockTickets = hasBlockTicket ? Collections.unmodifiableMap(blockTickets.get(value.getKey())) : Collections.emptyMap();
					Map<UUID, TicketSet> ownedEntityTickets = hasEntityTicket ? Collections.unmodifiableMap(entityTickets.get(value.getKey())) : Collections.emptyMap();
					value.getValue().callback().validateTickets(level, new TicketHelper(saveData, value.getKey(), ownedBlockTickets, ownedEntityTickets));
				}
			});
		}
		//Reinstate the chunks that we want to load
		reinstatePersistentChunks(level, BLOCK, saveData.getBlockForcedChunks().chunks, false);
		reinstatePersistentChunks(level, BLOCK_TICKING, saveData.getBlockForcedChunks().tickingChunks, true);
		reinstatePersistentChunks(level, ENTITY, saveData.getEntityForcedChunks().chunks, false);
		reinstatePersistentChunks(level, ENTITY_TICKING, saveData.getEntityForcedChunks().tickingChunks, true);
	}

	/**
	 * Gathers tickets into an ID filtered map for use in providing all tickets a controller has registered to its {@link LoadingValidationCallback}.
	 */
	private static <T extends Comparable<? super T>> Map<class_2960, Map<T, TicketSet>> gatherTicketsById(TicketTracker<T> tickets) {
		Map<class_2960, Map<T, TicketSet>> modSortedOwnedChunks = new HashMap<>();
		gatherTicketsById(tickets.chunks, TicketSet::nonTicking, modSortedOwnedChunks);
		gatherTicketsById(tickets.tickingChunks, TicketSet::ticking, modSortedOwnedChunks);
		return modSortedOwnedChunks;
	}

	/**
	 * Gathers tickets into an ID filtered map for use in providing all tickets a controller has registered to its {@link LoadingValidationCallback}.
	 */
	private static <T extends Comparable<? super T>> void gatherTicketsById(Map<TicketOwner<T>, LongSet> tickets, Function<TicketSet, LongSet> typeGetter,
																			Map<class_2960, Map<T, TicketSet>> modSortedOwnedChunks) {
		tickets.forEach((owner, values) -> {
			TicketSet pair = modSortedOwnedChunks.computeIfAbsent(owner.id, modId -> new HashMap<>()).computeIfAbsent(owner.owner, o -> new TicketSet(new LongOpenHashSet(), new LongOpenHashSet()));
			typeGetter.apply(pair).addAll(values);
		});
	}

	/**
	 * Adds back any persistent forced chunks to the level's chunk provider.
	 */
	private static <T extends Comparable<? super T>> void reinstatePersistentChunks(class_3218 level, class_3230<TicketOwner<T>> type,
																					Map<TicketOwner<T>, LongSet> tickets, boolean ticking) {
		tickets.forEach((owner, values) -> {
			for (long chunk : values) {
				forceChunk(level, new class_1923(chunk), type, owner, true, ticking);
			}
		});
	}

	/**
	 * Writes the mod forced chunks into the NBT compound. Format is List{controllerId, List{ChunkPos, List{BlockPos}, List{UUID}}}
	 */
	@ApiStatus.Internal
	public static void writeModForcedChunks(class_2487 nbt, TicketTracker<class_2338> blockForcedChunks, TicketTracker<UUID> entityForcedChunks) {
		if (!blockForcedChunks.isEmpty() || !entityForcedChunks.isEmpty()) {
			Map<class_2960, Long2ObjectMap<class_2487>> forcedEntries = new HashMap<>();
			writeForcedChunkOwners(forcedEntries, blockForcedChunks, "Blocks", class_2520.field_33260, (pos, forcedBlocks) -> forcedBlocks.add(writeBlockPos(pos)));
			writeForcedChunkOwners(forcedEntries, entityForcedChunks, "Entities", class_2520.field_33261, (uuid, forcedEntities) -> forcedEntities.add(class_2512.method_25929(uuid)));
			class_2499 forcedChunks = new class_2499();
			for (Map.Entry<class_2960, Long2ObjectMap<class_2487>> entry : forcedEntries.entrySet()) {
				class_2487 forcedEntry = new class_2487();
				forcedEntry.method_10582("Controller", entry.getKey().toString());
				class_2499 modForced = new class_2499();
				modForced.addAll(entry.getValue().values());
				forcedEntry.method_10566("ModForced", modForced);
				forcedChunks.add(forcedEntry);
			}
			nbt.method_10566("ModForced", forcedChunks);
		}
	}

	private static <T extends Comparable<? super T>> void writeForcedChunkOwners(Map<class_2960, Long2ObjectMap<class_2487>> forcedEntries, TicketTracker<T> tracker,
																				 String listKey, int listType, BiConsumer<T, class_2499> ownerWriter) {
		writeForcedChunkOwners(forcedEntries, tracker.chunks, listKey, listType, ownerWriter);
		writeForcedChunkOwners(forcedEntries, tracker.tickingChunks, "Ticking" + listKey, listType, ownerWriter);
	}

	private static <T extends Comparable<? super T>> void writeForcedChunkOwners(Map<class_2960, Long2ObjectMap<class_2487>> forcedEntries,
																				 Map<TicketOwner<T>, LongSet> forcedChunks, String listKey, int listType, BiConsumer<T, class_2499> ownerWriter) {
		for (Map.Entry<TicketOwner<T>, LongSet> entry : forcedChunks.entrySet()) {
			Long2ObjectMap<class_2487> modForced = forcedEntries.computeIfAbsent(entry.getKey().id, modId -> new Long2ObjectOpenHashMap<>());
			for (long chunk : entry.getValue()) {
				class_2487 modEntry = modForced.computeIfAbsent(chunk, chunkPos -> {
					class_2487 baseEntry = new class_2487();
					baseEntry.method_10544("Chunk", chunkPos);
					return baseEntry;
				});
				class_2499 ownerList = modEntry.method_10554(listKey, listType);
				ownerWriter.accept(entry.getKey().owner, ownerList);
				//Note: As getList returns a new list in the case the data is of the wrong type,
				// we need to mimic was vanilla does in various places and put our list back in
				// the CompoundNBT regardless.
				modEntry.method_10566(listKey, ownerList);
			}
		}
	}

	/**
	 * Reads the mod forced chunks from the NBT compound. Format is List{controllerId, List{ChunkPos, List{BlockPos}, List{UUID}}}
	 */
	@ApiStatus.Internal
	public static void readModForcedChunks(class_2487 nbt, TicketTracker<class_2338> blockForcedChunks, TicketTracker<UUID> entityForcedChunks) {
		class_2499 forcedChunks = nbt.method_10554("ModForced", class_2520.field_33260);
		for (int i = 0; i < forcedChunks.size(); i++) {
			class_2487 forcedEntry = forcedChunks.method_10602(i);
			class_2960 controllerId;
			if (forcedEntry.method_10573("Controller", class_2520.field_33258)) {
				controllerId = class_2960.method_60654(forcedEntry.method_10558("Controller"));
			} else {
				controllerId = class_2960.method_60655(forcedEntry.method_10558("Mod"), "default");
			}
			if (controllers.containsKey(controllerId)) {
				class_2499 modForced = forcedEntry.method_10554("ModForced", class_2520.field_33260);
				for (int j = 0; j < modForced.size(); j++) {
					class_2487 modEntry = modForced.method_10602(j);
					long chunkPos = modEntry.method_10537("Chunk");
					readBlockForcedChunks(controllerId, chunkPos, modEntry, "Blocks", blockForcedChunks.chunks);
					readBlockForcedChunks(controllerId, chunkPos, modEntry, "TickingBlocks", blockForcedChunks.tickingChunks);
					readEntityForcedChunks(controllerId, chunkPos, modEntry, "Entities", entityForcedChunks.chunks);
					readEntityForcedChunks(controllerId, chunkPos, modEntry, "TickingEntities", entityForcedChunks.tickingChunks);
				}
			} else {
				LOGGER.warn("Found chunk loading data for controller id {} which is currently not available or active - it will be removed from the level save.", controllerId);
			}
		}
	}

	/**
	 * Reads the forge block forced chunks.
	 */
	private static void readBlockForcedChunks(class_2960 controllerId, long chunkPos, class_2487 modEntry, String key, Map<TicketOwner<class_2338>, LongSet> blockForcedChunks) {
		class_2499 forcedBlocks = modEntry.method_10554(key, class_2520.field_33260);
		for (int k = 0; k < forcedBlocks.size(); k++) {
			blockForcedChunks.computeIfAbsent(new TicketOwner<>(controllerId, readBlockPos(forcedBlocks.method_10602(k))), owner -> new LongOpenHashSet()).add(chunkPos);
		}
	}

	private static class_2338 readBlockPos(class_2487 compoundtag) {
		return new class_2338(compoundtag.method_10550("X"), compoundtag.method_10550("Y"), compoundtag.method_10550("Z"));
	}

	public static class_2487 writeBlockPos(class_2338 blockpos) {
		class_2487 compoundtag = new class_2487();
		compoundtag.method_10569("X", blockpos.method_10263());
		compoundtag.method_10569("Y", blockpos.method_10264());
		compoundtag.method_10569("Z", blockpos.method_10260());
		return compoundtag;
	}

	/**
	 * Reads the forge entity forced chunks.
	 */
	private static void readEntityForcedChunks(class_2960 controllerId, long chunkPos, class_2487 modEntry, String key, Map<TicketOwner<UUID>, LongSet> entityForcedChunks) {
		class_2499 forcedEntities = modEntry.method_10554(key, class_2520.field_33261);
		for (class_2520 uuid : forcedEntities) {
			entityForcedChunks.computeIfAbsent(new TicketOwner<>(controllerId, class_2512.method_25930(uuid)), owner -> new LongOpenHashSet()).add(chunkPos);
		}
	}

	/**
	 * Helper class to keep track of a ticket owner by controller ID and owner object
	 */
	static class TicketOwner<T extends Comparable<? super T>> implements Comparable<TicketOwner<T>> {
		private final class_2960 id;
		private final T owner;

		TicketOwner(class_2960 id, T owner) {
			this.id = id;
			this.owner = owner;
		}

		@Override
		public int compareTo(TicketOwner<T> other) {
			int res = id.method_12833(other.id);
			return res == 0 ? owner.compareTo(other.owner) : res;
		}

		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (o == null || getClass() != o.getClass()) return false;
			TicketOwner<?> that = (TicketOwner<?>) o;
			return Objects.equals(id, that.id) && Objects.equals(owner, that.owner);
		}

		@Override
		public int hashCode() {
			return Objects.hash(id, owner);
		}
	}

	/**
	 * Helper class to manage tracking and handling loaded tickets.
	 */
	public static class TicketTracker<T extends Comparable<? super T>> {
		final Map<TicketOwner<T>, LongSet> chunks = new HashMap<>();
		final Map<TicketOwner<T>, LongSet> tickingChunks = new HashMap<>();

		/**
		 * Gets an unmodifiable view of the tracked chunks.
		 */
		public Map<TicketOwner<T>, LongSet> getChunks() {
			return Collections.unmodifiableMap(chunks);
		}

		/**
		 * Gets an unmodifiable view of the tracked fully ticking chunks.
		 */
		public Map<TicketOwner<T>, LongSet> getTickingChunks() {
			return Collections.unmodifiableMap(tickingChunks);
		}

		/**
		 * Checks if this tracker is empty.
		 *
		 * @return {@code true} if there are no chunks or ticking chunks being tracked.
		 */
		public boolean isEmpty() {
			return chunks.isEmpty() && tickingChunks.isEmpty();
		}

		private Map<TicketOwner<T>, LongSet> getTickets(boolean ticking) {
			return ticking ? tickingChunks : chunks;
		}

		/**
		 * @return {@code true} if the state changed.
		 */
		public boolean remove(TicketOwner<T> owner, long chunk, boolean ticking) {
			Map<TicketOwner<T>, LongSet> tickets = getTickets(ticking);
			if (tickets.containsKey(owner)) {
				LongSet ticketChunks = tickets.get(owner);
				if (ticketChunks.remove(chunk)) {
					if (ticketChunks.isEmpty())
						tickets.remove(owner);
					return true;
				}
			}
			return false;
		}

		/**
		 * @return {@code true} if the state changed.
		 */
		private boolean add(TicketOwner<T> owner, long chunk, boolean ticking) {
			return getTickets(ticking).computeIfAbsent(owner, o -> new LongOpenHashSet()).add(chunk);
		}
	}
}
