package io.github.fabricators_of_create.porting_lib.chunk.loading;

import java.util.Objects;
import java.util.UUID;
import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.class_1297;
import net.minecraft.class_1932;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import org.jetbrains.annotations.Nullable;

/**
 * A class used to manage chunk loading tickets associated with a specific ID.
 * <p>
 * Controllers must be registered via {@link RegisterTicketControllersEvent}. A controller that isn't registered will have all of its tickets discarded when the world is loaded, and any attempts at force-loading a chunk through it will result in an {@link IllegalArgumentException}.
 *
 * @param id       the ID of this controller
 * @param callback a callback to be called when the tickets are loaded, in order to validate whether they're still active or not. {@code null} should be used when a callback needn't be provided
 */
@ParametersAreNonnullByDefault
public record TicketController(class_2960 id, @Nullable LoadingValidationCallback callback) {
	public TicketController {
		Objects.requireNonNull(id, "id must not be null");
	}

	/**
	 * Creates a ticket controller without a validation callback.
	 *
	 * @param id the ID of the controller
	 */
	public TicketController(class_2960 id) {
		this(id, null);
	}

	/**
	 * Forces a chunk to be loaded with the "owner" of the ticket being a given block position.
	 *
	 * @param add     {@code true} to force the chunk, {@code false} to unforce the chunk.
	 * @param ticking {@code true} to make the chunk receive full chunk ticks even if there is no player nearby.
	 */
	public boolean forceChunk(class_3218 level, class_2338 owner, int chunkX, int chunkZ, boolean add, boolean ticking) {
		return ForcedChunkManager.forceChunk(level, id, owner, chunkX, chunkZ, add, ticking, ticking ? ForcedChunkManager.BLOCK_TICKING : ForcedChunkManager.BLOCK, class_1932::getBlockForcedChunks);
	}

	/**
	 * Forces a chunk to be loaded with the "owner" of the ticket being the UUID of the given entity.
	 *
	 * @param add     {@code true} to force the chunk, {@code false} to unforce the chunk.
	 * @param ticking {@code true} to make the chunk receive full chunk ticks even if there is no player nearby.
	 */
	public boolean forceChunk(class_3218 level, class_1297 owner, int chunkX, int chunkZ, boolean add, boolean ticking) {
		return forceChunk(level, owner.method_5667(), chunkX, chunkZ, add, ticking);
	}

	/**
	 * Forces a chunk to be loaded with the "owner" of the ticket being a given UUID.
	 *
	 * @param add     {@code true} to force the chunk, {@code false} to unforce the chunk.
	 * @param ticking {@code true} to make the chunk receive full chunk ticks even if there is no player nearby.
	 */
	public boolean forceChunk(class_3218 level, UUID owner, int chunkX, int chunkZ, boolean add, boolean ticking) {
		return ForcedChunkManager.forceChunk(level, id(), owner, chunkX, chunkZ, add, ticking, ticking ? ForcedChunkManager.ENTITY_TICKING : ForcedChunkManager.ENTITY, class_1932::getEntityForcedChunks);
	}
}
