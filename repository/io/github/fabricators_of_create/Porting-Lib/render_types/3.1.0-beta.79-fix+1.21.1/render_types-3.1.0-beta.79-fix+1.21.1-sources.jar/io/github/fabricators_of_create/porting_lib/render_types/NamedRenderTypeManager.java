package io.github.fabricators_of_create.porting_lib.render_types;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_2960;

/**
 * Manager for named {@link class_1921 render types}.
 * <p>
 * Provides a lookup.
 */
public final class NamedRenderTypeManager {
	private static Map<class_2960, RenderTypeGroup> RENDER_TYPES = new HashMap<>();

	/**
	 * Finds the {@link RenderTypeGroup} for a given name, or the {@link RenderTypeGroup#EMPTY empty group} if not found.
	 */
	public static RenderTypeGroup get(class_2960 name) {
		return RENDER_TYPES.getOrDefault(name, RenderTypeGroup.EMPTY);
	}

	public static void register(class_2960 key, class_1921 blockRenderType, class_1921 entityRenderType) {
		RENDER_TYPES.put(key, new RenderTypeGroup(blockRenderType, entityRenderType));
	}

	/**
	 * Pre-registers vanilla render types.
	 */
	static {
		register(class_2960.method_60656("solid"), class_1921.method_23577(), PortingLibRenderTypes.ITEM_LAYERED_SOLID.get());
		register(class_2960.method_60656("cutout"), class_1921.method_23581(), PortingLibRenderTypes.ITEM_LAYERED_CUTOUT.get());
		// Generally entity/item rendering shouldn't use mipmaps, so cutout_mipped has them off by default. To enforce them, use cutout_mipped_all.
		register(class_2960.method_60656("cutout_mipped"), class_1921.method_23579(), PortingLibRenderTypes.ITEM_LAYERED_CUTOUT.get());
		register(class_2960.method_60656("cutout_mipped_all"), class_1921.method_23579(), PortingLibRenderTypes.ITEM_LAYERED_CUTOUT_MIPPED.get());
		register(class_2960.method_60656("translucent"), class_1921.method_23583(), PortingLibRenderTypes.ITEM_LAYERED_TRANSLUCENT.get());
		register(class_2960.method_60656("tripwire"), class_1921.method_29997(), PortingLibRenderTypes.ITEM_LAYERED_TRANSLUCENT.get());
	}

	private NamedRenderTypeManager() {}
}
