package io.github.fabricators_of_create.porting_lib.render_types;

import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Function;
import java.util.function.Supplier;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.core.util.Lazy;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.class_1059;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_1921.class_4688;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4668;
import net.minecraft.class_4668.class_4678;
import net.minecraft.class_4668.class_4683;
import net.minecraft.class_5944;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("deprecation")
public enum PortingLibRenderTypes {
	ITEM_LAYERED_SOLID(() -> getItemLayeredSolid(class_1059.field_5275)),
	ITEM_LAYERED_CUTOUT(() -> getItemLayeredCutout(class_1059.field_5275)),
	ITEM_LAYERED_CUTOUT_MIPPED(() -> getItemLayeredCutoutMipped(class_1059.field_5275)),
	ITEM_LAYERED_TRANSLUCENT(() -> getItemLayeredTranslucent(class_1059.field_5275)),
	ITEM_UNSORTED_TRANSLUCENT(() -> getUnsortedTranslucent(class_1059.field_5275)),
	ITEM_UNLIT_TRANSLUCENT(() -> getUnlitTranslucent(class_1059.field_5275)),
	ITEM_UNSORTED_UNLIT_TRANSLUCENT(() -> getUnlitTranslucent(class_1059.field_5275, false)),
	TRANSLUCENT_ON_PARTICLES_TARGET(() -> getTranslucentParticlesTarget(class_1059.field_5275));

	public static boolean enableTextTextureLinearFiltering = false;

	@Nullable
	private static class_5944 rendertypeEntityTranslucentUnlitShader;

	public static class_5944 getEntityTranslucentUnlitShader() {
		return Objects.requireNonNull(rendertypeEntityTranslucentUnlitShader, "Attempted to call getEntityTranslucentUnlitShader before shaders have finished loading.");
	}

	public static void init() {
		CoreShaderRegistrationCallback.EVENT.register(context -> {
			context.register(PortingLib.id("rendertype_entity_unlit_translucent"), class_290.field_1580, shader -> {
				rendertypeEntityTranslucentUnlitShader = shader;
			});
		});
	}

	/**
	 * @return A RenderType fit for multi-layer solid item rendering.
	 */
	public static class_1921 getItemLayeredSolid(class_2960 textureLocation) {
		return Internal.LAYERED_ITEM_SOLID.apply(textureLocation);
	}

	/**
	 * @return A RenderType fit for multi-layer cutout item item rendering.
	 */
	public static class_1921 getItemLayeredCutout(class_2960 textureLocation) {
		return Internal.LAYERED_ITEM_CUTOUT.apply(textureLocation);
	}

	/**
	 * @return A RenderType fit for multi-layer cutout-mipped item rendering.
	 */
	public static class_1921 getItemLayeredCutoutMipped(class_2960 textureLocation) {
		return Internal.LAYERED_ITEM_CUTOUT_MIPPED.apply(textureLocation);
	}

	/**
	 * @return A RenderType fit for multi-layer translucent item rendering.
	 */
	public static class_1921 getItemLayeredTranslucent(class_2960 textureLocation) {
		return Internal.LAYERED_ITEM_TRANSLUCENT.apply(textureLocation);
	}

	/**
	 * @return A RenderType fit for translucent item/entity rendering, but with depth sorting disabled.
	 */
	public static class_1921 getUnsortedTranslucent(class_2960 textureLocation) {
		return Internal.UNSORTED_TRANSLUCENT.apply(textureLocation);
	}

	/**
	 * @return A RenderType fit for translucent item/entity rendering, but with diffuse lighting disabled
	 *         so that fullbright quads look correct.
	 */
	public static class_1921 getUnlitTranslucent(class_2960 textureLocation) {
		return Internal.UNLIT_TRANSLUCENT_SORTED.apply(textureLocation);
	}

	/**
	 * @return A RenderType fit for translucent item/entity rendering, but with diffuse lighting disabled
	 *         so that fullbright quads look correct.
	 * @param sortingEnabled If false, depth sorting will not be performed.
	 */
	public static class_1921 getUnlitTranslucent(class_2960 textureLocation, boolean sortingEnabled) {
		return (sortingEnabled ? Internal.UNLIT_TRANSLUCENT_SORTED : Internal.UNLIT_TRANSLUCENT_UNSORTED).apply(textureLocation);
	}

	/**
	 * @return Same as {@link class_1921#method_23576(class_2960)}, but with mipmapping enabled.
	 */
	public static class_1921 getEntityCutoutMipped(class_2960 textureLocation) {
		return Internal.LAYERED_ITEM_CUTOUT_MIPPED.apply(textureLocation);
	}

	/**
	 * @return Replacement of {@link class_1921#method_23028(class_2960)}, but with optional linear texture filtering.
	 */
	public static class_1921 getText(class_2960 locationIn) {
		return Internal.TEXT.apply(locationIn);
	}

	/**
	 * @return Replacement of {@link class_1921#method_36434(class_2960)}, but with optional linear texture filtering.
	 */
	public static class_1921 getTextIntensity(class_2960 locationIn) {
		return Internal.TEXT_INTENSITY.apply(locationIn);
	}

	/**
	 * @return Replacement of {@link class_1921#method_37345(class_2960)}, but with optional linear texture filtering.
	 */
	public static class_1921 getTextPolygonOffset(class_2960 locationIn) {
		return Internal.TEXT_POLYGON_OFFSET.apply(locationIn);
	}

	/**
	 * @return Replacement of {@link class_1921#method_37346(class_2960)}, but with optional linear texture filtering.
	 */
	public static class_1921 getTextIntensityPolygonOffset(class_2960 locationIn) {
		return Internal.TEXT_INTENSITY_POLYGON_OFFSET.apply(locationIn);
	}

	/**
	 * @return Replacement of {@link class_1921#method_23030(class_2960)}, but with optional linear texture filtering.
	 */
	public static class_1921 getTextSeeThrough(class_2960 locationIn) {
		return Internal.TEXT_SEETHROUGH.apply(locationIn);
	}

	/**
	 * @return Replacement of {@link class_1921#method_36435(class_2960)}, but with optional linear texture filtering.
	 */
	public static class_1921 getTextIntensitySeeThrough(class_2960 locationIn) {
		return Internal.TEXT_INTENSITY_SEETHROUGH.apply(locationIn);
	}

	/**
	 * @return A variation of {@link class_1921#method_23583()} that uses {@link class_4678#field_25281} to allow fabulous transparency sorting when using {@link RenderLevelStageEvent}
	 */
	public static class_1921 getTranslucentParticlesTarget(class_2960 locationIn) {
		return Internal.TRANSLUCENT_PARTICLES_TARGET.apply(locationIn);
	}

	// ----------------------------------------
	//  Implementation details below this line
	// ----------------------------------------

	private final Supplier<class_1921> renderTypeSupplier;

	PortingLibRenderTypes(Supplier<class_1921> renderTypeSupplier) {
		// Wrap in a Lazy<> to avoid running the supplier more than once.
		this.renderTypeSupplier = Lazy.of(renderTypeSupplier);
	}

	public class_1921 get() {
		return renderTypeSupplier.get();
	}

	private static class Internal {
		private static final class_4668.class_5942 RENDERTYPE_ENTITY_TRANSLUCENT_UNLIT_SHADER = new class_4668.class_5942(PortingLibRenderTypes::getEntityTranslucentUnlitShader);

		public static Function<class_2960, class_1921> UNSORTED_TRANSLUCENT = class_156.method_34866(Internal::unsortedTranslucent);

		private static class_1921 unsortedTranslucent(class_2960 textureLocation) {
			final boolean sortingEnabled = false;
			var renderState = class_1921.class_4688.method_23598()
					.method_34578(class_1921.field_29407)
					.method_34577(new class_4683(textureLocation, false, false))
					.method_23615(class_1921.field_21370)
					.method_23603(class_1921.field_21345)
					.method_23608(class_1921.field_21383)
					.method_23611(class_1921.field_21385)
					.method_23617(true);
			return class_1921.method_24049("neoforge_entity_unsorted_translucent", class_290.field_1580, class_293.class_5596.field_27382, 256, true, sortingEnabled, renderState);
		}

		public static Function<class_2960, class_1921> UNLIT_TRANSLUCENT_SORTED = class_156.method_34866(tex -> Internal.unlitTranslucent(tex, true));
		public static Function<class_2960, class_1921> UNLIT_TRANSLUCENT_UNSORTED = class_156.method_34866(tex -> Internal.unlitTranslucent(tex, false));

		private static class_1921 unlitTranslucent(class_2960 textureLocation, boolean sortingEnabled) {
			var renderState = class_1921.class_4688.method_23598()
					.method_34578(RENDERTYPE_ENTITY_TRANSLUCENT_UNLIT_SHADER)
					.method_34577(new class_4683(textureLocation, false, false))
					.method_23615(class_1921.field_21370)
					.method_23603(class_1921.field_21345)
					.method_23608(class_1921.field_21383)
					.method_23611(class_1921.field_21385)
					.method_23617(true);
			return class_1921.method_24049("neoforge_entity_unlit_translucent", class_290.field_1580, class_293.class_5596.field_27382, 256, true, sortingEnabled, renderState);
		}

		public static Function<class_2960, class_1921> LAYERED_ITEM_SOLID = class_156.method_34866(Internal::layeredItemSolid);

		private static class_1921 layeredItemSolid(class_2960 locationIn) {
			var rendertype$state = class_1921.class_4688.method_23598()
					.method_34578(class_1921.field_29450)
					.method_34577(new class_4668.class_4683(locationIn, false, false))
					.method_23615(class_1921.field_21364)
					.method_23608(class_1921.field_21383)
					.method_23611(class_1921.field_21385)
					.method_23617(true);
			return class_1921.method_24049("neoforge_item_entity_solid", class_290.field_1580, class_293.class_5596.field_27382, 256, true, false, rendertype$state);
		}

		public static Function<class_2960, class_1921> LAYERED_ITEM_CUTOUT = class_156.method_34866(Internal::layeredItemCutout);

		private static class_1921 layeredItemCutout(class_2960 locationIn) {
			var rendertype$state = class_1921.class_4688.method_23598()
					.method_34578(class_1921.field_29451)
					.method_34577(new class_4668.class_4683(locationIn, false, false))
					.method_23615(class_1921.field_21364)
					.method_23608(class_1921.field_21383)
					.method_23611(class_1921.field_21385)
					.method_23617(true);
			return class_1921.method_24049("neoforge_item_entity_cutout", class_290.field_1580, class_293.class_5596.field_27382, 256, true, false, rendertype$state);
		}

		public static Function<class_2960, class_1921> LAYERED_ITEM_CUTOUT_MIPPED = class_156.method_34866(Internal::layeredItemCutoutMipped);

		private static class_1921 layeredItemCutoutMipped(class_2960 locationIn) {
			var rendertype$state = class_1921.class_4688.method_23598()
					.method_34578(class_1921.field_29408)
					.method_34577(new class_4668.class_4683(locationIn, false, true))
					.method_23615(class_1921.field_21364)
					.method_23608(class_1921.field_21383)
					.method_23611(class_1921.field_21385)
					.method_23617(true);
			return class_1921.method_24049("neoforge_item_entity_cutout_mipped", class_290.field_1580, class_293.class_5596.field_27382, 256, true, false, rendertype$state);
		}

		public static Function<class_2960, class_1921> LAYERED_ITEM_TRANSLUCENT = class_156.method_34866(Internal::layeredItemTranslucent);

		private static class_1921 layeredItemTranslucent(class_2960 locationIn) {
			var rendertype$state = class_1921.class_4688.method_23598()
					.method_34578(class_1921.field_29407)
					.method_34577(new class_4668.class_4683(locationIn, false, false))
					.method_23615(class_1921.field_21370)
					.method_23608(class_1921.field_21383)
					.method_23611(class_1921.field_21385)
					.method_23617(true);
			return class_1921.method_24049("neoforge_item_entity_translucent_cull", class_290.field_1580, class_293.class_5596.field_27382, 256, true, true, rendertype$state);
		}

		public static Function<class_2960, class_1921> TEXT = class_156.method_34866(Internal::getText);

		private static class_1921 getText(class_2960 locationIn) {
			var rendertype$state = class_1921.class_4688.method_23598()
					.method_34578(class_1921.field_29427)
					.method_34577(new CustomizableTextureState(locationIn, () -> PortingLibRenderTypes.enableTextTextureLinearFiltering, () -> false))
					.method_23615(class_1921.field_21370)
					.method_23608(class_1921.field_21383)
					.method_23617(false);
			return class_1921.method_24049("neoforge_text", class_290.field_20888, class_293.class_5596.field_27382, 256, false, true, rendertype$state);
		}

		public static Function<class_2960, class_1921> TEXT_INTENSITY = class_156.method_34866(Internal::getTextIntensity);

		private static class_1921 getTextIntensity(class_2960 locationIn) {
			var rendertype$state = class_1921.class_4688.method_23598()
					.method_34578(class_1921.field_33628)
					.method_34577(new CustomizableTextureState(locationIn, () -> PortingLibRenderTypes.enableTextTextureLinearFiltering, () -> false))
					.method_23615(class_1921.field_21370)
					.method_23608(class_1921.field_21383)
					.method_23617(false);
			return class_1921.method_24049("neoforge_text_intensity", class_290.field_20888, class_293.class_5596.field_27382, 256, false, true, rendertype$state);
		}

		public static Function<class_2960, class_1921> TEXT_POLYGON_OFFSET = class_156.method_34866(Internal::getTextPolygonOffset);

		private static class_1921 getTextPolygonOffset(class_2960 locationIn) {
			var rendertype$state = class_1921.class_4688.method_23598()
					.method_34578(class_1921.field_29427)
					.method_34577(new CustomizableTextureState(locationIn, () -> PortingLibRenderTypes.enableTextTextureLinearFiltering, () -> false))
					.method_23615(class_1921.field_21370)
					.method_23608(class_1921.field_21383)
					.method_23607(class_1921.field_21353)
					.method_23617(false);
			return class_1921.method_24049("neoforge_text_polygon_offset", class_290.field_20888, class_293.class_5596.field_27382, 256, false, true, rendertype$state);
		}

		public static Function<class_2960, class_1921> TEXT_INTENSITY_POLYGON_OFFSET = class_156.method_34866(Internal::getTextIntensityPolygonOffset);

		private static class_1921 getTextIntensityPolygonOffset(class_2960 locationIn) {
			var rendertype$state = class_1921.class_4688.method_23598()
					.method_34578(class_1921.field_33628)
					.method_34577(new CustomizableTextureState(locationIn, () -> PortingLibRenderTypes.enableTextTextureLinearFiltering, () -> false))
					.method_23615(class_1921.field_21370)
					.method_23608(class_1921.field_21383)
					.method_23607(class_1921.field_21353)
					.method_23617(false);
			return class_1921.method_24049("neoforge_text_intensity_polygon_offset", class_290.field_20888, class_293.class_5596.field_27382, 256, false, true, rendertype$state);
		}

		public static Function<class_2960, class_1921> TEXT_SEETHROUGH = class_156.method_34866(Internal::getTextSeeThrough);

		private static class_1921 getTextSeeThrough(class_2960 locationIn) {
			var rendertype$state = class_1921.class_4688.method_23598()
					.method_34578(class_1921.field_29428)
					.method_34577(new CustomizableTextureState(locationIn, () -> PortingLibRenderTypes.enableTextTextureLinearFiltering, () -> false))
					.method_23615(class_1921.field_21370)
					.method_23608(class_1921.field_21383)
					.method_23604(class_1921.field_21346)
					.method_23616(class_1921.field_21350)
					.method_23617(false);
			return class_1921.method_24049("neoforge_text_see_through", class_290.field_20888, class_293.class_5596.field_27382, 256, false, true, rendertype$state);
		}

		public static Function<class_2960, class_1921> TEXT_INTENSITY_SEETHROUGH = class_156.method_34866(Internal::getTextIntensitySeeThrough);

		private static class_1921 getTextIntensitySeeThrough(class_2960 locationIn) {
			var rendertype$state = class_1921.class_4688.method_23598()
					.method_34578(class_1921.field_33629)
					.method_34577(new CustomizableTextureState(locationIn, () -> PortingLibRenderTypes.enableTextTextureLinearFiltering, () -> false))
					.method_23615(class_1921.field_21370)
					.method_23608(class_1921.field_21383)
					.method_23604(class_1921.field_21346)
					.method_23616(class_1921.field_21350)
					.method_23617(false);
			return class_1921.method_24049("neoforge_text_see_through", class_290.field_20888, class_293.class_5596.field_27382, 256, false, true, rendertype$state);
		}

		public static Function<class_2960, class_1921> TRANSLUCENT_PARTICLES_TARGET = class_156.method_34866(Internal::getTranslucentParticlesTarget);

		private static class_1921 getTranslucentParticlesTarget(class_2960 locationIn) {
			var rendertype$state = class_1921.class_4688.method_23598()
					.method_34578(class_1921.field_29446)
					.method_34577(new class_4668.class_4683(locationIn, false, true))
					.method_23615(class_1921.field_21370)
					.method_23608(class_1921.field_21383)
					.method_23610(class_1921.field_25281)
					.method_23617(true);
			return class_1921.method_24049("neoforge_translucent_particles_target", class_290.field_1590, class_293.class_5596.field_27382, 2097152, true, true, rendertype$state);
		}
	}

	private static class CustomizableTextureState extends class_4683 {
		private final BooleanSupplier blurSupplier;
		private final BooleanSupplier mipmapSupplier;

		private CustomizableTextureState(class_2960 resLoc, BooleanSupplier blur, BooleanSupplier mipmap) {
			super(resLoc, blur.getAsBoolean(), mipmap.getAsBoolean());
			blurSupplier = blur;
			mipmapSupplier = mipmap;
		}

		@Override
		public void method_23516() {
			// must be done before super call as super uses the `blur` and `mipmap` fields within the `setupState` runnable | See super constructor
			field_21398 = blurSupplier.getAsBoolean();
			field_21399 = mipmapSupplier.getAsBoolean();
			super.method_23516();
		}
	}
}
