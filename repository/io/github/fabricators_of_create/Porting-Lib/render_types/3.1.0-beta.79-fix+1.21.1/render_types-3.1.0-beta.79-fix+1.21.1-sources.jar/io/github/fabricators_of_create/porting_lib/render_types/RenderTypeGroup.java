package io.github.fabricators_of_create.porting_lib.render_types;

import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.minecraft.class_1921;

/**
 * A set of functionally equivalent shaders. One using {@link net.minecraft.class_290#field_1590},
 * and the other two using {@link net.minecraft.class_290#field_1580}.
 * {@code entityFabulous} may support custom render targets and other aspects of the fabulous pipeline, or can otherwise
 * be the same as {@code entity}.
 */
public record RenderTypeGroup(class_1921 block, class_1921 entity, class_1921 entityFabulous, RenderMaterial material) {
	public RenderTypeGroup {
		if ((block == null) != (entity == null) || (block == null) != (entityFabulous == null))
			throw new IllegalArgumentException("The render types in a group must either be all null, or all non-null.");
	}

	public RenderTypeGroup(class_1921 block, class_1921 entity, class_1921 entityFabulous) {
		this(block, entity, entityFabulous, RendererAccess.INSTANCE.getRenderer().materialFinder().blendMode(BlendMode.fromRenderLayer(block)).find());
	}

	public RenderTypeGroup(class_1921 block, class_1921 entity) {
		this(block, entity, entity);
	}

	public static RenderTypeGroup EMPTY = new RenderTypeGroup(null, null, null);

	/**
	 * {@return true if this group has render types or not. It either has all, or none}
	 */
	public boolean isEmpty() {
		// We throw an exception in the constructor if nullability doesn't match, so checking this is enough
		return block == null;
	}
}
