package io.github.fabricators_of_create.porting_lib.tags;

import org.jetbrains.annotations.NotNull;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_156;
import net.minecraft.class_2378;
import net.minecraft.class_5819;
import net.minecraft.class_6862;
import net.minecraft.class_6880;

public class TagHelper {
	public static <V> Optional<class_6880.class_6883<V>> getReverseTag(class_2378<V> registry, @NotNull V value) {
		return registry.method_40264(registry.method_29113(value).get());
	}

	public static <V> Optional<V> getRandomElement(class_2378<V> registry, class_6862<V> tag, class_5819 random) {
		return class_156.method_40083(getContents(registry, tag), random);
	}

	public static <V> List<V> getContents(class_2378<V> registry, class_6862<V> tag) {
		return registry.method_40266(tag).map(holders -> holders.method_40239().map(class_6880::comp_349).toList()).orElse(Collections.emptyList());
	}
}
