package io.github.fabricators_of_create.porting_lib.tags;

import net.minecraft.class_1299;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3481;
import net.minecraft.class_3611;
import net.minecraft.class_4970;
import net.minecraft.class_6862;
import net.minecraft.class_757;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public class Tags {
	public static class Blocks {
		// `neoforge` tags for functional behavior provided by NeoForge
		/**
		 * Controls what blocks Endermen cannot place blocks onto.
		 * <p></p>
		 * This is patched into the following method: {@link net.minecraft.class_1560.class_1561#canPlaceBlock(Level, BlockPos, BlockState, BlockState, BlockState, BlockPos)}
		 */
		public static final class_6862<class_2248> ENDERMAN_PLACE_ON_BLACKLIST = neoforgeTag("enderman_place_on_blacklist");
		public static final class_6862<class_2248> NEEDS_WOOD_TOOL = neoforgeTag("needs_wood_tool");
		public static final class_6862<class_2248> NEEDS_GOLD_TOOL = neoforgeTag("needs_gold_tool");
		public static final class_6862<class_2248> NEEDS_NETHERITE_TOOL = neoforgeTag("needs_netherite_tool");

		// `c` tags for common conventions
		public static final class_6862<class_2248> BARRELS = tag("barrels");
		public static final class_6862<class_2248> BARRELS_WOODEN = tag("barrels/wooden");
		public static final class_6862<class_2248> BOOKSHELVES = tag("bookshelves");
		/**
		 * For blocks that are similar to amethyst where their budding block produces buds and cluster blocks
		 */
		public static final class_6862<class_2248> BUDDING_BLOCKS = tag("budding_blocks");
		/**
		 * For blocks that are similar to amethyst where they have buddings forming from budding blocks
		 */
		public static final class_6862<class_2248> BUDS = tag("buds");
		public static final class_6862<class_2248> CHAINS = tag("chains");
		public static final class_6862<class_2248> CHESTS = tag("chests");
		public static final class_6862<class_2248> CHESTS_ENDER = tag("chests/ender");
		public static final class_6862<class_2248> CHESTS_TRAPPED = tag("chests/trapped");
		public static final class_6862<class_2248> CHESTS_WOODEN = tag("chests/wooden");
		/**
		 * For blocks that are similar to amethyst where they have clusters forming from budding blocks
		 */
		public static final class_6862<class_2248> CLUSTERS = tag("clusters");
		public static final class_6862<class_2248> COBBLESTONES = tag("cobblestones");
		public static final class_6862<class_2248> COBBLESTONES_NORMAL = tag("cobblestones/normal");
		public static final class_6862<class_2248> COBBLESTONES_INFESTED = tag("cobblestones/infested");
		public static final class_6862<class_2248> COBBLESTONES_MOSSY = tag("cobblestones/mossy");
		public static final class_6862<class_2248> COBBLESTONES_DEEPSLATE = tag("cobblestones/deepslate");
		public static final class_6862<class_2248> CONCRETES = tag("concretes");

		/**
		 * Tag that holds all blocks that can be dyed a specific color.
		 * (Does not include color blending blocks that would behave similar to leather armor item)
		 */
		public static final class_6862<class_2248> DYED = tag("dyed");
		public static final class_6862<class_2248> DYED_BLACK = tag("dyed/black");
		public static final class_6862<class_2248> DYED_BLUE = tag("dyed/blue");
		public static final class_6862<class_2248> DYED_BROWN = tag("dyed/brown");
		public static final class_6862<class_2248> DYED_CYAN = tag("dyed/cyan");
		public static final class_6862<class_2248> DYED_GRAY = tag("dyed/gray");
		public static final class_6862<class_2248> DYED_GREEN = tag("dyed/green");
		public static final class_6862<class_2248> DYED_LIGHT_BLUE = tag("dyed/light_blue");
		public static final class_6862<class_2248> DYED_LIGHT_GRAY = tag("dyed/light_gray");
		public static final class_6862<class_2248> DYED_LIME = tag("dyed/lime");
		public static final class_6862<class_2248> DYED_MAGENTA = tag("dyed/magenta");
		public static final class_6862<class_2248> DYED_ORANGE = tag("dyed/orange");
		public static final class_6862<class_2248> DYED_PINK = tag("dyed/pink");
		public static final class_6862<class_2248> DYED_PURPLE = tag("dyed/purple");
		public static final class_6862<class_2248> DYED_RED = tag("dyed/red");
		public static final class_6862<class_2248> DYED_WHITE = tag("dyed/white");
		public static final class_6862<class_2248> DYED_YELLOW = tag("dyed/yellow");
		public static final class_6862<class_2248> END_STONES = tag("end_stones");
		public static final class_6862<class_2248> FENCE_GATES = tag("fence_gates");
		public static final class_6862<class_2248> FENCE_GATES_WOODEN = tag("fence_gates/wooden");
		public static final class_6862<class_2248> FENCES = tag("fences");
		public static final class_6862<class_2248> FENCES_NETHER_BRICK = tag("fences/nether_brick");
		public static final class_6862<class_2248> FENCES_WOODEN = tag("fences/wooden");

		public static final class_6862<class_2248> GLASS_BLOCKS = tag("glass_blocks");
		public static final class_6862<class_2248> GLASS_BLOCKS_COLORLESS = tag("glass_blocks/colorless");
		/**
		 * Glass which is made from cheap resources like sand and only minor additional ingredients like dyes
		 */
		public static final class_6862<class_2248> GLASS_BLOCKS_CHEAP = tag("glass_blocks/cheap");
		public static final class_6862<class_2248> GLASS_BLOCKS_TINTED = tag("glass_blocks/tinted");

		public static final class_6862<class_2248> GLASS_PANES = tag("glass_panes");
		public static final class_6862<class_2248> GLASS_PANES_COLORLESS = tag("glass_panes/colorless");
		public static final class_6862<class_2248> GLAZED_TERRACOTTAS = tag("glazed_terracottas");

		public static final class_6862<class_2248> GRAVELS = tag("gravels");
		/**
		 * Tag that holds all blocks that recipe viewers should not show to users.
		 * Recipe viewers may use this to automatically find the corresponding BlockItem to hide.
		 */
		public static final class_6862<class_2248> HIDDEN_FROM_RECIPE_VIEWERS = tag("hidden_from_recipe_viewers");
		public static final class_6862<class_2248> NETHERRACKS = tag("netherracks");
		public static final class_6862<class_2248> OBSIDIANS = tag("obsidians");
		/**
		 * Blocks which are often replaced by deepslate ores, i.e. the ores in the tag {@link #ORES_IN_GROUND_DEEPSLATE}, during world generation
		 */
		public static final class_6862<class_2248> ORE_BEARING_GROUND_DEEPSLATE = tag("ore_bearing_ground/deepslate");
		/**
		 * Blocks which are often replaced by netherrack ores, i.e. the ores in the tag {@link #ORES_IN_GROUND_NETHERRACK}, during world generation
		 */
		public static final class_6862<class_2248> ORE_BEARING_GROUND_NETHERRACK = tag("ore_bearing_ground/netherrack");
		/**
		 * Blocks which are often replaced by stone ores, i.e. the ores in the tag {@link #ORES_IN_GROUND_STONE}, during world generation
		 */
		public static final class_6862<class_2248> ORE_BEARING_GROUND_STONE = tag("ore_bearing_ground/stone");
		/**
		 * Ores which on average result in more than one resource worth of materials
		 */
		public static final class_6862<class_2248> ORE_RATES_DENSE = tag("ore_rates/dense");
		/**
		 * Ores which on average result in one resource worth of materials
		 */
		public static final class_6862<class_2248> ORE_RATES_SINGULAR = tag("ore_rates/singular");
		/**
		 * Ores which on average result in less than one resource worth of materials
		 */
		public static final class_6862<class_2248> ORE_RATES_SPARSE = tag("ore_rates/sparse");
		public static final class_6862<class_2248> ORES = tag("ores");
		public static final class_6862<class_2248> ORES_COAL = tag("ores/coal");
		public static final class_6862<class_2248> ORES_COPPER = tag("ores/copper");
		public static final class_6862<class_2248> ORES_DIAMOND = tag("ores/diamond");
		public static final class_6862<class_2248> ORES_EMERALD = tag("ores/emerald");
		public static final class_6862<class_2248> ORES_GOLD = tag("ores/gold");
		public static final class_6862<class_2248> ORES_IRON = tag("ores/iron");
		public static final class_6862<class_2248> ORES_LAPIS = tag("ores/lapis");
		public static final class_6862<class_2248> ORES_NETHERITE_SCRAP = tag("ores/netherite_scrap");
		public static final class_6862<class_2248> ORES_QUARTZ = tag("ores/quartz");
		public static final class_6862<class_2248> ORES_REDSTONE = tag("ores/redstone");
		/**
		 * Ores in deepslate (or in equivalent blocks in the tag {@link #ORE_BEARING_GROUND_DEEPSLATE}) which could logically use deepslate as recipe input or output
		 */
		public static final class_6862<class_2248> ORES_IN_GROUND_DEEPSLATE = tag("ores_in_ground/deepslate");
		/**
		 * Ores in netherrack (or in equivalent blocks in the tag {@link #ORE_BEARING_GROUND_NETHERRACK}) which could logically use netherrack as recipe input or output
		 */
		public static final class_6862<class_2248> ORES_IN_GROUND_NETHERRACK = tag("ores_in_ground/netherrack");
		/**
		 * Ores in stone (or in equivalent blocks in the tag {@link #ORE_BEARING_GROUND_STONE}) which could logically use stone as recipe input or output
		 */
		public static final class_6862<class_2248> ORES_IN_GROUND_STONE = tag("ores_in_ground/stone");
		public static final class_6862<class_2248> PLAYER_WORKSTATIONS_CRAFTING_TABLES = tag("player_workstations/crafting_tables");
		public static final class_6862<class_2248> PLAYER_WORKSTATIONS_FURNACES = tag("player_workstations/furnaces");
		/**
		 * Blocks should be included in this tag if their movement/relocation can cause serious issues such
		 * as world corruption upon being moved or for balance reason where the block should not be able to be relocated.
		 * Example: Chunk loaders or pipes where other mods that move blocks do not respect
		 * {@link class_4970.class_4971#method_26223}.
		 */
		public static final class_6862<class_2248> RELOCATION_NOT_SUPPORTED = tag("relocation_not_supported");
		public static final class_6862<class_2248> ROPES = tag("ropes");

		public static final class_6862<class_2248> SANDS = tag("sands");
		public static final class_6862<class_2248> SANDS_COLORLESS = tag("sands/colorless");
		public static final class_6862<class_2248> SANDS_RED = tag("sands/red");

		public static final class_6862<class_2248> SANDSTONE_BLOCKS = tag("sandstone/blocks");
		public static final class_6862<class_2248> SANDSTONE_SLABS = tag("sandstone/slabs");
		public static final class_6862<class_2248> SANDSTONE_STAIRS = tag("sandstone/stairs");
		public static final class_6862<class_2248> SANDSTONE_RED_BLOCKS = tag("sandstone/red_blocks");
		public static final class_6862<class_2248> SANDSTONE_RED_SLABS = tag("sandstone/red_slabs");
		public static final class_6862<class_2248> SANDSTONE_RED_STAIRS = tag("sandstone/red_stairs");
		public static final class_6862<class_2248> SANDSTONE_UNCOLORED_BLOCKS = tag("sandstone/uncolored_blocks");
		public static final class_6862<class_2248> SANDSTONE_UNCOLORED_SLABS = tag("sandstone/uncolored_slabs");
		public static final class_6862<class_2248> SANDSTONE_UNCOLORED_STAIRS = tag("sandstone/uncolored_stairs");
		/**
		 * Tag that holds all head based blocks such as Skeleton Skull or Player Head. (Named skulls to match minecraft:skulls item tag)
		 */
		public static final class_6862<class_2248> SKULLS = tag("skulls");
		/**
		 * Natural stone-like blocks that can be used as a base ingredient in recipes that takes stone.
		 */
		public static final class_6862<class_2248> STONES = tag("stones");
		/**
		 * A storage block is generally a block that has a recipe to craft a bulk of 1 kind of resource to a block
		 * and has a mirror recipe to reverse the crafting with no loss in resources.
		 * <p></p>
		 * Honey Block is special in that the reversing recipe is not a perfect mirror of the crafting recipe
		 * and so, it is considered a special case and not given a storage block tag.
		 */
		public static final class_6862<class_2248> STORAGE_BLOCKS = tag("storage_blocks");
		public static final class_6862<class_2248> STORAGE_BLOCKS_BONE_MEAL = tag("storage_blocks/bone_meal");
		public static final class_6862<class_2248> STORAGE_BLOCKS_COAL = tag("storage_blocks/coal");
		public static final class_6862<class_2248> STORAGE_BLOCKS_COPPER = tag("storage_blocks/copper");
		public static final class_6862<class_2248> STORAGE_BLOCKS_DIAMOND = tag("storage_blocks/diamond");
		public static final class_6862<class_2248> STORAGE_BLOCKS_DRIED_KELP = tag("storage_blocks/dried_kelp");
		public static final class_6862<class_2248> STORAGE_BLOCKS_EMERALD = tag("storage_blocks/emerald");
		public static final class_6862<class_2248> STORAGE_BLOCKS_GOLD = tag("storage_blocks/gold");
		public static final class_6862<class_2248> STORAGE_BLOCKS_IRON = tag("storage_blocks/iron");
		public static final class_6862<class_2248> STORAGE_BLOCKS_LAPIS = tag("storage_blocks/lapis");
		public static final class_6862<class_2248> STORAGE_BLOCKS_NETHERITE = tag("storage_blocks/netherite");
		public static final class_6862<class_2248> STORAGE_BLOCKS_RAW_COPPER = tag("storage_blocks/raw_copper");
		public static final class_6862<class_2248> STORAGE_BLOCKS_RAW_GOLD = tag("storage_blocks/raw_gold");
		public static final class_6862<class_2248> STORAGE_BLOCKS_RAW_IRON = tag("storage_blocks/raw_iron");
		public static final class_6862<class_2248> STORAGE_BLOCKS_REDSTONE = tag("storage_blocks/redstone");
		public static final class_6862<class_2248> STORAGE_BLOCKS_SLIME = tag("storage_blocks/slime");
		public static final class_6862<class_2248> STORAGE_BLOCKS_WHEAT = tag("storage_blocks/wheat");
		public static final class_6862<class_2248> VILLAGER_JOB_SITES = tag("villager_job_sites");

		private static class_6862<class_2248> tag(String name) {
			return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", name));
		}

		private static class_6862<class_2248> neoforgeTag(String name) {
			return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("neoforge", name));
		}
	}

	public static class EntityTypes {
		public static final class_6862<class_1299<?>> BOSSES = tag("bosses");
		public static final class_6862<class_1299<?>> MINECARTS = tag("minecarts");
		public static final class_6862<class_1299<?>> BOATS = tag("boats");

		/**
		 * Entities should be included in this tag if they are not allowed to be picked up by items or grabbed in a way
		 * that a player can easily move the entity to anywhere they want. Ideal for special entities that should not
		 * be able to be put into a mob jar for example.
		 */
		public static final class_6862<class_1299<?>> CAPTURING_NOT_SUPPORTED = tag("capturing_not_supported");

		/**
		 * Entities should be included in this tag if they are not allowed to be teleported in any way.
		 * This is more for mods that allow teleporting entities within the same dimension. Any mod that is
		 * teleporting entities to new dimensions should be checking canChangeDimensions method on the entity itself.
		 */
		public static final class_6862<class_1299<?>> TELEPORTING_NOT_SUPPORTED = tag("teleporting_not_supported");

		private static class_6862<class_1299<?>> tag(String name) {
			return class_6862.method_40092(class_7924.field_41266, class_2960.method_60655("c", name));
		}
	}

	public static class Items {
		// `neoforge` tags for functional behavior provided by NeoForge
		/**
		 * Controls what items can be consumed for enchanting such as Enchanting Tables.
		 * This tag defaults to {@link net.minecraft.class_1802#field_8759} when not present in any datapacks, including forge client on vanilla server
		 */
		public static final class_6862<class_1792> ENCHANTING_FUELS = neoforgeTag("enchanting_fuels");

		// `c` tags for common conventions
		public static final class_6862<class_1792> BARRELS = tag("barrels");
		public static final class_6862<class_1792> BARRELS_WOODEN = tag("barrels/wooden");
		public static final class_6862<class_1792> BONES = tag("bones");
		public static final class_6862<class_1792> BOOKSHELVES = tag("bookshelves");
		public static final class_6862<class_1792> BRICKS = tag("bricks");
		public static final class_6862<class_1792> BRICKS_NORMAL = tag("bricks/normal");
		public static final class_6862<class_1792> BRICKS_NETHER = tag("bricks/nether");
		public static final class_6862<class_1792> BUCKETS = tag("buckets");
		public static final class_6862<class_1792> BUCKETS_EMPTY = tag("buckets/empty");
		/**
		 * Does not include entity water buckets.
		 * If checking for the fluid this bucket holds in code, please use {@link net.neoforged.neoforge.fluids.capability.wrappers.FluidBucketWrapper#getFluid} instead.
		 */
		public static final class_6862<class_1792> BUCKETS_WATER = tag("buckets/water");
		/**
		 * If checking for the fluid this bucket holds in code, please use {@link net.neoforged.neoforge.fluids.capability.wrappers.FluidBucketWrapper#getFluid} instead.
		 */
		public static final class_6862<class_1792> BUCKETS_LAVA = tag("buckets/lava");
		public static final class_6862<class_1792> BUCKETS_MILK = tag("buckets/milk");
		public static final class_6862<class_1792> BUCKETS_POWDER_SNOW = tag("buckets/powder_snow");
		public static final class_6862<class_1792> BUCKETS_ENTITY_WATER = tag("buckets/entity_water");
		/**
		 * For blocks that are similar to amethyst where their budding block produces buds and cluster blocks
		 */
		public static final class_6862<class_1792> BUDDING_BLOCKS = tag("budding_blocks");
		/**
		 * For blocks that are similar to amethyst where they have buddings forming from budding blocks
		 */
		public static final class_6862<class_1792> BUDS = tag("buds");
		public static final class_6862<class_1792> CHAINS = tag("chains");
		public static final class_6862<class_1792> CHESTS = tag("chests");
		public static final class_6862<class_1792> CHESTS_ENDER = tag("chests/ender");
		public static final class_6862<class_1792> CHESTS_TRAPPED = tag("chests/trapped");
		public static final class_6862<class_1792> CHESTS_WOODEN = tag("chests/wooden");
		public static final class_6862<class_1792> COBBLESTONES = tag("cobblestones");
		public static final class_6862<class_1792> COBBLESTONES_NORMAL = tag("cobblestones/normal");
		public static final class_6862<class_1792> COBBLESTONES_INFESTED = tag("cobblestones/infested");
		public static final class_6862<class_1792> COBBLESTONES_MOSSY = tag("cobblestones/mossy");
		public static final class_6862<class_1792> COBBLESTONES_DEEPSLATE = tag("cobblestones/deepslate");
		public static final class_6862<class_1792> CONCRETES = tag("concretes");
		/**
		 * Block tag equivalent is {@link class_3481#field_45063}
		 */
		public static final class_6862<class_1792> CONCRETE_POWDERS = tag("concrete_powders");
		/**
		 * For blocks that are similar to amethyst where they have clusters forming from budding blocks
		 */
		public static final class_6862<class_1792> CLUSTERS = tag("clusters");
		public static final class_6862<class_1792> CROPS = tag("crops");
		public static final class_6862<class_1792> CROPS_BEETROOT = tag("crops/beetroot");
		public static final class_6862<class_1792> CROPS_CARROT = tag("crops/carrot");
		public static final class_6862<class_1792> CROPS_NETHER_WART = tag("crops/nether_wart");
		public static final class_6862<class_1792> CROPS_POTATO = tag("crops/potato");
		public static final class_6862<class_1792> CROPS_WHEAT = tag("crops/wheat");
		public static final class_6862<class_1792> DUSTS = tag("dusts");
		public static final class_6862<class_1792> DUSTS_REDSTONE = tag("dusts/redstone");
		public static final class_6862<class_1792> DUSTS_GLOWSTONE = tag("dusts/glowstone");

		/**
		 * Tag that holds all blocks and items that can be dyed a specific color.
		 * (Does not include color blending items like leather armor
		 * Use {@link net.minecraft.class_3489#field_48803} tag instead for color blending items)
		 * <p></p>
		 * Note: Use custom ingredients in recipes to do tag intersections and/or tag exclusions
		 * to make more powerful recipes utilizing multiple tags such as dyed tags for an ingredient.
		 * See {@link net.neoforged.neoforge.common.crafting.DifferenceIngredient} and {@link net.neoforged.neoforge.common.crafting.CompoundIngredient}
		 * for various custom ingredients available that can also be used in data generation.
		 */
		public static final class_6862<class_1792> DYED = tag("dyed");
		public static final class_6862<class_1792> DYED_BLACK = tag("dyed/black");
		public static final class_6862<class_1792> DYED_BLUE = tag("dyed/blue");
		public static final class_6862<class_1792> DYED_BROWN = tag("dyed/brown");
		public static final class_6862<class_1792> DYED_CYAN = tag("dyed/cyan");
		public static final class_6862<class_1792> DYED_GRAY = tag("dyed/gray");
		public static final class_6862<class_1792> DYED_GREEN = tag("dyed/green");
		public static final class_6862<class_1792> DYED_LIGHT_BLUE = tag("dyed/light_blue");
		public static final class_6862<class_1792> DYED_LIGHT_GRAY = tag("dyed/light_gray");
		public static final class_6862<class_1792> DYED_LIME = tag("dyed/lime");
		public static final class_6862<class_1792> DYED_MAGENTA = tag("dyed/magenta");
		public static final class_6862<class_1792> DYED_ORANGE = tag("dyed/orange");
		public static final class_6862<class_1792> DYED_PINK = tag("dyed/pink");
		public static final class_6862<class_1792> DYED_PURPLE = tag("dyed/purple");
		public static final class_6862<class_1792> DYED_RED = tag("dyed/red");
		public static final class_6862<class_1792> DYED_WHITE = tag("dyed/white");
		public static final class_6862<class_1792> DYED_YELLOW = tag("dyed/yellow");

		public static final class_6862<class_1792> DYES = tag("dyes");
		public static final class_6862<class_1792> DYES_BLACK = class_1767.field_7963.getTag();
		public static final class_6862<class_1792> DYES_RED = class_1767.field_7964.getTag();
		public static final class_6862<class_1792> DYES_GREEN = class_1767.field_7942.getTag();
		public static final class_6862<class_1792> DYES_BROWN = class_1767.field_7957.getTag();
		public static final class_6862<class_1792> DYES_BLUE = class_1767.field_7966.getTag();
		public static final class_6862<class_1792> DYES_PURPLE = class_1767.field_7945.getTag();
		public static final class_6862<class_1792> DYES_CYAN = class_1767.field_7955.getTag();
		public static final class_6862<class_1792> DYES_LIGHT_GRAY = class_1767.field_7967.getTag();
		public static final class_6862<class_1792> DYES_GRAY = class_1767.field_7944.getTag();
		public static final class_6862<class_1792> DYES_PINK = class_1767.field_7954.getTag();
		public static final class_6862<class_1792> DYES_LIME = class_1767.field_7961.getTag();
		public static final class_6862<class_1792> DYES_YELLOW = class_1767.field_7947.getTag();
		public static final class_6862<class_1792> DYES_LIGHT_BLUE = class_1767.field_7951.getTag();
		public static final class_6862<class_1792> DYES_MAGENTA = class_1767.field_7958.getTag();
		public static final class_6862<class_1792> DYES_ORANGE = class_1767.field_7946.getTag();
		public static final class_6862<class_1792> DYES_WHITE = class_1767.field_7952.getTag();

		public static final class_6862<class_1792> EGGS = tag("eggs");
		public static final class_6862<class_1792> END_STONES = tag("end_stones");
		public static final class_6862<class_1792> ENDER_PEARLS = tag("ender_pearls");
		public static final class_6862<class_1792> FEATHERS = tag("feathers");
		public static final class_6862<class_1792> FENCE_GATES = tag("fence_gates");
		public static final class_6862<class_1792> FENCE_GATES_WOODEN = tag("fence_gates/wooden");
		public static final class_6862<class_1792> FENCES = tag("fences");
		public static final class_6862<class_1792> FENCES_NETHER_BRICK = tag("fences/nether_brick");
		public static final class_6862<class_1792> FENCES_WOODEN = tag("fences/wooden");
		public static final class_6862<class_1792> FOODS = tag("foods");
		/**
		 * Apples and other foods that are considered fruits in the culinary field belong in this tag.
		 * Cherries would go here as they are considered a "stone fruit" within culinary fields.
		 */
		public static final class_6862<class_1792> FOODS_FRUITS = tag("foods/fruits");
		/**
		 * Tomatoes and other foods that are considered vegetables in the culinary field belong in this tag.
		 */
		public static final class_6862<class_1792> FOODS_VEGETABLES = tag("foods/vegetables");
		/**
		 * Strawberries, raspberries, and other berry foods belong in this tag.
		 * Cherries would NOT go here as they are considered a "stone fruit" within culinary fields.
		 */
		public static final class_6862<class_1792> FOODS_BERRIES = tag("foods/berries");
		public static final class_6862<class_1792> FOODS_BREADS = tag("foods/breads");
		public static final class_6862<class_1792> FOODS_COOKIES = tag("foods/cookies");
		public static final class_6862<class_1792> FOODS_RAW_MEATS = tag("foods/raw_meats");
		public static final class_6862<class_1792> FOODS_COOKED_MEATS = tag("foods/cooked_meats");
		public static final class_6862<class_1792> FOODS_RAW_FISHES = tag("foods/raw_fishes");
		public static final class_6862<class_1792> FOODS_COOKED_FISHES = tag("foods/cooked_fishes");
		/**
		 * Soups, stews, and other liquid food in bowls belongs in this tag.
		 */
		public static final class_6862<class_1792> FOODS_SOUPS = tag("foods/soups");
		/**
		 * Sweets and candies like lollipops or chocolate belong in this tag.
		 */
		public static final class_6862<class_1792> FOODS_CANDIES = tag("foods/candies");
		/**
		 * Foods like cake that can be eaten when placed in the world belong in this tag.
		 */
		public static final class_6862<class_1792> FOODS_EDIBLE_WHEN_PLACED = tag("foods/edible_when_placed");
		/**
		 * For foods that inflict food poisoning-like effects.
		 * Examples are Rotten Flesh's Hunger or Pufferfish's Nausea, or Poisonous Potato's Poison.
		 */
		public static final class_6862<class_1792> FOODS_FOOD_POISONING = tag("foods/food_poisoning");
		public static final class_6862<class_1792> GEMS = tag("gems");
		public static final class_6862<class_1792> GEMS_DIAMOND = tag("gems/diamond");
		public static final class_6862<class_1792> GEMS_EMERALD = tag("gems/emerald");
		public static final class_6862<class_1792> GEMS_AMETHYST = tag("gems/amethyst");
		public static final class_6862<class_1792> GEMS_LAPIS = tag("gems/lapis");
		public static final class_6862<class_1792> GEMS_PRISMARINE = tag("gems/prismarine");
		public static final class_6862<class_1792> GEMS_QUARTZ = tag("gems/quartz");

		public static final class_6862<class_1792> GLASS_BLOCKS = tag("glass_blocks");
		public static final class_6862<class_1792> GLASS_BLOCKS_COLORLESS = tag("glass_blocks/colorless");
		/**
		 * Glass which is made from cheap resources like sand and only minor additional ingredients like dyes
		 */
		public static final class_6862<class_1792> GLASS_BLOCKS_CHEAP = tag("glass_blocks/cheap");
		public static final class_6862<class_1792> GLASS_BLOCKS_TINTED = tag("glass_blocks/tinted");

		public static final class_6862<class_1792> GLASS_PANES = tag("glass_panes");
		public static final class_6862<class_1792> GLASS_PANES_COLORLESS = tag("glass_panes/colorless");
		public static final class_6862<class_1792> GLAZED_TERRACOTTAS = tag("glazed_terracottas");

		public static final class_6862<class_1792> GRAVELS = tag("gravels");
		public static final class_6862<class_1792> GUNPOWDERS = tag("gunpowders");
		/**
		 * Tag that holds all items that recipe viewers should not show to users.
		 */
		public static final class_6862<class_1792> HIDDEN_FROM_RECIPE_VIEWERS = tag("hidden_from_recipe_viewers");
		public static final class_6862<class_1792> INGOTS = tag("ingots");
		public static final class_6862<class_1792> INGOTS_COPPER = tag("ingots/copper");
		public static final class_6862<class_1792> INGOTS_GOLD = tag("ingots/gold");
		public static final class_6862<class_1792> INGOTS_IRON = tag("ingots/iron");
		public static final class_6862<class_1792> INGOTS_NETHERITE = tag("ingots/netherite");
		public static final class_6862<class_1792> LEATHERS = tag("leathers");
		public static final class_6862<class_1792> MUSHROOMS = tag("mushrooms");
		/**
		 * For music disc-like materials to be used in recipes.
		 * A pancake with a JUKEBOX_PLAYABLE component attached to play in Jukeboxes as an Easter Egg is not a music disc and would not go in this tag.
		 */
		public static final class_6862<class_1792> MUSIC_DISCS = tag("music_discs");
		public static final class_6862<class_1792> NETHER_STARS = tag("nether_stars");
		public static final class_6862<class_1792> NETHERRACKS = tag("netherracks");
		public static final class_6862<class_1792> NUGGETS = tag("nuggets");
		public static final class_6862<class_1792> NUGGETS_GOLD = tag("nuggets/gold");
		public static final class_6862<class_1792> NUGGETS_IRON = tag("nuggets/iron");
		public static final class_6862<class_1792> OBSIDIANS = tag("obsidians");
		/**
		 * Blocks which are often replaced by deepslate ores, i.e. the ores in the tag {@link #ORES_IN_GROUND_DEEPSLATE}, during world generation
		 */
		public static final class_6862<class_1792> ORE_BEARING_GROUND_DEEPSLATE = tag("ore_bearing_ground/deepslate");
		/**
		 * Blocks which are often replaced by netherrack ores, i.e. the ores in the tag {@link #ORES_IN_GROUND_NETHERRACK}, during world generation
		 */
		public static final class_6862<class_1792> ORE_BEARING_GROUND_NETHERRACK = tag("ore_bearing_ground/netherrack");
		/**
		 * Blocks which are often replaced by stone ores, i.e. the ores in the tag {@link #ORES_IN_GROUND_STONE}, during world generation
		 */
		public static final class_6862<class_1792> ORE_BEARING_GROUND_STONE = tag("ore_bearing_ground/stone");
		/**
		 * Ores which on average result in more than one resource worth of materials
		 */
		public static final class_6862<class_1792> ORE_RATES_DENSE = tag("ore_rates/dense");
		/**
		 * Ores which on average result in one resource worth of materials
		 */
		public static final class_6862<class_1792> ORE_RATES_SINGULAR = tag("ore_rates/singular");
		/**
		 * Ores which on average result in less than one resource worth of materials
		 */
		public static final class_6862<class_1792> ORE_RATES_SPARSE = tag("ore_rates/sparse");
		public static final class_6862<class_1792> ORES = tag("ores");
		public static final class_6862<class_1792> ORES_COAL = tag("ores/coal");
		public static final class_6862<class_1792> ORES_COPPER = tag("ores/copper");
		public static final class_6862<class_1792> ORES_DIAMOND = tag("ores/diamond");
		public static final class_6862<class_1792> ORES_EMERALD = tag("ores/emerald");
		public static final class_6862<class_1792> ORES_GOLD = tag("ores/gold");
		public static final class_6862<class_1792> ORES_IRON = tag("ores/iron");
		public static final class_6862<class_1792> ORES_LAPIS = tag("ores/lapis");
		public static final class_6862<class_1792> ORES_NETHERITE_SCRAP = tag("ores/netherite_scrap");
		public static final class_6862<class_1792> ORES_QUARTZ = tag("ores/quartz");
		public static final class_6862<class_1792> ORES_REDSTONE = tag("ores/redstone");
		/**
		 * Ores in deepslate (or in equivalent blocks in the tag {@link #ORE_BEARING_GROUND_DEEPSLATE}) which could logically use deepslate as recipe input or output
		 */
		public static final class_6862<class_1792> ORES_IN_GROUND_DEEPSLATE = tag("ores_in_ground/deepslate");
		/**
		 * Ores in netherrack (or in equivalent blocks in the tag {@link #ORE_BEARING_GROUND_NETHERRACK}) which could logically use netherrack as recipe input or output
		 */
		public static final class_6862<class_1792> ORES_IN_GROUND_NETHERRACK = tag("ores_in_ground/netherrack");
		/**
		 * Ores in stone (or in equivalent blocks in the tag {@link #ORE_BEARING_GROUND_STONE}) which could logically use stone as recipe input or output
		 */
		public static final class_6862<class_1792> ORES_IN_GROUND_STONE = tag("ores_in_ground/stone");
		public static final class_6862<class_1792> PLAYER_WORKSTATIONS_CRAFTING_TABLES = tag("player_workstations/crafting_tables");
		public static final class_6862<class_1792> PLAYER_WORKSTATIONS_FURNACES = tag("player_workstations/furnaces");
		public static final class_6862<class_1792> RAW_MATERIALS = tag("raw_materials");
		public static final class_6862<class_1792> RAW_MATERIALS_COPPER = tag("raw_materials/copper");
		public static final class_6862<class_1792> RAW_MATERIALS_GOLD = tag("raw_materials/gold");
		public static final class_6862<class_1792> RAW_MATERIALS_IRON = tag("raw_materials/iron");
		/**
		 * For rod-like materials to be used in recipes.
		 */
		public static final class_6862<class_1792> RODS = tag("rods");
		public static final class_6862<class_1792> RODS_BLAZE = tag("rods/blaze");
		public static final class_6862<class_1792> RODS_BREEZE = tag("rods/breeze");
		/**
		 * For stick-like materials to be used in recipes.
		 * One example is a mod adds stick variants such as Spruce Sticks but would like stick recipes to be able to use it.
		 */
		public static final class_6862<class_1792> RODS_WOODEN = tag("rods/wooden");
		public static final class_6862<class_1792> ROPES = tag("ropes");

		public static final class_6862<class_1792> SANDS = tag("sands");
		public static final class_6862<class_1792> SANDS_COLORLESS = tag("sands/colorless");
		public static final class_6862<class_1792> SANDS_RED = tag("sands/red");

		public static final class_6862<class_1792> SANDSTONE_BLOCKS = tag("sandstone/blocks");
		public static final class_6862<class_1792> SANDSTONE_SLABS = tag("sandstone/slabs");
		public static final class_6862<class_1792> SANDSTONE_STAIRS = tag("sandstone/stairs");
		public static final class_6862<class_1792> SANDSTONE_RED_BLOCKS = tag("sandstone/red_blocks");
		public static final class_6862<class_1792> SANDSTONE_RED_SLABS = tag("sandstone/red_slabs");
		public static final class_6862<class_1792> SANDSTONE_RED_STAIRS = tag("sandstone/red_stairs");
		public static final class_6862<class_1792> SANDSTONE_UNCOLORED_BLOCKS = tag("sandstone/uncolored_blocks");
		public static final class_6862<class_1792> SANDSTONE_UNCOLORED_SLABS = tag("sandstone/uncolored_slabs");
		public static final class_6862<class_1792> SANDSTONE_UNCOLORED_STAIRS = tag("sandstone/uncolored_stairs");

		public static final class_6862<class_1792> SEEDS = tag("seeds");
		public static final class_6862<class_1792> SEEDS_BEETROOT = tag("seeds/beetroot");
		public static final class_6862<class_1792> SEEDS_MELON = tag("seeds/melon");
		public static final class_6862<class_1792> SEEDS_PUMPKIN = tag("seeds/pumpkin");
		public static final class_6862<class_1792> SEEDS_WHEAT = tag("seeds/wheat");
		/**
		 * Block tag equivalent is {@link class_3481#field_21490}
		 */
		public static final class_6862<class_1792> SHULKER_BOXES = tag("shulker_boxes");
		public static final class_6862<class_1792> SLIMEBALLS = tag("slimeballs");
		/**
		 * Natural stone-like blocks that can be used as a base ingredient in recipes that takes stone.
		 */
		public static final class_6862<class_1792> STONES = tag("stones");
		/**
		 * A storage block is generally a block that has a recipe to craft a bulk of 1 kind of resource to a block
		 * and has a mirror recipe to reverse the crafting with no loss in resources.
		 * <p></p>
		 * Honey Block is special in that the reversing recipe is not a perfect mirror of the crafting recipe
		 * and so, it is considered a special case and not given a storage block tag.
		 */
		public static final class_6862<class_1792> STORAGE_BLOCKS = tag("storage_blocks");
		public static final class_6862<class_1792> STORAGE_BLOCKS_BONE_MEAL = tag("storage_blocks/bone_meal");
		public static final class_6862<class_1792> STORAGE_BLOCKS_COAL = tag("storage_blocks/coal");
		public static final class_6862<class_1792> STORAGE_BLOCKS_COPPER = tag("storage_blocks/copper");
		public static final class_6862<class_1792> STORAGE_BLOCKS_DIAMOND = tag("storage_blocks/diamond");
		public static final class_6862<class_1792> STORAGE_BLOCKS_DRIED_KELP = tag("storage_blocks/dried_kelp");
		public static final class_6862<class_1792> STORAGE_BLOCKS_EMERALD = tag("storage_blocks/emerald");
		public static final class_6862<class_1792> STORAGE_BLOCKS_GOLD = tag("storage_blocks/gold");
		public static final class_6862<class_1792> STORAGE_BLOCKS_IRON = tag("storage_blocks/iron");
		public static final class_6862<class_1792> STORAGE_BLOCKS_LAPIS = tag("storage_blocks/lapis");
		public static final class_6862<class_1792> STORAGE_BLOCKS_NETHERITE = tag("storage_blocks/netherite");
		public static final class_6862<class_1792> STORAGE_BLOCKS_RAW_COPPER = tag("storage_blocks/raw_copper");
		public static final class_6862<class_1792> STORAGE_BLOCKS_RAW_GOLD = tag("storage_blocks/raw_gold");
		public static final class_6862<class_1792> STORAGE_BLOCKS_RAW_IRON = tag("storage_blocks/raw_iron");
		public static final class_6862<class_1792> STORAGE_BLOCKS_REDSTONE = tag("storage_blocks/redstone");
		public static final class_6862<class_1792> STORAGE_BLOCKS_SLIME = tag("storage_blocks/slime");
		public static final class_6862<class_1792> STORAGE_BLOCKS_WHEAT = tag("storage_blocks/wheat");
		public static final class_6862<class_1792> STRINGS = tag("strings");
		public static final class_6862<class_1792> VILLAGER_JOB_SITES = tag("villager_job_sites");

		// Tools and Armors
		/**
		 * A tag containing all existing tools. Do not use this tag for determining a tool's behavior.
		 * Please use {@link io.github.fabricators_of_create.porting_lib.tool.ToolActions} instead for what action a tool can do.
		 *
		 * @see ToolAction
		 * @see ToolActions
		 */
		public static final class_6862<class_1792> TOOLS = tag("tools");
		/**
		 * A tag containing all existing shields. Do not use this tag for determining a tool's behavior.
		 * Please use {@link io.github.fabricators_of_create.porting_lib.tool.ToolActions} instead for what action a tool can do.
		 *
		 * @see ToolAction
		 * @see ToolActions
		 */
		public static final class_6862<class_1792> TOOLS_SHIELD = tag("tools/shield");
		/**
		 * A tag containing all existing bows. Do not use this tag for determining a tool's behavior.
		 * Please use {@link io.github.fabricators_of_create.porting_lib.tool.ToolActions} instead for what action a tool can do.
		 *
		 * @see ToolAction
		 * @see ToolActions
		 */
		public static final class_6862<class_1792> TOOLS_BOW = tag("tools/bow");
		/**
		 * A tag containing all existing crossbows. Do not use this tag for determining a tool's behavior.
		 * Please use {@link io.github.fabricators_of_create.porting_lib.tool.ToolActions} instead for what action a tool can do.
		 *
		 * @see io.github.fabricators_of_create.porting_lib.tool.ToolAction
		 * @see io.github.fabricators_of_create.porting_lib.tool.ToolActions
		 */
		public static final class_6862<class_1792> TOOLS_CROSSBOW = tag("tools/crossbow");
		/**
		 * A tag containing all existing fishing rods. Do not use this tag for determining a tool's behavior.
		 * Please use {@link io.github.fabricators_of_create.porting_lib.tool.ToolActions} instead for what action a tool can do.
		 *
		 * @see io.github.fabricators_of_create.porting_lib.tool.ToolAction
		 * @see io.github.fabricators_of_create.porting_lib.tool.ToolActions
		 */
		public static final class_6862<class_1792> TOOLS_FISHING_ROD = tag("tools/fishing_rod");
		/**
		 * A tag containing all existing spears. Other tools such as throwing knives or boomerangs
		 * should not be put into this tag and should be put into their own tool tags.
		 * Do not use this tag for determining a tool's behavior.
		 * Please use {@link io.github.fabricators_of_create.porting_lib.tool.ToolActions} instead for what action a tool can do.
		 *
		 * @see ToolAction
		 * @see ToolActions
		 */
		public static final class_6862<class_1792> TOOLS_SPEAR = tag("tools/spear");
		/**
		 * A tag containing all existing shears. Do not use this tag for determining a tool's behavior.
		 * Please use {@link io.github.fabricators_of_create.porting_lib.tool.ToolActions} instead for what action a tool can do.
		 *
		 * @see ToolAction
		 * @see ToolActions
		 */
		public static final class_6862<class_1792> TOOLS_SHEAR = tag("tools/shear");
		/**
		 * A tag containing all existing brushes. Do not use this tag for determining a tool's behavior.
		 * Please use {@link io.github.fabricators_of_create.porting_lib.tool.ToolActions} instead for what action a tool can do.
		 *
		 * @see ToolAction
		 * @see ToolActions
		 */
		public static final class_6862<class_1792> TOOLS_BRUSH = tag("tools/brush");
		/**
		 * Collects the 4 vanilla armor tags into one parent collection for ease.
		 */
		public static final class_6862<class_1792> ARMORS = tag("armors");
		/**
		 * Collects the many enchantable tags into one parent collection for ease.
		 */
		public static final class_6862<class_1792> ENCHANTABLES = tag("enchantables");

		private static class_6862<class_1792> tag(String name) {
			return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", name));
		}

		private static class_6862<class_1792> neoforgeTag(String name) {
			return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("neoforge", name));
		}
	}

	/**
	 * Note, fluid tags should not be plural to match the vanilla standard.
	 * This is the only tag category exempted from many-different-types plural rule.
	 */
	public static class Fluids {
		/**
		 * Holds all fluids related to water.
		 * This tag is done to help out multi-loader mods/datapacks where the vanilla water tag has attached behaviors outside Neo.
		 */
		public static final class_6862<class_3611> WATER = tag("water");
		/**
		 * Holds all fluids related to lava.
		 * This tag is done to help out multi-loader mods/datapacks where the vanilla lava tag has attached behaviors outside Neo.
		 */
		public static final class_6862<class_3611> LAVA = tag("lava");
		/**
		 * Holds all fluids related to milk.
		 */
		public static final class_6862<class_3611> MILK = tag("milk");
		/**
		 * Holds all fluids that are gaseous at room temperature.
		 */
		public static final class_6862<class_3611> GASEOUS = tag("gaseous");
		/**
		 * Holds all fluids related to honey.<br></br>
		 * (Standard unit for honey bottle is 250mb per bottle)
		 */
		public static final class_6862<class_3611> HONEY = tag("honey");
		/**
		 * Holds all fluids related to potions. The effects of the potion fluid should be read from NBT.
		 * The effects and color of the potion fluid should be read from {@link net.minecraft.class_9334#field_49651}
		 * component that people should be attaching to the fluidstack of this fluid.<br></br>
		 * (Standard unit for potions is 250mb per bottle)
		 */
		public static final class_6862<class_3611> POTION = tag("potion");
		/**
		 * Holds all fluids related to Suspicious Stew.
		 * The effects of the suspicious stew fluid should be read from {@link net.minecraft.class_9334#field_49652}
		 * component that people should be attaching to the fluidstack of this fluid.<br></br>
		 * (Standard unit for suspicious stew is 250mb per bowl)
		 */
		public static final class_6862<class_3611> SUSPICIOUS_STEW = tag("suspicious_stew");
		/**
		 * Holds all fluids related to Mushroom Stew.<br></br>
		 * (Standard unit for mushroom stew is 250mb per bowl)
		 */
		public static final class_6862<class_3611> MUSHROOM_STEW = tag("mushroom_stew");
		/**
		 * Holds all fluids related to Rabbit Stew.<br></br>
		 * (Standard unit for rabbit stew is 250mb per bowl)
		 */
		public static final class_6862<class_3611> RABBIT_STEW = tag("rabbit_stew");
		/**
		 * Holds all fluids related to Beetroot Soup.<br></br>
		 * (Standard unit for beetroot soup is 250mb per bowl)
		 */
		public static final class_6862<class_3611> BEETROOT_SOUP = tag("beetroot_soup");
		/**
		 * Tag that holds all fluids that recipe viewers should not show to users.
		 */
		public static final class_6862<class_3611> HIDDEN_FROM_RECIPE_VIEWERS = tag("hidden_from_recipe_viewers");

		private static class_6862<class_3611> tag(String name) {
			return class_6862.method_40092(class_7924.field_41270, class_2960.method_60655("c", name));
		}
	}

	public static class Enchantments {
		/**
		 * A tag containing enchantments that increase the amount or
		 * quality of drops from blocks, such as {@link net.minecraft.class_1893#field_9130}.
		 */
		public static final class_6862<class_1887> INCREASE_BLOCK_DROPS = tag("increase_block_drops");
		/**
		 * A tag containing enchantments that increase the amount or
		 * quality of drops from entities, such as {@link net.minecraft.class_1893#field_9110}.
		 */
		public static final class_6862<class_1887> INCREASE_ENTITY_DROPS = tag("increase_entity_drops");
		/**
		 * For enchantments that increase the damage dealt by an item.
		 */
		public static final class_6862<class_1887> WEAPON_DAMAGE_ENHANCEMENTS = tag("weapon_damage_enhancements");
		/**
		 * For enchantments that increase movement speed for entity wearing armor enchanted with it.
		 */
		public static final class_6862<class_1887> ENTITY_SPEED_ENHANCEMENTS = tag("entity_speed_enhancements");
		/**
		 * For enchantments that applies movement-based benefits unrelated to speed for the entity wearing armor enchanted with it.
		 * Example: Reducing falling speeds ({@link net.minecraft.class_1893#field_9129}) or allowing walking on water ({@link net.minecraft.class_1893#field_9122})
		 */
		public static final class_6862<class_1887> ENTITY_AUXILIARY_MOVEMENT_ENHANCEMENTS = tag("entity_auxiliary_movement_enhancements");
		/**
		 * For enchantments that decrease damage taken or otherwise benefit, in regard to damage, the entity wearing armor enchanted with it.
		 */
		public static final class_6862<class_1887> ENTITY_DEFENSE_ENHANCEMENTS = tag("entity_defense_enhancements");

		private static class_6862<class_1887> tag(String name) {
			return class_6862.method_40092(class_7924.field_41265, class_2960.method_60655("c", name));
		}
	}

	public static class Biomes {
		/**
		 * For biomes that should not spawn monsters over time the normal way.
		 * In other words, their Spawners and Spawn Cost entries have the monster category empty.
		 * Example: Mushroom Biomes not having Zombies, Creepers, Skeleton, nor any other normal monsters.
		 */
		public static final class_6862<class_1959> NO_DEFAULT_MONSTERS = tag("no_default_monsters");
		/**
		 * Biomes that should not be locatable/selectable by modded biome-locating items or abilities.
		 */
		public static final class_6862<class_1959> HIDDEN_FROM_LOCATOR_SELECTION = tag("hidden_from_locator_selection");

		public static final class_6862<class_1959> IS_VOID = tag("is_void");

		public static final class_6862<class_1959> IS_HOT = tag("is_hot");
		public static final class_6862<class_1959> IS_HOT_OVERWORLD = tag("is_hot/overworld");
		public static final class_6862<class_1959> IS_HOT_NETHER = tag("is_hot/nether");
		public static final class_6862<class_1959> IS_HOT_END = tag("is_hot/end");

		public static final class_6862<class_1959> IS_COLD = tag("is_cold");
		public static final class_6862<class_1959> IS_COLD_OVERWORLD = tag("is_cold/overworld");
		public static final class_6862<class_1959> IS_COLD_NETHER = tag("is_cold/nether");
		public static final class_6862<class_1959> IS_COLD_END = tag("is_cold/end");

		public static final class_6862<class_1959> IS_SPARSE_VEGETATION = tag("is_sparse_vegetation");
		public static final class_6862<class_1959> IS_SPARSE_VEGETATION_OVERWORLD = tag("is_sparse_vegetation/overworld");
		public static final class_6862<class_1959> IS_SPARSE_VEGETATION_NETHER = tag("is_sparse_vegetation/nether");
		public static final class_6862<class_1959> IS_SPARSE_VEGETATION_END = tag("is_sparse_vegetation/end");
		public static final class_6862<class_1959> IS_DENSE_VEGETATION = tag("is_dense_vegetation");
		public static final class_6862<class_1959> IS_DENSE_VEGETATION_OVERWORLD = tag("is_dense_vegetation/overworld");
		public static final class_6862<class_1959> IS_DENSE_VEGETATION_NETHER = tag("is_dense_vegetation/nether");
		public static final class_6862<class_1959> IS_DENSE_VEGETATION_END = tag("is_dense_vegetation/end");

		public static final class_6862<class_1959> IS_WET = tag("is_wet");
		public static final class_6862<class_1959> IS_WET_OVERWORLD = tag("is_wet/overworld");
		public static final class_6862<class_1959> IS_WET_NETHER = tag("is_wet/nether");
		public static final class_6862<class_1959> IS_WET_END = tag("is_wet/end");
		public static final class_6862<class_1959> IS_DRY = tag("is_dry");
		public static final class_6862<class_1959> IS_DRY_OVERWORLD = tag("is_dry/overworld");
		public static final class_6862<class_1959> IS_DRY_NETHER = tag("is_dry/nether");
		public static final class_6862<class_1959> IS_DRY_END = tag("is_dry/end");

		/**
		 * Biomes that spawn in the Overworld.
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_37393}
		 * <p></p>
		 * NOTE: If you do not add to the vanilla Overworld tag, be sure to add to
		 * {@link net.minecraft.class_6908#field_36502} so some Strongholds do not go missing.)
		 */
		public static final class_6862<class_1959> IS_OVERWORLD = tag("is_overworld");

		public static final class_6862<class_1959> IS_CONIFEROUS_TREE = tag("is_tree/coniferous");
		public static final class_6862<class_1959> IS_SAVANNA_TREE = tag("is_tree/savanna");
		public static final class_6862<class_1959> IS_JUNGLE_TREE = tag("is_tree/jungle");
		public static final class_6862<class_1959> IS_DECIDUOUS_TREE = tag("is_tree/deciduous");

		/**
		 * Biomes that spawn as part of giant mountains.
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_36512})
		 */
		public static final class_6862<class_1959> IS_MOUNTAIN = tag("is_mountain");
		public static final class_6862<class_1959> IS_MOUNTAIN_PEAK = tag("is_mountain/peak");
		public static final class_6862<class_1959> IS_MOUNTAIN_SLOPE = tag("is_mountain/slope");

		/**
		 * For temperate or warmer plains-like biomes.
		 * For snowy plains-like biomes, see {@link #IS_SNOWY_PLAINS}.
		 */
		public static final class_6862<class_1959> IS_PLAINS = tag("is_plains");
		/**
		 * For snowy plains-like biomes.
		 * For warmer plains-like biomes, see {@link #IS_PLAINS}.
		 */
		public static final class_6862<class_1959> IS_SNOWY_PLAINS = tag("is_snowy_plains");
		/**
		 * Biomes densely populated with deciduous trees.
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_36517})
		 */
		public static final class_6862<class_1959> IS_FOREST = tag("is_forest");
		public static final class_6862<class_1959> IS_BIRCH_FOREST = tag("is_birch_forest");
		public static final class_6862<class_1959> IS_FLOWER_FOREST = tag("is_flower_forest");
		/**
		 * Biomes that spawn as a taiga.
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_36515})
		 */
		public static final class_6862<class_1959> IS_TAIGA = tag("is_taiga");
		public static final class_6862<class_1959> IS_OLD_GROWTH = tag("is_old_growth");
		/**
		 * Biomes that spawn as a hills biome. (Previously was called Extreme Hills biome in past)
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_36514})
		 */
		public static final class_6862<class_1959> IS_HILL = tag("is_hill");
		public static final class_6862<class_1959> IS_WINDSWEPT = tag("is_windswept");
		/**
		 * Biomes that spawn as a jungle.
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_36516})
		 */
		public static final class_6862<class_1959> IS_JUNGLE = tag("is_jungle");
		/**
		 * Biomes that spawn as a savanna.
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_37392})
		 */
		public static final class_6862<class_1959> IS_SAVANNA = tag("is_savanna");
		public static final class_6862<class_1959> IS_SWAMP = tag("is_swamp");
		public static final class_6862<class_1959> IS_DESERT = tag("is_desert");
		/**
		 * Biomes that spawn as a badlands.
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_36513})
		 */
		public static final class_6862<class_1959> IS_BADLANDS = tag("is_badlands");
		/**
		 * Biomes that are dedicated to spawning on the shoreline of a body of water.
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_36510})
		 */
		public static final class_6862<class_1959> IS_BEACH = tag("is_beach");
		public static final class_6862<class_1959> IS_STONY_SHORES = tag("is_stony_shores");
		public static final class_6862<class_1959> IS_MUSHROOM = tag("is_mushroom");

		/**
		 * Biomes that spawn as a river.
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_36511})
		 */
		public static final class_6862<class_1959> IS_RIVER = tag("is_river");
		/**
		 * Biomes that spawn as part of the world's oceans.
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_36509})
		 */
		public static final class_6862<class_1959> IS_OCEAN = tag("is_ocean");
		/**
		 * Biomes that spawn as part of the world's oceans that have low depth.
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_36508})
		 */
		public static final class_6862<class_1959> IS_DEEP_OCEAN = tag("is_deep_ocean");
		public static final class_6862<class_1959> IS_SHALLOW_OCEAN = tag("is_shallow_ocean");

		public static final class_6862<class_1959> IS_UNDERGROUND = tag("is_underground");
		public static final class_6862<class_1959> IS_CAVE = tag("is_cave");

		public static final class_6862<class_1959> IS_LUSH = tag("is_lush");
		public static final class_6862<class_1959> IS_MAGICAL = tag("is_magical");
		public static final class_6862<class_1959> IS_RARE = tag("is_rare");
		public static final class_6862<class_1959> IS_PLATEAU = tag("is_plateau");
		public static final class_6862<class_1959> IS_MODIFIED = tag("is_modified");
		public static final class_6862<class_1959> IS_SPOOKY = tag("is_spooky");
		/**
		 * Biomes that lack any natural life or vegetation.
		 * (Example, land destroyed and sterilized by nuclear weapons)
		 */
		public static final class_6862<class_1959> IS_WASTELAND = tag("is_wasteland");
		/**
		 * Biomes whose flora primarily consists of dead or decaying vegetation.
		 */
		public static final class_6862<class_1959> IS_DEAD = tag("is_dead");
		/**
		 * Biomes with a large amount of flowers.
		 */
		public static final class_6862<class_1959> IS_FLORAL = tag("is_floral");
		/**
		 * Biomes that are able to spawn sand-based blocks on the surface.
		 */
		public static final class_6862<class_1959> IS_SANDY = tag("is_sandy");
		/**
		 * For biomes that contains lots of naturally spawned snow.
		 * For biomes where lot of ice is present, see {@link #IS_ICY}.
		 * Biome with lots of both snow and ice may be in both tags.
		 */
		public static final class_6862<class_1959> IS_SNOWY = tag("is_snowy");
		/**
		 * For land biomes where ice naturally spawns.
		 * For biomes where snow alone spawns, see {@link #IS_SNOWY}.
		 */
		public static final class_6862<class_1959> IS_ICY = tag("is_icy");
		/**
		 * Biomes consisting primarily of water.
		 */
		public static final class_6862<class_1959> IS_AQUATIC = tag("is_aquatic");
		/**
		 * For water biomes where ice naturally spawns.
		 * For biomes where snow alone spawns, see {@link #IS_SNOWY}.
		 */
		public static final class_6862<class_1959> IS_AQUATIC_ICY = tag("is_aquatic_icy");

		/**
		 * Biomes that spawn in the Nether.
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_36518})
		 */
		public static final class_6862<class_1959> IS_NETHER = tag("is_nether");
		public static final class_6862<class_1959> IS_NETHER_FOREST = tag("is_nether_forest");

		/**
		 * Biomes that spawn in the End.
		 * (This is for people who want to tag their biomes without getting
		 * side effects from {@link net.minecraft.class_6908#field_37394})
		 */
		public static final class_6862<class_1959> IS_END = tag("is_end");
		/**
		 * Biomes that spawn as part of the large islands outside the center island in The End dimension.
		 */
		public static final class_6862<class_1959> IS_OUTER_END_ISLAND = tag("is_outer_end_island");

		private static class_6862<class_1959> tag(String name) {
			return class_6862.method_40092(class_7924.field_41236, class_2960.method_60655("c", name));
		}
	}

	public static class Structures {
		/**
		 * Structures that should not show up on minimaps or world map views from mods/sites.
		 * No effect on vanilla map items.
		 */
		public static final class_6862<class_3195> HIDDEN_FROM_DISPLAYERS = tag("hidden_from_displayers");

		/**
		 * Structures that should not be locatable/selectable by modded structure-locating items or abilities.
		 * No effect on vanilla map items.
		 */
		public static final class_6862<class_3195> HIDDEN_FROM_LOCATOR_SELECTION = tag("hidden_from_locator_selection");

		private static class_6862<class_3195> tag(String name) {
			return class_6862.method_40092(class_7924.field_41246, class_2960.method_60655("c", name));
		}
	}

	public static class DamageTypes {
		/**
		 * Damage types representing magic damage.
		 */
		public static final class_6862<class_8110> IS_MAGIC = neoforgeTag("is_magic");

		/**
		 * Damage types representing poison damage.
		 */
		public static final class_6862<class_8110> IS_POISON = neoforgeTag("is_poison");

		/**
		 * Damage types representing damage that can be attributed to withering or the wither.
		 */
		public static final class_6862<class_8110> IS_WITHER = neoforgeTag("is_wither");

		/**
		 * Damage types representing environmental damage, such as fire, lava, magma, cactus, lightning, etc.
		 */
		public static final class_6862<class_8110> IS_ENVIRONMENT = neoforgeTag("is_environment");

		/**
		 * Damage types representing physical damage.<br>
		 * These are types that do not fit other #is_x tags (except #is_fall)
		 * and would meet the general definition of physical damage.
		 */
		public static final class_6862<class_8110> IS_PHYSICAL = neoforgeTag("is_physical");

		/**
		 * Damage types representing damage from commands or other non-gameplay sources.<br>
		 * Damage from these types should not be reduced, and bypasses invulnerability.
		 */
		public static final class_6862<class_8110> IS_TECHNICAL = neoforgeTag("is_technical");

		/**
		 * Damage types that will not cause the red flashing effect.<br>
		 * This tag is empty by default.
		 *
		 * @see class_757#method_3198
		 */
		public static final class_6862<class_8110> NO_FLINCH = neoforgeTag("no_flinch");

		private static class_6862<class_8110> neoforgeTag(String name) {
			return class_6862.method_40092(class_7924.field_42534, class_2960.method_60655("neoforge", name));
		}
	}

	/**
	 * Use this to get a TagKey's translation key safely on any side.
	 *
	 * @return the translation key for a TagKey.
	 */
	public static String getTagTranslationKey(class_6862<?> tagKey) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("tag.");

		class_2960 registryIdentifier = tagKey.comp_326().method_29177();
		class_2960 tagIdentifier = tagKey.comp_327();

		if (!registryIdentifier.method_12836().equals("minecraft")) {
			stringBuilder.append(registryIdentifier.method_12836())
					.append(".");
		}

		stringBuilder.append(registryIdentifier.method_12832().replace("/", "."))
				.append(".")
				.append(tagIdentifier.method_12836())
				.append(".")
				.append(tagIdentifier.method_12832().replace("/", ".").replace(":", "."));

		return stringBuilder.toString();
	}
}
