package io.github.fabricators_of_create.porting_lib.tags.data;

import java.util.concurrent.CompletableFuture;

import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6908;
import net.minecraft.class_7225;
import net.minecraft.class_7924;

public final class BiomeTagsProvider extends FabricTagProvider<class_1959> {
	public BiomeTagsProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> lookupProvider) {
		super(output, class_7924.field_41236, lookupProvider);
	}

	@Override
	protected void method_10514(class_7225.class_7874 lookupProvider) {
		method_10512(Tags.Biomes.NO_DEFAULT_MONSTERS).method_46835(class_1972.field_9462).method_46835(class_1972.field_37543);
		method_10512(Tags.Biomes.HIDDEN_FROM_LOCATOR_SELECTION); // Create tag file for visibility

		method_10512(Tags.Biomes.IS_VOID).method_46835(class_1972.field_9473);

		method_10512(Tags.Biomes.IS_END).method_26792(class_6908.field_37394);
		method_10512(Tags.Biomes.IS_NETHER).method_26792(class_6908.field_36518);
		method_10512(Tags.Biomes.IS_OVERWORLD).method_26792(class_6908.field_37393);

		method_10512(Tags.Biomes.IS_HOT_OVERWORLD)
				.method_46835(class_1972.field_9471)
				.method_46835(class_1972.field_38748)
				.method_46835(class_1972.field_9417)
				.method_46835(class_1972.field_9440)
				.method_46835(class_1972.field_35118)
				.method_46835(class_1972.field_9424)
				.method_46835(class_1972.field_9443)
				.method_46835(class_1972.field_9449)
				.method_46835(class_1972.field_9430)
				.method_46835(class_1972.field_35114)
				.method_46835(class_1972.field_34475)
				.method_46835(class_1972.field_9408);
		method_10512(Tags.Biomes.IS_HOT_NETHER)
				.method_46835(class_1972.field_9461)
				.method_46835(class_1972.field_22077)
				.method_46835(class_1972.field_22075)
				.method_46835(class_1972.field_22076)
				.method_46835(class_1972.field_23859);
		method_10512(Tags.Biomes.IS_HOT_END);
		method_10512(Tags.Biomes.IS_HOT).method_26792(Tags.Biomes.IS_HOT_OVERWORLD).method_26792(Tags.Biomes.IS_HOT_NETHER).method_35923(Tags.Biomes.IS_HOT_END.comp_327());

		method_10512(Tags.Biomes.IS_COLD_OVERWORLD)
				.method_46835(class_1972.field_9420)
				.method_46835(class_1972.field_35119)
				.method_46835(class_1972.field_35117)
				.method_46835(class_1972.field_9453)
				.method_46835(class_1972.field_34471)
				.method_46835(class_1972.field_34472)
				.method_46835(class_1972.field_34474)
				.method_46835(class_1972.field_35115)
				.method_46835(class_1972.field_9478)
				.method_46835(class_1972.field_9454)
				.method_46835(class_1972.field_9463)
				.method_46835(class_1972.field_9467)
				.method_46835(class_1972.field_9435)
				.method_46835(class_1972.field_9470)
				.method_46835(class_1972.field_9418);
		method_10512(Tags.Biomes.IS_COLD_NETHER);
		method_10512(Tags.Biomes.IS_COLD_END)
				.method_46835(class_1972.field_9411)
				.method_46835(class_1972.field_9457)
				.method_46835(class_1972.field_9447)
				.method_46835(class_1972.field_9442)
				.method_46835(class_1972.field_9465);
		method_10512(Tags.Biomes.IS_COLD).method_26792(Tags.Biomes.IS_COLD_OVERWORLD).method_35923(Tags.Biomes.IS_COLD_NETHER.comp_327()).method_26792(Tags.Biomes.IS_COLD_END);

		method_10512(Tags.Biomes.IS_SPARSE_VEGETATION_OVERWORLD)
				.method_46835(class_1972.field_35110)
				.method_46835(class_1972.field_9449)
				.method_46835(class_1972.field_9430)
				.method_46835(class_1972.field_35114)
				.method_46835(class_1972.field_35120)
				.method_46835(class_1972.field_35116)
				.method_46835(class_1972.field_35111)
				.method_46835(class_1972.field_34472)
				.method_46835(class_1972.field_34474)
				.method_46835(class_1972.field_35115);
		method_10512(Tags.Biomes.IS_SPARSE_VEGETATION_NETHER);
		method_10512(Tags.Biomes.IS_SPARSE_VEGETATION_END);
		method_10512(Tags.Biomes.IS_SPARSE_VEGETATION).method_26792(Tags.Biomes.IS_SPARSE_VEGETATION_OVERWORLD).method_35923(Tags.Biomes.IS_SPARSE_VEGETATION_NETHER.comp_327()).method_35923(Tags.Biomes.IS_SPARSE_VEGETATION_END.comp_327());

		method_10512(Tags.Biomes.IS_DENSE_VEGETATION_OVERWORLD)
				.method_46835(class_1972.field_9475)
				.method_46835(class_1972.field_35112)
				.method_46835(class_1972.field_35113)
				.method_46835(class_1972.field_9417)
				.method_46835(class_1972.field_9440)
				.method_46835(class_1972.field_38748);
		method_10512(Tags.Biomes.IS_DENSE_VEGETATION_NETHER);
		method_10512(Tags.Biomes.IS_DENSE_VEGETATION_END);
		method_10512(Tags.Biomes.IS_DENSE_VEGETATION).method_26792(Tags.Biomes.IS_DENSE_VEGETATION_OVERWORLD).method_35923(Tags.Biomes.IS_DENSE_VEGETATION_NETHER.comp_327()).method_35923(Tags.Biomes.IS_DENSE_VEGETATION_END.comp_327());

		method_10512(Tags.Biomes.IS_WET_OVERWORLD)
				.method_46835(class_1972.field_9471)
				.method_46835(class_1972.field_38748)
				.method_46835(class_1972.field_9417)
				.method_46835(class_1972.field_9440)
				.method_46835(class_1972.field_35118)
				.method_46835(class_1972.field_9434)
				.method_46835(class_1972.field_29218)
				.method_46835(class_1972.field_28107);
		method_10512(Tags.Biomes.IS_WET_NETHER);
		method_10512(Tags.Biomes.IS_WET_END);
		method_10512(Tags.Biomes.IS_WET).method_26792(Tags.Biomes.IS_WET_OVERWORLD).method_35923(Tags.Biomes.IS_WET_NETHER.comp_327()).method_35923(Tags.Biomes.IS_WET_END.comp_327());

		method_10512(Tags.Biomes.IS_DRY_OVERWORLD)
				.method_46835(class_1972.field_9424)
				.method_46835(class_1972.field_9415)
				.method_46835(class_1972.field_35110)
				.method_46835(class_1972.field_9443)
				.method_46835(class_1972.field_9449)
				.method_46835(class_1972.field_9430)
				.method_46835(class_1972.field_35114);
		method_10512(Tags.Biomes.IS_DRY_NETHER)
				.method_46835(class_1972.field_9461)
				.method_46835(class_1972.field_22077)
				.method_46835(class_1972.field_22075)
				.method_46835(class_1972.field_22076)
				.method_46835(class_1972.field_23859);
		method_10512(Tags.Biomes.IS_DRY_END)
				.method_46835(class_1972.field_9411)
				.method_46835(class_1972.field_9457)
				.method_46835(class_1972.field_9447)
				.method_46835(class_1972.field_9442)
				.method_46835(class_1972.field_9465);
		method_10512(Tags.Biomes.IS_DRY).method_26792(Tags.Biomes.IS_DRY_OVERWORLD).method_26792(Tags.Biomes.IS_DRY_NETHER).method_26792(Tags.Biomes.IS_DRY_END);

		method_10512(Tags.Biomes.IS_CONIFEROUS_TREE).method_26792(Tags.Biomes.IS_TAIGA).method_46835(class_1972.field_34471);
		method_10512(Tags.Biomes.IS_SAVANNA_TREE).method_26792(Tags.Biomes.IS_SAVANNA);
		method_10512(Tags.Biomes.IS_JUNGLE_TREE).method_26792(Tags.Biomes.IS_JUNGLE);
		method_10512(Tags.Biomes.IS_DECIDUOUS_TREE).method_46835(class_1972.field_9409).method_46835(class_1972.field_9414).method_46835(class_1972.field_9412).method_46835(class_1972.field_9475).method_46835(class_1972.field_35112).method_46835(class_1972.field_35120);

		method_10512(Tags.Biomes.IS_MOUNTAIN_SLOPE).method_46835(class_1972.field_34472).method_46835(class_1972.field_34470).method_46835(class_1972.field_34471).method_46835(class_1972.field_42720);
		method_10512(Tags.Biomes.IS_MOUNTAIN_PEAK).method_46835(class_1972.field_34474).method_46835(class_1972.field_35115).method_46835(class_1972.field_34475);
		method_10512(Tags.Biomes.IS_MOUNTAIN).method_26792(class_6908.field_36512).method_26792(Tags.Biomes.IS_MOUNTAIN_PEAK).method_26792(Tags.Biomes.IS_MOUNTAIN_SLOPE);

		method_10512(Tags.Biomes.IS_FOREST).method_26792(class_6908.field_36517);
		method_10512(Tags.Biomes.IS_BIRCH_FOREST).method_46835(class_1972.field_9412).method_46835(class_1972.field_35112);
		method_10512(Tags.Biomes.IS_FLOWER_FOREST).method_46835(class_1972.field_9414);
		method_10512(Tags.Biomes.IS_FLORAL).method_26792(Tags.Biomes.IS_FLOWER_FOREST).method_46835(class_1972.field_9455).method_46835(class_1972.field_42720).method_46835(class_1972.field_34470);
		method_10512(Tags.Biomes.IS_BEACH).method_26792(class_6908.field_36510);
		method_10512(Tags.Biomes.IS_STONY_SHORES).method_46835(class_1972.field_9419);
		method_10512(Tags.Biomes.IS_DESERT).method_46835(class_1972.field_9424);
		method_10512(Tags.Biomes.IS_BADLANDS).method_26792(class_6908.field_36513);
		method_10512(Tags.Biomes.IS_PLAINS).method_46835(class_1972.field_9451).method_46835(class_1972.field_9455);
		method_10512(Tags.Biomes.IS_SNOWY_PLAINS).method_46835(class_1972.field_35117);
		method_10512(Tags.Biomes.IS_TAIGA).method_26792(class_6908.field_36515);
		method_10512(Tags.Biomes.IS_HILL).method_26792(class_6908.field_36514);
		method_10512(Tags.Biomes.IS_WINDSWEPT).method_46835(class_1972.field_35116).method_46835(class_1972.field_35111).method_46835(class_1972.field_35120).method_46835(class_1972.field_35114);
		method_10512(Tags.Biomes.IS_SAVANNA).method_26792(class_6908.field_37392);
		method_10512(Tags.Biomes.IS_JUNGLE).method_26792(class_6908.field_36516);
		method_10512(Tags.Biomes.IS_SNOWY).method_46835(class_1972.field_9478).method_46835(class_1972.field_35117).method_46835(class_1972.field_9453).method_46835(class_1972.field_9454).method_46835(class_1972.field_34471).method_46835(class_1972.field_34472).method_46835(class_1972.field_34474).method_46835(class_1972.field_35115);
		method_10512(Tags.Biomes.IS_ICY).method_46835(class_1972.field_9453).method_46835(class_1972.field_35115);
		method_10512(Tags.Biomes.IS_SWAMP).method_46835(class_1972.field_9471).method_46835(class_1972.field_38748);
		method_10512(Tags.Biomes.IS_OLD_GROWTH).method_46835(class_1972.field_35112).method_46835(class_1972.field_35119).method_46835(class_1972.field_35113);
		method_10512(Tags.Biomes.IS_LUSH).method_46835(class_1972.field_29218);
		method_10512(Tags.Biomes.IS_SANDY).method_46835(class_1972.field_9424).method_46835(class_1972.field_9415).method_46835(class_1972.field_35110).method_46835(class_1972.field_9443).method_46835(class_1972.field_9434);
		method_10512(Tags.Biomes.IS_MUSHROOM).method_46835(class_1972.field_9462);
		method_10512(Tags.Biomes.IS_PLATEAU).method_46835(class_1972.field_35110).method_46835(class_1972.field_9430).method_46835(class_1972.field_42720).method_46835(class_1972.field_34470);
		method_10512(Tags.Biomes.IS_SPOOKY).method_46835(class_1972.field_9475).method_46835(class_1972.field_37543);
		method_10512(Tags.Biomes.IS_WASTELAND);
		method_10512(Tags.Biomes.IS_RARE).method_46835(class_1972.field_9455).method_46835(class_1972.field_9414).method_46835(class_1972.field_35112).method_46835(class_1972.field_35113).method_46835(class_1972.field_9440).method_46835(class_1972.field_35118).method_46835(class_1972.field_9443).method_46835(class_1972.field_9430).method_46835(class_1972.field_35114).method_46835(class_1972.field_9453).method_46835(class_1972.field_35111).method_46835(class_1972.field_9462).method_46835(class_1972.field_37543);

		method_10512(Tags.Biomes.IS_RIVER).method_26792(class_6908.field_36511);
		method_10512(Tags.Biomes.IS_SHALLOW_OCEAN).method_46835(class_1972.field_9423).method_46835(class_1972.field_9441).method_46835(class_1972.field_9408).method_46835(class_1972.field_9467).method_46835(class_1972.field_9435);
		method_10512(Tags.Biomes.IS_DEEP_OCEAN).method_26792(class_6908.field_36508);
		method_10512(Tags.Biomes.IS_OCEAN).method_26792(class_6908.field_36509).method_26792(Tags.Biomes.IS_SHALLOW_OCEAN).method_26792(Tags.Biomes.IS_DEEP_OCEAN);
		method_10512(Tags.Biomes.IS_AQUATIC_ICY).method_46835(class_1972.field_9463).method_46835(class_1972.field_9418).method_46835(class_1972.field_9435);
		method_10512(Tags.Biomes.IS_AQUATIC).method_26792(Tags.Biomes.IS_OCEAN).method_26792(Tags.Biomes.IS_RIVER);

		method_10512(Tags.Biomes.IS_CAVE).method_46835(class_1972.field_29218).method_46835(class_1972.field_28107).method_46835(class_1972.field_37543);
		method_10512(Tags.Biomes.IS_UNDERGROUND).method_26792(Tags.Biomes.IS_CAVE);

		method_10512(Tags.Biomes.IS_NETHER_FOREST).method_46835(class_1972.field_22077).method_46835(class_1972.field_22075);
		method_10512(Tags.Biomes.IS_OUTER_END_ISLAND).method_46835(class_1972.field_9442).method_46835(class_1972.field_9447).method_46835(class_1972.field_9465);

		// Backwards compat with pre-1.21 tags. Done after so optional tag is last for better readability.
		// TODO: Remove backwards compat tag entries in 1.22
		method_10512(Tags.Biomes.IS_MOUNTAIN_SLOPE).method_35923(class_2960.method_60655("forge", "is_slope"));
		method_10512(Tags.Biomes.IS_MOUNTAIN_PEAK).method_35923(class_2960.method_60655("forge", "is_peak"));
		tagWithOptionalLegacy(Tags.Biomes.IS_MOUNTAIN);
		tagWithOptionalLegacy(Tags.Biomes.IS_HOT_OVERWORLD);
		tagWithOptionalLegacy(Tags.Biomes.IS_HOT_NETHER);
		tagWithOptionalLegacy(Tags.Biomes.IS_HOT_END);
		tagWithOptionalLegacy(Tags.Biomes.IS_HOT);
		tagWithOptionalLegacy(Tags.Biomes.IS_COLD_OVERWORLD);
		tagWithOptionalLegacy(Tags.Biomes.IS_COLD_NETHER);
		tagWithOptionalLegacy(Tags.Biomes.IS_COLD_END);
		tagWithOptionalLegacy(Tags.Biomes.IS_COLD);
		tagWithOptionalLegacy(Tags.Biomes.IS_SPARSE_VEGETATION_OVERWORLD);
		tagWithOptionalLegacy(Tags.Biomes.IS_SPARSE_VEGETATION_NETHER);
		tagWithOptionalLegacy(Tags.Biomes.IS_SPARSE_VEGETATION_END);
		tagWithOptionalLegacy(Tags.Biomes.IS_SPARSE_VEGETATION);
		method_10512(Tags.Biomes.IS_SPARSE_VEGETATION_OVERWORLD).method_35923(class_2960.method_60655("forge", "is_sparse/overworld"));
		method_10512(Tags.Biomes.IS_SPARSE_VEGETATION_NETHER).method_35923(class_2960.method_60655("forge", "is_sparse/nether"));
		method_10512(Tags.Biomes.IS_SPARSE_VEGETATION_END).method_35923(class_2960.method_60655("forge", "is_sparse/end"));
		method_10512(Tags.Biomes.IS_SPARSE_VEGETATION).method_35923(class_2960.method_60655("forge", "is_sparse"));
		method_10512(Tags.Biomes.IS_DENSE_VEGETATION_OVERWORLD).method_35923(class_2960.method_60655("forge", "is_dense/overworld"));
		method_10512(Tags.Biomes.IS_DENSE_VEGETATION_NETHER).method_35923(class_2960.method_60655("forge", "is_dense/nether"));
		method_10512(Tags.Biomes.IS_DENSE_VEGETATION_END).method_35923(class_2960.method_60655("forge", "is_dense/end"));
		method_10512(Tags.Biomes.IS_DENSE_VEGETATION).method_35923(class_2960.method_60655("forge", "is_dense"));
		tagWithOptionalLegacy(Tags.Biomes.IS_WET_OVERWORLD);
		tagWithOptionalLegacy(Tags.Biomes.IS_WET_NETHER);
		tagWithOptionalLegacy(Tags.Biomes.IS_WET_END);
		tagWithOptionalLegacy(Tags.Biomes.IS_WET);
		tagWithOptionalLegacy(Tags.Biomes.IS_DRY_OVERWORLD);
		tagWithOptionalLegacy(Tags.Biomes.IS_DRY_NETHER);
		tagWithOptionalLegacy(Tags.Biomes.IS_DRY_END);
		tagWithOptionalLegacy(Tags.Biomes.IS_DRY);
		tagWithOptionalLegacy(Tags.Biomes.IS_CONIFEROUS_TREE);
		tagWithOptionalLegacy(Tags.Biomes.IS_SPOOKY);
		tagWithOptionalLegacy(Tags.Biomes.IS_DEAD);
		tagWithOptionalLegacy(Tags.Biomes.IS_LUSH);
		tagWithOptionalLegacy(Tags.Biomes.IS_MUSHROOM);
		tagWithOptionalLegacy(Tags.Biomes.IS_MAGICAL);
		tagWithOptionalLegacy(Tags.Biomes.IS_RARE);
		tagWithOptionalLegacy(Tags.Biomes.IS_PLATEAU);
		tagWithOptionalLegacy(Tags.Biomes.IS_MODIFIED);
		tagWithOptionalLegacy(Tags.Biomes.IS_FLORAL);
		method_10512(Tags.Biomes.IS_AQUATIC).method_35923(class_2960.method_60655("forge", "is_water"));
		tagWithOptionalLegacy(Tags.Biomes.IS_DESERT);
		tagWithOptionalLegacy(Tags.Biomes.IS_PLAINS);
		tagWithOptionalLegacy(Tags.Biomes.IS_SWAMP);
		tagWithOptionalLegacy(Tags.Biomes.IS_SANDY);
		tagWithOptionalLegacy(Tags.Biomes.IS_SNOWY);
		tagWithOptionalLegacy(Tags.Biomes.IS_WASTELAND);
		tagWithOptionalLegacy(Tags.Biomes.IS_VOID);
		tagWithOptionalLegacy(Tags.Biomes.IS_CAVE);
		tagWithOptionalLegacy(Tags.Biomes.IS_END);
		tagWithOptionalLegacy(Tags.Biomes.IS_NETHER);
		tagWithOptionalLegacy(Tags.Biomes.IS_OVERWORLD);
	}

	@SafeVarargs
	private void tag(class_5321<class_1959> biome, class_6862<class_1959>... tags) {
		for (class_6862<class_1959> key : tags) {
			method_10512(key).method_46835(biome);
		}
	}

	private class_5124<class_1959> tagWithOptionalLegacy(class_6862<class_1959> tag) {
		return method_10512(tag).method_35923(class_2960.method_60655("forge", tag.comp_327().method_12832()));
	}

	@Override
	public String method_10321() {
		return "PortingLib Biome Tags";
	}
}
