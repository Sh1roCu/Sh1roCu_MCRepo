package io.github.fabricators_of_create.porting_lib.tags.data;

import java.util.concurrent.CompletableFuture;

import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1299;
import net.minecraft.class_7225;

public class EntityTagProvider extends FabricTagProvider.EntityTypeTagProvider {
	public EntityTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
		super(output, registriesFuture);
	}

	@Override
	protected void method_10514(class_7225.class_7874 arg) {
		getOrCreateTagBuilder(Tags.EntityTypes.BOSSES).add(class_1299.field_6116, class_1299.field_6119);
	}
}
