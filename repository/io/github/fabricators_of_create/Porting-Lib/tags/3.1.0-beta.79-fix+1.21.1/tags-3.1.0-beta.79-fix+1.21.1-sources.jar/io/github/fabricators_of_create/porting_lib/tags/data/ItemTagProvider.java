package io.github.fabricators_of_create.porting_lib.tags.data;

import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7923;

public final class ItemTagProvider extends FabricTagProvider.ItemTagProvider {
	public ItemTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> lookupProvider, FabricTagProvider.BlockTagProvider blockTagProvider) {
		super(output, lookupProvider, blockTagProvider);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void method_10514(class_7225.class_7874 lookupProvider) {
		copy(Tags.Blocks.BARRELS, Tags.Items.BARRELS);
		copy(Tags.Blocks.BARRELS_WOODEN, Tags.Items.BARRELS_WOODEN);
		method_10512(Tags.Items.BONES).add(class_1802.field_8606);
		copy(Tags.Blocks.BOOKSHELVES, Tags.Items.BOOKSHELVES);
		method_10512(Tags.Items.BRICKS).method_26792(Tags.Items.BRICKS_NORMAL).method_26792(Tags.Items.BRICKS_NETHER);
		method_10512(Tags.Items.BRICKS_NORMAL).add(class_1802.field_8621);
		method_10512(Tags.Items.BRICKS_NETHER).add(class_1802.field_8729);
		method_10512(Tags.Items.BUCKETS_EMPTY).add(class_1802.field_8550);
		method_10512(Tags.Items.BUCKETS_WATER).add(class_1802.field_8705);
		method_10512(Tags.Items.BUCKETS_LAVA).add(class_1802.field_8187);
		method_10512(Tags.Items.BUCKETS_MILK).add(class_1802.field_8103);
		method_10512(Tags.Items.BUCKETS_POWDER_SNOW).add(class_1802.field_27876);
		method_10512(Tags.Items.BUCKETS_ENTITY_WATER).add(class_1802.field_28354, class_1802.field_8666, class_1802.field_8108, class_1802.field_37533, class_1802.field_8478, class_1802.field_8714);
		method_10512(Tags.Items.BUCKETS).method_26792(Tags.Items.BUCKETS_EMPTY).method_26792(Tags.Items.BUCKETS_WATER).method_26792(Tags.Items.BUCKETS_LAVA).method_26792(Tags.Items.BUCKETS_MILK).method_26792(Tags.Items.BUCKETS_POWDER_SNOW).method_26792(Tags.Items.BUCKETS_ENTITY_WATER);
		copy(Tags.Blocks.BUDDING_BLOCKS, Tags.Items.BUDDING_BLOCKS);
		copy(Tags.Blocks.BUDS, Tags.Items.BUDS);
		copy(Tags.Blocks.CHAINS, Tags.Items.CHAINS);
		copy(Tags.Blocks.CHESTS, Tags.Items.CHESTS);
		copy(Tags.Blocks.CHESTS_ENDER, Tags.Items.CHESTS_ENDER);
		copy(Tags.Blocks.CHESTS_TRAPPED, Tags.Items.CHESTS_TRAPPED);
		copy(Tags.Blocks.CHESTS_WOODEN, Tags.Items.CHESTS_WOODEN);
		copy(Tags.Blocks.CLUSTERS, Tags.Items.CLUSTERS);
		copy(Tags.Blocks.COBBLESTONES, Tags.Items.COBBLESTONES);
		copy(Tags.Blocks.COBBLESTONES_NORMAL, Tags.Items.COBBLESTONES_NORMAL);
		copy(Tags.Blocks.COBBLESTONES_INFESTED, Tags.Items.COBBLESTONES_INFESTED);
		copy(Tags.Blocks.COBBLESTONES_MOSSY, Tags.Items.COBBLESTONES_MOSSY);
		copy(Tags.Blocks.COBBLESTONES_DEEPSLATE, Tags.Items.COBBLESTONES_DEEPSLATE);
		copy(Tags.Blocks.CONCRETES, Tags.Items.CONCRETES);
		method_10512(Tags.Items.CONCRETE_POWDERS)
				.add(class_1802.field_8582).add(class_1802.field_8487).add(class_1802.field_8336)
				.add(class_1802.field_8764).add(class_1802.field_8205).add(class_1802.field_8418)
				.add(class_1802.field_8222).add(class_1802.field_8818).add(class_1802.field_8558)
				.add(class_1802.field_8593).add(class_1802.field_8690).add(class_1802.field_8164)
				.add(class_1802.field_8437).add(class_1802.field_8198).add(class_1802.field_8757)
				.add(class_1802.field_8516);
		method_10512(Tags.Items.CROPS).method_26792(Tags.Items.CROPS_BEETROOT).method_26792(Tags.Items.CROPS_CARROT).method_26792(Tags.Items.CROPS_NETHER_WART).method_26792(Tags.Items.CROPS_POTATO).method_26792(Tags.Items.CROPS_WHEAT);
		method_10512(Tags.Items.CROPS_BEETROOT).add(class_1802.field_8186);
		method_10512(Tags.Items.CROPS_CARROT).add(class_1802.field_8179);
		method_10512(Tags.Items.CROPS_NETHER_WART).add(class_1802.field_8790);
		method_10512(Tags.Items.CROPS_POTATO).add(class_1802.field_8567);
		method_10512(Tags.Items.CROPS_WHEAT).add(class_1802.field_8861);
		addColored(Tags.Items.DYED, "{color}_banner");
		addColored(Tags.Items.DYED, "{color}_bed");
		addColored(Tags.Items.DYED, "{color}_candle");
		addColored(Tags.Items.DYED, "{color}_carpet");
		addColored(Tags.Items.DYED, "{color}_concrete");
		addColored(Tags.Items.DYED, "{color}_concrete_powder");
		addColored(Tags.Items.DYED, "{color}_glazed_terracotta");
		addColored(Tags.Items.DYED, "{color}_shulker_box");
		addColored(Tags.Items.DYED, "{color}_stained_glass");
		addColored(Tags.Items.DYED, "{color}_stained_glass_pane");
		addColored(Tags.Items.DYED, "{color}_terracotta");
		addColored(Tags.Items.DYED, "{color}_wool");
		addColoredTags(method_10512(Tags.Items.DYED)::method_26792, Tags.Items.DYED);
		method_10512(Tags.Items.DUSTS).method_26792(Tags.Items.DUSTS_GLOWSTONE).method_26792(Tags.Items.DUSTS_REDSTONE);
		method_10512(Tags.Items.DUSTS_GLOWSTONE).add(class_1802.field_8601);
		method_10512(Tags.Items.DUSTS_REDSTONE).add(class_1802.field_8725);
		addColored(Tags.Items.DYES, "{color}_dye");
		addColoredTags(method_10512(Tags.Items.DYES)::method_26792, Tags.Items.DYES);
		method_10512(Tags.Items.EGGS).add(class_1802.field_8803);
		method_10512(Tags.Items.ENCHANTING_FUELS).method_26792(Tags.Items.GEMS_LAPIS);
		copy(Tags.Blocks.END_STONES, Tags.Items.END_STONES);
		method_10512(Tags.Items.ENDER_PEARLS).add(class_1802.field_8634);
		method_10512(Tags.Items.FEATHERS).add(class_1802.field_8153);
		copy(Tags.Blocks.FENCE_GATES, Tags.Items.FENCE_GATES);
		copy(Tags.Blocks.FENCE_GATES_WOODEN, Tags.Items.FENCE_GATES_WOODEN);
		copy(Tags.Blocks.FENCES, Tags.Items.FENCES);
		copy(Tags.Blocks.FENCES_NETHER_BRICK, Tags.Items.FENCES_NETHER_BRICK);
		copy(Tags.Blocks.FENCES_WOODEN, Tags.Items.FENCES_WOODEN);
		method_10512(Tags.Items.FOODS_FRUITS).add(class_1802.field_8279, class_1802.field_8463, class_1802.field_8367);
		method_10512(Tags.Items.FOODS_VEGETABLES).add(class_1802.field_8179, class_1802.field_8071, class_1802.field_8567, class_1802.field_8497, class_1802.field_8186);
		method_10512(Tags.Items.FOODS_BERRIES).add(class_1802.field_16998, class_1802.field_28659);
		method_10512(Tags.Items.FOODS_BREADS).add(class_1802.field_8229);
		method_10512(Tags.Items.FOODS_COOKIES).add(class_1802.field_8423);
		method_10512(Tags.Items.FOODS_RAW_MEATS).add(class_1802.field_8046, class_1802.field_8389, class_1802.field_8726, class_1802.field_8504, class_1802.field_8748);
		method_10512(Tags.Items.FOODS_RAW_FISHES).add(class_1802.field_8429, class_1802.field_8209, class_1802.field_8846, class_1802.field_8323);
		method_10512(Tags.Items.FOODS_COOKED_MEATS).add(class_1802.field_8176, class_1802.field_8261, class_1802.field_8544, class_1802.field_8752, class_1802.field_8347);
		method_10512(Tags.Items.FOODS_COOKED_FISHES).add(class_1802.field_8373, class_1802.field_8509);
		method_10512(Tags.Items.FOODS_SOUPS).add(class_1802.field_8515, class_1802.field_8208, class_1802.field_8308, class_1802.field_8766);
		method_10512(Tags.Items.FOODS_CANDIES);
		method_10512(Tags.Items.FOODS_EDIBLE_WHEN_PLACED).add(class_1802.field_17534);
		method_10512(Tags.Items.FOODS_FOOD_POISONING).add(class_1802.field_8635, class_1802.field_8323, class_1802.field_8680, class_1802.field_8726, class_1802.field_8511);
		method_10512(Tags.Items.FOODS)
				.add(class_1802.field_8512, class_1802.field_8741, class_1802.field_20417, class_1802.field_50140, class_1802.field_8551)
				.method_26792(Tags.Items.FOODS_FRUITS).method_26792(Tags.Items.FOODS_VEGETABLES).method_26792(Tags.Items.FOODS_BERRIES).method_26792(Tags.Items.FOODS_BREADS).method_26792(Tags.Items.FOODS_COOKIES)
						.method_26792(Tags.Items.FOODS_RAW_MEATS).method_26792(Tags.Items.FOODS_RAW_FISHES).method_26792(Tags.Items.FOODS_COOKED_MEATS).method_26792(Tags.Items.FOODS_COOKED_FISHES)
						.method_26792(Tags.Items.FOODS_SOUPS).method_26792(Tags.Items.FOODS_CANDIES)
						.method_26792(Tags.Items.FOODS_EDIBLE_WHEN_PLACED).method_26792(Tags.Items.FOODS_FOOD_POISONING);
		method_10512(Tags.Items.GEMS).method_26792(Tags.Items.GEMS_AMETHYST).method_26792(Tags.Items.GEMS_DIAMOND).method_26792(Tags.Items.GEMS_EMERALD).method_26792(Tags.Items.GEMS_LAPIS).method_26792(Tags.Items.GEMS_PRISMARINE).method_26792(Tags.Items.GEMS_QUARTZ);
		method_10512(Tags.Items.GEMS_AMETHYST).add(class_1802.field_27063);
		method_10512(Tags.Items.GEMS_DIAMOND).add(class_1802.field_8477);
		method_10512(Tags.Items.GEMS_EMERALD).add(class_1802.field_8687);
		method_10512(Tags.Items.GEMS_LAPIS).add(class_1802.field_8759);
		method_10512(Tags.Items.GEMS_PRISMARINE).add(class_1802.field_8434);
		method_10512(Tags.Items.GEMS_QUARTZ).add(class_1802.field_8155);
		copy(Tags.Blocks.GLASS_BLOCKS, Tags.Items.GLASS_BLOCKS);
		copy(Tags.Blocks.GLASS_BLOCKS_COLORLESS, Tags.Items.GLASS_BLOCKS_COLORLESS);
		copy(Tags.Blocks.GLASS_BLOCKS_TINTED, Tags.Items.GLASS_BLOCKS_TINTED);
		copy(Tags.Blocks.GLASS_BLOCKS_CHEAP, Tags.Items.GLASS_BLOCKS_CHEAP);
		copy(Tags.Blocks.GLASS_PANES, Tags.Items.GLASS_PANES);
		copy(Tags.Blocks.GLASS_PANES_COLORLESS, Tags.Items.GLASS_PANES_COLORLESS);
		copy(Tags.Blocks.GLAZED_TERRACOTTAS, Tags.Items.GLAZED_TERRACOTTAS);
		copy(Tags.Blocks.GRAVELS, Tags.Items.GRAVELS);
		method_10512(Tags.Items.GUNPOWDERS).add(class_1802.field_8054);
		method_10512(Tags.Items.HIDDEN_FROM_RECIPE_VIEWERS);
		method_10512(Tags.Items.INGOTS).method_26792(Tags.Items.INGOTS_COPPER).method_26792(Tags.Items.INGOTS_GOLD).method_26792(Tags.Items.INGOTS_IRON).method_26792(Tags.Items.INGOTS_NETHERITE);
		method_10512(Tags.Items.INGOTS_COPPER).add(class_1802.field_27022);
		method_10512(Tags.Items.INGOTS_GOLD).add(class_1802.field_8695);
		method_10512(Tags.Items.INGOTS_IRON).add(class_1802.field_8620);
		method_10512(Tags.Items.INGOTS_NETHERITE).add(class_1802.field_22020);
		method_10512(Tags.Items.LEATHERS).add(class_1802.field_8745);
		method_10512(Tags.Items.MUSHROOMS).add(class_1802.field_17516, class_1802.field_17517);
		method_10512(Tags.Items.MUSIC_DISCS).add(class_1802.field_8144, class_1802.field_8075, class_1802.field_8425, class_1802.field_8623,
				class_1802.field_8502, class_1802.field_8534, class_1802.field_8344, class_1802.field_8834, class_1802.field_8065,
				class_1802.field_8355, class_1802.field_8731, class_1802.field_8806, class_1802.field_35358, class_1802.field_38973,
				class_1802.field_23984, class_1802.field_44705, class_1802.field_51628, class_1802.field_51629,
				class_1802.field_51630);
		method_10512(Tags.Items.NETHER_STARS).add(class_1802.field_8137);
		copy(Tags.Blocks.NETHERRACKS, Tags.Items.NETHERRACKS);
		method_10512(Tags.Items.NUGGETS).method_26792(Tags.Items.NUGGETS_GOLD).method_26792(Tags.Items.NUGGETS_IRON);
		method_10512(Tags.Items.NUGGETS_IRON).add(class_1802.field_8675);
		method_10512(Tags.Items.NUGGETS_GOLD).add(class_1802.field_8397);
		copy(Tags.Blocks.OBSIDIANS, Tags.Items.OBSIDIANS);
		copy(Tags.Blocks.ORE_BEARING_GROUND_DEEPSLATE, Tags.Items.ORE_BEARING_GROUND_DEEPSLATE);
		copy(Tags.Blocks.ORE_BEARING_GROUND_NETHERRACK, Tags.Items.ORE_BEARING_GROUND_NETHERRACK);
		copy(Tags.Blocks.ORE_BEARING_GROUND_STONE, Tags.Items.ORE_BEARING_GROUND_STONE);
		copy(Tags.Blocks.ORE_RATES_DENSE, Tags.Items.ORE_RATES_DENSE);
		copy(Tags.Blocks.ORE_RATES_SINGULAR, Tags.Items.ORE_RATES_SINGULAR);
		copy(Tags.Blocks.ORE_RATES_SPARSE, Tags.Items.ORE_RATES_SPARSE);
		copy(Tags.Blocks.ORES, Tags.Items.ORES);
		copy(Tags.Blocks.ORES_COAL, Tags.Items.ORES_COAL);
		copy(Tags.Blocks.ORES_COPPER, Tags.Items.ORES_COPPER);
		copy(Tags.Blocks.ORES_DIAMOND, Tags.Items.ORES_DIAMOND);
		copy(Tags.Blocks.ORES_EMERALD, Tags.Items.ORES_EMERALD);
		copy(Tags.Blocks.ORES_GOLD, Tags.Items.ORES_GOLD);
		copy(Tags.Blocks.ORES_IRON, Tags.Items.ORES_IRON);
		copy(Tags.Blocks.ORES_LAPIS, Tags.Items.ORES_LAPIS);
		copy(Tags.Blocks.ORES_QUARTZ, Tags.Items.ORES_QUARTZ);
		copy(Tags.Blocks.ORES_REDSTONE, Tags.Items.ORES_REDSTONE);
		copy(Tags.Blocks.ORES_NETHERITE_SCRAP, Tags.Items.ORES_NETHERITE_SCRAP);
		copy(Tags.Blocks.ORES_IN_GROUND_DEEPSLATE, Tags.Items.ORES_IN_GROUND_DEEPSLATE);
		copy(Tags.Blocks.ORES_IN_GROUND_NETHERRACK, Tags.Items.ORES_IN_GROUND_NETHERRACK);
		copy(Tags.Blocks.ORES_IN_GROUND_STONE, Tags.Items.ORES_IN_GROUND_STONE);
		copy(Tags.Blocks.PLAYER_WORKSTATIONS_CRAFTING_TABLES, Tags.Items.PLAYER_WORKSTATIONS_CRAFTING_TABLES);
		copy(Tags.Blocks.PLAYER_WORKSTATIONS_FURNACES, Tags.Items.PLAYER_WORKSTATIONS_FURNACES);
		method_10512(Tags.Items.RAW_MATERIALS).method_26792(Tags.Items.RAW_MATERIALS_COPPER).method_26792(Tags.Items.RAW_MATERIALS_GOLD).method_26792(Tags.Items.RAW_MATERIALS_IRON);
		method_10512(Tags.Items.RAW_MATERIALS_COPPER).add(class_1802.field_33401);
		method_10512(Tags.Items.RAW_MATERIALS_GOLD).add(class_1802.field_33402);
		method_10512(Tags.Items.RAW_MATERIALS_IRON).add(class_1802.field_33400);
		method_10512(Tags.Items.RODS).method_26792(Tags.Items.RODS_WOODEN).method_26792(Tags.Items.RODS_BLAZE).method_26792(Tags.Items.RODS_BREEZE);
		method_10512(Tags.Items.RODS_BLAZE).add(class_1802.field_8894);
		method_10512(Tags.Items.RODS_BREEZE).add(class_1802.field_49821);
		method_10512(Tags.Items.RODS_WOODEN).add(class_1802.field_8600);
		copy(Tags.Blocks.ROPES, Tags.Items.ROPES);
		copy(Tags.Blocks.SANDS, Tags.Items.SANDS);
		copy(Tags.Blocks.SANDS_COLORLESS, Tags.Items.SANDS_COLORLESS);
		copy(Tags.Blocks.SANDS_RED, Tags.Items.SANDS_RED);
		copy(Tags.Blocks.SANDSTONE_BLOCKS, Tags.Items.SANDSTONE_BLOCKS);
		copy(Tags.Blocks.SANDSTONE_SLABS, Tags.Items.SANDSTONE_SLABS);
		copy(Tags.Blocks.SANDSTONE_STAIRS, Tags.Items.SANDSTONE_STAIRS);
		copy(Tags.Blocks.SANDSTONE_RED_BLOCKS, Tags.Items.SANDSTONE_RED_BLOCKS);
		copy(Tags.Blocks.SANDSTONE_RED_SLABS, Tags.Items.SANDSTONE_RED_SLABS);
		copy(Tags.Blocks.SANDSTONE_RED_STAIRS, Tags.Items.SANDSTONE_RED_STAIRS);
		copy(Tags.Blocks.SANDSTONE_UNCOLORED_BLOCKS, Tags.Items.SANDSTONE_UNCOLORED_BLOCKS);
		copy(Tags.Blocks.SANDSTONE_UNCOLORED_SLABS, Tags.Items.SANDSTONE_UNCOLORED_SLABS);
		copy(Tags.Blocks.SANDSTONE_UNCOLORED_STAIRS, Tags.Items.SANDSTONE_UNCOLORED_STAIRS);
		method_10512(Tags.Items.SEEDS).method_26792(Tags.Items.SEEDS_BEETROOT).method_26792(Tags.Items.SEEDS_MELON).method_26792(Tags.Items.SEEDS_PUMPKIN).method_26792(Tags.Items.SEEDS_WHEAT);
		method_10512(Tags.Items.SEEDS_BEETROOT).add(class_1802.field_8309);
		method_10512(Tags.Items.SEEDS_MELON).add(class_1802.field_46250);
		method_10512(Tags.Items.SEEDS_PUMPKIN).add(class_1802.field_46249);
		method_10512(Tags.Items.SEEDS_WHEAT).add(class_1802.field_8317);
		method_10512(Tags.Items.SLIMEBALLS).add(class_1802.field_8777);
		method_10512(Tags.Items.SHULKER_BOXES)
				.add(class_1802.field_8545).add(class_1802.field_8722).add(class_1802.field_8380)
				.add(class_1802.field_8050).add(class_1802.field_8829).add(class_1802.field_8271)
				.add(class_1802.field_8548).add(class_1802.field_8520).add(class_1802.field_8627)
				.add(class_1802.field_8451).add(class_1802.field_8213).add(class_1802.field_8816)
				.add(class_1802.field_8350).add(class_1802.field_8584).add(class_1802.field_8461)
				.add(class_1802.field_8676).add(class_1802.field_8268);
		copy(Tags.Blocks.STONES, Tags.Items.STONES);
		copy(Tags.Blocks.STORAGE_BLOCKS, Tags.Items.STORAGE_BLOCKS);
		copy(Tags.Blocks.STORAGE_BLOCKS_BONE_MEAL, Tags.Items.STORAGE_BLOCKS_BONE_MEAL);
		copy(Tags.Blocks.STORAGE_BLOCKS_COAL, Tags.Items.STORAGE_BLOCKS_COAL);
		copy(Tags.Blocks.STORAGE_BLOCKS_COPPER, Tags.Items.STORAGE_BLOCKS_COPPER);
		copy(Tags.Blocks.STORAGE_BLOCKS_DIAMOND, Tags.Items.STORAGE_BLOCKS_DIAMOND);
		copy(Tags.Blocks.STORAGE_BLOCKS_DRIED_KELP, Tags.Items.STORAGE_BLOCKS_DRIED_KELP);
		copy(Tags.Blocks.STORAGE_BLOCKS_EMERALD, Tags.Items.STORAGE_BLOCKS_EMERALD);
		copy(Tags.Blocks.STORAGE_BLOCKS_GOLD, Tags.Items.STORAGE_BLOCKS_GOLD);
		copy(Tags.Blocks.STORAGE_BLOCKS_IRON, Tags.Items.STORAGE_BLOCKS_IRON);
		copy(Tags.Blocks.STORAGE_BLOCKS_LAPIS, Tags.Items.STORAGE_BLOCKS_LAPIS);
		copy(Tags.Blocks.STORAGE_BLOCKS_NETHERITE, Tags.Items.STORAGE_BLOCKS_NETHERITE);
		copy(Tags.Blocks.STORAGE_BLOCKS_RAW_COPPER, Tags.Items.STORAGE_BLOCKS_RAW_COPPER);
		copy(Tags.Blocks.STORAGE_BLOCKS_RAW_GOLD, Tags.Items.STORAGE_BLOCKS_RAW_GOLD);
		copy(Tags.Blocks.STORAGE_BLOCKS_RAW_IRON, Tags.Items.STORAGE_BLOCKS_RAW_IRON);
		copy(Tags.Blocks.STORAGE_BLOCKS_REDSTONE, Tags.Items.STORAGE_BLOCKS_REDSTONE);
		copy(Tags.Blocks.STORAGE_BLOCKS_SLIME, Tags.Items.STORAGE_BLOCKS_SLIME);
		copy(Tags.Blocks.STORAGE_BLOCKS_WHEAT, Tags.Items.STORAGE_BLOCKS_WHEAT);
		method_10512(Tags.Items.STRINGS).add(class_1802.field_8276);
		method_10512(Tags.Items.VILLAGER_JOB_SITES).add(
				class_1802.field_16307, class_1802.field_16306, class_1802.field_8740, class_1802.field_16313,
				class_1802.field_8638, class_1802.field_17530, class_1802.field_16310, class_1802.field_16311,
				class_1802.field_16312, class_1802.field_8772, class_1802.field_16308, class_1802.field_16309, class_1802.field_16305);

		// Tools and Armors
		method_10512(Tags.Items.TOOLS_SHIELD).add(class_1802.field_8255);
		method_10512(Tags.Items.TOOLS_BOW).add(class_1802.field_8102);
		method_10512(Tags.Items.TOOLS_BRUSH).add(class_1802.field_42716);
		method_10512(Tags.Items.TOOLS_CROSSBOW).add(class_1802.field_8399);
		method_10512(Tags.Items.TOOLS_FISHING_ROD).add(class_1802.field_8378);
		method_10512(Tags.Items.TOOLS_SHEAR).add(class_1802.field_8868);
		method_10512(Tags.Items.TOOLS_SPEAR).add(class_1802.field_8547);
		method_10512(Tags.Items.TOOLS)
				.method_26792(class_3489.field_42612).method_26792(class_3489.field_42613).method_26792(class_3489.field_42614).method_26792(class_3489.field_42615).method_26792(class_3489.field_42611)
				.method_26792(Tags.Items.TOOLS_BOW).method_26792(Tags.Items.TOOLS_BRUSH).method_26792(Tags.Items.TOOLS_CROSSBOW).method_26792(Tags.Items.TOOLS_FISHING_ROD).method_26792(Tags.Items.TOOLS_SHEAR).method_26792(Tags.Items.TOOLS_SHIELD).method_26792(Tags.Items.TOOLS_SPEAR);
		method_10512(Tags.Items.ARMORS).method_26792(class_3489.field_48297).method_26792(class_3489.field_48296).method_26792(class_3489.field_48295).method_26792(class_3489.field_48294);
		method_10512(Tags.Items.ENCHANTABLES).method_26792(class_3489.field_48303).method_26792(class_3489.field_48312).method_26792(class_3489.field_48305).method_26792(class_3489.field_48304).method_26792(class_3489.field_48306).method_26792(class_3489.field_48307).method_26792(class_3489.field_48308).method_26792(class_3489.field_48309).method_26792(class_3489.field_48311).method_26792(class_3489.field_48313).method_26792(class_3489.field_50107).method_26792(class_3489.field_48310).addOptionalTag(class_3489.field_50109);

		// Backwards compat with pre-1.21 tags. Done after so optional tag is last for better readability.
		// TODO: Remove backwards compat tag entries in 1.22
//		tagWithOptionalLegacy(Tags.Items.BONES);
		method_10512(Tags.Items.BRICKS_NORMAL).method_35923(class_2960.method_60655("forge", "ingots/brick"));
		method_10512(Tags.Items.BRICKS_NETHER).method_35923(class_2960.method_60655("forge", "ingots/nether_brick"));
//		tagWithOptionalLegacy(Tags.Items.CROPS);
//		tagWithOptionalLegacy(Tags.Items.CROPS_BEETROOT);
//		tagWithOptionalLegacy(Tags.Items.CROPS_CARROT);
//		tagWithOptionalLegacy(Tags.Items.CROPS_NETHER_WART);
//		tagWithOptionalLegacy(Tags.Items.CROPS_POTATO);
//		tagWithOptionalLegacy(Tags.Items.CROPS_WHEAT);
//		tagWithOptionalLegacy(Tags.Items.DUSTS);
//		tagWithOptionalLegacy(Tags.Items.DUSTS_GLOWSTONE);
//		tagWithOptionalLegacy(Tags.Items.DUSTS_REDSTONE);
//		tagColoredWithOptionalLegacy(Tags.Items.DYES);
		method_10512(Tags.Items.DYED_BLACK)
				.method_35923(class_2960.method_60655("forge", "glass/black"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/black"));
		method_10512(Tags.Items.DYED_BLUE)
				.method_35923(class_2960.method_60655("forge", "glass/blue"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/blue"));
		method_10512(Tags.Items.DYED_BROWN)
				.method_35923(class_2960.method_60655("forge", "glass/brown"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/brown"));
		method_10512(Tags.Items.DYED_CYAN)
				.method_35923(class_2960.method_60655("forge", "glass/cyan"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/cyan"));
		method_10512(Tags.Items.DYED_GRAY)
				.method_35923(class_2960.method_60655("forge", "glass/gray"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/gray"));
		method_10512(Tags.Items.DYED_GREEN)
				.method_35923(class_2960.method_60655("forge", "glass/green"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/green"));
		method_10512(Tags.Items.DYED_LIGHT_BLUE)
				.method_35923(class_2960.method_60655("forge", "glass/light_blue"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/light_blue"));
		method_10512(Tags.Items.DYED_LIGHT_GRAY)
				.method_35923(class_2960.method_60655("forge", "glass/light_gray"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/light_gray"));
		method_10512(Tags.Items.DYED_LIME)
				.method_35923(class_2960.method_60655("forge", "glass/lime"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/lime"));
		method_10512(Tags.Items.DYED_MAGENTA)
				.method_35923(class_2960.method_60655("forge", "glass/magenta"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/magenta"));
		method_10512(Tags.Items.DYED_MAGENTA)
				.method_35923(class_2960.method_60655("forge", "glass/magenta"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/magenta"));
		method_10512(Tags.Items.DYED_ORANGE)
				.method_35923(class_2960.method_60655("forge", "glass/orange"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/orange"));
		method_10512(Tags.Items.DYED_PINK)
				.method_35923(class_2960.method_60655("forge", "glass/pink"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/pink"));
		method_10512(Tags.Items.DYED_PURPLE)
				.method_35923(class_2960.method_60655("forge", "glass/purple"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/purple"));
		method_10512(Tags.Items.DYED_RED)
				.method_35923(class_2960.method_60655("forge", "glass/red"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/red"));
		method_10512(Tags.Items.DYED_WHITE)
				.method_35923(class_2960.method_60655("forge", "glass/white"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/white"));
		method_10512(Tags.Items.DYED_YELLOW)
				.method_35923(class_2960.method_60655("forge", "glass/yellow"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/yellow"));
//		tagWithOptionalLegacy(Tags.Items.ENDER_PEARLS);
//		tagWithOptionalLegacy(Tags.Items.FEATHERS);
//		tagWithOptionalLegacy(Tags.Items.GEMS);
//		tagWithOptionalLegacy(Tags.Items.GEMS_AMETHYST);
//		tagWithOptionalLegacy(Tags.Items.GEMS_DIAMOND);
//		tagWithOptionalLegacy(Tags.Items.GEMS_EMERALD);
//		tagWithOptionalLegacy(Tags.Items.GEMS_LAPIS);
//		tagWithOptionalLegacy(Tags.Items.GEMS_PRISMARINE);
//		tagWithOptionalLegacy(Tags.Items.GEMS_QUARTZ);
		method_10512(Tags.Items.GUNPOWDERS).method_35923(class_2960.method_60655("forge", "gunpowder"));
//		tagWithOptionalLegacy(Tags.Items.INGOTS);
//		tagWithOptionalLegacy(Tags.Items.INGOTS_COPPER);
//		tagWithOptionalLegacy(Tags.Items.INGOTS_GOLD);
//		tagWithOptionalLegacy(Tags.Items.INGOTS_IRON);
//		tagWithOptionalLegacy(Tags.Items.INGOTS_NETHERITE);
		method_10512(Tags.Items.LEATHERS).method_35923(class_2960.method_60655("forge", "leather"));
//		tagWithOptionalLegacy(Tags.Items.MUSHROOMS);
//		tagWithOptionalLegacy(Tags.Items.NETHER_STARS);
//		tagWithOptionalLegacy(Tags.Items.NUGGETS);
//		tagWithOptionalLegacy(Tags.Items.NUGGETS_IRON);
//		tagWithOptionalLegacy(Tags.Items.NUGGETS_GOLD);
//		tagWithOptionalLegacy(Tags.Items.RAW_MATERIALS);
//		tagWithOptionalLegacy(Tags.Items.RAW_MATERIALS_COPPER);
//		tagWithOptionalLegacy(Tags.Items.RAW_MATERIALS_GOLD);
//		tagWithOptionalLegacy(Tags.Items.RAW_MATERIALS_IRON);
//		tagWithOptionalLegacy(Tags.Items.RODS);
//		tagWithOptionalLegacy(Tags.Items.RODS_BLAZE);
//		tagWithOptionalLegacy(Tags.Items.RODS_WOODEN);
//		tagWithOptionalLegacy(Tags.Items.SEEDS);
//		tagWithOptionalLegacy(Tags.Items.SEEDS_BEETROOT);
//		tagWithOptionalLegacy(Tags.Items.SEEDS_MELON);
//		tagWithOptionalLegacy(Tags.Items.SEEDS_PUMPKIN);
//		tagWithOptionalLegacy(Tags.Items.SEEDS_WHEAT);
//		tagWithOptionalLegacy(Tags.Items.SLIMEBALLS);
//		tagWithOptionalLegacy(Tags.Items.STRINGS);
		method_10512(Tags.Items.TOOLS_SHEAR).method_35923(class_2960.method_60655("forge", "shears"));
		method_10512(Tags.Items.TOOLS_SPEAR).method_35923(class_2960.method_60655("forge", "tools/tridents"));
//		tagWithOptionalLegacy(Tags.Items.TOOLS);
//		tagWithOptionalLegacy(Tags.Items.ARMORS);
		method_10512(Tags.Items.TOOLS_SHIELD).method_35923(class_2960.method_60655("forge", "tools/shields"));
		method_10512(Tags.Items.TOOLS_BOW).method_35923(class_2960.method_60655("forge", "tools/bows"));
		method_10512(Tags.Items.TOOLS_BRUSH).method_35923(class_2960.method_60655("forge", "tools/brushes"));
		method_10512(Tags.Items.TOOLS_CROSSBOW).method_35923(class_2960.method_60655("forge", "tools/crossbows"));
		method_10512(Tags.Items.TOOLS_FISHING_ROD).method_35923(class_2960.method_60655("forge", "tools/fishing_rods"));
		method_10512(Tags.Items.TOOLS_SHEAR).method_35923(class_2960.method_60655("forge", "tools/shears"));
		method_10512(Tags.Items.TOOLS_SPEAR).method_35923(class_2960.method_60655("forge", "tools/tridents"));
		method_10512(Tags.Items.TOOLS_SHIELD).method_35923(class_2960.method_60655("c", "tools/shields"));
		method_10512(Tags.Items.TOOLS_BOW).method_35923(class_2960.method_60655("c", "tools/bows"));
		method_10512(Tags.Items.TOOLS_BRUSH).method_35923(class_2960.method_60655("c", "tools/brushes"));
		method_10512(Tags.Items.TOOLS_CROSSBOW).method_35923(class_2960.method_60655("c", "tools/crossbows"));
		method_10512(Tags.Items.TOOLS_FISHING_ROD).method_35923(class_2960.method_60655("c", "tools/fishing_rods"));
		method_10512(Tags.Items.TOOLS_SHEAR).method_35923(class_2960.method_60655("c", "tools/shears"));
		method_10512(Tags.Items.TOOLS_SPEAR).method_35923(class_2960.method_60655("c", "tools/tridents"));
	}

//	private FabricTagBuilder tagWithOptionalLegacy(TagKey<Item> tag) {
//		FabricTagBuilder tagAppender = tag(tag);
//		tagAppender.addOptionalTag(ResourceLocation.fromNamespaceAndPath("forge", tag.location().getPath()));
//		return tagAppender;
//	}

//	private void tagColoredWithOptionalLegacy(TagKey<Item> group) {
//		String prefix = group.location().getPath().toUpperCase(Locale.ENGLISH) + '_';
//		for (DyeColor color : DyeColor.values()) {
//			TagKey<Item> tag = getForgeItemTag(prefix + color.getName());
//			tagWithOptionalLegacy(tag);
//		}
//	}

	private void addColored(class_6862<class_1792> group, String pattern) {
		String prefix = group.comp_327().method_12832().toUpperCase(Locale.ENGLISH) + '_';
		for (class_1767 color : class_1767.values()) {
			class_2960 key = class_2960.method_60655("minecraft", pattern.replace("{color}", color.method_7792()));
			class_6862<class_1792> tag = getForgeItemTag(prefix + color.method_7792());
			class_1792 item = class_7923.field_41178.method_10223(key);
			if (item == null || item == class_1802.field_8162)
				throw new IllegalStateException("Unknown vanilla item: " + key);
			method_10512(tag).add(item);
		}
	}

	private void addColoredTags(Consumer<class_6862<class_1792>> consumer, class_6862<class_1792> group) {
		String prefix = group.comp_327().method_12832().toUpperCase(Locale.ENGLISH) + '_';
		for (class_1767 color : class_1767.values()) {
			class_6862<class_1792> tag = getForgeItemTag(prefix + color.method_7792());
			consumer.accept(tag);
		}
	}

	@SuppressWarnings("unchecked")
	private class_6862<class_2248> getForgeBlockTag(String name) {
		try {
			name = name.toUpperCase(Locale.ENGLISH);
			return (class_6862<class_2248>) Tags.Blocks.class.getDeclaredField(name).get(null);
		} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
			throw new IllegalStateException(Tags.Blocks.class.getName() + " is missing tag name: " + name);
		}
	}

	@SuppressWarnings("unchecked")
	private class_6862<class_1792> getForgeItemTag(String name) {
		try {
			name = name.toUpperCase(Locale.ENGLISH);
			return (class_6862<class_1792>) Tags.Items.class.getDeclaredField(name).get(null);
		} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
			throw new IllegalStateException(Tags.Items.class.getName() + " is missing tag name: " + name);
		}
	}

	public FabricTagBuilder method_10512(class_6862<class_1792> tag) {
		return getOrCreateTagBuilder(tag);
	}

	@Override
	public String method_10321() {
		return "PortingLib Item Tags";
	}
}
