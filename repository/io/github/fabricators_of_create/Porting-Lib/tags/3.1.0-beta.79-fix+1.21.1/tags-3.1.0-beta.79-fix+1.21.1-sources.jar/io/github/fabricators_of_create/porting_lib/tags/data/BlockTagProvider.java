package io.github.fabricators_of_create.porting_lib.tags.data;

import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1767;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7923;

public final class BlockTagProvider extends FabricTagProvider.BlockTagProvider {
	public BlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> lookupProvider) {
		super(output, lookupProvider);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void method_10514(class_7225.class_7874 p_256380_) {
		method_10512(Tags.Blocks.BARRELS).method_26792(Tags.Blocks.BARRELS_WOODEN);
		method_10512(Tags.Blocks.BARRELS_WOODEN).add(class_2246.field_16328);
		method_10512(Tags.Blocks.BOOKSHELVES).add(class_2246.field_10504);
		method_10512(Tags.Blocks.BUDDING_BLOCKS).add(class_2246.field_27160);
		method_10512(Tags.Blocks.BUDS).add(class_2246.field_27164).add(class_2246.field_27163).add(class_2246.field_27162);
		method_10512(Tags.Blocks.CHAINS).add(class_2246.field_23985);
		method_10512(Tags.Blocks.CHESTS).method_26792(Tags.Blocks.CHESTS_ENDER).method_26792(Tags.Blocks.CHESTS_TRAPPED).method_26792(Tags.Blocks.CHESTS_WOODEN);
		method_10512(Tags.Blocks.CHESTS_ENDER).add(class_2246.field_10443);
		method_10512(Tags.Blocks.CHESTS_TRAPPED).add(class_2246.field_10380);
		method_10512(Tags.Blocks.CHESTS_WOODEN).add(class_2246.field_10034, class_2246.field_10380);
		method_10512(Tags.Blocks.CLUSTERS).add(class_2246.field_27161);
		method_10512(Tags.Blocks.COBBLESTONES).method_26792(Tags.Blocks.COBBLESTONES_NORMAL).method_26792(Tags.Blocks.COBBLESTONES_INFESTED).method_26792(Tags.Blocks.COBBLESTONES_MOSSY).method_26792(Tags.Blocks.COBBLESTONES_DEEPSLATE);
		method_10512(Tags.Blocks.COBBLESTONES_NORMAL).add(class_2246.field_10445);
		method_10512(Tags.Blocks.COBBLESTONES_INFESTED).add(class_2246.field_10492);
		method_10512(Tags.Blocks.COBBLESTONES_MOSSY).add(class_2246.field_9989);
		method_10512(Tags.Blocks.COBBLESTONES_DEEPSLATE).add(class_2246.field_29031);
		method_10512(Tags.Blocks.CONCRETES).add(class_2246.field_10107, class_2246.field_10210, class_2246.field_10585, class_2246.field_10242, class_2246.field_10542, class_2246.field_10421, class_2246.field_10434, class_2246.field_10038, class_2246.field_10172, class_2246.field_10308, class_2246.field_10206, class_2246.field_10011, class_2246.field_10439, class_2246.field_10367, class_2246.field_10058, class_2246.field_10458);
		addColored(Tags.Blocks.DYED, "{color}_banner");
		addColored(Tags.Blocks.DYED, "{color}_bed");
		addColored(Tags.Blocks.DYED, "{color}_candle");
		addColored(Tags.Blocks.DYED, "{color}_carpet");
		addColored(Tags.Blocks.DYED, "{color}_concrete");
		addColored(Tags.Blocks.DYED, "{color}_concrete_powder");
		addColored(Tags.Blocks.DYED, "{color}_glazed_terracotta");
		addColored(Tags.Blocks.DYED, "{color}_shulker_box");
		addColored(Tags.Blocks.DYED, "{color}_stained_glass");
		addColored(Tags.Blocks.DYED, "{color}_stained_glass_pane");
		addColored(Tags.Blocks.DYED, "{color}_terracotta");
		addColored(Tags.Blocks.DYED, "{color}_wall_banner");
		addColored(Tags.Blocks.DYED, "{color}_wool");
		addColoredTags(method_10512(Tags.Blocks.DYED)::method_26792, Tags.Blocks.DYED);
		method_10512(Tags.Blocks.END_STONES).add(class_2246.field_10471);
		method_10512(Tags.Blocks.ENDERMAN_PLACE_ON_BLACKLIST);
		method_10512(Tags.Blocks.FENCE_GATES).method_26792(Tags.Blocks.FENCE_GATES_WOODEN);
		method_10512(Tags.Blocks.FENCE_GATES_WOODEN).add(class_2246.field_10188, class_2246.field_10291, class_2246.field_10513, class_2246.field_10041, class_2246.field_10457, class_2246.field_10196, class_2246.field_22096, class_2246.field_22097, class_2246.field_37563, class_2246.field_40289, class_2246.field_42745);
		method_10512(Tags.Blocks.FENCES).method_26792(Tags.Blocks.FENCES_NETHER_BRICK).method_26792(Tags.Blocks.FENCES_WOODEN);
		method_10512(Tags.Blocks.FENCES_NETHER_BRICK).add(class_2246.field_10364);
		method_10512(Tags.Blocks.FENCES_WOODEN).method_26792(class_3481.field_17619);
		method_10512(Tags.Blocks.GLASS_BLOCKS).method_26792(Tags.Blocks.GLASS_BLOCKS_COLORLESS).method_26792(Tags.Blocks.GLASS_BLOCKS_CHEAP).method_26792(Tags.Blocks.GLASS_BLOCKS_TINTED).add(class_2246.field_10087, class_2246.field_10227, class_2246.field_10574, class_2246.field_10271, class_2246.field_10049, class_2246.field_10157, class_2246.field_10317, class_2246.field_10555, class_2246.field_9996, class_2246.field_10248, class_2246.field_10399, class_2246.field_10060, class_2246.field_10073, class_2246.field_10357, class_2246.field_10272, class_2246.field_9997);
		method_10512(Tags.Blocks.GLASS_BLOCKS_COLORLESS).add(class_2246.field_10033);
		method_10512(Tags.Blocks.GLASS_BLOCKS_CHEAP).add(class_2246.field_10033, class_2246.field_10087, class_2246.field_10227, class_2246.field_10574, class_2246.field_10271, class_2246.field_10049, class_2246.field_10157, class_2246.field_10317, class_2246.field_10555, class_2246.field_9996, class_2246.field_10248, class_2246.field_10399, class_2246.field_10060, class_2246.field_10073, class_2246.field_10357, class_2246.field_10272, class_2246.field_9997);
		method_10512(Tags.Blocks.GLASS_BLOCKS_TINTED).add(class_2246.field_27115);
		method_10512(Tags.Blocks.GLASS_PANES).method_26792(Tags.Blocks.GLASS_PANES_COLORLESS).add(class_2246.field_9991, class_2246.field_10496, class_2246.field_10469, class_2246.field_10193, class_2246.field_10578, class_2246.field_10305, class_2246.field_10565, class_2246.field_10077, class_2246.field_10129, class_2246.field_10355, class_2246.field_10152, class_2246.field_9982, class_2246.field_10163, class_2246.field_10419, class_2246.field_10118, class_2246.field_10070);
		method_10512(Tags.Blocks.GLASS_PANES_COLORLESS).add(class_2246.field_10285);
		method_10512(Tags.Blocks.GLAZED_TERRACOTTAS).add(class_2246.field_10595, class_2246.field_10280, class_2246.field_10538, class_2246.field_10345, class_2246.field_10096, class_2246.field_10046, class_2246.field_10567, class_2246.field_10220, class_2246.field_10052, class_2246.field_10078, class_2246.field_10426, class_2246.field_10550, class_2246.field_10004, class_2246.field_10475, class_2246.field_10383, class_2246.field_10501);
		method_10512(Tags.Blocks.GRAVELS).add(class_2246.field_10255);
		method_10512(Tags.Blocks.SKULLS).add(class_2246.field_10481, class_2246.field_10388, class_2246.field_10177, class_2246.field_10101, class_2246.field_10432, class_2246.field_10208, class_2246.field_10241, class_2246.field_10581, class_2246.field_10042, class_2246.field_10509, class_2246.field_41305, class_2246.field_41306, class_2246.field_10337, class_2246.field_10472);
		method_10512(Tags.Blocks.HIDDEN_FROM_RECIPE_VIEWERS);
		method_10512(Tags.Blocks.NETHERRACKS).add(class_2246.field_10515);
		method_10512(Tags.Blocks.OBSIDIANS).add(class_2246.field_10540);
		method_10512(Tags.Blocks.ORE_BEARING_GROUND_DEEPSLATE).add(class_2246.field_28888);
		method_10512(Tags.Blocks.ORE_BEARING_GROUND_NETHERRACK).add(class_2246.field_10515);
		method_10512(Tags.Blocks.ORE_BEARING_GROUND_STONE).add(class_2246.field_10340);
		method_10512(Tags.Blocks.ORE_RATES_DENSE).add(class_2246.field_27120, class_2246.field_29221, class_2246.field_29028, class_2246.field_29030, class_2246.field_10090, class_2246.field_10080);
		method_10512(Tags.Blocks.ORE_RATES_SINGULAR).add(class_2246.field_22109, class_2246.field_10418, class_2246.field_29219, class_2246.field_29029, class_2246.field_29220, class_2246.field_29026, class_2246.field_29027, class_2246.field_10442, class_2246.field_10013, class_2246.field_10571, class_2246.field_10212, class_2246.field_10213);
		method_10512(Tags.Blocks.ORE_RATES_SPARSE).add(class_2246.field_23077);
		method_10512(Tags.Blocks.ORES).method_26792(Tags.Blocks.ORES_COAL).method_26792(Tags.Blocks.ORES_COPPER).method_26792(Tags.Blocks.ORES_DIAMOND).method_26792(Tags.Blocks.ORES_EMERALD).method_26792(Tags.Blocks.ORES_GOLD).method_26792(Tags.Blocks.ORES_IRON).method_26792(Tags.Blocks.ORES_LAPIS).method_26792(Tags.Blocks.ORES_NETHERITE_SCRAP).method_26792(Tags.Blocks.ORES_REDSTONE).method_26792(Tags.Blocks.ORES_QUARTZ);
		method_10512(Tags.Blocks.ORES_COAL).method_26792(class_3481.field_29193);
		method_10512(Tags.Blocks.ORES_COPPER).method_26792(class_3481.field_29195);
		method_10512(Tags.Blocks.ORES_DIAMOND).method_26792(class_3481.field_28989);
		method_10512(Tags.Blocks.ORES_EMERALD).method_26792(class_3481.field_29194);
		method_10512(Tags.Blocks.ORES_GOLD).method_26792(class_3481.field_23062);
		method_10512(Tags.Blocks.ORES_IRON).method_26792(class_3481.field_28988);
		method_10512(Tags.Blocks.ORES_LAPIS).method_26792(class_3481.field_28991);
		method_10512(Tags.Blocks.ORES_QUARTZ).add(class_2246.field_10213);
		method_10512(Tags.Blocks.ORES_REDSTONE).method_26792(class_3481.field_28990);
		method_10512(Tags.Blocks.ORES_NETHERITE_SCRAP).add(class_2246.field_22109);
		method_10512(Tags.Blocks.ORES_IN_GROUND_DEEPSLATE).add(class_2246.field_29219, class_2246.field_29221, class_2246.field_29029, class_2246.field_29220, class_2246.field_29026, class_2246.field_29027, class_2246.field_29028, class_2246.field_29030);
		method_10512(Tags.Blocks.ORES_IN_GROUND_NETHERRACK).add(class_2246.field_23077, class_2246.field_10213);
		method_10512(Tags.Blocks.ORES_IN_GROUND_STONE).add(class_2246.field_10418, class_2246.field_27120, class_2246.field_10442, class_2246.field_10013, class_2246.field_10571, class_2246.field_10212, class_2246.field_10090, class_2246.field_10080);
		method_10512(Tags.Blocks.PLAYER_WORKSTATIONS_CRAFTING_TABLES).add(class_2246.field_9980);
		method_10512(Tags.Blocks.PLAYER_WORKSTATIONS_FURNACES).add(class_2246.field_10181);
		method_10512(Tags.Blocks.SANDS).method_26792(Tags.Blocks.SANDS_COLORLESS).method_26792(Tags.Blocks.SANDS_RED);
		method_10512(Tags.Blocks.RELOCATION_NOT_SUPPORTED);
		method_10512(Tags.Blocks.ROPES);
		method_10512(Tags.Blocks.SANDS_COLORLESS).add(class_2246.field_10102);
		method_10512(Tags.Blocks.SANDS_RED).add(class_2246.field_10534);

		method_10512(Tags.Blocks.SANDSTONE_RED_BLOCKS).add(class_2246.field_10344, class_2246.field_10518, class_2246.field_10117, class_2246.field_10483);
		method_10512(Tags.Blocks.SANDSTONE_UNCOLORED_BLOCKS).add(class_2246.field_9979, class_2246.field_10361, class_2246.field_10292, class_2246.field_10467);
		method_10512(Tags.Blocks.SANDSTONE_BLOCKS).method_26792(Tags.Blocks.SANDSTONE_RED_BLOCKS).method_26792(Tags.Blocks.SANDSTONE_UNCOLORED_BLOCKS);
		method_10512(Tags.Blocks.SANDSTONE_RED_SLABS).add(class_2246.field_10624, class_2246.field_18891, class_2246.field_10283);
		method_10512(Tags.Blocks.SANDSTONE_UNCOLORED_SLABS).add(class_2246.field_10007, class_2246.field_18890, class_2246.field_10262);
		method_10512(Tags.Blocks.SANDSTONE_SLABS).method_26792(Tags.Blocks.SANDSTONE_RED_SLABS).method_26792(Tags.Blocks.SANDSTONE_UNCOLORED_SLABS);
		method_10512(Tags.Blocks.SANDSTONE_RED_STAIRS).add(class_2246.field_10420, class_2246.field_10039);
		method_10512(Tags.Blocks.SANDSTONE_UNCOLORED_STAIRS).add(class_2246.field_10142, class_2246.field_10549);
		method_10512(Tags.Blocks.SANDSTONE_STAIRS).method_26792(Tags.Blocks.SANDSTONE_RED_STAIRS).method_26792(Tags.Blocks.SANDSTONE_UNCOLORED_STAIRS);

		method_10512(Tags.Blocks.STONES).add(class_2246.field_10115, class_2246.field_10508, class_2246.field_10474, class_2246.field_10340, class_2246.field_28888, class_2246.field_27165);
		method_10512(Tags.Blocks.STORAGE_BLOCKS).method_26792(Tags.Blocks.STORAGE_BLOCKS_BONE_MEAL).method_26792(Tags.Blocks.STORAGE_BLOCKS_COAL)
				.method_26792(Tags.Blocks.STORAGE_BLOCKS_COPPER).method_26792(Tags.Blocks.STORAGE_BLOCKS_DIAMOND).method_26792(Tags.Blocks.STORAGE_BLOCKS_DRIED_KELP)
				.method_26792(Tags.Blocks.STORAGE_BLOCKS_EMERALD).method_26792(Tags.Blocks.STORAGE_BLOCKS_GOLD).method_26792(Tags.Blocks.STORAGE_BLOCKS_IRON)
				.method_26792(Tags.Blocks.STORAGE_BLOCKS_LAPIS).method_26792(Tags.Blocks.STORAGE_BLOCKS_NETHERITE).method_26792(Tags.Blocks.STORAGE_BLOCKS_RAW_COPPER)
				.method_26792(Tags.Blocks.STORAGE_BLOCKS_RAW_GOLD).method_26792(Tags.Blocks.STORAGE_BLOCKS_RAW_IRON).method_26792(Tags.Blocks.STORAGE_BLOCKS_REDSTONE)
				.method_26792(Tags.Blocks.STORAGE_BLOCKS_SLIME).method_26792(Tags.Blocks.STORAGE_BLOCKS_WHEAT);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_BONE_MEAL).add(class_2246.field_10166);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_COAL).add(class_2246.field_10381);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_COPPER).add(class_2246.field_27119);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_DIAMOND).add(class_2246.field_10201);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_DRIED_KELP).add(class_2246.field_10342);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_EMERALD).add(class_2246.field_10234);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_GOLD).add(class_2246.field_10205);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_IRON).add(class_2246.field_10085);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_LAPIS).add(class_2246.field_10441);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_NETHERITE).add(class_2246.field_22108);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_RAW_COPPER).add(class_2246.field_33509);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_RAW_GOLD).add(class_2246.field_33510);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_RAW_IRON).add(class_2246.field_33508);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_REDSTONE).add(class_2246.field_10002);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_SLIME).add(class_2246.field_10030);
		method_10512(Tags.Blocks.STORAGE_BLOCKS_WHEAT).add(class_2246.field_10359);
		method_10512(Tags.Blocks.VILLAGER_JOB_SITES).add(
				class_2246.field_16328, class_2246.field_16333, class_2246.field_10333, class_2246.field_16336,
				class_2246.field_10593, class_2246.field_27097, class_2246.field_27098, class_2246.field_27878,
				class_2246.field_17563, class_2246.field_16331, class_2246.field_16337, class_2246.field_16330,
				class_2246.field_10083, class_2246.field_16329, class_2246.field_16334, class_2246.field_16335);

		// Backwards compat with pre-1.21 tags. Done after so optional tag is last for better readability.
		// TODO: Remove backwards compat tag entries in 1.22
//		tagWithOptionalLegacy(Tags.Blocks.BARRELS);
//		tagWithOptionalLegacy(Tags.Blocks.BARRELS_WOODEN);
//		tagWithOptionalLegacy(Tags.Blocks.BOOKSHELVES);
//		tagWithOptionalLegacy(Tags.Blocks.CHESTS);
//		tagWithOptionalLegacy(Tags.Blocks.CHESTS_ENDER);
//		tagWithOptionalLegacy(Tags.Blocks.CHESTS_TRAPPED);
//		tagWithOptionalLegacy(Tags.Blocks.CHESTS_WOODEN);
		method_10512(Tags.Blocks.COBBLESTONES).method_35923(class_2960.method_60655("forge", "cobblestone"));
		method_10512(Tags.Blocks.COBBLESTONES_NORMAL).method_35923(class_2960.method_60655("forge", "cobblestone/normal"));
		method_10512(Tags.Blocks.COBBLESTONES_INFESTED).method_35923(class_2960.method_60655("forge", "cobblestone/infested"));
		method_10512(Tags.Blocks.COBBLESTONES_MOSSY).method_35923(class_2960.method_60655("forge", "cobblestone/mossy"));
		method_10512(Tags.Blocks.COBBLESTONES_DEEPSLATE).method_35923(class_2960.method_60655("forge", "cobblestone/deepslate"));
		method_10512(Tags.Blocks.DYED_BLACK)
				.method_35923(class_2960.method_60655("forge", "glass/black"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/black"));
		method_10512(Tags.Blocks.DYED_BLUE)
				.method_35923(class_2960.method_60655("forge", "glass/blue"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/blue"));
		method_10512(Tags.Blocks.DYED_BROWN)
				.method_35923(class_2960.method_60655("forge", "glass/brown"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/brown"));
		method_10512(Tags.Blocks.DYED_CYAN)
				.method_35923(class_2960.method_60655("forge", "glass/cyan"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/cyan"));
		method_10512(Tags.Blocks.DYED_GRAY)
				.method_35923(class_2960.method_60655("forge", "glass/gray"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/gray"));
		method_10512(Tags.Blocks.DYED_GREEN)
				.method_35923(class_2960.method_60655("forge", "glass/green"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/green"));
		method_10512(Tags.Blocks.DYED_LIGHT_BLUE)
				.method_35923(class_2960.method_60655("forge", "glass/light_blue"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/light_blue"));
		method_10512(Tags.Blocks.DYED_LIGHT_GRAY)
				.method_35923(class_2960.method_60655("forge", "glass/light_gray"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/light_gray"));
		method_10512(Tags.Blocks.DYED_LIME)
				.method_35923(class_2960.method_60655("forge", "glass/lime"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/lime"));
		method_10512(Tags.Blocks.DYED_MAGENTA)
				.method_35923(class_2960.method_60655("forge", "glass/magenta"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/magenta"));
		method_10512(Tags.Blocks.DYED_MAGENTA)
				.method_35923(class_2960.method_60655("forge", "glass/magenta"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/magenta"));
		method_10512(Tags.Blocks.DYED_ORANGE)
				.method_35923(class_2960.method_60655("forge", "glass/orange"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/orange"));
		method_10512(Tags.Blocks.DYED_PINK)
				.method_35923(class_2960.method_60655("forge", "glass/pink"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/pink"));
		method_10512(Tags.Blocks.DYED_PURPLE)
				.method_35923(class_2960.method_60655("forge", "glass/purple"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/purple"));
		method_10512(Tags.Blocks.DYED_RED)
				.method_35923(class_2960.method_60655("forge", "glass/red"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/red"));
		method_10512(Tags.Blocks.DYED_WHITE)
				.method_35923(class_2960.method_60655("forge", "glass/white"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/white"));
		method_10512(Tags.Blocks.DYED_YELLOW)
				.method_35923(class_2960.method_60655("forge", "glass/yellow"))
				.method_35923(class_2960.method_60655("forge", "stained_glass/yellow"));
//		tagWithOptionalLegacy(Tags.Blocks.END_STONES);
//		tagWithOptionalLegacy(Tags.Blocks.ENDERMAN_PLACE_ON_BLACKLIST);
//		tagWithOptionalLegacy(Tags.Blocks.FENCE_GATES);
//		tagWithOptionalLegacy(Tags.Blocks.FENCE_GATES_WOODEN);
//		tagWithOptionalLegacy(Tags.Blocks.FENCES);
//		tagWithOptionalLegacy(Tags.Blocks.FENCES_NETHER_BRICK);
//		tagWithOptionalLegacy(Tags.Blocks.FENCES_WOODEN);
		method_10512(Tags.Blocks.GRAVELS).method_35923(class_2960.method_60655("forge", "gravel"));
		method_10512(Tags.Blocks.GLASS_BLOCKS).method_35923(class_2960.method_60655("forge", "glass"));
		method_10512(Tags.Blocks.GLASS_BLOCKS_COLORLESS).method_35923(class_2960.method_60655("forge", "glass_colorless"));
		method_10512(Tags.Blocks.GLASS_BLOCKS_CHEAP).method_35923(class_2960.method_60655("forge", "glass_silica"));
		method_10512(Tags.Blocks.GLASS_BLOCKS_TINTED).method_35923(class_2960.method_60655("forge", "glass_tinted"));
		method_10512(Tags.Blocks.GLASS_PANES_COLORLESS).method_35923(class_2960.method_60655("forge", "glass_panes_colorless"));
		method_10512(Tags.Blocks.NETHERRACKS).method_35923(class_2960.method_60655("forge", "netherrack"));
		method_10512(Tags.Blocks.OBSIDIANS).method_35923(class_2960.method_60655("forge", "obsidian"));
//		tagWithOptionalLegacy(Tags.Blocks.ORE_BEARING_GROUND_DEEPSLATE);
//		tagWithOptionalLegacy(Tags.Blocks.ORE_BEARING_GROUND_NETHERRACK);
//		tagWithOptionalLegacy(Tags.Blocks.ORE_BEARING_GROUND_STONE);
//		tagWithOptionalLegacy(Tags.Blocks.ORE_RATES_DENSE);
//		tagWithOptionalLegacy(Tags.Blocks.ORE_RATES_SINGULAR);
//		tagWithOptionalLegacy(Tags.Blocks.ORE_RATES_SPARSE);
//		tagWithOptionalLegacy(Tags.Blocks.ORES);
//		tagWithOptionalLegacy(Tags.Blocks.ORES_COAL);
//		tagWithOptionalLegacy(Tags.Blocks.ORES_COPPER);
//		tagWithOptionalLegacy(Tags.Blocks.ORES_DIAMOND);
//		tagWithOptionalLegacy(Tags.Blocks.ORES_EMERALD);
//		tagWithOptionalLegacy(Tags.Blocks.ORES_GOLD);
//		tagWithOptionalLegacy(Tags.Blocks.ORES_IRON);
//		tagWithOptionalLegacy(Tags.Blocks.ORES_LAPIS);
//		tagWithOptionalLegacy(Tags.Blocks.ORES_QUARTZ);
//		tagWithOptionalLegacy(Tags.Blocks.ORES_REDSTONE);
//		tagWithOptionalLegacy(Tags.Blocks.ORES_NETHERITE_SCRAP);
//		tagWithOptionalLegacy(Tags.Blocks.ORES_IN_GROUND_DEEPSLATE);
//		tagWithOptionalLegacy(Tags.Blocks.ORES_IN_GROUND_NETHERRACK);
//		tagWithOptionalLegacy(Tags.Blocks.ORES_IN_GROUND_STONE);
		method_10512(Tags.Blocks.STONES).method_35923(class_2960.method_60655("forge", "stone"));
//		tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS);
//		tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_COAL);
//		tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_COPPER);
//		tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_DIAMOND);
//		tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_EMERALD);
//		tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_GOLD);
//		tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_IRON);
//		tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_LAPIS);
//		tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_RAW_COPPER);
//		tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_RAW_GOLD);
//		tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_RAW_IRON);
//		tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_REDSTONE);
//		tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_NETHERITE);
		method_10512(Tags.Blocks.RELOCATION_NOT_SUPPORTED)
				.method_35923(class_2960.method_60655("forge", "relocation_not_supported"))
				.method_35923(class_2960.method_60655("forge", "immovable"));
		method_10512(Tags.Blocks.SANDSTONE_BLOCKS).method_35923(class_2960.method_60655("forge", "sandstone"));
		method_10512(Tags.Blocks.SANDS).method_35923(class_2960.method_60655("forge", "sand"));
		method_10512(Tags.Blocks.SANDS_COLORLESS).method_35923(class_2960.method_60655("forge", "sand/colorless"));
		method_10512(Tags.Blocks.SANDS_RED).method_35923(class_2960.method_60655("forge", "sand/red"));
	}

//	private FabricTagBuilder tagWithOptionalLegacy(TagKey<Block> tag) {
//		FabricTagBuilder tagAppender = tag(tag);
//		tagAppender.addOptionalTag(ResourceLocation.fromNamespaceAndPath("c", tag.location().getPath()));
//		return tagAppender;
//	}

	private void addColored(class_6862<class_2248> group, String pattern) {
		String prefix = group.comp_327().method_12832().toUpperCase(Locale.ENGLISH) + '_';
		for (class_1767 color : class_1767.values()) {
			class_2960 key = class_2960.method_60655("minecraft", pattern.replace("{color}", color.method_7792()));
			class_6862<class_2248> tag = getForgeTag(prefix + color.method_7792());
			class_2248 block = class_7923.field_41175.method_10223(key);
			if (block == null || block == class_2246.field_10124)
				throw new IllegalStateException("Unknown vanilla block: " + key);
			method_10512(tag).add(block);
		}
	}

	private void addColoredTags(Consumer<class_6862<class_2248>> consumer, class_6862<class_2248> group) {
		String prefix = group.comp_327().method_12832().toUpperCase(Locale.ENGLISH) + '_';
		for (class_1767 color : class_1767.values()) {
			class_6862<class_2248> tag = getForgeTag(prefix + color.method_7792());
			consumer.accept(tag);
		}
	}

	@SuppressWarnings("unchecked")
	private class_6862<class_2248> getForgeTag(String name) {
		try {
			name = name.toUpperCase(Locale.ENGLISH);
			return (class_6862<class_2248>) Tags.Blocks.class.getDeclaredField(name).get(null);
		} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
			throw new IllegalStateException(Tags.Blocks.class.getName() + " is missing tag name: " + name);
		}
	}

	public FabricTagBuilder method_10512(class_6862<class_2248> tag) {
		return getOrCreateTagBuilder(tag);
	}
}
