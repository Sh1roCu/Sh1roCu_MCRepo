package io.github.fabricators_of_create.porting_lib.tags.extensions;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import net.minecraft.class_1792;
import net.minecraft.class_6862;

public interface DyeExtension {
	/**
	 * Gets the tag key representing the set of items which provide this dye color.
	 * @return A {@link net.minecraft.tags.TagKey<Item>} representing the set of items which provide this dye color.
	 */
	default class_6862<class_1792> getTag() {
		throw PortingLib.createMixinException(this.getClass().getSimpleName() + " does not support getTag()");
	}

	/**
	 * Gets the tag key representing the set of items which are dyed with this color.
	 * @return A {@link net.minecraft.tags.TagKey<Item>} representing the set of items which are dyed with this color.
	 */
	default class_6862<class_1792> getDyedTag() {
		throw PortingLib.createMixinException(this.getClass().getSimpleName() + " does not support getDyedTag()");
	}
}
