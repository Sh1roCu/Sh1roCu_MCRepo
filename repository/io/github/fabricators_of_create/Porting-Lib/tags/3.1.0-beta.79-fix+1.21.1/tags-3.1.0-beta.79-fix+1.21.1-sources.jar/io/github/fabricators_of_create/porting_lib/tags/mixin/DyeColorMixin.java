package io.github.fabricators_of_create.porting_lib.tags.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import io.github.fabricators_of_create.porting_lib.tags.extensions.DyeExtension;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

@Mixin(class_1767.class)
public class DyeColorMixin implements DyeExtension {
	@Shadow
	@Final
	private String name;
	@Unique
	private class_6862<class_1792> dyesTag;
	@Unique
	private class_6862<class_1792> dyedTag;

	@Inject(method = "<init>", at = @At("TAIL"))
	public void addTag(String enumName, int ordinal, int id, String name, int diffuseColor, class_3620 mapColor, int fireworkColor, int textColor, CallbackInfo ci) {
		this.dyesTag = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "dyes/" + name));
		this.dyedTag = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "dyed/" + name));
	}

	@Override
	public class_6862<class_1792> getTag() {
		return dyesTag;
	}

	@Override
	public class_6862<class_1792> getDyedTag() {
		return dyedTag;
	}
}
