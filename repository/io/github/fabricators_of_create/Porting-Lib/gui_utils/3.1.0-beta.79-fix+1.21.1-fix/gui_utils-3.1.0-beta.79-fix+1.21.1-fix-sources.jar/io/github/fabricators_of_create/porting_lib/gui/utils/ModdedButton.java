package io.github.fabricators_of_create.porting_lib.gui.utils;

import net.minecraft.class_4185;

public class ModdedButton extends class_4185 {
	protected ModdedButton(class_7840 builder) {
		super(builder.field_40759, builder.field_40760, builder.field_40761, builder.field_40762, builder.field_40756, builder.field_40757, builder.field_40763);
		method_47400(builder.field_41099); // Forge: Make use of the Builder tooltip
	}
}
