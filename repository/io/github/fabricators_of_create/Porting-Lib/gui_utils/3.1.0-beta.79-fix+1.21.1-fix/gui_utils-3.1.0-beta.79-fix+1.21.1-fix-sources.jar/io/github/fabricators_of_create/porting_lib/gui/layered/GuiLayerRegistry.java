package io.github.fabricators_of_create.porting_lib.gui.layered;

import io.github.fabricators_of_create.porting_lib.gui.events.RenderGuiLayerCallback;
import io.github.fabricators_of_create.porting_lib.gui.mixin.GuiAccessor;
import java.util.function.UnaryOperator;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_9080;

import static io.github.fabricators_of_create.porting_lib.gui.layered.VanillaGuiLayers.*;

/**
 * Allows users to register custom {@link class_9080.class_9081 layers} for GUI rendering.
 *
 * <p>See also {@link RenderGuiLayerCallback} to intercept rendering of registered layers.
 */
public class GuiLayerRegistry {
	private static final GuiLayerManager layerManager = new GuiLayerManager();

	public static GuiLayerManager getLayerManager() {
		return layerManager;
	}

	static {
		GuiLayerManager playerHealthComponents = new GuiLayerManager()
				.addVanilla(PLAYER_HEALTH)
				.addVanilla(ARMOR_LEVEL)
				.addVanilla(FOOD_LEVEL);

		GuiLayerManager mainLayers = new GuiLayerManager()
				.addVanilla(CAMERA_OVERLAYS, (guiGraphics, deltaTracker) -> ((GuiAccessor) getGui()).callRenderCameraOverlays(guiGraphics, deltaTracker))
				.addVanilla(CROSSHAIR, (guiGraphics, deltaTracker) -> ((GuiAccessor) getGui()).callRenderCrosshair(guiGraphics, deltaTracker))
				.addVanilla(HOTBAR)
				.addVanilla(JUMP_METER)
				.addVanilla(EXPERIENCE_BAR)
				.add(playerHealthComponents, () -> class_310.method_1551().field_1761.method_2908())
				.addVanilla(VEHICLE_HEALTH)
				.addVanilla(AIR_LEVEL)
				.addVanilla(SELECTED_ITEM_NAME)
				.addVanilla(SPECTATOR_TOOLTIP)
				.addVanilla(EXPERIENCE_LEVEL, (guiGraphics, deltaTracker) -> ((GuiAccessor) getGui()).callRenderExperienceLevel(guiGraphics, deltaTracker))
				.addVanilla(EFFECTS, (guiGraphics, deltaTracker) -> ((GuiAccessor) getGui()).callRenderEffects(guiGraphics, deltaTracker))
				.addVanilla(BOSS_OVERLAY, (guiGraphics, tickDelta) -> getGui().method_1740().method_1796(guiGraphics));

		GuiLayerManager additionalLayers = new GuiLayerManager()
				.addVanilla(DEMO_OVERLAY, (guiGraphics, deltaTracker) -> ((GuiAccessor) getGui()).callRenderDemoOverlay(guiGraphics, deltaTracker))
				.addVanilla(DEBUG_OVERLAY, (guiGraphics, deltaTracker) -> {
					class_329 gui = getGui();
					if (gui.method_53531().method_53536()) {
						gui.method_53531().method_1846(guiGraphics);
					}
				})
				.addVanilla(SCOREBOARD_SIDEBAR, (guiGraphics, deltaTracker) -> ((GuiAccessor) getGui()).callRenderScoreboardSidebar(guiGraphics, deltaTracker))
				.addVanilla(OVERLAY_MESSAGE, (guiGraphics, deltaTracker) -> ((GuiAccessor) getGui()).callRenderOverlayMessage(guiGraphics, deltaTracker))
				.addVanilla(TITLE, (guiGraphics, deltaTracker) -> ((GuiAccessor) getGui()).callRenderTitle(guiGraphics, deltaTracker))
				.addVanilla(CHAT, (guiGraphics, deltaTracker) -> ((GuiAccessor) getGui()).callRenderChat(guiGraphics, deltaTracker))
				.addVanilla(TAB_LIST, (guiGraphics, deltaTracker) -> ((GuiAccessor) getGui()).callRenderTabList(guiGraphics, deltaTracker))
				.addVanilla(SUBTITLE_OVERLAY, (guiGraphics, deltaTracker) -> ((GuiAccessor) getGui()).getSubtitleOverlay().method_1957(guiGraphics))
				.addVanilla(SAVING_INDICATOR, (guiGraphics, deltaTracker) -> getGui().method_39192(guiGraphics, deltaTracker));

		layerManager
				.add(mainLayers, () -> !class_310.method_1551().field_1690.field_1842)
				.addVanilla(SLEEP_OVERLAY, (guiGraphics, deltaTracker) -> ((GuiAccessor) getGui()).callRenderSleepOverlay(guiGraphics, deltaTracker))
				.add(additionalLayers, () -> !class_310.method_1551().field_1690.field_1842);
	}

	/**
	 * Registers a layer that renders below all others.
	 *
	 * @param id    A unique resource id for this layer
	 * @param layer The layer
	 */
	public static void registerBelowAll(class_2960 id, class_9080.class_9081 layer) {
		getLayerManager().register(Ordering.BEFORE, null, id, layer);
	}

	/**
	 * Registers a layer that renders below another.
	 *
	 * @param other The id of the layer to render below. This must be a layer you have already registered or one of the
	 *              {@link VanillaGuiLayers vanilla layers}. Do not use other mods' layers.
	 * @param id    A unique resource id for this layer
	 * @param layer The layer
	 */
	public static void registerBelow(class_2960 other, class_2960 id, class_9080.class_9081 layer) {
		getLayerManager().register(Ordering.BEFORE, other, id, layer);
	}

	/**
	 * Registers an layer that renders above another.
	 *
	 * @param other The id of the layer to render above. This must be a layer you have already registered or one of the
	 *              {@link VanillaGuiLayers vanilla layers}. Do not use other mods' layers.
	 * @param id    A unique resource id for this layer
	 * @param layer The layer
	 */
	public static void registerAbove(class_2960 other, class_2960 id, class_9080.class_9081 layer) {
		getLayerManager().register(Ordering.AFTER, other, id, layer);
	}

	/**
	 * Registers a layer that renders above all others.
	 *
	 * @param id    A unique resource id for this layer
	 * @param layer The layer
	 */
	public static void registerAboveAll(class_2960 id, class_9080.class_9081 layer) {
		getLayerManager().register(Ordering.AFTER, null, id, layer);
	}

	/**
	 * Replace the layer with the given {@code id} with a new one.
	 *
	 * @param id          the id of the layer to replace
	 * @param replacement the layer to replace it with
	 * @throws IllegalArgumentException if a layer with the given {@code id} is not yet registered
	 * @see #wrapLayer(class_2960, UnaryOperator) use {@code wrapLayer} if you'd like to
	 *      wrap the layer to apply pose stack transformations
	 */
	public static void replaceLayer(class_2960 id, class_9080.class_9081 replacement) {
		wrapLayer(id, old -> replacement);
	}

	/**
	 * Wrap the layer with the given {@code id} in a new layer.
	 * <p>
	 * This can be used, for instance, to apply pose stack transformations to move the layer or resize it.
	 *
	 * @param id      the id of the layer to wrap
	 * @param wrapper an unary operator which takes in the old layer and returns the new layer that wraps the old one
	 * @throws IllegalArgumentException if a layer with the given {@code id} is not yet registered
	 */
	public static void wrapLayer(class_2960 id, UnaryOperator<class_9080.class_9081> wrapper) {
		getLayerManager().wrapLayer(id, wrapper);
	}

	private static class_329 getGui() {
		return class_310.method_1551().field_1705;
	}

	public enum Ordering {
		BEFORE, AFTER
	}
}
