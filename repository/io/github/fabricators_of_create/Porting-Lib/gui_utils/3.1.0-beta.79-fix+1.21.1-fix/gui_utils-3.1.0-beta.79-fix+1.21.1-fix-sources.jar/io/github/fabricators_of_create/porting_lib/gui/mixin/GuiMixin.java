package io.github.fabricators_of_create.porting_lib.gui.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.gui.events.RenderGuiCallback;
import io.github.fabricators_of_create.porting_lib.gui.layered.GuiLayerManager;
import io.github.fabricators_of_create.porting_lib.gui.layered.GuiLayerRegistry;
import net.minecraft.class_1316;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_365;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static io.github.fabricators_of_create.porting_lib.gui.layered.VanillaGuiLayers.*;

@Mixin(class_329.class)
public abstract class GuiMixin {
	@Shadow
	@Final
	private class_310 minecraft;

	@Unique
	private final GuiLayerManager port_lib$layerManager = GuiLayerRegistry.getLayerManager();

	@Unique
	private void port_lib$tryRenderLayer(class_2960 layerId, class_332 guiGraphics, class_9779 deltaTracker, Runnable renderCallback) {
		if (!port_lib$layerManager.callPreRenderEvent(layerId, guiGraphics, deltaTracker)) {
			renderCallback.run();
			port_lib$layerManager.callPostRenderEvent(layerId, guiGraphics, deltaTracker);
		}

		port_lib$layerManager.renderFrom(layerId, guiGraphics, deltaTracker);
	}

	@WrapMethod(method = "method_55808")
	private void tryRenderBossOverlay(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(BOSS_OVERLAY, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapOperation(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/spectator/SpectatorGui;renderHotbar(Lnet/minecraft/client/gui/GuiGraphics;)V"))
	private void tryRenderHotbar(class_365 instance, class_332 guiGraphics, Operation<Void> original, @Local(argsOnly = true) class_9779 deltaTracker) {
		port_lib$tryRenderLayer(HOTBAR, guiGraphics, deltaTracker, () -> original.call(instance, guiGraphics));
	}

	@WrapOperation(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;renderItemHotbar(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/DeltaTracker;)V"))
	private void tryRenderHotbar(class_329 instance, class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(HOTBAR, guiGraphics, deltaTracker, () -> original.call(instance, guiGraphics, deltaTracker));
	}

	@Inject(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;jumpableVehicle()Lnet/minecraft/world/entity/PlayerRideableJumping;"))
	private void renderJumpAndExperienceLayers(class_332 guiGraphics, class_9779 deltaTracker, CallbackInfo ci) {
		// TODO: this renders before jump meter and experience bar, but we can't wrap blocks of code.
		port_lib$layerManager.renderFrom(JUMP_METER, guiGraphics, deltaTracker);
		port_lib$layerManager.renderFrom(EXPERIENCE_BAR, guiGraphics, deltaTracker);
	}

	@WrapOperation(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;renderJumpMeter(Lnet/minecraft/world/entity/PlayerRideableJumping;Lnet/minecraft/client/gui/GuiGraphics;I)V"))
	private void tryRenderJumpBar(class_329 instance, class_1316 rideable, class_332 guiGraphics, int x, Operation<Void> original, @Local(argsOnly = true) class_9779 deltaTracker) {
		if (!port_lib$layerManager.callPreRenderEvent(JUMP_METER, guiGraphics, deltaTracker)) {
			original.call(instance, rideable, guiGraphics, x);
			port_lib$layerManager.callPostRenderEvent(JUMP_METER, guiGraphics, deltaTracker);
		}
	}

	@WrapOperation(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;renderExperienceBar(Lnet/minecraft/client/gui/GuiGraphics;I)V"))
	private void tryRenderExperienceBar(class_329 instance, class_332 guiGraphics, int x, Operation<Void> original, @Local(argsOnly = true) class_9779 deltaTracker) {
		if (!port_lib$layerManager.callPreRenderEvent(EXPERIENCE_BAR, guiGraphics, deltaTracker)) {
			original.call(instance, guiGraphics, x);
			port_lib$layerManager.callPostRenderEvent(EXPERIENCE_BAR, guiGraphics, deltaTracker);
		}
	}

	@WrapOperation(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;renderPlayerHealth(Lnet/minecraft/client/gui/GuiGraphics;)V"))
	private void tryRenderPlayerBar(class_329 instance, class_332 guiGraphics, Operation<Void> original, @Local(argsOnly = true) class_9779 deltaTracker) {
		if (!port_lib$layerManager.callPreRenderEvent(EXPERIENCE_BAR, guiGraphics, deltaTracker)) {
			original.call(instance, guiGraphics);
			port_lib$layerManager.callPostRenderEvent(EXPERIENCE_BAR, guiGraphics, deltaTracker);
		}
	}

	@WrapOperation(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;renderPlayerHealth(Lnet/minecraft/client/gui/GuiGraphics;)V"))
	private void tryRenderPlayerHealth(class_329 instance, class_332 guiGraphics, Operation<Void> original, @Local(argsOnly = true) class_9779 deltaTracker) {
		if (!port_lib$layerManager.callPreRenderEvent(PLAYER_HEALTH, guiGraphics, deltaTracker)) {
			original.call(instance, guiGraphics);
			port_lib$layerManager.callPostRenderEvent(PLAYER_HEALTH, guiGraphics, deltaTracker);
		}
	}

	@Inject(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;renderVehicleHealth(Lnet/minecraft/client/gui/GuiGraphics;)V"))
	private void renderPlayerHealthLayers(class_332 guiGraphics, class_9779 deltaTracker, CallbackInfo ci) {
		port_lib$layerManager.renderFrom(PLAYER_HEALTH, guiGraphics, deltaTracker);
	}

	@WrapOperation(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;renderVehicleHealth(Lnet/minecraft/client/gui/GuiGraphics;)V"))
	private void tryRenderVehicleHealth(class_329 instance, class_332 guiGraphics, Operation<Void> original, @Local(argsOnly = true) class_9779 deltaTracker) {
		port_lib$tryRenderLayer(VEHICLE_HEALTH, guiGraphics, deltaTracker, () -> original.call(instance, guiGraphics));
	}

	@Inject(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/MultiPlayerGameMode;getPlayerMode()Lnet/minecraft/world/level/GameType;", ordinal = 1))
	private void renderTooltipLayers(class_332 guiGraphics, class_9779 deltaTracker, CallbackInfo ci) {
		// TODO: this renders before selected item name and spectator tooltip, but we can't wrap blocks of code.
		port_lib$layerManager.renderFrom(SELECTED_ITEM_NAME, guiGraphics, deltaTracker);
		port_lib$layerManager.renderFrom(SPECTATOR_TOOLTIP, guiGraphics, deltaTracker);
	}

	@WrapOperation(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/Gui;renderSelectedItemName(Lnet/minecraft/client/gui/GuiGraphics;)V"))
	private void tryRenderSelectedItemName(class_329 instance, class_332 guiGraphics, Operation<Void> original, @Local(argsOnly = true) class_9779 deltaTracker) {
		if (!port_lib$layerManager.callPreRenderEvent(SELECTED_ITEM_NAME, guiGraphics, deltaTracker)) {
			original.call(instance, guiGraphics);
			port_lib$layerManager.callPostRenderEvent(SELECTED_ITEM_NAME, guiGraphics, deltaTracker);
		}
	}

	@WrapOperation(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/spectator/SpectatorGui;renderTooltip(Lnet/minecraft/client/gui/GuiGraphics;)V"))
	private void tryRenderSpectatorTooltip(class_365 instance, class_332 guiGraphics, Operation<Void> original, @Local(argsOnly = true) class_9779 deltaTracker) {
		if (!port_lib$layerManager.callPreRenderEvent(SPECTATOR_TOOLTIP, guiGraphics, deltaTracker)) {
			original.call(instance, guiGraphics);
			port_lib$layerManager.callPostRenderEvent(SPECTATOR_TOOLTIP, guiGraphics, deltaTracker);
		}
	}

	@WrapMethod(method = "renderPlayerHealth")
	private void tryRenderPlayerHealth(class_332 guiGraphics, Operation<Void> original) {
		// TODO: try to split it apart
		if (!port_lib$layerManager.callPreRenderEvent(PLAYER_HEALTH, guiGraphics, minecraft.method_60646())
				&& !port_lib$layerManager.callPreRenderEvent(ARMOR_LEVEL, guiGraphics, minecraft.method_60646())
				&& !port_lib$layerManager.callPreRenderEvent(FOOD_LEVEL, guiGraphics, minecraft.method_60646())
				&& !port_lib$layerManager.callPreRenderEvent(AIR_LEVEL, guiGraphics, minecraft.method_60646())
		) {
			original.call(guiGraphics);
			port_lib$layerManager.callPostRenderEvent(PLAYER_HEALTH, guiGraphics, minecraft.method_60646());
			port_lib$layerManager.callPostRenderEvent(ARMOR_LEVEL, guiGraphics, minecraft.method_60646());
			port_lib$layerManager.callPostRenderEvent(FOOD_LEVEL, guiGraphics, minecraft.method_60646());
			port_lib$layerManager.callPostRenderEvent(AIR_LEVEL, guiGraphics, minecraft.method_60646());
		}

		port_lib$layerManager.renderFrom(PLAYER_HEALTH, guiGraphics, minecraft.method_60646());
		port_lib$layerManager.renderFrom(ARMOR_LEVEL, guiGraphics, minecraft.method_60646());
		port_lib$layerManager.renderFrom(FOOD_LEVEL, guiGraphics, minecraft.method_60646());
		port_lib$layerManager.renderFrom(AIR_LEVEL, guiGraphics, minecraft.method_60646());
	}

	// Main layers
	@WrapMethod(method = "renderCameraOverlays")
	private void tryRenderCameraOverlays(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(CAMERA_OVERLAYS, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapMethod(method = "renderCrosshair")
	private void tryRenderCrosshairs(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(CROSSHAIR, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapMethod(method = "renderExperienceLevel")
	private void tryRenderExperienceLevel(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(EXPERIENCE_LEVEL, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapMethod(method = "renderEffects")
	private void tryRenderEffects(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(EFFECTS, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	// Additional layers
	@WrapMethod(method = "renderDemoOverlay")
	private void tryRenderDemoOverlay(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(DEMO_OVERLAY, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapMethod(method = "method_55807")
	private void tryRenderDebugOverlay(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(DEBUG_OVERLAY, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapMethod(method = "renderScoreboardSidebar")
	private void tryRenderSidebarOverlay(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(SCOREBOARD_SIDEBAR, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapMethod(method = "renderOverlayMessage")
	private void tryRenderOverlayMessage(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(OVERLAY_MESSAGE, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapMethod(method = "renderTitle")
	private void tryRenderTitle(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(TITLE, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapMethod(method = "renderChat")
	private void tryRenderChat(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(CHAT, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapMethod(method = "renderTabList")
	private void tryRenderTabList(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(TAB_LIST, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapMethod(method = "method_55806")
	private void tryRenderSubtitleOverlay(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(SUBTITLE_OVERLAY, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapMethod(method = "renderSavingIndicator")
	private void tryRenderSaving(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(SAVING_INDICATOR, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapMethod(method = "renderSleepOverlay")
	private void tryRenderSleepOverlay(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		port_lib$tryRenderLayer(SLEEP_OVERLAY, guiGraphics, deltaTracker, () -> original.call(guiGraphics, deltaTracker));
	}

	@WrapMethod(method = "render")
	private void callGuiRenderEvents(class_332 guiGraphics, class_9779 deltaTracker, Operation<Void> original) {
		if (RenderGuiCallback.PRE.invoker().preRenderGui(guiGraphics, deltaTracker)) {
			return;
		}

		port_lib$layerManager.renderFrom((GuiLayerManager.NamedLayer) null, guiGraphics, minecraft.method_60646());
		original.call(guiGraphics, deltaTracker);

		RenderGuiCallback.POST.invoker().postRenderGui(guiGraphics, deltaTracker);
	}
}
