package io.github.fabricators_of_create.porting_lib.gui.mixin;

import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_359;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_329.class)
public interface GuiAccessor {
	@Accessor
	class_359 getSubtitleOverlay();

	@Invoker
	void callRenderCameraOverlays(class_332 guiGraphics, class_9779 deltaTracker);

	@Invoker
	void callRenderCrosshair(class_332 guiGraphics, class_9779 deltaTracker);

	@Invoker
	void callRenderExperienceLevel(class_332 guiGraphics, class_9779 deltaTracker);

	@Invoker
	void callRenderEffects(class_332 guiGraphics, class_9779 deltaTracker);

	@Invoker
	void callRenderDemoOverlay(class_332 guiGraphics, class_9779 deltaTracker);

	@Invoker
	void callRenderScoreboardSidebar(class_332 guiGraphics, class_9779 deltaTracker);

	@Invoker
	void callRenderOverlayMessage(class_332 guiGraphics, class_9779 deltaTracker);

	@Invoker
	void callRenderTitle(class_332 guiGraphics, class_9779 deltaTracker);

	@Invoker
	void callRenderChat(class_332 guiGraphics, class_9779 deltaTracker);

	@Invoker
	void callRenderTabList(class_332 guiGraphics, class_9779 deltaTracker);

	@Invoker
	void callRenderSleepOverlay(class_332 guiGraphics, class_9779 deltaTracker);
}
