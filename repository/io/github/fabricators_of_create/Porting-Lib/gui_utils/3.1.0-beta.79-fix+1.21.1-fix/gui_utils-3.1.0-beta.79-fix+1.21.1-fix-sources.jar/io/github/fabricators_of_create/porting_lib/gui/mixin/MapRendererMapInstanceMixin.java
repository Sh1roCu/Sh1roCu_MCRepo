package io.github.fabricators_of_create.porting_lib.gui.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;

import com.llamalad7.mixinextras.sugar.ref.LocalIntRef;

import io.github.fabricators_of_create.porting_lib.gui.map.MapDecorationRendererManager;
import net.minecraft.class_20;
import net.minecraft.class_22;
import net.minecraft.class_330;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_330.class_331.class)
public abstract class MapRendererMapInstanceMixin {

	@Shadow
	private class_22 data;
	@Shadow
	@Final
	private class_330 field_2047;

	// Instead of replacing the iterator just modifyexpression the renderOnFrame call
	@ModifyExpressionValue(method = "draw", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/saveddata/maps/MapDecoration;renderOnFrame()Z"))
	private boolean renderMapDecorationType(boolean original, class_4587 poseStack, class_4597 bufferSource, boolean active, int packedLight, @Local class_20 mapDecoration, @Local(ordinal = 2)LocalIntRef indexRef) {
		if (original) {
			if (MapDecorationRendererManager.render(mapDecoration, poseStack, bufferSource, this.data, this.field_2047.field_50036, active, packedLight, indexRef.get())) {
				indexRef.set(indexRef.get() + 1);
				return false;
			}
		}
		return original;
	}
}
