package io.github.fabricators_of_create.porting_lib.gui.map;

import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.class_20;
import net.minecraft.class_22;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_9428;
import net.minecraft.class_9443;

/**
 * In froge you register these via an event, but on fabric just register them directly via {@link MapDecorationRendererManager#register(class_9428, IMapDecorationRenderer)}.
 */
public final class MapDecorationRendererManager {
	private static final Map<class_9428, IMapDecorationRenderer> RENDERERS = new IdentityHashMap<>();

	private MapDecorationRendererManager() {}

	public static void register(class_9428 type, IMapDecorationRenderer renderer) {
		RENDERERS.put(type, renderer);
	}

	public static boolean render(
			class_20 decoration,
			class_4587 poseStack,
			class_4597 bufferSource,
			class_22 mapData,
			class_9443 decorationTextures,
			boolean inItemFrame,
			int packedLight,
			int index) {
		IMapDecorationRenderer decorationRenderer = RENDERERS.get(decoration.comp_1842().comp_349());
		if (decorationRenderer != null) {
			return decorationRenderer.render(decoration, poseStack, bufferSource, mapData, decorationTextures, inItemFrame, packedLight, index);
		}
		return false;
	}
}
