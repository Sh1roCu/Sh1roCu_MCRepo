package io.github.fabricators_of_create.porting_lib.gui.layered;

import net.minecraft.class_2960;

public class VanillaGuiLayers {
	public static final class_2960 CAMERA_OVERLAYS = class_2960.method_60656("camera_overlays");
	public static final class_2960 CROSSHAIR = class_2960.method_60656("crosshair");
	public static final class_2960 HOTBAR = class_2960.method_60656("hotbar");
	public static final class_2960 JUMP_METER = class_2960.method_60656("jump_meter");
	public static final class_2960 EXPERIENCE_BAR = class_2960.method_60656("experience_bar");
	public static final class_2960 PLAYER_HEALTH = class_2960.method_60656("player_health");
	public static final class_2960 ARMOR_LEVEL = class_2960.method_60656("armor_level");
	public static final class_2960 FOOD_LEVEL = class_2960.method_60656("food_level");
	public static final class_2960 VEHICLE_HEALTH = class_2960.method_60656("vehicle_health");
	public static final class_2960 AIR_LEVEL = class_2960.method_60656("air_level");
	public static final class_2960 SELECTED_ITEM_NAME = class_2960.method_60656("selected_item_name");
	public static final class_2960 SPECTATOR_TOOLTIP = class_2960.method_60656("spectator_tooltip");
	public static final class_2960 EXPERIENCE_LEVEL = class_2960.method_60656("experience_level");
	public static final class_2960 EFFECTS = class_2960.method_60656("effects");
	public static final class_2960 BOSS_OVERLAY = class_2960.method_60656("boss_overlay");
	public static final class_2960 SLEEP_OVERLAY = class_2960.method_60656("sleep_overlay");
	public static final class_2960 DEMO_OVERLAY = class_2960.method_60656("demo_overlay");
	public static final class_2960 DEBUG_OVERLAY = class_2960.method_60656("debug_overlay");
	public static final class_2960 SCOREBOARD_SIDEBAR = class_2960.method_60656("scoreboard_sidebar");
	public static final class_2960 OVERLAY_MESSAGE = class_2960.method_60656("overlay_message");
	public static final class_2960 TITLE = class_2960.method_60656("title");
	public static final class_2960 CHAT = class_2960.method_60656("chat");
	public static final class_2960 TAB_LIST = class_2960.method_60656("tab_list");
	public static final class_2960 SUBTITLE_OVERLAY = class_2960.method_60656("subtitle_overlay");
	public static final class_2960 SAVING_INDICATOR = class_2960.method_60656("saving_indicator");
}
