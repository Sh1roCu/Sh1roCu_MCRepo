package io.github.fabricators_of_create.porting_lib.gui.map;

import net.minecraft.class_20;
import net.minecraft.class_22;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_9443;

/**
 * Interface for custom {@link class_20} renderers
 */
public interface IMapDecorationRenderer {
	/**
	 * Render the given {@link class_20} on the map. If this method returns true, the vanilla rendering will be
	 * canceled. Otherwise, it will render above whatever is rendered in this method, if anything
	 *
	 * @param decoration         The decoration to be rendered
	 * @param poseStack          The {@link class_4587} to render the decoration with
	 * @param bufferSource       The {@link class_4597} to render the decoration with
	 * @param mapData            The data of the map being rendered
	 * @param decorationTextures The manager holding map decoration sprites
	 * @param inItemFrame        Whether the map is being rendered in an item frame
	 * @param packedLight        The packed light value
	 * @param index              The z index of the decoration being rendered
	 * @return true to cancel vanilla rendering
	 */
	boolean render(
			class_20 decoration,
			class_4587 poseStack,
			class_4597 bufferSource,
			class_22 mapData,
			class_9443 decorationTextures,
			boolean inItemFrame,
			int packedLight,
			int index);
}
