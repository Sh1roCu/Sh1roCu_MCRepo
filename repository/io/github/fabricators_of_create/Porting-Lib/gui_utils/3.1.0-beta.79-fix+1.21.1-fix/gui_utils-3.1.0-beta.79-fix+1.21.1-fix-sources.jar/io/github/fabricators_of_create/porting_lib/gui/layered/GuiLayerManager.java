package io.github.fabricators_of_create.porting_lib.gui.layered;

import com.google.common.base.Preconditions;
import io.github.fabricators_of_create.porting_lib.gui.events.RenderGuiCallback;
import io.github.fabricators_of_create.porting_lib.gui.events.RenderGuiLayerCallback;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.OptionalInt;
import java.util.function.BooleanSupplier;
import java.util.function.UnaryOperator;
import java.util.stream.IntStream;
import net.minecraft.class_2960;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9080;
import net.minecraft.class_9080.class_9081;
import net.minecraft.class_9779;

/**
 * Adaptation of {@link class_9080} that is used for {@link class_329} rendering specifically,
 * to give layers a name and fire appropriate events.
 *
 * <p>Overlays can be registered using the {@link GuiLayerRegistry}.
 */
@ApiStatus.Internal
public class GuiLayerManager {
	public static final float Z_SEPARATION = class_9080.field_47848;
	private final List<NamedLayer> layers = new ArrayList<>();

	public record NamedLayer(class_2960 name, class_9080.class_9081 layer, boolean isVanilla) {
		public NamedLayer(class_2960 name, class_9080.class_9081 layer) {
			this(name, layer, false);
		}
	}

	public GuiLayerManager add(class_2960 name, class_9080.class_9081 layer) {
		this.layers.add(new NamedLayer(name, layer));
		return this;
	}

	public GuiLayerManager add(class_2960 name, class_9080.class_9081 layer, boolean isVanilla) {
		this.layers.add(new NamedLayer(name, layer, isVanilla));
		return this;
	}

	public GuiLayerManager add(GuiLayerManager child, BooleanSupplier shouldRender) {
		// Flatten the layers to allow mods to insert layers between vanilla layers.
		for (var entry : child.layers) {
			add(entry.name(), (guiGraphics, partialTick) -> {
				if (shouldRender.getAsBoolean()) {
					entry.layer().render(guiGraphics, partialTick);
				}
			}, entry.isVanilla());
		}
		return this;
	}

	public GuiLayerManager addVanilla(class_2960 name) {
		add(name, (guiGraphics, deltaTracker) -> {}, true);
		return this;
	}

	public GuiLayerManager addVanilla(class_2960 name, class_9080.class_9081 layer) {
		add(name, layer, true);
		return this;
	}

	// Doesn't actually get called, but if another mod for whatever reason uses this, welp.
	public void render(class_332 guiGraphics, class_9779 partialTick) {
		if (RenderGuiCallback.PRE.invoker().preRenderGui(guiGraphics, partialTick)) {
			return;
		}

		renderInner(guiGraphics, partialTick);

		RenderGuiCallback.POST.invoker().postRenderGui(guiGraphics, partialTick);
	}

	private void renderInner(class_332 guiGraphics, class_9779 partialTick) {
		guiGraphics.method_51448().method_22903();

		for (var layer : this.layers) {
			renderLayer(guiGraphics, partialTick, layer);
		}

		guiGraphics.method_51448().method_22909();
	}

	/**
	 * Renders layers starting from one render layer until the next Vanilla layer is reached.
	 * @param start The ID of the rendering layer to start from
	 */
	public void renderFrom(class_2960 start, class_332 guiGraphics, class_9779 partialTick) {
		NamedLayer startingLayer = getLayer(start);
		if (startingLayer == null) {
			throw new IllegalArgumentException("Layer " + start + " does not exist!");
		}

		renderFrom(startingLayer, guiGraphics, partialTick);
	}

	public void renderFrom(NamedLayer startingLayer, class_332 guiGraphics, class_9779 partialTick) {
		guiGraphics.method_51448().method_22903();
		boolean hasStartedRendering = false;

		for (NamedLayer layer : layers) {
			if (layer == startingLayer || startingLayer == null) {
				hasStartedRendering = true;
			}

			if (!hasStartedRendering) {
				continue;
			}

			// Stop rendering entirely if this layer is a Vanilla layer that isn't the starting layer.
			if (layer.isVanilla() && layer != startingLayer) {
				break;
			}

			// Render only non-Vanilla layers - we may end up double-rendering otherwise.
			if (!layer.isVanilla()) {
				renderLayer(guiGraphics, partialTick, layer);
			}
		}
		guiGraphics.method_51448().method_22909();
	}

	public boolean callPreRenderEvent(class_2960 id, class_332 guiGraphics, class_9779 partialTick) {
		NamedLayer layer = getLayer(id);

		if (layer == null) {
			throw new IllegalArgumentException("Layer " + id + " does not exist!");
		}

		return RenderGuiLayerCallback.PRE.invoker().preRenderGuiLayer(guiGraphics, partialTick, layer.name(), layer.layer());
	}

	public void callPostRenderEvent(class_2960 id, class_332 guiGraphics, class_9779 partialTick) {
		NamedLayer layer = getLayer(id);

		if (layer == null) {
			throw new IllegalArgumentException("Layer " + id + " does not exist!");
		}

		RenderGuiLayerCallback.POST.invoker().postRenderGuiLayer(guiGraphics, partialTick, layer.name(), layer.layer());
	}

	private void renderLayer(class_332 guiGraphics, class_9779 partialTick, NamedLayer layer) {
		if (!RenderGuiLayerCallback.PRE.invoker().preRenderGuiLayer(guiGraphics, partialTick, layer.name(), layer.layer())) {
			layer.layer().render(guiGraphics, partialTick);
			RenderGuiLayerCallback.POST.invoker().postRenderGuiLayer(guiGraphics, partialTick, layer.name(), layer.layer());
		}

		guiGraphics.method_51448().method_46416(0.0F, 0.0F, Z_SEPARATION);
	}

	public NamedLayer getLayer(class_2960 id) {
		for (NamedLayer layer : layers) {
			if (layer.name().equals(id)) {
				return layer;
			}
		}

		return null;
	}

	public int getLayerCount() {
		return layers.size();
	}

	/**
	 * Wrap the layer with the given {@code id} in a new layer.
	 * <p>
	 * This can be used, for instance, to apply pose stack transformations to move the layer or resize it.
	 *
	 * @param id      the id of the layer to wrap
	 * @param wrapper an unary operator which takes in the old layer and returns the new layer that wraps the old one
	 * @throws IllegalArgumentException if a layer with the given {@code id} is not yet registered
	 */
	public void wrapLayer(class_2960 id, UnaryOperator<class_9080.class_9081> wrapper) {
		Objects.requireNonNull(id);
		Objects.requireNonNull(wrapper);

		for (int i = 0; i < layers.size(); i++) {
			var layer = layers.get(i);
			if (layer.name().equals(id)) {
				var wrapped = wrapper.apply(layer.layer());
				Objects.requireNonNull(wrapped, "wrapping layer must not be null");
				layers.set(i, new GuiLayerManager.NamedLayer(id, wrapped));
				return;
			}
		}

		throw new IllegalArgumentException("Attempted to wrap layer with id '" + id + "', which does not exist!");
	}

	public void register(GuiLayerRegistry.Ordering ordering, @Nullable class_2960 other, class_2960 key, class_9080.class_9081 layer) {
		Objects.requireNonNull(key);
		for (var namedLayer : layers) {
			Preconditions.checkArgument(!namedLayer.name().equals(key), "Layer already registered: " + key);
		}

		int insertPosition;
		if (other == null) {
			insertPosition = ordering == GuiLayerRegistry.Ordering.BEFORE ? 0 : layers.size();
		} else {
			var otherIndex = IntStream.range(0, layers.size())
					.filter(i -> layers.get(i).name().equals(other))
					.findFirst();
			if (otherIndex.isEmpty()) {
				throw new IllegalArgumentException("Attempted to order against an unregistered layer " + other + ". Only order against vanilla's and your own.");
			}

			insertPosition = otherIndex.getAsInt() + (ordering == GuiLayerRegistry.Ordering.BEFORE ? 0 : 1);
		}

		layers.add(insertPosition, new GuiLayerManager.NamedLayer(key, layer));
	}
}
