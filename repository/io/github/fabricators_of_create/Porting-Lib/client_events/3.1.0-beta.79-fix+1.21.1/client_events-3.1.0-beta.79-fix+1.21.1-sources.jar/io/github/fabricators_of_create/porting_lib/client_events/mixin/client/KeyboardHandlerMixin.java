package io.github.fabricators_of_create.porting_lib.client_events.mixin.client;

import io.github.fabricators_of_create.porting_lib.client_events.event.client.InputEvent;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class KeyboardHandlerMixin {
	@Shadow
	@Final
	private class_310 minecraft;

	@Inject(method = "keyPress", at = @At("TAIL"))
	private void port_lib$onKeyPressEvent(long windowPointer, int key, int scanCode, int action, int modifiers, CallbackInfo ci) {
		if (windowPointer == minecraft.method_22683().method_4490()) {
			new InputEvent.Key(key, scanCode, action, modifiers).sendEvent();
		}
	}
}
