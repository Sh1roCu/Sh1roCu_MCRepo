package io.github.fabricators_of_create.porting_lib.client_events.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import com.llamalad7.mixinextras.sugar.Share;

import com.llamalad7.mixinextras.sugar.ref.LocalRef;

import io.github.fabricators_of_create.porting_lib.client_events.event.client.InputEvent;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3965;
import net.minecraft.class_702;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public abstract class MinecraftMixin {
	@Shadow
	@Final
	public class_315 options;

	@Shadow
	@Final
	public class_702 particleEngine;

	@Shadow
	@Nullable
	public class_746 player;

	@Unique
	private InputEvent.InteractionKeyMappingTriggered port_lib$onClickInput(int button, class_304 keyMapping, class_1268 hand) {
		InputEvent.InteractionKeyMappingTriggered event = new InputEvent.InteractionKeyMappingTriggered(button, keyMapping, hand);
		event.sendEvent();
		return event;
	}

	@Inject(method = "continueAttack", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/phys/BlockHitResult;getDirection()Lnet/minecraft/core/Direction;"), cancellable = true)
	private void port_lib$onClickInputEvent(boolean leftClick, CallbackInfo ci, @Local class_3965 blockHitResult, @Local class_2338 blockPos, @Share("event") LocalRef<InputEvent.InteractionKeyMappingTriggered> eventRef) {
		InputEvent.InteractionKeyMappingTriggered inputEvent = port_lib$onClickInput(0, this.options.field_1886, class_1268.field_5808);
		eventRef.set(inputEvent);
		if (inputEvent.isCanceled()) {
			if (inputEvent.shouldSwingHand()) {
				this.particleEngine.method_3054(blockPos, blockHitResult.method_17780());
				this.player.method_6104(class_1268.field_5808);
			}
			ci.cancel();
		}
	}

	@ModifyExpressionValue(method = "continueAttack", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/MultiPlayerGameMode;continueDestroyBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)Z"))
	private boolean port_lib$checkHandSwing(boolean original, @Share("event") LocalRef<InputEvent.InteractionKeyMappingTriggered> eventRef) {
		return original && eventRef.get().shouldSwingHand();
	}

	@Inject(method = "startAttack", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/phys/HitResult;getType()Lnet/minecraft/world/phys/HitResult$Type;"), cancellable = true)
	private void port_lib$onAttackClickInputEvent(CallbackInfoReturnable<Boolean> cir, @Share("inputEvent") LocalRef<InputEvent.InteractionKeyMappingTriggered> inputEvent, @Local boolean flag) {
		inputEvent.set(port_lib$onClickInput(0, this.options.field_1886, class_1268.field_5808));

		if (inputEvent.get().isCanceled()) {
			if (inputEvent.get().shouldSwingHand())
				this.player.method_6104(class_1268.field_5808);

			cir.setReturnValue(flag);
		}
	}

	@WrapWithCondition(method = "startAttack", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;swing(Lnet/minecraft/world/InteractionHand;)V"))
	private boolean port_lib$swingHandIfEventPermits(class_746 instance, class_1268 interactionHand, @Share("inputEvent") LocalRef<InputEvent.InteractionKeyMappingTriggered> inputEvent) {
		return inputEvent.get() == null || inputEvent.get().shouldSwingHand();
	}

	@Inject(method = "startUseItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;getItemInHand(Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/item/ItemStack;", ordinal = 0), cancellable = true)
	private void port_lib$callForgeUseInputEvent(CallbackInfo ci, @Share("inputEvent") LocalRef<InputEvent.InteractionKeyMappingTriggered> inputEvent, @Local class_1268 hand) {
		inputEvent.set(port_lib$onClickInput(1, this.options.field_1904, hand));

		if (inputEvent.get().isCanceled()) {
			if (inputEvent.get().shouldSwingHand())
				this.player.method_6104(hand);

			ci.cancel();
		}
	}

	@ModifyExpressionValue(method = "startUseItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/InteractionResult;shouldSwing()Z"))
	private boolean port_lib$onlySwingHandIfNeeded(boolean original, @Share("inputEvent") LocalRef<InputEvent.InteractionKeyMappingTriggered> inputEvent) {
		return original && (inputEvent.get() == null || inputEvent.get().shouldSwingHand());
	}

	@Inject(method = "pickBlock", at = @At(value = "FIELD", target = "Lnet/minecraft/world/entity/player/Abilities;instabuild:Z", ordinal = 0), cancellable = true)
	private void port_lib$callInteractionPickInput(CallbackInfo ci) {
		if (port_lib$onClickInput(2, this.options.field_1871, class_1268.field_5808).isCanceled())
			ci.cancel();
	}
}
