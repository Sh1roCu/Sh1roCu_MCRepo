package io.github.fabricators_of_create.porting_lib.client_events.event.client;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1268;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.jetbrains.annotations.ApiStatus;
import org.lwjgl.glfw.GLFW;

/**
 * Fired when an input is detected from the user's input devices.
 * See the various subclasses to listen for specific devices and inputs.
 *
 * @see InputEvent.MouseButton
 * @see MouseScrollingEvent
 * @see Key
 * @see InteractionKeyMappingTriggered
 */
public abstract class InputEvent extends BaseEvent {
	@ApiStatus.Internal
	protected InputEvent() {}

	/**
	 * Fired when a mouse button is pressed/released. Sub-events get fired {@link Pre before} and {@link Post after} this happens.
	 *
	 * <p>These events are fired only on the {@linkplain EnvType#CLIENT logical client}.</p>
	 *
	 * @see <a href="https://www.glfw.org/docs/latest/input_guide.html#input_mouse_button" target="_top">the online GLFW documentation</a>
	 * @see Pre
	 * @see Post
	 */
	public static abstract class MouseButton extends InputEvent {
		private final int button;
		private final int action;
		private final int modifiers;

		@ApiStatus.Internal
		protected MouseButton(int button, int action, int modifiers) {
			this.button = button;
			this.action = action;
			this.modifiers = modifiers;
		}

		/**
		 * {@return the mouse button's input code}
		 *
		 * @see GLFW mouse constants starting with 'GLFW_MOUSE_BUTTON_'
		 * @see <a href="https://www.glfw.org/docs/latest/group__buttons.html" target="_top">the online GLFW documentation</a>
		 */
		public int getButton() {
			return this.button;
		}

		/**
		 * {@return the mouse button's action}
		 *
		 * @see class_3675#field_31997
		 * @see class_3675#field_31998
		 */
		public int getAction() {
			return this.action;
		}

		/**
		 * {@return a bit field representing the active modifier keys}
		 *
		 * @see class_3675#field_32003 CTRL modifier key bit
		 * @see GLFW#GLFW_MOD_SHIFT SHIFT modifier key bit
		 * @see GLFW#GLFW_MOD_ALT ALT modifier key bit
		 * @see GLFW#GLFW_MOD_SUPER SUPER modifier key bit
		 * @see GLFW#GLFW_KEY_CAPS_LOCK CAPS LOCK modifier key bit
		 * @see GLFW#GLFW_KEY_NUM_LOCK NUM LOCK modifier key bit
		 * @see <a href="https://www.glfw.org/docs/latest/group__mods.html" target="_top">the online GLFW documentation</a>
		 */
		public int getModifiers() {
			return this.modifiers;
		}

		/**
		 * Fired when a mouse button is pressed/released, <b>before</b> being processed by vanilla.
		 *
		 * <p>This event is {@linkplain CancellableEvent cancellable}, and does not have a result.
		 * If the event is cancelled, then the mouse event will not be processed by vanilla (e.g. keymappings and screens) </p>
		 *
		 * <p>This event is fired only on the {@linkplain EnvType#CLIENT logical client}.</p>
		 *
		 * @see <a href="https://www.glfw.org/docs/latest/input_guide.html#input_mouse_button" target="_top">the online GLFW documentation</a>
		 */
		public static class Pre extends MouseButton implements CancellableEvent {
			@ApiStatus.Internal
			public Pre(int button, int action, int modifiers) {
				super(button, action, modifiers);
			}

			public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
				for (Callback callback : callbacks) {
					callback.onMouseButtonPre(event);
				}
			});

			@Override
			public void sendEvent() {
				EVENT.invoker().onMouseButtonPre(this);
			}

			public interface Callback {
				void onMouseButtonPre(Pre event);
			}
		}

		/**
		 * Fired when a mouse button is pressed/released, <b>after</b> processing.
		 *
		 * <p>This event is not {@linkplain CancellableEvent cancellable}, and does not have a result.</p>
		 *
		 * <p>This event is fired only on the {@linkplain EnvType#CLIENT logical client}.</p>
		 *
		 * @see <a href="https://www.glfw.org/docs/latest/input_guide.html#input_mouse_button" target="_top">the online GLFW documentation</a>
		 */
		public static class Post extends MouseButton {
			@ApiStatus.Internal
			public Post(int button, int action, int modifiers) {
				super(button, action, modifiers);
			}

			public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
				for (Callback callback : callbacks) {
					callback.onMouseButtonPost(event);
				}
			});

			@Override
			public void sendEvent() {
				EVENT.invoker().onMouseButtonPost(this);
			}

			public interface Callback {
				void onMouseButtonPost(Post event);
			}
		}
	}

	/**
	 * Fired when a mouse scroll wheel is used outside of a screen and a player is loaded, <b>before</b> being
	 * processed by vanilla.
	 *
	 * <p>This event is {@linkplain CancellableEvent cancellable}, and does not have a result.
	 * If the event is cancelled, then the mouse scroll event will not be processed further.</p>
	 *
	 * <p>This event is fired only on the {@linkplain EnvType#CLIENT logical client}.</p>
	 *
	 * @see <a href="https://www.glfw.org/docs/latest/input_guide.html#input_mouse_button" target="_top">the online GLFW documentation</a>
	 */
	public static class MouseScrollingEvent extends InputEvent implements CancellableEvent {
		private final double scrollDeltaX;
		private final double scrollDeltaY;
		private final double mouseX;
		private final double mouseY;
		private final boolean leftDown;
		private final boolean middleDown;
		private final boolean rightDown;

		@ApiStatus.Internal
		public MouseScrollingEvent(double scrollDeltaX, double scrollDeltaY, boolean leftDown, boolean middleDown, boolean rightDown, double mouseX, double mouseY) {
			this.scrollDeltaX = scrollDeltaX;
			this.scrollDeltaY = scrollDeltaY;
			this.leftDown = leftDown;
			this.middleDown = middleDown;
			this.rightDown = rightDown;
			this.mouseX = mouseX;
			this.mouseY = mouseY;
		}

		/**
		 * {@return the amount of change / delta of the mouse scroll on the X axis}
		 */
		public double getScrollDeltaX() {
			return this.scrollDeltaX;
		}

		/**
		 * {@return the amount of change / delta of the mouse scroll on the Y axis}
		 */
		public double getScrollDeltaY() {
			return this.scrollDeltaY;
		}

		/**
		 * {@return {@code true} if the left mouse button is pressed}
		 */
		public boolean isLeftDown() {
			return this.leftDown;
		}

		/**
		 * {@return {@code true} if the right mouse button is pressed}
		 */
		public boolean isRightDown() {
			return this.rightDown;
		}

		/**
		 * {@return {@code true} if the middle mouse button is pressed}
		 */
		public boolean isMiddleDown() {
			return this.middleDown;
		}

		/**
		 * {@return the X position of the mouse cursor}
		 */
		public double getMouseX() {
			return this.mouseX;
		}

		/**
		 * {@return the Y position of the mouse cursor}
		 */
		public double getMouseY() {
			return this.mouseY;
		}

		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks) {
				callback.onMouseScroll(event);
			}
		});

		@Override
		public void sendEvent() {
			EVENT.invoker().onMouseScroll(this);
		}

		public interface Callback {
			void onMouseScroll(MouseScrollingEvent event);
		}
	}

	/**
	 * Fired when a keyboard key input occurs, such as pressing, releasing, or repeating a key.
	 *
	 * <p>This event is not {@linkplain CancellableEvent cancellable}, and does not have a result.</p>
	 *
	 * <p>This event is fired only on the {@linkplain EnvType#CLIENT logical client}.</p>
	 */
	public static class Key extends InputEvent {
		private final int key;
		private final int scanCode;
		private final int action;
		private final int modifiers;

		@ApiStatus.Internal
		public Key(int key, int scanCode, int action, int modifiers) {
			this.key = key;
			this.scanCode = scanCode;
			this.action = action;
			this.modifiers = modifiers;
		}

		/**
		 * {@return the {@code GLFW} (platform-agnostic) key code}
		 *
		 * @see class_3675 input constants starting with {@code KEY_}
		 * @see GLFW key constants starting with {@code GLFW_KEY_}
		 * @see <a href="https://www.glfw.org/docs/latest/group__keys.html" target="_top">the online GLFW documentation</a>
		 */
		public int getKey() {
			return this.key;
		}

		/**
		 * {@return the platform-specific scan code}
		 * <p>
		 * The scan code is unique for every key, regardless of whether it has a key code.
		 * Scan codes are platform-specific but consistent over time, so keys will have different scan codes depending
		 * on the platform but they are safe to save to disk as custom key bindings.
		 *
		 * @see class_3675#method_15985(int, int)
		 */
		public int getScanCode() {
			return this.scanCode;
		}

		/**
		 * {@return the mouse button's action}
		 *
		 * @see class_3675#field_31997
		 * @see class_3675#field_31998
		 * @see class_3675#field_31999
		 */
		public int getAction() {
			return this.action;
		}

		/**
		 * {@return a bit field representing the active modifier keys}
		 *
		 * @see class_3675#field_32003 CTRL modifier key bit
		 * @see GLFW#GLFW_MOD_SHIFT SHIFT modifier key bit
		 * @see GLFW#GLFW_MOD_ALT ALT modifier key bit
		 * @see GLFW#GLFW_MOD_SUPER SUPER modifier key bit
		 * @see GLFW#GLFW_KEY_CAPS_LOCK CAPS LOCK modifier key bit
		 * @see GLFW#GLFW_KEY_NUM_LOCK NUM LOCK modifier key bit
		 * @see <a href="https://www.glfw.org/docs/latest/group__mods.html" target="_top">the online GLFW documentation</a>
		 */
		public int getModifiers() {
			return this.modifiers;
		}

		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks) {
				callback.onKeyInput(event);
			}
		});

		@Override
		public void sendEvent() {
			EVENT.invoker().onKeyInput(this);
		}

		public interface Callback {
			void onKeyInput(Key event);
		}
	}

	/**
	 * Fired when a keymapping that by default involves clicking the mouse buttons is triggered.
	 *
	 * <p>The key bindings that trigger this event are:</p>
	 * <ul>
	 * <li><b>Use Item</b> - defaults to <em>left mouse click</em></li>
	 * <li><b>Pick Block</b> - defaults to <em>middle mouse click</em></li>
	 * <li><b>Attack</b> - defaults to <em>right mouse click</em></li>
	 * </ul>
	 *
	 * <p>This event is {@linkplain CancellableEvent cancellable}, and does not have a result.
	 * If this event is cancelled, then the keymapping's action is not processed further, and the hand will be swung
	 * according to {@link #shouldSwingHand()}.</p>
	 *
	 * <p>This event is fired only on the {@linkplain EnvType#CLIENT logical client}.</p>
	 */
	public static class InteractionKeyMappingTriggered extends InputEvent implements CancellableEvent {
		private final int button;
		private final class_304 keyMapping;
		private final class_1268 hand;
		private boolean handSwing = true;

		@ApiStatus.Internal
		public InteractionKeyMappingTriggered(int button, class_304 keyMapping, class_1268 hand) {
			this.button = button;
			this.keyMapping = keyMapping;
			this.hand = hand;
		}

		/**
		 * Sets whether to swing the hand. This takes effect whether or not the event is cancelled.
		 *
		 * @param value whether to swing the hand
		 */
		public void setSwingHand(boolean value) {
			handSwing = value;
		}

		/**
		 * {@return whether to swing the hand; always takes effect, regardless of cancellation}
		 */
		public boolean shouldSwingHand() {
			return handSwing;
		}

		/**
		 * {@return the hand that caused the input}
		 * <p>
		 * The event will be called for both hands if this is a use item input regardless
		 * of both event's cancellation.
		 * Will always be {@link class_1268#field_5808} if this is an attack or pick block input.
		 */
		public class_1268 getHand() {
			return hand;
		}

		/**
		 * {@return {@code true} if the mouse button is the left mouse button}
		 */
		public boolean isAttack() {
			return button == 0;
		}

		/**
		 * {@return {@code true} if the mouse button is the right mouse button}
		 */
		public boolean isUseItem() {
			return button == 1;
		}

		/**
		 * {@return {@code true} if the mouse button is the middle mouse button}
		 */
		public boolean isPickBlock() {
			return button == 2;
		}

		/**
		 * {@return the key mapping which triggered this event}
		 */
		public class_304 getKeyMapping() {
			return keyMapping;
		}

		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks) {
				callback.onInteractionKeyMappingTriggered(event);
			}
		});

		@Override
		public void sendEvent() {
			EVENT.invoker().onInteractionKeyMappingTriggered(this);
		}

		public interface Callback {
			void onInteractionKeyMappingTriggered(InteractionKeyMappingTriggered event);
		}
	}
}
