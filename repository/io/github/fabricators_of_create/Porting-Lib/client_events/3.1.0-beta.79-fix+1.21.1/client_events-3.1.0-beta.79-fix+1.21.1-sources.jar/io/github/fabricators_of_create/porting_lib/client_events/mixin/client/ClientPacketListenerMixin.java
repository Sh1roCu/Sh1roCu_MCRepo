package io.github.fabricators_of_create.porting_lib.client_events.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import io.github.fabricators_of_create.porting_lib.client_events.event.client.ClientPlayerNetworkCloneCallback;
import net.minecraft.class_1297;
import net.minecraft.class_2535;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_746;
import net.minecraft.class_8673;
import net.minecraft.class_8675;

@Mixin(class_634.class)
public abstract class ClientPacketListenerMixin extends class_8673 {
	protected ClientPacketListenerMixin(class_310 client, class_2535 connection, class_8675 commonListenerCookie) {
		super(client, connection, commonListenerCookie);
	}

	@ModifyArg(
			method = "handleRespawn",
			at = @At(value = "INVOKE",
					target = "Lnet/minecraft/client/multiplayer/ClientLevel;addEntity(Lnet/minecraft/world/entity/Entity;)V"
			)
	)
	private class_1297 onClientPlayerRespawn(class_1297 entity, @Local(ordinal = 0) class_746 oldPlayer) {
		class_746 newPlayer = (class_746) entity;
		ClientPlayerNetworkCloneCallback.EVENT.invoker().onPlayerRespawn(this.field_45588.field_1761, oldPlayer, newPlayer, this.field_45589);
		return entity;
	}
}
