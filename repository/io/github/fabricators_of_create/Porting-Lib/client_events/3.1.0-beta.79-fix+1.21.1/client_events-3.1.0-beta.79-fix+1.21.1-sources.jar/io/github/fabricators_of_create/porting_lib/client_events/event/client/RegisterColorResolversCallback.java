package io.github.fabricators_of_create.porting_lib.client_events.event.client;

import com.google.common.collect.ImmutableList;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_6539;
import org.jetbrains.annotations.ApiStatus;

public interface RegisterColorResolversCallback {
	Event<RegisterColorResolversCallback> EVENT = EventFactory.createArrayBacked(RegisterColorResolversCallback.class, callbacks -> registrationHelper -> {
		for (RegisterColorResolversCallback e : callbacks)
			e.onColorResolverCreation(registrationHelper);
	});

	class RegistrationHelper {
		private final ImmutableList.Builder<class_6539> builder = ImmutableList.builder();
		public void register(class_6539 resolver) {
			this.builder.add(resolver);
		}

		@ApiStatus.Internal
		public ImmutableList<class_6539> build() {
			return builder.build();
		}
	}

	void onColorResolverCreation(RegistrationHelper registrationHelper);
}
