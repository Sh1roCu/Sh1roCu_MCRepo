package io.github.fabricators_of_create.porting_lib.client_events;

import com.google.common.collect.ImmutableMap;

import io.github.fabricators_of_create.porting_lib.client_events.event.client.RegisterEntitySpectatorShadersCallback;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_2960;

public class EntityShaderManager {
	private static final Map<class_1299<?>, class_2960> SHADERS;

	/**
	 * Finds the path to the spectator mode shader used for the specified entity type, or null if none is registered.
	 */
	@Nullable
	public static class_2960 get(class_1299<?> entityType) {
		return SHADERS.get(entityType);
	}

	static {
		var shaders = new HashMap<class_1299<?>, class_2960>();
		RegisterEntitySpectatorShadersCallback.EVENT.invoker().registerCustomShaders(shaders);
		SHADERS = ImmutableMap.copyOf(shaders);
	}
}
