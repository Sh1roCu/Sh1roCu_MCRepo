package io.github.fabricators_of_create.porting_lib.client_events.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import io.github.fabricators_of_create.porting_lib.client_events.event.client.ComputeFovModifierEvent;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_742.class)
public abstract class AbstractClientPlayerMixin {
	@ModifyReturnValue(method = "getFieldOfViewModifier", at = @At("RETURN"))
	private float port_lib$modifyFovModifier(float original) {
		var event = new ComputeFovModifierEvent((class_742) (Object) this, original);
		event.sendEvent();

		return event.getNewFovModifier();
	}
}
