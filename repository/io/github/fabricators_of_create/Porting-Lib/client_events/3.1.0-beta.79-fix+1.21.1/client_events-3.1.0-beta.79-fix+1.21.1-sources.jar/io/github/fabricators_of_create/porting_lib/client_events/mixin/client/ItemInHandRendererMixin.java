package io.github.fabricators_of_create.porting_lib.client_events.mixin.client;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import io.github.fabricators_of_create.porting_lib.client_events.ClientEventHooks;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_759.class)
public class ItemInHandRendererMixin {
	@Shadow
	private class_1799 mainHandItem;

	@WrapWithCondition(method = "renderHandsWithItems", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderArmWithItem(Lnet/minecraft/client/player/AbstractClientPlayer;FFLnet/minecraft/world/InteractionHand;FLnet/minecraft/world/item/ItemStack;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", ordinal = 0))
	private boolean renderMainArmEvent(class_759 instance, class_742 abstractClientPlayer, float partialTick, float interpPitch, class_1268 interactionHand, float swingProgress, class_1799 itemStack, float equipProgress, class_4587 poseStack, class_4597 multiBufferSource, int packedLight) {
		return !ClientEventHooks.renderSpecificFirstPersonHand(class_1268.field_5808, poseStack, multiBufferSource, packedLight, partialTick, interpPitch, swingProgress, equipProgress, itemStack);
	}

	@WrapWithCondition(method = "renderHandsWithItems", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderArmWithItem(Lnet/minecraft/client/player/AbstractClientPlayer;FFLnet/minecraft/world/InteractionHand;FLnet/minecraft/world/item/ItemStack;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", ordinal = 1))
	private boolean renderOffArmEvent(class_759 instance, class_742 abstractClientPlayer, float partialTick, float interpPitch, class_1268 interactionHand, float swingProgress, class_1799 itemStack, float equipProgress, class_4587 poseStack, class_4597 multiBufferSource, int packedLight) {
		return !ClientEventHooks.renderSpecificFirstPersonHand(class_1268.field_5810, poseStack, multiBufferSource, packedLight, partialTick, interpPitch, swingProgress, equipProgress, itemStack);
	}
}
