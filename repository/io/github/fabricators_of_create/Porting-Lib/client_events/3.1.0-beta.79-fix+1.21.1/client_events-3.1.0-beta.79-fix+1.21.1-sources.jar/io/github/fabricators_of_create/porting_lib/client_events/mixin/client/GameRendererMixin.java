package io.github.fabricators_of_create.porting_lib.client_events.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.client_events.EntityShaderManager;
import io.github.fabricators_of_create.porting_lib.client_events.event.client.ViewportEvent;
import io.github.fabricators_of_create.porting_lib.client_events.event.client.ViewportEvent.ComputeFov;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public abstract class GameRendererMixin {
	@Shadow
	abstract void loadEffect(class_2960 resourceLocation);

	@Inject(method = "checkEntityPostEffect", at = @At("TAIL"))
	private void addCustomShader(class_1297 entity, CallbackInfo ci) {
		if (entity != null) {
			var shader = EntityShaderManager.get(entity.method_5864());
			if (shader != null)
				loadEffect(shader);
		}
	}

	@ModifyReturnValue(method = "getFov", at = @At(value = "RETURN", ordinal = 1))
	private double port_lib$invokeFovEvent(double original, @Local(argsOnly = true) class_4184 camera, @Local(argsOnly = true) float partialTicks, @Local(argsOnly = true) boolean useConfigured) {
		var event = new ViewportEvent.ComputeFov((class_757) (Object) this, camera, partialTicks, original, useConfigured);
		event.sendEvent();

		return event.getFOV();
	}
}
