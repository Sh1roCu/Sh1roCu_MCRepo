package io.github.fabricators_of_create.porting_lib.client_events.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.client_events.event.client.EntityRenderersEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_3300;
import net.minecraft.class_5617;
import net.minecraft.class_8685;
import net.minecraft.class_897;
import net.minecraft.class_898;

@Mixin(class_898.class)
public abstract class EntityRenderDispatcherMixin {
	@Shadow
	private Map<class_1299<?>, class_897<?>> renderers;

	@Shadow
	private Map<class_8685.class_7920, class_897<? extends class_1657>> playerRenderers;

	@Inject(method = "onResourceManagerReload", at = @At("TAIL"))
	public void port_lib$resourceReload(class_3300 resourceManager, CallbackInfo ci, @Local class_5617.class_5618 context) {
		EntityRenderersEvent.AddLayers event = new EntityRenderersEvent.AddLayers(renderers, playerRenderers, context);
		event.sendEvent();
	}
}

