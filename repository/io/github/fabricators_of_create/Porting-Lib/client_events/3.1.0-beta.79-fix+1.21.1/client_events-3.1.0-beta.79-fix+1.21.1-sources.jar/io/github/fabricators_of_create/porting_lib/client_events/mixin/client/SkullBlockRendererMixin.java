package io.github.fabricators_of_create.porting_lib.client_events.mixin.client;

import com.google.common.collect.ImmutableMap;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.client_events.event.client.EntityRenderersEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import net.minecraft.class_2484;
import net.minecraft.class_5598;
import net.minecraft.class_5599;
import net.minecraft.class_836;

@Mixin(class_836.class)
public abstract class SkullBlockRendererMixin {
	@Inject(method = "createSkullRenderers", at = @At(value = "INVOKE", target = "Lcom/google/common/collect/ImmutableMap$Builder;put(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/common/collect/ImmutableMap$Builder;", ordinal = 5))
	private static void port_lib$createSkullModels(class_5599 entityModelSet, CallbackInfoReturnable<Map<class_2484.class_2485, class_5598>> cir, @Local ImmutableMap.Builder<class_2484.class_2485, class_5598> builder) {
		EntityRenderersEvent.CreateSkullModels event = new EntityRenderersEvent.CreateSkullModels(builder, entityModelSet);
		event.sendEvent();
	}
}

