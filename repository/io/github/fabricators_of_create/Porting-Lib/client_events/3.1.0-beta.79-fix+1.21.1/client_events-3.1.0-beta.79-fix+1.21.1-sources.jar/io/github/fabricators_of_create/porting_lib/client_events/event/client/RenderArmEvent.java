package io.github.fabricators_of_create.porting_lib.client_events.event.client;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1306;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_765;
import org.jetbrains.annotations.ApiStatus;

/**
 * Fired before the player's arm is rendered in first person. This is a more targeted version of {@link RenderHandEvent},
 * and can be used to replace the rendering of the player's arm, such as for rendering armor on the arm or outright
 * replacing the arm with armor.
 *
 * <p>This event is {@linkplain CancellableEvent cancellable}.
 * If this event is cancelled, then the arm will not be rendered.</p>
 *
 * <p>This event is fired only on the {@linkplain EnvType#CLIENT logical client}.</p>
 */
public class RenderArmEvent extends BaseEvent implements CancellableEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (final Callback callback : callbacks)
			callback.onRenderArm(event);
	});

	private final class_4587 poseStack;
	private final class_4597 multiBufferSource;
	private final int packedLight;
	private final class_742 player;
	private final class_1306 arm;

	@ApiStatus.Internal
	public RenderArmEvent(class_4587 poseStack, class_4597 multiBufferSource, int packedLight, class_742 player, class_1306 arm) {
		this.poseStack = poseStack;
		this.multiBufferSource = multiBufferSource;
		this.packedLight = packedLight;
		this.player = player;
		this.arm = arm;
	}

	/**
	 * {@return the arm being rendered}
	 */
	public class_1306 getArm() {
		return arm;
	}

	/**
	 * {@return the pose stack used for rendering}
	 */
	public class_4587 getPoseStack() {
		return poseStack;
	}

	/**
	 * {@return the source of rendering buffers}
	 */
	public class_4597 getMultiBufferSource() {
		return multiBufferSource;
	}

	/**
	 * {@return the amount of packed (sky and block) light for rendering}
	 *
	 * @see class_765
	 */
	public int getPackedLight() {
		return packedLight;
	}

	/**
	 * {@return the client player that is having their arm rendered} In general, this will be the same as
	 * {@link net.minecraft.class_310#field_1724}.
	 */
	public class_742 getPlayer() {
		return player;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onRenderArm(this);
	}

	public interface Callback {
		void onRenderArm(RenderArmEvent event);
	}
}
