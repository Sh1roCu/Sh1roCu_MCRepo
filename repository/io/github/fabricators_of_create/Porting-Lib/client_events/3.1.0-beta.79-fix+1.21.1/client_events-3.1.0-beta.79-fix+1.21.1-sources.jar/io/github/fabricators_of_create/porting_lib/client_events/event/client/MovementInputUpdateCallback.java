package io.github.fabricators_of_create.porting_lib.client_events.event.client;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1657;
import net.minecraft.class_744;

public interface MovementInputUpdateCallback {
	Event<MovementInputUpdateCallback> EVENT = EventFactory.createArrayBacked(MovementInputUpdateCallback.class, movementInputUpdateCallbacks -> (player, input) -> {
		for (MovementInputUpdateCallback e : movementInputUpdateCallbacks)
			e.onMovementUpdate(player, input);
	});

	void onMovementUpdate(class_1657 player, class_744 input);
}
