package io.github.fabricators_of_create.porting_lib.client_events.event.client;

import com.google.common.collect.ImmutableMap;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1007;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_2484;
import net.minecraft.class_5598;
import net.minecraft.class_5599;
import net.minecraft.class_5601;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_607;
import net.minecraft.class_8685;
import net.minecraft.class_897;
import net.minecraft.class_922;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Set;

/**
 * Fired for on different events/actions relating to {@linkplain class_897 entity renderers}.
 * See the various subclasses for listening to different events.
 *
 * <p>These events are fired only on the {@linkplain EnvType#CLIENT logical client}.</p>
 *
 * @see EntityRenderersEvent.AddLayers
 */
public abstract class EntityRenderersEvent extends BaseEvent {
	@ApiStatus.Internal
	protected EntityRenderersEvent() {}

	/**
	 * Fired for registering entity renderer layers at the appropriate time, after the entity and player renderers maps
	 * have been created.
	 *
	 * <p>This event is not {@linkplain CancellableEvent cancellable}, and does not have a result.</p>
	 *
	 * <p>This event is fired only on the {@linkplain EnvType#CLIENT logical client}.</p>
	 */
	public static class AddLayers extends EntityRenderersEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks) {
				callback.onAddLayers(event);
			}
		});

		public interface Callback {
			void onAddLayers(AddLayers event);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onAddLayers(this);
		}

		private final Map<class_1299<?>, class_897<?>> renderers;
		private final Map<class_8685.class_7920, class_897<? extends class_1657>> skinMap;
		private final class_5617.class_5618 context;

		@ApiStatus.Internal
		public AddLayers(Map<class_1299<?>, class_897<?>> renderers, Map<class_8685.class_7920, class_897<? extends class_1657>> playerRenderers, class_5617.class_5618 context) {
			this.renderers = renderers;
			this.skinMap = playerRenderers;
			this.context = context;
		}

		/**
		 * {@return the set of player skin names which have a renderer}
		 * <p>
		 * Minecraft provides two default skin names: {@code default} for the
		 * {@linkplain class_5602#field_27577 regular player model} and {@code slim} for the
		 * {@linkplain class_5602#field_27581 slim player model}.
		 */
		public Set<class_8685.class_7920> getSkins() {
			return skinMap.keySet();
		}

		/**
		 * Returns a player skin renderer for the given skin name.
		 *
		 * @param skinModel the skin model to get the renderer for
		 * @param <R>       the type of the skin renderer, usually {@link class_1007}
		 * @return the skin renderer, or {@code null} if no renderer is registered for that skin name
		 * @see #getSkins()
		 */
		@Nullable
		@SuppressWarnings("unchecked")
		public <R extends class_897<? extends class_1657>> R getSkin(class_8685.class_7920 skinModel) {
			return (R) skinMap.get(skinModel);
		}

		/**
		 * {@return the set of entity types which have a renderer}
		 */
		public Set<class_1299<?>> getEntityTypes() {
			return renderers.keySet();
		}

		/**
		 * Returns an entity renderer for the given entity type. Note that the returned renderer may not be a
		 * {@link class_922}.
		 *
		 * @param entityType the entity type to return a renderer for
		 * @param <T>        the type of entity the renderer is for
		 * @param <R>        the type of the renderer
		 * @return the renderer, or {@code null} if no renderer is registered for that entity type
		 */
		@Nullable
		@SuppressWarnings("unchecked")
		public <T extends class_1297, R extends class_897<T>> R getRenderer(class_1299<? extends T> entityType) {
			return (R) renderers.get(entityType);
		}

		/**
		 * {@return the set of entity models}
		 */
		public class_5599 getEntityModels() {
			return this.context.method_32170();
		}

		/**
		 * {@return the context for the entity renderer provider}
		 */
		public class_5617.class_5618 getContext() {
			return context;
		}
	}

	/**
	 * Fired for registering additional {@linkplain class_5598 skull models} at the appropriate time.
	 *
	 * <p>This event is not {@linkplain CancellableEvent cancellable}, and does not have a result.</p>
	 *
	 * <p>This event is fired only on the {@linkplain EnvType#CLIENT logical client}.</p>
	 */
	public static class CreateSkullModels extends EntityRenderersEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks) {
				callback.onSkullModelsCreated(event);
			}
		});

		public interface Callback {
			void onSkullModelsCreated(CreateSkullModels event);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onSkullModelsCreated(this);
		}

		private final ImmutableMap.Builder<class_2484.class_2485, class_5598> builder;
		private final class_5599 entityModelSet;

		@ApiStatus.Internal
		public CreateSkullModels(ImmutableMap.Builder<class_2484.class_2485, class_5598> builder, class_5599 entityModelSet) {
			this.builder = builder;
			this.entityModelSet = entityModelSet;
		}

		/**
		 * {@return the set of entity models}
		 */
		public class_5599 getEntityModelSet() {
			return entityModelSet;
		}

		/**
		 * Registers the constructor for a skull block with the given {@link class_2484.class_2485}.
		 * These will be inserted into the maps used by the item, entity, and block model renderers at the appropriate
		 * time.
		 *
		 * @param type  a unique skull type; an exception will be thrown later if multiple mods (including vanilla)
		 *              register models for the same type
		 * @param model the skull model instance. A typical implementation will simply bake a model using
		 *              {@link class_5599#method_32072(class_5601)} and pass it to the constructor for
		 *              {@link class_607}.
		 */
		public void registerSkullModel(class_2484.class_2485 type, class_5598 model) {
			builder.put(type, model);
		}
	}
}
