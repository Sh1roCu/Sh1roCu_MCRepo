package io.github.fabricators_of_create.porting_lib.client_events.event.client;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1113;
import net.minecraft.class_1140;

/**
 * Fired when a sound is about to be played by the sound engine. This fires before the sound is played and before any
 * checks on the sound (such as a zeroed volume, an empty {@link net.minecraft.class_1111}, and
 * others). This can be used to change or prevent (by passing {@code null)} a sound from being played by returning null.
 *
 * @see PlaySoundSourceCallback
 * @see PlayStreamingSourceEvent
 */
public interface PlaySoundCallback {
	Event<PlaySoundCallback> EVENT = EventFactory.createArrayBacked(PlaySoundCallback.class, callbacks -> (manager, sound, originalSound) -> {
		class_1113 newSound = originalSound;
		for (PlaySoundCallback e : callbacks)
			newSound = e.onPlaySound(manager, sound, originalSound);
		return newSound;
	});

	/**
	 * @param engine The {@link class_1140} handling the sound.
	 * @param sound The {@link class_1113} that will be played.
	 * @param originalSound The original {@link class_1113}; will be equal to {@code sound} if the sound hasn't been modified by another mod.
	 * @return The sound that should be played, or null if nothing should be played.
	 */
	class_1113 onPlaySound(class_1140 engine, class_1113 sound, class_1113 originalSound);
}
