package io.github.fabricators_of_create.porting_lib.client_events.mixin.client;

import io.github.fabricators_of_create.porting_lib.client_events.event.client.RegisterColorResolversCallback;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import net.minecraft.class_2338;
import net.minecraft.class_4700;
import net.minecraft.class_638;
import net.minecraft.class_6539;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_638.class)
public abstract class ClientLevelMixin {
	@Shadow
	public abstract int calculateBlockTint(class_2338 blockPos, class_6539 colorResolver);

	@Inject(method = "method_23778", at = @At("TAIL"))
	private void addCustomColorResolvers(Object2ObjectArrayMap<class_6539, class_4700> target, CallbackInfo ci) {
		RegisterColorResolversCallback.RegistrationHelper helper = new RegisterColorResolversCallback.RegistrationHelper();
		RegisterColorResolversCallback.EVENT.invoker().onColorResolverCreation(helper);
		for (var resolver : helper.build()) {
			target.put(resolver, new class_4700(pos -> calculateBlockTint(pos, resolver)));
		}
	}
}
