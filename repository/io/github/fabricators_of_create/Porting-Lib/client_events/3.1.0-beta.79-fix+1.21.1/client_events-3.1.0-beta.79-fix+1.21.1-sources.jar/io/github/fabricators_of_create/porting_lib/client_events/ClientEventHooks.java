package io.github.fabricators_of_create.porting_lib.client_events;

import io.github.fabricators_of_create.porting_lib.client_events.event.client.RenderArmEvent;
import io.github.fabricators_of_create.porting_lib.client_events.event.client.RenderHandEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;

public class ClientEventHooks {
	public static boolean renderSpecificFirstPersonHand(class_1268 hand, class_4587 poseStack, class_4597 bufferSource, int packedLight, float partialTick, float interpPitch, float swingProgress, float equipProgress, class_1799 stack) {
		return new RenderHandEvent(hand, poseStack, bufferSource, packedLight, partialTick, interpPitch, swingProgress, equipProgress, stack).post();
	}

	public static boolean renderSpecificFirstPersonArm(class_4587 poseStack, class_4597 multiBufferSource, int packedLight, class_742 player, class_1306 arm) {
		return new RenderArmEvent(poseStack, multiBufferSource, packedLight, player, arm).post();
	}
}
