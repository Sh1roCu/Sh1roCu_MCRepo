package io.github.fabricators_of_create.porting_lib.client_events.mixin.client;

import io.github.fabricators_of_create.porting_lib.client_events.ClientEventHooks;
import net.minecraft.class_1007;
import net.minecraft.class_1306;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public class PlayerRendererMixin {
	@Inject(method = "renderLeftHand", at = @At("HEAD"), cancellable = true)
	private void onRenderLeftArm(class_4587 poseStack, class_4597 buffer, int packedLight, class_742 player, CallbackInfo ci) {
		if (ClientEventHooks.renderSpecificFirstPersonArm(poseStack, buffer, packedLight, player, class_1306.field_6182))
			ci.cancel();
	}

	@Inject(method = "renderRightHand", at = @At("HEAD"), cancellable = true)
	private void onRenderRightArm(class_4587 poseStack, class_4597 buffer, int packedLight, class_742 player, CallbackInfo ci) {
		if (ClientEventHooks.renderSpecificFirstPersonArm(poseStack, buffer, packedLight, player, class_1306.field_6183))
			ci.cancel();
	}
}
