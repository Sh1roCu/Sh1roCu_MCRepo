package io.github.fabricators_of_create.porting_lib.client_events.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.client_events.event.client.SelectMusicEvent;
import net.minecraft.class_1113;
import net.minecraft.class_1142;
import net.minecraft.class_310;
import net.minecraft.class_5195;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1142.class)
public abstract class MusicManagerMixin {
	@Shadow
	@Nullable
	private class_1113 currentMusic;

	@Shadow
	public abstract void stopPlaying();

	@Shadow
	private int nextSongDelay;

	@WrapOperation(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;getSituationalMusic()Lnet/minecraft/sounds/Music;"))
	private class_5195 selectMusicEvent(class_310 instance, Operation<class_5195> original) {
		SelectMusicEvent event = new SelectMusicEvent(original.call(instance), this.currentMusic);
		event.sendEvent();
		return event.getMusic();
	}

	@Inject(method = "tick", at = @At(value = "FIELD", target = "Lnet/minecraft/client/sounds/MusicManager;currentMusic:Lnet/minecraft/client/resources/sounds/SoundInstance;"), cancellable = true)
	private void checkIfMusicIsNull(CallbackInfo ci, @Local(ordinal = 0) class_5195 music) {
		if (music == null) {
			if (this.currentMusic != null) {
				stopPlaying();
			}
			this.nextSongDelay = 0;
			ci.cancel();
		}
	}
}
