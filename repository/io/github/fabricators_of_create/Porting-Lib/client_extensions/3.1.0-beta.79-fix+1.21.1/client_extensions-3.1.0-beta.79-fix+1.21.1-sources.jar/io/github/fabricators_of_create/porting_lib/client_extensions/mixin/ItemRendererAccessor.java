package io.github.fabricators_of_create.porting_lib.client_extensions.mixin;

import net.minecraft.class_756;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_918.class)
public interface ItemRendererAccessor {
	@Accessor
	class_756 getBlockEntityRenderer();
}
