package io.github.fabricators_of_create.porting_lib.client_extensions.mixin;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;

import io.github.fabricators_of_create.porting_lib.client_extensions.IClientBlockExtensions;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_702;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_310.class)
public class MinecraftMixin {
	@Shadow
	@Nullable
	public class_638 level;

	@Shadow
	@Nullable
	public class_239 hitResult;

	@WrapWithCondition(
			method = "continueAttack",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/particle/ParticleEngine;crack(Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V"
			)
	)
	private boolean customHitEffects(class_702 engine, class_2338 pos, class_2350 side) {
		class_2680 state = level.method_8320(pos);
		return !IClientBlockExtensions.of(state).addHitEffects(state, level, hitResult, engine);
	}
}
