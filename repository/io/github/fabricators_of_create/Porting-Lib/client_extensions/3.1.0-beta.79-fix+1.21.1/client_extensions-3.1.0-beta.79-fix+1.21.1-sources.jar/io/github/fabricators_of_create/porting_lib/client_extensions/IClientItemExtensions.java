package io.github.fabricators_of_create.porting_lib.client_extensions;

import io.github.fabricators_of_create.porting_lib.client_extensions.mixin.ItemRendererAccessor;
import net.fabricmc.api.EnvType;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_756;

/**
 * {@linkplain EnvType#CLIENT Client-only} extensions to {@link class_1792}.
 */
public interface IClientItemExtensions {
	IClientItemExtensions DEFAULT = new IClientItemExtensions() {};

	static IClientItemExtensions of(class_1799 stack) {
		return of(stack.method_7909());
	}

	static IClientItemExtensions of(class_1792 item) {
		return ClientExtensionsRegistry.ITEM_EXTENSIONS.getOrDefault(item, DEFAULT);
	}

	static boolean exists(class_1799 stack) {
		return exists(stack.method_7909());
	}

	static boolean exists(class_1792 item) {
		return ClientExtensionsRegistry.ITEM_EXTENSIONS.containsKey(item);
	}

	default class_756 getCustomRenderer() {
		return ((ItemRendererAccessor) class_310.method_1551().method_1480()).getBlockEntityRenderer();
	}
}
