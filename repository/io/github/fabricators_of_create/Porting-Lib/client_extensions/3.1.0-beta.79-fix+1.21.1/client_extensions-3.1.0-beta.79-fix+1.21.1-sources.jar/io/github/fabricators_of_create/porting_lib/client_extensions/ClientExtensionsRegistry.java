package io.github.fabricators_of_create.porting_lib.client_extensions;

import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1291;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_6880;
import java.util.Arrays;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class ClientExtensionsRegistry {
	static final Map<class_2248, IClientBlockExtensions> BLOCK_EXTENSIONS = new Reference2ObjectOpenHashMap<>();
	static final Map<class_1792, IClientItemExtensions> ITEM_EXTENSIONS = new Reference2ObjectOpenHashMap<>();
	static final Map<class_1291, IClientMobEffectExtensions> MOB_EFFECT_EXTENSIONS = new Reference2ObjectOpenHashMap<>();

	@SafeVarargs
	static <T, E> void register(E extensions, Map<T, E> target, T... objects) {
		if (objects.length == 0) {
			throw new IllegalArgumentException("At least one target must be provided");
		}
		Objects.requireNonNull(extensions, "Extensions must not be null");

		for (T object : objects) {
			Objects.requireNonNull(objects, "Target must not be null");
			E oldExtensions = target.put(object, extensions);
			if (oldExtensions != null) {
				throw new IllegalStateException(String.format(
						Locale.ROOT,
						"Duplicate client extensions registration for %s (old: %s, new: %s)",
						object,
						oldExtensions,
						extensions));
			}
		}
	}

	/**
	 * Register the given {@link IClientBlockExtensions} for the given {@link class_2248}s
	 */
	public static void registerBlock(IClientBlockExtensions extensions, class_2248... blocks) {
		register(extensions, BLOCK_EXTENSIONS, blocks);
	}

	/**
	 * Register the given {@link IClientBlockExtensions} for the given {@link class_2248}s
	 */
	@SafeVarargs
	public static void registerBlock(IClientBlockExtensions extensions, class_6880<class_2248>... blocks) {
		registerBlock(extensions, Arrays.stream(blocks).map(class_6880::comp_349).toArray(class_2248[]::new));
	}

	/**
	 * {@return whether a {@link IClientBlockExtensions} has been registered for the given {@link class_2248}}
	 */
	public static boolean isBlockRegistered(class_2248 block) {
		return BLOCK_EXTENSIONS.containsKey(block);
	}

	/**
	 * Register the given {@link IClientItemExtensions} for the given {@link class_1792}s
	 */
	public static void registerItem(IClientItemExtensions extensions, class_1792... items) {
		register(extensions, ITEM_EXTENSIONS, items);

		// Register the item renderers directly to Fabric's item renderer registry.
		for (class_1792 item : items) {
			BuiltinItemRendererRegistry.INSTANCE.register(item, (stack, mode, matrices, vertexConsumers, light, overlay) -> {
				extensions.getCustomRenderer().method_3166(stack, mode, matrices, vertexConsumers, light, overlay);
			});
		}
	}

	/**
	 * Register the given {@link IClientItemExtensions} for the given {@link class_1792}s
	 */
	@SafeVarargs
	public static void registerItem(IClientItemExtensions extensions, class_6880<class_1792>... items) {
		registerItem(extensions, Arrays.stream(items).map(class_6880::comp_349).toArray(class_1792[]::new));
	}

	/**
	 * {@return whether a {@link IClientItemExtensions} has been registered for the given {@link class_1792}}
	 */
	public static boolean isItemRegistered(class_1792 item) {
		return ITEM_EXTENSIONS.containsKey(item);
	}

	/**
	 * Register the given {@link IClientMobEffectExtensions} for the given {@link class_1291}s
	 */
	public static void registerMobEffect(IClientMobEffectExtensions extensions, class_1291... mobEffects) {
		register(extensions, MOB_EFFECT_EXTENSIONS, mobEffects);
	}

	/**
	 * Register the given {@link IClientMobEffectExtensions} for the given {@link class_1291}s
	 */
	@SafeVarargs
	public static void registerMobEffect(IClientMobEffectExtensions extensions, class_6880<class_1291>... mobEffects) {
		registerMobEffect(extensions, Arrays.stream(mobEffects).map(class_6880::comp_349).toArray(class_1291[]::new));
	}

	/**
	 * {@return whether a {@link IClientMobEffectExtensions} has been registered for the given {@link class_1291}}
	 */
	public static boolean isMobEffectRegistered(class_1291 mobEffect) {
		return MOB_EFFECT_EXTENSIONS.containsKey(mobEffect);
	}
}
