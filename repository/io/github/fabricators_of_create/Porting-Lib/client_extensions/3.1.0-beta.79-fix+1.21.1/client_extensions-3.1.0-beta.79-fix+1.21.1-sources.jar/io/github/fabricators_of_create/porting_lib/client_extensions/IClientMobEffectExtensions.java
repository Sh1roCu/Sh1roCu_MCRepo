package io.github.fabricators_of_create.porting_lib.client_extensions;

import net.fabricmc.api.EnvType;
import net.minecraft.class_1291;
import net.minecraft.class_1293;

/**
 * {@linkplain EnvType#CLIENT Client-only} extensions to {@link class_1291}.
 */
public interface IClientMobEffectExtensions {
	IClientMobEffectExtensions DEFAULT = new IClientMobEffectExtensions() {};

	static IClientMobEffectExtensions of(class_1293 instance) {
		return of(instance.method_5579().comp_349());
	}

	static IClientMobEffectExtensions of(class_1291 effect) {
		return ClientExtensionsRegistry.MOB_EFFECT_EXTENSIONS.getOrDefault(effect, DEFAULT);
	}
}
