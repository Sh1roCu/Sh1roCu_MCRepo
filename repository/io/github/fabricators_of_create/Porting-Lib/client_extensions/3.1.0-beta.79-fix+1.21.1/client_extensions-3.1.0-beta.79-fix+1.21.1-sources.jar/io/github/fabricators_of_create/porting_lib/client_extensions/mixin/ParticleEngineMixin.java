package io.github.fabricators_of_create.porting_lib.client_extensions.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import io.github.fabricators_of_create.porting_lib.client_extensions.IClientBlockExtensions;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_638;
import net.minecraft.class_702;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_702.class)
public class ParticleEngineMixin {
	@Shadow
	protected class_638 level;

	@ModifyExpressionValue(method = "destroy", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;shouldSpawnTerrainParticles()Z"))
	private boolean customDestroyEffects(boolean original, class_2338 blockPos, class_2680 blockState) {
		if (IClientBlockExtensions.exists(blockState)) {
			if (!IClientBlockExtensions.of(blockState).addDestroyEffects(blockState, level, blockPos, (class_702) (Object) this)) {
				return false;
			}
		}
		return original;
	}
}
