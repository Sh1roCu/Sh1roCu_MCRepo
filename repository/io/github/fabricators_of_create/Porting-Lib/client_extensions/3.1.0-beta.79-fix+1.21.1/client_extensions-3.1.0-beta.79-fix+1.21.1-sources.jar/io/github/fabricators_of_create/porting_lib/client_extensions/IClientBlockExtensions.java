package io.github.fabricators_of_create.porting_lib.client_extensions;

import net.fabricmc.api.EnvType;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_702;

/**
 * {@linkplain EnvType#CLIENT Client-only} extensions to {@link class_2248}.
 */
public interface IClientBlockExtensions {
	IClientBlockExtensions DEFAULT = new IClientBlockExtensions() {};

	static IClientBlockExtensions of(class_2680 state) {
		return of(state.method_26204());
	}

	static IClientBlockExtensions of(class_2248 block) {
		return ClientExtensionsRegistry.BLOCK_EXTENSIONS.getOrDefault(block, DEFAULT);
	}

	static boolean exists(class_2680 state) {
		return exists(state.method_26204());
	}

	static boolean exists(class_2248 block) {
		return ClientExtensionsRegistry.BLOCK_EXTENSIONS.containsKey(block);
	}

	/**
	 * Spawn a digging particle effect in the level, this is a wrapper
	 * around EffectRenderer.addBlockHitEffects to allow the block more
	 * control over the particles. Useful when you have entirely different
	 * texture sheets for different sides/locations in the level.
	 *
	 * @param state   The current state
	 * @param level   The current level
	 * @param target  The target the player is looking at {x/y/z/side/sub}
	 * @param manager A reference to the current particle manager.
	 * @return True to prevent vanilla digging particles form spawning.
	 */
	default boolean addHitEffects(class_2680 state, class_1937 level, class_239 target, class_702 manager) {
		return false;
	}

	/**
	 * Spawn particles for when the block is destroyed. Due to the nature
	 * of how this is invoked, the x/y/z locations are not always guaranteed
	 * to host your block. So be sure to do proper sanity checks before assuming
	 * that the location is this block.
	 *
	 * @param Level   The current Level
	 * @param pos     Position to spawn the particle
	 * @param manager A reference to the current particle manager.
	 * @return True to prevent vanilla break particles from spawning.
	 */
	default boolean addDestroyEffects(class_2680 state, class_1937 Level, class_2338 pos, class_702 manager) {
		return !state.method_45475();
	}
}
