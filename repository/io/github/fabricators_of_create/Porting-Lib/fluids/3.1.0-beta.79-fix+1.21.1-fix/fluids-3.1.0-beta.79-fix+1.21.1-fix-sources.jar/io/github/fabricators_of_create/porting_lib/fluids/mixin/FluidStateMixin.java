package io.github.fabricators_of_create.porting_lib.fluids.mixin;

import io.github.fabricators_of_create.porting_lib.fluids.extensions.FluidStateExtension;
import net.minecraft.class_3610;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_3610.class)
public class FluidStateMixin implements FluidStateExtension {
}
