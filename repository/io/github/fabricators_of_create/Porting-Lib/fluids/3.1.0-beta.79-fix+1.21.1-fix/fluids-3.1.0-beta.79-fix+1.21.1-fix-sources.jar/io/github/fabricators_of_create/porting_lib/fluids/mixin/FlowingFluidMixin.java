package io.github.fabricators_of_create.porting_lib.fluids.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import com.llamalad7.mixinextras.sugar.Local;

import com.llamalad7.mixinextras.sugar.Share;

import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;

import io.github.fabricators_of_create.porting_lib.fluids.extensions.ConvertToSourceFluid;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_3609.class)
public class FlowingFluidMixin {
	@ModifyExpressionValue(method = "getNewLiquid", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/material/FluidState;isSource()Z"))
	private boolean canConvertToSource(boolean original, @Local(argsOnly = true) class_1937 level, @Local(ordinal = 1) class_2338 pos, @Local class_3610 fluidState, @Share("source") LocalBooleanRef sourceFlag) {
		if (sourceFlag.get()) {
			return original && fluidState.port_lib$canConvertToSource(level, pos);
		}
		if (fluidState.method_15772() instanceof ConvertToSourceFluid sourceFluid) {
			sourceFlag.set(true);
			return original && sourceFluid.canConvertToSource(fluidState, level, pos);
		}
		return original;
	}

	@ModifyExpressionValue(method = "getNewLiquid", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/material/FlowingFluid;canConvertToSource(Lnet/minecraft/world/level/Level;)Z"))
	private boolean checkConvertToSource(boolean original, @Share("source") LocalBooleanRef sourceFlag) {
		if (sourceFlag.get())
			return true;
		return original;
	}
}
