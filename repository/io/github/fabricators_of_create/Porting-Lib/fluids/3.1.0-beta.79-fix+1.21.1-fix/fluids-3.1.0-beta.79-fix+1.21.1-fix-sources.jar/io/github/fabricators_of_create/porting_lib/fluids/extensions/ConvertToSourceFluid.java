package io.github.fabricators_of_create.porting_lib.fluids.extensions;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3610;

public interface ConvertToSourceFluid {
	/**
	 * Returns whether the fluid can create a source.
	 *
	 * @param state the state of the fluid
	 * @param level the level that can get the fluid
	 * @param pos the location of the fluid
	 * @return {@code true} if the fluid can create a source, {@code false} otherwise
	 */
	default boolean canConvertToSource(class_3610 state, class_1937 level, class_2338 pos) {
		return false;
	}
}
