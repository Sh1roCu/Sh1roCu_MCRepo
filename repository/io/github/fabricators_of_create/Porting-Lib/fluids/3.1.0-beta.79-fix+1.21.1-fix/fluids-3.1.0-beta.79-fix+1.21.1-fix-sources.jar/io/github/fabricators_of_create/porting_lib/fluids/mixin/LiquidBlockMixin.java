package io.github.fabricators_of_create.porting_lib.fluids.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import io.github.fabricators_of_create.porting_lib.fluids.FluidInteractionRegistry;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2680;

@Mixin(class_2404.class)
public class LiquidBlockMixin {
	@ModifyExpressionValue(method = "onPlace", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/LiquidBlock;shouldSpreadLiquid(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Z"))
	private boolean canPlaceCustom(boolean original, class_2680 blockState, class_1937 level, class_2338 blockPos) {
		if (!FluidInteractionRegistry.canInteract(level, blockPos, false))
			return true;
		return original;
	}

	@ModifyExpressionValue(method = "neighborChanged", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/LiquidBlock;shouldSpreadLiquid(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Z"))
	private boolean neighborChangedCustom(boolean original, class_2680 blockState, class_1937 level, class_2338 blockPos) {
		if (!FluidInteractionRegistry.canInteract(level, blockPos, false))
			return true;
		return original;
	}
}
