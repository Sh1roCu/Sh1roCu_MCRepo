package io.github.fabricators_of_create.porting_lib.fluids.mixin;

import io.github.fabricators_of_create.porting_lib.fluids.FluidType;
import io.github.fabricators_of_create.porting_lib.fluids.PortingLibFluids;
import io.github.fabricators_of_create.porting_lib.fluids.extensions.FluidExtension;
import io.github.fabricators_of_create.porting_lib.fluids.wrapper.FluidAttributeFluidType;
import io.github.fabricators_of_create.porting_lib.fluids.wrapper.MergingFluidAttributeFluidType;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_3611.class)
public class FluidMixin implements FluidExtension {
	private FluidType portingLibFluidType;
	@Override
	public FluidType getFluidType() {
		var fluid = (class_3611) (Object) this;
		if (portingLibFluidType == null) {
			if (fluid == class_3612.field_15906)
				portingLibFluidType = PortingLibFluids.EMPTY_TYPE;
			if (fluid == class_3612.field_15910 || fluid == class_3612.field_15909)
				portingLibFluidType = PortingLibFluids.WATER_TYPE;//new MergingFluidAttributeFluidType(PortingLibFluids.WATER_TYPE, FluidVariant.of(fluid), FluidVariantAttributes.getHandler(Fluids.WATER));
			if (fluid == class_3612.field_15908 || fluid == class_3612.field_15907)
				portingLibFluidType = PortingLibFluids.LAVA_TYPE;//new MergingFluidAttributeFluidType(PortingLibFluids.LAVA_TYPE, FluidVariant.of(fluid), FluidVariantAttributes.getHandler(Fluids.LAVA));
		}
		return this.portingLibFluidType;
	}
}
