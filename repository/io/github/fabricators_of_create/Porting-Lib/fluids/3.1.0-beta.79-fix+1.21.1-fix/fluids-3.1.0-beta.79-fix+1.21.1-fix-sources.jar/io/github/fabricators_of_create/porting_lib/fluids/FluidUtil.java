package io.github.fabricators_of_create.porting_lib.fluids;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1074;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_7923;

public class FluidUtil {
	@Environment(EnvType.CLIENT)
	public static String getTranslationKey(class_3611 fluid) {
		String translationKey;

		if (fluid == class_3612.field_15906) {
			translationKey = "";
		} else if (fluid == class_3612.field_15910) {
			translationKey = "block.minecraft.water";
		} else if (fluid == class_3612.field_15908) {
			translationKey = "block.minecraft.lava";
		} else {
			class_2960 id = class_7923.field_41173.method_10221(fluid);
			String key = class_156.method_646("block", id);
			String translated = class_1074.method_4662(key);
			translationKey = translated.equals(key) ? class_156.method_646("fluid", id) : key;
		}

		return translationKey;
	}
}
