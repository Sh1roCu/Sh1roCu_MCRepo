package io.github.fabricators_of_create.porting_lib.fluids.wrapper;

import java.util.Optional;
import org.jetbrains.annotations.Nullable;

import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.fluids.FluidType;
import io.github.fabricators_of_create.porting_lib.fluids.sound.SoundActions;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributeHandler;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.minecraft.class_3611;

/**
 * If you're just using fluid types then make sure you register this for your fluid
 * using {@link net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes#register(class_3611, FluidVariantAttributeHandler)}
 */
public class FabricFluidTypeWrapper implements FluidVariantAttributeHandler {
	private final FluidType type;

	public FabricFluidTypeWrapper(FluidType type) {
		this.type = type;
	}

	@Override
	public class_2561 getName(FluidVariant variant) {
		return type.getDescription(new FluidStack(variant, FluidConstants.BUCKET));
	}

	@Override
	public Optional<class_3414> getFillSound(FluidVariant variant) {
		return Optional.ofNullable(type.getSound(new FluidStack(variant, FluidConstants.BUCKET), SoundActions.BUCKET_FILL));
	}

	@Override
	public Optional<class_3414> getEmptySound(FluidVariant variant) {
		return Optional.ofNullable(type.getSound(new FluidStack(variant, FluidConstants.BUCKET), SoundActions.BUCKET_EMPTY));
	}

	@Override
	public int getLuminance(FluidVariant variant) {
		return type.getLightLevel(new FluidStack(variant, FluidConstants.BUCKET));
	}

	@Override
	public int getTemperature(FluidVariant variant) {
		return type.getTemperature(new FluidStack(variant, FluidConstants.BUCKET));
	}

	@Override
	public int getViscosity(FluidVariant variant, @Nullable class_1937 world) {
		return type.getViscosity(variant.getFluid().method_15785(), world, null);
	}

	@Override
	public boolean isLighterThanAir(FluidVariant variant) {
		return type.isLighterThanAir();
	}
}
