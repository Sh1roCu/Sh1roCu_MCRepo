package io.github.fabricators_of_create.porting_lib.fluids;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_6088;

/**
 * A registry which defines the interactions a source fluid can have with its
 * surroundings. Each possible flow direction is checked for all interactions with
 * the source.
 *
 * <p>Fluid interactions mimic the behavior of {@code LiquidBlock#shouldSpreadLiquid}.
 * As such, all directions, besides {@link class_2350#field_11033} is tested and then replaced.
 * Any fluids which cause a change in the down interaction must be handled in
 * {@code FlowingFluid#spreadTo} and not by this interaction manager.
 */
public final class FluidInteractionRegistry {
	private static final Map<FluidType, List<InteractionInformation>> INTERACTIONS = new HashMap<>();

	/**
	 * Adds an interaction between a source and its surroundings.
	 *
	 * @param source      the source of the interaction, this will be replaced if the interaction occurs
	 * @param interaction the interaction data to check and perform
	 */
	public static synchronized void addInteraction(FluidType source, InteractionInformation interaction) {
		INTERACTIONS.computeIfAbsent(source, s -> new ArrayList<>()).add(interaction);
	}

	/**
	 * Performs all potential fluid interactions at a given position.
	 *
	 * <p>Note: Only the first interaction check that succeeds will occur.
	 *
	 * @param level the level the interactions take place in
	 * @param pos   the position of the source fluid
	 * @return {@code true} if an interaction took place, {@code false} otherwise
	 */
	public static boolean canInteract(class_1937 level, class_2338 pos) {
		return canInteract(level, pos, true);
	}

	/**
	 * Performs all potential fluid interactions at a given position.
	 *
	 * <p>Note: Only the first interaction check that succeeds will occur.
	 *
	 * @param level the level the interactions take place in
	 * @param pos   the position of the source fluid
	 * @return {@code true} if an interaction took place, {@code false} otherwise
	 */
	public static boolean canInteract(class_1937 level, class_2338 pos, boolean overrideVanilla) {
		class_3610 state = level.method_8316(pos);
		for (class_2350 direction : class_2404.field_34006) {
			class_2338 relativePos = pos.method_10093(direction.method_10153());
			List<InteractionInformation> interactions = INTERACTIONS.getOrDefault(state.getFluidType(), Collections.emptyList());
			for (InteractionInformation interaction : interactions) {
				if (interaction.isVanilla() && !overrideVanilla)
					continue;
				if (interaction.predicate().test(level, pos, relativePos, state)) {
					interaction.interaction().interact(level, pos, relativePos, state);
					return true;
				}
			}
		}

		return false;
	}

	static {
		// Lava + Water = Obsidian (Source Lava) / Cobblestone (Flowing Lava)
		addInteraction(PortingLibFluids.LAVA_TYPE, new InteractionInformation(
				PortingLibFluids.WATER_TYPE,
				fluidState -> fluidState.method_15771() ? class_2246.field_10540.method_9564() : class_2246.field_10445.method_9564(),
				true
		));

		// Lava + Soul Soil (Below) + Blue Ice = Basalt
		addInteraction(PortingLibFluids.LAVA_TYPE, new InteractionInformation(
				(level, currentPos, relativePos, currentState) -> level.method_8320(currentPos.method_10074()).method_27852(class_2246.field_22090) && level.method_8320(relativePos).method_27852(class_2246.field_10384),
				class_2246.field_22091.method_9564(),
				true
		));
	}

	/**
	 * Holds the interaction data for a given source type on when to succeed
	 * and what to perform.
	 *
	 * @param predicate   a test to see whether an interaction can occur
	 * @param interaction the interaction to perform
	 */
	public record InteractionInformation(HasFluidInteraction predicate, FluidInteraction interaction,
										 boolean isVanilla) {

		public InteractionInformation(HasFluidInteraction predicate, FluidInteraction interaction) {
			this(predicate, interaction, false);
		}

		/**
		 * Constructor which checks the surroundings fluids for a specific type
		 * and then transforms the source state into a block.
		 *
		 * @param type  the type of the fluid that must be surrounding the source
		 * @param state the state of the block replacing the source
		 */
		public InteractionInformation(FluidType type, class_2680 state) {
			this(type, fluidState -> state);
		}

		/**
		 * Constructor which transforms the source state into a block.
		 *
		 * @param predicate a test to see whether an interaction can occur
		 * @param state     the state of the block replacing the source
		 */
		public InteractionInformation(HasFluidInteraction predicate, class_2680 state) {
			this(predicate, state, false);
		}

		/**
		 * Constructor which transforms the source state into a block.
		 *
		 * @param predicate a test to see whether an interaction can occur
		 * @param state     the state of the block replacing the source
		 */
		public InteractionInformation(HasFluidInteraction predicate, class_2680 state, boolean isVanilla) {
			this(predicate, fluidState -> state, isVanilla);
		}

		/**
		 * Constructor which checks the surroundings fluids for a specific type
		 * and then transforms the source state into a block.
		 *
		 * @param type     the type of the fluid that must be surrounding the source
		 * @param getState a function to transform the source fluid into a block state
		 */
		public InteractionInformation(FluidType type, Function<class_3610, class_2680> getState) {
			this((level, currentPos, relativePos, currentState) -> level.method_8316(relativePos).getFluidType() == type, getState);
		}

		/**
		 * Constructor which checks the surroundings fluids for a specific type
		 * and then transforms the source state into a block.
		 *
		 * @param type     the type of the fluid that must be surrounding the source
		 * @param getState a function to transform the source fluid into a block state
		 */
		public InteractionInformation(FluidType type, Function<class_3610, class_2680> getState, boolean isVanilla) {
			this((level, currentPos, relativePos, currentState) -> level.method_8316(relativePos).getFluidType() == type, getState, isVanilla);
		}

		/**
		 * Constructor which transforms the source state into a block.
		 *
		 * @param predicate a test to see whether an interaction can occur
		 * @param getState  a function to transform the source fluid into a block state
		 */
		public InteractionInformation(HasFluidInteraction predicate, Function<class_3610, class_2680> getState) {
			this(predicate, getState, false);
		}

		/**
		 * Constructor which transforms the source state into a block.
		 *
		 * @param predicate a test to see whether an interaction can occur
		 * @param getState  a function to transform the source fluid into a block state
		 */
		public InteractionInformation(HasFluidInteraction predicate, Function<class_3610, class_2680> getState, boolean isVanilla) {
			this(predicate, (level, currentPos, relativePos, currentState) ->
			{
				level.method_8501(currentPos, getState.apply(currentState)/*ForgeEventFactory.fireFluidPlaceBlockEvent(level, currentPos, currentPos, getState.apply(currentState))*/);
				level.method_20290(class_6088.field_31138, currentPos, 0);
			}, isVanilla);
		}
	}

	/**
	 * An interface which tests whether a source fluid can interact with its
	 * surroundings.
	 */
	@FunctionalInterface
	public interface HasFluidInteraction {
		/**
		 * Returns whether the interaction can occur.
		 *
		 * @param level        the level the interaction takes place in
		 * @param currentPos   the position of the source
		 * @param relativePos  a position surrounding the source
		 * @param currentState the state of the fluid surrounding the source
		 * @return {@code true} if an interaction can occur, {@code false} otherwise
		 */
		boolean test(class_1937 level, class_2338 currentPos, class_2338 relativePos, class_3610 currentState);
	}

	/**
	 * An interface which performs an interaction for a source.
	 */
	@FunctionalInterface
	public interface FluidInteraction {
		/**
		 * Performs the interaction between the source and the surrounding data.
		 *
		 * @param level        the level the interaction takes place in
		 * @param currentPos   the position of the source
		 * @param relativePos  a position surrounding the source
		 * @param currentState the state of the fluid surrounding the source
		 */
		void interact(class_1937 level, class_2338 currentPos, class_2338 relativePos, class_3610 currentState);
	}
}
