package io.github.fabricators_of_create.porting_lib.fluids.mixin;

import net.minecraft.class_1937;
import net.minecraft.class_3609;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_3609.class)
public interface FlowingFluidAccessor {
	@Invoker
	boolean callCanConvertToSource(class_1937 level);
}
