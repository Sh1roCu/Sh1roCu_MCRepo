package io.github.fabricators_of_create.porting_lib.fluids.extensions;

import io.github.fabricators_of_create.porting_lib.fluids.FluidType;
import io.github.fabricators_of_create.porting_lib.fluids.mixin.FlowingFluidAccessor;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import org.jetbrains.annotations.Nullable;

public interface FluidStateExtension {
	/**
	 * Returns the type of this fluid.
	 *
	 * @return the type of this fluid
	 */
	@Nullable
	default FluidType getFluidType() {
		return ((class_3610) this).method_15772().getFluidType();
	}

	/**
	 * Returns whether the fluid can create a source.
	 *
	 * @param level the level that can get the fluid
	 * @param pos   the location of the fluid
	 * @return {@code true} if the fluid can create a source, {@code false} otherwise
	 */
	default boolean port_lib$canConvertToSource(class_1937 level, class_2338 pos) {
		class_3611 fluid = ((class_3610) this).method_15772();
		if (fluid instanceof ConvertToSourceFluid sourceFluid)
			return sourceFluid.canConvertToSource((class_3610) this, level, pos);
		if (fluid instanceof class_3609 flowingFluid)
			return ((FlowingFluidAccessor) flowingFluid).callCanConvertToSource(level);
		return false;
	}
}
