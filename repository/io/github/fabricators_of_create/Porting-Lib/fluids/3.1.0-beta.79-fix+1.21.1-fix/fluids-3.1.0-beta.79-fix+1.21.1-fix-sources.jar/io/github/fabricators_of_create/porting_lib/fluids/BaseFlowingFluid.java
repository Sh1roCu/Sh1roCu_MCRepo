package io.github.fabricators_of_create.porting_lib.fluids;

import java.util.Optional;

import io.github.fabricators_of_create.porting_lib.fluids.extensions.ConvertToSourceFluid;
import io.github.fabricators_of_create.porting_lib.fluids.sound.SoundActions;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2404;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3414;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4538;

public abstract class BaseFlowingFluid extends class_3609 implements ConvertToSourceFluid {
	private final Supplier<? extends FluidType> fluidType;
	private final Supplier<? extends class_3611> flowing;
	private final Supplier<? extends class_3611> still;
	@Nullable
	private final Supplier<? extends class_1792> bucket;
	@Nullable
	private final Supplier<? extends class_2404> block;
	private final int slopeFindDistance;
	private final int levelDecreasePerBlock;
	private final float explosionResistance;
	private final int tickRate;

	protected BaseFlowingFluid(Properties properties) {
		this.fluidType = properties.fluidType;
		this.flowing = properties.flowing;
		this.still = properties.still;
		this.bucket = properties.bucket;
		this.block = properties.block;
		this.slopeFindDistance = properties.slopeFindDistance;
		this.levelDecreasePerBlock = properties.levelDecreasePerBlock;
		this.explosionResistance = properties.explosionResistance;
		this.tickRate = properties.tickRate;
	}

	@Override
	public FluidType getFluidType() {
		return this.fluidType.get();
	}

	@Override
	public class_3611 method_15750() {
		return flowing.get();
	}

	@Override
	public class_3611 method_15751() {
		return still.get();
	}

	@Override
	protected boolean method_15737(class_1937 level) {
		return false;
	}

	@Override
	public boolean canConvertToSource(class_3610 state, class_1937 level, class_2338 pos) {
		return this.getFluidType().canConvertToSource(state, level, pos);
	}

	@Override
	protected void method_15730(class_1936 worldIn, class_2338 pos, class_2680 state) {
		class_2586 blockEntity = state.method_31709() ? worldIn.method_8321(pos) : null;
		class_2248.method_9610(state, worldIn, pos, blockEntity);
	}

	@Override
	protected int method_15733(class_4538 worldIn) {
		return slopeFindDistance;
	}

	@Override
	protected int method_15739(class_4538 worldIn) {
		return levelDecreasePerBlock;
	}

	@Override
	public class_1792 method_15774() {
		return bucket != null ? bucket.get() : class_1802.field_8162;
	}

	@Override
	protected boolean method_15777(class_3610 state, class_1922 level, class_2338 pos, class_3611 fluidIn, class_2350 direction) {
		// Based on the water implementation, may need to be overriden for mod fluids that shouldn't behave like water.
		return direction == class_2350.field_11033 && !method_15780(fluidIn);
	}

	@Override
	public int method_15789(class_4538 level) {
		return tickRate;
	}

	@Override
	protected float method_15784() {
		return explosionResistance;
	}

	@Override
	protected class_2680 method_15790(class_3610 state) {
		if (block != null)
			return block.get().method_9564().method_11657(class_2404.field_11278, method_15741(state));
		return class_2246.field_10124.method_9564();
	}

	@Override
	public boolean method_15780(class_3611 fluidIn) {
		return fluidIn == still.get() || fluidIn == flowing.get();
	}

	@NotNull
	@Override
	public Optional<class_3414> method_32359() {
		return Optional.ofNullable(getFluidType().getSound(SoundActions.BUCKET_FILL));
	}

	public static class Flowing extends BaseFlowingFluid {
		public Flowing(Properties properties) {
			super(properties);
			method_15781(method_15783().method_11664().method_11657(field_15900, 7));
		}

		protected void method_15775(class_2689.class_2690<class_3611, class_3610> builder) {
			super.method_15775(builder);
			builder.method_11667(field_15900);
		}

		public int method_15779(class_3610 state) {
			return state.method_11654(field_15900);
		}

		public boolean method_15793(class_3610 state) {
			return false;
		}
	}

	public static class Source extends BaseFlowingFluid {
		public Source(Properties properties) {
			super(properties);
		}

		public int method_15779(class_3610 state) {
			return 8;
		}

		public boolean method_15793(class_3610 state) {
			return true;
		}
	}

	public static class Properties {
		private Supplier<? extends FluidType> fluidType;
		private Supplier<? extends class_3611> still;
		private Supplier<? extends class_3611> flowing;
		private Supplier<? extends class_1792> bucket;
		private Supplier<? extends class_2404> block;
		private int slopeFindDistance = 4;
		private int levelDecreasePerBlock = 1;
		private float explosionResistance = 1;
		private int tickRate = 5;

		public Properties(Supplier<? extends FluidType> fluidType, Supplier<? extends class_3611> still, Supplier<? extends class_3611> flowing) {
			this.fluidType = fluidType;
			this.still = still;
			this.flowing = flowing;
		}

		public Properties bucket(Supplier<? extends class_1792> bucket) {
			this.bucket = bucket;
			return this;
		}

		public Properties block(Supplier<? extends class_2404> block) {
			this.block = block;
			return this;
		}

		public Properties slopeFindDistance(int slopeFindDistance) {
			this.slopeFindDistance = slopeFindDistance;
			return this;
		}

		public Properties levelDecreasePerBlock(int levelDecreasePerBlock) {
			this.levelDecreasePerBlock = levelDecreasePerBlock;
			return this;
		}

		public Properties explosionResistance(float explosionResistance) {
			this.explosionResistance = explosionResistance;
			return this;
		}

		public Properties tickRate(int tickRate) {
			this.tickRate = tickRate;
			return this;
		}
	}
}
