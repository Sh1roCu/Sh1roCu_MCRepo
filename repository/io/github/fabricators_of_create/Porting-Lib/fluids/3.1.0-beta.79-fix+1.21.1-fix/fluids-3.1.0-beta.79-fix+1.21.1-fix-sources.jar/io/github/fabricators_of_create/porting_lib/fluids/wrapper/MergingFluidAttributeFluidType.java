package io.github.fabricators_of_create.porting_lib.fluids.wrapper;

import org.jetbrains.annotations.Nullable;

import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.fluids.FluidType;
import io.github.fabricators_of_create.porting_lib.fluids.sound.SoundAction;
import io.github.fabricators_of_create.porting_lib.fluids.sound.SoundActions;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributeHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1920;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3610;
import net.minecraft.class_4538;
import net.minecraft.class_7;

public class MergingFluidAttributeFluidType extends FluidType {
	private final FluidVariant variant;
	private final FluidVariantAttributeHandler handler;
	private final FluidType superType;
	public MergingFluidAttributeFluidType(FluidType superType, FluidVariant variant, FluidVariantAttributeHandler handler) {
		super(createProperties(variant, handler));
		this.variant = variant;
		this.handler = handler;
		this.superType = superType;
	}

	public static Properties createProperties(FluidVariant variant, FluidVariantAttributeHandler handler) {
		Properties properties = Properties.create()
				.viscosity(handler.getViscosity(variant, null))
				.temperature(handler.getTemperature(variant))
				.lightLevel(handler.getLuminance(variant))
				.density(handler.isLighterThanAir(variant) ? -1 : 1);
		handler.getFillSound(variant).ifPresent(soundEvent -> properties.sound(SoundActions.BUCKET_FILL, soundEvent));
		handler.getEmptySound(variant).ifPresent(soundEvent -> properties.sound(SoundActions.BUCKET_EMPTY, soundEvent));
		return properties;
	}

	@Override
	public class_2561 getDescription() {
		return handler.getName(variant);
	}

	@Override
	public int getTemperature(FluidStack stack) {
		return handler.getTemperature(stack.getVariant());
	}

	@Override
	public int getViscosity(FluidStack stack) {
		return handler.getViscosity(stack.getVariant(), null);
	}

	@Override
	public int getViscosity(class_3610 state, class_1920 getter, class_2338 pos) {
		if (getter instanceof class_1937 level)
			return handler.getViscosity(FluidVariant.of(state.method_15772()), level);
		return super.getViscosity(state, getter, pos);
	}

	@Override
	public int getLightLevel(FluidStack stack) {
		return handler.getLuminance(stack.getVariant());
	}

	@Override
	public int getDensity() {
		return superType.getDensity();
	}

	@Override
	public int getTemperature() {
		return superType.getTemperature();
	}

	@Override
	public int getViscosity() {
		return superType.getViscosity();
	}

	@Override
	public class_1814 getRarity() {
		return superType.getRarity();
	}

	@Override
	public @Nullable class_3414 getSound(SoundAction action) {
		return superType.getSound(action);
	}

	@Override
	public double motionScale(class_1297 entity) {
		return superType.motionScale(entity);
	}

	@Override
	public boolean canPushEntity(class_1297 entity) {
		return superType.canPushEntity(entity);
	}

	@Override
	public boolean canSwim(class_1297 entity) {
		return superType.canSwim(entity);
	}

	@Override
	public float getFallDistanceModifier(class_1297 entity) {
		return superType.getFallDistanceModifier(entity);
	}

	@Override
	public boolean canExtinguish(class_1297 entity) {
		return superType.canExtinguish(entity);
	}

	@Override
	public boolean move(class_3610 state, class_1309 entity, class_243 movementVector, double gravity) {
		return superType.move(state, entity, movementVector, gravity);
	}

	@Override
	public boolean canDrownIn(class_1309 entity) {
		return superType.canDrownIn(entity);
	}

	@Override
	public void setItemMovement(class_1542 entity) {
		superType.setItemMovement(entity);
	}

	@Override
	public boolean supportsBoating(class_1690 boat) {
		return superType.supportsBoating(boat);
	}

	@Override
	public boolean supportsBoating(class_3610 state, class_1690 boat) {
		return superType.supportsBoating(state, boat);
	}

	@Override
	public boolean canRideVehicleUnder(class_1297 vehicle, class_1297 rider) {
		return superType.canRideVehicleUnder(vehicle, rider);
	}

	@Override
	public boolean canHydrate(class_1297 entity) {
		return superType.canHydrate(entity);
	}

	@Override
	public @Nullable class_3414 getSound(class_1297 entity, SoundAction action) {
		return superType.getSound(entity, action);
	}

	@Override
	public boolean canExtinguish(class_3610 state, class_1922 getter, class_2338 pos) {
		return superType.canExtinguish(state, getter, pos);
	}

	@Override
	public boolean canConvertToSource(class_3610 state, class_4538 reader, class_2338 pos) {
		return superType.canConvertToSource(state, reader, pos);
	}

	@Override
	public @Nullable class_7 getBlockPathType(class_3610 state, class_1922 level, class_2338 pos, @Nullable class_1308 mob, boolean canFluidLog) {
		return superType.getBlockPathType(state, level, pos, mob, canFluidLog);
	}

	@Override
	public @Nullable class_7 getAdjacentBlockPathType(class_3610 state, class_1922 level, class_2338 pos, @Nullable class_1308 mob, class_7 originalType) {
		return superType.getAdjacentBlockPathType(state, level, pos, mob, originalType);
	}

	@Override
	public @Nullable class_3414 getSound(@Nullable class_1657 player, class_1922 getter, class_2338 pos, SoundAction action) {
		return superType.getSound(player, getter, pos, action);
	}

	@Override
	public boolean canHydrate(class_3610 state, class_1922 getter, class_2338 pos, class_2680 source, class_2338 sourcePos) {
		return superType.canHydrate(state, getter, pos, source, sourcePos);
	}

	@Override
	public int getLightLevel(class_3610 state, class_1920 getter, class_2338 pos) {
		return superType.getLightLevel(state, getter, pos);
	}

	@Override
	public int getDensity(class_3610 state, class_1920 getter, class_2338 pos) {
		return superType.getDensity(state, getter, pos);
	}

	@Override
	public int getTemperature(class_3610 state, class_1920 getter, class_2338 pos) {
		return superType.getTemperature(state, getter, pos);
	}

	@Override
	public boolean canConvertToSource(FluidStack stack) {
		return superType.canConvertToSource(stack);
	}

	@Override
	public @Nullable class_3414 getSound(FluidStack stack, SoundAction action) {
		return superType.getSound(stack, action);
	}

	@Override
	public boolean canHydrate(FluidStack stack) {
		return superType.canHydrate(stack);
	}

	@Override
	public int getDensity(FluidStack stack) {
		return superType.getDensity(stack);
	}

	@Override
	public class_1814 getRarity(FluidStack stack) {
		return superType.getRarity(stack);
	}

	@Override
	public class_1799 getBucket(FluidStack stack) {
		return superType.getBucket(stack);
	}

	@Override
	public class_2680 getBlockForFluidState(class_1920 getter, class_2338 pos, class_3610 state) {
		return superType.getBlockForFluidState(getter, pos, state);
	}

	@Override
	public class_3610 getStateForPlacement(class_1920 getter, class_2338 pos, FluidStack stack) {
		return superType.getStateForPlacement(getter, pos, stack);
	}

	@Override
	public boolean isVaporizedOnPlacement(class_1937 level, class_2338 pos, FluidStack stack) {
		return superType.isVaporizedOnPlacement(level, pos, stack);
	}

	@Override
	public void onVaporize(@Nullable class_1657 player, class_1937 level, class_2338 pos, FluidStack stack) {
		superType.onVaporize(player, level, pos, stack);
	}

	public FluidType getRegisteredWrapper() {
		return this.superType;
	}
}
