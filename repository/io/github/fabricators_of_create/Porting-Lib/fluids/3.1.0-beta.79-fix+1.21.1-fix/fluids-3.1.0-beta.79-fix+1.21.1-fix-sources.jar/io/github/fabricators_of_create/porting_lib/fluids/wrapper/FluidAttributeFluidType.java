package io.github.fabricators_of_create.porting_lib.fluids.wrapper;

import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.fluids.FluidType;
import io.github.fabricators_of_create.porting_lib.fluids.sound.SoundActions;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributeHandler;
import net.minecraft.class_1920;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3610;

public class FluidAttributeFluidType extends FluidType {
	private final FluidVariant variant;
	private final FluidVariantAttributeHandler handler;
	public FluidAttributeFluidType(FluidVariant variant, FluidVariantAttributeHandler handler) {
		super(Properties.create()
				.viscosity(handler.getViscosity(variant, null))
				.temperature(handler.getTemperature(variant))
				.lightLevel(handler.getLuminance(variant))
				.sound(SoundActions.BUCKET_FILL, handler.getFillSound(variant).get())
				.sound(SoundActions.BUCKET_EMPTY, handler.getEmptySound(variant).get())
				.density(handler.isLighterThanAir(variant) ? -1 : 1)
		);
		this.variant = variant;
		this.handler = handler;
	}

	@Override
	public class_2561 getDescription() {
		return handler.getName(variant);
	}

	@Override
	public int getTemperature(FluidStack stack) {
		return handler.getTemperature(stack.getVariant());
	}

	@Override
	public int getViscosity(FluidStack stack) {
		return handler.getViscosity(stack.getVariant(), null);
	}

	@Override
	public int getViscosity(class_3610 state, class_1920 getter, class_2338 pos) {
		if (getter instanceof class_1937 level)
			return handler.getViscosity(FluidVariant.of(state.method_15772()), level);
		return super.getViscosity(state, getter, pos);
	}

	@Override
	public int getLightLevel(FluidStack stack) {
		return handler.getLuminance(stack.getVariant());
	}
}
