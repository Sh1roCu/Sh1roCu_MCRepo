package io.github.fabricators_of_create.porting_lib.fluids;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;

import org.jetbrains.annotations.Nullable;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.fluids.sound.SoundActions;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1542;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_3417;
import net.minecraft.class_3610;
import net.minecraft.class_5321;
import net.minecraft.class_7;
import java.util.function.Function;

public class PortingLibFluids implements ModInitializer {
	public static final Codec<Long> POSITIVE_LONG = longRangeWithMessage(1, Long.MAX_VALUE, (integer) -> {
		return "Value must be positive: " + integer;
	});
	public static final class_5321<class_2378<FluidType>> FLUID_TYPE_REGISTRY = class_5321.method_29180(PortingLib.id("fluid_type"));
	public static final class_2378<FluidType> FLUID_TYPES = FabricRegistryBuilder.createDefaulted(FLUID_TYPE_REGISTRY, PortingLib.id("empty")).buildAndRegister();

	public static final FluidType EMPTY_TYPE =
			new FluidType(FluidType.Properties.create()
					.descriptionId("block.minecraft.air")
					.motionScale(1D)
					.canPushEntity(false)
					.canSwim(false)
					.canDrown(false)
					.fallDistanceModifier(1F)
					.pathType(null)
					.adjacentPathType(null)
					.density(0)
					.temperature(0)
					.viscosity(0))
			{
				@Override
				public void setItemMovement(class_1542 entity) {
					if (!entity.method_5740()) entity.method_18799(entity.method_18798().method_1031(0.0D, -0.04D, 0.0D));
				}
			};
	public static final FluidType WATER_TYPE =
			new FluidType(FluidType.Properties.create()
					.descriptionId("block.minecraft.water")
					.fallDistanceModifier(0F)
					.canExtinguish(true)
					.canConvertToSource(true)
					.supportsBoating(true)
					.sound(SoundActions.BUCKET_FILL, class_3417.field_15126)
					.sound(SoundActions.BUCKET_EMPTY, class_3417.field_14834)
					.sound(SoundActions.FLUID_VAPORIZE, class_3417.field_15102)
					.canHydrate(true))
			{
				@Override
				public @Nullable class_7 getBlockPathType(class_3610 state, class_1922 level, class_2338 pos, @Nullable class_1308 mob, boolean canFluidLog)
				{
					return canFluidLog ? super.getBlockPathType(state, level, pos, mob, true) : null;
				}

//				@Override
//				public void initializeClient(Consumer<IClientFluidTypeExtensions> consumer)
//				{
//					consumer.accept(new IClientFluidTypeExtensions()
//					{
//						private static final ResourceLocation UNDERWATER_LOCATION = new ResourceLocation("textures/misc/underwater.png"),
//								WATER_STILL = new ResourceLocation("block/water_still"),
//								WATER_FLOW = new ResourceLocation("block/water_flow"),
//								WATER_OVERLAY = new ResourceLocation("block/water_overlay");
//
//						@Override
//						public ResourceLocation getStillTexture()
//						{
//							return WATER_STILL;
//						}
//
//						@Override
//						public ResourceLocation getFlowingTexture()
//						{
//							return WATER_FLOW;
//						}
//
//						@Nullable
//						@Override
//						public ResourceLocation getOverlayTexture()
//						{
//							return WATER_OVERLAY;
//						}
//
//						@Override
//						public ResourceLocation getRenderOverlayTexture(Minecraft mc)
//						{
//							return UNDERWATER_LOCATION;
//						}
//
//						@Override
//						public int getTintColor()
//						{
//							return 0xFF3F76E4;
//						}
//
//						@Override
//						public int getTintColor(FluidState state, BlockAndTintGetter getter, BlockPos pos)
//						{
//							return BiomeColors.getAverageWaterColor(getter, pos) | 0xFF000000;
//						}
//					});
//				}
			};
	public static final FluidType LAVA_TYPE =
			new FluidType(FluidType.Properties.create()
					.descriptionId("block.minecraft.lava")
					.canSwim(false)
					.canDrown(false)
					.pathType(class_7.field_14)
					.adjacentPathType(null)
					.sound(SoundActions.BUCKET_FILL, class_3417.field_15202)
					.sound(SoundActions.BUCKET_EMPTY, class_3417.field_15010)
					.lightLevel(15)
					.density(3000)
					.viscosity(6000)
					.temperature(1300))
			{
				@Override
				public double motionScale(class_1297 entity)
				{
					return entity.method_37908().method_8597().comp_644() ? 0.007D : 0.0023333333333333335D;
				}

				@Override
				public void setItemMovement(class_1542 entity)
				{
					class_243 vec3 = entity.method_18798();
					entity.method_18800(vec3.field_1352 * (double)0.95F, vec3.field_1351 + (double)(vec3.field_1351 < (double)0.06F ? 5.0E-4F : 0.0F), vec3.field_1350 * (double)0.95F);
				}

//				@Override
//				public void initializeClient(Consumer<IClientFluidTypeExtensions> consumer)
//				{
//					consumer.accept(new IClientFluidTypeExtensions()
//					{
//						private static final ResourceLocation LAVA_STILL = new ResourceLocation("block/lava_still"),
//								LAVA_FLOW = new ResourceLocation("block/lava_flow");
//
//						@Override
//						public ResourceLocation getStillTexture()
//						{
//							return LAVA_STILL;
//						}
//
//						@Override
//						public ResourceLocation getFlowingTexture()
//						{
//							return LAVA_FLOW;
//						}
//					});
//				}
			};

	@Override
	public void onInitialize() {
		class_2378.method_10230(FLUID_TYPES, PortingLib.id("empty"), EMPTY_TYPE);
		class_2378.method_10230(FLUID_TYPES, PortingLib.id("water"), WATER_TYPE);
		class_2378.method_10230(FLUID_TYPES, PortingLib.id("lava"), LAVA_TYPE);
	}

	private static Codec<Long> longRangeWithMessage(long min, long max, Function<Long, String> messageFunction) {
		return Codec.LONG.validate((value) -> {
			return value.compareTo(min) >= 0 && value.compareTo(max) <= 0 ? DataResult.success(value) : DataResult.error(() -> {
				return messageFunction.apply(value);
			});
		});
	}
}
