package io.github.fabricators_of_create.porting_lib.fluids;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import io.github.fabricators_of_create.porting_lib.core.util.MutableDataComponentHolder;
import io.github.fabricators_of_create.porting_lib.fluids.mixin.PatchedDataComponentMapAccessor;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.storage.base.ResourceAmount;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_5699;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9323;
import net.minecraft.class_9326;
import net.minecraft.class_9331;
import net.minecraft.class_9335;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
// TODO: PORT Integrate FluidVariant
/**
 * {@link class_1799} equivalent for fluids.
 * The main difference is that a fluid stack is always required to have an amount, while an item stack defaults to 1.
 * Another difference is that the component prototype of a fluid stack is currently always empty, while an item stack gets its component prototype from the item.
 *
 * <p>Most methods in this class are adapted from {@link class_1799}.
 */
public final class FluidStack implements MutableDataComponentHolder {
	public static final Codec<class_6880<class_3611>> FLUID_NON_EMPTY_CODEC = class_7923.field_41173.method_40294().validate(holder -> {
		return holder.method_55838(class_3612.field_15906.method_40178()) ? DataResult.error(() -> {
			return "Fluid must not be minecraft:empty";
		}) : DataResult.success(holder);
	});
	/**
	 * A standard codec for fluid stacks that does not accept empty stacks.
	 */
	public static final Codec<FluidStack> CODEC = Codec.lazyInitialized(
			() -> RecordCodecBuilder.create(
					instance -> instance.group(
									FLUID_NON_EMPTY_CODEC.fieldOf("id").forGetter(FluidStack::getFluidHolder),
									PortingLibFluids.POSITIVE_LONG.fieldOf("amount").forGetter(FluidStack::getAmount), // note: no .orElse(1) compared to ItemStack
									class_9326.field_49589.optionalFieldOf("components", class_9326.field_49588)
											.forGetter(stack -> stack.components.method_57940()))
							.apply(instance, FluidStack::new)));

	/**
	 * A standard codec for fluid stacks that always deserializes with a fixed amount,
	 * and does not accept empty stacks.
	 *
	 * <p>Fluid equivalent of {@link class_1799#field_49747}.
	 */
	public static Codec<FluidStack> fixedAmountCodec(long amount) {
		return Codec.lazyInitialized(
				() -> RecordCodecBuilder.create(
						instance -> instance.group(
										FLUID_NON_EMPTY_CODEC.fieldOf("id").forGetter(FluidStack::getFluidHolder),
										class_9326.field_49589.optionalFieldOf("components", class_9326.field_49588)
												.forGetter(stack -> stack.components.method_57940()))
								.apply(instance, (holder, patch) -> new FluidStack(holder, amount, patch))));
	}

	/**
	 * A standard codec for fluid stacks that accepts empty stacks, serializing them as {@code {}}.
	 */
	public static final Codec<FluidStack> OPTIONAL_CODEC = class_5699.method_57155(CODEC)
			.xmap(optional -> optional.orElse(FluidStack.EMPTY), stack -> stack.isEmpty() ? Optional.empty() : Optional.of(stack));
	/**
	 * A stream codec for fluid stacks that accepts empty stacks.
	 */
	public static final class_9139<class_9129, FluidStack> OPTIONAL_STREAM_CODEC = new class_9139<>() {
		private static final class_9139<class_9129, class_6880<class_3611>> FLUID_STREAM_CODEC = class_9135.method_56383(class_7924.field_41270);

		@Override
		public FluidStack decode(class_9129 buf) {
			long amount = buf.method_10792();
			if (amount <= 0) {
				return FluidStack.EMPTY;
			} else {
				class_6880<class_3611> holder = FLUID_STREAM_CODEC.decode(buf);
				class_9326 patch = class_9326.field_49590.decode(buf);
				return new FluidStack(holder, amount, patch);
			}
		}

		@Override
		public void encode(class_9129 buf, FluidStack stack) {
			if (stack.isEmpty()) {
				buf.method_10804(0);
			} else {
				buf.method_10791(stack.getAmount());
				FLUID_STREAM_CODEC.encode(buf, stack.getFluidHolder());
				class_9326.field_49590.encode(buf, stack.components.method_57940());
			}
		}
	};
	/**
	 * A stream codec for fluid stacks that does not accept empty stacks.
	 */
	public static final class_9139<class_9129, FluidStack> STREAM_CODEC = new class_9139<>() {
		@Override
		public FluidStack decode(class_9129 buf) {
			FluidStack stack = FluidStack.OPTIONAL_STREAM_CODEC.decode(buf);
			if (stack.isEmpty()) {
				throw new DecoderException("Empty FluidStack not allowed");
			} else {
				return stack;
			}
		}

		@Override
		public void encode(class_9129 buf, FluidStack stack) {
			if (stack.isEmpty()) {
				throw new EncoderException("Empty FluidStack not allowed");
			} else {
				FluidStack.OPTIONAL_STREAM_CODEC.encode(buf, stack);
			}
		}
	};
	private static final Logger LOGGER = LogUtils.getLogger();
	public static final FluidStack EMPTY = new FluidStack(null, null);
	private long amount;
	private final class_3611 fluid;
	private final class_9335 components;

	@Override
	public class_9335 method_57353() {
		return components;
	}

	public class_9326 getComponentsPatch() {
		return !this.isEmpty() ? this.components.method_57940() : class_9326.field_49588;
	}

	public boolean isComponentsPatchEmpty() {
		return !this.isEmpty() ? ((PatchedDataComponentMapAccessor) (Object) this.components).getPatch().isEmpty() : true;
	}

	public FluidStack(class_6880<class_3611> fluid, long amount, class_9326 patch) {
		this(fluid.comp_349(), amount, class_9335.method_57935(class_9323.field_49584, patch));
	}

	public FluidStack(class_6880<class_3611> fluid, long amount) {
		this(fluid.comp_349(), amount);
	}

	public FluidStack(class_3611 fluid, long amount) {
		this(fluid, amount, new class_9335(class_9323.field_49584));
	}

	public FluidStack(FluidVariant variant, long amount) {
		this(variant.getFluid(), amount, class_9335.method_57935(class_9323.field_49584, variant.getComponents()));
	}

	public FluidStack(StorageView<FluidVariant> view) {
		this(view.getResource(), view.getAmount());
	}

	public FluidStack(ResourceAmount<FluidVariant> resourceAmount) {
		this(resourceAmount.resource(), resourceAmount.amount());
	}

	private FluidStack(class_3611 fluid, long amount, class_9335 components) {
		this.fluid = fluid;
		this.amount = amount;
		this.components = components;
	}

	private FluidStack(@Nullable Void unused, @Nullable Void unused1) {
		this.fluid = class_3612.field_15906;
		this.components = new class_9335(class_9323.field_49584);
	}

	/**
	 * Tries to parse a fluid stack. Empty stacks cannot be parsed with this method.
	 */
	public static Optional<FluidStack> parse(class_7225.class_7874 lookupProvider, class_2520 tag) {
		return CODEC.parse(lookupProvider.method_57093(class_2509.field_11560), tag)
				.resultOrPartial(error -> LOGGER.error("Tried to load invalid fluid: '{}'", error));
	}

	/**
	 * Tries to parse a fluid stack, defaulting to {@link #EMPTY} on parsing failure.
	 */
	public static FluidStack parseOptional(class_7225.class_7874 lookupProvider, class_2487 tag) {
		return tag.method_33133() ? EMPTY : parse(lookupProvider, tag).orElse(EMPTY);
	}

	/**
	 * Checks if this fluid stack is empty.
	 */
	public boolean isEmpty() {
		return this == EMPTY || this.fluid == class_3612.field_15906 || this.amount <= 0;
	}

	/**
	 * Splits off a stack of the given amount of this stack and reduces this stack by the amount.
	 */
	public FluidStack split(long amount) {
		long i = Math.min(amount, this.amount);
		FluidStack fluidStack = this.copyWithAmount(i);
		this.shrink(i);
		return fluidStack;
	}

	/**
	 * Creates a copy of this stack with {@code 0} amount.
	 */
	public FluidStack copyAndClear() {
		if (this.isEmpty()) {
			return EMPTY;
		} else {
			FluidStack fluidStack = this.copy();
			this.setAmount(0);
			return fluidStack;
		}
	}

	/**
	 * Returns the fluid in this stack, or {@link class_3612#field_15906} if this stack is empty.
	 */
	public class_3611 getFluid() {
		return this.isEmpty() ? class_3612.field_15906 : this.fluid;
	}

	public class_6880<class_3611> getFluidHolder() {
		return this.getFluid().method_40178();
	}

	public boolean is(class_6862<class_3611> tag) {
		return this.getFluid().method_40178().method_40220(tag);
	}

	public boolean is(class_3611 fluid) {
		return this.getFluid() == fluid;
	}

	public boolean is(Predicate<class_6880<class_3611>> holderPredicate) {
		return holderPredicate.test(this.getFluidHolder());
	}

	public boolean is(class_6880<class_3611> holder) {
		return is(holder.comp_349());
	}

	public boolean is(class_6885<class_3611> holderSet) {
		return holderSet.method_40241(this.getFluidHolder());
	}

	public Stream<class_6862<class_3611>> getTags() {
		return this.getFluid().method_40178().method_40228();
	}

	/**
	 * Saves this stack to a tag, directly writing the keys into the passed tag.
	 *
	 * @throws IllegalStateException if this stack is empty
	 */
	public class_2520 save(class_7225.class_7874 lookupProvider, class_2520 prefix) {
		if (this.isEmpty()) {
			throw new IllegalStateException("Cannot encode empty FluidStack");
		} else {
			return CODEC.encode(this, lookupProvider.method_57093(class_2509.field_11560), prefix).getOrThrow();
		}
	}

	/**
	 * Saves this stack to a new tag.
	 *
	 * @throws IllegalStateException if this stack is empty
	 */
	public class_2520 save(class_7225.class_7874 lookupProvider) {
		if (this.isEmpty()) {
			throw new IllegalStateException("Cannot encode empty FluidStack");
		} else {
			return CODEC.encodeStart(lookupProvider.method_57093(class_2509.field_11560), this).getOrThrow();
		}
	}

	/**
	 * Saves this stack to a new tag. Empty stacks are supported and will be saved as an empty tag.
	 */
	public class_2520 saveOptional(class_7225.class_7874 lookupProvider) {
		return this.isEmpty() ? new class_2487() : this.save(lookupProvider, new class_2487());
	}

	/**
	 * Creates a copy of this fluid stack.
	 */
	public FluidStack copy() {
		if (this.isEmpty()) {
			return EMPTY;
		} else {
			return new FluidStack(this.fluid, this.amount, this.components.method_57941());
		}
	}

	/**
	 * Creates a copy of this fluid stack with the given amount.
	 */
	public FluidStack copyWithAmount(long amount) {
		if (this.isEmpty()) {
			return EMPTY;
		} else {
			FluidStack fluidStack = this.copy();
			fluidStack.setAmount(amount);
			return fluidStack;
		}
	}

	/**
	 * Checks if the two fluid stacks are equal. This checks the fluid, amount, and components.
	 *
	 * @return {@code true} if the two fluid stacks have equal fluid, amount, and components
	 */
	public static boolean matches(FluidStack first, FluidStack second) {
		if (first == second) {
			return true;
		} else {
			return first.getAmount() != second.getAmount() ? false : isSameFluidSameComponents(first, second);
		}
	}

	/**
	 * Checks if the two fluid stacks have the same fluid. Ignores amount and components.
	 *
	 * @return {@code true} if the two fluid stacks have the same fluid
	 */
	public static boolean isSameFluid(FluidStack first, FluidStack second) {
		return first.is(second.getFluid());
	}

	/**
	 * Checks if the two fluid stacks have the same fluid and components. Ignores amount.
	 *
	 * @return {@code true} if the two fluid stacks have the same fluid and components
	 */
	public static boolean isSameFluidSameComponents(FluidStack first, FluidStack second) {
		if (!first.is(second.getFluid())) {
			return false;
		} else {
			return first.isEmpty() && second.isEmpty() ? true : Objects.equals(first.components, second.components);
		}
	}

	public static MapCodec<FluidStack> lenientOtionalFieldOf(String fieldName) {
		return CODEC.lenientOptionalFieldOf(fieldName)
				.xmap(optional -> optional.orElse(EMPTY), stack -> stack.isEmpty() ? Optional.empty() : Optional.of(stack));
	}

	/**
	 * Hashes the fluid and components of this stack, ignoring the amount.
	 */
	public static int hashFluidAndComponents(@Nullable FluidStack stack) {
		if (stack != null) {
			int i = 31 + stack.getFluid().hashCode();
			return 31 * i + stack.method_57353().hashCode();
		} else {
			return 0;
		}
	}

	/**
	 * Returns the {@link FluidType#getDescriptionId(FluidStack) description id} of this stack.
	 */
	public String getDescriptionId() {
		return this.getFluidType().getDescriptionId(this);
	}

	@Override
	public String toString() {
		return this.getAmount() + " " + this.getFluid();
	}

	/**
	 * Sets a data component.
	 */
	@Nullable
	@Override
	public <T> T set(class_9331<? super T> type, @Nullable T component) {
		return this.components.method_57938(type, component);
	}

	/**
	 * Removes a data component.
	 */
	@Nullable
	@Override
	public <T> T remove(class_9331<? extends T> type) {
		return this.components.method_57939(type);
	}

	/**
	 * Applies a set of component changes to this stack.
	 */
	@Override
	public void applyComponents(class_9326 patch) {
		this.components.method_57936(patch);
	}

	/**
	 * Applies a set of component changes to this stack.
	 */
	@Override
	public void applyComponents(class_9323 components) {
		this.components.method_57933(components);
	}

	/**
	 * Returns the hover name of this stack.
	 */
	public class_2561 getHoverName() {
		return getFluidType().getDescription(this);
	}

	/**
	 * Returns the amount of this stack.
	 */
	public long getAmount() {
		return this.isEmpty() ? 0 : this.amount;
	}

	/**
	 * Sets the amount of this stack.
	 */
	public void setAmount(long amount) {
		this.amount = amount;
	}

	/**
	 * Limits the amount of this stack is at most the given amount.
	 */
	public void limitSize(long amount) {
		if (!this.isEmpty() && this.getAmount() > amount) {
			this.setAmount(amount);
		}
	}

	/**
	 * Adds the given amount to this stack.
	 */
	public void grow(long addedAmount) {
		this.setAmount(this.getAmount() + addedAmount);
	}

	/**
	 * Removes the given amount from this stack.
	 */
	public void shrink(long removedAmount) {
		this.grow(-removedAmount);
	}

	// Extra methods that are not directly adapted from ItemStack go below

	/**
	 * Returns the fluid type of this stack.
	 */
	public FluidType getFluidType() {
		return getFluid().getFluidType();
	}

	public FluidVariant getVariant() {
		return FluidVariant.of(this.fluid, this.components.method_57940());
	}

	/**
	 * Check if the fluid type of this stack is equal to the given fluid type.
	 */
	public boolean is(FluidType fluidType) {
		return getFluidType() == fluidType;
	}
}
