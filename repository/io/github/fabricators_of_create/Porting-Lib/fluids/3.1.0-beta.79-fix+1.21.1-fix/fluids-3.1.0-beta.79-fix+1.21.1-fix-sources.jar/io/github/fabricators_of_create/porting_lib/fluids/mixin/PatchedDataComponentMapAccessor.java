package io.github.fabricators_of_create.porting_lib.fluids.mixin;

import it.unimi.dsi.fastutil.objects.Reference2ObjectMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Optional;
import net.minecraft.class_9331;
import net.minecraft.class_9335;

@Mixin(class_9335.class)
public interface PatchedDataComponentMapAccessor {
	@Accessor
	Reference2ObjectMap<class_9331<?>, Optional<?>> getPatch();
}
