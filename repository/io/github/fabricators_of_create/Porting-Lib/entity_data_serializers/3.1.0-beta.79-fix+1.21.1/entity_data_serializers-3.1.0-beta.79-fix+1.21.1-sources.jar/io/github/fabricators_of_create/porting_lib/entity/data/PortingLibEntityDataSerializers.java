package io.github.fabricators_of_create.porting_lib.entity.data;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.fabricmc.fabric.api.event.registry.RegistryAttribute;
import net.minecraft.class_2378;
import net.minecraft.class_2941;
import net.minecraft.class_3513;
import net.minecraft.class_5321;
import org.jetbrains.annotations.Nullable;

public class PortingLibEntityDataSerializers {
	public static final class_5321<class_2378<class_2941<?>>> ENTITY_DATA_SERIALIZERS_KEY = PortingLib.key("entity_data_serializers");
	public static final class_2378<class_2941<?>> ENTITY_DATA_SERIALIZERS = FabricRegistryBuilder.createSimple(ENTITY_DATA_SERIALIZERS_KEY).attribute(RegistryAttribute.SYNCED).buildAndRegister();

	public static void init() {}

	public static final int VANILLA_SERIALIZER_LIMIT = 256;

	@Nullable
	public static class_2941<?> getSerializer(int id, class_3513<class_2941<?>> vanilla) {
		class_2941<?> serializer = vanilla.method_10200(id);
		if (serializer == null) {
			return ENTITY_DATA_SERIALIZERS.method_10200(id - VANILLA_SERIALIZER_LIMIT);
		}
		return serializer;
	}

	public static int getSerializerId(class_2941<?> serializer, class_3513<class_2941<?>> vanilla) {
		int id = vanilla.method_10206(serializer);
		if (id < 0) {
			id = ENTITY_DATA_SERIALIZERS.method_10206(serializer);
			if (id >= 0) {
				return id + VANILLA_SERIALIZER_LIMIT;
			}
		}
		return id;
	}

	@Nullable
	public static class_2941<?> getSerializer(int id, class_3513<class_2941<?>> vanilla, Operation<Object> original) {
		class_2941<?> serializer = (class_2941<?>) original.call(vanilla, id);
		if (serializer == null) {
			return ENTITY_DATA_SERIALIZERS.method_10200(id - VANILLA_SERIALIZER_LIMIT);
		}
		return serializer;
	}

	public static int getSerializerId(class_2941<?> serializer, class_3513<class_2941<?>> vanilla, Operation<Integer> original) {
		int id = original.call(vanilla, serializer);
		if (id < 0) {
			id = ENTITY_DATA_SERIALIZERS.method_10206(serializer);
			if (id >= 0) {
				return id + VANILLA_SERIALIZER_LIMIT;
			}
		}
		return id;
	}
}
