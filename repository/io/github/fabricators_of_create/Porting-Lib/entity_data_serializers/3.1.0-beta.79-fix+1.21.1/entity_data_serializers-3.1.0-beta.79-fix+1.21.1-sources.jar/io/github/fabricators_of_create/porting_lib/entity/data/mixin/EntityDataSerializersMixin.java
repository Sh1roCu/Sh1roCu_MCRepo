package io.github.fabricators_of_create.porting_lib.entity.data.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.entity.data.PortingLibEntityDataSerializers;
import net.minecraft.class_2941;
import net.minecraft.class_2943;
import net.minecraft.class_3513;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_2943.class)
public class EntityDataSerializersMixin {
	@WrapOperation(method = "getSerializer", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/CrudeIncrementalIntIdentityHashBiMap;byId(I)Ljava/lang/Object;"))
	private static Object getSerializer(class_3513<class_2941<?>> instance, int id, Operation<Object> original) {
		return PortingLibEntityDataSerializers.getSerializer(id, instance, original);
	}

	@WrapOperation(method = "getSerializedId", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/CrudeIncrementalIntIdentityHashBiMap;getId(Ljava/lang/Object;)I"))
	private static int getSerializedId(class_3513<class_2941<?>> instance, Object value, Operation<Integer> original) {
		return PortingLibEntityDataSerializers.getSerializerId((class_2941<?>) value, instance, original);
	}
}
