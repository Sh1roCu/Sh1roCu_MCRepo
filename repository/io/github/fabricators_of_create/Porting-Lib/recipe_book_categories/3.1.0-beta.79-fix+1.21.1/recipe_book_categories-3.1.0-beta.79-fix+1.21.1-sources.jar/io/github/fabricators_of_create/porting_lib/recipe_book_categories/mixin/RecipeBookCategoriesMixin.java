package io.github.fabricators_of_create.porting_lib.recipe_book_categories.mixin;

import io.github.fabricators_of_create.porting_lib.recipe_book_categories.RecipeBookRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_314;
import net.minecraft.class_5421;

@Mixin(class_314.class)
public class RecipeBookCategoriesMixin {
	@Inject(method = "getCategories", at = @At("HEAD"), cancellable = true)
	private static void getCustomCategories(class_5421 recipeBookType, CallbackInfoReturnable<List<class_314>> cir) {
		List<class_314> categories = RecipeBookRegistry.getCustomCategoriesOrNull(recipeBookType);
		if (categories != null)
			cir.setReturnValue(categories);
	}
}
