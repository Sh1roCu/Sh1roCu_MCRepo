package io.github.fabricators_of_create.porting_lib.recipe_book_categories.mixin;

import com.google.common.collect.ImmutableList;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.recipe_book_categories.RecipeBookRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1860;
import net.minecraft.class_299;
import net.minecraft.class_314;
import net.minecraft.class_3956;
import net.minecraft.class_516;
import net.minecraft.class_5455;
import net.minecraft.class_8786;

@Mixin(class_299.class)
public class ClientRecipeBookMixin {
	@Inject(method = "setupCollections", at = @At(value = "INVOKE", target = "Lcom/google/common/collect/ImmutableMap;copyOf(Ljava/util/Map;)Lcom/google/common/collect/ImmutableMap;"))
	private void setupModdedAggregateCategories(Iterable<class_1860<?>> iterable, class_5455 registryAccess, CallbackInfo ci, @Local(ordinal = 1) Map<class_314, List<class_516>> aggregateCategories) {
		RecipeBookRegistry.AGGREGATE_CATEGORIES.forEach((recipeBookCategories, list) -> {
			aggregateCategories.put(recipeBookCategories, list.stream().flatMap((recipeBookCategoriesx) ->
				aggregateCategories.getOrDefault(recipeBookCategoriesx, ImmutableList.of()).stream()
			).collect(ImmutableList.toImmutableList()));
		});
	}

	@Inject(method = "getCategory", at = @At(value = "INVOKE", target = "Lcom/mojang/logging/LogUtils;defer(Ljava/util/function/Supplier;)Ljava/lang/Object;", ordinal = 0), cancellable = true)
	private static void getCustomRecipeCategory(class_8786<?> recipe, CallbackInfoReturnable<class_314> cir) {
		class_314 categories = RecipeBookRegistry.findCategories((class_3956) recipe.comp_1933().method_17716(), recipe);
		if (categories != null)
			cir.setReturnValue(categories);
	}
}
