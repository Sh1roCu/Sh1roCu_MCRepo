package io.github.fabricators_of_create.porting_lib.recipe_book_categories;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1860;
import net.minecraft.class_314;
import net.minecraft.class_3956;
import net.minecraft.class_5421;
import net.minecraft.class_8786;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.ImmutableList;

/**
 * Manager for {@link class_5421 recipe book types} and {@link class_314 categories}.
 * <p>
 * Provides a recipe category lookup.
 */
public class RecipeBookRegistry {

	// Not using ConcurrentHashMap here because it's slower for lookups, so we only use it during init
	public static final Map<class_314, List<class_314>> AGGREGATE_CATEGORIES = new HashMap<>();
	private static final Map<class_5421, List<class_314>> TYPE_CATEGORIES = new HashMap<>();
	private static final Map<class_3956<?>, Function<class_8786<?>, class_314>> RECIPE_CATEGORY_LOOKUPS = new HashMap<>();

	/**
	 * Finds the category the specified recipe should display in, or null if none.
	 */
	@Nullable
	public static <T extends class_1860<?>> class_314 findCategories(class_3956<T> type, class_8786<T> recipe) {
		var lookup = RECIPE_CATEGORY_LOOKUPS.get(type);
		return lookup != null ? lookup.apply(recipe) : null;
	}

	@Nullable
	public static List<class_314> getCustomCategoriesOrNull(class_5421 recipeBookType) {
		return TYPE_CATEGORIES.getOrDefault(recipeBookType, null);
	}

	/**
	 * Registers the list of categories that compose an aggregate category.
	 */
	public static void registerAggregateCategory(class_314 category, List<class_314> others) {
		AGGREGATE_CATEGORIES.put(category, ImmutableList.copyOf(others));
	}

	/**
	 * Registers the list of categories that compose a recipe book.
	 */
	public static void registerBookCategories(class_5421 type, List<class_314> categories) {
		TYPE_CATEGORIES.put(type, ImmutableList.copyOf(categories));
	}

	/**
	 * Registers a category lookup for a certain recipe type.
	 */
	public static void registerRecipeCategoryFinder(class_3956<?> type, Function<class_8786<?>, class_314> lookup) {
		RECIPE_CATEGORY_LOOKUPS.put(type, lookup);
	}
}
