package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1688;
import net.minecraft.class_1922;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import org.jetbrains.annotations.Nullable;

/**
 * Implement on classes extending {@link net.minecraft.class_2241}
 */
public interface CustomRailDirectionBlock {
	/**
	 * Return the rail's direction.
	 * Can be used to make the cart think the rail is a different shape,
	 * for example when making diamond junctions or switches.
	 * The cart parameter will often be null unless it is called from {@link class_1688}.
	 *
	 * @param level The level.
	 * @param pos Block's position in level
	 * @param state The BlockState
	 * @param cart The cart asking for the metadata, null if it is not called by {@link class_1688}.
	 * @return The direction.
	 */
	default class_2768 getRailDirection(class_2680 state, class_1922 level, class_2338 pos, @Nullable class_1688 cart) {
		return state.method_11654(((class_2241) this).method_9474());
	}
}
