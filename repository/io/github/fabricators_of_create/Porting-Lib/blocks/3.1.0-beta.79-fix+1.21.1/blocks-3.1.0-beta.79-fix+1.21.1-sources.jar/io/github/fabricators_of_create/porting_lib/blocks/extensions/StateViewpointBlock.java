package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4184;

public interface StateViewpointBlock {
	/**
	 * Used to determine the state 'viewed' by an entity (see
	 * {@link class_4184#port_lib$getBlockAtCamera()}).
	 * Can be used by fluid blocks to determine if the viewpoint is within the fluid or not.
	 *
	 * @param state     the state
	 * @param level     the level
	 * @param pos       the position
	 * @param viewpoint the viewpoint
	 * @return the block state that should be 'seen'
	 */
	default class_2680 getStateAtViewpoint(class_2680 state, class_1922 level, class_2338 pos, class_243 viewpoint) {
		return state;
	}
}
