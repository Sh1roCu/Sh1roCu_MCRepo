package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import io.github.fabricators_of_create.porting_lib.blocks.injects.PlayerInjection;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1657.class)
public class PlayerMixin implements PlayerInjection {
}
