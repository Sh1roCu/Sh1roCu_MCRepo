package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import io.github.fabricators_of_create.porting_lib.blocks.BlockHooks;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface HarvestableBlock {
	/**
	 * Determines if the player can harvest this block, obtaining it's drops when the block is destroyed.
	 *
	 * @param level  The current level
	 * @param pos    The block's current position
	 * @param player The player damaging the block
	 * @return True to spawn the drops
	 */
	default boolean canHarvestBlock(class_2680 state, class_1922 level, class_2338 pos, class_1657 player) {
		return BlockHooks.doPlayerHarvestCheck(player, state, level, pos);
	}
}
