package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import io.github.fabricators_of_create.porting_lib.blocks.util.BlockEntityDataKeys;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_7225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import io.github.fabricators_of_create.porting_lib.blocks.injects.BlockEntityInjection;

@Mixin(class_2586.class)
public abstract class BlockEntityMixin implements BlockEntityInjection {
	@Unique
	private class_2487 port_lib$extraData = null;

	@Inject(at = @At("RETURN"), method = "saveMetadata")
	private void port_lib$saveMetadata(class_2487 nbt, CallbackInfo ci) {
		if (port_lib$extraData != null && !port_lib$extraData.method_33133()) {
			nbt.method_10566(BlockEntityDataKeys.EXTRA_DATA_KEY, port_lib$extraData);
		}
	}

	@Inject(at = @At("RETURN"), method = "loadWithComponents")
	private void port_lib$load(class_2487 tag, class_7225.class_7874 provider, CallbackInfo ci) {
		if (tag.method_10545(BlockEntityDataKeys.EXTRA_DATA_KEY)) {
			port_lib$extraData = tag.method_10562(BlockEntityDataKeys.EXTRA_DATA_KEY);
		}
	}

	@Override
	public class_2487 getPortingLibPersistentData() {
		if (port_lib$extraData == null) {
			port_lib$extraData = new class_2487();
		}
		return port_lib$extraData;
	}
}
