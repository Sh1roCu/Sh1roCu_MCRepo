package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_2586;
import net.minecraft.class_2818;

public interface OnLoadBlockEntity {
	/**
	 * Called when this is first added to the world (by {@link class_2818#method_12216(class_2586)})
	 * or right before the first tick when the chunk is generated or loaded from disk.
	 * Override instead of adding {@code if (firstTick)} stuff in update.
	 */
	default void onLoad() {
	}
}
