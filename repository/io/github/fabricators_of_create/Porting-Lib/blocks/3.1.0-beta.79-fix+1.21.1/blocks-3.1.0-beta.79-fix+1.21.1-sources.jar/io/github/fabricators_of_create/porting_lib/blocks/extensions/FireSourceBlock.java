package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4538;

public interface FireSourceBlock {
	/**
	 * Currently only called by fire when it is on top of this block.
	 * Returning true will prevent the fire from naturally dying during updating.
	 * Also prevents firing from dying from rain.
	 *
	 * @param state The current state
	 * @param level The current level
	 * @param pos Block position in level
	 * @param direction The direction that the fire is coming from
	 * @return True if this block sustains fire, meaning it will never go out.
	 */
	default boolean isFireSource(class_2680 state, class_4538 level, class_2338 pos, class_2350 direction) {
		return state.method_26164(level.method_8597().comp_654());
	}
}
