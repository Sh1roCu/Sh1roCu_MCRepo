package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_4538;

public interface EnchantmentBonusBlock {
	/**
	 * Determines the amount of enchanting power this block can provide to an enchanting table.
	 * @param level The level
	 * @param pos Block position in level
	 * @return The amount of enchanting power this block produces.
	 */
	default int getEnchantPowerBonus(class_2680 state, class_4538 level, class_2338 pos) {
		return state.method_26164(class_3481.field_44472) ? 1 : 0;
	}
}
