package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import java.util.function.BiConsumer;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3746;
import net.minecraft.class_4643;
import net.minecraft.class_5141;
import net.minecraft.class_5819;

@Mixin(class_5141.class)
public class TrunkPlacerMixin {
	@ModifyExpressionValue(method = "setDirtAt", at = @At(value = "FIELD", target = "Lnet/minecraft/world/level/levelgen/feature/configurations/TreeConfiguration;forceDirt:Z"))
	private static boolean shouldUseModdedDirt(boolean original, class_3746 pLevel, BiConsumer<class_2338, class_2680> pBlockSetter, class_5819 pRandom, class_2338 pPos, class_4643 pConfig) {
		return !(((net.minecraft.class_4538) pLevel).method_8320(pPos).port_lib$onTreeGrow((net.minecraft.class_4538) pLevel, pBlockSetter, pRandom, pPos, pConfig)) && original;
	}
}
