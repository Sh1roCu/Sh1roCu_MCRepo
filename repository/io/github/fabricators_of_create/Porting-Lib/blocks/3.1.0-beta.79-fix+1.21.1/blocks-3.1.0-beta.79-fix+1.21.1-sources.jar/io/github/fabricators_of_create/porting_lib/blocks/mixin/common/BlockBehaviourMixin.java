package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.blocks.BlockHooks;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.OnExplodedBlock;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_4970.class)
public class BlockBehaviourMixin {

	@WrapOperation(method = "onExplosionHit", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/Block;wasExploded(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/Explosion;)V"))
	private void onBlockExploded(class_2248 instance, class_1937 level, class_2338 blockPos, class_1927 explosion, Operation<Void> original, @Local(argsOnly = true) class_2680 state) {
		if (state.method_26204() instanceof OnExplodedBlock onExplodedBlock) {
			onExplodedBlock.onBlockExploded(state, level, blockPos, explosion);
		} else {
			original.call(instance, level, blockPos, explosion);
		}
	}

	@WrapWithCondition(method = "onExplosionHit", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z"))
	private boolean dontSetBlockOnCustom(class_1937 level, class_2338 pos, class_2680 airState, int flag, @Local(argsOnly = true) class_2680 state) {
		if (state.method_26204() instanceof OnExplodedBlock)
			return false;
		return true;
	}

	@WrapOperation(method = "getDestroyProgress", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;hasCorrectToolForDrops(Lnet/minecraft/world/level/block/state/BlockState;)Z"))
	private boolean doHarvestCheck(class_1657 instance, class_2680 state, Operation<Boolean> original, @Local(argsOnly = true) class_1922 level, @Local(argsOnly = true) class_2338 pos) {
		return BlockHooks.doPlayerHarvestCheck(instance, state, level, pos, original);
	}
}
