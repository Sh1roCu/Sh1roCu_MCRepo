package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_638;
import net.minecraft.class_702;

public interface CustomDestroyEffectsBlock {
	/**
	 * Spawn particles for when the block is destroyed. Due to the nature
	 * of how this is invoked, the x/y/z locations are not always guaranteed
	 * to host your block. So be sure to do proper sanity checks before assuming
	 * that the location is this block.
	 *
	 * @param Level   The current Level
	 * @param pos     Position to spawn the particle
	 * @param engine  A reference to the current particle engine.
	 * @return True to prevent vanilla break particles from spawning.
	 */
	@Environment(EnvType.CLIENT)
	default boolean addDestroyEffects(class_2680 state, class_638 Level, class_2338 pos, class_702 engine) {
		return !state.method_45475();
	}
}
