package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1297;
import net.minecraft.class_1510;
import net.minecraft.class_1528;
import net.minecraft.class_1687;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3481;

public interface EntityDestroyBlock {
	/**
	 * Determines if this block is can be destroyed by the specified entities normal behavior.
	 *
	 * @param state The current state
	 * @param level The current level
	 * @param pos Block position in level
	 * @return True to allow the ender dragon to destroy this block
	 */
	default boolean canEntityDestroy(class_2680 state, class_1922 level, class_2338 pos, class_1297 entity) {
		if (entity instanceof class_1510) {
			return !((class_2248)this).method_9564().method_26164(class_3481.field_17753);
		} else if ((entity instanceof class_1528) ||
				(entity instanceof class_1687)) {
			return state.method_26215() || class_1528.method_6883(state);
		}

		return true;
	}
}
