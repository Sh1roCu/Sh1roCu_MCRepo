package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.BeaconColorMultiplierBlock;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2580;
import net.minecraft.class_2680;

@Mixin(class_2580.class)
public class BeaconBlockEntityMixin {
	@ModifyExpressionValue(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/DyeColor;getTextureDiffuseColor()I"))
	private static int modifyBeaconColor(int original, class_1937 level, class_2338 beaconPos, class_2680 beaconState, class_2580 beaconBlockEntity, @Local(index = 7) class_2338 blockPos) {
		class_2680 blockState = level.method_8320(beaconPos);
		if (blockState.method_26204() instanceof BeaconColorMultiplierBlock colorMultiplierBlock)
			return colorMultiplierBlock.getBeaconColorMultiplier(blockState, level, beaconPos, beaconPos, original);
		return original;
	}
}
