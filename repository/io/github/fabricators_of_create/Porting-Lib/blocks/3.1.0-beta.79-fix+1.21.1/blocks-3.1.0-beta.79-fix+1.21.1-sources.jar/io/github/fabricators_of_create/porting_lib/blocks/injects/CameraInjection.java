package io.github.fabricators_of_create.porting_lib.blocks.injects;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import net.minecraft.class_2680;

public interface CameraInjection {
	default class_2680 port_lib$getBlockAtCamera() {
		throw PortingLib.createMixinException("CameraInjection.port_lib$getBlockAtCamera()");
	}
}
