package io.github.fabricators_of_create.porting_lib.blocks;

import java.util.Iterator;
import java.util.NoSuchElementException;
import net.minecraft.class_2586;
import net.minecraft.class_4604;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomRenderBoundingBoxBlockEntity;

public class CullingBlockEntityIterator implements Iterator<class_2586> {
	private final Iterator<? extends class_2586> wrapped;
	private final class_4604 frustum;

	private class_2586 next;
	private boolean nextChecked;

	public CullingBlockEntityIterator(Iterator<? extends class_2586> iterator, class_4604 frustum) {
		wrapped = iterator;
		this.frustum = frustum;
	}

	@Override
	public boolean hasNext() {
		ensureNextChecked();
		return next != null;
	}

	@Override
	public class_2586 next() {
		ensureNextChecked();
		if (next == null) {
			throw new NoSuchElementException();
		}
		nextChecked = false;
		return next;
	}

	@Override
	public void remove() {
		wrapped.remove();
	}

	private void ensureNextChecked() {
		if (!nextChecked) {
			next = nextCulled();
			nextChecked = true;
		}
	}

	private class_2586 nextCulled() {
		while (true) {
			if (wrapped.hasNext()) {
				class_2586 next = wrapped.next();
				if (next instanceof CustomRenderBoundingBoxBlockEntity cullable) {
					if (frustum.method_23093(cullable.getRenderBoundingBox())) {
						return next;
					}
				} else {
					return next;
				}
			} else {
				return null;
			}
		}
	}
}
