package io.github.fabricators_of_create.porting_lib.blocks.injects;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.BeaconColorMultiplierBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomSlimeBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.EntityDestroyBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.FaceHidingBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.OnTreeGrowBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.PlayerDestroyBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.StateViewpointBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.StickToBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.StickyBlock;
import org.jetbrains.annotations.NotNull;

import java.util.function.BiConsumer;
import net.minecraft.class_1297;
import net.minecraft.class_1510;
import net.minecraft.class_1528;
import net.minecraft.class_1657;
import net.minecraft.class_1687;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3610;
import net.minecraft.class_4184;
import net.minecraft.class_4275;
import net.minecraft.class_4538;
import net.minecraft.class_4643;
import net.minecraft.class_5819;

/**
 * These extensions aren't implemented themselves and are only here so modders don't need to manually check for their mod compatible interfaces preventing.
 */
public interface BlockStateInjection {
	/**
	 * @param level  The level
	 * @param pos    The position of this state
	 * @param beacon The position of the beacon
	 * @return An int RGB to be averaged with a beacon's existing beam color, or original to do nothing to the beam
	 */

	default int port_lib$getBeaconColorMultiplier(class_4538 level, class_2338 pos, class_2338 beacon, int original) {
		class_2248 block = ((class_2680) this).method_26204();
		if (block instanceof BeaconColorMultiplierBlock beaconColorMultiplierBlock)
			return beaconColorMultiplierBlock.getBeaconColorMultiplier((class_2680) this, level, pos, beacon, original);
		if (block instanceof class_4275 beamBlock)
			return beamBlock.method_10622().method_7787();
		return original;
	}

	/**
	 * Called when a player removes a block.  This is responsible for
	 * actually destroying the block, and the block is intact at time of call.
	 * This is called regardless of whether the player can harvest the block or
	 * not.
	 * <p>
	 * Return true if the block is actually destroyed.
	 * <p>
	 * Note: When used in multiplayer, this is called on both client and
	 * server sides!
	 *
	 * @param level       The current level
	 * @param player      The player damaging the block, may be null
	 * @param pos         Block position in level
	 * @param willHarvest True if Block.harvestBlock will be called after this, if the return in true.
	 *                    Can be useful to delay the destruction of tile entities till after harvestBlock
	 * @param fluid       The current fluid and block state for the position in the level.
	 * @return True if the block is actually destroyed.
	 */
	default boolean port_lib$onDestroyedByPlayer(class_1937 level, class_2338 pos, class_1657 player, boolean willHarvest, class_3610 fluid) {
		class_2248 block = ((class_2680) this).method_26204();
		if (block instanceof PlayerDestroyBlock destroyBlock)
			return destroyBlock.onDestroyedByPlayer((class_2680) this, level, pos, player, willHarvest, fluid);

		block.method_9576(level, pos, (class_2680) this, player);
		return level.method_8652(pos, fluid.method_15759(), level.field_9236 ? 11 : 3);
	}

	/**
	 * Determines if this block is can be destroyed by the specified entities normal behavior.
	 *
	 * @param level The current level
	 * @param pos   Block position in level
	 * @return True to allow the ender dragon to destroy this block
	 */
	default boolean port_lib$canEntityDestroy(class_1922 level, class_2338 pos, class_1297 entity) {
		class_2248 block = ((class_2680) this).method_26204();
		if (block instanceof EntityDestroyBlock destroyBlock)
			return destroyBlock.canEntityDestroy((class_2680) this, level, pos, entity);

		if (entity instanceof class_1510) {
			return !block.method_9564().method_26164(class_3481.field_17753);
		} else if ((entity instanceof class_1528) ||
				(entity instanceof class_1687)) {
			return ((class_2680) this).method_26215() || class_1528.method_6883((class_2680) this);
		}

		return true;
	}

	/**
	 * @return true if the block is sticky block which used for pull or push adjacent blocks (use by piston)
	 */
	default boolean port_lib$isSlimeBlock() {
		if (((class_2680) this).method_26204() instanceof CustomSlimeBlock slimeBlock)
			return slimeBlock.isSlimeBlock((class_2680) this);
		return ((class_2680) this).method_27852(class_2246.field_10030);
	}

	/**
	 * @return true if the block is sticky block which used for pull or push adjacent blocks (use by piston)
	 */
	default boolean port_lib$isStickyBlock() {
		class_2248 block = ((class_2680) this).method_26204();
		if (block instanceof StickyBlock stickyBlock)
			return stickyBlock.isStickyBlock((class_2680) this);
		return block == class_2246.field_10030 || block == class_2246.field_21211;
	}

	/**
	 * Determines if this block can stick to another block when pushed by a piston.
	 *
	 * @param other Other block
	 * @return True to link blocks
	 */
	default boolean port_lib$canStickTo(@NotNull class_2680 other) {
		class_2248 block = ((class_2680) this).method_26204();
		if (block instanceof StickToBlock stickTo)
			return stickTo.canStickTo((class_2680) this, other);
		if (block == class_2246.field_21211 && other.method_26204() == class_2246.field_10030) return false;
		if (block == class_2246.field_10030 && other.method_26204() == class_2246.field_21211) return false;
		return port_lib$isStickyBlock() || other.port_lib$isStickyBlock();
	}

	/**
	 * Called when a tree grows on top of this block and tries to set it to dirt by the trunk placer.
	 * An override that returns true is responsible for using the place function to
	 * set blocks in the world properly during generation. A modded grass block might override this method
	 * to ensure it turns into the corresponding modded dirt instead of regular dirt when a tree grows on it.
	 * For modded grass blocks, returning true from this method is NOT a substitute for adding your block
	 * to the #minecraft:dirt tag, rather for changing the behaviour to something other than setting to dirt.
	 *
	 * NOTE: This happens DURING world generation, the generation may be incomplete when this is called.
	 * Use the placeFunction when modifying the level.
	 *
	 * @param level         The current level
	 * @param placeFunction Function to set blocks in the level for the tree, use this instead of the level directly
	 * @param randomSource  The random source
	 * @param pos           Position of the block to be set to dirt
	 * @param config        Configuration of the trunk placer. Consider azalea trees, which should place rooted dirt instead of regular dirt.
	 * @return True to ignore vanilla behaviour
	 */
	default boolean port_lib$onTreeGrow(class_4538 level, BiConsumer<class_2338, class_2680> placeFunction, class_5819 randomSource, class_2338 pos, class_4643 config) {
		if (((class_2680) this).method_26204() instanceof OnTreeGrowBlock block)
			return block.onTreeGrow((class_2680) this, level, placeFunction, randomSource, pos, config);
		return false;
	}

	/**
	 * Used to determine the state 'viewed' by an entity (see
	 * {@link class_4184#port_lib$getBlockAtCamera()}).
	 * Can be used by fluid blocks to determine if the viewpoint is within the fluid or not.
	 *
	 * @param level     the level
	 * @param pos       the position
	 * @param viewpoint the viewpoint
	 * @return the block state that should be 'seen'
	 */
	default class_2680 port_lib$getStateAtViewpoint(class_1922 level, class_2338 pos, class_243 viewpoint) {
		if (((class_2680)this).method_26204() instanceof StateViewpointBlock block)
			return block.getStateAtViewpoint((class_2680) this, level, pos, viewpoint);
		return (class_2680) this;
	}

	/**
	 * Whether this block hides the neighbors face pointed towards by the given direction.
	 * <p>
	 * This method should only be used for blocks you don't control, for your own blocks override
	 * {@link net.minecraft.class_2248#method_9522(class_2680, class_2680, class_2350)}
	 * on the respective block instead
	 *
	 * @param level The world
	 * @param pos The blocks position in the world
	 * @param neighborState The neighboring blocks {@link class_2680}
	 * @param dir The direction towards the neighboring block
	 */
	default boolean port_lib$hidesNeighborFace(class_1922 level, class_2338 pos, class_2680 neighborState, class_2350 dir) {
		if (((class_2680) this).method_26204() instanceof FaceHidingBlock block)
			return block.hidesNeighborFace(level, pos, ((class_2680)this), neighborState, dir);
		return false;
	}

	/**
	 * Whether this block allows a neighboring block to hide the face of this block it touches.
	 * If this returns true, {@link BlockStateInjection#port_lib$hidesNeighborFace(class_1922, class_2338, class_2680, class_2350)}
	 * will be called on the neighboring block.
	 */
	default boolean port_lib$supportsExternalFaceHiding() {
		if (((class_2680)this).method_26204() instanceof FaceHidingBlock block)
			return block.supportsExternalFaceHiding((class_2680) this);
		return false;
	}
}
