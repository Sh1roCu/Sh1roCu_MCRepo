package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.EntityDestroyBlock;
import net.minecraft.class_1297;
import net.minecraft.class_1687;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1687.class)
public class WitherSkullMixin {
	@Unique
	private boolean customLogic = false;
	@Unique
	private boolean shouldBreak = false;

	@Inject(method = "getBlockExplosionResistance", at = @At("HEAD"))
	public void port_lib$canDestroy(class_1927 explosion, class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_3610 fluidState, float f, CallbackInfoReturnable<Float> cir) {
		if (blockState.method_26204() instanceof EntityDestroyBlock destroyBlock) {
			customLogic = true;
			shouldBreak = destroyBlock.canEntityDestroy(blockState, blockGetter, blockPos, (class_1297) (Object) this);
		} else
			customLogic = false;
	}

	@ModifyExpressionValue(method = "getBlockExplosionResistance", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/projectile/WitherSkull;isDangerous()Z"))
	public boolean port_lib$canDestroy(boolean original) {
		if (customLogic)
			return original && shouldBreak;
		return original;
	}
}
