package io.github.fabricators_of_create.porting_lib.blocks.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.PlayerDestroyBlock;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_636.class)
public class MultiPlayerGameModeMixin {
	@Shadow
	@Final
	private class_310 minecraft;

	@WrapOperation(method = "destroyBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z"))
	public boolean playerDestroyBlock(class_1937 instance, class_2338 pos, class_2680 state, int flags, Operation<Boolean> original, @Local class_3610 fluidstate) {
		if (state.method_26204() instanceof PlayerDestroyBlock destroyBlock) {
			return destroyBlock.onDestroyedByPlayer(state, instance, pos, minecraft.field_1724, false, fluidstate);
		}
		return original.call(instance, pos, state, flags);
	}
}
