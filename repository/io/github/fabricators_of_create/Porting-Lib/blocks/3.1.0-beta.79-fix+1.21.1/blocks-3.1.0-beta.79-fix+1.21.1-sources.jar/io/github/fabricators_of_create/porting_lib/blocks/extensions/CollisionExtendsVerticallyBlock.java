package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2680;
import net.minecraft.class_3481;

public interface CollisionExtendsVerticallyBlock {
	/**
	 * Determines if this block's collision box should be treated as though it can extend above its block space.
	 * Use this to replicate fence and wall behavior.
	 */
	default boolean collisionExtendsVertically(class_2680 state, class_1922 level, class_2338 pos, class_1297 collidingEntity) {
		return state.method_26164(class_3481.field_16584) || state.method_26164(class_3481.field_15504) || this instanceof class_2349;
	}
}
