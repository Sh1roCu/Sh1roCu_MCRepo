package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomFrictionBlock;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1303;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1303.class)
public abstract class ExperienceOrbMixin extends class_1297 {
	public ExperienceOrbMixin(class_1299<?> entityType, class_1937 level) {
		super(entityType, level);
	}

	@ModifyVariable(
			method = "tick",
			at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/world/level/block/Block;getFriction()F")
	)
	private float port_lib$setFriction(float original) {
		class_2338 pos = class_2338.method_49637(method_23317(), method_23318() - 1, method_23321());
		class_2680 state = method_37908().method_8320(pos);
		if (state.method_26204() instanceof CustomFrictionBlock custom) {
			return custom.getFriction(state, method_37908(), pos, this);
		}
		return original;
	}
}
