package io.github.fabricators_of_create.porting_lib.blocks.injects;

import java.util.Collection;
import net.minecraft.class_2586;

public interface LevelInjection {
	default void port_lib$addFreshBlockEntities(Collection<class_2586> beList) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}
