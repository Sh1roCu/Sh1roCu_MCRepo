package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.LightEmissiveBlock;
import net.minecraft.class_1299;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_4970.class_2251.class)
public class BlockBehavior$PropertiesMixin {
	@WrapOperation(
			// isValidSpawn lambda
			method = "method_26239",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getLightEmission()I")
	)
	private static int port_lib$customLight(class_2680 state, Operation<Integer> original,
											class_2680 state2, class_1922 level, class_2338 pos, class_1299<?> type) {
		if (state.method_26204() instanceof LightEmissiveBlock custom) {
			return custom.getLightEmission(state, level, pos);
		}
		return original.call(state);
	}
}
