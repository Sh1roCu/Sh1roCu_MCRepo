package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.SlopeCreationCheckingRailBlock;
import net.minecraft.class_1937;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_2452;
import net.minecraft.class_2680;

@Mixin(class_2452.class)
public abstract class RailStateMixin {

	@Final
	@Shadow
	private class_2241 block;

	@Shadow
	private class_2680 state;

	@Shadow
	@Final
	private class_1937 level;

	@WrapOperation(method = { "connectTo", "place" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/BaseRailBlock;isRail(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)Z"))
	private boolean port_lib$wrapRailChecksToCheckSlopes(class_1937 level, class_2338 blockPos, Operation<Boolean> original) {
		boolean canMakeSlopes = true;
		if (block instanceof SlopeCreationCheckingRailBlock checking) {
			canMakeSlopes = checking.canMakeSlopes(state, this.level, blockPos);
		}
		return original.call(level, blockPos) && canMakeSlopes;
	}

}
