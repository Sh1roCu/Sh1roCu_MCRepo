package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4538;

public interface CustomScaffoldingBlock {
	/**
	 * Normally, sneaking while sliding down a climbable block will stop sliding.
	 * On scaffolding, this is not the case, and sneaking is ignored.
	 * This is because on scaffolding, sneaking is how you descend.
	 * Checks if a player or entity handles movement on this block like scaffolding.
	 *
	 * @param state The current state
	 * @param level The current level
	 * @param pos The block position in level
	 * @param entity The entity on the scaffolding
	 * @return True if the block should act like scaffolding
	 */
	default boolean isScaffolding(class_2680 state, class_4538 level, class_2338 pos, class_1309 entity) {
		return state.method_27852(class_2246.field_16492);
	}
}
