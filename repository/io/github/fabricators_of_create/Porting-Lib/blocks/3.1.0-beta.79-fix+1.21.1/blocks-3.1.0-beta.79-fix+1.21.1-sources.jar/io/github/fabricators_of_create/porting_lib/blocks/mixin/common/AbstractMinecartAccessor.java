package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import net.minecraft.class_1688;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1688.class)
public interface AbstractMinecartAccessor {
	@Invoker("getMaxSpeed")
	double port_lib$getMaxSpeed();
}
