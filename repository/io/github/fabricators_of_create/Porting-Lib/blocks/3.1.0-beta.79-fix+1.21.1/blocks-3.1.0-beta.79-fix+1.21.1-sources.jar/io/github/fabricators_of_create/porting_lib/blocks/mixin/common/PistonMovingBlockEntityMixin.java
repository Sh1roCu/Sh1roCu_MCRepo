package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomSlimeBlock;
import net.minecraft.class_2248;
import net.minecraft.class_2669;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_2669.class)
public class PistonMovingBlockEntityMixin {
	@WrapOperation(method = "moveCollidedEntities", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/world/level/block/Block;)Z"))
	private static boolean isCustomSlimeBlock(class_2680 instance, class_2248 block, Operation<Boolean> original) {
		if (instance.method_26204() instanceof CustomSlimeBlock)
			return instance.port_lib$isSlimeBlock();
		return original.call(instance, block);
	}
}
