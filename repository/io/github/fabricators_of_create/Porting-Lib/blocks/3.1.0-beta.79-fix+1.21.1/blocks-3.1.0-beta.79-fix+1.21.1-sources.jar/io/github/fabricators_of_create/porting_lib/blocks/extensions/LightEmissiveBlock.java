package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface LightEmissiveBlock {
	default int getLightEmission(class_2680 state, class_1922 world, class_2338 pos) {
		return state.method_26213();
	}
}
