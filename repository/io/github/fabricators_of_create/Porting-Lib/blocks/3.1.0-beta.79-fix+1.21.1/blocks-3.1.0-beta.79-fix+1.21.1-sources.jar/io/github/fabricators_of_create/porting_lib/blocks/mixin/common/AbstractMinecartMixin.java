package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomRailDirectionBlock;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.MinecartPassHandlerBlock;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1688.class)
public abstract class AbstractMinecartMixin extends class_1297 {
	private AbstractMinecartMixin(class_1299<?> entityType, class_1937 world) {
		super(entityType, world);
	}

	@Inject(method = "moveAlongTrack", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/Mth;floor(D)I", ordinal = 4))
	protected void onMoveAlongTrack(class_2338 blockPos, class_2680 blockState, CallbackInfo ci) {
		if (blockState.method_26204() instanceof MinecartPassHandlerBlock handler) {
			handler.onMinecartPass(blockState, method_37908(), blockPos, (class_1688) (Object) this);
		}
	}

	@ModifyExpressionValue(method = "moveAlongTrack", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getValue(Lnet/minecraft/world/level/block/state/properties/Property;)Ljava/lang/Comparable;", ordinal = 1))
	protected Comparable<?> getRailShape(Comparable<?> original, class_2338 pos, class_2680 state) {
		if (state.method_26204() instanceof CustomRailDirectionBlock block) {
			return block.getRailDirection(state, method_37908(), pos, (class_1688) (Object) this);
		}
		return original;
	}

	@ModifyExpressionValue(method = "getPosOffs", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getValue(Lnet/minecraft/world/level/block/state/properties/Property;)Ljava/lang/Comparable;"))
	protected Comparable<?> getRailShape1(Comparable original, double x, double y, double z, @Local class_2680 state) {
		if (state.method_26204() instanceof CustomRailDirectionBlock block) {
			return block.getRailDirection(state, method_37908(), new class_2338(class_3532.method_15357(x), class_3532.method_15357(y), class_3532.method_15357(z)), (class_1688) (Object) this);
		}
		return original;
	}

	@ModifyExpressionValue(method = "getPos", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getValue(Lnet/minecraft/world/level/block/state/properties/Property;)Ljava/lang/Comparable;"))
	protected Comparable<?> getRailShape2(Comparable original, double x, double y, double z, @Local class_2680 state) {
		if (state.method_26204() instanceof CustomRailDirectionBlock block) {
			return block.getRailDirection(state, method_37908(), new class_2338(class_3532.method_15357(x), class_3532.method_15357(y), class_3532.method_15357(z)), (class_1688) (Object) this);
		}
		return original;
	}
}
