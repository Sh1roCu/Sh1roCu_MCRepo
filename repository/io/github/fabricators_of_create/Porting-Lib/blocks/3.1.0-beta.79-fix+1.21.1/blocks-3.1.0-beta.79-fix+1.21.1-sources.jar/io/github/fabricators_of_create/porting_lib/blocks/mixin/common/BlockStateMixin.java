package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import io.github.fabricators_of_create.porting_lib.blocks.injects.BlockStateInjection;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2680.class)
public class BlockStateMixin implements BlockStateInjection {
}
