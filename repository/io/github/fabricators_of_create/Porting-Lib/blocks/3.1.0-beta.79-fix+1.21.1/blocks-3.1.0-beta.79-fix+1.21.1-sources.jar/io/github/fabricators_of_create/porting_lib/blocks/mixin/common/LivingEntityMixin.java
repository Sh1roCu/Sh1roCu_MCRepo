package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomFrictionBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomLadderBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomLandingEffectsBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomScaffoldingBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.SupportsClimbableOpenTrapdoorBlock;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 {
	public LivingEntityMixin(class_1299<?> entityType, class_1937 level) {
		super(entityType, level);
	}

	@SuppressWarnings("InvalidInjectorMethodSignature")
	@Inject(
			method = "checkFallDamage",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/server/level/ServerLevel;sendParticles(Lnet/minecraft/core/particles/ParticleOptions;DDDIDDDD)I",
					shift = At.Shift.BEFORE
			),
			cancellable = true
	)
	protected void updateFallState(double y, boolean onGround, class_2680 state, class_2338 pos,
								   CallbackInfo ci, @Local(index = 19) int count) {
		if (state.method_26204() instanceof CustomLandingEffectsBlock custom &&
				custom.addLandingEffects(state, (class_3218) method_37908(), pos, state, (class_1309) (Object) this, count)) {
			super.method_5623(y, onGround, state, pos);
			ci.cancel();
		}
	}

	@ModifyExpressionValue(
			method = "handleOnClimbable",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/world/level/block/Block;)Z"
			)
	)
	private boolean customScaffoldingMovement(boolean original) {
		class_2680 state = method_55667();
		if (state.method_26204() instanceof CustomScaffoldingBlock custom)
			return custom.isScaffolding(state, method_37908(), method_24515(), (class_1309) (Object) this);
		return original;
	}

	@SuppressWarnings("InvalidInjectorMethodSignature")
	@ModifyVariable(
			method = "travel",
			slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;getBlockPosBelowThatAffectsMyMovement()Lnet/minecraft/core/BlockPos;")),
			at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/world/level/block/Block;getFriction()F")
	)
	public float port_lib$setSlipperiness(float p) {
		class_2338 pos = method_23314();
		class_2680 state = method_37908().method_8320(pos);
		if (state.method_26204() instanceof CustomFrictionBlock custom) {
			return custom.getFriction(state, method_37908(), pos, (class_1309) (Object) this);
		}
		return p;
	}

	@WrapOperation(method = "onClimbable", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/tags/TagKey;)Z", ordinal = 0))
	private boolean port_lib$tryUseCustomLadder(class_2680 instance, class_6862 tagKey, Operation<Boolean> original, @Local class_2338 pos) {
		if (instance.method_26204() instanceof CustomLadderBlock ladderBlock) {
			return ladderBlock.isLadder(instance, method_37908(), pos, (class_1309) (Object) this);
		}

		return original.call(instance, tagKey);
	}

	@ModifyReturnValue(method = "trapdoorUsableAsLadder", at = @At(value = "RETURN", ordinal = 1))
	private boolean port_lib$tryCheckCanClimbTrapdoor(boolean original, @Local(argsOnly = true) class_2338 pos, @Local(argsOnly = true) class_2680 state) {
		class_2338 belowPos = pos.method_10074();
		class_2680 belowState = this.method_37908().method_8320(belowPos); // TODO: Can't access the local one, for some reason...

		if (belowState.method_26204() instanceof SupportsClimbableOpenTrapdoorBlock climbableOpenTrapdoorBlock) {
			return climbableOpenTrapdoorBlock.makesOpenTrapdoorAboveClimbable(belowState, this.method_37908(), belowPos, state);
		}

		return original;
	}
}
