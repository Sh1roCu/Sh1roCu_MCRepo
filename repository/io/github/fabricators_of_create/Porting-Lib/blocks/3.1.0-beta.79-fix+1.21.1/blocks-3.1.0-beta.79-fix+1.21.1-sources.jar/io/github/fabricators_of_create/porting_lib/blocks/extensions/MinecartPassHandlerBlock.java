package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface MinecartPassHandlerBlock {
	void onMinecartPass(class_2680 state, class_1937 world, class_2338 pos, class_1688 cart);
}
