package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.VanillaCustomExpBlock;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2496;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2496.class)
public abstract class SpawnerBlockMixin implements VanillaCustomExpBlock {

	// Port Lib: Patch-in override for getExpDrop. Also fixes MC-273642 (Spawner XP drops bypass enchantments)
	// Original vanilla logic passes 15 + level.random.nextInt(15) + level.random.nextInt(15) to popExperience, bypassing enchantments
	@Override
	public int port_lib$getExpDrop(class_2680 state, class_1936 level, class_2338 pos,
								   @Nullable class_2586 blockEntity,
								   @Nullable class_1297 breaker, class_1799 tool) {
		return 15 + level.method_8409().method_43048(15) + level.method_8409().method_43048(15);
	}
}
