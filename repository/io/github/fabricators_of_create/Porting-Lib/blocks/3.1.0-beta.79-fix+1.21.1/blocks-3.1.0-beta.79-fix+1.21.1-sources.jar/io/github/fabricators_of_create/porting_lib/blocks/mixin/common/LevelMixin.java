package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.NeighborChangeListeningBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.OnLoadBlockEntity;
import io.github.fabricators_of_create.porting_lib.blocks.injects.LevelInjection;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.Collection;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

@Mixin(class_1937.class)
public abstract class LevelMixin implements class_1936, LevelInjection {
	@Shadow
	private boolean tickingBlockEntities;
	private final ArrayList<class_2586> port_lib$freshBlockEntities = new ArrayList<>();
	private final ArrayList<class_2586> port_lib$pendingFreshBlockEntities = new ArrayList<>();

	@Inject(method = "tickBlockEntities", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiling/ProfilerFiller;push(Ljava/lang/String;)V", shift = At.Shift.AFTER))
	public void port_lib$pendingBlockEntities(CallbackInfo ci) {
		if (!this.port_lib$pendingFreshBlockEntities.isEmpty()) {
			this.port_lib$freshBlockEntities.addAll(this.port_lib$pendingFreshBlockEntities);
			this.port_lib$pendingFreshBlockEntities.clear();
		}
	}

	@Inject(method = "tickBlockEntities", at = @At(value = "INVOKE", target = "Ljava/util/List;isEmpty()Z"))
	public void port_lib$onBlockEntitiesLoad(CallbackInfo ci) {
		if (!this.port_lib$freshBlockEntities.isEmpty()) {
			this.port_lib$freshBlockEntities.forEach(blockEntity -> {
				if (blockEntity instanceof OnLoadBlockEntity be) be.onLoad();
			});
			this.port_lib$freshBlockEntities.clear();
		}
	}

	@Unique
	@Override
	public void port_lib$addFreshBlockEntities(Collection<class_2586> beList) {
		if (this.tickingBlockEntities) {
			this.port_lib$pendingFreshBlockEntities.addAll(beList);
		} else {
			this.port_lib$freshBlockEntities.addAll(beList);
		}
	}

	@Inject(
			method = "updateNeighbourForOutputSignal",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/world/level/block/Block;)Z",
					ordinal = 0
			)
	)
	public void port_lib$updateNeighbourForOutputSignal(class_2338 pos, class_2248 block, CallbackInfo ci,
														@Local(ordinal = 1) class_2338 offset, @Local class_2680 state) {
		if (state.method_26204() instanceof NeighborChangeListeningBlock listener) {
			listener.onNeighborChange(state, this, offset, pos);
		}
	}
}
