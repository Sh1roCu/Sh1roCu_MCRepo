package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.WeakPowerCheckingBlock;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_8235;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_8235.class)
public interface SignalGetterMixin extends class_1922 {
	@WrapOperation(
			method = "getSignal",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/block/state/BlockState;isRedstoneConductor(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z"
			)
	)
	private boolean port_lib$modifyRedstoneSignal(class_2680 state, class_1922 level, class_2338 pos, Operation<Boolean> original,
												  class_2338 pos2, class_2350 facing) {
		if (state.method_26204() instanceof WeakPowerCheckingBlock checking) {
			return checking.shouldCheckWeakPower(state, (class_8235) this, pos, facing);
		}
		return original.call(state, level, pos);
	}
}
