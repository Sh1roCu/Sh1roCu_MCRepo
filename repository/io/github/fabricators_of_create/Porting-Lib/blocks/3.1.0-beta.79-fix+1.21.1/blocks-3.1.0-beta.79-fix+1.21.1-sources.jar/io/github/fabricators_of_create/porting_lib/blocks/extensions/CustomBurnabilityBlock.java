package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_2358;
import net.minecraft.class_2680;

/**
 * Allows blocks to control their burnability based on their state
 * @see class_2358#method_10195(class_2680)
 */
public interface CustomBurnabilityBlock {
	/**
	 * @return true if the provided state is burnable by fire
	 */
	boolean canBurn(class_2680 state);
}
