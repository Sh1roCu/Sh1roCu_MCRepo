package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.FlammableBlock;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2530;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_2530.class)
public class TntBlockMixin {
	@WrapOperation(method = "onPlace", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/TntBlock;explode(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)V"))
	private void onPlaceExplode(class_1937 level, class_2338 pos, Operation<Void> original, class_2680 state) {
		if (state.method_26204() instanceof FlammableBlock block)
			block.onCaughtFire(state, level, pos, null, null);
		else
			original.call(level, pos);
	}

	@WrapOperation(method = "neighborChanged", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/TntBlock;explode(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)V"))
	private void neighborChangedExplode(class_1937 level, class_2338 pos, Operation<Void> original, class_2680 state) {
		if (state.method_26204() instanceof FlammableBlock block)
			block.onCaughtFire(state, level, pos, null, null);
		else
			original.call(level, pos);
	}

	@WrapOperation(method = "playerWillDestroy", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/TntBlock;explode(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)V"))
	private void playerWillDestroyExplode(class_1937 level, class_2338 pos, Operation<Void> original, @Local(argsOnly = true) class_2680 state) {
		if (state.method_26204() instanceof FlammableBlock block)
			block.onCaughtFire(state, level, pos, null, null);
		else
			original.call(level, pos);
	}

	@WrapOperation(method = "useItemOn", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/TntBlock;explode(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/LivingEntity;)V"))
	private void useItemOnExplode(class_1937 level, class_2338 pos, class_1309 entity, Operation<Void> original, @Local(argsOnly = true) class_2680 state, @Local(argsOnly = true) class_1657 player, @Local(argsOnly = true) class_3965 hitResult) {
		if (state.method_26204() instanceof FlammableBlock block)
			block.onCaughtFire(state, level, pos, hitResult.method_17780(), player);
		else
			original.call(level, pos, entity);
	}

	@WrapOperation(method = "onProjectileHit", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/TntBlock;explode(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/LivingEntity;)V"))
	private void onProjectileHitExplode(class_1937 level, class_2338 pos, class_1309 entity, Operation<Void> original, @Local(argsOnly = true) class_2680 state) {
		if (state.method_26204() instanceof FlammableBlock block)
			block.onCaughtFire(state, level, pos, null, entity);
		else
			original.call(level, pos, entity);
	}
}
