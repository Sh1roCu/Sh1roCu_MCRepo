package io.github.fabricators_of_create.porting_lib.blocks.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.blocks.CullingBlockEntityIterator;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.LightEmissiveBlock;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Slice;

import java.util.Iterator;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_4604;
import net.minecraft.class_761;

@Mixin(class_761.class)
public class LevelRendererMixin {
	@Shadow
	private class_4604 cullingFrustum;

	@Shadow
	@Nullable
	private class_4604 capturedFrustum;

	@ModifyVariable(
			method = "renderLevel",
			slice = @Slice(
					from = @At(
							value = "INVOKE",
							target = "Lnet/minecraft/client/renderer/chunk/SectionRenderDispatcher$CompiledSection;getRenderableBlockEntities()Ljava/util/List;"
					),
					to = @At(
							value = "INVOKE",
							target = "Lnet/minecraft/client/renderer/OutlineBufferSource;endOutlineBatch()V"
					)
			),
			at = @At("STORE")
	)
	private Iterator<class_2586> port_lib$wrapBlockEntityIterator(Iterator<class_2586> iterator) {
		return new CullingBlockEntityIterator(iterator, capturedFrustum != null ? capturedFrustum : cullingFrustum);
	}

	@WrapOperation(
			method = "getLightColor(Lnet/minecraft/world/level/BlockAndTintGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;)I",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/block/state/BlockState;getLightEmission()I"
			)
	)
	private static int port_lib$customLight(class_2680 state, Operation<Integer> original,
											class_1920 world, class_2680 state2, class_2338 pos) {
		if (state.method_26204() instanceof LightEmissiveBlock custom) {
			return custom.getLightEmission(state, world, pos);
		}
		return original.call(state);
	}
}
