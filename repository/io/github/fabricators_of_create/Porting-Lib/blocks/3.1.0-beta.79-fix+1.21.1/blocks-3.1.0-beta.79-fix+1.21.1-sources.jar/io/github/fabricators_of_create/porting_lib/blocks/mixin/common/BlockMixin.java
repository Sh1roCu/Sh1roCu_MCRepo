package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_2248.class)
public abstract class BlockMixin extends class_4970 {
	private BlockMixin(class_4970.class_2251 properties) {
		super(properties);
	}

	@ModifyExpressionValue(
			method = "shouldRenderFace",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/block/state/BlockState;skipRendering(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)Z"
			)
	)
	private static boolean customFaceHiding(boolean orignial, class_2680 pState, class_1922 pLevel, class_2338 pOffset, class_2350 pFace, class_2338 pPos) {
		return orignial || (pState.port_lib$supportsExternalFaceHiding() && pLevel.method_8320(pPos).port_lib$hidesNeighborFace(pLevel, pPos, pState, pFace.method_10153()));
	}
}
