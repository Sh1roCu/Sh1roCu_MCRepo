package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface OnExplodedBlock {
	/**
	 * Called when the block is destroyed by an explosion.
	 * Useful for allowing the block to take into account tile entities,
	 * state, etc. when exploded, before it is removed.
	 *
	 * @param level     The current level
	 * @param pos       Block position in level
	 * @param explosion The explosion instance affecting the block
	 */
	default void onBlockExploded(class_2680 state, class_1937 level, class_2338 pos, class_1927 explosion) {
		level.method_8652(pos, class_2246.field_10124.method_9564(), 3);
		((class_2248) this).method_9586(level, pos, explosion);
	}
}
