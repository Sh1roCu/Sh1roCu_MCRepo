package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.EnchantmentBonusBlock;
import net.minecraft.class_1937;
import net.minecraft.class_2331;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_6862;

@Mixin(class_2331.class)
public abstract class EnchantmentTableBlockMixin {
	@WrapOperation(method = "isValidBookShelf", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/tags/TagKey;)Z", ordinal = 0))
	private static boolean checkIsValid(class_2680 state, class_6862<class_2680> tagKey, Operation<Boolean> original, class_1937 level, class_2338 enchantingTablePos, class_2338 bookshelfPos) {
		if (state.method_26204() instanceof EnchantmentBonusBlock bonusBlock) {
			return bonusBlock.getEnchantPowerBonus(state, level, enchantingTablePos.method_10081(bookshelfPos)) != 0;
		}

		return original.call(state, tagKey);
	}
}
