package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_7225;

public interface CustomUpdateTagHandlingBlockEntity {
	/**
	 * Called when the chunk's BE update tag, gotten from {@link class_2586#method_16887(class_7225.class_7874)}, is received on the client.
	 * <p>
	 * Used to handle this tag in a special way. By default this simply calls {@link class_2586#method_58690(class_2487, class_7225.class_7874)}.
	 *
	 * @param tag The {@link class_2487} sent from {@link class_2586#method_16887(class_7225.class_7874)}
	 */
	default void handleUpdateTag(class_2487 tag, class_7225.class_7874 lookupProvider) {
		((class_2586) this).method_58690(tag, lookupProvider);
	}
}
