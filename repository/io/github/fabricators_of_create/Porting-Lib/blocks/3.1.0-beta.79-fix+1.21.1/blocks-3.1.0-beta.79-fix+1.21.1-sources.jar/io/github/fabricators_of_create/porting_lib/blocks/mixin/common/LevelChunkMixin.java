package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.ChunkUnloadListeningBlockEntity;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomUpdateTagHandlingBlockEntity;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.OnLoadBlockEntity;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2843;
import net.minecraft.class_5539;
import net.minecraft.class_6749;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2818.class)
public abstract class LevelChunkMixin extends class_2791 {
	@Shadow
	@Final
	class_1937 level;

	@Shadow
	public abstract class_2680 method_8320(class_2338 pos);

	@Shadow
	public abstract class_1937 getLevel();

	public LevelChunkMixin(class_1923 chunkPos, class_2843 upgradeData, class_5539 levelHeightAccessor, class_2378<class_1959> registry, long l, @Nullable class_2826[] levelChunkSections, @Nullable class_6749 blendingData) {
		super(chunkPos, upgradeData, levelHeightAccessor, registry, l, levelChunkSections, blendingData);
	}

	@Inject(method = "clearAllBlockEntities", at = @At("HEAD"))
	private void port_lib$blockEntityClear(CallbackInfo ci) {
		field_34543.values().forEach(be -> {
			if (be instanceof ChunkUnloadListeningBlockEntity listener) {
				listener.onChunkUnloaded();
			}
		});
	}

	@WrapWithCondition(method = "method_31716",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/entity/BlockEntity;loadWithComponents(Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/core/HolderLookup$Provider;)V")
	)
	private boolean handleBlockEntityUpdateTag(class_2586 instance, class_2487 tag, class_7225.class_7874 provider) {
		if (instance instanceof CustomUpdateTagHandlingBlockEntity handler) {
			handler.handleUpdateTag(tag, provider);
			return false;
		}
		return true;
	}

	@Inject(method = "addAndRegisterBlockEntity", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/chunk/LevelChunk;updateBlockEntityTicker(Lnet/minecraft/world/level/block/entity/BlockEntity;)V", shift = At.Shift.AFTER))
	public void port_lib$onBlockEntityLoad(class_2586 blockEntity, CallbackInfo ci) {
		if (blockEntity instanceof OnLoadBlockEntity be)
			be.onLoad();
	}

	@Inject(method = "registerAllBlockEntitiesAfterLevelLoad", at = @At("HEAD"))
	public void port_lib$addPendingBlockEntities(CallbackInfo ci) {
		this.level.port_lib$addFreshBlockEntities(this.field_34543.values());
	}
}
