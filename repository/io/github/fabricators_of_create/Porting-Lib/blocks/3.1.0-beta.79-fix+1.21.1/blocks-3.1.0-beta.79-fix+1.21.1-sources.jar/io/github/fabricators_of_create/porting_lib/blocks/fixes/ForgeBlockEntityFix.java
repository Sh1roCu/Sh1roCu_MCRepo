package io.github.fabricators_of_create.porting_lib.blocks.fixes;

import com.mojang.datafixers.DSL;
import com.mojang.datafixers.DataFix;
import com.mojang.datafixers.TypeRewriteRule;

import com.mojang.datafixers.schemas.Schema;
import com.mojang.serialization.Dynamic;

import io.github.fabricators_of_create.porting_lib.blocks.util.BlockEntityDataKeys;
import net.minecraft.class_1208;

public class ForgeBlockEntityFix extends DataFix {
	public static final String LEGACY_DATA_KEY = "ForgeData";
	public static final String NEO_DATA_KEY = BlockEntityDataKeys.EXTRA_DATA_KEY;

	public ForgeBlockEntityFix(Schema outputSchema, boolean changesType) {
		super(outputSchema, changesType);
	}

	public Dynamic<?> fix(Dynamic<?> original) {
		return original.renameField(LEGACY_DATA_KEY, NEO_DATA_KEY).renameField(BlockEntityDataKeys.OLD_EXTRA_DATA_KEY, NEO_DATA_KEY);
	}

	@Override
	protected TypeRewriteRule makeRule() {
		return this.fixTypeEverywhereTyped("jigsaw_rotation_fix", this.getInputSchema().getType(class_1208.field_5727), (typed) -> {
			return typed.update(DSL.remainderFinder(), this::fix);
		});
	}
}
