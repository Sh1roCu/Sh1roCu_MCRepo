package io.github.fabricators_of_create.porting_lib.blocks.injects;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;

import io.github.fabricators_of_create.porting_lib.blocks.BlockHooks;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface PlayerInjection {
	default boolean port_lib$hasCorrectToolForDrops(class_2680 state, class_1937 level, class_2338 pos) {
		return BlockHooks.doPlayerHarvestCheck((class_1657) this, state, level, pos);
	}

	default boolean port_lib$hasCorrectToolForDrops(class_2680 state, class_1937 level, class_2338 pos, Operation<Boolean> original) {
		return BlockHooks.doPlayerHarvestCheck((class_1657) this, state, level, pos, original);
	}
}
