package io.github.fabricators_of_create.porting_lib.blocks;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.player.PlayerEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public final class BlockEvents {
	private BlockEvents() {}

	/**
	 * HarvestCheck is fired when a player attempts to harvest a block.<br>
	 * This event is fired whenever a player attempts to harvest a block in
	 * {@link class_1657#method_7305(class_2680)}.<br>
	 * <br>
	 * This event is fired via the {@link BlockHooks#doPlayerHarvestCheck(class_1657, class_2680, class_1922, class_2338)}.<br>
	 * <br>
	 * {@link #state} contains the {@link class_2680} that is being checked for harvesting. <br>
	 * {@link #success} contains the boolean value for whether the Block will be successfully harvested. <br>
	 * <br>
	 * This event is not {@link CancellableEvent}.<br>
	 * <br>
	 **/
	public static class HarvestCheck extends PlayerEvent {
		public static final Event<HarvestCheckCallback> EVENT = EventFactory.createArrayBacked(HarvestCheckCallback.class, callbacks -> evnet -> {
			for (HarvestCheckCallback callback : callbacks)
				callback.onHarvest(evnet);
		});

		private final class_2680 state;
		private final class_1922 level;
		private final class_2338 pos;
		private boolean success;

		public HarvestCheck(class_1657 player, class_2680 state, class_1922 level, class_2338 pos, boolean success) {
			super(player);
			this.state = state;
			this.level = level;
			this.pos = pos;
			this.success = success;
		}

		public class_2680 getTargetBlock() {
			return this.state;
		}

		public class_1922 getLevel() {
			return level;
		}

		public class_2338 getPos() {
			return pos;
		}

		public boolean canHarvest() {
			return this.success;
		}

		public void setCanHarvest(boolean success) {
			this.success = success;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onHarvest(this);
		}
	}

	public interface HarvestCheckCallback {
		void onHarvest(HarvestCheck event);
	}
}
