package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4275;
import net.minecraft.class_4538;

public interface BeaconColorMultiplierBlock {
	/**
	 * @param state The state
	 * @param level The level
	 * @param pos The position of this state
	 * @param beaconPos The position of the beacon
	 * @return A float RGB [0.0, 1.0] array to be averaged with a beacon's existing beam color, or null to do nothing to the beam
	 */
	default int getBeaconColorMultiplier(class_2680 state, class_4538 level, class_2338 pos, class_2338 beaconPos, int original) {
		if (this instanceof class_4275 beamBlock)
			return beamBlock.method_10622().method_7787();
		return original;
	}
}
