package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_2246;
import net.minecraft.class_2680;

public interface StickyBlock {
	/**
	 * @param state The state
	 * @return true if the block is sticky block which used for pull or push adjacent blocks (use by piston)
	 */
	default boolean isStickyBlock(class_2680 state) {
		return state.method_26204() == class_2246.field_10030 || state.method_26204() == class_2246.field_21211;
	}
}
