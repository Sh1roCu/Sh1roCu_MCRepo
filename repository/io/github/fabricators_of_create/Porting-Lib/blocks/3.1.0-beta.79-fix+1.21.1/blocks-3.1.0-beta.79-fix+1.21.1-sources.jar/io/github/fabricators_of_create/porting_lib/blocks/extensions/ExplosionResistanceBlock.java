package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface ExplosionResistanceBlock {
	/**
	 * Location sensitive version of getExplosionResistance
	 *
	 * @param level The current level
	 * @param pos Block position in level
	 * @param explosion The explosion
	 * @return The amount of the explosion absorbed.
	 */
	default float getExplosionResistance(class_2680 state, class_1922 level, class_2338 pos, class_1927 explosion) {
		return ((class_2248) this).method_9520();
	}
}
