package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_8235;

public interface WeakPowerCheckingBlock {
	/**
	 * Called to determine whether to allow the block to handle its own indirect power rather than using the default rules.
	 *
	 * @param level The level
	 * @param pos   Block position in level
	 * @param side  The INPUT side of the block to be powered - ie the opposite of this block's output side
	 * @return Whether Block#isProvidingWeakPower should be called when determining indirect power
	 */
	default boolean shouldCheckWeakPower(class_2680 state, class_8235 level, class_2338 pos, class_2350 side) {
		return state.method_26212(level, pos);
	}
}
