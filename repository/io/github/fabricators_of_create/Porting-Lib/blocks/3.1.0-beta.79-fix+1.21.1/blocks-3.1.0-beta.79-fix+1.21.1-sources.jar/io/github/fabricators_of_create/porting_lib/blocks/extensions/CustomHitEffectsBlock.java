package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_702;

/**
 * Use client extensions module implementing this on a blocks is dangerous and hacky
 */
@Deprecated(forRemoval = true)
public interface CustomHitEffectsBlock {
	/**
	 * Spawn a digging particle effect in the level, this is a wrapper
	 * around EffectRenderer.addBlockHitEffects to allow the block more
	 * control over the particles. Useful when you have entirely different
	 * texture sheets for different sides/locations in the level.
	 *
	 * @param state   The current state
	 * @param level   The current level
	 * @param target  The target the player is looking at {x/y/z/side/sub}
	 * @param manager A reference to the current particle manager.
	 * @return True to prevent vanilla digging particles form spawning.
	 */
	default boolean addHitEffects(class_2680 state, class_1937 level, class_239 target, class_702 manager) {
		return false;
	}
}
