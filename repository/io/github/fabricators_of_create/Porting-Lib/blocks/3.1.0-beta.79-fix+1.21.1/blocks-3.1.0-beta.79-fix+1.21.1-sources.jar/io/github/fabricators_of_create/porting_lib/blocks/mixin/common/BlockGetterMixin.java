package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.LightEmissiveBlock;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1922.class)
public interface BlockGetterMixin {
	@Shadow
	class_2680 getBlockState(class_2338 pos);

	@WrapOperation(
			method = "getLightEmission",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/block/state/BlockState;getLightEmission()I"
			)
	)
	private int port_lib$customLight(class_2680 state, Operation<Integer> original,
									 class_2338 pos) {
		if (state.method_26204() instanceof LightEmissiveBlock custom) {
			return custom.getLightEmission(state, (class_1922) this, pos);
		}
		return original.call(state);
	}
}
