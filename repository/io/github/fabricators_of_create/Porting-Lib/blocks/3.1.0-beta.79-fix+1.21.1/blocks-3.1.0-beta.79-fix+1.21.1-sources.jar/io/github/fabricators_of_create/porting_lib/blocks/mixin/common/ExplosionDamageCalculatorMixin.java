package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.ExplosionResistanceBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_5362;

@Mixin(class_5362.class)
public abstract class ExplosionDamageCalculatorMixin {
	@Inject(method = "getBlockExplosionResistance", at = @At("HEAD"), cancellable = true)
	public void port_lib$explosionBlock(class_1927 explosion, class_1922 reader, class_2338 pos, class_2680 state, class_3610 fluid, CallbackInfoReturnable<Optional<Float>> cir) {
		if (state.method_26204() instanceof ExplosionResistanceBlock resistanceBlock)
			cir.setReturnValue(state.method_26215() && fluid.method_15769()
					? Optional.empty()
					: Optional.of(Math.max(resistanceBlock.getExplosionResistance(state, reader, pos, explosion), fluid.method_15760())));
	}
}
