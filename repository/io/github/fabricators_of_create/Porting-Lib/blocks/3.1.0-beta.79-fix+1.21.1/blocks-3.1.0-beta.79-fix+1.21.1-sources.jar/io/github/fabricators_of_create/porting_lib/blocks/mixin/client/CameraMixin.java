package io.github.fabricators_of_create.porting_lib.blocks.mixin.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import io.github.fabricators_of_create.porting_lib.blocks.injects.CameraInjection;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4184;

@Mixin(class_4184.class)
public abstract class CameraMixin implements CameraInjection {
	@Shadow
	private float yRot;

	@Shadow
	private float xRot;

	@Shadow
	private boolean initialized;

	@Shadow
	private class_1922 level;

	@Shadow
	@Final
	private class_2338.class_2339 blockPosition;

	@Shadow
	private class_243 position;

	@Override
	public class_2680 port_lib$getBlockAtCamera() {
		if (!this.initialized)
			return class_2246.field_10124.method_9564();
		else
			return this.level.method_8320(this.blockPosition).port_lib$getStateAtViewpoint(this.level, this.blockPosition, this.position);
	}
}
