package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import io.github.fabricators_of_create.porting_lib.blocks.mixin.common.FireBlockAccessor;
import javax.annotation.Nullable;
import net.minecraft.class_1309;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2530;
import net.minecraft.class_2680;

public interface FlammableBlock {
	// These methods are here because fabric doesn't expose their registry and I can't be assed to support it, forge allows for more customization anyway
	/**
	 * Chance that fire will spread and consume this block.
	 * 300 being a 100% chance, 0, being a 0% chance.
	 *
	 * @param state     The current state
	 * @param level     The current level
	 * @param pos       Block position in level
	 * @param direction The direction that the fire is coming from
	 * @return A number ranging from 0 to 300 relating used to determine if the block will be consumed by fire
	 */
	default int getFlammability(class_2680 state, class_1922 level, class_2338 pos, @Nullable class_2350 direction) {
		return ((FireBlockAccessor) class_2246.field_10036).callGetBurnOdds(state);
	}

	/**
	 * Called when fire is updating on a neighbor block.
	 * The higher the number returned, the faster fire will spread around this block.
	 *
	 * @param state     The current state
	 * @param level     The current level
	 * @param pos       Block position in level
	 * @param direction The direction that the fire is coming from
	 * @return A number that is used to determine the speed of fire growth around the block
	 */
	default int getFireSpreadSpeed(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
		return ((FireBlockAccessor) class_2246.field_10036).callGetIgniteOdds(state);
	}

	/**
	 * Called when fire is updating, checks if a block face can catch fire.
	 *
	 *
	 * @param state     The current state
	 * @param level     The current level
	 * @param pos       Block position in level
	 * @param direction The direction that the fire is coming from
	 * @return True if the face can be on fire, false otherwise.
	 */
	default boolean isFlammable(class_2680 state, class_1922 level, class_2338 pos, class_2350 direction) {
		if (state.method_26204() instanceof FlammableBlock block) {
			return block.getFlammability(state, level, pos, direction) > 0;
		}
		return ((FireBlockAccessor) class_2246.field_10036).callGetBurnOdds(state) > 0;
	}

	/**
	 * If the block is flammable, this is called when it gets lit on fire.
	 *
	 * @param state The current state
	 * @param level The current level
	 * @param pos Block position in level
	 * @param direction The direction that the fire is coming from
	 * @param igniter The entity that lit the fire
	 */
	default void onCaughtFire(class_2680 state, class_1937 level, class_2338 pos, @Nullable class_2350 direction, @Nullable class_1309 igniter) {}

	/**
	 * Helper method for mods which also handles vanilla
	 */
	static void onCaughtFireVanilla(class_2680 state, class_1937 level, class_2338 pos, @Nullable class_2350 direction, @Nullable class_1309 igniter) {
		if (state.method_26204() instanceof FlammableBlock block) {
			block.onCaughtFire(state, level, pos, direction, igniter);
		} else if (state.method_26204() == class_2246.field_10375) {
			class_2530.method_10738(level, pos);
		}
	}
}
