package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2373;
import net.minecraft.class_2397;
import net.minecraft.class_2680;
import net.minecraft.class_3610;

public interface CustomDisplayFluidOverlayBlock {
	/**
	 * Called to determine whether this block should use the fluid overlay texture or flowing texture when it is placed under the fluid.
	 *
	 * @param state      The current state
	 * @param level      The level
	 * @param pos        Block position in level
	 * @param fluidState The state of the fluid
	 * @return Whether the fluid overlay texture should be used
	 */
	default boolean shouldDisplayFluidOverlay(class_2680 state, class_1920 level, class_2338 pos, class_3610 fluidState) {
		return state.method_26204() instanceof class_2373 || state.method_26204() instanceof class_2397;
	}
}
