package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_2338;
import net.minecraft.class_2399;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_4538;

public interface SupportsClimbableOpenTrapdoorBlock {
	/**
	 * Checks if this block makes an open trapdoor above it climbable.
	 *
	 * @param state         The current state
	 * @param level         The current level
	 * @param pos           Block position in level
	 * @param trapdoorState The current state of the open trapdoor above
	 * @return True if the block should act like a ladder
	 */
	default boolean makesOpenTrapdoorAboveClimbable(class_2680 state, class_4538 level, class_2338 pos, class_2680 trapdoorState) {
		return state.method_26204() instanceof class_2399 && state.method_11654(class_2399.field_11253) == trapdoorState.method_11654(class_2533.field_11177);
	}
}
