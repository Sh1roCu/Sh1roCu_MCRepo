package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import com.llamalad7.mixinextras.sugar.Local;

import com.llamalad7.mixinextras.sugar.ref.LocalIntRef;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.EnchantmentBonusBlock;
import net.minecraft.class_1718;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

@Mixin(class_1718.class)
public abstract class EnchantmentMenuMixin {
	@ModifyExpressionValue(
			method = "method_17411",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/block/EnchantingTableBlock;isValidBookShelf(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)Z"
			)
	)
	private boolean modifyEnchantValue(boolean original, @Local(argsOnly = true) class_1937 level, @Local(argsOnly = true) class_2338 pos, @Local(ordinal = 1) class_2338 offset, @Local(ordinal = 0) LocalIntRef powerRef) {
		class_2680 state = level.method_8320(pos.method_10081(offset));
		if (state.method_26204() instanceof EnchantmentBonusBlock block) {
			powerRef.set(powerRef.get() + block.getEnchantPowerBonus(state, level, pos.method_10081(offset)));
			return false;
		}
		return original;
	}
}
