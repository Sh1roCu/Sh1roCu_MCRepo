package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import net.minecraft.class_2358;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2358.class)
public interface FireBlockAccessor {
	@Invoker
	int callGetIgniteOdds(class_2680 state);

	@Invoker
	int callGetBurnOdds(class_2680 state);
}
