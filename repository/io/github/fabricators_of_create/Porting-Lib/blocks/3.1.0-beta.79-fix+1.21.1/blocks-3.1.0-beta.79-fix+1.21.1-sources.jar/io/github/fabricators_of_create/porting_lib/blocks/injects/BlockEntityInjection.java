package io.github.fabricators_of_create.porting_lib.blocks.injects;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import net.minecraft.class_2487;

public interface BlockEntityInjection {
	/**
	 * Gets a {@link class_2487} that can be used to store custom data for this block entity.
	 * It will be written, and read from disc, so it persists over world saves.
	 *
	 * @return A compound tag for custom persistent data
	 */
	default class_2487 getPortingLibPersistentData() {
		throw PortingLib.createMixinException("BlockEntityInjection.getPortingLibPersistentData()");
	}
}
