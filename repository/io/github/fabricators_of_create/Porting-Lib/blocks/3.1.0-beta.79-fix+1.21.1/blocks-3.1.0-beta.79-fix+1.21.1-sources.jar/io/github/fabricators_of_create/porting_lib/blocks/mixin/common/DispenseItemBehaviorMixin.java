package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.FlammableBlock;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_2530;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

@Mixin(targets = "net/minecraft/core/dispenser/DispenseItemBehavior$8")
public class DispenseItemBehaviorMixin {
	@Definition(id = "TntBlock", type = class_2530.class)
	@Definition(id = "blockState", local = @Local(type = class_2680.class))
	@Definition(id = "getBlock", method = "Lnet/minecraft/world/level/block/state/BlockState;getBlock()Lnet/minecraft/world/level/block/Block;")
	@Expression("blockState.getBlock() instanceof TntBlock")
	@WrapOperation(method = "execute", at = @At("MIXINEXTRAS:EXPRESSION"))
	private boolean checkFlammable(Object object, Operation<Boolean> original, class_2342 source, @Local class_2338 blockPos, @Local class_2680 blockState) {
		if (blockState.method_26204() instanceof FlammableBlock block)
			return block.isFlammable(blockState, source.comp_1967(), blockPos, source.comp_1969().method_11654(class_2315.field_10918).method_10153());
		return original.call(object);
	}

	@WrapOperation(method = "execute", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/TntBlock;explode(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)V"))
	private void onCaughtFire(class_1937 level, class_2338 pos, Operation<Void> original, class_2342 source, @Local class_2680 blockState) {
		if (blockState.method_26204() instanceof FlammableBlock block)
			block.onCaughtFire(blockState, level, pos, source.comp_1969().method_11654(class_2315.field_10918).method_10153(), null);
		else
			original.call(level, pos);
	}
}
