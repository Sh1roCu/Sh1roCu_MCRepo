package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface SlopeCreationCheckingRailBlock {
	/**
	 * Returns true if the rail can make up and down slopes.
	 * Used by placement logic.
	 *
	 * @param level The level.
	 * @param pos   Block's position in level
	 * @return True if the rail can make slopes.
	 */
	default boolean canMakeSlopes(class_2680 state, class_1922 level, class_2338 pos) {
		return true;
	}
}
