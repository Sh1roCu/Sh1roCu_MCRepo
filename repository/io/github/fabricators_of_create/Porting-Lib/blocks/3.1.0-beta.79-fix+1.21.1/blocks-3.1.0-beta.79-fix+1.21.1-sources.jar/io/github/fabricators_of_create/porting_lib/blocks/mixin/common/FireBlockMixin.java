package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomBurnabilityBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.FireSourceBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.FlammableBlock;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2358;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2358.class)
public class FireBlockMixin {
	@WrapOperation(method = "checkBurnOut", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/FireBlock;getBurnOdds(Lnet/minecraft/world/level/block/state/BlockState;)I"))
	private int getBurnOdds(class_2358 instance, class_2680 state, Operation<Integer> original, class_1937 level, class_2338 pos) {
		// TODO: find some way in hell to pass the direction
		if (state.method_26204() instanceof FlammableBlock block) {
			return block.getFlammability(state, level, pos, null);
		}
		return original.call(instance, state);
	}

	@WrapOperation(method = "getIgniteOdds(Lnet/minecraft/world/level/LevelReader;Lnet/minecraft/core/BlockPos;)I", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/FireBlock;getIgniteOdds(Lnet/minecraft/world/level/block/state/BlockState;)I"))
	private int getFireSpreadSpeed(class_2358 instance, class_2680 state, Operation<Integer> original, class_4538 level, class_2338 pos, @Local(ordinal = 0) int chance, @Local class_2350 direction) {
		if (state.method_26204() instanceof FlammableBlock block) {
			return block.getFireSpreadSpeed(state, level, pos.method_10093(direction), direction.method_10153());
		}
		return original.call(instance, state);
	}

	@Inject(
			method = "checkBurnOut",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getBlock()Lnet/minecraft/world/level/block/Block;"),
			cancellable = true
	)
	private void port_lib$onCaughtFire(class_1937 level, class_2338 pos, int spreadFactor, class_5819 random, int currentAge, CallbackInfo ci, @Local class_2680 blockState) {
		if (blockState.method_26204() instanceof FlammableBlock fireBlock) {
			fireBlock.onCaughtFire(blockState, level, pos, null, null);
			ci.cancel();
		}
	}

	@ModifyExpressionValue(method = "canBurn", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/FireBlock;getIgniteOdds(Lnet/minecraft/world/level/block/state/BlockState;)I"))
	private int port_lib$customBurnability(int igniteOdds, class_2680 state) {
		if (state.method_26204() instanceof CustomBurnabilityBlock custom) {
			boolean burnable = custom.canBurn(state);
			// replace igniteOdds. normally, burnable if igniteOdds > 0
			return burnable ? 1 : 0;
		}
		return igniteOdds;
	}

	@ModifyVariable(method = "tick", at = @At("STORE"), index = 6)
	private boolean customFireSource(boolean value, class_2680 otherState, class_3218 world, class_2338 pos, @Local(index = 5) class_2680 state) {
		if (state.method_26204() instanceof FireSourceBlock fireSource)
			return fireSource.isFireSource(state, world, pos, class_2350.field_11036);
		return value;
	}
}
