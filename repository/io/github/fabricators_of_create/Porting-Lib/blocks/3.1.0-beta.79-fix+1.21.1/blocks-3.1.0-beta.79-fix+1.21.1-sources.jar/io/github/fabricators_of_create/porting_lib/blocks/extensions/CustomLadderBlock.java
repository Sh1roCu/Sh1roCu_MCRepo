package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_4538;

public interface CustomLadderBlock {
	/**
	 * Checks if a player or entity can use this block to 'climb' like a ladder.
	 *
	 * @param state  The current state
	 * @param level  The current level
	 * @param pos    Block position in level
	 * @param entity The entity trying to use the ladder, CAN be null.
	 * @return True if the block should act like a ladder
	 */
	default boolean isLadder(class_2680 state, class_4538 level, class_2338 pos, class_1309 entity) {
		return state.method_26164(class_3481.field_22414);
	}
}
