package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2426;
import net.minecraft.class_2457;
import net.minecraft.class_2462;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public interface ConnectableRedstoneBlock {
	/**
	 * Whether redstone dust should visually connect to this block on a given side
	 * <p>
	 * The default implementation is identical to
	 * {@code RedStoneWireBlock#shouldConnectTo(BlockState, Direction)}
	 *
	 * <p>
	 * {@link class_2457} updates its visual connection when
	 * {@link class_2680#method_26191(class_2350, class_2680, class_1936, class_2338, class_2338)}
	 * is called, this callback is used during the evaluation of its new shape.
	 *
	 * @param state     The current state
	 * @param level     The level
	 * @param pos       The block position in level
	 * @param direction The coming direction of the redstone dust connection (with respect to the block at pos)
	 * @return True if redstone dust should visually connect on the side passed
	 * <p>
	 * If the return value is evaluated based on level and pos (e.g. from BlockEntity), then the implementation of
	 * this block should notify its neighbors to update their shapes when necessary. Consider using
	 * {@link class_2680#method_26183(class_1936, class_2338, int, int)} or
	 * {@link class_2680#method_26191(class_2350, class_2680, class_1936, class_2338, class_2338)}.
	 * <p>
	 * Example:
	 * <p>
	 * 1. {@code yourBlockState.updateNeighbourShapes(level, yourBlockPos, UPDATE_ALL);}
	 * <p>
	 * 2. {@code neighborState.updateShape(fromDirection, stateOfYourBlock, level, neighborBlockPos, yourBlockPos)},
	 * where {@code fromDirection} is defined from the neighbor block's point of view.
	 */
	default boolean canConnectRedstone(class_2680 state, class_1922 level, class_2338 pos, @Nullable class_2350 direction) {
		if (state.method_27852(class_2246.field_10091)) {
			return true;
		} else if (state.method_27852(class_2246.field_10450)) {
			class_2350 facing = state.method_11654(class_2462.field_11177);
			return facing == direction || facing.method_10153() == direction;
		} else if (state.method_27852(class_2246.field_10282)) {
			return direction == state.method_11654(class_2426.field_10927);
		} else {
			return state.method_26219() && direction != null;
		}
	}
}
