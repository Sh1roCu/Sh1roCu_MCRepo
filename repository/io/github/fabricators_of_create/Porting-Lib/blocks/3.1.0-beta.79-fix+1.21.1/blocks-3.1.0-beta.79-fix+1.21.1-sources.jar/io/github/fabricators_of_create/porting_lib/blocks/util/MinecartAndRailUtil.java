package io.github.fabricators_of_create.porting_lib.blocks.util;

import javax.annotation.Nullable;
import net.minecraft.class_1688;
import net.minecraft.class_1922;
import net.minecraft.class_2241;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomRailDirectionBlock;
import io.github.fabricators_of_create.porting_lib.blocks.mixin.common.AbstractMinecartAccessor;

public class MinecartAndRailUtil {

	// rails

	public static final class_6862<class_2248> ACTIVATOR_RAILS = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("c", "rails/activator"));

	public static boolean isActivatorRail(class_2248 rail) {
		return rail.method_40142().method_40220(ACTIVATOR_RAILS);
	}

	public static class_2768 getDirectionOfRail(class_2680 state, class_1922 world, class_2338 pos, @Nullable class_1688 minecart) {
		if (state.method_26204() instanceof CustomRailDirectionBlock block) {
			return block.getRailDirection(state, world, pos, minecart);
		}
		return state.method_11654(((class_2241) state.method_26204()).method_9474());
	}

	// carts

	public static double getMaximumSpeed(class_1688 cart) {
		return ((AbstractMinecartAccessor) cart).port_lib$getMaxSpeed();
	}

	public static double getSlopeAdjustment() {
		return 0.0078125D;
	}
}
