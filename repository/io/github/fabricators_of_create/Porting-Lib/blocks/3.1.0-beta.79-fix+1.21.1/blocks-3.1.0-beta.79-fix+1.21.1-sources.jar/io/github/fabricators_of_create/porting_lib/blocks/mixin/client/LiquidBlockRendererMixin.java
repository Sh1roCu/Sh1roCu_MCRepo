package io.github.fabricators_of_create.porting_lib.blocks.mixin.client;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomDisplayFluidOverlayBlock;
import net.minecraft.class_1920;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2373;
import net.minecraft.class_3610;
import net.minecraft.class_775;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;

@Mixin(class_775.class)
public abstract class LiquidBlockRendererMixin {
	@Definition(id = "block", local = @Local(type = class_2248.class))
	@Definition(id = "HalfTransparentBlock", type = class_2373.class)
	@Expression("block instanceof HalfTransparentBlock")
	@ModifyExpressionValue(method = "tesselate", at = @At("MIXINEXTRAS:EXPRESSION"))
	private boolean port_lib$checkShouldDisplayFluidOverlay(boolean original, @Local class_2248 block, @Local(argsOnly = true) class_1920 level, @Local(ordinal = 1) class_2338 pos, @Local(argsOnly = true) class_3610 fluidState) {
		if (block instanceof CustomDisplayFluidOverlayBlock displayFluidOverlayBlock) {
			return displayFluidOverlayBlock.shouldDisplayFluidOverlay(level.method_8320(pos), level, pos, fluidState);
		}

		return original;
	}
}
