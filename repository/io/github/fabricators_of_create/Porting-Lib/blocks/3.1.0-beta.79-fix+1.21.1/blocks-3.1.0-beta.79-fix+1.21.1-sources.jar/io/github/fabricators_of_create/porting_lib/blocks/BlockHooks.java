package io.github.fabricators_of_create.porting_lib.blocks;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class BlockHooks {
	public static boolean doPlayerHarvestCheck(class_1657 player, class_2680 state, class_1922 level, class_2338 pos) {
		return doPlayerHarvestCheck(player, state, level, pos, args -> ((class_1657) args[0]).method_7305((class_2680) args[1]));
	}

	public static boolean doPlayerHarvestCheck(class_1657 player, class_2680 state, class_1922 level, class_2338 pos, Operation<Boolean> original) {
		// Call deprecated hasCorrectToolForDrops overload for a fallback value, in turn the non-deprecated overload calls this method
		boolean vanillaValue = original.call(player, state);
		BlockEvents.HarvestCheck event = new BlockEvents.HarvestCheck(player, state, level, pos, vanillaValue);
		event.sendEvent();
		return event.canHarvest();
	}
}
