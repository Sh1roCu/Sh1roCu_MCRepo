package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.ConnectableRedstoneBlock;
import net.minecraft.class_2350;
import net.minecraft.class_2457;
import net.minecraft.class_2680;

@Mixin(class_2457.class)
public abstract class RedStoneWireBlockMixin {
	@Inject(
			method = "shouldConnectTo(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)Z",
			at = @At("HEAD"),
			cancellable = true
	)
	private static void port_lib$shouldConnectTo(class_2680 state, class_2350 side, CallbackInfoReturnable<Boolean> cir) {
		if (state.method_26204() instanceof ConnectableRedstoneBlock connectable) {
			// Passing null for world and pos here just for extra upstream compat, not properly implementing it because
			// 1. world and pos are never used in Create
			// 2. extra work :help_me:
			cir.setReturnValue(connectable.canConnectRedstone(state, null, null, side));
		}
	}
}
