package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.llamalad7.mixinextras.sugar.Local;

import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.HarvestableBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.PlayerDestroyBlock;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3225.class)
public class ServerPlayerGameModeMixin {
	@Shadow
	protected class_3218 level;

	@Shadow
	@Final
	protected class_3222 player;

	// This code is very cursed but it works:tm:
	@WrapOperation(method = "destroyBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;removeBlock(Lnet/minecraft/core/BlockPos;Z)Z"))
	private boolean onDestroyedBlockCheck(class_3218 instance, class_2338 blockPos, boolean isMoving, Operation<Boolean> original, @Local(ordinal = 1) class_2680 state) {
		if (state.method_26204() instanceof PlayerDestroyBlock)
			return false;
		return original.call(instance, blockPos, isMoving);
	}

	@Inject(method = "destroyBlock", at = @At(value = "RETURN", ordinal = 3))
	private void actuallyRemoveBlock(class_2338 pos, CallbackInfoReturnable<Boolean> cir, @Local(ordinal = 0) class_2680 state) {
		if (state.method_26204() instanceof PlayerDestroyBlock block)
			block.onDestroyedByPlayer(state, this.level, pos, this.player, false, this.level.method_8316(pos));
	}

	@Inject(method = "destroyBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;mineBlock(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V"))
	private void actuallyRemoveBlockElectricBoogaloo(class_2338 pos, CallbackInfoReturnable<Boolean> cir, @Local(ordinal = 0) class_2680 state, @Local(ordinal = 0) LocalBooleanRef removedRef, @Local(ordinal = 1) boolean canHarvest) {
		if (state.method_26204() instanceof PlayerDestroyBlock block)
			removedRef.set(block.onDestroyedByPlayer(state, this.level, pos, this.player, canHarvest, this.level.method_8316(pos)));
	}

	@WrapOperation(method = "destroyBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;hasCorrectToolForDrops(Lnet/minecraft/world/level/block/state/BlockState;)Z"))
	private boolean port_lib$canHarvestBlock(class_3222 player, class_2680 blockstate, Operation<Boolean> operation, class_2338 pos) {
		if (blockstate.method_26204() instanceof HarvestableBlock harvestableBlock)
			return harvestableBlock.canHarvestBlock(blockstate, this.level, pos, player);
		else
			return operation.call(player, blockstate);
	}
}
