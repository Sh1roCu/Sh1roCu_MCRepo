package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_2246;
import net.minecraft.class_2680;

public interface StickToBlock {
	/**
	 * Determines if this block can stick to another block when pushed by a piston.
	 *
	 * @param state My state
	 * @param other Other block
	 * @return True to link blocks
	 */
	default boolean canStickTo(class_2680 state, class_2680 other) {
		if (state.method_26204() == class_2246.field_21211 && other.method_26204() == class_2246.field_10030) return false;
		if (state.method_26204() == class_2246.field_10030 && other.method_26204() == class_2246.field_21211) return false;
		return state.port_lib$isStickyBlock() || other.port_lib$isStickyBlock();
	}
}
