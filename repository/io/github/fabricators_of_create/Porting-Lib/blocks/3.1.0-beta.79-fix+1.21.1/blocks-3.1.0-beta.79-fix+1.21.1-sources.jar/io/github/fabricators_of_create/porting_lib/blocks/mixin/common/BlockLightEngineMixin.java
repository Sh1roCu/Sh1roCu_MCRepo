package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.LightEmissiveBlock;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2823;
import net.minecraft.class_3547;
import net.minecraft.class_3552;
import net.minecraft.class_3558;

@Mixin(class_3552.class)
public abstract class BlockLightEngineMixin extends class_3558<class_3547.class_3548, class_3547> {
	protected BlockLightEngineMixin(class_2823 chunkProvider, class_3547 lightStorage) {
		super(chunkProvider, lightStorage);
	}

	@WrapOperation(method = "getEmission", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getLightEmission()I"))
	private int getCustomLightEmission(class_2680 state, Operation<Integer> operation, long blockPos, class_2680 blockState) {
		if (state.method_26204() instanceof LightEmissiveBlock lightEmissiveBlock)
			return lightEmissiveBlock.getLightEmission(state, this.field_15795.method_16399(), class_2338.method_10092(blockPos));
		return operation.call(state);
	}
}
