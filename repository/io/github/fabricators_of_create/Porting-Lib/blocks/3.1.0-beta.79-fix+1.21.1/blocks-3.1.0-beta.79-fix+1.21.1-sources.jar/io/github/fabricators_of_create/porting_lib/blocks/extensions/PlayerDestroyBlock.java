package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3610;

public interface PlayerDestroyBlock {
	/**
	 * Called when a player removes a block. This is responsible for
	 * actually destroying the block, and the block is intact at time of call.
	 * This is called regardless of whether the player can harvest the block or
	 * not.
	 *
	 * Return true if the block is actually destroyed.
	 *
	 * This function is called on both the logical client and logical server.
	 *
	 * @param state       The current state.
	 * @param level       The current level
	 * @param player      The player damaging the block, may be null
	 * @param pos         Block position in level
	 * @param willHarvest The result of {@link HarvestableBlock#canHarvestBlock}, if called on the server by a non-creative player, otherwise always false.
	 * @param fluid       The current fluid state at current position
	 * @return True if the block is actually destroyed.
	 */
	default boolean onDestroyedByPlayer(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, boolean willHarvest, class_3610 fluid) {
		if (level.method_8608()) {
			// On the client, vanilla calls Level#setBlock, per MultiPlayerGameMode#destroyBlock
			return level.method_8652(pos, fluid.method_15759(), 11);
		} else {
			// On the server, vanilla calls Level#removeBlock, per ServerPlayerGameMode#destroyBlock
			return level.method_8650(pos, false);
		}
	}
}
