package io.github.fabricators_of_create.porting_lib.blocks.mixin.client;

import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomDataPacketHandlingBlockEntity;
import net.minecraft.class_2535;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_634;
import net.minecraft.class_8673;
import net.minecraft.class_8675;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class ClientPacketListenerMixin extends class_8673 {

	@Final
	@Shadow
	private class_5455.class_6890 registryAccess;

	protected ClientPacketListenerMixin(class_310 minecraft, class_2535 connection, class_8675 commonListenerCookie) {
		super(minecraft, connection, commonListenerCookie);
	}

	@Inject(method = "method_38542", at = @At("HEAD"), cancellable = true)
	public void andleCustomBlockEntity(class_2622 packet, class_2586 blockEntity, CallbackInfo ci, @Share("data_packet") LocalBooleanRef handleRef) {
		if (blockEntity instanceof CustomDataPacketHandlingBlockEntity handler) {
			handler.onDataPacket(field_45589, packet, this.registryAccess);
			handleRef.set(true);
		} else
			handleRef.set(false);
	}
}
