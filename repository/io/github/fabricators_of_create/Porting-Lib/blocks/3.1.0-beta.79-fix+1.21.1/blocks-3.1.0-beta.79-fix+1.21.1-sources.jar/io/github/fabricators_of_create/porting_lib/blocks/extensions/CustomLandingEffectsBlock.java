package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public interface CustomLandingEffectsBlock {
	/**
	 * @return true to prevent vanilla particles spawning
	 */
	boolean addLandingEffects(class_2680 state1, class_3218 level, class_2338 pos, class_2680 state2, class_1309 entity, int numberOfParticles);
}
