package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_2487;
import net.minecraft.class_2535;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_7225;

public interface CustomDataPacketHandlingBlockEntity {
	/**
	 * Called when you receive a {@link class_2622} packet for the location this
	 * BlockEntity is currently in. On the client, the Connection will always
	 * be the remote server. On the server, it will be whomever is responsible for
	 * sending the packet.
	 *
	 * @param net The Connection the packet originated from
	 * @param pkt The data packet
	 */
	default void onDataPacket(class_2535 net, class_2622 pkt, class_7225.class_7874 lookupProvider) {
		class_2487 compoundtag = pkt.method_11290();
		if (!compoundtag.method_33133()) {
			((class_2586) this).method_58690(compoundtag, lookupProvider);
		}
	}
}
