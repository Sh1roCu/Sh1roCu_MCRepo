package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.VanillaCustomExpBlock;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2431;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_6017;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_2431.class)
public abstract class DropExperienceBlockMixin implements VanillaCustomExpBlock {
	@Shadow
	@Final
	private class_6017 xpRange;

	// Port Lib: Patch-in override for getExpDrop.
	@Override
	public int port_lib$getExpDrop(class_2680 state, class_1936 level, class_2338 pos,
								   @Nullable class_2586 blockEntity,
								   @Nullable class_1297 breaker, class_1799 tool) {
		return this.xpRange.method_35008(level.method_8409());
	}
}
