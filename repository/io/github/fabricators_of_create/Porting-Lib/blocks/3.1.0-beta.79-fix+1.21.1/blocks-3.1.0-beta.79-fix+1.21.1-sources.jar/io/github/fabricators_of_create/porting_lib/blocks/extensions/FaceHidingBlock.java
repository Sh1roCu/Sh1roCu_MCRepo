package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import io.github.fabricators_of_create.porting_lib.blocks.ClientBlockHooks;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

public interface FaceHidingBlock {
	/**
	 * Whether this block allows a neighboring block to hide the face of this block it touches.
	 * If this returns true, {@link io.github.fabricators_of_create.porting_lib.blocks.injects.BlockStateInjection#port_lib$hidesNeighborFace(class_1922, class_2338, class_2680, class_2350)}
	 * will be called on the neighboring block.
	 */
	default boolean supportsExternalFaceHiding(class_2680 state) {
		if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
			return ClientBlockHooks.isBlockInSolidLayer(state);
		}
		return true;
	}

	/**
	 * Whether this block hides the neighbors face pointed towards by the given direction.
	 * <p>
	 * This method should only be used for blocks you don't control, for your own blocks override
	 * {@link class_2248#method_9522(class_2680, class_2680, class_2350)} on the respective block instead
	 * <p>
	 * WARNING: This method is likely to be called from a worker thread! If you want to retrieve a
	 *          {@link net.minecraft.class_2586} from the given level, make sure to use
	 *          {@link net.minecraftforge.common.extensions.IForgeBlockGetter#getExistingBlockEntity(BlockPos)} to not
	 *          accidentally create a new or delete an old {@link net.minecraft.class_2586}
	 *          off of the main thread as this would cause a write operation to the given {@link class_1922} and cause
	 *          a CME in the process. Any other direct or indirect write operation to the {@link class_1922} will have
	 *          the same outcome.
	 *
	 * @param level The world
	 * @param pos The blocks position in the world
	 * @param state The blocks {@link class_2680}
	 * @param neighborState The neighboring blocks {@link class_2680}
	 * @param dir The direction towards the neighboring block
	 */
	default boolean hidesNeighborFace(class_1922 level, class_2338 pos, class_2680 state, class_2680 neighborState, class_2350 dir) {
		return false;
	}
}
