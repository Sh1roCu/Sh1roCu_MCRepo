package io.github.fabricators_of_create.porting_lib.blocks.mixin.compat.sodium;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomDisplayFluidOverlayBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.LightEmissiveBlock;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import org.spongepowered.asm.mixin.Dynamic;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(targets = "net.caffeinemc.mods.sodium.fabric.block.FabricBlockAccess")
public abstract class FabricBlockAccessMixin {
	@Dynamic
	@Inject(method = "getLightEmission", at = @At("HEAD"), cancellable = true)
	private void port_lib$usePortingLibLightEmission(class_2680 state, class_1920 level, class_2338 pos, CallbackInfoReturnable<Integer> cir) {
		if (state.method_26204() instanceof LightEmissiveBlock lightEmissiveBlock) {
			cir.setReturnValue(lightEmissiveBlock.getLightEmission(state, level, pos));
		}
	}

	@Dynamic
	@Inject(method = "shouldShowFluidOverlay", at = @At("HEAD"), cancellable = true)
	private void port_lib$usePortingLibFluidOverlay(class_2680 state, class_1920 level, class_2338 pos, class_3610 fluidState, CallbackInfoReturnable<Boolean> cir) {
		if (state.method_26204() instanceof CustomDisplayFluidOverlayBlock fluidOverlayBlock) {
			cir.setReturnValue(fluidOverlayBlock.shouldDisplayFluidOverlay(state, level, pos, fluidState));
		}
	}
}
