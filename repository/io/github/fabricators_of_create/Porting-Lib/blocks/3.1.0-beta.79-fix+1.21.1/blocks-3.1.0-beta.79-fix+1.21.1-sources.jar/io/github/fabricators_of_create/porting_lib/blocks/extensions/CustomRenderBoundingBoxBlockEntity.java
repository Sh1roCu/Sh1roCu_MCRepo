package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2586;
import net.minecraft.class_265;

public interface CustomRenderBoundingBoxBlockEntity {
	class_238 INFINITE_EXTENT_AABB = new class_238(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);

	default class_2586 self() {
		return (class_2586) this;
	}

	default class_238 getRenderBoundingBox() {
		class_238 box = getInfiniteBoundingBox();
		class_2338 pos = self().method_11016();
		try {
			class_265 collisionShape = self().method_11010().method_26220(self().method_10997(), pos);
			if (!collisionShape.method_1110()) {
				box = collisionShape.method_1107().method_996(pos);
			}
		} catch (Exception e) {
			box = class_238.method_54784(pos.method_10069(-1, 0, -1), pos.method_10069(1, 1, 1));
		}

		return box;
	}

	default class_238 getInfiniteBoundingBox() {
		return INFINITE_EXTENT_AABB;
	}
}
