package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.EntityDestroyBlock;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1528;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1528.class)
public abstract class WitherBossMixin extends class_1297 {

	public WitherBossMixin(class_1299<?> entityType, class_1937 level) {
		super(entityType, level);
	}
	@Unique
	private boolean customLogic = false;
	@Unique
	private boolean shouldBreak = false;

	@ModifyExpressionValue(method = "customServerAiStep", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/boss/wither/WitherBoss;canDestroy(Lnet/minecraft/world/level/block/state/BlockState;)Z"))
	public boolean port_lib$canDestroy(boolean original) {
		if (customLogic)
			return shouldBreak;
		return original;
	}

	@Inject(method = "customServerAiStep", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;", shift = At.Shift.AFTER))
	public void port_lib$shouldDestroy(CallbackInfo ci, @Local(index = 5) class_2338 blockPos) {
		class_2680 blockState = this.method_37908().method_8320(blockPos);
		if (blockState.method_26204() instanceof EntityDestroyBlock destroyBlock) {
			customLogic = true;
			shouldBreak = destroyBlock.canEntityDestroy(blockState, this.method_37908(), blockPos, this);
		} else
			customLogic = false;
	}
}
