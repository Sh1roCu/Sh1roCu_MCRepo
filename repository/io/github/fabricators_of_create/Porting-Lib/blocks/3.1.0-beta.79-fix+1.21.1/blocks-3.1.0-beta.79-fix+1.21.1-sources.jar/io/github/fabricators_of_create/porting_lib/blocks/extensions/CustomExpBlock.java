package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_9701;
import org.jetbrains.annotations.Nullable;

public interface CustomExpBlock {
	/**
	 * Returns how many experience points this block drops when broken, before application of {@linkplain class_9701#field_51681 enchantments}.
	 *
	 * @param state       The state of the block being broken
	 * @param level       The level
	 * @param pos         The position of the block being broken
	 * @param blockEntity The block entity, if any
	 * @param breaker     The entity who broke the block, if known
	 * @param tool        The item stack used to break the block. May be empty
	 * @return The amount of experience points dropped by this block
	 */
	default int getExpDrop(class_2680 state, class_1936 level, class_2338 pos, @Nullable class_2586 blockEntity, @Nullable class_1297 breaker, class_1799 tool) {
		return 0;
	}
}
