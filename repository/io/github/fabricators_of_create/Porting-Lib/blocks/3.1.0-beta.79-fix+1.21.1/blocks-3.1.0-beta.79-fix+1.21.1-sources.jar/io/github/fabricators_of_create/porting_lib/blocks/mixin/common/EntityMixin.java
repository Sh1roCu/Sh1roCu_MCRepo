package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.CollisionExtendsVerticallyBlock;
import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomRunningEffectsBlock;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1297.class)
public abstract class EntityMixin {
	// RUNNING EFFECTS

	@Shadow
	public abstract class_1937 level();

	@Definition(id = "blockState", local = @Local(type = class_2680.class))
	@Definition(id = "getRenderShape", method = "Lnet/minecraft/world/level/block/state/BlockState;getRenderShape()Lnet/minecraft/world/level/block/RenderShape;")
	@Definition(id = "INVISIBLE", field = "Lnet/minecraft/world/level/block/RenderShape;INVISIBLE:Lnet/minecraft/world/level/block/RenderShape;")
	@Expression("blockState.getRenderShape() != INVISIBLE")
	@ModifyExpressionValue(method = "spawnSprintParticle", at = @At("MIXINEXTRAS:EXPRESSION"))
	public boolean port_lib$spawnSprintParticle(boolean original, @Local class_2338 pos, @Local class_2680 state) {
		//noinspection ConstantValue
		return original && !(state.method_26204() instanceof CustomRunningEffectsBlock custom &&
				custom.addRunningEffects(state, this.level(), pos, (class_1297) (Object) this));
	}

	@WrapOperation(method = "getOnPos(F)Lnet/minecraft/core/BlockPos;", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/tags/TagKey;)Z", ordinal = 0))
	private boolean port_lib$tryCheckCollisionsExtendVertically(class_2680 instance, class_6862 tagKey, Operation<Boolean> original, @Local class_2338 pos) {
		if (instance.method_26204() instanceof CollisionExtendsVerticallyBlock collisionExtendsVerticallyBlock) {
			return collisionExtendsVerticallyBlock.collisionExtendsVertically(instance, this.level(), pos, (class_1297) (Object) this);
		}

		return original.call(instance, tagKey);
	}
}
