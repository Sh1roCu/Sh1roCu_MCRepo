package io.github.fabricators_of_create.porting_lib.blocks.mixin.common;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.VanillaCustomExpBlock;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2449;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_6019;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2449.class)
public abstract class RedStoneOreBlockMixin implements VanillaCustomExpBlock {
	// Port Lib: Patch-in override for getExpDrop.
	@Override
	public int port_lib$getExpDrop(class_2680 state, class_1936 level, class_2338 pos,
								   @Nullable class_2586 blockEntity,
								   @Nullable class_1297 breaker, class_1799 tool) {
		return class_6019.method_35017(1, 5).method_35008(level.method_8409());
	}
}
