package io.github.fabricators_of_create.porting_lib.blocks;

import net.minecraft.class_1921;
import net.minecraft.class_2680;
import net.minecraft.class_4696;

public class ClientBlockHooks {
	public static boolean isBlockInSolidLayer(class_2680 state) {
		return class_4696.method_23679(state) != class_1921.method_23577();
	}
}
