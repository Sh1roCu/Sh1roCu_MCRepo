package io.github.fabricators_of_create.porting_lib.blocks.extensions;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4538;

public interface CustomFrictionBlock {
	float getFriction(class_2680 state, class_4538 world, class_2338 pos, class_1297 entity);
}
