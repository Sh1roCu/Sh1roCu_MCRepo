package io.github.fabricators_of_create.porting_lib.resources.injections;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ICondition;
import net.minecraft.class_7225;

public interface ReloadableServerResourcesInjection {
	default ICondition.IContext port_lib$getConditionContext() {
		throw PortingLib.createMixinException("ReloadableServerResourcesInjection.port_lib$getConditionContext()");
	}

	default class_7225.class_7874 port_lib$getRegistryLookup() {
		throw PortingLib.createMixinException("ReloadableServerResourcesInjection.port_lib$getRegistryLookup");
	}
}
