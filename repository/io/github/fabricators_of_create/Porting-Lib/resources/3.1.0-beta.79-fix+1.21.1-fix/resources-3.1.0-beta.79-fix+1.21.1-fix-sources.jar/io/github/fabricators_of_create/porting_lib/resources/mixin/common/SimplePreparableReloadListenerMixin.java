package io.github.fabricators_of_create.porting_lib.resources.mixin.common;

import io.github.fabricators_of_create.porting_lib.resources.conditions.ICondition;
import io.github.fabricators_of_create.porting_lib.resources.extensions.ContextAwareReloadListenerExtension;
import net.minecraft.class_4080;
import net.minecraft.class_7225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_4080.class)
public abstract class SimplePreparableReloadListenerMixin implements ContextAwareReloadListenerExtension {
	@Unique private ICondition.IContext port_lib$context;
	@Unique private class_7225.class_7874 port_lib$registryLookup;

	@Override
	public void injectContext(ICondition.IContext context, class_7225.class_7874 registryLookup) {
		this.port_lib$context = context;
		this.port_lib$registryLookup = registryLookup;
	}

	@Override
	public ICondition.IContext port_lib$getContext() {
		return this.port_lib$context;
	}

	@Override
	public class_7225.class_7874 getRegistryLookup() {
		return this.port_lib$registryLookup;
	}
}
