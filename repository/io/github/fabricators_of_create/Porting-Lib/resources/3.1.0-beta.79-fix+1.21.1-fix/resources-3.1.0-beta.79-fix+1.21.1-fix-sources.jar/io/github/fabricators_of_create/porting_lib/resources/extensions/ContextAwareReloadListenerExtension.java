package io.github.fabricators_of_create.porting_lib.resources.extensions;

import io.github.fabricators_of_create.porting_lib.resources.conditions.ICondition;
import net.minecraft.class_5455;
import net.minecraft.class_7225;
import org.jetbrains.annotations.ApiStatus;

public interface ContextAwareReloadListenerExtension {
	@ApiStatus.Internal
	void injectContext(ICondition.IContext context, class_7225.class_7874 registryLookup);

	/**
	 * Returns the condition context held by this listener, or {@link ICondition.IContext#EMPTY} if it is unavailable.
	 */
	ICondition.IContext port_lib$getContext();

	/**
	 * Returns the registry access held by this listener, or {@link class_5455#field_40585} if it is unavailable.
	 */
	class_7225.class_7874 getRegistryLookup();
}
