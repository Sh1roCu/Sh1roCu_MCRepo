package io.github.fabricators_of_create.porting_lib.resources.conditions;

import com.google.gson.JsonElement;

import com.mojang.serialization.JsonOps;

import io.github.fabricators_of_create.porting_lib.resources.extensions.ContextAwareReloadListenerExtension;
import net.minecraft.class_3302;
import net.minecraft.class_4080;
import net.minecraft.class_5455;
import net.minecraft.class_7225;
import org.jetbrains.annotations.ApiStatus;

/**
 * Reload listeners that descend from this class will have the reload context automatically populated when it is available.
 * <p>
 * The context is guaranteed to be available for the duration of {@link class_3302#method_25931}.
 * <p>
 * For children of {@link class_4080}, it will be available during both {@link class_4080#method_18789} prepare()} and {@link class_4080#method_18788 apply()}.
 */
public abstract class ContextAwareReloadListener implements class_3302, ContextAwareReloadListenerExtension {
	private ICondition.IContext conditionContext = ICondition.IContext.EMPTY;

	private class_7225.class_7874 registryLookup = class_5455.field_40585;

	@ApiStatus.Internal
	public void injectContext(ICondition.IContext context, class_7225.class_7874 registryLookup) {
		this.conditionContext = context;
		this.registryLookup = registryLookup;
	}

	/**
	 * Returns the condition context held by this listener, or {@link ICondition.IContext#EMPTY} if it is unavailable.
	 */
	public final ICondition.IContext port_lib$getContext() {
		return this.conditionContext;
	}

	/**
	 * Returns the registry access held by this listener, or {@link class_5455#field_40585} if it is unavailable.
	 */
	public final class_7225.class_7874 getRegistryLookup() {
		return this.registryLookup;
	}

	/**
	 * Creates a new {@link ConditionalOps} using {@link #port_lib$getContext()} and {@link #getRegistryLookup()} ()}.
	 */
	protected final ConditionalOps<JsonElement> makeConditionalOps() {
		return new ConditionalOps<>(getRegistryLookup().method_57093(JsonOps.INSTANCE), port_lib$getContext());
	}
}
