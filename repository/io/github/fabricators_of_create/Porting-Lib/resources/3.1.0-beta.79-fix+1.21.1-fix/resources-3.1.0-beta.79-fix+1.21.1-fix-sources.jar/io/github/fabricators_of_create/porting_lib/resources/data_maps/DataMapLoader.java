package io.github.fabricators_of_create.porting_lib.resources.data_maps;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.datafixers.util.Either;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ConditionalOps;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ICondition;
import io.github.fabricators_of_create.porting_lib.resources.data_maps.DataMapEntry.Removal;
import io.github.fabricators_of_create.porting_lib.resources.events.DataMapsUpdatedEvent;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6903;
import net.minecraft.class_7654;
import org.slf4j.Logger;

import java.io.Reader;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

public class DataMapLoader implements IdentifiableResourceReloadListener {
	public static final class_2960 ID = PortingLib.id("data_maps");

	@Override
	public class_2960 getFabricId() {
		return ID;
	}

	private static final Logger LOGGER = LogUtils.getLogger();
	public static final String PATH = "data_maps";
	private Map<class_5321<? extends class_2378<?>>, LoadResult<?>> results;
	private final ICondition.IContext conditionContext;
	private final class_5455 registryAccess;

	public DataMapLoader(ICondition.IContext conditionContext, class_5455 registryAccess) {
		this.conditionContext = conditionContext;
		this.registryAccess = registryAccess;
	}

	@Override
	public CompletableFuture<Void> method_25931(class_4045 preparationBarrier, class_3300 resourceManager, class_3695 preparationsProfiler, class_3695 reloadProfiler, Executor backgroundExecutor, Executor gameExecutor) {
		return this.load(resourceManager, backgroundExecutor, preparationsProfiler)
				.thenCompose(preparationBarrier::method_18352)
				.thenAcceptAsync(values -> this.results = values, gameExecutor);
	}

	public void apply() {
		results.forEach((key, result) -> this.apply((class_2378) registryAccess.method_30530(key), result));

		// Clear the intermediary maps and objects
		results = null;
	}

	private <T> void apply(class_2378<T> registry, LoadResult<T> result) {
		registry.port_lib$getDataMaps().clear();
		result.results().forEach((key, entries) -> registry.port_lib$getDataMaps().put(
				key, this.buildDataMap(registry, key, (List) entries)));

		(new DataMapsUpdatedEvent(registryAccess, registry, DataMapsUpdatedEvent.UpdateCause.SERVER_RELOAD)).sendEvent();
	}

	private <T, R> Map<class_5321<R>, T> buildDataMap(class_2378<R> registry, DataMapType<R, T> attachment, List<DataMapFile<T, R>> entries) {
		record WithSource<T, R>(T attachment, Either<class_6862<R>, class_5321<R>> source) {}
		final Map<class_5321<R>, WithSource<T, R>> result = new IdentityHashMap<>();
		final DataMapValueMerger<R, T> merger = attachment instanceof AdvancedDataMapType<R, T, ?> adv ? adv.merger() : DataMapValueMerger.defaultMerger();
		entries.forEach(entry -> {
			if (entry.replace()) {
				result.clear();
			}

			entry.values().forEach((tKey, value) -> {
				if (value.isEmpty()) return;

				resolve(registry, tKey, true, holder -> {
					final var newValue = value.get().carrier();
					final var key = holder.method_40230().orElseThrow();
					final var oldValue = result.get(key);
					if (oldValue == null || newValue.replace()) {
						result.put(key, new WithSource<>(newValue.value(), tKey));
					} else {
						result.put(key, new WithSource<>(merger.merge(registry, oldValue.source(), oldValue.attachment(), tKey, newValue.value()), tKey));
					}
				});
			});

			for (var removal : entry.removals()) {
				if (removal.remover().isPresent()) {
					var remover = removal.remover().orElseThrow();
					resolve(registry, removal.key(), false, holder -> {
						final var key = holder.method_40230().orElseThrow();
						final var oldValue = result.get(key);
						if (oldValue != null) {
							final var newValue = remover.remove(oldValue.attachment(), registry, oldValue.source(), holder.comp_349());
							if (newValue.isEmpty()) {
								result.remove(key);
							} else {
								result.put(key, new WithSource<>(newValue.get(), oldValue.source()));
							}
						}
					});
				} else {
					resolve(registry, removal.key(), false, holder -> result.remove(holder.method_40230().orElseThrow()));
				}
			}
		});
		final Map<class_5321<R>, T> newMap = new IdentityHashMap<>();
		result.forEach((key, val) -> newMap.put(key, val.attachment()));

		return newMap;
	}

	private <R> void resolve(class_2378<R> registry, Either<class_6862<R>, class_5321<R>> value, boolean required, Consumer<class_6880<R>> consumer) {
		if (value.left().isPresent()) {
			registry.method_40286(value.left().orElseThrow()).forEach(consumer);
		} else {
			var object = registry.method_40264(value.right().orElseThrow());
			if (object.isPresent()) {
				consumer.accept(object.get());
			} else if (required) {
				LOGGER.error("Object with ID {} specified in data map for registry {} doesn't exist", value.right().orElseThrow().method_29177(), registry.method_30517().method_29177());
			}
		}
	}

	private CompletableFuture<Map<class_5321<? extends class_2378<?>>, LoadResult<?>>> load(class_3300 manager, Executor executor, class_3695 profiler) {
		return CompletableFuture.supplyAsync(() -> load(manager, profiler, registryAccess, conditionContext), executor);
	}

	private static Map<class_5321<? extends class_2378<?>>, LoadResult<?>> load(class_3300 manager, class_3695 profiler, class_5455 access, ICondition.IContext context) {
		final class_6903<JsonElement> ops = new ConditionalOps<>(class_6903.method_46632(JsonOps.INSTANCE, access), context);

		final Map<class_5321<? extends class_2378<?>>, LoadResult<?>> values = new HashMap<>();
		access.method_40311().forEach(registryEntry -> {
			final var registryKey = registryEntry.comp_350();
			profiler.method_15396("registry_data_maps/" + registryKey.method_29177() + "/locating");
			final var fileToId = class_7654.method_45114(PATH + "/" + getFolderLocation(registryKey.method_29177()));
			for (Map.Entry<class_2960, List<class_3298>> entry : fileToId.method_45116(manager).entrySet()) {
				class_2960 key = entry.getKey();
				final class_2960 attachmentId = fileToId.method_45115(key);
				final var attachment = PortingLibDataMaps.getDataMap((class_5321) registryKey, attachmentId);
				if (attachment == null) {
					LOGGER.warn("Found data map file for non-existent data map type '{}' on registry '{}'.", attachmentId, registryKey.method_29177());
					continue;
				}
				profiler.method_15405("registry_data_maps/" + registryKey.method_29177() + "/" + attachmentId + "/loading");
				values.computeIfAbsent(registryKey, k -> new LoadResult<>(new HashMap<>())).results.put(attachment, readData(
						ops, attachment, (class_5321) registryKey, entry.getValue()));
			}
			profiler.method_15407();
		});

		return values;
	}

	public static String getFolderLocation(class_2960 registryId) {
		return (registryId.method_12836().equals(class_2960.field_33381) ? "" : registryId.method_12836() + "/") + registryId.method_12832();
	}

	private static <A, T> List<DataMapFile<A, T>> readData(class_6903<JsonElement> ops, DataMapType<T, A> attachmentType, class_5321<class_2378<T>> registryKey, List<class_3298> resources) {
		final var codec = DataMapFile.codec(registryKey, attachmentType);
		final List<DataMapFile<A, T>> entries = new LinkedList<>();
		for (final class_3298 resource : resources) {
			try (Reader reader = resource.method_43039()) {
				JsonElement jsonelement = JsonParser.parseReader(reader);
				entries.add(codec.decode(ops, jsonelement).getOrThrow().getFirst());
			} catch (Exception exception) {
				LOGGER.error("Could not read data map of type {} for registry {}", attachmentType.id(), registryKey, exception);
			}
		}
		return entries;
	}

	private record LoadResult<T>(Map<DataMapType<T, ?>, List<DataMapFile<?, T>>> results) {}
}
