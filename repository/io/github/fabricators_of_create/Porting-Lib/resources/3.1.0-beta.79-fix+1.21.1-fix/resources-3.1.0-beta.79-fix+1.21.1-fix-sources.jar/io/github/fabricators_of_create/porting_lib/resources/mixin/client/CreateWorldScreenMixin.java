package io.github.fabricators_of_create.porting_lib.resources.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;

import com.mojang.datafixers.util.Pair;

import io.github.fabricators_of_create.porting_lib.resources.events.AddPackFindersEvent;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.nio.file.Path;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_437;
import net.minecraft.class_525;
import net.minecraft.class_7712;

@Mixin(class_525.class)
public abstract class CreateWorldScreenMixin {
	@Shadow
	@Nullable
	private class_3283 tempDataPackRepository;

	@Inject(method = "openFresh", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/worldselection/CreateWorldScreen;createDefaultLoadConfig(Lnet/minecraft/server/packs/repository/PackRepository;Lnet/minecraft/world/level/WorldDataConfiguration;)Lnet/minecraft/server/WorldLoader$InitConfig;"))
	private static void addPacks(class_310 minecraft, class_437 screen, CallbackInfo ci, @Local(index = 2) class_3283 repository) {
		new AddPackFindersEvent(class_3264.field_14190, repository::port_lib$addPackFinder, false).sendEvent();
	}

	@Inject(method = "getDataPackSelectionSettings", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/packs/repository/PackRepository;reload()V"))
	private void addPacks2(class_7712 worldDataConfiguration, CallbackInfoReturnable<Pair<Path, class_3283>> cir) {
		new AddPackFindersEvent(class_3264.field_14190, this.tempDataPackRepository::port_lib$addPackFinder, false).sendEvent();
	}
}
