package io.github.fabricators_of_create.porting_lib.resources.mixin.common;

import io.github.fabricators_of_create.porting_lib.resources.data_maps.DataMapType;
import io.github.fabricators_of_create.porting_lib.resources.injections.RegistryLookupInjection;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_7225.class_7226.class)
public interface HolderLookupRegistryLookupMixin<T> extends RegistryLookupInjection<T> {

	@Mixin(class_7225.class_7226.class_7875.class)
	public interface DelegateMixin<T> extends RegistryLookupInjection<T> {
		@Shadow
		class_7225.class_7226<T> parent();

		@Override
		@Nullable
		default <A> A getData(DataMapType<T, A> attachment, class_5321<T> key) {
			return parent().getData(attachment, key);
		}
	}
}
