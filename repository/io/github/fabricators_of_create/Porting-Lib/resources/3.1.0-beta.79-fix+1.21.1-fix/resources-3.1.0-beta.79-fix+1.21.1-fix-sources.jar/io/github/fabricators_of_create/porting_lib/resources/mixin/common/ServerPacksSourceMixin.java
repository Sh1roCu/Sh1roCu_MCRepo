package io.github.fabricators_of_create.porting_lib.resources.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import io.github.fabricators_of_create.porting_lib.resources.events.AddPackFindersEvent;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_3286;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_3286.class)
public abstract class ServerPacksSourceMixin {
	@ModifyReturnValue(method = "createPackRepository(Ljava/nio/file/Path;Lnet/minecraft/world/level/validation/DirectoryValidator;)Lnet/minecraft/server/packs/repository/PackRepository;", at = @At("RETURN"))
	private static class_3283 firePackFinders(class_3283 original) {
		new AddPackFindersEvent(class_3264.field_14190, original::port_lib$addPackFinder, false).sendEvent();
		return original;
	}

	@ModifyReturnValue(method = "createVanillaTrustedRepository", at = @At("RETURN"))
	private static class_3283 firePackFinders2(class_3283 original) {
		new AddPackFindersEvent(class_3264.field_14190, original::port_lib$addPackFinder, true).sendEvent();
		return original;
	}
}
