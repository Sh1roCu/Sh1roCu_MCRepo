package io.github.fabricators_of_create.porting_lib.resources.mixin.common;

import io.github.fabricators_of_create.porting_lib.resources.data_maps.DataMapType;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7876;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_6880.class_6883.class)
public abstract class HolderReferenceMixin<T> implements class_6880<T> {
	@Shadow
	@Final
	private class_7876<T> owner;

	@Shadow
	public abstract class_5321<T> key();

	@Nullable
	public <A> A getData(DataMapType<T, A> type) {
		if (owner instanceof class_7225.class_7226<T> lookup) {
			return lookup.getData(type, key());
		}
		return null;
	}
}
