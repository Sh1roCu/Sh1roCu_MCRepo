package io.github.fabricators_of_create.porting_lib.resources.conditions;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ItemExistsCondition implements ICondition {
	public static MapCodec<ItemExistsCondition> CODEC = RecordCodecBuilder.mapCodec(
			builder -> builder
					.group(
							class_2960.field_25139.fieldOf("item").forGetter(ItemExistsCondition::getItem))
					.apply(builder, ItemExistsCondition::new));

	private final class_2960 item;

	public ItemExistsCondition(String location) {
		this(class_2960.method_60654(location));
	}

	public ItemExistsCondition(String namespace, String path) {
		this(class_2960.method_60655(namespace, path));
	}

	public ItemExistsCondition(class_2960 item) {
		this.item = item;
	}

	@Override
	public boolean test(IContext context) {
		return class_7923.field_41178.method_10250(item);
	}

	@Override
	public MapCodec<? extends ICondition> codec() {
		return CODEC;
	}

	public class_2960 getItem() {
		return item;
	}

	@Override
	public String toString() {
		return "item_exists(\"" + item + "\")";
	}
}
