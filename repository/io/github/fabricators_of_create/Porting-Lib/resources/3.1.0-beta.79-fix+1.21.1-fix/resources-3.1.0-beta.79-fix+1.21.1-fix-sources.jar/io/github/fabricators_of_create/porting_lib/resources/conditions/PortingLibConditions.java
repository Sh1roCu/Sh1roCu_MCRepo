package io.github.fabricators_of_create.porting_lib.resources.conditions;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.minecraft.class_161;
import net.minecraft.class_1860;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import java.util.Optional;

public class PortingLibConditions {
	public static final class_5321<class_2378<MapCodec<? extends ICondition>>> CONDITION_CODECS_KEY =  class_5321.method_29180(PortingLib.id("condition_codecs"));
	public static final class_2378<MapCodec<? extends ICondition>> CONDITION_SERIALIZERS = FabricRegistryBuilder.createSimple(CONDITION_CODECS_KEY).buildAndRegister();

	public static final Codec<Optional<WithConditions<class_161>>> CONDITIONAL_ADVANCEMENTS_CODEC = ConditionalOps.createConditionalCodecWithConditions(class_161.field_47179);
	public static final Codec<Optional<WithConditions<class_1860<?>>>> CONDITIONAL_RECIPES_CODEC = ConditionalOps.createConditionalCodecWithConditions(class_1860.field_47319);

	public static final MapCodec<AndCondition> AND_CONDITION = class_2378.method_10230(CONDITION_SERIALIZERS, PortingLib.neo("and"), AndCondition.CODEC);
	public static final MapCodec<FalseCondition> FALSE_CONDITION = class_2378.method_10230(CONDITION_SERIALIZERS, PortingLib.neo("false"), FalseCondition.CODEC);
	public static final MapCodec<ItemExistsCondition> ITEM_EXISTS_CONDITION = class_2378.method_10230(CONDITION_SERIALIZERS, PortingLib.neo("item_exists"), ItemExistsCondition.CODEC);
	public static final MapCodec<ModLoadedCondition> MOD_LOADED_CONDITION = class_2378.method_10230(CONDITION_SERIALIZERS, PortingLib.neo("mod_loaded"), ModLoadedCondition.CODEC);
	public static final MapCodec<NotCondition> NOT_CONDITION = class_2378.method_10230(CONDITION_SERIALIZERS, PortingLib.neo("not"), NotCondition.CODEC);
	public static final MapCodec<OrCondition> OR_CONDITION = class_2378.method_10230(CONDITION_SERIALIZERS, PortingLib.neo("or"), OrCondition.CODEC);
	public static final MapCodec<TagEmptyCondition> TAG_EMPTY_CONDITION = class_2378.method_10230(CONDITION_SERIALIZERS, PortingLib.neo("tag_empty"), TagEmptyCondition.CODEC);
	public static final MapCodec<TrueCondition> TRUE_CONDITION = class_2378.method_10230(CONDITION_SERIALIZERS, PortingLib.neo("true"), TrueCondition.CODEC);

	public static void init() {}
}
