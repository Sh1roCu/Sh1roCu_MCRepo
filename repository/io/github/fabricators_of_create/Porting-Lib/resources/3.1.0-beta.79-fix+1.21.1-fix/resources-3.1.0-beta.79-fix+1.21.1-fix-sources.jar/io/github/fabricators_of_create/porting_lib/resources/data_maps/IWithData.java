package io.github.fabricators_of_create.porting_lib.resources.data_maps;

import org.jetbrains.annotations.Nullable;

/**
 * Represents a registry object (usually a {@link net.minecraft.class_6880}) that has data maps.
 *
 * @param <R> the type of the object
 */
public interface IWithData<R> {
	/**
	 * {@return the data of the given type that is attached to this object, or {@code null} if one isn't}
	 *
	 * @param type the data type
	 * @param <T>  the type of the data
	 */
	@Nullable
	default <T> T getData(DataMapType<R, T> type) {
		return null;
	}
}
