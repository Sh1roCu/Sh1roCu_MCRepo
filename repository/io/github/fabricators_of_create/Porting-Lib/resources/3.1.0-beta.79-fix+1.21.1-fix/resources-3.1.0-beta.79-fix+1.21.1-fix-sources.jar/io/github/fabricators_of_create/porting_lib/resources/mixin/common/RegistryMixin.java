package io.github.fabricators_of_create.porting_lib.resources.mixin.common;

import io.github.fabricators_of_create.porting_lib.resources.injections.RegistryInjection;
import net.minecraft.class_2378;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2378.class)
public interface RegistryMixin<T> extends RegistryInjection<T> {
}
