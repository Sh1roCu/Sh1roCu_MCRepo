package io.github.fabricators_of_create.porting_lib.resources.fluids.crafting;

import com.mojang.serialization.MapCodec;
import java.util.stream.Stream;

import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.resources.crafting.PortingLibIngredients;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_6880;

/**
 * Fluid ingredient that only matches the fluid of the given stack.
 * <p>
 * Unlike with ingredients, this is an explicit "type" of fluid ingredient,
 * though it may still be written without a type field, see {@link FluidIngredient#MAP_CODEC_NONEMPTY}
 */
public class SingleFluidIngredient extends FluidIngredient {
	public static final MapCodec<SingleFluidIngredient> CODEC = FluidStack.FLUID_NON_EMPTY_CODEC
			.xmap(SingleFluidIngredient::new, SingleFluidIngredient::fluid).fieldOf("fluid");

	private final class_6880<class_3611> fluid;

	public SingleFluidIngredient(class_6880<class_3611> fluid) {
		if (fluid.method_55838(class_3612.field_15906.method_40178())) {
			throw new IllegalStateException("SingleFluidIngredient must not be constructed with minecraft:empty, use FluidIngredient.empty() instead!");
		}
		this.fluid = fluid;
	}

	@Override
	public boolean test(FluidStack fluidStack) {
		return fluidStack.is(fluid);
	}

	@Override
	protected Stream<FluidStack> generateStacks() {
		return Stream.of(new FluidStack(fluid, FluidConstants.BUCKET));
	}

	@Override
	public boolean isSimple() {
		return true;
	}

	@Override
	public FluidIngredientType<?> getType() {
		return PortingLibIngredients.SINGLE_FLUID_INGREDIENT_TYPE;
	}

	@Override
	public int hashCode() {
		return this.fluid().comp_349().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		return obj instanceof SingleFluidIngredient other && other.fluid.method_55838(this.fluid);
	}

	public class_6880<class_3611> fluid() {
		return fluid;
	}
}
