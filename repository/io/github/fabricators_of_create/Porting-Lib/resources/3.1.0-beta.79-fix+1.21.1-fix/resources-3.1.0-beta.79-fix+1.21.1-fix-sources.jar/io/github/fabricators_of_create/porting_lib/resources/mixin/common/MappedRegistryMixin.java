package io.github.fabricators_of_create.porting_lib.resources.mixin.common;

import io.github.fabricators_of_create.porting_lib.resources.data_maps.DataMapType;
import io.github.fabricators_of_create.porting_lib.resources.injections.RegistryInjection;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.class_2370;
import net.minecraft.class_5321;
import net.minecraft.class_7225;

@Mixin(class_2370.class)
public abstract class MappedRegistryMixin<T> implements RegistryInjection<T> {
	@Unique private final Map<DataMapType<T, ?>, Map<class_5321<T>, ?>> port_lib$dataMaps = new IdentityHashMap<>();

	@Override
	public Map<DataMapType<T, ?>, Map<class_5321<T>, ?>> port_lib$getDataMaps() {
		return port_lib$dataMaps;
	}

	@Mixin(targets = "net/minecraft/core/MappedRegistry$1")
	public abstract static class MappedRegistryLookupMixin<T> implements class_7225.class_7226<T> {
		@Shadow
		@Final
		private class_2370<T> field_36468;

		@Override
		@Nullable
		public <A> A getData(DataMapType<T, A> type, class_5321<T> key) {
			return field_36468.getData(type, key);
		}
	}
}
