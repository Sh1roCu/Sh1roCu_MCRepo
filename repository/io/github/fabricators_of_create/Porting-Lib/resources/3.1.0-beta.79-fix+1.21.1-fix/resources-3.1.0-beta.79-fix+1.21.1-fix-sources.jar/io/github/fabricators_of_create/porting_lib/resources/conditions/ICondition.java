/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package io.github.fabricators_of_create.porting_lib.resources.conditions;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.MapCodec;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3902;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6903;
import net.minecraft.class_7225;

public interface ICondition {
	Codec<ICondition> CODEC = PortingLibConditions.CONDITION_SERIALIZERS.method_39673()
			.dispatch(ICondition::codec, Function.identity());
	Codec<List<ICondition>> LIST_CODEC = CODEC.listOf();

	static <V, T> Optional<T> getConditionally(Codec<T> codec, DynamicOps<V> ops, V element) {
		return getWithConditionalCodec(ConditionalOps.createConditionalCodec(codec), ops, element);
	}

	static <V, T> Optional<T> getWithConditionalCodec(Codec<Optional<T>> codec, DynamicOps<V> ops, V element) {
		return codec.parse(ops, element).getOrThrow(JsonParseException::new);
	}

	static <V, T> Optional<T> getWithWithConditionsCodec(Codec<Optional<WithConditions<T>>> codec, DynamicOps<V> ops, V elements) {
		return codec.parse(ops, elements).promotePartial((m) -> {}).getOrThrow(JsonParseException::new).map(WithConditions::carrier);
	}

	static <V> boolean conditionsMatched(DynamicOps<V> ops, V element) {
		final Codec<class_3902> codec = Codec.unit(class_3902.field_17274);
		return getConditionally(codec, ops, element).isPresent();
	}

	/**
	 * Writes an array of conditions to a JSON object.
	 */
	static void writeConditions(class_7225.class_7874 registries, JsonObject jsonObject, ICondition... conditions) {
		writeConditions(registries, jsonObject, List.of(conditions));
	}

	/**
	 * Writes a list of conditions to a JSON object.
	 */
	static void writeConditions(class_7225.class_7874 registries, JsonObject jsonObject, List<ICondition> conditions) {
		writeConditions(class_6903.method_46632(JsonOps.INSTANCE, registries), jsonObject, conditions);
	}

	/**
	 * Writes a list of conditions to a JSON object.
	 */
	static void writeConditions(DynamicOps<JsonElement> jsonOps, JsonObject jsonObject, List<ICondition> conditions) {
		if (!conditions.isEmpty()) {
			var result = LIST_CODEC.encodeStart(jsonOps, conditions);
			JsonElement serializedConditions = result.result().orElseThrow(() -> new RuntimeException("Failed to serialize conditions"));
			jsonObject.add(ConditionalOps.DEFAULT_CONDITIONS_KEY, serializedConditions);
		}
	}

	boolean test(IContext context);

	MapCodec<? extends ICondition> codec();

	interface IContext {
		IContext EMPTY = new IContext() {
			@Override
			public <T> Map<class_2960, Collection<class_6880<T>>> getAllTags(class_5321<? extends class_2378<T>> registry) {
				return Collections.emptyMap();
			}
		};

		IContext TAGS_INVALID = new IContext() {
			@Override
			public <T> Map<class_2960, Collection<class_6880<T>>> getAllTags(class_5321<? extends class_2378<T>> registry) {
				throw new UnsupportedOperationException("Usage of tag-based conditions is not permitted in this context!");
			}
		};

		/**
		 * Return the requested tag if available, or an empty tag otherwise.
		 */
		default <T> Collection<class_6880<T>> getTag(class_6862<T> key) {
			return getAllTags(key.comp_326()).getOrDefault(key.comp_327(), Set.of());
		}

		/**
		 * Return all the loaded tags for the passed registry, or an empty map if none is available.
		 * Note that the map and the tags are unmodifiable.
		 */
		<T> Map<class_2960, Collection<class_6880<T>>> getAllTags(class_5321<? extends class_2378<T>> registry);
	}
}
