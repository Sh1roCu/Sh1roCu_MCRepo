package io.github.fabricators_of_create.porting_lib.resources.conditions;

import com.mojang.serialization.MapCodec;

import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public record TagEmptyCondition(class_6862<class_1792> tag) implements ICondition {
	public static final MapCodec<TagEmptyCondition> CODEC = RecordCodecBuilder.mapCodec(
			builder -> builder
					.group(
							class_2960.field_25139.xmap(loc -> class_6862.method_40092(class_7924.field_41197, loc), class_6862::comp_327).fieldOf("tag").forGetter(TagEmptyCondition::tag))
					.apply(builder, TagEmptyCondition::new));

	public TagEmptyCondition(String location) {
		this(class_2960.method_60654(location));
	}

	public TagEmptyCondition(String namespace, String path) {
		this(class_2960.method_60655(namespace, path));
	}

	public TagEmptyCondition(class_2960 tag) {
		this(class_6862.method_40092(class_7924.field_41197, tag));
	}

	@Override
	public boolean test(ICondition.IContext context) {
		return context.getTag(tag).isEmpty();
	}

	@Override
	public MapCodec<? extends ICondition> codec() {
		return CODEC;
	}

	@Override
	public String toString() {
		return "tag_empty(\"" + tag.comp_327() + "\")";
	}
}
