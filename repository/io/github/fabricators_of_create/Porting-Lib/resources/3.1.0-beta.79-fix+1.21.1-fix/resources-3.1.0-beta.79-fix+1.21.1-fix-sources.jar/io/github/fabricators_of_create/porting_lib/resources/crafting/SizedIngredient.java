package io.github.fabricators_of_create.porting_lib.resources.crafting;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Objects;
import java.util.stream.Stream;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_5699;
import net.minecraft.class_6862;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.github.fabricators_of_create.porting_lib.core.util.PortingLibExtraCodecs;
import org.jetbrains.annotations.Nullable;

/**
 * Standard implementation for an ingredient and a count.
 *
 * <p>{@link class_1856} does not perform count checks, so this class is used to wrap an ingredient with a count,
 * and provide a standard serialization format.
 */
public final class SizedIngredient {
	/**
	 * The "flat" codec for {@link SizedIngredient}.
	 *
	 * <p>The count is serialized inline with the rest of the ingredient, for example:
	 *
	 * <pre>{@code
	 * {
	 *     "item": "minecraft:apple",
	 *     "count": 3
	 * }
	 * }</pre>
	 *
	 * Array ingredients are serialized using the compound ingredient type:
	 *
	 * <pre>{@code
	 * {
	 *     "fabric:type": "fabric:any",
	 *     "ingredients": [
	 *         { "item": "minecraft:coal" },
	 *         { "item": "minecraft:charcoal" }
	 *     ],
	 *     "count": 2
	 * }
	 * }</pre>
	 *
	 * See {@link PortingLibIngredients#INGREDIENT_MAP_CODEC_NONEMPTY} for details of the ingredient serialization.
	 */
	public static final Codec<SizedIngredient> FLAT_CODEC = RecordCodecBuilder.create(instance -> instance.group(
					PortingLibIngredients.INGREDIENT_MAP_CODEC_NONEMPTY.forGetter(SizedIngredient::ingredient),
					PortingLibExtraCodecs.optionalFieldAlwaysWrite(class_5699.field_33442, "count", 1).forGetter(SizedIngredient::count))
			.apply(instance, SizedIngredient::new));

	/**
	 * The "nested" codec for {@link SizedIngredient}.
	 *
	 * <p>The count is serialized separately from the rest of the ingredient, for example:
	 *
	 * <pre>{@code
	 * {
	 *     "ingredient": {
	 *         "item": "minecraft:apple"
	 *     },
	 *     "count": 3
	 * }
	 * }</pre>
	 */
	public static final Codec<SizedIngredient> NESTED_CODEC = RecordCodecBuilder.create(instance -> instance.group(
					class_1856.field_46096.fieldOf("ingredient").forGetter(SizedIngredient::ingredient),
					PortingLibExtraCodecs.optionalFieldAlwaysWrite(class_5699.field_33442, "count", 1).forGetter(SizedIngredient::count))
			.apply(instance, SizedIngredient::new));

	public static final class_9139<class_9129, SizedIngredient> STREAM_CODEC = class_9139.method_56435(
			class_1856.field_48355,
			SizedIngredient::ingredient,
			class_9135.field_48550,
			SizedIngredient::count,
			SizedIngredient::new);

	/**
	 * Helper method to create a simple sized ingredient that matches a single item.
	 */
	public static SizedIngredient of(class_1935 item, int count) {
		return new SizedIngredient(class_1856.method_8091(item), count);
	}

	/**
	 * Helper method to create a simple sized ingredient that matches items in a tag.
	 */
	public static SizedIngredient of(class_6862<class_1792> tag, int count) {
		return new SizedIngredient(class_1856.method_8106(tag), count);
	}

	private final class_1856 ingredient;
	private final int count;
	@Nullable
	private class_1799[] cachedStacks;

	public SizedIngredient(class_1856 ingredient, int count) {
		if (count <= 0) {
			throw new IllegalArgumentException("Size must be positive");
		}
		this.ingredient = ingredient;
		this.count = count;
	}

	public class_1856 ingredient() {
		return ingredient;
	}

	public int count() {
		return count;
	}

	/**
	 * Performs a size-sensitive test on the given stack.
	 *
	 * @return {@code true} if the stack matches the ingredient and has at least the required count.
	 */
	public boolean test(class_1799 stack) {
		return ingredient.method_8093(stack) && stack.method_7947() >= count;
	}

	/**
	 * Returns a list of the stacks from this {@link #ingredient}, with an updated {@link #count}.
	 *
	 * @implNote the array is cached and should not be modified, just like {@link class_1856#method_8105()}.
	 */
	public class_1799[] getItems() {
		if (cachedStacks == null) {
			cachedStacks = Stream.of(ingredient.method_8105())
					.map(s -> s.method_46651(count))
					.toArray(class_1799[]::new);
		}
		return cachedStacks;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof SizedIngredient other)) return false;
		return count == other.count && ingredient.equals(other.ingredient);
	}

	@Override
	public int hashCode() {
		return Objects.hash(ingredient, count);
	}

	@Override
	public String toString() {
		return count + "x " + ingredient;
	}
}
