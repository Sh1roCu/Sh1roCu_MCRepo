package io.github.fabricators_of_create.porting_lib.resources.fluids.crafting;

import com.mojang.serialization.MapCodec;
import java.util.stream.Stream;

import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.resources.crafting.PortingLibIngredients;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import net.minecraft.class_6885;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Fluid ingredient that matches all fluids within the given tag.
 * <p>
 * Unlike with ingredients, this is an explicit "type" of fluid ingredient,
 * though it may still be written without a type field, see {@link FluidIngredient#MAP_CODEC_NONEMPTY}
 */
public class TagFluidIngredient extends FluidIngredient {
	public static final MapCodec<TagFluidIngredient> CODEC = class_6862.method_40090(class_7924.field_41270)
			.xmap(TagFluidIngredient::new, TagFluidIngredient::tag).fieldOf("tag");

	private final class_6862<class_3611> tag;

	public TagFluidIngredient(class_6862<class_3611> tag) {
		this.tag = tag;
	}

	@Override
	public boolean test(FluidStack fluidStack) {
		return fluidStack.is(tag);
	}

	@Override
	protected Stream<FluidStack> generateStacks() {
		return class_7923.field_41173.method_40266(tag)
				.stream()
				.flatMap(class_6885::method_40239)
				.map(fluid -> new FluidStack(fluid, FluidConstants.BUCKET));
	}

	@Override
	public boolean isSimple() {
		return true;
	}

	@Override
	public FluidIngredientType<?> getType() {
		return PortingLibIngredients.TAG_FLUID_INGREDIENT_TYPE;
	}

	@Override
	public int hashCode() {
		return tag.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		return obj instanceof TagFluidIngredient tag && tag.tag.equals(this.tag);
	}

	public class_6862<class_3611> tag() {
		return tag;
	}
}
