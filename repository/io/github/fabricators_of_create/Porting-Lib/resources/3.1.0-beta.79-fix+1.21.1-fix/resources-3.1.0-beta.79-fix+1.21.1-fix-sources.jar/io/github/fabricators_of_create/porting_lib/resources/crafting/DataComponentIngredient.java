package io.github.fabricators_of_create.porting_lib.resources.crafting;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;

import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredient;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredientSerializer;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_6898;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9323;
import net.minecraft.class_9329;
import net.minecraft.class_9331;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

/**
 * Ingredient that matches the given items, performing either a {@link DataComponentIngredient#isStrict() strict} or a partial NBT test.
 * <p>
 * Strict NBT ingredients will only match items that have <b>exactly</b> the provided tag, while partial ones will
 * match if the item's tags contain all of the elements of the provided one, while allowing for additional elements to exist.
 */
public class DataComponentIngredient implements CustomIngredient {
	public static final MapCodec<DataComponentIngredient> CODEC = RecordCodecBuilder.mapCodec(
			builder -> builder
					.group(
							class_6898.method_40388(class_7924.field_41197, class_7923.field_41178.method_40294(), false).fieldOf("items").forGetter(DataComponentIngredient::items),
							class_9329.field_49595.fieldOf("components").forGetter(DataComponentIngredient::components),
							Codec.BOOL.optionalFieldOf("strict", false).forGetter(DataComponentIngredient::isStrict))
					.apply(builder, DataComponentIngredient::new));

	private final class_6885<class_1792> items;
	private final class_9329 components;
	private final boolean strict;
	private final class_1799[] stacks;

	public DataComponentIngredient(class_6885<class_1792> items, class_9329 components, boolean strict) {
		this.items = items;
		this.components = components;
		this.strict = strict;
		this.stacks = items.method_40239()
				.map(i -> new class_1799(i, 1, components.method_57870()))
				.toArray(class_1799[]::new);
	}

	@Override
	public boolean test(class_1799 stack) {
		if (strict) {
			for (class_1799 stack2 : this.stacks) {
				if (class_1799.method_31577(stack, stack2)) return true;
			}
			return false;
		} else {
			return this.items.method_40241(stack.method_41409()) && this.components.method_57864(stack);
		}
	}

	@Override
	public List<class_1799> getMatchingStacks() {
		return List.of(stacks);
	}

	@Override
	public boolean requiresTesting() {
		return true;
	}

	@Override
	public CustomIngredientSerializer<?> getSerializer() {
		return PortingLibIngredients.DATA_COMPONENT_INGREDIENT_TYPE;
	}

	public class_6885<class_1792> items() {
		return items;
	}

	public class_9329 components() {
		return components;
	}

	public boolean isStrict() {
		return strict;
	}

	/**
	 * Creates a new ingredient matching the given item, containing the given components
	 */
	public static class_1856 of(boolean strict, class_1799 stack) {
		return of(strict, stack.method_57353(), stack.method_7909());
	}

	/**
	 * Creates a new ingredient matching any item from the list, containing the given components
	 */
	public static <T> class_1856 of(boolean strict, class_9331<? super T> type, T value, class_1935... items) {
		return of(strict, class_9329.method_57862().method_57872(type, value).method_57871(), items);
	}

	/**
	 * Creates a new ingredient matching any item from the list, containing the given components
	 */
	public static <T> class_1856 of(boolean strict, Supplier<? extends class_9331<? super T>> type, T value, class_1935... items) {
		return of(strict, type.get(), value, items);
	}

	/**
	 * Creates a new ingredient matching any item from the list, containing the given components
	 */
	public static class_1856 of(boolean strict, class_9323 map, class_1935... items) {
		return of(strict, class_9329.method_57865(map), items);
	}

	/**
	 * Creates a new ingredient matching any item from the list, containing the given components
	 */
	@SafeVarargs
	public static class_1856 of(boolean strict, class_9323 map, class_6880<class_1792>... items) {
		return of(strict, class_9329.method_57865(map), items);
	}

	/**
	 * Creates a new ingredient matching any item from the list, containing the given components
	 */
	public static class_1856 of(boolean strict, class_9323 map, class_6885<class_1792> items) {
		return of(strict, class_9329.method_57865(map), items);
	}

	/**
	 * Creates a new ingredient matching any item from the list, containing the given components
	 */
	@SafeVarargs
	public static class_1856 of(boolean strict, class_9329 predicate, class_6880<class_1792>... items) {
		return of(strict, predicate, class_6885.method_40246(items));
	}

	/**
	 * Creates a new ingredient matching any item from the list, containing the given components
	 */
	public static class_1856 of(boolean strict, class_9329 predicate, class_1935... items) {
		return of(strict, predicate, class_6885.method_40242(Arrays.stream(items).map(class_1935::method_8389).map(class_1792::method_40131).toList()));
	}

	/**
	 * Creates a new ingredient matching any item from the list, containing the given components
	 */
	public static class_1856 of(boolean strict, class_9329 predicate, class_6885<class_1792> items) {
		return new DataComponentIngredient(items, predicate, strict).toVanilla();
	}
}
