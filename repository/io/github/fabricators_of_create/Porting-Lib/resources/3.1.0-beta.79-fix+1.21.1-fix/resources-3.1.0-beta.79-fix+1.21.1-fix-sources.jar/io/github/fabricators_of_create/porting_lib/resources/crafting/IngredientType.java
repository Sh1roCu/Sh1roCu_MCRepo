package io.github.fabricators_of_create.porting_lib.resources.crafting;

import com.mojang.serialization.MapCodec;

import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredient;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredientSerializer;
import net.minecraft.class_2960;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record IngredientType<T extends CustomIngredient>(class_2960 id, MapCodec<T> codec, class_9139<class_9129, T> streamCodec) implements CustomIngredientSerializer<T> {
	/**
	 * Constructor for ingredient types that use a regular codec for network syncing.
	 */
	public IngredientType(class_2960 id, MapCodec<T> codec) {
		this(id, codec, class_9135.method_56896(codec.codec()));
	}

	@Override
	public class_2960 getIdentifier() {
		return id;
	}

	@Override
	public MapCodec<T> getCodec(boolean allowEmpty) {
		return codec;
	}

	@Override
	public class_9139<class_9129, T> getPacketCodec() {
		return streamCodec;
	}
}
