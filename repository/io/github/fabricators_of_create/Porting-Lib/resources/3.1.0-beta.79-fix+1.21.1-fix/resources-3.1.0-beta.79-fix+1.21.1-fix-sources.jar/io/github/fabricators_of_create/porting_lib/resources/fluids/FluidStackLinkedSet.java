package io.github.fabricators_of_create.porting_lib.resources.fluids;

import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import it.unimi.dsi.fastutil.Hash;
import it.unimi.dsi.fastutil.objects.ObjectLinkedOpenCustomHashSet;
import java.util.Set;
import org.jetbrains.annotations.Nullable;

/**
 * Utility class for creating {@linkplain ObjectLinkedOpenCustomHashSet linked set} for {@link FluidStack}
 * with specific {@linkplain Hash.Strategy hash strategy} as {@link FluidStack} does not override {@link #hashCode()} and {@link #equals(Object)}.
 *
 * @see net.minecraft.class_7708
 */
public class FluidStackLinkedSet {
	public static final Hash.Strategy<? super FluidStack> TYPE_AND_COMPONENTS = new Hash.Strategy<>() {
		public int hashCode(@Nullable FluidStack stack) {
			return FluidStack.hashFluidAndComponents(stack);
		}

		public boolean equals(@Nullable FluidStack first, @Nullable FluidStack second) {
			return first == second
					|| first != null
					&& second != null
					&& first.isEmpty() == second.isEmpty()
					&& FluidStack.isSameFluidSameComponents(first, second);
		}
	};

	public static Set<FluidStack> createTypeAndComponentsSet() {
		return new ObjectLinkedOpenCustomHashSet<>(TYPE_AND_COMPONENTS);
	}
}
