package io.github.fabricators_of_create.porting_lib.resources.conditions;

import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3505;
import net.minecraft.class_3505.class_6863;
import net.minecraft.class_5321;
import net.minecraft.class_6880;

public class ConditionContext implements ICondition.IContext {
	private final class_3505 tagManager;
	@Nullable
	// TODO 1.20.5: Clear loaded tags after reloads complete. The context object may leak, but we still want to invalidate it.
	private Map<class_5321<?>, Map<class_2960, Collection<class_6880<?>>>> loadedTags = null;

	public ConditionContext(class_3505 tagManager) {
		this.tagManager = tagManager;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public <T> Map<class_2960, Collection<class_6880<T>>> getAllTags(class_5321<? extends class_2378<T>> registry) {
		if (loadedTags == null) {
			var tags = tagManager.method_40096();
			if (tags.isEmpty()) throw new IllegalStateException("Tags have not been loaded yet.");

			loadedTags = new IdentityHashMap<>();
			for (var loadResult : tags) {
				Map<class_2960, Collection<? extends class_6880<?>>> map = Collections.unmodifiableMap(loadResult.comp_329());
				loadedTags.put(loadResult.comp_328(), (Map) map);
			}
		}
		return (Map) loadedTags.getOrDefault(registry, Collections.emptyMap());
	}
}
