package io.github.fabricators_of_create.porting_lib.resources.mixin.client;

import io.github.fabricators_of_create.porting_lib.resources.events.RecipesUpdatedEvent;
import net.minecraft.class_1863;
import net.minecraft.class_2788;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class ClientPacketListenerMixin {
	@Shadow
	@Final
	private class_1863 recipeManager;

	@Inject(method = "handleUpdateRecipes", at = @At("TAIL"))
	public void port_lib$updateRecipes(class_2788 packet, CallbackInfo ci) {
		new RecipesUpdatedEvent(this.recipeManager).sendEvent();
	}
}
