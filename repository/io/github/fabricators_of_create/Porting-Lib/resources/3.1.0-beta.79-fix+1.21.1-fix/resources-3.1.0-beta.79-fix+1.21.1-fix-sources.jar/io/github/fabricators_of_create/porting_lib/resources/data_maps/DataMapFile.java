package io.github.fabricators_of_create.porting_lib.resources.data_maps;

import com.mojang.datafixers.util.Either;

import com.mojang.serialization.Codec;

import com.mojang.serialization.codecs.RecordCodecBuilder;

import io.github.fabricators_of_create.porting_lib.core.util.PortingLibExtraCodecs;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ConditionalOps;
import io.github.fabricators_of_create.porting_lib.resources.conditions.WithConditions;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_5699;
import net.minecraft.class_6862;

public record DataMapFile<T, R>(
		boolean replace,
		Map<Either<class_6862<R>, class_5321<R>>, Optional<WithConditions<DataMapEntry<T>>>> values,
		List<DataMapEntry.Removal<T, R>> removals) {
	public static <T, R> Codec<DataMapFile<T, R>> codec(class_5321<class_2378<R>> registryKey, DataMapType<R, T> dataMap) {
		final Codec<Either<class_6862<R>, class_5321<R>>> tagOrValue = class_5699.field_39274.xmap(
				l -> l.comp_814() ? Either.left(class_6862.method_40092(registryKey, l.comp_813())) : Either.right(class_5321.method_29179(registryKey, l.comp_813())),
				e -> e.map(t -> new class_5699.class_7476(t.comp_327(), true), r -> new class_5699.class_7476(r.method_29177(), false)));

		final Codec<List<DataMapEntry.Removal<T, R>>> removalsCodec;
		if (dataMap instanceof AdvancedDataMapType<R, T, ?>) {
			final var removalCodec = DataMapEntry.Removal.codec(tagOrValue, dataMap);
			final AdvancedDataMapType<R, T, DataMapValueRemover<R, T>> advanced = (AdvancedDataMapType<R, T, DataMapValueRemover<R, T>>) dataMap;
			removalsCodec = PortingLibExtraCodecs.withAlternative(
					PortingLibExtraCodecs.withAlternative(removalCodec.listOf(), PortingLibExtraCodecs.decodeOnly(tagOrValue.listOf()
							.map(l -> l.stream().map(k -> new DataMapEntry.Removal<T, R>(k, Optional.empty())).toList()))),
					PortingLibExtraCodecs.decodeOnly(class_5699.method_53703(tagOrValue, advanced.remover())
							.map(map -> map.entrySet().stream()
									.map(entry -> new DataMapEntry.Removal<>(entry.getKey(), Optional.of(entry.getValue()))).toList())));
		} else {
			removalsCodec = tagOrValue.listOf()
					.xmap(l -> l.stream().map(k -> new DataMapEntry.Removal<T, R>(k, Optional.empty())).toList(),
							rm -> rm.stream().map(DataMapEntry.Removal::key).toList());
		}

		return RecordCodecBuilder.create(in -> in.group(
						Codec.BOOL.optionalFieldOf("replace", false).forGetter(DataMapFile::replace),
						class_5699.method_53703(tagOrValue, ConditionalOps.createConditionalCodecWithConditions(DataMapEntry.codec(dataMap))).fieldOf("values").forGetter(DataMapFile::values),
						removalsCodec.optionalFieldOf("remove", List.of()).forGetter(DataMapFile::removals))
				.apply(in, DataMapFile::new));
	}
}
