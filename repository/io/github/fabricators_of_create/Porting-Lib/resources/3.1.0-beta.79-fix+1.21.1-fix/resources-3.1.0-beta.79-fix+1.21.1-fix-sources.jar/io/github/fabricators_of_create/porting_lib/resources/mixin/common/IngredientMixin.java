package io.github.fabricators_of_create.porting_lib.resources.mixin.common;

import io.github.fabricators_of_create.porting_lib.resources.injections.IngredientInjection;
import net.fabricmc.fabric.api.recipe.v1.ingredient.FabricIngredient;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_5250;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1856.class)
public abstract class IngredientMixin implements IngredientInjection, FabricIngredient {
	@Shadow
	@Final
	private class_1856.class_1859[] values;

	@Shadow
	public abstract class_1799[] getItems();

	@Override
	public class_1856.class_1859[] port_lib$getValues() {
		if (port_lib$isCustom()) {
			throw new IllegalStateException("Cannot retrieve values from custom ingredient!");
		}
		return this.values;
	}

	@Override
	public boolean port_lib$isCustom() {
		return getCustomIngredient() != null;
	}

	@Override
	public boolean port_lib$hasNoItems() {
		class_1799[] items = getItems();
		if (items.length == 0)
			return true;
		if (items.length == 1) {
			// If we potentially added a barrier due to the ingredient being an empty tag, try and check if it is the stack we added
			class_1799 item = items[0];
			return item.method_7909() == class_1802.field_8077 && item.method_7964() instanceof class_5250 hoverName && hoverName.getString().startsWith("Empty Tag: ");
		}
		return false;
	}
}
