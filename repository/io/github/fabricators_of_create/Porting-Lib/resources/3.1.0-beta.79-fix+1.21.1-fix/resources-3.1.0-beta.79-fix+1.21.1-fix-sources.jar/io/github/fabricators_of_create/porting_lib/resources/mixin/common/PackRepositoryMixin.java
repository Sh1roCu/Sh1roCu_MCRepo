package io.github.fabricators_of_create.porting_lib.resources.mixin.common;

import io.github.fabricators_of_create.porting_lib.resources.injections.PackRepositoryInjection;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Set;
import net.minecraft.class_3283;
import net.minecraft.class_3285;

@Mixin(class_3283.class)
public abstract class PackRepositoryMixin implements PackRepositoryInjection {
	@Shadow
	@Final
	private Set<class_3285> sources;

	@Override
	public synchronized void port_lib$addPackFinder(class_3285 packFinder) {
		this.sources.add(packFinder);
	}
}
