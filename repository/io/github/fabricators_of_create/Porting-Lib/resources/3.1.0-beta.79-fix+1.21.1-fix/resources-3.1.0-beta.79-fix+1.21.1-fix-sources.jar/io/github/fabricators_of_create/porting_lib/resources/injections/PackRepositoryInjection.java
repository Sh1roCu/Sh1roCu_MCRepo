package io.github.fabricators_of_create.porting_lib.resources.injections;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import net.minecraft.class_3285;

public interface PackRepositoryInjection {
	default void port_lib$addPackFinder(class_3285 packFinder) {
		throw PortingLib.createMixinException("PackRepositoryExtension.addPackFinder(RepositorySource)");
	}
}
