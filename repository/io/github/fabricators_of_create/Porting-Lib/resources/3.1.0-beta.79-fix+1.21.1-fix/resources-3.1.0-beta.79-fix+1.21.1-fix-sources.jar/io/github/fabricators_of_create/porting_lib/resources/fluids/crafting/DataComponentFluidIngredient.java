package io.github.fabricators_of_create.porting_lib.resources.fluids.crafting;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Arrays;
import java.util.Objects;
import java.util.function.Supplier;
import java.util.stream.Stream;

import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.resources.crafting.DataComponentIngredient;
import io.github.fabricators_of_create.porting_lib.resources.crafting.PortingLibIngredients;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_3611;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_6898;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9323;
import net.minecraft.class_9329;
import net.minecraft.class_9331;

/**
 * Fluid ingredient that matches the given set of fluids, additionally performing either a
 * {@link DataComponentFluidIngredient#isStrict() strict} or partial test on the FluidStack's components.
 * <p>
 * Strict ingredients will only match fluid stacks that have <b>exactly</b> the provided components, while partial ones will
 * match if the stack's components contain all required components for the {@linkplain #components input predicate}.
 *
 * @see DataComponentIngredient DataComponentIngredient, its item equivalent
 */
public class DataComponentFluidIngredient extends FluidIngredient {
	public static final MapCodec<DataComponentFluidIngredient> CODEC = RecordCodecBuilder.mapCodec(
			builder -> builder
					.group(
							class_6898.method_40388(class_7924.field_41270, class_7923.field_41173.method_40294(), false).fieldOf("fluids").forGetter(DataComponentFluidIngredient::fluids),
							class_9329.field_49595.fieldOf("components").forGetter(DataComponentFluidIngredient::components),
							Codec.BOOL.optionalFieldOf("strict", false).forGetter(DataComponentFluidIngredient::isStrict))
					.apply(builder, DataComponentFluidIngredient::new));

	private final class_6885<class_3611> fluids;
	private final class_9329 components;
	private final boolean strict;
	private final FluidStack[] stacks;

	public DataComponentFluidIngredient(class_6885<class_3611> fluids, class_9329 components, boolean strict) {
		this.fluids = fluids;
		this.components = components;
		this.strict = strict;
		this.stacks = fluids.method_40239()
				.map(i -> new FluidStack(i, FluidConstants.BUCKET, components.method_57870()))
				.toArray(FluidStack[]::new);
	}

	@Override
	public boolean test(FluidStack stack) {
		if (strict) {
			for (FluidStack stack2 : this.stacks) {
				if (FluidStack.isSameFluidSameComponents(stack, stack2)) return true;
			}
			return false;
		} else {
			return this.fluids.method_40241(stack.getFluidHolder()) && this.components.method_57868(stack);
		}
	}

	public Stream<FluidStack> generateStacks() {
		return Stream.of(stacks);
	}

	@Override
	public boolean isSimple() {
		return false;
	}

	@Override
	public FluidIngredientType<?> getType() {
		return PortingLibIngredients.DATA_COMPONENT_FLUID_INGREDIENT_TYPE;
	}

	@Override
	public int hashCode() {
		return Objects.hash(fluids, components, strict);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (!(obj instanceof DataComponentFluidIngredient other)) return false;
		return other.fluids.equals(this.fluids)
				&& other.components.equals(this.components)
				&& other.strict == this.strict;
	}

	public class_6885<class_3611> fluids() {
		return fluids;
	}

	public class_9329 components() {
		return components;
	}

	public boolean isStrict() {
		return strict;
	}

	/**
	 * Creates a new ingredient matching the given fluid, containing the given components
	 */
	public static FluidIngredient of(boolean strict, FluidStack stack) {
		return of(strict, stack.getComponents(), stack.getFluid());
	}

	/**
	 * Creates a new ingredient matching any fluid from the list, containing the given components
	 */
	public static <T> FluidIngredient of(boolean strict, class_9331<? super T> type, T value, class_3611... fluids) {
		return of(strict, class_9329.method_57862().method_57872(type, value).method_57871(), fluids);
	}

	/**
	 * Creates a new ingredient matching any fluid from the list, containing the given components
	 */
	public static <T> FluidIngredient of(boolean strict, Supplier<? extends class_9331<? super T>> type, T value, class_3611... fluids) {
		return of(strict, type.get(), value, fluids);
	}

	/**
	 * Creates a new ingredient matching any fluid from the list, containing the given components
	 */
	public static FluidIngredient of(boolean strict, class_9323 map, class_3611... fluids) {
		return of(strict, class_9329.method_57865(map), fluids);
	}

	/**
	 * Creates a new ingredient matching any fluid from the list, containing the given components
	 */
	@SafeVarargs
	public static FluidIngredient of(boolean strict, class_9323 map, class_6880<class_3611>... fluids) {
		return of(strict, class_9329.method_57865(map), fluids);
	}

	/**
	 * Creates a new ingredient matching any fluid from the list, containing the given components
	 */
	public static FluidIngredient of(boolean strict, class_9323 map, class_6885<class_3611> fluids) {
		return of(strict, class_9329.method_57865(map), fluids);
	}

	/**
	 * Creates a new ingredient matching any fluid from the list, containing the given components
	 */
	@SafeVarargs
	public static FluidIngredient of(boolean strict, class_9329 predicate, class_6880<class_3611>... fluids) {
		return of(strict, predicate, class_6885.method_40246(fluids));
	}

	/**
	 * Creates a new ingredient matching any fluid from the list, containing the given components
	 */
	public static FluidIngredient of(boolean strict, class_9329 predicate, class_3611... fluids) {
		return of(strict, predicate, class_6885.method_40242(Arrays.stream(fluids).map(class_3611::method_40178).toList()));
	}

	/**
	 * Creates a new ingredient matching any fluid from the list, containing the given components
	 */
	public static FluidIngredient of(boolean strict, class_9329 predicate, class_6885<class_3611> fluids) {
		return new DataComponentFluidIngredient(fluids, predicate, strict);
	}
}
