package io.github.fabricators_of_create.porting_lib.resources.events;

import java.util.function.Consumer;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_3285;
import net.minecraft.class_3288;

/**
 * Fired on {@link class_3283} creation to allow mods to add new pack finders.
 */
public class AddPackFindersEvent extends BaseEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (Callback c : callbacks)
			c.findPacks(event);
	});
	private final class_3264 packType;
	private final Consumer<class_3285> sources;
	private final boolean trusted;

	public AddPackFindersEvent(class_3264 packType, Consumer<class_3285> sources, boolean trusted) {
		this.packType = packType;
		this.sources = sources;
		this.trusted = trusted;
	}

	/**
	 * Adds a new source to the list of pack finders.
	 *
	 * <p>Sources are processed in the order that they are added to the event.
	 * Use {@link class_3288.class_3289#field_14280} to add high priority packs,
	 * and {@link class_3288.class_3289#field_14281} to add low priority packs.
	 *
	 * @param source the pack finder
	 */
	public void addRepositorySource(class_3285 source) {
		sources.accept(source);
	}

	/**
	 * @return the {@link class_3264} of the pack repository being constructed.
	 */
	public class_3264 getPackType() {
		return packType;
	}

	/**
	 * {@return whether or not the pack repository being assembled is the one used to provide known packs to the client to avoid syncing from the server}
	 */
	public boolean isTrusted() {
		return trusted;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().findPacks(this);
	}

	public interface Callback {
		void findPacks(AddPackFindersEvent event);
	}
}
