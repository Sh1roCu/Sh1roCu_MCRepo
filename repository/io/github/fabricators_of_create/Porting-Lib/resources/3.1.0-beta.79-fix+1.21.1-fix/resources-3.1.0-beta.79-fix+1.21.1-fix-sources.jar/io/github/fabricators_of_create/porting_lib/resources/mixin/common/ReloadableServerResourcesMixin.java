package io.github.fabricators_of_create.porting_lib.resources.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.resources.conditions.ConditionContext;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ICondition;
import io.github.fabricators_of_create.porting_lib.resources.events.AddReloadListenersEvent;
import io.github.fabricators_of_create.porting_lib.resources.events.TagsUpdatedEvent;
import io.github.fabricators_of_create.porting_lib.resources.extensions.ContextAwareReloadListenerExtension;
import io.github.fabricators_of_create.porting_lib.resources.injections.ReloadableServerResourcesInjection;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_3302;
import net.minecraft.class_3505;
import net.minecraft.class_5350;
import net.minecraft.class_7225;
import net.minecraft.class_7659;
import net.minecraft.class_7780;
import net.minecraft.class_9383;

@Mixin(class_5350.class)
public abstract class ReloadableServerResourcesMixin implements ReloadableServerResourcesInjection {
	@Shadow
	@Final
	private class_3505 tagManager;

	@Shadow
	@Final
	private class_5350.class_9180 registryLookup;

	@Shadow
	@Final
	private class_9383.class_9385 fullRegistryHolder;
	@Unique
	private ICondition.IContext port_lib$context;

	@Override
	public ICondition.IContext port_lib$getConditionContext() {
		if (this.port_lib$context == null) // Need to initialize this when it's queried, otherwise tagManager seems to fail.
		 	this.port_lib$context = new ConditionContext(this.tagManager);

		return this.port_lib$context;
	}


	@Override
	public class_7225.class_7874 port_lib$getRegistryLookup() {
		return this.registryLookup;
	}

	@ModifyArg(method = "method_58296", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/packs/resources/SimpleReloadInstance;create(Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/List;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture;Z)Lnet/minecraft/server/packs/resources/ReloadInstance;"))
	private static List<class_3302> port_lib$invokeOnResourceReload(List<class_3302> listeners, @Local class_5350 resources, @Local(argsOnly = true) class_7780<class_7659> registryAccess) {
		List<class_3302> newListeners = new ArrayList<>(listeners);
		AddReloadListenersEvent event = new AddReloadListenersEvent(resources, registryAccess.method_45926());
		event.sendEvent();

		newListeners.addAll(event.getListeners());

		for (class_3302 listener : newListeners) {
			if (listener instanceof ContextAwareReloadListenerExtension contextAwareReloadListener) {
				contextAwareReloadListener.injectContext(resources.port_lib$getConditionContext(), resources.port_lib$getRegistryLookup());
			}
		}

		return newListeners;
	}

	@Inject(method = "updateRegistryTags()V", at = @At("TAIL"))
	public void port_lib$updateTags(CallbackInfo ci) {
		new TagsUpdatedEvent(this.fullRegistryHolder.method_58289(), false, false).sendEvent();
	}
}
