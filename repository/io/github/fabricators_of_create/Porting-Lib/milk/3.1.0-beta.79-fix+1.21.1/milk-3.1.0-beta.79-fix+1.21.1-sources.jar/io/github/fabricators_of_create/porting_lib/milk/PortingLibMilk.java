package io.github.fabricators_of_create.porting_lib.milk;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.fluids.BaseFlowingFluid;
import io.github.fabricators_of_create.porting_lib.fluids.FluidType;
import io.github.fabricators_of_create.porting_lib.fluids.PortingLibFluids;
import io.github.fabricators_of_create.porting_lib.fluids.sound.SoundActions;
import io.github.fabricators_of_create.porting_lib.milk.client.PortingLibMilkClient;
import io.github.fabricators_of_create.porting_lib.registry.DeferredHolder;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.FullItemFluidStorage;
import net.fabricmc.fabric.mixin.transfer.BucketItemAccessor;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1802;
import net.minecraft.class_1805;
import net.minecraft.class_2378;
import net.minecraft.class_3414;
import net.minecraft.class_3611;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class PortingLibMilk {
	private static boolean enableMilkFluid = false;

	public static final DeferredHolder<class_3414, class_3414> BUCKET_EMPTY_MILK = DeferredHolder.create(class_7924.field_41225, PortingLib.id("item.bucket.empty_milk"));
	public static final DeferredHolder<class_3414, class_3414> BUCKET_FILL_MILK = DeferredHolder.create(class_7924.field_41225, PortingLib.id("item.bucket.fill_milk"));
	public static final DeferredHolder<FluidType, FluidType> MILK_TYPE = DeferredHolder.create(PortingLibFluids.FLUID_TYPE_REGISTRY, PortingLib.id("milk"));
	public static final DeferredHolder<class_3611, class_3611> MILK = DeferredHolder.create(class_7924.field_41270, PortingLib.id("milk"));
	public static final DeferredHolder<class_3611, class_3611> FLOWING_MILK = DeferredHolder.create(class_7924.field_41270, PortingLib.id("flowing_milk"));

	/**
	 * Run this method during mod constructor to enable milk and add it to the Minecraft milk bucket
	 */
	public static void enableMilkFluid() {
		if (!enableMilkFluid) {
			// register milk fill, empty sounds (delegates to water fill, empty sounds)
			class_2378.method_10226(class_7923.field_41172, BUCKET_EMPTY_MILK.getId(), class_3414.method_47908(BUCKET_EMPTY_MILK.getId()));
			class_2378.method_10226(class_7923.field_41172, BUCKET_FILL_MILK.getId(), class_3414.method_47908(BUCKET_FILL_MILK.getId()));

			// register fluid type
			class_2378.method_10226(PortingLibFluids.FLUID_TYPES, MILK_TYPE.unwrapKey().orElseThrow(), new FluidType(
					FluidType.Properties.create().density(1024).viscosity(1024)
							.sound(SoundActions.BUCKET_FILL, BUCKET_FILL_MILK.value())
							.sound(SoundActions.BUCKET_EMPTY, BUCKET_EMPTY_MILK.value()))
			);

			// register fluids
			// set up properties
			BaseFlowingFluid.Properties properties = new BaseFlowingFluid.Properties(MILK_TYPE::value, MILK::value, FLOWING_MILK::value).bucket(() -> Items.MILK_BUCKET);
			class_2378.method_10226(class_7923.field_41173, MILK.getId(), new BaseFlowingFluid.Source(properties));
			class_2378.method_10226(class_7923.field_41173, FLOWING_MILK.getId(), new BaseFlowingFluid.Flowing(properties));

			FluidStorage.GENERAL_COMBINED_PROVIDER.register(context -> {
				if (context.getItemVariant().getItem() instanceof class_1805 bucketItem) {
					class_3611 bucketFluid = MILK.get();

					// Make sure the mapping is bidirectional.
					if (bucketFluid != null && bucketFluid.method_15774() == bucketItem) {
						return new FullItemFluidStorage(context, class_1802.field_8550, FluidVariant.of(bucketFluid), FluidConstants.BUCKET);
					}
				}

				return null;
			});

			if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
				PortingLibMilkClient.init();
			}
		}
		enableMilkFluid = true;
	}
}
