package io.github.fabricators_of_create.porting_lib.milk.data;

import io.github.fabricators_of_create.porting_lib.milk.PortingLibMilk;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalFluidTags;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class MilkTagProvider extends FabricTagProvider.FluidTagProvider {
	public MilkTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
		super(output, completableFuture);
	}

	@Override
	protected void method_10514(class_7225.class_7874 wrapperLookup) {
		getOrCreateTagBuilder(ConventionalFluidTags.MILK).method_35922(PortingLibMilk.MILK.getId()).addOptional(PortingLibMilk.FLOWING_MILK.getId());
	}
}
