package io.github.fabricators_of_create.porting_lib.common.injects;

import net.minecraft.class_2338;
import net.minecraft.class_4538;

public interface LevelReaderInjection {
	default boolean isAreaLoaded(class_2338 center, int range) {
		return ((class_4538)this).method_22343(center.method_10069(-range, -range, -range), center.method_10069(range, range, range));
	}
}
