package io.github.fabricators_of_create.porting_lib.common.util;

import javax.annotation.Nonnull;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_6862;
import java.util.function.Supplier;

/**
 * Helper class to define a custom tier
 */
public final class SimpleTier implements class_1832 {
	private final class_6862<class_2248> incorrectBlocksForDrops;
	private final int uses;
	private final float speed;
	private final float attackDamageBonus;
	private final int enchantmentValue;
	@Nonnull
	private final class_6862<class_2248> tag;
	@Nonnull
	private final Supplier<class_1856> repairIngredient;

	public SimpleTier(class_6862<class_2248> incorrectBlocksForDrops, int uses, float speed, float attackDamageBonus, int enchantmentValue,
					  @Nonnull class_6862<class_2248> tag, @Nonnull Supplier<class_1856> repairIngredient) {
		this.incorrectBlocksForDrops = incorrectBlocksForDrops;
		this.uses = uses;
		this.speed = speed;
		this.attackDamageBonus = attackDamageBonus;
		this.enchantmentValue = enchantmentValue;
		this.tag = tag;
		this.repairIngredient = repairIngredient;
	}

	@Override
	public int method_8025() {
		return this.uses;
	}

	@Override
	public float method_8027() {
		return this.speed;
	}

	@Override
	public float method_8028() {
		return this.attackDamageBonus;
	}

	@Override
	public class_6862<class_2248> method_58419() {
		return this.incorrectBlocksForDrops;
	}

	@Override
	public int method_8026() {
		return this.enchantmentValue;
	}

	@Nonnull
	public class_6862<class_2248> getTag() {
		return this.tag;
	}

	@Nonnull
	@Override
	public class_1856 method_8023() {
		return this.repairIngredient.get();
	}

	@Override
	public String toString() {
		return "SimpleTier[" +
				"incorrectBlocksForDrops=" + incorrectBlocksForDrops + ", " +
				"uses=" + uses + ", " +
				"speed=" + speed + ", " +
				"attackDamageBonus=" + attackDamageBonus + ", " +
				"enchantmentValue=" + enchantmentValue + ", " +
				"tag=" + tag + ", " +
				"repairIngredient=" + repairIngredient + ']';
	}
}
