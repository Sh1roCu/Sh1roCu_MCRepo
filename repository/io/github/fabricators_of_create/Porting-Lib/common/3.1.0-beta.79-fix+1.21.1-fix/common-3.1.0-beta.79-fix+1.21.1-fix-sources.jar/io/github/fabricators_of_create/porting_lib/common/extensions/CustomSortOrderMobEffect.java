package io.github.fabricators_of_create.porting_lib.common.extensions;

import net.minecraft.class_1291;
import net.minecraft.class_1293;

public interface CustomSortOrderMobEffect {
	/**
	 * Used for determining {@link class_1291} sort order in GUIs.
	 * Defaults to the {@link class_1291}'s liquid color.
	 *
	 * @param effectInstance the {@link class_1293} containing this {@link class_1291}
	 * @return a value used to sort {@link class_1291}s in GUIs
	 */
	default int getSortOrder(class_1293 effectInstance) {
		return ((class_1291) this).method_5556();
	}
}
