package io.github.fabricators_of_create.porting_lib.common.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.common.extensions.CustomSortOrderMobEffect;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1293.class)
public class MobEffectInstanceMixin {
	@WrapOperation(method = "compareTo(Lnet/minecraft/world/effect/MobEffectInstance;)I", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/effect/MobEffect;getColor()I", ordinal = 0))
	private int getSortOrder1(class_1291 instance, Operation<Integer> original) {
		if (instance instanceof CustomSortOrderMobEffect custom)
			return custom.getSortOrder((class_1293) (Object) this);
		return original.call(instance);
	}

	@WrapOperation(method = "compareTo(Lnet/minecraft/world/effect/MobEffectInstance;)I", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/effect/MobEffect;getColor()I", ordinal = 2))
	private int getSortOrder2(class_1291 instance, Operation<Integer> original) {
		if (instance instanceof CustomSortOrderMobEffect custom)
			return custom.getSortOrder((class_1293) (Object) this);
		return original.call(instance);
	}

	@WrapOperation(method = "compareTo(Lnet/minecraft/world/effect/MobEffectInstance;)I", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/effect/MobEffect;getColor()I", ordinal = 1))
	private int getSortOrder1(class_1291 instance, Operation<Integer> original, class_1293 other) {
		if (other.method_5579().comp_349() instanceof CustomSortOrderMobEffect custom)
			return custom.getSortOrder(other);
		return original.call(instance);
	}

	@WrapOperation(method = "compareTo(Lnet/minecraft/world/effect/MobEffectInstance;)I", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/effect/MobEffect;getColor()I", ordinal = 3))
	private int getSortOrder2(class_1291 instance, Operation<Integer> original, class_1293 other) {
		if (other.method_5579().comp_349() instanceof CustomSortOrderMobEffect custom)
			return custom.getSortOrder(other);
		return original.call(instance);
	}
}
