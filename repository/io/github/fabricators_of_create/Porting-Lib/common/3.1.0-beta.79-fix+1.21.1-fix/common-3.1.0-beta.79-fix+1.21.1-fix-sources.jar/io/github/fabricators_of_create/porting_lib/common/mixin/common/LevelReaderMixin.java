package io.github.fabricators_of_create.porting_lib.common.mixin.common;

import io.github.fabricators_of_create.porting_lib.common.injects.LevelReaderInjection;
import net.minecraft.class_4538;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_4538.class)
public interface LevelReaderMixin extends LevelReaderInjection {
}
