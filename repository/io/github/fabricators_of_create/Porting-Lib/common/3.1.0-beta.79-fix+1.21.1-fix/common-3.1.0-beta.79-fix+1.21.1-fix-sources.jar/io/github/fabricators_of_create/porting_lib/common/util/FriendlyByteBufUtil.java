package io.github.fabricators_of_create.porting_lib.common.util;

import io.netty.buffer.Unpooled;
import java.util.function.Consumer;
import net.minecraft.class_2540;
import net.minecraft.class_5455;
import net.minecraft.class_9129;

/**
 * Utility class for working with {@link class_2540}s.
 */
public class FriendlyByteBufUtil {
	private FriendlyByteBufUtil() {
		throw new IllegalStateException("Tried to create utility class!");
	}

	/**
	 * Writes custom data to a {@link class_9129}, then returns the written data as a byte array.
	 *
	 * @param dataWriter     The data writer.
	 * @param registryAccess The registry access used by registry dependent writers on the buffer
	 * @return The written data.
	 */
	public static byte[] writeCustomData(Consumer<class_9129> dataWriter, class_5455 registryAccess) {
		final class_9129 buf = new class_9129(Unpooled.buffer(), registryAccess);
		try {
			dataWriter.accept(buf);
			return buf.array();
		} finally {
			buf.release();
		}
	}
}
