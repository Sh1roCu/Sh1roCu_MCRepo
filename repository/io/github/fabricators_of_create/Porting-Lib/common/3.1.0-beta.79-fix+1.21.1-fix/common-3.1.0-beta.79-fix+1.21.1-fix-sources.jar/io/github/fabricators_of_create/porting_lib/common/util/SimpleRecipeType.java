package io.github.fabricators_of_create.porting_lib.common.util;

import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_3956;

public record SimpleRecipeType<T extends class_1860<?>>(class_2960 name) implements class_3956<T> {
	@Override
	public String toString() {
		return name.toString();
	}
}
