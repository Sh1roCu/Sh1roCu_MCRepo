package io.github.fabricators_of_create.porting_lib.transfer.mixin.common;

import io.github.fabricators_of_create.porting_lib.transfer.internal.extensions.LevelExtensions;
import io.github.fabricators_of_create.porting_lib.transfer.internal.cache.EmptyFluidLookupCache;
import io.github.fabricators_of_create.porting_lib.transfer.internal.cache.EmptyItemLookupCache;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiCache;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1937.class)
public abstract class LevelMixin implements LevelExtensions {
	@Override
	public BlockApiCache<Storage<ItemVariant>, class_2350> port_lib$getItemCache(class_2338 pos) {
		// uh oh. Not a ClientLevel or ServerLevel!
		return new EmptyItemLookupCache(pos);
	}

	@Override
	public BlockApiCache<Storage<FluidVariant>, class_2350> port_lib$getFluidApiCache(class_2338 pos) {
		// uh oh. Not a ClientLevel or ServerLevel!
		return new EmptyFluidLookupCache(pos);
	}
}
