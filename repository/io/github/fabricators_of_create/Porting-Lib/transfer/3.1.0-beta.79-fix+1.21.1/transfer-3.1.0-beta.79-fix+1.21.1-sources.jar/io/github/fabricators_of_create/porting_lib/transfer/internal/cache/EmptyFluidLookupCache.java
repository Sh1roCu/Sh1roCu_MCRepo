package io.github.fabricators_of_create.porting_lib.transfer.internal.cache;

import io.github.fabricators_of_create.porting_lib.util.StorageProvider;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;

import org.jetbrains.annotations.ApiStatus.Internal;
import org.jetbrains.annotations.Nullable;

import net.fabricmc.fabric.api.lookup.v1.block.BlockApiCache;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiLookup;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/**
 * This should not be used directly. Use {@link StorageProvider} instead.
 */
@Internal
@SuppressWarnings("NonExtendableApiUsage")
public record EmptyFluidLookupCache(class_2338 pos) implements BlockApiCache<Storage<FluidVariant>, class_2350> {
	@Override
	@Nullable
	public Storage<FluidVariant> find(@Nullable class_2680 state, class_2350 context) {
		return null;
	}

	@Override
	@Nullable
	public class_2586 getBlockEntity() {
		return null;
	}

	@Override
	public BlockApiLookup<Storage<FluidVariant>, class_2350> getLookup() {
		return FluidStorage.SIDED;
	}

	@Override
	public class_3218 getWorld() {
		throw new UnsupportedOperationException("Cannot call getWorld on an empty cache as no world is associated with it");
	}

	@Override
	public class_2338 getPos() {
		return pos;
	}
}
