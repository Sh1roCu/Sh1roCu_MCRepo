package io.github.fabricators_of_create.porting_lib.transfer.internal.extensions;

import io.github.fabricators_of_create.porting_lib.transfer.internal.cache.ClientBlockApiCache;
import net.minecraft.class_2338;
import org.jetbrains.annotations.ApiStatus.Internal;

@Internal
public interface ClientLevelExtensions {
	default void port_lib$registerCache(class_2338 pos, ClientBlockApiCache cache) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default void port_lib$invalidateCache(class_2338 pos) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}
