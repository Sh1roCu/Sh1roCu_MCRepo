package io.github.fabricators_of_create.porting_lib.transfer.item;

import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.item.PlayerInventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import javax.annotation.Nonnull;

public class ItemHandlerHelper {
	/**
	 * giveItemToPlayer without preferred slot
	 */
	public static void giveItemToPlayer(class_1657 player, @Nonnull class_1799 stack) {
		try (Transaction tx = TransferUtil.getTransaction()) {
			PlayerInventoryStorage.of(player).offerOrDrop(ItemVariant.of(stack.method_7909()), stack.method_7947(), tx);
			tx.commit();
		}
	}

	/**
	 * Inserts the given itemstack into the players inventory.
	 * If the inventory can't hold it, the item will be dropped in the world at the players position.
	 * Different from {@link net.fabricmc.fabric.api.transfer.v1.item.PlayerInventoryStorage#offerOrDrop(ItemVariant, long, TransactionContext)} by allowing to insert into a specific slot
	 * and also plays a sound.
	 *
	 * @param player The player to give the item to
	 * @param stack  The itemstack to insert
	 */
	public static void giveItemToPlayer(class_1657 player, @Nonnull class_1799 stack, int preferredSlot) {
		if (stack.method_7960()) return;

		PlayerInventoryStorage inventory = PlayerInventoryStorage.of(player.method_31548());
		class_1937 world = player.method_37908();

		// try adding it into the inventory
		long remainder = stack.method_7947();
		// insert into preferred slot first
		if (preferredSlot >= 0 && preferredSlot < inventory.getSlotCount()) {
			remainder -= TransferUtil.insertItem(inventory.getSlot(preferredSlot), stack);
		}
		// then into the inventory in general
		if (remainder > 0) {
			try (Transaction tx = TransferUtil.getTransaction()) {
				// This doesn't play the item pickup sound but who really cares
				remainder -= inventory.offer(ItemVariant.of(stack), remainder, tx);
				tx.commit();
			}
		}

		// play sound if something got picked up
		if (remainder <= 0 || remainder != stack.method_7947()) {
			world.method_43128(null, player.method_23317(), player.method_23318() + 0.5, player.method_23321(),
					class_3417.field_15197, class_3419.field_15248, 0.2F, ((world.field_9229.method_43057() - world.field_9229.method_43057()) * 0.7F + 1.0F) * 2.0F);
		}

		// drop remaining itemstack into the world
		if (remainder > 0 && !world.field_9236) {
			class_1542 entityitem = new class_1542(world, player.method_23317(), player.method_23318() + 0.5, player.method_23321(), stack.method_46651((int) remainder));
			entityitem.method_6982(40);
			entityitem.method_18799(entityitem.method_18798().method_18805(0, 1, 0));

			world.method_8649(entityitem);
		}
	}
}
