package io.github.fabricators_of_create.porting_lib.transfer.item;

import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import org.jetbrains.annotations.NotNull;
import java.util.Set;

/**
 * An {@link ItemStackHandler} that is also a {@link class_1263}.
 */
public class ItemStackHandlerContainer extends ItemStackHandler implements class_1263 {

	public ItemStackHandlerContainer() {
		super(1);
	}

	public ItemStackHandlerContainer(int stacks) {
		super(stacks);
	}

	public ItemStackHandlerContainer(class_1799[] stacks) {
		super(stacks);
	}

	@Override
	public int method_5439() {
		return getSlotCount();
	}

	@Override
	public boolean method_5442() {
		return super.empty();
	}

	@Override
	@NotNull
	public class_1799 method_5438(int slot) {
		if (indexInvalid(slot))
			return class_1799.field_8037;
		return getStackInSlot(slot);
	}

	@Override
	@NotNull
	public class_1799 method_5434(int index, int amount) {
		if (indexInvalid(index))
			return class_1799.field_8037;
		ItemStackHandlerSlot slot = getSlot(index);
		class_1799 stack = slot.getStack();
		if (stack.method_7960())
			return class_1799.field_8037;

		int count = stack.method_7947();
		int toRemove = Math.min(amount, count);
		int remaining = count - toRemove;
		class_1799 removed = stack.method_46651(toRemove);
		class_1799 remainder = remaining <= 0 ? class_1799.field_8037 : stack.method_46651(remaining);
		slot.setNewStack(remainder);
		return removed;
	}

	@Override
	@NotNull
	public class_1799 method_5441(int index) {
		if (indexInvalid(index))
			return class_1799.field_8037;
		ItemStackHandlerSlot slot = getSlot(index);
		class_1799 stack = slot.getStack();
		slot.setNewStack(class_1799.field_8037);
		return stack;
	}

	@Override
	public void method_5447(int slot, @NotNull class_1799 stack) {
		if (indexInvalid(slot))
			return;
		setStackInSlot(slot, stack);
	}

	@Override
	public void method_5431() {
	}

	@Override
	public boolean method_5443(@NotNull class_1657 player) {
		return false;
	}

	@Override
	public boolean method_5437(int index, @NotNull class_1799 stack) {
		if (indexInvalid(index))
			return false;
		return isItemValid(index, ItemVariant.of(stack), stack.method_7947());
	}

	@Override
	public int method_18861(@NotNull class_1792 item) {
		int total = 0;
		for (ItemStackHandlerSlot slot : getSlotsContaining(item)) {
			total += slot.getStack().method_7947();
		}
		return total;
	}

	@Override
	public boolean method_18862(Set<class_1792> set) {
		for (class_1792 item : set) {
			if (!getSlotsContaining(item).isEmpty())
				return true;
		}
		return false;
	}

	@Override
	public void method_5448() {
		for (int i = 0; i < getSlotCount(); i++) {
			setStackInSlot(i, class_1799.field_8037);
		}
	}

	public boolean indexInvalid(int slot) {
		return slot < 0 || slot >= getSlotCount();
	}
}
