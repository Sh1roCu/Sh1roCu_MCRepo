package io.github.fabricators_of_create.porting_lib.transfer.mixin.common;

import io.github.fabricators_of_create.porting_lib.transfer.internal.extensions.LevelExtensions;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiCache;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_3218.class)
public class ServerLevelMixin implements LevelExtensions {
	@Override
	public BlockApiCache<Storage<ItemVariant>, class_2350> port_lib$getItemCache(class_2338 pos) {
		return BlockApiCache.create(ItemStorage.SIDED, ((class_3218) (Object) this), pos);
	}

	@Override
	public BlockApiCache<Storage<FluidVariant>, class_2350> port_lib$getFluidApiCache(class_2338 pos) {
		return BlockApiCache.create(FluidStorage.SIDED, ((class_3218) (Object) this), pos);
	}
}
