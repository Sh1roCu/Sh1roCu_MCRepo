package io.github.fabricators_of_create.porting_lib.transfer.item;

import org.jetbrains.annotations.NotNull;

import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.SlottedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class SlotItemHandler extends class_1735 {
	private static final class_1263 emptyInventory = new class_1277(0);
	private final SlottedStorage<ItemVariant> storage;
	private final int index;

	public SlotItemHandler(SlottedStackStorage storage, int index, int xPosition, int yPosition) {
		super(emptyInventory, index, xPosition, yPosition);
		this.storage = storage;
		this.field_7874 = index;
	}

	public SlotItemHandler(SlottedStorage<ItemVariant> storage, int index, int xPosition, int yPosition) {
		super(emptyInventory, index, xPosition, yPosition);
		this.storage = storage;
		this.field_7874 = index;
	}

	@Override
	public boolean method_7680(class_1799 stack) {
		if (stack.method_7960())
			return false;
		if (storage instanceof SlottedStackStorage slottedStorage)
			return slottedStorage.isItemValid(field_7874, ItemVariant.of(stack), stack.method_7947());
		return true;
	}

	@Override
	@NotNull
	public class_1799 method_7677() {
		if (storage instanceof SlottedStackStorage slottedStorage)
			return slottedStorage.getStackInSlot(field_7874);
		var slot = storage.getSlot(field_7874);
		return slot.getResource().toStack((int) slot.getAmount());
	}

	// Override if your IItemHandler does not implement IItemHandlerModifiable
	@Override
	public void method_7673(@NotNull class_1799 stack) {
		if (storage instanceof SlottedStackStorage slottedStorage)
			slottedStorage.setStackInSlot(field_7874, stack);
		else {
			var slot = storage.getSlot(field_7874);
			if (!slot.isResourceBlank()) {
				try (Transaction t = TransferUtil.getTransaction()) {
					slot.extract(slot.getResource(), slot.getAmount(), t);
					t.commit();
				}
			}
			var variant = ItemVariant.of(stack);
			if (!variant.isBlank()) {
				try (Transaction t = TransferUtil.getTransaction()) {
					slot.insert(variant, stack.method_7947(), t);
					t.commit();
				}
			}
		}
		this.method_7668();
	}

	@Override
	public void method_7670(@NotNull class_1799 oldStackIn, @NotNull class_1799 newStackIn) {
	}

	@Override
	public int method_7675() {
		if (storage instanceof SlottedStackStorage slottedStorage)
			return slottedStorage.getSlotLimit(this.field_7874);
		return (int) storage.getSlot(field_7874).getCapacity();
	}

	@Override
	public int method_7676(@NotNull class_1799 stack) {
		if (storage instanceof SlottedStackStorage slottedStorage)
			return slottedStorage.getSlotLimit(field_7874);
		return (int) storage.getSlot(field_7874).getCapacity();
	}

	@Override
	public boolean method_7674(@NotNull class_1657 playerIn) {
		if (storage instanceof SlottedStackStorage slottedStorage)
			return !slottedStorage.getStackInSlot(field_7874).method_7960();
		return !storage.getSlot(field_7874).isResourceBlank();
	}

	@Override
	@NotNull
	public class_1799 method_7671(int amount) {
		if (storage instanceof SlottedStackStorage slottedStorage) {
			class_1799 held = slottedStorage.getStackInSlot(field_7874).method_7972();
			class_1799 removed = held.method_7971(amount);
			slottedStorage.setStackInSlot(field_7874, held);
			return removed;
		}
		try (Transaction t = TransferUtil.getTransaction()) {
			var slot = storage.getSlot(field_7874);
			class_1799 lastResource = slot.getResource().toStack();
			long extraced = slot.extract(slot.getResource(), amount, t);
			t.commit();
			return lastResource.method_46651((int) extraced);
		}
	}

	public SlottedStorage<ItemVariant> getItemHandler() {
		return storage;
	}
}
