package io.github.fabricators_of_create.porting_lib.transfer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;

import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.storage.StoragePreconditions;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageUtil;

import net.fabricmc.fabric.api.transfer.v1.storage.TransferVariant;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.item.PlayerInventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.storage.base.ResourceAmount;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext;
import net.minecraft.class_128;
import net.minecraft.class_148;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

/**
 * Utilities for transferring things.
 * All Storage-modifying helpers use {@link TransferUtil#getTransaction()} to
 * create Transactions, and they automatically commit.
 * This means that in order to simulate these actions, they must be wrapped as so:<pre>{@code
 *  try (Transaction t = Transaction.openOuter()) {
 * 		boolean result = TransferUtil.clearStorage(storage);
 * 		t.abort();
 * 		if (result) {
 * 		 	...
 * 		}
 * 	}
 * }</pre>
 */
@SuppressWarnings({"removal", "unused"})
public class TransferUtil {
	/**
	 * @return Either an outer transaction or a nested one in the current open one
	 */
	public static Transaction getTransaction() {
		if (Transaction.isOpen()) {
			//noinspection deprecation
			TransactionContext open = Transaction.getCurrentUnsafe();
			if (open != null) {
				return open.openNested();
			}
		}
		return Transaction.openOuter();
	}

	// Item Storage getting

	@Nullable
	public static Storage<ItemVariant> getItemStorage(class_1937 level, class_2338 pos, @Nullable class_2350 side) {
		return getItemStorage(level, pos, null, side);
	}

	@Nullable
	public static Storage<ItemVariant> getItemStorage(class_1937 level, class_2338 pos) {
		return getItemStorage(level, pos, null);
	}

	/**
	 * Be careful with this method. Don't forget that non-BEs can also hold storages.
	 */
	@Nullable
	public static Storage<ItemVariant> getItemStorage(class_2586 be, @Nullable class_2350 side) {
		return getItemStorage(null, null, be, side);
	}

	/**
	 * Be careful with this method. Don't forget that non-BEs can also hold storages.
	 */
	@Nullable
	public static Storage<ItemVariant> getItemStorage(class_2586 be) {
		return getItemStorage(be, null);
	}

	/**
	 * Using the provided Level and BlockPos OR BlockEntity, find a Storage containing ItemVariants.
	 * Prefer {@link TransferUtil#getItemStorage(class_1937, class_2338, class_2350)} variant generally.
	 * @param level the Level to check in - may be client only, despite what regular FAPI allows. Null is allowed as long as 'be' is NOT null.
	 * @param pos the position to check. Null is allowed as long as 'be' is NOT null.
	 * @param be the Block Entity to check. Null is allowed as long as 'level' and 'pos' are NOT null.
	 * @param side the Direction to check in - null is considered all sides and will return a wrapper around all found.
	 * @see TransferUtil#getItemStorage(class_1937, class_2338, class_2350)
	 * @return a Storage of ItemVariants, or null if none found.
	 */
	@Nullable
	public static Storage<ItemVariant> getItemStorage(class_1937 level, class_2338 pos, class_2586 be, @Nullable class_2350 side) {
		if (be == null) {
			Objects.requireNonNull(level, "If a null Block Entity is provided, the Level may NOT be null!");
			Objects.requireNonNull(pos, "If a null Block Entity is provided, the pos may NOT be null!");
			be = level.method_8321(pos);
		}
		if (level == null || pos == null) {
			Objects.requireNonNull(be, "If a null level or pos is provided, the Block Entity may NOT be null!");
			level = be.method_10997();
			pos = be.method_11016();
		}
		if (level == null)
			return null;
		class_2680 state = be == null ? level.method_8320(pos) : be.method_11010();

		return ItemStorage.SIDED.find(level, pos, state, be, side);
	}

	// Fluid storage getting

	@Nullable
	public static Storage<FluidVariant> getFluidStorage(class_1937 level, class_2338 pos, @Nullable class_2350 side) {
		return getFluidStorage(level, pos, null, side);
	}

	@Nullable
	public static Storage<FluidVariant> getFluidStorage(class_1937 level, class_2338 pos) {
		return getFluidStorage(level, pos, null);
	}


	/**
	 * Be careful with this method. Don't forget that non-BEs can also hold storages.
	 */
	@Nullable
	public static Storage<FluidVariant> getFluidStorage(class_2586 be, @Nullable class_2350 side) {
		return getFluidStorage(null, null, be, side);
	}

	/**
	 * Be careful with this method. Don't forget that non-BEs can also hold storages.
	 */
	@Nullable
	public static Storage<FluidVariant> getFluidStorage(class_2586 be) {
		return getFluidStorage(be, null);
	}

	/**
	 * Using the provided Level and BlockPos OR BlockEntity, find a Storage containing FluidVariants.
	 * Prefer {@link TransferUtil#getFluidStorage(class_1937, class_2338, class_2350)} variant generally.
	 * @param level the Level to check in - may be client only, despite what regular FAPI allows. Null is allowed as long as 'be' is NOT null.
	 * @param pos the position to check. Null is allowed as long as 'be' is NOT null.
	 * @param be the Block Entity to check. Null is allowed as long as 'level' and 'pos' are NOT null.
	 * @param side the Direction to check in - null is considered all sides and will return a wrapper around all found.
	 * @see TransferUtil#getFluidStorage(class_1937, class_2338, class_2350)
	 * @return a Storage of FluidVariants, or null if none found.
	 */
	@Nullable
	public static Storage<FluidVariant> getFluidStorage(class_1937 level, class_2338 pos, class_2586 be, @Nullable class_2350 side) {
		if (be == null) {
			Objects.requireNonNull(level, "If a null Block Entity is provided, the Level may NOT be null!");
			Objects.requireNonNull(pos, "If a null Block Entity is provided, the pos may NOT be null!");
			be = level.method_8321(pos);
		}
		if (level == null || pos == null) {
			Objects.requireNonNull(be, "If a null level or pos is provided, the Block Entity may NOT be null!");
			level = be.method_10997();
			pos = be.method_11016();
		}
		if (level == null)
			return null;
		class_2680 state = be == null ? level.method_8320(pos) : be.method_11010();
		return FluidStorage.SIDED.find(level, pos, state, be, side);
	}

	// misc utils below

	/**
	 * Find A Storage of the given Class using the given BlockEntity and Direction.
	 * @param be the BlockEntity to check
	 * @param side the Direction to check
	 * @param capability either ItemVariant.class or FluidVariant.class
	 * @param <T> either ItemVariant or FluidVariant, corresponding to the provided Class.
	 * @return the found storage, or null if none available.
	 */
	@Nullable
	@SuppressWarnings("unchecked")
	public static <T> Storage<T> getStorage(class_2586 be, @Nullable class_2350 side, Class<T> capability) {
		if (capability == ItemVariant.class) {
			return (Storage<T>) getItemStorage(null, null, be, side);
		} else if (capability == FluidVariant.class) {
			return (Storage<T>) getFluidStorage(null, null, be, side);
		} else {
			throw new RuntimeException("Class must either be ItemVariant or FluidVariant!");
		}
	}

	/**
	 * @return an Optional of a FluidStack containing the first fluid found in the supplied item, or Optional.empty() if none.
	 */
	public static Optional<FluidStack> getFluidContained(class_1799 container) {
		if (container != null && !container.method_7960()) {
			Storage<FluidVariant> storage = ContainerItemContext.withConstant(container).find(FluidStorage.ITEM);
			if (storage != null) {
				FluidStack first = getFirstFluid(storage);
				if (first != null) return Optional.of(first);
			}
		}
		return Optional.empty();
	}

	/**
	 * @return the capacity of the first StorageView of the storage
	 */
	public static <T> long firstCapacity(Storage<T> storage) {
		List<Long> capacities = capacities(storage, 1);
		return capacities.size() > 0 ? capacities.get(0) : 0;
	}

	/**
	 * @return the capacities of all StorageViews of the storage added together.
	 */
	public static <T> long totalCapacity(Storage<T> storage) {
		long total = 0;
		List<Long> capacities = capacities(storage, Integer.MAX_VALUE);
		for (Long l : capacities) total += l;
		return total;
	}

	/**
	 * Finds the capacities of each StorageView in the storage.
	 * @param cutoff number of capacities to find before exiting early
	 */
	public static <T> List<Long> capacities(Storage<T> storage, int cutoff) {
		List<Long> capacities = new ArrayList<>();
		try (Transaction t = getTransaction()) {
			for (StorageView<T> view : storage) {
				capacities.add(view.getCapacity());
				if (capacities.size() == cutoff)
					break;
			}
		}
		return capacities;
	}

	/** @return a copy of the first FluidStack found, or EMPTY if none */
	public static FluidStack firstCopyOrEmpty(Storage<FluidVariant> storage) {
		return firstOrEmpty(storage).copy();
	}

	/** @return the first FluidStack found, or EMPTY if none */
	public static FluidStack firstOrEmpty(Storage<FluidVariant> storage) {
		FluidStack stack = getFirstFluid(storage);
		return stack == null ? FluidStack.EMPTY : stack;
	}

	/** @return the first FluidStack found, or null if none */
	@Nullable
	public static FluidStack getFirstFluid(Storage<FluidVariant> storage) {
		List<FluidStack> stacks = getFluids(storage, 1);
		if (stacks.size() > 0) return stacks.get(0);
		return null;
	}

	/** @see TransferUtil#getFluids(Storage, int) */
	public static List<FluidStack> getAllFluids(Storage<FluidVariant> storage) {
		return getFluids(storage, Integer.MAX_VALUE);
	}

	/**
	 * Find all fluids inside a storage, until the cutoff is hit. One FluidStack for each non-empty StorageView.
	 * @param cutoff number of fluids to find before exiting early
	 */
	public static List<FluidStack> getFluids(Storage<FluidVariant> storage, int cutoff) {
		List<FluidStack> stacks = new ArrayList<>();
		try (Transaction t = getTransaction()) {
			for (StorageView<FluidVariant> view : storage.nonEmptyViews()) {
				stacks.add(new FluidStack(view));
				if (stacks.size() == cutoff) {
					break;
				}
			}
		}
		return stacks;
	}

	/** @see TransferUtil#getItems(Storage, int) */
	public static List<class_1799> getAllItems(Storage<ItemVariant> storage) {
		return getItems(storage, Integer.MAX_VALUE);
	}

	/**
	 * Find all ItemStacks within a Storage. There is no guarantee a single StorageView holds a single ItemStack.
	 * For example, if a single StorageView holds 128 dirt blocks, that will be converted into two ItemStacks of 64.
	 * @return a list of all ItemStacks found
	 */
	public static List<class_1799> getItems(Storage<ItemVariant> storage, int cutoff) {
		List<class_1799> stacks = new ArrayList<>();
		try (Transaction t = getTransaction()) {
			for (StorageView<ItemVariant> view : storage.nonEmptyViews()) {
				long contained = view.getAmount();
				ItemVariant item = view.getResource();
				int maxSize = item.getItem().method_7882();
				while (contained > 0 && stacks.size() < cutoff) {
					int stackSize = Math.min(maxSize, (int) contained);
					contained -= stackSize;
					stacks.add(item.toStack(stackSize));
				}
				if (stacks.size() == cutoff) {
					break;
				}
			}
		}
		return stacks;
	}

	/**
	 * Remove as much as possible from a Storage.
	 * @return true if all removed
	 */
	public static <T> boolean clearStorage(Storage<T> storage) {
		if (!storage.supportsExtraction()) {
			return false;
		}
		boolean success = true;
		try (Transaction t = getTransaction()) {
			for (StorageView<T> view : storage.nonEmptyViews()) {
				long amount = view.getAmount();
				long extracted = view.extract(view.getResource(), amount, t);
				if (extracted < amount)
					success = false;
			}
			t.commit();
		}
		return success;
	}

	/**
	 * Try to extract any FluidStack possible from a Storage.
	 * @return the extracted FluidStack, or EMPTY if none.
	 */
	public static FluidStack extractAnyFluid(Storage<FluidVariant> storage, long maxAmount, Transaction tx) {
		if (!storage.supportsExtraction())
			return FluidStack.EMPTY;
		ResourceAmount<FluidVariant> extracted = StorageUtil.extractAny(storage, maxAmount, tx);
		return extracted == null ? FluidStack.EMPTY : new FluidStack(extracted);
	}

	/**
	 * Try to extract any FluidStack possible from a Storage.
	 * @return the extracted FluidStack, or EMPTY if none.
	 */
	public static FluidStack extractAnyFluid(Storage<FluidVariant> storage, long maxAmount) {
		try (Transaction tx = getTransaction()) {
			FluidStack fluid = extractAnyFluid(storage, maxAmount, tx);
			tx.commit();
			return fluid;
		}
	}

	/**
	 * Try to extract any FluidStack possible from a Storage without affecting the actual storage contents.
	 * @return the extracted FluidStack, or EMPTY if none.
	 */
	public static FluidStack simulateExtractAnyFluid(Storage<FluidVariant> storage, long maxAmount) {
		try (Transaction t = getTransaction()) {
			return extractAnyFluid(storage, maxAmount, t);
		}
	}

	/** @see TransferUtil#extractAnyFluid(Storage, long) */
	public static class_1799 extractAnyItem(Storage<ItemVariant> storage, long maxAmount, Transaction tx) {
		if (!storage.supportsExtraction())
			return class_1799.field_8037;
		int max = (int) Math.min(Integer.MAX_VALUE, maxAmount);
		ResourceAmount<ItemVariant> extracted = StorageUtil.extractAny(storage, max, tx);
		return extracted == null ? class_1799.field_8037 : extracted.resource().toStack((int) extracted.amount());
	}

	/** @see TransferUtil#extractAnyFluid(Storage, long) */
	public static class_1799 extractAnyItem(Storage<ItemVariant> storage, long maxAmount) {
		try (Transaction tx = getTransaction()) {
			class_1799 stack = extractAnyItem(storage, maxAmount, tx);
			tx.commit();
			return stack;
		}
	}

	/** @see TransferUtil#simulateExtractAnyFluid(Storage, long) (Storage, long) */
	public static class_1799 simulateExtractAnyItem(Storage<ItemVariant> storage, long maxAmount) {
		try (Transaction tx = getTransaction()) {
			return extractAnyItem(storage, maxAmount, tx);
		}
	}

	/** Less clunky way of simulating extraction on a {@link StorageView<T>} */
	public static <T> long simulateExtractView(@NotNull StorageView<T> view, T variant, long amount) {
		try (Transaction t = getTransaction()) {
			return view.extract(variant, amount, t);
		}
	}

	/** Quickly extract and commit the given variant with the given amount. */
	public static <T> long extract(Storage<T> storage, T variant, long amount) {
		if (!storage.supportsExtraction()) return 0;
		try (Transaction t = getTransaction()) {
			long extracted = storage.extract(variant, amount, t);
			t.commit();
			return extracted;
		}
	}

	/** Quickly extract and commit the given ItemStack. */
	public static long extractItem(Storage<ItemVariant> storage, class_1799 stack) {
		return extract(storage, ItemVariant.of(stack), stack.method_7947());
	}

	/** Quickly extract and commit the given ItemStack. */
	public static long extractFluid(Storage<FluidVariant> storage, FluidStack stack) {
		return extract(storage, stack.getVariant(), stack.getAmount());
	}

	/** Quickly insert and commit the given variant with the given amount. */
	public static <T> long insert(Storage<T> storage, T variant, long amount) {
		if (!storage.supportsInsertion()) return 0;
		try (Transaction t = getTransaction()) {
			long inserted = storage.insert(variant, amount, t);
			t.commit();
			return inserted;
		}
	}

	/** Quickly insert and commit the given ItemStack. */
	public static long insertItem(Storage<ItemVariant> storage, class_1799 stack) {
		return insert(storage, ItemVariant.of(stack), stack.method_7947());
	}

	/** Quickly insert and commit the given FluidStack. */
	public static long insertFluid(Storage<FluidVariant> storage, FluidStack stack) {
		return insert(storage, stack.getVariant(), stack.getAmount());
	}

	/** Insert the given variant and amount into the given Player's inventory, excluding the hotbar, offhand, and armor. */
	public static long insertToMainInv(class_1657 player, ItemVariant variant, long amount) {
		long inserted = 0;
		try (Transaction t = getTransaction()) {
			PlayerInventoryStorage inv = PlayerInventoryStorage.of(player);
			if (!inv.supportsInsertion()) return 0;
			List<SingleSlotStorage<ItemVariant>> slots = inv.getSlots();
			for (int i = 9; i < class_1661.field_30638; i++) { // start at 9 and skip hotbar, end before armor and offhand
				SingleSlotStorage<ItemVariant> slot = slots.get(i);
				inserted += slot.insert(variant, amount - inserted, t);
				if (amount == 0) break;
			}
			t.commit();
			return inserted;
		}
	}

	/**
	 * Extract all contents of the Storage as ItemStacks.
	 * Follows the same logic as {@link TransferUtil#getItems(Storage, int) }
	 */
	public static List<class_1799> extractAllAsStacks(Storage<ItemVariant> storage) {
		List<class_1799> stacks = new ArrayList<>();
		if (!storage.supportsExtraction()) return stacks;
		try (Transaction t = getTransaction()) {
			Iterator<? extends StorageView<ItemVariant>> itr = storage.nonEmptyIterator();
			StorageView<ItemVariant> currentView = itr.hasNext() ? itr.next() : null;
			while (currentView != null) {
				long contained = currentView.getAmount();
				if (contained == 0) {
					currentView = itr.hasNext() ? itr.next() : null;
					continue;
				}
				ItemVariant variant = currentView.getResource();
				int max = (int) Math.min(contained, variant.getItem().method_7882());
				long extracted = currentView.extract(variant, max, t);
				if (extracted == 0) {
					currentView = itr.hasNext() ? itr.next() : null;
					continue;
				}
				class_1799 stack = variant.toStack((int) extracted);
				stacks.add(stack);
			}
			t.commit();
			return stacks;
		}
	}


	/**
	 * Gets the filled bucket for the specified fluid.
	 * @param variant contents used to fill the bucket. {@link FluidVariant} is used instead of Fluid to preserve fluid NBT.
	 * @return the filled bucket.
	 */
	public static class_1799 getFilledBucket(FluidVariant variant) {
		ContainerItemContext context = new MutableContainerItemContext(class_1802.field_8550.method_7854());
		try (Transaction tx = TransferUtil.getTransaction()) {
			Storage<FluidVariant> storage = context.find(FluidStorage.ITEM);
			if (storage != null) {
				storage.insert(variant, FluidConstants.BUCKET, tx);
				tx.commit();
			}
		}
		return context.getItemVariant().toStack();
	}

	/**
	 * Extract anything matching the given predicate, or null if none available.
	 * based on {@link StorageUtil#extractAny(Storage, long, TransactionContext)}
	 */
	@Nullable
	public static <T extends TransferVariant<?>> ResourceAmount<T> extractMatching(Storage<T> storage, Predicate<T> predicate,
																				   long maxAmount, TransactionContext transaction) {
		StoragePreconditions.notNegative(maxAmount);

		if (storage == null) return null;

		try {
			for (StorageView<T> view : storage.nonEmptyViews()) {
				T resource = view.getResource();
				if (predicate.test(resource)) { // only addition
					long amount = view.extract(resource, maxAmount, transaction);
					if (amount > 0) return new ResourceAmount<>(resource, amount);
				}
			}
		} catch (Exception e) {
			class_128 report = class_128.method_560(e, "Extracting resources from storage");
			report.method_562("Extraction details")
					.method_577("Storage", storage::toString)
					.method_578("Max amount", maxAmount)
					.method_578("Transaction", transaction);
			throw new class_148(report);
		}

		return null;
	}

	/**
	 * Creates a ContainerItemContext with a single mutable slot. This is useful for simulating interactions, such as filling a bucket to get the filled item.
	 */
	public ContainerItemContext mutableContext(class_1799 initial) {
		return new MutableContainerItemContext(initial);
	}

	/**
	 * Restrict a long to the integer range and avoid overflow from casting.
	 */
	public static int truncateLong(long l) {
		if (l > Integer.MAX_VALUE) {
			return Integer.MAX_VALUE;
		} else if (l < Integer.MIN_VALUE) {
			return Integer.MIN_VALUE;
		}
		return (int) l;
	}
}
