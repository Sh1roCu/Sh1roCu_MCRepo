package io.github.fabricators_of_create.porting_lib.transfer.internal.cache;

import io.github.fabricators_of_create.porting_lib.transfer.internal.extensions.ClientLevelExtensions;
import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;
import io.github.fabricators_of_create.porting_lib.util.StorageProvider;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiCache;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiLookup;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_638;
import org.jetbrains.annotations.ApiStatus.Internal;
import org.jetbrains.annotations.Nullable;

/**
 * This should not be used directly. Use {@link StorageProvider} instead.
 */
@Internal
@SuppressWarnings("NonExtendableApiUsage")
public class ClientFluidLookupCache implements BlockApiCache<Storage<FluidVariant>, class_2350>, ClientBlockApiCache {
	private final class_638 world;
	private final class_2338 pos;
	private boolean blockEntityCacheValid = false;
	private class_2586 cachedBlockEntity = null;

	public static BlockApiCache<Storage<FluidVariant>, class_2350> get(class_1937 level, class_2338 pos) {
		if (level instanceof class_638 c)
			return new ClientFluidLookupCache(c, pos);
		return new EmptyFluidLookupCache(pos);
	}

	public ClientFluidLookupCache(class_638 world, class_2338 pos) {
		((ClientLevelExtensions) world).port_lib$registerCache(pos ,this);
		this.world = world;
		this.pos = pos.method_10062();
	}

	public void invalidate() {
		blockEntityCacheValid = false;
		cachedBlockEntity = null;
	}

	@Nullable
	@Override
	public Storage<FluidVariant> find(@Nullable class_2680 state, class_2350 context) {
		// Update block entity cache
		getBlockEntity();
		// Query the provider
		if (cachedBlockEntity == null)
			return null;
		return TransferUtil.getFluidStorage(world, pos, cachedBlockEntity, context);
	}

	@Override
	@Nullable
	public class_2586 getBlockEntity() {
		if (!blockEntityCacheValid) {
			cachedBlockEntity = world.method_8321(pos);
			blockEntityCacheValid = true;
		}

		return cachedBlockEntity;
	}

	@Override
	public BlockApiLookup<Storage<FluidVariant>, class_2350> getLookup() {
		return FluidStorage.SIDED;
	}

	@Override
	public class_3218 getWorld() {
		throw new UnsupportedOperationException("Cannot call getWorld on a client-side cache as only ServerLevels are supported");
	}

	@Override
	public class_2338 getPos() {
		return pos;
	}
}
