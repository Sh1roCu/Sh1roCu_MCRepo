/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package io.github.fabricators_of_create.porting_lib.transfer.fluid;

import com.mojang.serialization.Codec;
import java.util.function.Predicate;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9322;
import net.minecraft.class_9323;
import net.minecraft.class_9331;
import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.fluids.FluidType;

/**
 * Stock data component class to hold a {@link FluidStack}.
 *
 * <p>A corresponding {@link class_9331} must be registered to use this class.
 */
public class SimpleFluidContent implements class_9322 {
	public static final SimpleFluidContent EMPTY = new SimpleFluidContent(FluidStack.EMPTY);
	public static final Codec<SimpleFluidContent> CODEC = FluidStack.OPTIONAL_CODEC
			.xmap(SimpleFluidContent::new, content -> content.fluidStack);
	public static final class_9139<class_9129, SimpleFluidContent> STREAM_CODEC = FluidStack.OPTIONAL_STREAM_CODEC
			.map(SimpleFluidContent::new, content -> content.fluidStack);

	private final FluidStack fluidStack;

	private SimpleFluidContent(FluidStack fluidStack) {
		this.fluidStack = fluidStack;
	}

	public static SimpleFluidContent copyOf(FluidStack fluidStack) {
		return fluidStack.isEmpty() ? EMPTY : new SimpleFluidContent(fluidStack.copy());
	}

	public FluidStack copy() {
		return this.fluidStack.copy();
	}

	public boolean isEmpty() {
		return this.fluidStack.isEmpty();
	}

	public class_3611 getFluid() {
		return fluidStack.getFluid();
	}

	public class_6880<class_3611> getFluidHolder() {
		return fluidStack.getFluidHolder();
	}

	public boolean is(class_6862<class_3611> tag) {
		return fluidStack.is(tag);
	}

	public boolean is(class_3611 fluid) {
		return fluidStack.is(fluid);
	}

	public boolean is(Predicate<class_6880<class_3611>> predicate) {
		return fluidStack.is(predicate);
	}

	public boolean is(class_6880<class_3611> holder) {
		return fluidStack.is(holder);
	}

	public boolean is(class_6885<class_3611> holders) {
		return fluidStack.is(holders);
	}

	public long getAmount() {
		return fluidStack.getAmount();
	}

	public FluidType getFluidType() {
		return fluidStack.getFluidType();
	}

	public boolean is(FluidType fluidType) {
		return fluidStack.is(fluidType);
	}

	public boolean matches(FluidStack other) {
		return FluidStack.matches(fluidStack, other);
	}

	public boolean isSameFluid(FluidStack other) {
		return FluidStack.isSameFluid(fluidStack, other);
	}

	public boolean isSameFluidSameComponents(FluidStack other) {
		return FluidStack.isSameFluidSameComponents(fluidStack, other);
	}

	public boolean isSameFluidSameComponents(SimpleFluidContent content) {
		return isSameFluidSameComponents(content.fluidStack);
	}

	@Override
	public class_9323 method_57353() {
		return fluidStack.getComponents();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		} else if (!(obj instanceof SimpleFluidContent o)) {
			return false;
		} else {
			return FluidStack.matches(this.fluidStack, o.fluidStack);
		}
	}

	@Override
	public int hashCode() {
		return (int) (this.fluidStack.getAmount() * 31 + FluidStack.hashFluidAndComponents(this.fluidStack));
	}
}
