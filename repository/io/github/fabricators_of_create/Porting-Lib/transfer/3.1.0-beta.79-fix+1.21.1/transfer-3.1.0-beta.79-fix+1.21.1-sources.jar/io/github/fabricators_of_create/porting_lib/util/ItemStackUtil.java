package io.github.fabricators_of_create.porting_lib.util;

import java.util.Arrays;
import net.minecraft.class_1799;

public class ItemStackUtil {
	public static class_1799[] createEmptyStackArray(int size) {
		class_1799[] stacks = new class_1799[size];
		Arrays.fill(stacks, class_1799.field_8037);
		return stacks;
	}
}
