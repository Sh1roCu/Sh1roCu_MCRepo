package io.github.fabricators_of_create.porting_lib.transfer.fluid.block;

import io.github.fabricators_of_create.porting_lib.transfer.callbacks.TransactionSuccessCallback;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.ExtractionOnlyStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext;
import net.minecraft.class_1937;
import net.minecraft.class_2263;
import net.minecraft.class_2338;
import net.minecraft.class_3610;

public class BucketPickupHandlerWrapper implements SingleSlotStorage<FluidVariant>, ExtractionOnlyStorage<FluidVariant> {
	protected final class_2263 bucketPickupHandler;
	protected final class_1937 world;
	protected final class_2338 blockPos;

	public BucketPickupHandlerWrapper(class_2263 bucketPickupHandler, class_1937 world, class_2338 blockPos) {
		this.bucketPickupHandler = bucketPickupHandler;
		this.world = world;
		this.blockPos = blockPos;
	}

	@Override
	public long extract(FluidVariant resource, long maxAmount, TransactionContext tx) {
		if (!resource.isBlank() && FluidConstants.BUCKET <= maxAmount) {
			class_3610 fluidState = world.method_8316(blockPos);
			if (!fluidState.method_15769() && resource.getFluid() == fluidState.method_15772()) {
				TransactionSuccessCallback.onSuccess(tx, () -> bucketPickupHandler.method_9700(null, world, blockPos, world.method_8320(blockPos)));
				if (resource.equals(FluidVariant.of(fluidState.method_15772()))) {
					return FluidConstants.BUCKET;
				}
			}
		}
		return 0;
	}

	@Override
	public boolean isResourceBlank() {
		return getResource().isBlank();
	}

	@Override
	public FluidVariant getResource() {
		return FluidVariant.of(world.method_8316(blockPos).method_15772());
	}

	@Override
	public long getAmount() {
		return !world.method_8316(blockPos).method_15769() ? FluidConstants.BUCKET : 0;
	}

	@Override
	public long getCapacity() {
		return FluidConstants.BUCKET;
	}
}
