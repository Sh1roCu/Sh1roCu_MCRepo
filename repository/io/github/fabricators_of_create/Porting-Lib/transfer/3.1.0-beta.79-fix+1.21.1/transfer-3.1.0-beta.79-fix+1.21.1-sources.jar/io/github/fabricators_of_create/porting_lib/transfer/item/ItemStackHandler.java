package io.github.fabricators_of_create.porting_lib.transfer.item;

import io.github.fabricators_of_create.porting_lib.core.util.INBTSerializable;
import io.github.fabricators_of_create.porting_lib.util.DualSortedSetIterator;
import io.github.fabricators_of_create.porting_lib.util.EmptySortedSet;
import io.github.fabricators_of_create.porting_lib.util.ItemStackUtil;
import it.unimi.dsi.fastutil.objects.ObjectAVLTreeSet;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.StoragePreconditions;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_7225;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;

/**
 * An implementation of a item storage designed for ease of use and speed.
 */
public class ItemStackHandler implements SlottedStackStorage, INBTSerializable<class_2487> {
	private final List<ItemStackHandlerSlot> slots;
	private final SortedSet<ItemStackHandlerSlot> nonEmptySlots;
	private final Map<class_1792, SortedSet<ItemStackHandlerSlot>> lookup;

	public ItemStackHandler() {
		this(1);
	}

	public ItemStackHandler(int stacks) {
		this(ItemStackUtil.createEmptyStackArray(stacks));
	}

	public ItemStackHandler(class_1799[] stacks) {
		this.slots = new ArrayList<>(stacks.length);
		this.nonEmptySlots = createSlotSet();
		this.lookup = new HashMap<>();
		for (int i = 0; i < stacks.length; i++) {
			class_1799 stack = stacks[i];
			// slot handles filling lookup
			slots.add(makeSlot(i, stack));
		}
	}

	// core functionality

	@Override
	public long insert(ItemVariant resource, long maxAmount, TransactionContext transaction) {
		StoragePreconditions.notBlankNotNegative(resource, maxAmount);
		long inserted = 0;
		Iterator<ItemStackHandlerSlot> itr = getInsertableSlotsFor(resource);
		while (itr.hasNext()) {
			ItemStackHandlerSlot slot = itr.next();
			inserted += slot.insert(resource, maxAmount - inserted, transaction);
			if (inserted >= maxAmount)
				break;
		}
		return inserted;
	}

	@Override
	public long extract(ItemVariant resource, long maxAmount, TransactionContext transaction) {
		StoragePreconditions.notBlankNotNegative(resource, maxAmount);
		class_1792 item = resource.getItem();
		SortedSet<ItemStackHandlerSlot> slots = getSlotsContaining(item);
		if (slots.isEmpty())
			return 0; // no slots hold this item
		long extracted = 0;
		for (ItemStackHandlerSlot slot : slots) {
			extracted += slot.extract(resource, maxAmount - extracted, transaction);
			if (extracted >= maxAmount)
				break;
		}
		return extracted;
	}

	// iteration

	@Override
	public Iterable<StorageView<ItemVariant>> nonEmptyViews() {
		//noinspection unchecked,rawtypes
		return (Iterable) nonEmptySlots;
	}

	@Override
	public Iterator<StorageView<ItemVariant>> nonEmptyIterator() {
		//noinspection unchecked,rawtypes
		return (Iterator) nonEmptySlots.iterator();
	}

	// slot support

	@Override
	public int getSlotCount() {
		return slots.size();
	}

	@Override
	public ItemStackHandlerSlot getSlot(int slot) {
		return slots.get(slot);
	}

	@Override
	public List<SingleSlotStorage<ItemVariant>> getSlots() {
		//noinspection unchecked,rawtypes
		return (List) slots;
	}

	// API, mostly from forge, with extras


	public class_1799 getStackInSlot(int slot) {
		return getSlot(slot).getStack();
	}

	public void setStackInSlot(int slot, class_1799 stack) {
		getSlot(slot).setNewStack(stack);
	}

	public ItemVariant getVariantInSlot(int slot) {
		return getSlot(slot).getResource();
	}

	public int getSlotLimit(int slot) {
		return getStackInSlot(slot).method_57825(class_9334.field_50071, 64);
	}

	/**
	 * Determines the maximum amount of an item that can be stored in the given slot.
	 */
	protected int getStackLimit(int slot, ItemVariant resource) {
		return Math.min(getSlotLimit(slot), resource.getItem().method_7882());
	}

	/**
	 * Once a transaction is committed, this is invoked once for each modified slot.
	 */
	protected void onContentsChanged(int slot) {
	}

	/**
	 * Get a set of all slots containing the given item, sorted by ascending indices.
	 * The returned set may be empty, and should not be modified in any way.
	 */
	public SortedSet<ItemStackHandlerSlot> getSlotsContaining(class_1792 item) {
		return lookup.containsKey(item) ? lookup.get(item) : EmptySortedSet.cast();
	}

	/**
	 * Called after NBT is loaded and this handler has been updated.
	 */
	protected void onLoad() {
	}

	/**
	 * True if this handler only contains empty stacks.
	 */
	public boolean empty() {
		return nonEmptySlots.isEmpty();
	}

	/**
	 * Resize this handler, clearing all existing content.
	 */
	public void setSize(int size) {
		slots.clear();
		nonEmptySlots.clear();
		lookup.clear();
		for (int i = 0; i < size; i++) {
			slots.add(makeSlot(i, class_1799.field_8037));
		}
	}

	protected ItemStackHandlerSlot makeSlot(int index, class_1799 stack) {
		return new ItemStackHandlerSlot(index, this, stack);
	}

	// serialization

	@Override
	public class_2487 serializeNBT(class_7225.class_7874 provider) {
		class_2487 nbt = new class_2487();
		nbt.method_10569("Size", this.slots.size());

		class_2499 slots = new class_2499();
		for (ItemStackHandlerSlot slot : this.slots) {
			if (!slot.getStack().method_7960()) {
				class_2487 itemTag = new class_2487();
				itemTag.method_10569("Slot", slot.getIndex());
				slots.add(slot.save(provider, itemTag));
			}
		}

		nbt.method_10566("Items", slots);
		return nbt;
	}

	@Override
	public void deserializeNBT(class_7225.class_7874 provider, class_2487 nbt) {
		setSize(nbt.method_10573("Size", class_2520.field_33253) ? nbt.method_10550("Size") : slots.size()); // also clears
		class_2499 slots = nbt.method_10554("Items", class_2520.field_33260);
		for (int i = 0; i < slots.size(); i++) {
			class_2487 slotTag = slots.method_10602(i);
			int index = slotTag.method_10550("Slot");

			if (index >= 0 && index < this.slots.size()) {
				this.slots.get(index).load(provider, slotTag);
			}
		}
		onLoad();
	}

	// misc

	void onStackChange(ItemStackHandlerSlot slot, class_1799 oldStack, class_1799 newStack) {
		if (class_1799.method_7984(oldStack, newStack))
			return;
		SortedSet<ItemStackHandlerSlot> oldItemSlots = getSlotsContaining(oldStack.method_7909());
		if (!oldItemSlots.isEmpty()) {
			oldItemSlots.remove(slot);
		}
		lookup.computeIfAbsent(newStack.method_7909(), $ -> createSlotSet()).add(slot);
		if (oldStack.method_7960()) { // no longer empty
			nonEmptySlots.add(slot);
		} else if (newStack.method_7960()) { // became empty
			nonEmptySlots.remove(slot);
		}
	}

	void initSlot(ItemStackHandlerSlot slot) {
		class_1799 stack = slot.getStack();
		lookup.computeIfAbsent(stack.method_7909(), $ -> createSlotSet()).add(slot);
		if (!stack.method_7960())
			nonEmptySlots.add(slot);
	}

	@Override
	public String toString() {
		return getClass().getSimpleName() + '[' + slots + ']';
	}

	private Iterator<ItemStackHandlerSlot> getInsertableSlotsFor(ItemVariant variant) {
		SortedSet<ItemStackHandlerSlot> slots = getSlotsContaining(variant.getItem());
		SortedSet<ItemStackHandlerSlot> emptySlots = getSlotsContaining(class_1802.field_8162);
		if (slots.isEmpty()) {
			return emptySlots.isEmpty() ? Collections.emptyIterator() : emptySlots.iterator();
		} else {
			return emptySlots.isEmpty() ? slots.iterator() : new DualSortedSetIterator<>(slots, emptySlots);
		}
	}

	private static SortedSet<ItemStackHandlerSlot> createSlotSet() {
		return new ObjectAVLTreeSet<>(Comparator.comparingInt(ItemStackHandlerSlot::getIndex));
	}
}
