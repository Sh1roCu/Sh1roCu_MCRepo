package io.github.fabricators_of_create.porting_lib.transfer.item;

import net.minecraft.class_1799;
import net.minecraft.class_9695;

public class RecipeWrapper implements class_9695 {
	protected final SlottedStackStorage inv;

	public RecipeWrapper(SlottedStackStorage inv) {
		this.inv = inv;
	}

	/**
	 * Returns the size of this inventory.
	 */
	@Override
	public int method_59983() {
		return inv.getSlotCount();
	}

	/**
	 * Returns the stack in this slot. This stack should be a modifiable reference, not a copy of a stack in your inventory.
	 */
	@Override
	public class_1799 method_59984(int slot) {
		return inv.getStackInSlot(slot);
	}
}
