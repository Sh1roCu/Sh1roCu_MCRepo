package io.github.fabricators_of_create.porting_lib.transfer.mixin.client;

import io.github.fabricators_of_create.porting_lib.transfer.internal.extensions.ClientLevelExtensions;
import io.github.fabricators_of_create.porting_lib.transfer.internal.extensions.LevelExtensions;
import io.github.fabricators_of_create.porting_lib.transfer.internal.cache.ClientBlockApiCache;
import io.github.fabricators_of_create.porting_lib.transfer.internal.cache.ClientFluidLookupCache;
import io.github.fabricators_of_create.porting_lib.transfer.internal.cache.ClientItemLookupCache;
import it.unimi.dsi.fastutil.objects.Object2ReferenceOpenHashMap;

import net.fabricmc.fabric.api.lookup.v1.block.BlockApiCache;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Mixin(class_638.class)
public class ClientLevelMixin implements LevelExtensions, ClientLevelExtensions {
	// lookup stuff, from FAPI

	@Unique
	private final Map<class_2338, List<WeakReference<ClientBlockApiCache>>> port_lib$apiLookupCaches = new Object2ReferenceOpenHashMap<>();
	@Unique
	private int port_lib$apiLookupAccessesWithoutCleanup = 0;

	@Override
	public void port_lib$invalidateCache(class_2338 pos) {
		List<WeakReference<ClientBlockApiCache>> caches = port_lib$apiLookupCaches.get(pos);

		if (caches != null) {
			caches.removeIf(weakReference -> weakReference.get() == null);

			if (caches.size() == 0) {
				port_lib$apiLookupCaches.remove(pos);
			} else {
				caches.forEach(weakReference -> {
					ClientBlockApiCache cache = weakReference.get();

					if (cache != null) {
						cache.invalidate();
					}
				});
			}
		}

		port_lib$apiLookupAccessesWithoutCleanup++;

		// Try to invalidate GC'd lookups from the cache after 2 * the number of cached lookups
		if (port_lib$apiLookupAccessesWithoutCleanup > 2 * port_lib$apiLookupCaches.size()) {
			port_lib$apiLookupCaches.entrySet().removeIf(entry -> {
				entry.getValue().removeIf(weakReference -> weakReference.get() == null);
				return entry.getValue().isEmpty();
			});

			port_lib$apiLookupAccessesWithoutCleanup = 0;
		}
	}

	@Override
	public void port_lib$registerCache(class_2338 pos, ClientBlockApiCache cache) {
		List<WeakReference<ClientBlockApiCache>> caches = port_lib$apiLookupCaches.computeIfAbsent(pos.method_10062(), ignored -> new ArrayList<>());
		caches.removeIf(weakReference -> weakReference.get() == null);
		caches.add(new WeakReference<>(cache));
		port_lib$apiLookupAccessesWithoutCleanup++;
	}

	@Override
	public BlockApiCache<Storage<ItemVariant>, class_2350> port_lib$getItemCache(class_2338 pos) {
		return ClientItemLookupCache.get(((class_638) (Object) this), pos);
	}

	@Override
	public BlockApiCache<Storage<FluidVariant>, class_2350> port_lib$getFluidApiCache(class_2338 pos) {
		return ClientFluidLookupCache.get(((class_638) (Object) this), pos);
	}
}
