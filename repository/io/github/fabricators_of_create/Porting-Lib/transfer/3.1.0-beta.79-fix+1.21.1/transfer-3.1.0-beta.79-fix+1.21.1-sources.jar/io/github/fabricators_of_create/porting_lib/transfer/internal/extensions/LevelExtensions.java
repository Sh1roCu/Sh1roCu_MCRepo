package io.github.fabricators_of_create.porting_lib.transfer.internal.extensions;

import net.fabricmc.fabric.api.lookup.v1.block.BlockApiCache;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import org.jetbrains.annotations.ApiStatus.Internal;

@Internal
public interface LevelExtensions {
	default BlockApiCache<Storage<ItemVariant>, class_2350> port_lib$getItemCache(class_2338 pos) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default BlockApiCache<Storage<FluidVariant>, class_2350> port_lib$getFluidApiCache(class_2338 pos) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}
