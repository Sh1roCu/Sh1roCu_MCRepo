package io.github.fabricators_of_create.porting_lib.config.network.configuration;

import java.util.function.Consumer;

import io.github.fabricators_of_create.porting_lib.config.network.ConfigSync;
import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import net.fabricmc.fabric.api.networking.v1.FabricServerConfigurationNetworkHandler;
import net.minecraft.class_2596;
import net.minecraft.class_2658;
import net.minecraft.class_2960;
import net.minecraft.class_8605;
import net.minecraft.class_8710;
import org.jetbrains.annotations.ApiStatus;

/**
 * Configuration task that syncs the config files to the client
 *
 * @param listener the listener to indicate to that the task is complete
 */
@ApiStatus.Internal
public record SyncConfig(FabricServerConfigurationNetworkHandler listener) implements class_8605 {
	private static final class_2960 ID = PortingLib.id("sync_config");
	public static class_8605.class_8606 TYPE = new class_8605.class_8606(ID.toString());

	public void run(Consumer<class_8710> sender) {
		ConfigSync.syncConfigs().forEach(sender);
		listener().completeTask(method_52375());
	}

	@Override
	public void method_52376(Consumer<class_2596<?>> sender) {
		run(customPacketPayload -> sender.accept(new class_2658(customPacketPayload)));
	}

	@Override
	public class_8605.class_8606 method_52375() {
		return TYPE;
	}
}
