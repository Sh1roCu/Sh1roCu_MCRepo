package io.github.fabricators_of_create.porting_lib.config.network.payload;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.ApiStatus;

/**
 * A payload that contains a config file.
 * <p>
 * This is used to send config files to the client.
 * </p>
 *
 * @param fileName The name of the config file.
 * @param contents The contents of the config file.
 */
@ApiStatus.Internal
public record ConfigFilePayload(String fileName, byte[] contents) implements class_8710 {
	public static final class_9154<ConfigFilePayload> TYPE = new class_9154<>(PortingLib.id("config_file"));
	public static final class_9139<class_2540, ConfigFilePayload> STREAM_CODEC = class_9139.method_56435(
			class_9135.field_48554,
			ConfigFilePayload::fileName,
			class_9135.field_48987,
			ConfigFilePayload::contents,
			ConfigFilePayload::new);

	@Override
	public class_9154<ConfigFilePayload> method_56479() {
		return TYPE;
	}
}
