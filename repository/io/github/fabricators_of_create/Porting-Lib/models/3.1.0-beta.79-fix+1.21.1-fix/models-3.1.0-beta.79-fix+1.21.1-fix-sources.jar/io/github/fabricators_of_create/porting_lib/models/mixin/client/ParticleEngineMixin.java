package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_702;
import net.minecraft.class_703;
import net.minecraft.class_727;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(class_702.class)
public class ParticleEngineMixin {
	@ModifyArgs(
			method = "crack",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/particle/ParticleEngine;add(Lnet/minecraft/client/particle/Particle;)V"
			)
	)
	private void updateSpriteOnCrack(Args args, class_2338 pos, class_2350 side, @Local(ordinal = 0) class_2680 state) {
		class_703 particle = args.get(0);
		if (particle instanceof class_727 terrainParticle)
			terrainParticle.updateSprite(state, pos);
	}

	@ModifyArgs(
			method = "method_34020",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/particle/ParticleEngine;add(Lnet/minecraft/client/particle/Particle;)V"
			)
	)
	private void updateSpriteOnDestroy(Args args, class_2338 pos, class_2680 state,
									   double dx, double e, double f, double g, double h, double i) {
		class_703 particle = args.get(0);
		if (particle instanceof class_727 terrainParticle)
			terrainParticle.updateSprite(state, pos);
	}
}
