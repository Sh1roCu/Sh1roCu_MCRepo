package io.github.fabricators_of_create.porting_lib.models;

import net.fabricmc.fabric.api.renderer.v1.model.WrapperBakedModel;
import net.minecraft.class_1087;
import net.minecraft.class_4587;
import net.minecraft.class_811;
import org.jetbrains.annotations.ApiStatus.OverrideOnly;
import org.jetbrains.annotations.Nullable;

public interface TransformTypeDependentItemBakedModel {
	/**
	 * Applies a transform for the given {@link class_811} and {@code leftHand}, and
	 * returns the model to be rendered.
	 * {@link #maybeApplyTransform(class_1087, class_811, class_4587, boolean, DefaultTransform)} should always be used, do not call directly.
	 * @param leftHand true if this item is being rendered in the player's left hand
	 * @param defaultTransform a callback which will apply the vanilla transformation on
	 */
	@OverrideOnly
	class_1087 applyTransform(class_811 context, class_4587 poseStack, boolean leftHand, DefaultTransform defaultTransform);

	/**
	 * Attempt to apply a custom transform from the given model, unwrapping wrappers if needed.
	 * Does nothing if not a {@link TransformTypeDependentItemBakedModel}.
	 * @return null if no transformation occurred, otherwise the transformed model
	 */
	@Nullable
	static class_1087 maybeApplyTransform(class_1087 model, class_811 context, class_4587 poseStack, boolean leftHand, DefaultTransform defaultTransform) {
		if (model instanceof TransformTypeDependentItemBakedModel transformer)
			return transformer.applyTransform(context, poseStack, leftHand, defaultTransform);

		class_1087 wrapped = model;
		while (wrapped instanceof WrapperBakedModel wrapper) {
			wrapped = wrapper.getWrappedModel();
			if (wrapped == null) {
				return null;
			} else if (wrapped instanceof TransformTypeDependentItemBakedModel transformer) {
				return transformer.applyTransform(context, poseStack, leftHand, defaultTransform);
			}
		}

		return null;
	}

	@FunctionalInterface
	interface DefaultTransform {
		void apply(class_1087 model);
	}
}
