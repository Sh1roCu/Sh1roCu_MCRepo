package io.github.fabricators_of_create.porting_lib.models.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2388;
import net.minecraft.class_2394;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(class_1297.class)
public abstract class EntityMixin {
	@ModifyArg(
			method = "spawnSprintParticle",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/Level;addParticle(Lnet/minecraft/core/particles/ParticleOptions;DDDDDD)V"
			)
	)
	private class_2394 addSourcePos(class_2394 options, @Local(ordinal = 0) class_2338 onPos) {
		if (options instanceof class_2388 block) {
			block.setSourcePos(onPos);
		}
		return options;
	}
}
