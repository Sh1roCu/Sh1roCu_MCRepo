package io.github.fabricators_of_create.porting_lib.models.generators;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2310;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2354;
import net.minecraft.class_2389;
import net.minecraft.class_2405;
import net.minecraft.class_2429;
import net.minecraft.class_2440;
import net.minecraft.class_2465;
import net.minecraft.class_2482;
import net.minecraft.class_2508;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2544;
import net.minecraft.class_2551;
import net.minecraft.class_2680;
import net.minecraft.class_2738;
import net.minecraft.class_2741;
import net.minecraft.class_2750;
import net.minecraft.class_2756;
import net.minecraft.class_2760;
import net.minecraft.class_2769;
import net.minecraft.class_2771;
import net.minecraft.class_2778;
import net.minecraft.class_2960;
import net.minecraft.class_4778;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7923;
import io.github.fabricators_of_create.porting_lib.data.ExistingFileHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.VisibleForTesting;

/**
 * Data provider for blockstate files. Extends {@link BlockModelProvider} so that
 * blockstates and their referenced models can be provided in tandem.
 */
public abstract class BlockStateProvider implements class_2405 {
	private static final Logger LOGGER = LogManager.getLogger();
	private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().disableHtmlEscaping().create();

	@VisibleForTesting
	protected final Map<class_2248, IGeneratedBlockState> registeredBlocks = new LinkedHashMap<>();

	private final class_7784 output;
	private final String modid;
	private final BlockModelProvider blockModels;
	private final ItemModelProvider itemModels;

	public BlockStateProvider(class_7784 output, String modid, ExistingFileHelper exFileHelper) {
		this.output = output;
		this.modid = modid;
		this.blockModels = new BlockModelProvider(output, modid, exFileHelper) {
			@Override
			public CompletableFuture<?> method_10319(class_7403 cache) {
				return CompletableFuture.allOf();
			}

			@Override
			protected void registerModels() {}
		};
		this.itemModels = new ItemModelProvider(output, modid, this.blockModels.existingFileHelper) {
			@Override
			protected void registerModels() {}

			@Override
			public CompletableFuture<?> method_10319(class_7403 cache) {
				return CompletableFuture.allOf();
			}
		};
	}

	@Override
	public CompletableFuture<?> method_10319(class_7403 cache) {
		models().clear();
		itemModels().clear();
		registeredBlocks.clear();
		registerStatesAndModels();
		CompletableFuture<?>[] futures = new CompletableFuture<?>[2 + this.registeredBlocks.size()];
		int i = 0;
		futures[i++] = models().generateAll(cache);
		futures[i++] = itemModels().generateAll(cache);
		for (Map.Entry<class_2248, IGeneratedBlockState> entry : registeredBlocks.entrySet()) {
			futures[i++] = saveBlockState(cache, entry.getValue().toJson(), entry.getKey());
		}
		return CompletableFuture.allOf(futures);
	}

	protected abstract void registerStatesAndModels();

	public VariantBlockStateBuilder getVariantBuilder(class_2248 b) {
		if (registeredBlocks.containsKey(b)) {
			IGeneratedBlockState old = registeredBlocks.get(b);
			Preconditions.checkState(old instanceof VariantBlockStateBuilder);
			return (VariantBlockStateBuilder) old;
		} else {
			VariantBlockStateBuilder ret = new VariantBlockStateBuilder(b);
			registeredBlocks.put(b, ret);
			return ret;
		}
	}

	public MultiPartBlockStateBuilder getMultipartBuilder(class_2248 b) {
		if (registeredBlocks.containsKey(b)) {
			IGeneratedBlockState old = registeredBlocks.get(b);
			Preconditions.checkState(old instanceof MultiPartBlockStateBuilder);
			return (MultiPartBlockStateBuilder) old;
		} else {
			MultiPartBlockStateBuilder ret = new MultiPartBlockStateBuilder(b);
			registeredBlocks.put(b, ret);
			return ret;
		}
	}

	public BlockModelProvider models() {
		return blockModels;
	}

	public ItemModelProvider itemModels() {
		return itemModels;
	}

	public class_2960 modLoc(String name) {
		return class_2960.method_60655(modid, name);
	}

	public class_2960 mcLoc(String name) {
		return class_2960.method_60654(name);
	}

	private class_2960 key(class_2248 block) {
		return class_7923.field_41175.method_10221(block);
	}

	private String name(class_2248 block) {
		return key(block).method_12832();
	}

	public class_2960 blockTexture(class_2248 block) {
		class_2960 name = key(block);
		return class_2960.method_60655(name.method_12836(), ModelProvider.BLOCK_FOLDER + "/" + name.method_12832());
	}

	private class_2960 extend(class_2960 rl, String suffix) {
		return class_2960.method_60655(rl.method_12836(), rl.method_12832() + suffix);
	}

	public ModelFile cubeAll(class_2248 block) {
		return models().cubeAll(name(block), blockTexture(block));
	}

	public void simpleBlock(class_2248 block) {
		simpleBlock(block, cubeAll(block));
	}

	public void simpleBlock(class_2248 block, Function<ModelFile, ConfiguredModel[]> expander) {
		simpleBlock(block, expander.apply(cubeAll(block)));
	}

	public void simpleBlock(class_2248 block, ModelFile model) {
		simpleBlock(block, new ConfiguredModel(model));
	}

	public void simpleBlockItem(class_2248 block, ModelFile model) {
		itemModels().getBuilder(key(block).method_12832()).parent(model);
	}

	public void simpleBlockWithItem(class_2248 block, ModelFile model) {
		simpleBlock(block, model);
		simpleBlockItem(block, model);
	}

	public void simpleBlock(class_2248 block, ConfiguredModel... models) {
		getVariantBuilder(block)
				.partialState().setModels(models);
	}

	public void axisBlock(class_2465 block) {
		axisBlock(block, blockTexture(block));
	}

	public void logBlock(class_2465 block) {
		axisBlock(block, blockTexture(block), extend(blockTexture(block), "_top"));
	}

	public void axisBlock(class_2465 block, class_2960 baseName) {
		axisBlock(block, extend(baseName, "_side"), extend(baseName, "_end"));
	}

	public void axisBlock(class_2465 block, class_2960 side, class_2960 end) {
		axisBlock(block,
				models().cubeColumn(name(block), side, end),
				models().cubeColumnHorizontal(name(block) + "_horizontal", side, end));
	}

	public void axisBlockWithRenderType(class_2465 block, String renderType) {
		axisBlockWithRenderType(block, blockTexture(block), renderType);
	}

	public void logBlockWithRenderType(class_2465 block, String renderType) {
		axisBlockWithRenderType(block, blockTexture(block), extend(blockTexture(block), "_top"), renderType);
	}

	public void axisBlockWithRenderType(class_2465 block, class_2960 baseName, String renderType) {
		axisBlockWithRenderType(block, extend(baseName, "_side"), extend(baseName, "_end"), renderType);
	}

	public void axisBlockWithRenderType(class_2465 block, class_2960 side, class_2960 end, String renderType) {
		axisBlock(block,
				models().cubeColumn(name(block), side, end).renderType(renderType),
				models().cubeColumnHorizontal(name(block) + "_horizontal", side, end).renderType(renderType));
	}

	public void axisBlockWithRenderType(class_2465 block, class_2960 renderType) {
		axisBlockWithRenderType(block, blockTexture(block), renderType);
	}

	public void logBlockWithRenderType(class_2465 block, class_2960 renderType) {
		axisBlockWithRenderType(block, blockTexture(block), extend(blockTexture(block), "_top"), renderType);
	}

	public void axisBlockWithRenderType(class_2465 block, class_2960 baseName, class_2960 renderType) {
		axisBlockWithRenderType(block, extend(baseName, "_side"), extend(baseName, "_end"), renderType);
	}

	public void axisBlockWithRenderType(class_2465 block, class_2960 side, class_2960 end, class_2960 renderType) {
		axisBlock(block,
				models().cubeColumn(name(block), side, end).renderType(renderType),
				models().cubeColumnHorizontal(name(block) + "_horizontal", side, end).renderType(renderType));
	}

	public void axisBlock(class_2465 block, ModelFile vertical, ModelFile horizontal) {
		getVariantBuilder(block)
				.partialState().with(class_2465.field_11459, class_2351.field_11052)
				.modelForState().modelFile(vertical).addModel()
				.partialState().with(class_2465.field_11459, class_2351.field_11051)
				.modelForState().modelFile(horizontal).rotationX(90).addModel()
				.partialState().with(class_2465.field_11459, class_2351.field_11048)
				.modelForState().modelFile(horizontal).rotationX(90).rotationY(90).addModel();
	}

	private static final int DEFAULT_ANGLE_OFFSET = 180;

	public void horizontalBlock(class_2248 block, class_2960 side, class_2960 front, class_2960 top) {
		horizontalBlock(block, models().orientable(name(block), side, front, top));
	}

	public void horizontalBlock(class_2248 block, ModelFile model) {
		horizontalBlock(block, model, DEFAULT_ANGLE_OFFSET);
	}

	public void horizontalBlock(class_2248 block, ModelFile model, int angleOffset) {
		horizontalBlock(block, $ -> model, angleOffset);
	}

	public void horizontalBlock(class_2248 block, Function<class_2680, ModelFile> modelFunc) {
		horizontalBlock(block, modelFunc, DEFAULT_ANGLE_OFFSET);
	}

	public void horizontalBlock(class_2248 block, Function<class_2680, ModelFile> modelFunc, int angleOffset) {
		getVariantBuilder(block)
				.forAllStates(state -> ConfiguredModel.builder()
						.modelFile(modelFunc.apply(state))
						.rotationY(((int) state.method_11654(class_2741.field_12481).method_10144() + angleOffset) % 360)
						.build());
	}

	public void horizontalFaceBlock(class_2248 block, ModelFile model) {
		horizontalFaceBlock(block, model, DEFAULT_ANGLE_OFFSET);
	}

	public void horizontalFaceBlock(class_2248 block, ModelFile model, int angleOffset) {
		horizontalFaceBlock(block, $ -> model, angleOffset);
	}

	public void horizontalFaceBlock(class_2248 block, Function<class_2680, ModelFile> modelFunc) {
		horizontalFaceBlock(block, modelFunc, DEFAULT_ANGLE_OFFSET);
	}

	public void horizontalFaceBlock(class_2248 block, Function<class_2680, ModelFile> modelFunc, int angleOffset) {
		getVariantBuilder(block)
				.forAllStates(state -> ConfiguredModel.builder()
						.modelFile(modelFunc.apply(state))
						.rotationX(state.method_11654(class_2741.field_12555).ordinal() * 90)
						.rotationY((((int) state.method_11654(class_2741.field_12481).method_10144() + angleOffset) + (state.method_11654(class_2741.field_12555) == class_2738.field_12473 ? 180 : 0)) % 360)
						.build());
	}

	public void directionalBlock(class_2248 block, ModelFile model) {
		directionalBlock(block, model, DEFAULT_ANGLE_OFFSET);
	}

	public void directionalBlock(class_2248 block, ModelFile model, int angleOffset) {
		directionalBlock(block, $ -> model, angleOffset);
	}

	public void directionalBlock(class_2248 block, Function<class_2680, ModelFile> modelFunc) {
		directionalBlock(block, modelFunc, DEFAULT_ANGLE_OFFSET);
	}

	public void directionalBlock(class_2248 block, Function<class_2680, ModelFile> modelFunc, int angleOffset) {
		getVariantBuilder(block)
				.forAllStates(state -> {
					class_2350 dir = state.method_11654(class_2741.field_12525);
					return ConfiguredModel.builder()
							.modelFile(modelFunc.apply(state))
							.rotationX(dir == class_2350.field_11033 ? 180 : dir.method_10166().method_10179() ? 90 : 0)
							.rotationY(dir.method_10166().method_10178() ? 0 : (((int) dir.method_10144()) + angleOffset) % 360)
							.build();
				});
	}

	public void stairsBlock(class_2510 block, class_2960 texture) {
		stairsBlock(block, texture, texture, texture);
	}

	public void stairsBlock(class_2510 block, String name, class_2960 texture) {
		stairsBlock(block, name, texture, texture, texture);
	}

	public void stairsBlock(class_2510 block, class_2960 side, class_2960 bottom, class_2960 top) {
		stairsBlockInternal(block, key(block).toString(), side, bottom, top);
	}

	public void stairsBlock(class_2510 block, String name, class_2960 side, class_2960 bottom, class_2960 top) {
		stairsBlockInternal(block, name + "_stairs", side, bottom, top);
	}

	public void stairsBlockWithRenderType(class_2510 block, class_2960 texture, String renderType) {
		stairsBlockWithRenderType(block, texture, texture, texture, renderType);
	}

	public void stairsBlockWithRenderType(class_2510 block, String name, class_2960 texture, String renderType) {
		stairsBlockWithRenderType(block, name, texture, texture, texture, renderType);
	}

	public void stairsBlockWithRenderType(class_2510 block, class_2960 side, class_2960 bottom, class_2960 top, String renderType) {
		stairsBlockInternalWithRenderType(block, key(block).toString(), side, bottom, top, class_2960.method_12829(renderType));
	}

	public void stairsBlockWithRenderType(class_2510 block, String name, class_2960 side, class_2960 bottom, class_2960 top, String renderType) {
		stairsBlockInternalWithRenderType(block, name + "_stairs", side, bottom, top, class_2960.method_12829(renderType));
	}

	public void stairsBlockWithRenderType(class_2510 block, class_2960 texture, class_2960 renderType) {
		stairsBlockWithRenderType(block, texture, texture, texture, renderType);
	}

	public void stairsBlockWithRenderType(class_2510 block, String name, class_2960 texture, class_2960 renderType) {
		stairsBlockWithRenderType(block, name, texture, texture, texture, renderType);
	}

	public void stairsBlockWithRenderType(class_2510 block, class_2960 side, class_2960 bottom, class_2960 top, class_2960 renderType) {
		stairsBlockInternalWithRenderType(block, key(block).toString(), side, bottom, top, renderType);
	}

	public void stairsBlockWithRenderType(class_2510 block, String name, class_2960 side, class_2960 bottom, class_2960 top, class_2960 renderType) {
		stairsBlockInternalWithRenderType(block, name + "_stairs", side, bottom, top, renderType);
	}

	private void stairsBlockInternal(class_2510 block, String baseName, class_2960 side, class_2960 bottom, class_2960 top) {
		ModelFile stairs = models().stairs(baseName, side, bottom, top);
		ModelFile stairsInner = models().stairsInner(baseName + "_inner", side, bottom, top);
		ModelFile stairsOuter = models().stairsOuter(baseName + "_outer", side, bottom, top);
		stairsBlock(block, stairs, stairsInner, stairsOuter);
	}

	private void stairsBlockInternalWithRenderType(class_2510 block, String baseName, class_2960 side, class_2960 bottom, class_2960 top, class_2960 renderType) {
		ModelFile stairs = models().stairs(baseName, side, bottom, top).renderType(renderType);
		ModelFile stairsInner = models().stairsInner(baseName + "_inner", side, bottom, top).renderType(renderType);
		ModelFile stairsOuter = models().stairsOuter(baseName + "_outer", side, bottom, top).renderType(renderType);
		stairsBlock(block, stairs, stairsInner, stairsOuter);
	}

	public void stairsBlock(class_2510 block, ModelFile stairs, ModelFile stairsInner, ModelFile stairsOuter) {
		getVariantBuilder(block)
				.forAllStatesExcept(state -> {
					class_2350 facing = state.method_11654(class_2510.field_11571);
					class_2760 half = state.method_11654(class_2510.field_11572);
					class_2778 shape = state.method_11654(class_2510.field_11565);
					int yRot = (int) facing.method_10170().method_10144(); // Stairs model is rotated 90 degrees clockwise for some reason
					if (shape == class_2778.field_12712 || shape == class_2778.field_12708) {
						yRot += 270; // Left facing stairs are rotated 90 degrees clockwise
					}
					if (shape != class_2778.field_12710 && half == class_2760.field_12619) {
						yRot += 90; // Top stairs are rotated 90 degrees clockwise
					}
					yRot %= 360;
					boolean uvlock = yRot != 0 || half == class_2760.field_12619; // Don't set uvlock for states that have no rotation
					return ConfiguredModel.builder()
							.modelFile(shape == class_2778.field_12710 ? stairs : shape == class_2778.field_12712 || shape == class_2778.field_12713 ? stairsInner : stairsOuter)
							.rotationX(half == class_2760.field_12617 ? 0 : 180)
							.rotationY(yRot)
							.uvLock(uvlock)
							.build();
				}, class_2510.field_11573);
	}

	public void slabBlock(class_2482 block, class_2960 doubleslab, class_2960 texture) {
		slabBlock(block, doubleslab, texture, texture, texture);
	}

	public void slabBlock(class_2482 block, class_2960 doubleslab, class_2960 side, class_2960 bottom, class_2960 top) {
		slabBlock(block, models().slab(name(block), side, bottom, top), models().slabTop(name(block) + "_top", side, bottom, top), models().getExistingFile(doubleslab));
	}

	public void slabBlock(class_2482 block, ModelFile bottom, ModelFile top, ModelFile doubleslab) {
		getVariantBuilder(block)
				.partialState().with(class_2482.field_11501, class_2771.field_12681).addModels(new ConfiguredModel(bottom))
				.partialState().with(class_2482.field_11501, class_2771.field_12679).addModels(new ConfiguredModel(top))
				.partialState().with(class_2482.field_11501, class_2771.field_12682).addModels(new ConfiguredModel(doubleslab));
	}

	public void buttonBlock(class_2269 block, class_2960 texture) {
		ModelFile button = models().button(name(block), texture);
		ModelFile buttonPressed = models().buttonPressed(name(block) + "_pressed", texture);
		buttonBlock(block, button, buttonPressed);
	}

	public void buttonBlock(class_2269 block, ModelFile button, ModelFile buttonPressed) {
		getVariantBuilder(block).forAllStates(state -> {
			class_2350 facing = state.method_11654(class_2269.field_11177);
			class_2738 face = state.method_11654(class_2269.field_11007);
			boolean powered = state.method_11654(class_2269.field_10729);

			return ConfiguredModel.builder()
					.modelFile(powered ? buttonPressed : button)
					.rotationX(face == class_2738.field_12475 ? 0 : (face == class_2738.field_12471 ? 90 : 180))
					.rotationY((int) (face == class_2738.field_12473 ? facing : facing.method_10153()).method_10144())
					.uvLock(face == class_2738.field_12471)
					.build();
		});
	}

	public void pressurePlateBlock(class_2440 block, class_2960 texture) {
		ModelFile pressurePlate = models().pressurePlate(name(block), texture);
		ModelFile pressurePlateDown = models().pressurePlateDown(name(block) + "_down", texture);
		pressurePlateBlock(block, pressurePlate, pressurePlateDown);
	}

	public void pressurePlateBlock(class_2440 block, ModelFile pressurePlate, ModelFile pressurePlateDown) {
		getVariantBuilder(block)
				.partialState().with(class_2440.field_11358, true).addModels(new ConfiguredModel(pressurePlateDown))
				.partialState().with(class_2440.field_11358, false).addModels(new ConfiguredModel(pressurePlate));
	}

	public void signBlock(class_2508 signBlock, class_2551 wallSignBlock, class_2960 texture) {
		ModelFile sign = models().sign(name(signBlock), texture);
		signBlock(signBlock, wallSignBlock, sign);
	}

	public void signBlock(class_2508 signBlock, class_2551 wallSignBlock, ModelFile sign) {
		simpleBlock(signBlock, sign);
		simpleBlock(wallSignBlock, sign);
	}

	public void fourWayBlock(class_2310 block, ModelFile post, ModelFile side) {
		MultiPartBlockStateBuilder builder = getMultipartBuilder(block)
				.part().modelFile(post).addModel().end();
		fourWayMultipart(builder, side);
	}

	public void fourWayMultipart(MultiPartBlockStateBuilder builder, ModelFile side) {
		class_2429.field_11329.entrySet().forEach(e -> {
			class_2350 dir = e.getKey();
			if (dir.method_10166().method_10179()) {
				builder.part().modelFile(side).rotationY((((int) dir.method_10144()) + 180) % 360).uvLock(true).addModel()
						.condition(e.getValue(), true);
			}
		});
	}

	public void fenceBlock(class_2354 block, class_2960 texture) {
		String baseName = key(block).toString();
		fourWayBlock(block,
				models().fencePost(baseName + "_post", texture),
				models().fenceSide(baseName + "_side", texture));
	}

	public void fenceBlock(class_2354 block, String name, class_2960 texture) {
		fourWayBlock(block,
				models().fencePost(name + "_fence_post", texture),
				models().fenceSide(name + "_fence_side", texture));
	}

	public void fenceBlockWithRenderType(class_2354 block, class_2960 texture, String renderType) {
		String baseName = key(block).toString();
		fourWayBlock(block,
				models().fencePost(baseName + "_post", texture).renderType(renderType),
				models().fenceSide(baseName + "_side", texture).renderType(renderType));
	}

	public void fenceBlockWithRenderType(class_2354 block, String name, class_2960 texture, String renderType) {
		fourWayBlock(block,
				models().fencePost(name + "_fence_post", texture).renderType(renderType),
				models().fenceSide(name + "_fence_side", texture).renderType(renderType));
	}

	public void fenceBlockWithRenderType(class_2354 block, class_2960 texture, class_2960 renderType) {
		String baseName = key(block).toString();
		fourWayBlock(block,
				models().fencePost(baseName + "_post", texture).renderType(renderType),
				models().fenceSide(baseName + "_side", texture).renderType(renderType));
	}

	public void fenceBlockWithRenderType(class_2354 block, String name, class_2960 texture, class_2960 renderType) {
		fourWayBlock(block,
				models().fencePost(name + "_fence_post", texture).renderType(renderType),
				models().fenceSide(name + "_fence_side", texture).renderType(renderType));
	}

	public void fenceGateBlock(class_2349 block, class_2960 texture) {
		fenceGateBlockInternal(block, key(block).toString(), texture);
	}

	public void fenceGateBlock(class_2349 block, String name, class_2960 texture) {
		fenceGateBlockInternal(block, name + "_fence_gate", texture);
	}

	public void fenceGateBlockWithRenderType(class_2349 block, class_2960 texture, String renderType) {
		fenceGateBlockInternalWithRenderType(block, key(block).toString(), texture, class_2960.method_12829(renderType));
	}

	public void fenceGateBlockWithRenderType(class_2349 block, String name, class_2960 texture, String renderType) {
		fenceGateBlockInternalWithRenderType(block, name + "_fence_gate", texture, class_2960.method_12829(renderType));
	}

	public void fenceGateBlockWithRenderType(class_2349 block, class_2960 texture, class_2960 renderType) {
		fenceGateBlockInternalWithRenderType(block, key(block).toString(), texture, renderType);
	}

	public void fenceGateBlockWithRenderType(class_2349 block, String name, class_2960 texture, class_2960 renderType) {
		fenceGateBlockInternalWithRenderType(block, name + "_fence_gate", texture, renderType);
	}

	private void fenceGateBlockInternal(class_2349 block, String baseName, class_2960 texture) {
		ModelFile gate = models().fenceGate(baseName, texture);
		ModelFile gateOpen = models().fenceGateOpen(baseName + "_open", texture);
		ModelFile gateWall = models().fenceGateWall(baseName + "_wall", texture);
		ModelFile gateWallOpen = models().fenceGateWallOpen(baseName + "_wall_open", texture);
		fenceGateBlock(block, gate, gateOpen, gateWall, gateWallOpen);
	}

	private void fenceGateBlockInternalWithRenderType(class_2349 block, String baseName, class_2960 texture, class_2960 renderType) {
		ModelFile gate = models().fenceGate(baseName, texture).renderType(renderType);
		ModelFile gateOpen = models().fenceGateOpen(baseName + "_open", texture).renderType(renderType);
		ModelFile gateWall = models().fenceGateWall(baseName + "_wall", texture).renderType(renderType);
		ModelFile gateWallOpen = models().fenceGateWallOpen(baseName + "_wall_open", texture).renderType(renderType);
		fenceGateBlock(block, gate, gateOpen, gateWall, gateWallOpen);
	}

	public void fenceGateBlock(class_2349 block, ModelFile gate, ModelFile gateOpen, ModelFile gateWall, ModelFile gateWallOpen) {
		getVariantBuilder(block).forAllStatesExcept(state -> {
			ModelFile model = gate;
			if (state.method_11654(class_2349.field_11024)) {
				model = gateWall;
			}
			if (state.method_11654(class_2349.field_11026)) {
				model = model == gateWall ? gateWallOpen : gateOpen;
			}
			return ConfiguredModel.builder()
					.modelFile(model)
					.rotationY((int) state.method_11654(class_2349.field_11177).method_10144())
					.uvLock(true)
					.build();
		}, class_2349.field_11021);
	}

	public void wallBlock(class_2544 block, class_2960 texture) {
		wallBlockInternal(block, key(block).toString(), texture);
	}

	public void wallBlock(class_2544 block, String name, class_2960 texture) {
		wallBlockInternal(block, name + "_wall", texture);
	}

	public void wallBlockWithRenderType(class_2544 block, class_2960 texture, String renderType) {
		wallBlockInternalWithRenderType(block, key(block).toString(), texture, class_2960.method_12829(renderType));
	}

	public void wallBlockWithRenderType(class_2544 block, String name, class_2960 texture, String renderType) {
		wallBlockInternalWithRenderType(block, name + "_wall", texture, class_2960.method_12829(renderType));
	}

	public void wallBlockWithRenderType(class_2544 block, class_2960 texture, class_2960 renderType) {
		wallBlockInternalWithRenderType(block, key(block).toString(), texture, renderType);
	}

	public void wallBlockWithRenderType(class_2544 block, String name, class_2960 texture, class_2960 renderType) {
		wallBlockInternalWithRenderType(block, name + "_wall", texture, renderType);
	}

	private void wallBlockInternal(class_2544 block, String baseName, class_2960 texture) {
		wallBlock(block, models().wallPost(baseName + "_post", texture),
				models().wallSide(baseName + "_side", texture),
				models().wallSideTall(baseName + "_side_tall", texture));
	}

	private void wallBlockInternalWithRenderType(class_2544 block, String baseName, class_2960 texture, class_2960 renderType) {
		wallBlock(block, models().wallPost(baseName + "_post", texture).renderType(renderType),
				models().wallSide(baseName + "_side", texture).renderType(renderType),
				models().wallSideTall(baseName + "_side_tall", texture).renderType(renderType));
	}

	public static final ImmutableMap<class_2350, class_2769<class_4778>> WALL_PROPS = ImmutableMap.<class_2350, class_2769<class_4778>>builder()
			.put(class_2350.field_11034, class_2741.field_22174)
			.put(class_2350.field_11043, class_2741.field_22175)
			.put(class_2350.field_11035, class_2741.field_22176)
			.put(class_2350.field_11039, class_2741.field_22177)
			.build();

	public void wallBlock(class_2544 block, ModelFile post, ModelFile side, ModelFile sideTall) {
		MultiPartBlockStateBuilder builder = getMultipartBuilder(block)
				.part().modelFile(post).addModel()
				.condition(class_2544.field_11717, true).end();
		WALL_PROPS.entrySet().stream()
				.filter(e -> e.getKey().method_10166().method_10179())
				.forEach(e -> {
					wallSidePart(builder, side, e, class_4778.field_22179);
					wallSidePart(builder, sideTall, e, class_4778.field_22180);
				});
	}

	private void wallSidePart(MultiPartBlockStateBuilder builder, ModelFile model, Map.Entry<class_2350, class_2769<class_4778>> entry, class_4778 height) {
		builder.part()
				.modelFile(model)
				.rotationY((((int) entry.getKey().method_10144()) + 180) % 360)
				.uvLock(true)
				.addModel()
				.condition(entry.getValue(), height);
	}

	public void paneBlock(class_2389 block, class_2960 pane, class_2960 edge) {
		paneBlockInternal(block, key(block).toString(), pane, edge);
	}

	public void paneBlock(class_2389 block, String name, class_2960 pane, class_2960 edge) {
		paneBlockInternal(block, name + "_pane", pane, edge);
	}

	public void paneBlockWithRenderType(class_2389 block, class_2960 pane, class_2960 edge, String renderType) {
		paneBlockInternalWithRenderType(block, key(block).toString(), pane, edge, class_2960.method_12829(renderType));
	}

	public void paneBlockWithRenderType(class_2389 block, String name, class_2960 pane, class_2960 edge, String renderType) {
		paneBlockInternalWithRenderType(block, name + "_pane", pane, edge, class_2960.method_12829(renderType));
	}

	public void paneBlockWithRenderType(class_2389 block, class_2960 pane, class_2960 edge, class_2960 renderType) {
		paneBlockInternalWithRenderType(block, key(block).toString(), pane, edge, renderType);
	}

	public void paneBlockWithRenderType(class_2389 block, String name, class_2960 pane, class_2960 edge, class_2960 renderType) {
		paneBlockInternalWithRenderType(block, name + "_pane", pane, edge, renderType);
	}

	private void paneBlockInternal(class_2389 block, String baseName, class_2960 pane, class_2960 edge) {
		ModelFile post = models().panePost(baseName + "_post", pane, edge);
		ModelFile side = models().paneSide(baseName + "_side", pane, edge);
		ModelFile sideAlt = models().paneSideAlt(baseName + "_side_alt", pane, edge);
		ModelFile noSide = models().paneNoSide(baseName + "_noside", pane);
		ModelFile noSideAlt = models().paneNoSideAlt(baseName + "_noside_alt", pane);
		paneBlock(block, post, side, sideAlt, noSide, noSideAlt);
	}

	private void paneBlockInternalWithRenderType(class_2389 block, String baseName, class_2960 pane, class_2960 edge, class_2960 renderType) {
		ModelFile post = models().panePost(baseName + "_post", pane, edge).renderType(renderType);
		ModelFile side = models().paneSide(baseName + "_side", pane, edge).renderType(renderType);
		ModelFile sideAlt = models().paneSideAlt(baseName + "_side_alt", pane, edge).renderType(renderType);
		ModelFile noSide = models().paneNoSide(baseName + "_noside", pane).renderType(renderType);
		ModelFile noSideAlt = models().paneNoSideAlt(baseName + "_noside_alt", pane).renderType(renderType);
		paneBlock(block, post, side, sideAlt, noSide, noSideAlt);
	}

	public void paneBlock(class_2389 block, ModelFile post, ModelFile side, ModelFile sideAlt, ModelFile noSide, ModelFile noSideAlt) {
		MultiPartBlockStateBuilder builder = getMultipartBuilder(block)
				.part().modelFile(post).addModel().end();
		class_2429.field_11329.entrySet().forEach(e -> {
			class_2350 dir = e.getKey();
			if (dir.method_10166().method_10179()) {
				boolean alt = dir == class_2350.field_11035;
				builder.part().modelFile(alt || dir == class_2350.field_11039 ? sideAlt : side).rotationY(dir.method_10166() == class_2351.field_11048 ? 90 : 0).addModel()
						.condition(e.getValue(), true).end()
						.part().modelFile(alt || dir == class_2350.field_11034 ? noSideAlt : noSide).rotationY(dir == class_2350.field_11039 ? 270 : dir == class_2350.field_11035 ? 90 : 0).addModel()
						.condition(e.getValue(), false);
			}
		});
	}

	public void doorBlock(class_2323 block, class_2960 bottom, class_2960 top) {
		doorBlockInternal(block, key(block).toString(), bottom, top);
	}

	public void doorBlock(class_2323 block, String name, class_2960 bottom, class_2960 top) {
		doorBlockInternal(block, name + "_door", bottom, top);
	}

	public void doorBlockWithRenderType(class_2323 block, class_2960 bottom, class_2960 top, String renderType) {
		doorBlockInternalWithRenderType(block, key(block).toString(), bottom, top, class_2960.method_12829(renderType));
	}

	public void doorBlockWithRenderType(class_2323 block, String name, class_2960 bottom, class_2960 top, String renderType) {
		doorBlockInternalWithRenderType(block, name + "_door", bottom, top, class_2960.method_12829(renderType));
	}

	public void doorBlockWithRenderType(class_2323 block, class_2960 bottom, class_2960 top, class_2960 renderType) {
		doorBlockInternalWithRenderType(block, key(block).toString(), bottom, top, renderType);
	}

	public void doorBlockWithRenderType(class_2323 block, String name, class_2960 bottom, class_2960 top, class_2960 renderType) {
		doorBlockInternalWithRenderType(block, name + "_door", bottom, top, renderType);
	}

	private void doorBlockInternal(class_2323 block, String baseName, class_2960 bottom, class_2960 top) {
		ModelFile bottomLeft = models().doorBottomLeft(baseName + "_bottom_left", bottom, top);
		ModelFile bottomLeftOpen = models().doorBottomLeftOpen(baseName + "_bottom_left_open", bottom, top);
		ModelFile bottomRight = models().doorBottomRight(baseName + "_bottom_right", bottom, top);
		ModelFile bottomRightOpen = models().doorBottomRightOpen(baseName + "_bottom_right_open", bottom, top);
		ModelFile topLeft = models().doorTopLeft(baseName + "_top_left", bottom, top);
		ModelFile topLeftOpen = models().doorTopLeftOpen(baseName + "_top_left_open", bottom, top);
		ModelFile topRight = models().doorTopRight(baseName + "_top_right", bottom, top);
		ModelFile topRightOpen = models().doorTopRightOpen(baseName + "_top_right_open", bottom, top);
		doorBlock(block, bottomLeft, bottomLeftOpen, bottomRight, bottomRightOpen, topLeft, topLeftOpen, topRight, topRightOpen);
	}

	private void doorBlockInternalWithRenderType(class_2323 block, String baseName, class_2960 bottom, class_2960 top, class_2960 renderType) {
		ModelFile bottomLeft = models().doorBottomLeft(baseName + "_bottom_left", bottom, top).renderType(renderType);
		ModelFile bottomLeftOpen = models().doorBottomLeftOpen(baseName + "_bottom_left_open", bottom, top).renderType(renderType);
		ModelFile bottomRight = models().doorBottomRight(baseName + "_bottom_right", bottom, top).renderType(renderType);
		ModelFile bottomRightOpen = models().doorBottomRightOpen(baseName + "_bottom_right_open", bottom, top).renderType(renderType);
		ModelFile topLeft = models().doorTopLeft(baseName + "_top_left", bottom, top).renderType(renderType);
		ModelFile topLeftOpen = models().doorTopLeftOpen(baseName + "_top_left_open", bottom, top).renderType(renderType);
		ModelFile topRight = models().doorTopRight(baseName + "_top_right", bottom, top).renderType(renderType);
		ModelFile topRightOpen = models().doorTopRightOpen(baseName + "_top_right_open", bottom, top).renderType(renderType);
		doorBlock(block, bottomLeft, bottomLeftOpen, bottomRight, bottomRightOpen, topLeft, topLeftOpen, topRight, topRightOpen);
	}

	public void doorBlock(class_2323 block, ModelFile bottomLeft, ModelFile bottomLeftOpen, ModelFile bottomRight, ModelFile bottomRightOpen, ModelFile topLeft, ModelFile topLeftOpen, ModelFile topRight, ModelFile topRightOpen) {
		getVariantBuilder(block).forAllStatesExcept(state -> {
			int yRot = ((int) state.method_11654(class_2323.field_10938).method_10144()) + 90;
			boolean right = state.method_11654(class_2323.field_10941) == class_2750.field_12586;
			boolean open = state.method_11654(class_2323.field_10945);
			boolean lower = state.method_11654(class_2323.field_10946) == class_2756.field_12607;
			if (open) {
				yRot += 90;
			}
			if (right && open) {
				yRot += 180;
			}
			yRot %= 360;

			ModelFile model = null;
			if (lower && right && open) {
				model = bottomRightOpen;
			} else if (lower && !right && open) {
				model = bottomLeftOpen;
			}
			if (lower && right && !open) {
				model = bottomRight;
			} else if (lower && !right && !open) {
				model = bottomLeft;
			}
			if (!lower && right && open) {
				model = topRightOpen;
			} else if (!lower && !right && open) {
				model = topLeftOpen;
			}
			if (!lower && right && !open) {
				model = topRight;
			} else if (!lower && !right && !open) {
				model = topLeft;
			}

			return ConfiguredModel.builder().modelFile(model)
					.rotationY(yRot)
					.build();
		}, class_2323.field_10940);
	}

	public void trapdoorBlock(class_2533 block, class_2960 texture, boolean orientable) {
		trapdoorBlockInternal(block, key(block).toString(), texture, orientable);
	}

	public void trapdoorBlock(class_2533 block, String name, class_2960 texture, boolean orientable) {
		trapdoorBlockInternal(block, name + "_trapdoor", texture, orientable);
	}

	public void trapdoorBlockWithRenderType(class_2533 block, class_2960 texture, boolean orientable, String renderType) {
		trapdoorBlockInternalWithRenderType(block, key(block).toString(), texture, orientable, class_2960.method_12829(renderType));
	}

	public void trapdoorBlockWithRenderType(class_2533 block, String name, class_2960 texture, boolean orientable, String renderType) {
		trapdoorBlockInternalWithRenderType(block, name + "_trapdoor", texture, orientable, class_2960.method_12829(renderType));
	}

	public void trapdoorBlockWithRenderType(class_2533 block, class_2960 texture, boolean orientable, class_2960 renderType) {
		trapdoorBlockInternalWithRenderType(block, key(block).toString(), texture, orientable, renderType);
	}

	public void trapdoorBlockWithRenderType(class_2533 block, String name, class_2960 texture, boolean orientable, class_2960 renderType) {
		trapdoorBlockInternalWithRenderType(block, name + "_trapdoor", texture, orientable, renderType);
	}

	private void trapdoorBlockInternal(class_2533 block, String baseName, class_2960 texture, boolean orientable) {
		ModelFile bottom = orientable ? models().trapdoorOrientableBottom(baseName + "_bottom", texture) : models().trapdoorBottom(baseName + "_bottom", texture);
		ModelFile top = orientable ? models().trapdoorOrientableTop(baseName + "_top", texture) : models().trapdoorTop(baseName + "_top", texture);
		ModelFile open = orientable ? models().trapdoorOrientableOpen(baseName + "_open", texture) : models().trapdoorOpen(baseName + "_open", texture);
		trapdoorBlock(block, bottom, top, open, orientable);
	}

	private void trapdoorBlockInternalWithRenderType(class_2533 block, String baseName, class_2960 texture, boolean orientable, class_2960 renderType) {
		ModelFile bottom = orientable ? models().trapdoorOrientableBottom(baseName + "_bottom", texture).renderType(renderType) : models().trapdoorBottom(baseName + "_bottom", texture).renderType(renderType);
		ModelFile top = orientable ? models().trapdoorOrientableTop(baseName + "_top", texture).renderType(renderType) : models().trapdoorTop(baseName + "_top", texture).renderType(renderType);
		ModelFile open = orientable ? models().trapdoorOrientableOpen(baseName + "_open", texture).renderType(renderType) : models().trapdoorOpen(baseName + "_open", texture).renderType(renderType);
		trapdoorBlock(block, bottom, top, open, orientable);
	}

	public void trapdoorBlock(class_2533 block, ModelFile bottom, ModelFile top, ModelFile open, boolean orientable) {
		getVariantBuilder(block).forAllStatesExcept(state -> {
			int xRot = 0;
			int yRot = ((int) state.method_11654(class_2533.field_11177).method_10144()) + 180;
			boolean isOpen = state.method_11654(class_2533.field_11631);
			if (orientable && isOpen && state.method_11654(class_2533.field_11625) == class_2760.field_12619) {
				xRot += 180;
				yRot += 180;
			}
			if (!orientable && !isOpen) {
				yRot = 0;
			}
			yRot %= 360;
			return ConfiguredModel.builder().modelFile(isOpen ? open : state.method_11654(class_2533.field_11625) == class_2760.field_12619 ? top : bottom)
					.rotationX(xRot)
					.rotationY(yRot)
					.build();
		}, class_2533.field_11629, class_2533.field_11626);
	}

	private CompletableFuture<?> saveBlockState(class_7403 cache, JsonObject stateJson, class_2248 owner) {
		class_2960 blockName = Preconditions.checkNotNull(key(owner));
		Path outputPath = this.output.method_45972(class_7784.class_7490.field_39368)
				.resolve(blockName.method_12836()).resolve("blockstates").resolve(blockName.method_12832() + ".json");
		return class_2405.method_10320(cache, stateJson, outputPath);
	}

	@Override
	public String method_10321() {
		return "Block States: " + modid;
	}

	public static class ConfiguredModelList {
		private final List<ConfiguredModel> models;

		private ConfiguredModelList(List<ConfiguredModel> models) {
			Preconditions.checkArgument(!models.isEmpty());
			this.models = models;
		}

		public ConfiguredModelList(ConfiguredModel model) {
			this(ImmutableList.of(model));
		}

		public ConfiguredModelList(ConfiguredModel... models) {
			this(Arrays.asList(models));
		}

		public JsonElement toJSON() {
			if (models.size() == 1) {
				return models.get(0).toJSON(false);
			} else {
				JsonArray ret = new JsonArray();
				for (ConfiguredModel m : models) {
					ret.add(m.toJSON(true));
				}
				return ret;
			}
		}

		public ConfiguredModelList append(ConfiguredModel... models) {
			return new ConfiguredModelList(ImmutableList.<ConfiguredModel>builder().addAll(this.models).add(models).build());
		}
	}
}
