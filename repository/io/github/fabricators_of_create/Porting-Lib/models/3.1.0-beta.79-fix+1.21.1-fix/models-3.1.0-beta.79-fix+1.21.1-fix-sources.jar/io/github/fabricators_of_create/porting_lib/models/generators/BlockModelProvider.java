package io.github.fabricators_of_create.porting_lib.models.generators;

import io.github.fabricators_of_create.porting_lib.data.ExistingFileHelper;
import net.minecraft.class_7784;
import org.jetbrains.annotations.NotNull;

/**
 * Stub class to extend for block model data providers, eliminates some
 * boilerplate constructor parameters.
 */
public abstract class BlockModelProvider extends ModelProvider<BlockModelBuilder> {

	public BlockModelProvider(class_7784 output, String modid, ExistingFileHelper existingFileHelper) {
		super(output, modid, BLOCK_FOLDER, BlockModelBuilder::new, existingFileHelper);
	}

	@NotNull
	@Override
	public String method_10321() {
		return "Block Models: " + modid;
	}
}
