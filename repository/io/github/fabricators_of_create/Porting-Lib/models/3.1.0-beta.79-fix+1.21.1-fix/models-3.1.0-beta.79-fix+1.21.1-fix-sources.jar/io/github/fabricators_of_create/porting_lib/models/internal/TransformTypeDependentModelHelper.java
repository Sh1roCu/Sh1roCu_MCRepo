package io.github.fabricators_of_create.porting_lib.models.internal;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;

import com.llamalad7.mixinextras.sugar.ref.LocalRef;

import io.github.fabricators_of_create.porting_lib.models.TransformTypeDependentItemBakedModel;
import io.github.fabricators_of_create.porting_lib.models.TransformTypeDependentItemBakedModel.DefaultTransform;

import io.github.fabricators_of_create.porting_lib.models.mixin.client.ItemRendererMixin;
import net.minecraft.class_1087;
import net.minecraft.class_4587;
import net.minecraft.class_811;
import org.jetbrains.annotations.ApiStatus.Internal;

/**
 * Common code used in {@link ItemRendererMixin}
 */
@Internal
public class TransformTypeDependentModelHelper {
	public static void handleTransformations(class_1087 originalModel, class_811 ctx, boolean leftHanded, class_4587 poseStack,
											 Operation<Void> original, LocalRef<class_1087> transformedRef) {
		DefaultTransformImpl.INSTANCE.setup(original, ctx, leftHanded, poseStack);
		class_1087 transformed = TransformTypeDependentItemBakedModel
				.maybeApplyTransform(originalModel, ctx, poseStack, leftHanded, DefaultTransformImpl.INSTANCE);

		if (transformed != null) { // transform applied
			if (transformed != originalModel) { // model changed, store new one
				transformedRef.set(transformed);
			}
		} else { // no custom transform, apply default
			DefaultTransformImpl.INSTANCE.apply(originalModel);
		}
	}

	public static class_1087 getTransformedModel(class_1087 model, LocalRef<class_1087> transformedRef) {
		class_1087 transformed = transformedRef.get();
		return transformed != null ? transformed : model;
	}

	public enum DefaultTransformImpl implements DefaultTransform {
		INSTANCE;

		private Operation<Void> original;
		private class_811 ctx;
		private boolean leftHanded;
		private class_4587 poseStack;

		@Override
		public void apply(class_1087 model) {
			original.call(model.method_4709().method_3503(ctx), leftHanded, poseStack);
		}

		private void setup(Operation<Void> original, class_811 ctx, boolean leftHanded, class_4587 poseStack) {
			this.original = original;
			this.ctx = ctx;
			this.leftHanded = leftHanded;
			this.poseStack = poseStack;
		}
	}
}
