package io.github.fabricators_of_create.porting_lib.models.pipeline;

import net.minecraft.class_4588;
import net.minecraft.class_4590;
import org.joml.Vector3f;
import org.joml.Vector4f;

/**
 * Vertex pipeline element that applies a transformation to incoming geometry.
 */
public class TransformingVertexPipeline extends VertexConsumerWrapper {
	private final class_4590 transformation;

	public TransformingVertexPipeline(class_4588 parent, class_4590 transformation) {
		super(parent);
		this.transformation = transformation;
	}

	@Override
	public class_4588 method_22912(float x, float y, float z) {
		var vec = new Vector4f(x, y, z, 1);
		transformation.transformPosition(vec);
		vec.div(vec.w);
		return super.method_22912(vec.x(), vec.y(), vec.z());
	}

	@Override
	public class_4588 method_22914(float x, float y, float z) {
		var vec = new Vector3f(x, y, z);
		transformation.transformNormal(vec);
		vec.normalize();
		return super.method_22914(vec.x(), vec.y(), vec.z());
	}
}
