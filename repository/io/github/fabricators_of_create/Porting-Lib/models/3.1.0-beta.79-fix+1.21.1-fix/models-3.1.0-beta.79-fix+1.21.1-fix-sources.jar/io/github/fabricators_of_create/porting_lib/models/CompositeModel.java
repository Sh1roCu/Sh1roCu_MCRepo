package io.github.fabricators_of_create.porting_lib.models;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Supplier;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.models.geometry.IGeometryBakingContext;
import io.github.fabricators_of_create.porting_lib.models.geometry.IGeometryLoader;
import io.github.fabricators_of_create.porting_lib.models.geometry.IUnbakedGeometry;
import io.github.fabricators_of_create.porting_lib.render_types.RenderTypeGroup;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1100;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_806;
import net.minecraft.class_809;
import org.jetbrains.annotations.Nullable;

/**
 * A model composed of several named children.
 * <p>
 * These respect component visibility as specified in {@link IGeometryBakingContext} and can additionally be provided
 * with an item-specific render ordering, for multi-pass arrangements.
 */
public class CompositeModel implements IUnbakedGeometry<CompositeModel> {
	private final ImmutableMap<String, class_793> children;
	private final ImmutableList<String> itemPasses;

	public CompositeModel(ImmutableMap<String, class_793> children, ImmutableList<String> itemPasses) {
		this.children = children;
		this.itemPasses = itemPasses;
	}

	@Override
	public class_1087 bake(IGeometryBakingContext context, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelState, class_806 overrides) {
		class_4730 particleLocation = context.getMaterial("particle");
		class_1058 particle = spriteGetter.apply(particleLocation);

		var rootTransform = context.getRootTransform();
		if (!rootTransform.isIdentity())
			modelState = UnbakedGeometryHelper.composeRootTransformIntoModelState(modelState, rootTransform);

		var bakedPartsBuilder = ImmutableMap.<String, class_1087>builder();
		for (var entry : children.entrySet()) {
			var name = entry.getKey();
			if (!context.isComponentVisible(name, true))
				continue;
			var model = entry.getValue();
			bakedPartsBuilder.put(name, model.method_3446(baker, model, spriteGetter, modelState, true));
		}
		var bakedParts = bakedPartsBuilder.build();

		var itemPassesBuilder = ImmutableList.<class_1087>builder();
		for (String name : this.itemPasses) {
			var model = bakedParts.get(name);
			if (model == null)
				throw new IllegalStateException("Specified \"" + name + "\" in \"item_render_order\", but that is not a child of this model.");
			itemPassesBuilder.add(model);
		}

		return new Baked(context.isGui3d(), context.useBlockLight(), context.useAmbientOcclusion(), particle, context.getTransforms(), overrides, bakedParts, itemPassesBuilder.build());
	}

	@Override
	public void resolveParents(Function<class_2960, class_1100> modelGetter, IGeometryBakingContext context) {
		children.values().forEach(child -> child.method_45785(modelGetter));
	}

	@Override
	public Set<String> getConfigurableComponentNames() {
		return children.keySet();
	}

	public static class Baked implements class_1087 {
		private final boolean isAmbientOcclusion;
		private final boolean isGui3d;
		private final boolean isSideLit;
		private final class_1058 particle;
		private final class_806 overrides;
		private final class_809 transforms;
		private final ImmutableMap<String, class_1087> children;
		private final ImmutableList<class_1087> itemPasses;

		public Baked(boolean isGui3d, boolean isSideLit, boolean isAmbientOcclusion, class_1058 particle, class_809 transforms, class_806 overrides, ImmutableMap<String, class_1087> children, ImmutableList<class_1087> itemPasses) {
			this.children = children;
			this.isAmbientOcclusion = isAmbientOcclusion;
			this.isGui3d = isGui3d;
			this.isSideLit = isSideLit;
			this.particle = particle;
			this.overrides = overrides;
			this.transforms = transforms;
			this.itemPasses = itemPasses;
		}

		@Override
		public List<class_777> method_4707(@Nullable class_2680 state, @Nullable class_2350 side, class_5819 rand/*, ModelData data, @Nullable RenderType renderType*/) {
			List<List<class_777>> quadLists = new ArrayList<>();
			PortingLib.LOGGER.warn("Called CompositeModel getQuads which does not support multi render type support: " + Arrays.toString(Thread.currentThread().getStackTrace()));
			for (Map.Entry<String, class_1087> entry : children.entrySet()) {
//				if (renderType == null || (state != null && entry.getValue().getRenderTypes(state, rand, data).contains(renderType))) {
					quadLists.add(entry.getValue().method_4707(state, side, rand/*, CompositeModel.Data.resolve(data, entry.getKey()), renderType*/));
//				}
			}
			return ConcatenatedListView.of(quadLists);
		}

		@Override
		public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
			for (Map.Entry<String, class_1087> entry : children.entrySet()) {
				entry.getValue().emitBlockQuads(blockView, state, pos, randomSupplier, context);
			}
		}

		@Override
		public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
			for (Map.Entry<String, class_1087> entry : children.entrySet()) {
				entry.getValue().emitItemQuads(stack, randomSupplier, context);
			}
		}

		@Override
		public boolean isVanillaAdapter() {
			return false;
		}

		@Override
		public boolean method_4708() {
			return isAmbientOcclusion;
		}

		@Override
		public boolean method_4712() {
			return isGui3d;
		}

		@Override
		public boolean method_24304() {
			return isSideLit;
		}

		@Override
		public boolean method_4713() {
			return false;
		}

		@Override
		public class_1058 method_4711() {
			return particle;
		}

		@Override
		public class_806 method_4710() {
			return overrides;
		}

		@Override
		public class_809 method_4709() {
			return transforms;
		}

//		@Override
//		public ChunkRenderTypeSet getRenderTypes(BlockState state, RandomSource rand, ModelData data) {
//			var sets = new ArrayList<ChunkRenderTypeSet>();
//			for (Map.Entry<String, BakedModel> entry : children.entrySet())
//				sets.add(entry.getValue().getRenderTypes(state, rand, CompositeModel.Data.resolve(data, entry.getKey())));
//			return ChunkRenderTypeSet.union(sets);
//		}
//
//		@Override
//		public List<BakedModel> getRenderPasses(ItemStack itemStack, boolean fabulous) {
//			return itemPasses;
//		}

		@Nullable
		public class_1087 getPart(String name) {
			return children.get(name);
		}

		public static io.github.fabricators_of_create.porting_lib.models.CompositeModel.Baked.Builder builder(IGeometryBakingContext owner, class_1058 particle, class_806 overrides, class_809 cameraTransforms) {
			return builder(owner.useAmbientOcclusion(), owner.isGui3d(), owner.useBlockLight(), particle, overrides, cameraTransforms);
		}

		public static io.github.fabricators_of_create.porting_lib.models.CompositeModel.Baked.Builder builder(boolean isAmbientOcclusion, boolean isGui3d, boolean isSideLit, class_1058 particle, class_806 overrides, class_809 cameraTransforms) {
			return new io.github.fabricators_of_create.porting_lib.models.CompositeModel.Baked.Builder(isAmbientOcclusion, isGui3d, isSideLit, particle, overrides, cameraTransforms);
		}

		public static class Builder {
			private final boolean isAmbientOcclusion;
			private final boolean isGui3d;
			private final boolean isSideLit;
			private final List<class_1087> children = new ArrayList<>();
			private final List<class_777> quads = new ArrayList<>();
			private final class_806 overrides;
			private final class_809 transforms;
			private class_1058 particle;
			private RenderTypeGroup lastRenderTypes = RenderTypeGroup.EMPTY;

			private Builder(boolean isAmbientOcclusion, boolean isGui3d, boolean isSideLit, class_1058 particle, class_806 overrides, class_809 transforms) {
				this.isAmbientOcclusion = isAmbientOcclusion;
				this.isGui3d = isGui3d;
				this.isSideLit = isSideLit;
				this.particle = particle;
				this.overrides = overrides;
				this.transforms = transforms;
			}

			public void addLayer(class_1087 model) {
				flushQuads(null);
				children.add(model);
			}

			private void addLayer(RenderTypeGroup renderTypes, List<class_777> quads) {
				var modelBuilder = IModelBuilder.of(isAmbientOcclusion, isSideLit, isGui3d, transforms, overrides, particle, renderTypes);
				quads.forEach(modelBuilder::addUnculledFace);
				children.add(modelBuilder.build());
			}

			private void flushQuads(RenderTypeGroup renderTypes) {
				if (!Objects.equals(renderTypes, lastRenderTypes)) {
					if (quads.size() > 0) {
						addLayer(lastRenderTypes, quads);
						quads.clear();
					}
					lastRenderTypes = renderTypes;
				}
			}

			public io.github.fabricators_of_create.porting_lib.models.CompositeModel.Baked.Builder setParticle(class_1058 particleSprite) {
				this.particle = particleSprite;
				return this;
			}

			public io.github.fabricators_of_create.porting_lib.models.CompositeModel.Baked.Builder addQuads(RenderTypeGroup renderTypes, class_777... quadsToAdd) {
				flushQuads(renderTypes);
				Collections.addAll(quads, quadsToAdd);
				return this;
			}

			public io.github.fabricators_of_create.porting_lib.models.CompositeModel.Baked.Builder addQuads(RenderTypeGroup renderTypes, Collection<class_777> quadsToAdd) {
				flushQuads(renderTypes);
				quads.addAll(quadsToAdd);
				return this;
			}

			public class_1087 build() {
				if (quads.size() > 0) {
					addLayer(lastRenderTypes, quads);
				}
				var childrenBuilder = ImmutableMap.<String, class_1087>builder();
				var itemPassesBuilder = ImmutableList.<class_1087>builder();
				int i = 0;
				for (var model : this.children) {
					childrenBuilder.put("model_" + (i++), model);
					itemPassesBuilder.add(model);
				}
				return new Baked(isGui3d, isSideLit, isAmbientOcclusion, particle, transforms, overrides, childrenBuilder.build(), itemPassesBuilder.build());
			}
		}
	}

//	/**
//	 * A model data container which stores data for child components.
//	 */
//	public static class Data {
//		public static final ModelProperty<Data> PROPERTY = new ModelProperty<>();
//
//		private final Map<String, ModelData> partData;
//
//		private Data(Map<String, ModelData> partData) {
//			this.partData = partData;
//		}
//
//		@Nullable
//		public ModelData get(String name) {
//			return partData.get(name);
//		}
//
//		/**
//		 * Helper to get the data from a {@link ModelData} instance.
//		 *
//		 * @param modelData The object to get data from
//		 * @param name      The name of the part to get data for
//		 * @return The data for the part, or the one passed in if not found
//		 */
//		public static ModelData resolve(ModelData modelData, String name) {
//			var compositeData = modelData.get(PROPERTY);
//			if (compositeData == null)
//				return modelData;
//			var partData = compositeData.get(name);
//			return partData != null ? partData : modelData;
//		}
//
//		public static Builder builder() {
//			return new Builder();
//		}
//
//		public static final class Builder {
//			private final Map<String, ModelData> partData = new IdentityHashMap<>();
//
//			public Builder with(String name, ModelData data) {
//				partData.put(name, data);
//				return this;
//			}
//
//			public Data build() {
//				return new Data(partData);
//			}
//		}
//	}

	public static final class Loader implements IGeometryLoader<CompositeModel> {
		public static final Loader INSTANCE = new Loader();

		private Loader() {}

		@Override
		public CompositeModel read(JsonObject jsonObject, JsonDeserializationContext deserializationContext) {
			List<String> itemPasses = new ArrayList<>();
			ImmutableMap.Builder<String, class_793> childrenBuilder = ImmutableMap.builder();
			readChildren(jsonObject, "children", deserializationContext, childrenBuilder, itemPasses);

			var children = childrenBuilder.build();
			if (children.isEmpty())
				throw new JsonParseException("Composite model requires a \"children\" element with at least one element.");

			if (jsonObject.has("item_render_order")) {
				itemPasses.clear();
				for (var element : jsonObject.getAsJsonArray("item_render_order")) {
					var name = element.getAsString();
					if (!children.containsKey(name))
						throw new JsonParseException("Specified \"" + name + "\" in \"item_render_order\", but that is not a child of this model.");
					itemPasses.add(name);
				}
			}

			return new CompositeModel(children, ImmutableList.copyOf(itemPasses));
		}

		private void readChildren(JsonObject jsonObject, String name, JsonDeserializationContext deserializationContext, ImmutableMap.Builder<String, class_793> children, List<String> itemPasses) {
			if (!jsonObject.has(name))
				return;
			var childrenJsonObject = jsonObject.getAsJsonObject(name);
			for (Map.Entry<String, JsonElement> entry : childrenJsonObject.entrySet()) {
				children.put(entry.getKey(), deserializationContext.deserialize(entry.getValue(), class_793.class));
				itemPasses.add(entry.getKey()); // We can do this because GSON preserves ordering during deserialization
			}
		}
	}
}
