package io.github.fabricators_of_create.porting_lib.models;

import com.google.gson.JsonObject;
import net.minecraft.class_1100;
import net.minecraft.class_793;

public interface ModelLoader {
	class_1100 readModel(class_793 parent, JsonObject jsonObject);
}
