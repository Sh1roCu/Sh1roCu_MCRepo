package io.github.fabricators_of_create.porting_lib.models.injections;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import net.minecraft.class_1088;

public interface ModelManagerInjection {
	default class_1088 port_lib$getModelBakery() {
		throw PortingLib.createMixinException("ModelManagerInjection#getModelBakery");
	}
}
