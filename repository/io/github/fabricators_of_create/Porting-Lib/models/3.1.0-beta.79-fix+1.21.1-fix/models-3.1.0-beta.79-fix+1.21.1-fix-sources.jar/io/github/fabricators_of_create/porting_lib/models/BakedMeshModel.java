package io.github.fabricators_of_create.porting_lib.models;

import net.fabricmc.fabric.api.renderer.v1.mesh.Mesh;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.model.ModelHelper;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_793;
import net.minecraft.class_806;
import net.minecraft.class_809;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;

public record BakedMeshModel(class_793 parent, class_1058 particle, Mesh mesh) implements class_1087, FabricBakedModel {
	@Override
	public boolean isVanillaAdapter() {
		return false;
	}

	@Override
	public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
		context.meshConsumer().accept(mesh);
	}

	@Override
	public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
		context.meshConsumer().accept(mesh);
	}

	@Override
	public List<class_777> method_4707(@Nullable class_2680 blockState, @Nullable class_2350 side, class_5819 randomSource) {
		return ModelHelper.toQuadLists(mesh)[side == null ? ModelHelper.NULL_FACE_ID : side.method_10146()];
	}

	@Override
	public boolean method_4708() {
		return parent.method_3444();
	}

	@Override
	public boolean method_4712() {
		return true;
	}

	@Override
	public boolean method_24304() {
		return parent.method_24298().method_24299();
	}

	@Override
	public boolean method_4713() {
		return false;
	}

	@Override
	public class_1058 method_4711() {
		return particle;
	}

	@Override
	public class_809 method_4709() {
		return parent.method_3443();
	}

	@Override
	public class_806 method_4710() {
		return class_806.field_4292;
	}
}
