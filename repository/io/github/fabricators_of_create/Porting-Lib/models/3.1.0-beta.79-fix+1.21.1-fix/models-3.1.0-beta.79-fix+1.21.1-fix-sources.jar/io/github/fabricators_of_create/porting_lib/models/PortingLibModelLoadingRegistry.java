package io.github.fabricators_of_create.porting_lib.models;

import com.google.gson.Gson;

import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_793;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public enum PortingLibModelLoadingRegistry implements ModelLoadingPlugin {
	INSTANCE;

	public static final Map<class_2960, ModelLoader> LOADERS = new HashMap<>();

	public static final Gson GSON = class_793.field_4254.newBuilder().registerTypeAdapter(RenderMaterial.class, new RenderMaterialDeserializer()).create();

	@Override
	public void onInitializeModelLoader(Context ctx) {}

	/**
	 * Get a reader for the model associated with the provided ID.
	 * The provided ID is converted from model format (minecraft:block/stone) to file format (minecraft:models/block/stone.json)
	 * @throws IOException on an IO error
	 * @throws FileNotFoundException when the model's resource does not exist
	 */
	public static BufferedReader getModelJson(class_2960 location) throws IOException {
		class_2960 file = class_2960.method_60655(location.method_12836(), "models/" + location.method_12832() + ".json");
		Optional<class_3298> resource = class_310.method_1551().method_1478().method_14486(file);
		return resource.orElseThrow(() -> new FileNotFoundException(file.toString())).method_43039();
	}
}
