package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import io.github.fabricators_of_create.porting_lib.models.injections.ModelBakerInjection;
import net.minecraft.class_7775;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_7775.class)
public interface ModelBakerMixin extends ModelBakerInjection {
}
