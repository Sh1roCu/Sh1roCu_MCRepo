package io.github.fabricators_of_create.porting_lib.models;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.models.geometry.RegisterGeometryLoadersCallback;
import io.github.fabricators_of_create.porting_lib.models.util.TransformationHelper;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.minecraft.class_1091;
import net.minecraft.class_2960;
import net.minecraft.class_4590;
import net.minecraft.class_793;

public class PortingLibModels implements ClientModInitializer {
	public static final String STANDALONE_VARIANT = "standalone";

	public static class_1091 standalone(class_2960 id) {
		return new class_1091(id, STANDALONE_VARIANT);
	}

	@Override
	public void onInitializeClient() {
		ModelLoadingPlugin.register(PortingLibModelLoadingRegistry.INSTANCE);

		RegisterGeometryLoadersCallback.EVENT.register(loaders -> {
			loaders.put(PortingLib.id("elements"), ElementsModel.Loader.INSTANCE);

			loaders.put(PortingLib.id("composite"), CompositeModel.Loader.INSTANCE);
			loaders.put(PortingLib.id("item_layers"), ItemLayerModel.Loader.INSTANCE);
			loaders.put(PortingLib.id("separate_transforms"), SeparateTransformsModel.Loader.INSTANCE);

			loaders.put(PortingLib.id("fluid_container"), DynamicFluidContainerModel.Loader.INSTANCE);
		});
		class_793.field_4254 = class_793.field_4254.newBuilder()
				.registerTypeAdapter(class_4590.class, new TransformationHelper.Deserializer())
				.create();
	}
}
