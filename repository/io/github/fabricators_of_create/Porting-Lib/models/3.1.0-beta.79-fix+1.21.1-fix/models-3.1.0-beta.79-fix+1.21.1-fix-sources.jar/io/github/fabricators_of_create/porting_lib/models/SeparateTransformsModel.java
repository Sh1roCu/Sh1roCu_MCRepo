package io.github.fabricators_of_create.porting_lib.models;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Supplier;

import io.github.fabricators_of_create.porting_lib.models.geometry.IGeometryBakingContext;
import io.github.fabricators_of_create.porting_lib.models.geometry.IGeometryLoader;
import io.github.fabricators_of_create.porting_lib.models.geometry.IUnbakedGeometry;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1100;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_3665;
import net.minecraft.class_4587;
import net.minecraft.class_4730;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_806;
import net.minecraft.class_809;
import net.minecraft.class_811;
import org.jetbrains.annotations.Nullable;

/**
 * A model composed of multiple sub-models which are picked based on the {@link class_811} being used.
 */
public class SeparateTransformsModel implements IUnbakedGeometry<SeparateTransformsModel> {
	private final class_793 baseModel;
	private final ImmutableMap<class_811, class_793> perspectives;

	public SeparateTransformsModel(class_793 baseModel, ImmutableMap<class_811, class_793> perspectives) {
		this.baseModel = baseModel;
		this.perspectives = perspectives;
	}

	@Override
	public class_1087 bake(IGeometryBakingContext context, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelState, class_806 overrides) {
		return new Baked(
				context.useAmbientOcclusion(), context.isGui3d(), context.useBlockLight(),
				spriteGetter.apply(context.getMaterial("particle")), overrides,
				baseModel.method_3446(baker, baseModel, spriteGetter, modelState, context.useBlockLight()),
				ImmutableMap.copyOf(Maps.transformValues(perspectives, value -> {
					return value.bake(baker, value, spriteGetter, modelState, context.useBlockLight());
				})));
	}

	@Override
	public void resolveParents(Function<class_2960, class_1100> modelGetter, IGeometryBakingContext context) {
		baseModel.method_45785(modelGetter);
		perspectives.values().forEach(model -> model.method_45785(modelGetter));
	}

	public static class Baked implements class_1087, TransformTypeDependentItemBakedModel {
		private final boolean isAmbientOcclusion;
		private final boolean isGui3d;
		private final boolean isSideLit;
		private final class_1058 particle;
		private final class_806 overrides;
		private final class_1087 baseModel;
		private final ImmutableMap<class_811, class_1087> perspectives;

		public Baked(boolean isAmbientOcclusion, boolean isGui3d, boolean isSideLit, class_1058 particle, class_806 overrides, class_1087 baseModel, ImmutableMap<class_811, class_1087> perspectives) {
			this.isAmbientOcclusion = isAmbientOcclusion;
			this.isGui3d = isGui3d;
			this.isSideLit = isSideLit;
			this.particle = particle;
			this.overrides = overrides;
			this.baseModel = baseModel;
			this.perspectives = perspectives;
		}

		@Override
		public List<class_777> method_4707(@Nullable class_2680 state, @Nullable class_2350 direction, class_5819 random) {
			return baseModel.method_4707(state, direction, random);
		}

		@Override
		public boolean isVanillaAdapter() {
			return false;
		}

		@Override
		public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
			baseModel.emitBlockQuads(blockView, state, pos, randomSupplier, context);
		}

		@Override
		public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
			baseModel.emitItemQuads(stack, randomSupplier, context);
		}

		@Override
		public boolean method_4708() {
			return isAmbientOcclusion;
		}

		@Override
		public boolean method_4712() {
			return isGui3d;
		}

		@Override
		public boolean method_24304() {
			return isSideLit;
		}

		@Override
		public boolean method_4713() {
			return false;
		}

		@Override
		public class_1058 method_4711() {
			return particle;
		}

		@Override
		public class_806 method_4710() {
			return overrides;
		}

		@Override
		public class_809 method_4709() {
			return class_809.field_4301;
		}

		@Override
		public class_1087 applyTransform(class_811 cameraTransformType, class_4587 poseStack, boolean applyLeftHandTransform, DefaultTransform transform) {
			if (perspectives.containsKey(cameraTransformType)) {
				class_1087 p = perspectives.get(cameraTransformType);
				return TransformTypeDependentItemBakedModel.maybeApplyTransform(p, cameraTransformType, poseStack, applyLeftHandTransform, transform);
			}
			return TransformTypeDependentItemBakedModel.maybeApplyTransform(baseModel, cameraTransformType, poseStack, applyLeftHandTransform, transform);
		}
	}

	public static final class Loader implements IGeometryLoader<SeparateTransformsModel> {
		public static final Loader INSTANCE = new Loader();

		private Loader() {}

		@Override
		public SeparateTransformsModel read(JsonObject jsonObject, JsonDeserializationContext deserializationContext) {
			class_793 baseModel = deserializationContext.deserialize(class_3518.method_15296(jsonObject, "base"), class_793.class);

			JsonObject perspectiveData = class_3518.method_15296(jsonObject, "perspectives");

			Map<class_811, class_793> perspectives = new HashMap<>();
			for (class_811 transform : class_811.values()) {
				if (perspectiveData.has(transform.method_15434())) {
					class_793 perspectiveModel = deserializationContext.deserialize(class_3518.method_15296(perspectiveData, transform.method_15434()), class_793.class);
					perspectives.put(transform, perspectiveModel);
				}
			}

			return new SeparateTransformsModel(baseModel, ImmutableMap.copyOf(perspectives));
		}
	}
}
