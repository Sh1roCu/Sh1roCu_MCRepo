package io.github.fabricators_of_create.porting_lib.models.generators;

import io.github.fabricators_of_create.porting_lib.data.ExistingFileHelper;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_7784;
import net.minecraft.class_7923;

/**
 * Stub class to extend for item model data providers, eliminates some
 * boilerplate constructor parameters.
 */
public abstract class ItemModelProvider extends ModelProvider<ItemModelBuilder> {

	public ItemModelProvider(class_7784 output, String modid, ExistingFileHelper existingFileHelper) {
		super(output, modid, ITEM_FOLDER, ItemModelBuilder::new, existingFileHelper);
	}

	public ItemModelBuilder basicItem(class_1792 item)
	{
		return basicItem(Objects.requireNonNull(class_7923.field_41178.method_10221(item)));
	}

	public ItemModelBuilder basicItem(class_2960 item)
	{
		return getBuilder(item.toString())
				.parent(new ModelFile.UncheckedModelFile("item/generated"))
				.texture("layer0", class_2960.method_60655(item.method_12836(), "item/" + item.method_12832()));
	}

	@NotNull
	@Override
	public String method_10321() {
		return "Item Models: " + modid;
	}
}
