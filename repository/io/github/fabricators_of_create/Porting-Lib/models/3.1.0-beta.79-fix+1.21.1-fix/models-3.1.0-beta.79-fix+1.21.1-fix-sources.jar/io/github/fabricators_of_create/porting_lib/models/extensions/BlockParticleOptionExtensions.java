package io.github.fabricators_of_create.porting_lib.models.extensions;

import net.minecraft.class_2338;
import net.minecraft.class_2388;
import org.jetbrains.annotations.Nullable;

public interface BlockParticleOptionExtensions {
	/**
	 * Give this BlockParticleOption the BlockPos of the block that created it.
	 */
	default class_2388 setSourcePos(class_2338 pos) {
		throw new AssertionError("Should be implemented in a mixin");
	}

	/**
	 * Get the BlockPos of the block that created this particle. May be null, not always available.
	 */
	@Nullable
	default class_2338 getSourcePos() {
		throw new AssertionError("Should be implemented in a mixin");
	}
}
