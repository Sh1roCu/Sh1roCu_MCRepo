package io.github.fabricators_of_create.porting_lib.models.generators;

import com.google.common.base.Preconditions;

import io.github.fabricators_of_create.porting_lib.data.ExistingFileHelper;
import net.minecraft.class_2960;

public abstract class ModelFile {

	protected class_2960 location;

	protected ModelFile(class_2960 location) {
		this.location = location;
	}

	protected abstract boolean exists();

	public class_2960 getLocation() {
		assertExistence();
		return location;
	}

	/**
	 * Assert that this model exists.
	 * @throws IllegalStateException if this model does not exist
	 */
	public void assertExistence() {
		Preconditions.checkState(exists(), "Model at %s does not exist", location);
	}

	public class_2960 getUncheckedLocation() {
		return location;
	}

	public static class UncheckedModelFile extends ModelFile {

		public UncheckedModelFile(String location) {
			this(class_2960.method_60654(location));
		}
		public UncheckedModelFile(class_2960 location) {
			super(location);
		}

		@Override
		protected boolean exists() {
			return true;
		}
	}

	public static class ExistingModelFile extends ModelFile {
		private final ExistingFileHelper existingHelper;

		public ExistingModelFile(class_2960 location, ExistingFileHelper existingHelper) {
			super(location);
			this.existingHelper = existingHelper;
		}

		@Override
		protected boolean exists() {
			if (getUncheckedLocation().method_12832().contains("."))
				return existingHelper.exists(getUncheckedLocation(), ModelProvider.MODEL_WITH_EXTENSION);
			else
				return existingHelper.exists(getUncheckedLocation(), ModelProvider.MODEL);
		}
	}
}
