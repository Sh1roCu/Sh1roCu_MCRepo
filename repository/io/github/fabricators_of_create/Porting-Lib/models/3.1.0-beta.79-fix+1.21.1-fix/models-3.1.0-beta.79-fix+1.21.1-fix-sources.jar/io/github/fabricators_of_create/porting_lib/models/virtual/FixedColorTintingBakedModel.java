package io.github.fabricators_of_create.porting_lib.models.virtual;

import java.util.function.Supplier;

import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public class FixedColorTintingBakedModel extends ForwardingBakedModel {
	private static final ThreadLocal<FixedColorTintingBakedModel> THREAD_LOCAL = ThreadLocal.withInitial(FixedColorTintingBakedModel::new);

	protected int color;

	protected FixedColorTintingBakedModel() {
	}

	public static class_1087 wrap(class_1087 model, int color) {
		FixedColorTintingBakedModel wrapper = THREAD_LOCAL.get();
		wrapper.wrapped = model;
		wrapper.color = color;
		return wrapper;
	}

	@Override
	public boolean isVanillaAdapter() {
		return false;
	}

	@Override
	public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
		context.pushTransform(quad -> {
			if (quad.colorIndex() != -1) {
				quad.color(color, color, color, color);
				quad.colorIndex(-1);
			}
			return true;
		});
		super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
		context.popTransform();
	}

	@Override
	public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
		context.pushTransform(quad -> {
			if (quad.colorIndex() != -1) {
				quad.color(color, color, color, color);
				quad.colorIndex(-1);
			}
			return true;
		});
		super.emitItemQuads(stack, randomSupplier, context);
		context.popTransform();
	}
}
