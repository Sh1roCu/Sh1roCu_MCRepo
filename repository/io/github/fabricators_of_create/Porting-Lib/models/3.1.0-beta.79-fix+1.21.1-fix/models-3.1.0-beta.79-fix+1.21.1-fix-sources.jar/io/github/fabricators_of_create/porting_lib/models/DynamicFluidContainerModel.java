package io.github.fabricators_of_create.porting_lib.models;

import Z;
import com.google.common.collect.Maps;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import java.util.Map;
import java.util.function.Function;

import com.mojang.serialization.JsonOps;

import io.github.fabricators_of_create.porting_lib.models.geometry.IGeometryBakingContext;
import io.github.fabricators_of_create.porting_lib.models.geometry.IGeometryLoader;
import io.github.fabricators_of_create.porting_lib.models.geometry.IUnbakedGeometry;
import io.github.fabricators_of_create.porting_lib.models.geometry.SimpleModelState;
import io.github.fabricators_of_create.porting_lib.models.geometry.StandaloneGeometryBakingContext;
import io.github.fabricators_of_create.porting_lib.render_types.PortingLibRenderTypes;
import io.github.fabricators_of_create.porting_lib.render_types.RenderTypeGroup;
import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_326;
import net.minecraft.class_3518;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3665;
import net.minecraft.class_4590;
import net.minecraft.class_4730;
import net.minecraft.class_638;
import net.minecraft.class_7775;
import net.minecraft.class_7923;
import net.minecraft.class_806;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * A dynamic fluid container model, capable of re-texturing itself at runtime to match the contained fluid.
 * <p>
 * Composed of a base layer, a fluid layer (applied with a mask) and a cover layer (optionally applied with a mask).
 * The entire model may optionally be flipped if the fluid is gaseous, and the fluid layer may glow if light-emitting.
 * <p>
 * Fluid tinting requires registering a separate {@link class_326}. An implementation is provided in {@link Colors}.
 *
 * @see Colors
 */
public class DynamicFluidContainerModel implements IUnbakedGeometry<DynamicFluidContainerModel> {
	// Depth offsets to prevent Z-fighting
	private static final class_4590 FLUID_TRANSFORM = new class_4590(new Vector3f(), new Quaternionf(), new Vector3f(1, 1, 1.002f), new Quaternionf());
	private static final class_4590 COVER_TRANSFORM = new class_4590(new Vector3f(), new Quaternionf(), new Vector3f(1, 1, 1.004f), new Quaternionf());

	private final FluidVariant fluid;
	private final boolean flipGas;
	private final boolean coverIsMask;
	private final boolean applyFluidLuminosity;

	private DynamicFluidContainerModel(FluidVariant fluid, boolean flipGas, boolean coverIsMask, boolean applyFluidLuminosity) {
		this.fluid = fluid;
		this.flipGas = flipGas;
		this.coverIsMask = coverIsMask;
		this.applyFluidLuminosity = applyFluidLuminosity;
	}

	public static RenderTypeGroup getLayerRenderTypes(boolean unlit) {
		return new RenderTypeGroup(class_1921.method_23583(), unlit ? PortingLibRenderTypes.ITEM_UNSORTED_UNLIT_TRANSLUCENT.get() : PortingLibRenderTypes.ITEM_UNSORTED_TRANSLUCENT.get());
	}

	/**
	 * Returns a new ModelDynBucket representing the given fluid, but with the same
	 * other properties (flipGas, tint, coverIsMask).
	 */
	public DynamicFluidContainerModel withFluid(class_3611 newFluid) {
		return new DynamicFluidContainerModel(FluidVariant.of(newFluid), flipGas, coverIsMask, applyFluidLuminosity);
	}

	/**
	 * Returns a new ModelDynBucket representing the given fluid, but with the same
	 * other properties (flipGas, tint, coverIsMask).
	 */
	public DynamicFluidContainerModel withFluid(FluidVariant newFluid) {
		return new DynamicFluidContainerModel(newFluid, flipGas, coverIsMask, applyFluidLuminosity);
	}

	@Override
	public class_1087 bake(IGeometryBakingContext context, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelState, class_806 overrides) {
		class_4730 particleLocation = context.hasMaterial("particle") ? context.getMaterial("particle") : null;
		class_4730 baseLocation = context.hasMaterial("base") ? context.getMaterial("base") : null;
		class_4730 fluidMaskLocation = context.hasMaterial("fluid") ? context.getMaterial("fluid") : null;
		class_4730 coverLocation = context.hasMaterial("cover") ? context.getMaterial("cover") : null;

		class_1058 baseSprite = baseLocation != null ? spriteGetter.apply(baseLocation) : null;
		class_1058 fluidSprite = fluid != class_3612.field_15906 ? FluidVariantRendering.getSprite(fluid) : null;
		class_1058 coverSprite = (coverLocation != null && (!coverIsMask || baseLocation != null)) ? spriteGetter.apply(coverLocation) : null;

		class_1058 particleSprite = particleLocation != null ? spriteGetter.apply(particleLocation) : null;

		if (particleSprite == null) particleSprite = fluidSprite;
		if (particleSprite == null) particleSprite = baseSprite;
		if (particleSprite == null && !coverIsMask) particleSprite = coverSprite;

		// If the fluid is lighter than air, rotate 180deg to turn it upside down
		if (flipGas && fluid != class_3612.field_15906 && FluidVariantAttributes.isLighterThanAir(fluid)) {
			modelState = new SimpleModelState(
					modelState.method_3509().method_22933(
							new class_4590(null, new Quaternionf(0, 0, 1, 0), null, null)));
		}

		// We need to disable GUI 3D and block lighting for this to render properly
		var itemContext = StandaloneGeometryBakingContext.builder(context).withGui3d(false).withUseBlockLight(false).build(class_2960.method_60655("neoforge", "dynamic_fluid_container"));
		var modelBuilder = CompositeModel.Baked.builder(itemContext, particleSprite, new ContainedFluidOverrideHandler(overrides, baker, itemContext, this), context.getTransforms());

		var normalRenderTypes = getLayerRenderTypes(false);

		if (baseLocation != null && baseSprite != null) {
			// Base texture
			var unbaked = UnbakedGeometryHelper.createUnbakedItemElements(0, baseSprite);
			var quads = UnbakedGeometryHelper.bakeElements(unbaked, $ -> baseSprite, modelState);
			modelBuilder.addQuads(normalRenderTypes, quads);
		}

		if (fluidMaskLocation != null && fluidSprite != null) {
			class_1058 templateSprite = spriteGetter.apply(fluidMaskLocation);
			if (templateSprite != null) {
				// Fluid layer
				var transformedState = new SimpleModelState(modelState.method_3509().method_22933(FLUID_TRANSFORM), modelState.method_3512());
				var unbaked = UnbakedGeometryHelper.createUnbakedItemMaskElements(1, templateSprite); // Use template as mask
				var quads = UnbakedGeometryHelper.bakeElements(unbaked, $ -> fluidSprite, transformedState); // Bake with fluid texture

				var emissive = applyFluidLuminosity && FluidVariantAttributes.getLuminance(fluid) > 0;
				var renderTypes = getLayerRenderTypes(emissive);
				if (emissive) QuadTransformers.settingMaxEmissivity().processInPlace(quads);

				modelBuilder.addQuads(renderTypes, quads);
			}
		}

		if (coverSprite != null) {
			var sprite = coverIsMask ? baseSprite : coverSprite;
			if (sprite != null) {
				// Cover/overlay
				var transformedState = new SimpleModelState(modelState.method_3509().method_22933(COVER_TRANSFORM), modelState.method_3512());
				var unbaked = UnbakedGeometryHelper.createUnbakedItemMaskElements(2, coverSprite); // Use cover as mask
				var quads = UnbakedGeometryHelper.bakeElements(unbaked, $ -> sprite, transformedState); // Bake with selected texture
				modelBuilder.addQuads(normalRenderTypes, quads);
			}
		}

		modelBuilder.setParticle(particleSprite);

		return modelBuilder.build();
	}

	public static final class Loader implements IGeometryLoader<DynamicFluidContainerModel> {
		public static final Loader INSTANCE = new Loader();

		private Loader() {}

		@Override
		public DynamicFluidContainerModel read(JsonObject jsonObject, JsonDeserializationContext deserializationContext) {
			// Modified by porting lib to support fluid variants
			FluidVariant variant;

			if (jsonObject.has("variant")) {
				variant = FluidVariant.CODEC.decode(JsonOps.INSTANCE, jsonObject).getOrThrow().getFirst();
			} else if (jsonObject.has("fluid")) {
				class_2960 fluidName = class_2960.method_60654(jsonObject.get("fluid").getAsString());

				class_3611 fluid = class_7923.field_41173.method_10223(fluidName);
				variant = FluidVariant.of(fluid);
			} else {
				throw new RuntimeException("Bucket model requires 'fluid' or 'variant' value.");
			}

			boolean flip = class_3518.method_15258(jsonObject, "flip_gas", false);
			boolean coverIsMask = class_3518.method_15258(jsonObject, "cover_is_mask", true);
			boolean applyFluidLuminosity = class_3518.method_15258(jsonObject, "apply_fluid_luminosity", true);

			// create new model with correct liquid
			return new DynamicFluidContainerModel(variant, flip, coverIsMask, applyFluidLuminosity);
		}
	}

	private static final class ContainedFluidOverrideHandler extends class_806 {
		private final Map<String, class_1087> cache = Maps.newHashMap(); // contains all the baked models since they'll never change
		private final class_806 nested;
		private final class_7775 baker;
		private final IGeometryBakingContext owner;
		private final DynamicFluidContainerModel parent;

		private ContainedFluidOverrideHandler(class_806 nested, class_7775 baker, IGeometryBakingContext owner, DynamicFluidContainerModel parent) {
			this.nested = nested;
			this.baker = baker;
			this.owner = owner;
			this.parent = parent;
		}

		@Override
		public class_1087 method_3495(class_1087 originalModel, class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity, int seed) {
			class_1087 overridden = nested.method_3495(originalModel, stack, level, entity, seed);
			if (overridden != originalModel) return overridden;
			return TransferUtil.getFluidContained(stack)
					.map(fluidStack -> {
						Fluid fluid = fluidStack.getFluid();
						String name = BuiltInRegistries.FLUID.getKey(fluid).toString();

						if (!cache.containsKey(name)) {
							DynamicFluidContainerModel unbaked = this.parent.withFluid(fluid);
							BakedModel bakedModel = unbaked.bake(owner, baker, Material::sprite, BlockModelRotation.X0_Y0, this);
							cache.put(name, bakedModel);
							return bakedModel;
						}

						return cache.get(name);
					})
					// not a fluid item apparently
					.orElse(originalModel); // empty bucket
		}
	}

	public static class Colors implements class_326 {
		@Override
		public int getColor(class_1799 stack, int tintIndex) {
			if (tintIndex != 1) return 0xFFFFFFFF;
			return TransferUtil.getFluidContained(stack)
					.map(fluidStack -> FluidVariantRendering.getColor(fluidStack.getVariant()))
					.orElse(0xFFFFFFFF);
		}
	}
}
