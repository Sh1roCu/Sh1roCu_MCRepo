package io.github.fabricators_of_create.porting_lib.models.extensions;

import io.github.fabricators_of_create.porting_lib.models.CustomParticleIconModel;
import net.minecraft.class_1087;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_727;

public interface TerrainParticleExtensions {
	/**
	 * Refresh this particle's sprite using {@link class_1087#method_4711()} or {@link CustomParticleIconModel#getParticleIcon(Object)}.
	 * The model is gotten from the block state.
	 */
	default class_727 updateSprite(class_2680 state, class_2338 pos) {
		throw new AssertionError("Should be implemented in a mixin");
	}
}
