package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1092;
import net.minecraft.class_2960;
import net.minecraft.class_3695;
import net.minecraft.class_4724;
import net.minecraft.class_4730;
import com.google.common.base.Preconditions;

import io.github.fabricators_of_create.porting_lib.models.injections.ModelManagerInjection;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.models.events.client.ModelEvent;

@Mixin(class_1092.class)
public abstract class ModelManagerMixin implements ModelManagerInjection {
	@Shadow
	@Final
	private static Logger LOGGER;

	@Shadow
	private Map<class_1091, class_1087> bakedRegistry;

	@Unique
	private class_1088 port_lib$modelBakery;

	@Definition(id = "popPush", method = "Lnet/minecraft/util/profiling/ProfilerFiller;popPush(Ljava/lang/String;)V")
	@Definition(id = "profilerFiller", local = @Local(type = class_3695.class, argsOnly = true))
	@Expression("profilerFiller.popPush('dispatch')")
	@Inject(method = "loadModels", at = @At("MIXINEXTRAS:EXPRESSION"))
	private void modifyBakingResult(class_3695 profilerFiller, Map<class_2960, class_4724.class_7774> atlasPreparations, class_1088 modelBakery, CallbackInfoReturnable<class_1092.class_7779> cir) {
		profilerFiller.method_15405("porting_lib_modify_baking_result");

		Function<class_4730, class_1058> textureGetter = material -> {
			class_4724.class_7774 stitchResult = atlasPreparations.get(material.method_24144());
			class_1058 sprite = stitchResult.method_45869(material.method_24147());
			if (sprite != null) {
				return sprite;
			}
			LOGGER.warn("Failed to retrieve texture '{}' from atlas '{}'", material.method_24147(), material.method_24144(), new Throwable());
			return stitchResult.method_45868();
		};

		(new ModelEvent.ModifyBakingResult(modelBakery.method_4734(), textureGetter, modelBakery)).sendEvent();
	}

	@Definition(id = "profiler", local = @Local(type = class_3695.class, argsOnly = true))
	@Definition(id = "popPush", method = "Lnet/minecraft/util/profiling/ProfilerFiller;popPush(Ljava/lang/String;)V")
	@Expression("profiler.popPush('cache')")
	@Inject(method = "apply", at = @At("MIXINEXTRAS:EXPRESSION"))
	private void callBakingCompletedEvent(class_1092.class_7779 reloadState, class_3695 profiler, CallbackInfo ci, @Local class_1088 modelBakery) {
		port_lib$modelBakery = modelBakery;
		(new ModelEvent.BakingCompleted((class_1092) (Object) this, this.bakedRegistry, modelBakery)).sendEvent();
	}

	@Override
	public class_1088 port_lib$getModelBakery() {
		return Preconditions.checkNotNull(port_lib$modelBakery, "Attempted to query model bakery before it has been initialized.");
	}
}
