package io.github.fabricators_of_create.porting_lib.models.virtual;

import java.util.function.Supplier;

import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public class FixedLightBakedModel extends ForwardingBakedModel {
	private static final ThreadLocal<FixedLightBakedModel> THREAD_LOCAL = ThreadLocal.withInitial(FixedLightBakedModel::new);

	protected int light;

	protected FixedLightBakedModel() {
	}

	public static class_1087 wrap(class_1087 model, int light) {
		FixedLightBakedModel wrapper = THREAD_LOCAL.get();
		wrapper.wrapped = model;
		wrapper.light = light;
		return wrapper;
	}

	@Override
	public boolean isVanillaAdapter() {
		return false;
	}

	@Override
	public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
		context.pushTransform(quad -> {
			quad.lightmap(light, light, light, light);
			return true;
		});
		super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
		context.popTransform();
	}

	@Override
	public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
		context.pushTransform(quad -> {
			quad.lightmap(light, light, light, light);
			return true;
		});
		super.emitItemQuads(stack, randomSupplier, context);
		context.popTransform();
	}
}
