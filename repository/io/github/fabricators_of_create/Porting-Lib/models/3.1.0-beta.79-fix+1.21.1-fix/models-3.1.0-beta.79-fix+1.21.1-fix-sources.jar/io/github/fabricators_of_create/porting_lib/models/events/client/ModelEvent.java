package io.github.fabricators_of_create.porting_lib.models.events.client;

import com.google.common.base.Preconditions;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.models.PortingLibModels;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1092;
import net.minecraft.class_2960;
import net.minecraft.class_4730;
import net.minecraft.class_773;
import org.jetbrains.annotations.ApiStatus;

import java.util.Map;
import java.util.Set;
import java.util.function.Function;

/**
 * Houses events related to models.
 */
public abstract class ModelEvent extends BaseEvent {
	@ApiStatus.Internal
	protected ModelEvent() {}

	/**
	 * Fired while the {@link class_1092} is reloading models, after the model registry is set up, but before it's
	 * passed to the {@link class_773} for caching.
	 *
	 * <p>
	 * This event is fired from a worker thread and it is therefore not safe to access anything outside the
	 * model registry and {@link class_1088} provided in this event.<br>
	 * The {@link class_1092} firing this event is not fully set up with the latest data when this event fires and
	 * must therefore not be accessed in this event.
	 * </p>
	 *
	 * <p>Prefer modification events under {@link ModelLoadingPlugin.Context} where possible.</p>
	 *
	 * <p>This event is not {@linkplain CancellableEvent cancellable}, and does not have a result.</p>
	 *
	 * <p>This event is fired only on the {@linkplain EnvType#CLIENT logical client}.</p>
	 */
	public static class ModifyBakingResult extends ModelEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks) {
				callback.onModifyBakingResult(event);
			}
		});

		public interface Callback {
			void onModifyBakingResult(ModifyBakingResult event);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onModifyBakingResult(this);
		}

		private final Map<class_1091, class_1087> models;
		private final Function<class_4730, class_1058> textureGetter;
		private final class_1088 modelBakery;

		@ApiStatus.Internal
		public ModifyBakingResult(Map<class_1091, class_1087> models, Function<class_4730, class_1058> textureGetter, class_1088 modelBakery) {
			this.models = models;
			this.textureGetter = textureGetter;
			this.modelBakery = modelBakery;
		}

		/**
		 * @return the modifiable registry map of models and their model names
		 */
		public Map<class_1091, class_1087> getModels() {
			return models;
		}

		/**
		 * Returns a lookup function to retrieve {@link class_1058}s by name from any of the atlases handled by
		 * the {@link class_1092}. See {@link class_1092#VANILLA_ATLASES} for the atlases accessible through the
		 * returned function
		 *
		 * @return a function to lookup sprites from an atlas by name
		 */
		public Function<class_4730, class_1058> getTextureGetter() {
			return textureGetter;
		}

		/**
		 * @return the model loader
		 */
		public class_1088 getModelBakery() {
			return modelBakery;
		}
	}

	/**
	 * Fired when the {@link class_1092} is notified of the resource manager reloading.
	 * Called after the model registry is set up and cached in the {@link class_773}.<br>
	 * The model registry given by this event is unmodifiable. To modify the model registry, use
	 * {@link ModelEvent.ModifyBakingResult} instead.
	 *
	 * <p>This event is not {@linkplain CancellableEvent cancellable}, and does not have a result.</p>
	 *
	 * <p>This event is fired only on the {@linkplain EnvType#CLIENT logical client}.</p>
	 */
	public static class BakingCompleted extends ModelEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks) {
				callback.onBakingCompleted(event);
			}
		});

		public interface Callback {
			void onBakingCompleted(BakingCompleted event);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onBakingCompleted(this);
		}

		private final class_1092 modelManager;
		private final Map<class_1091, class_1087> models;
		private final class_1088 modelBakery;

		@ApiStatus.Internal
		public BakingCompleted(class_1092 modelManager, Map<class_1091, class_1087> models, class_1088 modelBakery) {
			this.modelManager = modelManager;
			this.models = models;
			this.modelBakery = modelBakery;
		}

		/**
		 * @return the model manager
		 */
		public class_1092 getModelManager() {
			return modelManager;
		}

		/**
		 * @return an unmodifiable view of the registry map of models and their model names
		 */
		public Map<class_1091, class_1087> getModels() {
			return models;
		}

		/**
		 * @return the model loader
		 */
		public class_1088 getModelBakery() {
			return modelBakery;
		}
	}

	/**
	 * Fired when the {@link class_1088} is notified of the resource manager reloading.
	 * Allows developers to register models to be loaded, along with their dependencies. Models registered through this
	 * event must use the {@link PortingLibModels#STANDALONE_VARIANT} variant.
	 * <p>Prefer {@link ModelLoadingPlugin.Context#addModels(class_2960...)} where possible.</p>
	 *
	 * <p>This event is not {@linkplain CancellableEvent cancellable}, and does not have a result.</p>
	 *
	 * <p>This event is fired only on the {@linkplain EnvType#CLIENT logical client}.</p>
	 */
	public static class RegisterAdditional extends ModelEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks) {
				callback.onRegisterAdditional(event);
			}
		});

		public interface Callback {
			void onRegisterAdditional(RegisterAdditional event);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onRegisterAdditional(this);
		}

		private final Set<class_1091> models;

		@ApiStatus.Internal
		public RegisterAdditional(Set<class_1091> models) {
			this.models = models;
		}

		/**
		 * Registers a model to be loaded, along with its dependencies.
		 * <p>
		 * The {@link class_1091} passed to this method must later be used to recover the loaded model.
		 */
		public void register(class_1091 model) {
			Preconditions.checkArgument(
					model.method_4740().equals(PortingLibModels.STANDALONE_VARIANT),
					"Side-loaded models must use the '" + PortingLibModels.STANDALONE_VARIANT + "' variant");
			models.add(model);
		}
	}
}
