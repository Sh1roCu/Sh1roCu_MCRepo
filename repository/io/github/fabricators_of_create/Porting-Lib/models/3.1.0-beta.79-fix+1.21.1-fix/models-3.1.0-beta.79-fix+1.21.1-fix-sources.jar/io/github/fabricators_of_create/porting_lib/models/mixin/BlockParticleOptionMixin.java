package io.github.fabricators_of_create.porting_lib.models.mixin;

import io.github.fabricators_of_create.porting_lib.models.extensions.BlockParticleOptionExtensions;
import net.minecraft.class_2338;
import net.minecraft.class_2388;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_2388.class)
public class BlockParticleOptionMixin implements BlockParticleOptionExtensions {
	@Unique
	@Nullable
	private class_2338 sourcePos;

	@Override
	public class_2388 setSourcePos(class_2338 pos) {
		this.sourcePos = pos;
		return (class_2388) (Object) this;
	}


	@Override
	public class_2338 getSourcePos() {
		return sourcePos;
	}
}
