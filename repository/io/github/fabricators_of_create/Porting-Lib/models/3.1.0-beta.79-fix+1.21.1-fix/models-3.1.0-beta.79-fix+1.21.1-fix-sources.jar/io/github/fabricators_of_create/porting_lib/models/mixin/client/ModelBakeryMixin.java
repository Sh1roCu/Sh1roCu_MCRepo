package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import io.github.fabricators_of_create.porting_lib.models.events.client.ModelEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_324;
import net.minecraft.class_3695;

@Mixin(class_1088.class)
public abstract class ModelBakeryMixin {
	@Shadow
	abstract class_1100 getModel(class_2960 modelLocation);

	@Shadow
	protected abstract void registerModelAndLoadDependencies(class_1091 modelLocation, class_1100 model);

	@Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/resources/model/ModelBakery;loadSpecialItemModelAndDependencies(Lnet/minecraft/client/resources/model/ModelResourceLocation;)V", ordinal = 1, shift = At.Shift.AFTER))
	private void registerAdditionalModels(class_324 blockColors, class_3695 profilerFiller, Map modelResources, Map blockStateResources, CallbackInfo ci) {
		Set<class_1091> additionalModels = new HashSet<>();
		(new ModelEvent.RegisterAdditional(additionalModels)).sendEvent();

		for (class_1091 model : additionalModels) {
			class_1100 unbakedModel = this.getModel(model.comp_2875());
			this.registerModelAndLoadDependencies(model, unbakedModel);
		}
	}
}
