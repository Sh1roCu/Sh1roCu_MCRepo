package io.github.fabricators_of_create.porting_lib.models.pipeline;

import java.util.Arrays;
import java.util.IdentityHashMap;
import java.util.Map;

import io.github.fabricators_of_create.porting_lib.models.IQuadTransformer;
import io.github.fabricators_of_create.porting_lib.textures.UnitTextureAtlasSprite;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.MaterialFinder;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadView;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.class_1058;
import net.minecraft.class_156;
import net.minecraft.class_2350;
import net.minecraft.class_290;
import net.minecraft.class_296;
import net.minecraft.class_4588;
import net.minecraft.class_777;

/**
 * Vertex consumer that outputs {@linkplain class_777 baked quads}.
 * <p>
 * This consumer accepts data in {@link net.minecraft.class_290#field_1590} and is not picky about
 * ordering or missing elements, but will not automatically populate missing data (color will be black, for example).
 * <p>
 * Built quads must be retrieved after building four vertices
 * <p>
 * Usage of this class on Fabric is highly discouraged, {@link net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter} should be used instead whenever possible.
 */
public class QuadBakingVertexConsumer implements class_4588 {
	private final Map<class_296, Integer> ELEMENT_OFFSETS = class_156.method_654(new IdentityHashMap<>(), map -> {
		for (var element : class_290.field_1590.method_1357())
			map.put(element, class_290.field_1590.method_60835(element) / 4); // Int offset
	});
	private static final int QUAD_DATA_SIZE = QuadView.VANILLA_QUAD_STRIDE;

	private final int[] quadData = new int[QUAD_DATA_SIZE];
	private int vertexIndex = 0;
	private boolean building = false;

	private int tintIndex = -1;
	private class_2350 direction = class_2350.field_11033;
	private class_1058 sprite = UnitTextureAtlasSprite.INSTANCE;
	private MaterialFinder materialFinder = RendererAccess.INSTANCE.getRenderer().materialFinder();
	private boolean shade;
	private int lightEmission;
	private boolean hasAmbientOcclusion;

	@Override
	public class_4588 method_22912(float x, float y, float z) {
		if (building) {
			if (++vertexIndex > 4) {
				throw new IllegalStateException("Expected quad export after fourth vertex");
			}
		}
		building = true;

		int offset = vertexIndex * IQuadTransformer.STRIDE + IQuadTransformer.POSITION;
		quadData[offset] = Float.floatToRawIntBits(x);
		quadData[offset + 1] = Float.floatToRawIntBits(y);
		quadData[offset + 2] = Float.floatToRawIntBits(z);
		return this;
	}

	@Override
	public class_4588 method_22914(float x, float y, float z) {
		int offset = vertexIndex * IQuadTransformer.STRIDE + IQuadTransformer.NORMAL;
		quadData[offset] = ((int) (x * 127.0f) & 0xFF) |
				(((int) (y * 127.0f) & 0xFF) << 8) |
				(((int) (z * 127.0f) & 0xFF) << 16);
		return this;
	}

	@Override
	public class_4588 method_1336(int r, int g, int b, int a) {
		int offset = vertexIndex * IQuadTransformer.STRIDE + IQuadTransformer.COLOR;
		quadData[offset] = ((a & 0xFF) << 24) |
				((b & 0xFF) << 16) |
				((g & 0xFF) << 8) |
				(r & 0xFF);
		return this;
	}

	@Override
	public class_4588 method_22913(float u, float v) {
		int offset = vertexIndex * IQuadTransformer.STRIDE + IQuadTransformer.UV0;
		quadData[offset] = Float.floatToRawIntBits(u);
		quadData[offset + 1] = Float.floatToRawIntBits(v);
		return this;
	}

	@Override
	public class_4588 method_60796(int u, int v) {
		if (IQuadTransformer.UV1 >= 0) { // Vanilla doesn't support this, but it may be added by a 3rd party
			int offset = vertexIndex * IQuadTransformer.STRIDE + IQuadTransformer.UV1;
			quadData[offset] = (u & 0xFFFF) | ((v & 0xFFFF) << 16);
		}
		return this;
	}

	@Override
	public class_4588 method_22921(int u, int v) {
		int offset = vertexIndex * IQuadTransformer.STRIDE + IQuadTransformer.UV2;
		quadData[offset] = (u & 0xFFFF) | ((v & 0xFFFF) << 16);
		return this;
	}

//	@Override forge method
	public class_4588 misc(class_296 element, int... rawData) {
		Integer baseOffset = ELEMENT_OFFSETS.get(element);
		if (baseOffset != null) {
			int offset = vertexIndex * IQuadTransformer.STRIDE + baseOffset;
			System.arraycopy(rawData, 0, quadData, offset, rawData.length);
		}
		return this;
	}

	public void setTintIndex(int tintIndex) {
		this.tintIndex = tintIndex;
	}

	public void setDirection(class_2350 direction) {
		this.direction = direction;
	}

	public void setSprite(class_1058 sprite) {
		this.sprite = sprite;
	}

	public void setShade(boolean shade) {
		this.shade = shade;
	}

	public void setLightEmission(int lightEmission) {
		this.lightEmission = lightEmission;
	}

	public void setHasAmbientOcclusion(boolean hasAmbientOcclusion) {
		this.hasAmbientOcclusion = hasAmbientOcclusion;
	}

	public void setRenderMaterial(RenderMaterial material) {
		this.materialFinder.clear();
		this.materialFinder.copyFrom(material);
	}

	/**
	 * Only supports vanilla's quad format use the method below this one for full rendering feature support.
	 * This method does not support ambient occlusion and light emission
	 */
	@Deprecated
	public class_777 bakeQuad() {
		if (!building || ++vertexIndex != 4) {
			throw new IllegalStateException("Not enough vertices available. Vertices in buffer: " + vertexIndex);
		}

		class_777 quad = new class_777(quadData.clone(), tintIndex, direction, sprite, shade);
		vertexIndex = 0;
		building = false;
		Arrays.fill(quadData, 0);
		return quad;
	}

	public QuadView build() {
		if (!building || ++vertexIndex != 4) {
			throw new IllegalStateException("Not enough vertices available. Vertices in buffer: " + vertexIndex);
		}

		QuadEmitter emitter = RendererAccess.INSTANCE.getRenderer().meshBuilder().getEmitter();

		emitter.fromVanilla(quadData.clone(), 0);
		emitter.colorIndex(tintIndex);
		emitter.nominalFace(direction);

		if (!shade) {
			materialFinder.disableDiffuse(true);
		}

		emitter.material(materialFinder.find());

		materialFinder.ambientOcclusion(TriState.of(hasAmbientOcclusion));

		emitter.lightmap(lightEmission, lightEmission, lightEmission, lightEmission);


		return emitter;
	}
}
