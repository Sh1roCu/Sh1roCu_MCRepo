package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import javax.annotation.Nullable;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import net.fabricmc.fabric.api.renderer.v1.model.WrapperBakedModel;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import io.github.fabricators_of_create.porting_lib.models.CustomParticleIconModel;
import net.fabricmc.fabric.api.rendering.data.v1.RenderAttachedBlockView;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_2338;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4603;
import net.minecraft.class_773;

@Mixin(class_4603.class)
public abstract class ScreenEffectRendererMixin {
	@Unique
	@Nullable
	private static class_2338 viewBlockingPos = null;

	@ModifyReturnValue(method = "getViewBlockingState", at = @At("RETURN"))
	private static class_2680 grabPos(class_2680 state, @Local(ordinal = 0) class_2339 pos) {
		viewBlockingPos = state == null ? null : pos.method_10062();
		return state;
	}

	@WrapOperation(
			method = "renderScreenEffect",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/renderer/block/BlockModelShaper;getParticleIcon(Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/client/renderer/texture/TextureAtlasSprite;"
			)
	)
	private static class_1058 useCustomParticleSprite(class_773 shaper, class_2680 state, Operation<class_1058> original,
															  class_310 mc, class_4587 poseStack) {
		if (viewBlockingPos == null || !(mc.field_1687 instanceof RenderAttachedBlockView view))
			return original.call(shaper, state);
		class_1087 model = shaper.method_3335(state);

		while (model instanceof WrapperBakedModel wrapped) {
			if (model instanceof CustomParticleIconModel) break;
			model = wrapped.getWrappedModel();
		}

		if (model instanceof CustomParticleIconModel custom) {
			Object data = view.getBlockEntityRenderAttachment(viewBlockingPos);
			return custom.getParticleIcon(data);
		}
		return original.call(shaper, state);
	}
}
