package io.github.fabricators_of_create.porting_lib.models;

import net.fabricmc.fabric.api.blockview.v2.FabricBlockView;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_2338;

public interface CustomParticleIconModel {
	/**
	 * An extension of {@link class_1087#method_4711()} that accepts custom BlockEntity data for context.
	 * The data is retrieved from {@link FabricBlockView#getBlockEntityRenderData(class_2338)}.
	 * By default, defers to the context-less method.
	 */
	default class_1058 getParticleIcon(Object data) {
		return ((class_1087) this).method_4711();
	}
}
