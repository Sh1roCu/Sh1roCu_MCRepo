package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import io.github.fabricators_of_create.porting_lib.models.extensions.ItemTransformExtensions;
import net.minecraft.class_804;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_804.class)
public class ItemTransformMixin implements ItemTransformExtensions {
	public Vector3f rightRotation;

	@Override
	public Vector3f getRightRotation() {
		return this.rightRotation;
	}

	@Override
	public void setRightRotation(Vector3f rightRotation) {
		this.rightRotation = rightRotation;
	}
}
