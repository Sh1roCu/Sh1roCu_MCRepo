package io.github.fabricators_of_create.porting_lib.models.mixin;

import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2388;
import net.minecraft.class_2394;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(class_1309.class)
public class LivingEntityMixin {
	@ModifyArgs(
			method = "checkFallDamage",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/server/level/ServerLevel;sendParticles(Lnet/minecraft/core/particles/ParticleOptions;DDDIDDDD)I"
			)
	)
	private void addSourcePos(Args args, double y, boolean onGround, class_2680 state, class_2338 pos) {
		class_2394 options = args.get(0);
		if (options instanceof class_2388 block)
			block.setSourcePos(pos);
	}
}
