package io.github.fabricators_of_create.porting_lib.models.injections;

import org.jetbrains.annotations.Nullable;

import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.class_4730;

public interface ModelBakerInjection {
	@Nullable
	default class_1100 port_lib$getTopLevelModel(class_1091 location) {
		return null;
	}

	default Function<class_4730, class_1058> port_lib$getModelTextureGetter() {
		return material -> null;
	}
}
