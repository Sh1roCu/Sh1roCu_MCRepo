package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.models.internal.TransformTypeDependentModelHelper;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_804;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;

@Mixin(class_918.class)
public class ItemRendererMixin {
	@WrapOperation(
			method = "render",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/renderer/block/model/ItemTransform;apply(ZLcom/mojang/blaze3d/vertex/PoseStack;)V"
			)
	)
	private void applyCustomTransforms(class_804 transform, boolean leftHanded, class_4587 poseStack, Operation<Void> original,
									   class_1799 stack, class_811 context, boolean leftHanded2, class_4587 matrices,
									   class_4597 vertexConsumers, int light, int overlay, class_1087 originalModel,
									   @Share("transformed") LocalRef<class_1087> transformedRef) {
		TransformTypeDependentModelHelper.handleTransformations(originalModel, context, leftHanded, poseStack, original, transformedRef);
	}

	@ModifyVariable(
			method = "render",
			at = @At(
					value = "INVOKE",
					target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V"
			),
			argsOnly = true
	)
	private class_1087 useTransformedModel(class_1087 model, @Share("transformed") LocalRef<class_1087> transformedRef) {
		return TransformTypeDependentModelHelper.getTransformedModel(model, transformedRef);
	}
}
