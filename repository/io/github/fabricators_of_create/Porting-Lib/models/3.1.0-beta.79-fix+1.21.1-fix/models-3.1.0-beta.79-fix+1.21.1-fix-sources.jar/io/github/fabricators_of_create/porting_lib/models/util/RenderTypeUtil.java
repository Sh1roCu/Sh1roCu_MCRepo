package io.github.fabricators_of_create.porting_lib.models.util;

import com.google.common.collect.ImmutableMap;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import net.minecraft.class_1921;
import net.minecraft.class_2960;

public final class RenderTypeUtil {
	private static final ImmutableMap<class_2960, class_1921> RENDER_TYPES;

	@Nullable
	public static class_1921 get(class_2960 name) {
		return RENDER_TYPES.getOrDefault(name, null);
	}

	static {
		var renderTypes = new HashMap<class_2960, class_1921>();
		renderTypes.put(class_2960.method_60656("solid"), class_1921.method_23577());
		renderTypes.put(class_2960.method_60656("cutout"), class_1921.method_23581());
		// Generally entity/item rendering shouldn't use mipmaps, so cutout_mipped has them off by default. To enforce them, use cutout_mipped_all.
		renderTypes.put(class_2960.method_60656("cutout_mipped"), class_1921.method_23579());
		renderTypes.put(class_2960.method_60656("cutout_mipped_all"), class_1921.method_23579());
		renderTypes.put(class_2960.method_60656("translucent"), class_1921.method_23583());
		renderTypes.put(class_2960.method_60656("tripwire"), class_1921.method_29997());
		RENDER_TYPES = ImmutableMap.copyOf(renderTypes);
	}
}
