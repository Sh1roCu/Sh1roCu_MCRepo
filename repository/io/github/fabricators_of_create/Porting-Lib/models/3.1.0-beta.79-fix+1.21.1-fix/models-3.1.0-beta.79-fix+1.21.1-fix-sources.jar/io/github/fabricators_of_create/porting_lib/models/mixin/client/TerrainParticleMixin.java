package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import io.github.fabricators_of_create.porting_lib.models.CustomParticleIconModel;
import io.github.fabricators_of_create.porting_lib.models.extensions.TerrainParticleExtensions;
import net.fabricmc.fabric.api.renderer.v1.model.WrapperBakedModel;
import net.minecraft.class_1087;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_727;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_727.class)
public abstract class TerrainParticleMixin extends class_4003 implements TerrainParticleExtensions {
	protected TerrainParticleMixin(class_638 clientLevel, double d, double e, double f) {
		super(clientLevel, d, e, f);
	}

	@Override
	public class_727 updateSprite(class_2680 state, class_2338 pos) {
		class_310 mc = class_310.method_1551();
		class_1087 model = mc.method_1554().method_4743().method_3335(state);

		while (model instanceof WrapperBakedModel wrapped) {
			if (model instanceof CustomParticleIconModel) break;
			model = wrapped.getWrappedModel();
		}

		if (model instanceof CustomParticleIconModel custom && mc.field_1687 != null) {
			Object data = mc.field_1687.getBlockEntityRenderData(pos);
			this.method_18141(custom.getParticleIcon(data));
		}
		return (class_727) (Object) this;
	}
}
