package io.github.fabricators_of_create.porting_lib.models;

import com.google.common.collect.ImmutableList;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import io.github.fabricators_of_create.porting_lib.models.geometry.IGeometryBakingContext;
import io.github.fabricators_of_create.porting_lib.models.geometry.IGeometryLoader;
import io.github.fabricators_of_create.porting_lib.models.geometry.IUnbakedGeometry;
import io.github.fabricators_of_create.porting_lib.render_types.PortingLibRenderTypes;
import io.github.fabricators_of_create.porting_lib.render_types.RenderTypeGroup;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_801;
import net.minecraft.class_806;
import org.jetbrains.annotations.Nullable;

/**
 * Forge reimplementation of vanilla's {@link class_801}, i.e. builtin/generated models with some tweaks:
 * - Represented as {@link IUnbakedGeometry} so it can be baked as usual instead of being special-cased
 * - Not limited to an arbitrary number of layers (5)
 * - Support for per-layer render types
 */
public class ItemLayerModel implements IUnbakedGeometry<ItemLayerModel> {
	@Nullable
	private ImmutableList<class_4730> textures;
	private final Int2ObjectMap<ExtraFaceData> layerData;
	private final Int2ObjectMap<class_2960> renderTypeNames;

	private ItemLayerModel(@Nullable ImmutableList<class_4730> textures, Int2ObjectMap<ExtraFaceData> layerData, Int2ObjectMap<class_2960> renderTypeNames) {
		this.textures = textures;
		this.layerData = layerData;
		this.renderTypeNames = renderTypeNames;
	}

	@Override
	public class_1087 bake(IGeometryBakingContext context, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelState, class_806 overrides) {
		if (textures == null) {
			ImmutableList.Builder<class_4730> builder = ImmutableList.builder();
			for (int i = 0; context.hasMaterial("layer" + i); i++) {
				builder.add(context.getMaterial("layer" + i));
			}
			textures = builder.build();
		}

		class_1058 particle = spriteGetter.apply(
				context.hasMaterial("particle") ? context.getMaterial("particle") : textures.get(0));
		var rootTransform = context.getRootTransform();
		if (!rootTransform.isIdentity())
			modelState = UnbakedGeometryHelper.composeRootTransformIntoModelState(modelState, rootTransform);

		var normalRenderTypes = new RenderTypeGroup(class_1921.method_23583(), PortingLibRenderTypes.ITEM_UNSORTED_TRANSLUCENT.get());
		CompositeModel.Baked.Builder builder = CompositeModel.Baked.builder(context, particle, overrides, context.getTransforms());
		for (int i = 0; i < textures.size(); i++) {
			class_1058 sprite = spriteGetter.apply(textures.get(i));
			var unbaked = UnbakedGeometryHelper.createUnbakedItemElements(i, sprite, this.layerData.get(i));
			var quads = UnbakedGeometryHelper.bakeElements(unbaked, $ -> sprite, modelState);
			var renderTypeName = renderTypeNames.get(i);
			RenderTypeGroup renderTypes = renderTypeName != null ? context.getRenderType(renderTypeName) : null;
			builder.addQuads(renderTypes != null ? renderTypes : normalRenderTypes, quads);
		}

		return builder.build();
	}

	public static final class Loader implements IGeometryLoader<ItemLayerModel> {
		public static final Loader INSTANCE = new Loader();

		@Override
		public ItemLayerModel read(JsonObject jsonObject, JsonDeserializationContext deserializationContext) {
			var renderTypeNames = new Int2ObjectOpenHashMap<class_2960>();
			if (jsonObject.has("render_types")) {
				var renderTypes = jsonObject.getAsJsonObject("render_types");
				for (Map.Entry<String, JsonElement> entry : renderTypes.entrySet()) {
					var renderType = class_2960.method_60654(entry.getKey());
					for (var layer : entry.getValue().getAsJsonArray())
						if (renderTypeNames.put(layer.getAsInt(), renderType) != null)
							throw new JsonParseException("Registered duplicate render type for layer " + layer);
				}
			}

			var emissiveLayers = new Int2ObjectArrayMap<ExtraFaceData>();
//			if (jsonObject.has("forge_data")) throw new JsonParseException("forge_data should be replaced by neoforge_data"); // TODO 1.22: Remove
			if (jsonObject.has("porting_lib_data")) {
				JsonObject forgeData = jsonObject.get("porting_lib_data").getAsJsonObject();
				readLayerData(forgeData, "layers", renderTypeNames, emissiveLayers, false);
			}
			return new ItemLayerModel(null, emissiveLayers, renderTypeNames);
		}

		protected void readLayerData(JsonObject jsonObject, String name, Int2ObjectOpenHashMap<class_2960> renderTypeNames, Int2ObjectMap<ExtraFaceData> layerData, boolean logWarning) {
			if (!jsonObject.has(name)) {
				return;
			}
			var fullbrightLayers = jsonObject.getAsJsonObject(name);
			for (var entry : fullbrightLayers.entrySet()) {
				int layer = Integer.parseInt(entry.getKey());
				var data = ExtraFaceData.read(entry.getValue(), ExtraFaceData.DEFAULT);
				layerData.put(layer, data);
			}
		}
	}
}
