package io.github.fabricators_of_create.porting_lib.models.pipeline;

import net.minecraft.class_4588;

/**
 * Wrapper for {@link class_4588} which delegates all operations to its parent.
 * <p>
 * Useful for defining custom pipeline elements that only process certain data.
 */
public abstract class VertexConsumerWrapper implements class_4588 {
	protected final class_4588 parent;

	public VertexConsumerWrapper(class_4588 parent) {
		this.parent = parent;
	}

	@Override
	public class_4588 method_22912(float x, float y, float z) {
		parent.method_22912(x, y, z);
		return this;
	}

	@Override
	public class_4588 method_1336(int r, int g, int b, int a) {
		parent.method_1336(r, g, b, a);
		return this;
	}

	@Override
	public class_4588 method_22913(float u, float v) {
		parent.method_22913(u, v);
		return this;
	}

	@Override
	public class_4588 method_60796(int u, int v) {
		parent.method_60796(u, v);
		return this;
	}

	@Override
	public class_4588 method_22921(int u, int v) {
		parent.method_22921(u, v);
		return this;
	}

	@Override
	public class_4588 method_22914(float x, float y, float z) {
		parent.method_22914(x, y, z);
		return this;
	}
}
