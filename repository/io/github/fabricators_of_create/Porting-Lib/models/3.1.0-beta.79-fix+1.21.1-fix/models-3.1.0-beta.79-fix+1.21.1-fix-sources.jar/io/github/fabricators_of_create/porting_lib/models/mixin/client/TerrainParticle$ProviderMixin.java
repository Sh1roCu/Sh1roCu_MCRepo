package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_2338;
import net.minecraft.class_2388;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_727;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_727.class_728.class)
public class TerrainParticle$ProviderMixin {
	@ModifyReturnValue(
			method = "createParticle(Lnet/minecraft/core/particles/BlockParticleOption;Lnet/minecraft/client/multiplayer/ClientLevel;DDDDDD)Lnet/minecraft/client/particle/Particle;",
			at = @At("RETURN")
	)
	private class_703 updateSprite(class_703 particle,
								  class_2388 type, class_638 level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
		class_2338 source = type.getSourcePos();
		if (source != null && particle instanceof class_727 terrainParticle) {
			terrainParticle.updateSprite(type.method_10278(), source);
		}
		return particle;
	}
}
