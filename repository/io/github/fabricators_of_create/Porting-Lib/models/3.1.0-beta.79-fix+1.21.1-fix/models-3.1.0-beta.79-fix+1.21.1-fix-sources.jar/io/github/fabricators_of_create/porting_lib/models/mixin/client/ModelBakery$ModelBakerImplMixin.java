package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import io.github.fabricators_of_create.porting_lib.models.injections.ModelBakerInjection;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.class_4730;

@Mixin(targets = "net.minecraft.client.resources.model.ModelBakery$ModelBakerImpl")
public abstract class ModelBakery$ModelBakerImplMixin implements ModelBakerInjection {
	@Shadow
	@Final
	private class_1088 field_40571;

	@Shadow
	@Final
	private Function<class_4730, class_1058> modelTextureGetter;

	@Override
	public class_1100 port_lib$getTopLevelModel(class_1091 location) {
		return ((ModelBakeryAccessor) field_40571).getTopLevelModels().get(location);
	}

	@Override
	public Function<class_4730, class_1058> port_lib$getModelTextureGetter() {
		return modelTextureGetter;
	}
}
