package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1100;

@Mixin(class_1088.class)
public interface ModelBakeryAccessor {
	@Accessor
	Map<class_1091, class_1100> getTopLevelModels();
}
