package io.github.fabricators_of_create.porting_lib.attributes;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1320;
import net.minecraft.class_1329;
import net.minecraft.class_2378;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class PortingLibAttributes implements ModInitializer {
	public static final class_6880<class_1320> SWIM_SPEED = register("swim_speed", new class_1329("porting_lib.swim_speed", 1.0D, 0.0D, 1024.0D).method_26829(true));
	public static final class_6880<class_1320> CREATIVE_FLIGHT = register("creative_flight", new BooleanAttribute("porting_lib.creative_flight", false).method_26829(true));

	public static class_6880<class_1320> register(String id, class_1320 attribute) {
		return class_2378.method_47985(class_7923.field_41190, PortingLib.id(id), attribute);
	}

	@Override
	public void onInitialize() {}
}
