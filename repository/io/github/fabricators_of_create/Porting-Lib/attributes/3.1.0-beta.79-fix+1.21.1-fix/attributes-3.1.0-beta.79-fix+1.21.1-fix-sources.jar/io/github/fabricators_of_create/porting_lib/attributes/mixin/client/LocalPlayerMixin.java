package io.github.fabricators_of_create.porting_lib.attributes.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.attributes.injections.PlayerAttributesInjection;
import net.minecraft.class_1656;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_746.class)
public class LocalPlayerMixin implements PlayerAttributesInjection {
	@WrapOperation(method = "aiStep", at = @At(value = "FIELD", target = "Lnet/minecraft/world/entity/player/Abilities;mayfly:Z"))
	private boolean mayFly1(class_1656 instance, Operation<Boolean> original) {
		return port_lib$mayFly(instance, original);
	}

	@WrapOperation(method = "hasEnoughFoodToStartSprinting", at = @At(value = "FIELD", target = "Lnet/minecraft/world/entity/player/Abilities;mayfly:Z"))
	private boolean mayFly2(class_1656 instance, Operation<Boolean> original) {
		return port_lib$mayFly(instance, original);
	}
}
