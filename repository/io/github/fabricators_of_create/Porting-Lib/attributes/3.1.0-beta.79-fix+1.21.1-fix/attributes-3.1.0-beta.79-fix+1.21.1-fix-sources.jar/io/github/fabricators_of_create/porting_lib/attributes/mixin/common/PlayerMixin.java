package io.github.fabricators_of_create.porting_lib.attributes.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.attributes.PortingLibAttributes;
import io.github.fabricators_of_create.porting_lib.attributes.injections.PlayerAttributesInjection;
import net.minecraft.class_1656;
import net.minecraft.class_1657;
import net.minecraft.class_5132;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1657.class)
public class PlayerMixin implements PlayerAttributesInjection {
	@ModifyReturnValue(method = "createAttributes", at = @At("RETURN"))
	private static class_5132.class_5133 addPlayerAttributes(class_5132.class_5133 original) {
		return original.method_26867(PortingLibAttributes.CREATIVE_FLIGHT);
	}

	@WrapOperation(method = "causeFallDamage", at = @At(value = "FIELD", target = "Lnet/minecraft/world/entity/player/Abilities;mayfly:Z"))
	private boolean mayFly(class_1656 instance, Operation<Boolean> original) {
		return port_lib$mayFly(instance, original);
	}
}
