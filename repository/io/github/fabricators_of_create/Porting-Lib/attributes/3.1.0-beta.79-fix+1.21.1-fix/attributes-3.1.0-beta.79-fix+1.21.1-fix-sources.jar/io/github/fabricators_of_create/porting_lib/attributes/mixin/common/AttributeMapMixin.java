package io.github.fabricators_of_create.porting_lib.attributes.mixin.common;

import net.minecraft.class_2960;
import net.minecraft.class_5131;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(class_5131.class)
public class AttributeMapMixin {
	@ModifyArg(method = "load", at = @At(value = "INVOKE", target = "Lnet/minecraft/resources/ResourceLocation;tryParse(Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation;"))
	private String port_lib$remapOldAttribute(String location) {
		if (class_7923.field_41190.method_17966(class_2960.method_12829(location)).isPresent())
			return location;
		return location.replace("forge", "porting_lib");
	}
}
