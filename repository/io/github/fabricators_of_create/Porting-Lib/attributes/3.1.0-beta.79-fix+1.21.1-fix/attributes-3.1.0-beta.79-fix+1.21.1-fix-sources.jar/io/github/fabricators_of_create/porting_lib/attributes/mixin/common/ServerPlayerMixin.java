package io.github.fabricators_of_create.porting_lib.attributes.mixin.common;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3222.class)
public abstract class ServerPlayerMixin extends class_1657 {
	public ServerPlayerMixin(class_1937 level, class_2338 pos, float yRot, GameProfile gameProfile) {
		super(level, pos, yRot, gameProfile);
	}

	@Inject(method = "doTick", at = @At(value = "FIELD", target = "Lnet/minecraft/server/level/ServerPlayer;tickCount:I"))
	private void checkFlyAttribute(CallbackInfo ci) {
		if (method_31549().field_7479 && !this.port_lib$mayFly()) {
			method_31549().field_7479 = false;
			method_7355();
		}
	}
}
