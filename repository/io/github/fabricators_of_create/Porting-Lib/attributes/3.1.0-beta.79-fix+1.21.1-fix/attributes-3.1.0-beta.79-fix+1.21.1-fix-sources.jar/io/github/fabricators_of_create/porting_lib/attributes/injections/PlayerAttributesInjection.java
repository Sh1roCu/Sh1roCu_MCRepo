package io.github.fabricators_of_create.porting_lib.attributes.injections;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;

import io.github.fabricators_of_create.porting_lib.attributes.PortingLibAttributes;
import net.minecraft.class_1297;
import net.minecraft.class_1656;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;

public interface PlayerAttributesInjection {
	/**
	 * Utility check to see if the player is close enough to a target entity. Uses "eye-to-closest-corner" checks.
	 * @param entity The entity being checked against
	 * @param dist The max distance allowed
	 * @return If the eye-to-center distance between this player and the passed entity is less than dist.
	 * @implNote This method inflates the bounding box by the pick radius, which differs from vanilla. But vanilla doesn't use the pick radius, the only entity with > 0 is AbstractHurtingProjectile.
	 */
	default boolean port_lib$isCloseEnough(class_1297 entity, double dist) {
		class_243 eye = ((class_1657) this).method_33571();
		class_238 aabb = entity.method_5829().method_1014(entity.method_5871());
		return aabb.method_49271(eye) < dist * dist;
	}

	/**
	 * Determine whether a player is allowed creative flight via game mode or attribute.
	 *
	 * @return true when creative flight is available
	 * @see PortingLibAttributes#CREATIVE_FLIGHT
	 */
	default boolean port_lib$mayFly() {
		return port_lib$mayFly(((class_1657) this).method_31549(), args -> ((class_1656) args[0]).field_7478);
	}

	default boolean port_lib$mayFly(class_1656 instance, Operation<Boolean> original) {
		return original.call(instance) || ((class_1657) this).method_45325(PortingLibAttributes.CREATIVE_FLIGHT) > 0;
	}
}
