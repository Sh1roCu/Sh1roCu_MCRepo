package io.github.fabricators_of_create.porting_lib.attributes.mixin.common;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import io.github.fabricators_of_create.porting_lib.attributes.PortingLibAttributes;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1324;
import net.minecraft.class_1937;
import net.minecraft.class_5132;
import net.minecraft.class_6880;

@Mixin(value = class_1309.class, priority = 500)
public abstract class LivingEntityMixin extends class_1297 {
	public LivingEntityMixin(class_1299<?> entityType, class_1937 level) {
		super(entityType, level);
	}

	@ModifyReturnValue(method = "createLivingAttributes", at = @At("RETURN"))
	private static class_5132.class_5133 port_lib$addModdedAttributes(class_5132.class_5133 builder) {
		return builder.method_26867(PortingLibAttributes.SWIM_SPEED);
	}

	@Shadow
	@Nullable
	public abstract class_1324 getAttribute(class_6880<class_1320> attribute);

	@ModifyArg(method = "travel", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;moveRelative(FLnet/minecraft/world/phys/Vec3;)V", ordinal = 0))
	private float port_lib$swimSpeed(float original) {
		return original * (float)this.getAttribute(PortingLibAttributes.SWIM_SPEED).method_6194();
	}

	@ModifyArg(method = "jumpInLiquid", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/phys/Vec3;add(DDD)Lnet/minecraft/world/phys/Vec3;"), index = 1)
	private double port_lib$modifySwimSpeed(double y) {
		return y * this.getAttribute(PortingLibAttributes.SWIM_SPEED).method_6194();
	}
}
