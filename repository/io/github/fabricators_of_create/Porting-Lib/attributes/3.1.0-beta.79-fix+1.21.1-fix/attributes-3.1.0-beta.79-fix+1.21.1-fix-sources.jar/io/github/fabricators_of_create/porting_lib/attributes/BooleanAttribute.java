package io.github.fabricators_of_create.porting_lib.attributes;

import net.minecraft.class_1320;
import net.minecraft.class_1322;

/**
 * A boolean attribute only has two states, on or off, represented by a value of 0 (false) or 1 (true).
 * <p>
 * For boolean attributes, only use the following modifier values:
 * <ul>
 * <li>A value of 1 with {@link class_1322.class_1323#field_6328} to enable the effect.</li>
 * <li>A value of -1 with {@link class_1322.class_1323#field_6331} to forcibly disable the effect.</li>
 * </ul>
 * This behavior allows for multiple enabling modifiers to coexist, not removing the effect unless all enabling modifiers are removed.
 * <p>
 * Additionally, it permits forcibly disabling the effect through multiply total.
 *
 * @apiNote Use of other operations and/or values will trigger undefined behavior, where no guarantees can be made if the attribute will be enabled or not.
 */
public class BooleanAttribute extends class_1320 {
	public BooleanAttribute(String descriptionId, boolean defaultValue) {
		super(descriptionId, defaultValue ? 1 : 0);
	}

	@Override
	public double method_6165(double value) {
		if (Double.isNaN(value)) {
			return 0;
		}
		return value > 0 ? 1 : 0;
	}
}
