package io.github.fabricators_of_create.porting_lib.attributes.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1656;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_3244.class)
public class ServerGamePacketListenerImplMixin {
	@Shadow
	public class_3222 player;

	@WrapOperation(method = "handleMovePlayer", at = @At(value = "FIELD", target = "Lnet/minecraft/world/entity/player/Abilities;mayfly:Z"))
	private boolean mayFly1(class_1656 instance, Operation<Boolean> original) {
		return this.player.port_lib$mayFly(instance, original);
	}

	@WrapOperation(method = "handlePlayerAbilities", at = @At(value = "FIELD", target = "Lnet/minecraft/world/entity/player/Abilities;mayfly:Z"))
	private boolean mayFly2(class_1656 instance, Operation<Boolean> original) {
		return this.player.port_lib$mayFly(instance, original);
	}
}
