package io.github.fabricators_of_create.porting_lib.loot.mixin;

import io.github.fabricators_of_create.porting_lib.loot.LootTableIdCondition;
import io.github.fabricators_of_create.porting_lib.loot.PortingLibLoot;
import io.github.fabricators_of_create.porting_lib.loot.extensions.LootContextExtensions;
import net.minecraft.class_169;
import net.minecraft.class_2960;
import net.minecraft.class_47;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_47.class)
public abstract class LootContextMixin implements LootContextExtensions {
	@Shadow
	@Nullable
	public abstract <T> T getParamOrNull(class_169<T> lootContextParam);

	@Unique
	private class_2960 queriedLootTableId;

	@Override
	public void setQueriedLootTableId(class_2960 queriedLootTableId) {
		if (this.queriedLootTableId == null && queriedLootTableId != null)
			this.queriedLootTableId = queriedLootTableId;
	}

	@Override
	public class_2960 getQueriedLootTableId() {
		return this.queriedLootTableId == null ? LootTableIdCondition.UNKNOWN_LOOT_TABLE : this.queriedLootTableId;
	}
}
