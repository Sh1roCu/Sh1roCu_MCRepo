package io.github.fabricators_of_create.porting_lib.loot;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.DynamicOps;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import com.mojang.serialization.JsonOps;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ConditionalOps;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ICondition;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3518;
import net.minecraft.class_3695;
import net.minecraft.class_4309;
import net.minecraft.class_6903;
import net.minecraft.class_7225;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LootModifierManager extends class_4309 implements IdentifiableResourceReloadListener {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
	public static final Logger LOGGER = LogManager.getLogger();

	public static final LootModifierManager INSTANCE = new LootModifierManager();

	private class_7225.class_7874 registries;
	private Map<class_2960, IGlobalLootModifier> registeredLootModifiers = ImmutableMap.of();
	private static final String folder = "loot_modifiers";
	public static final class_2960 ID = PortingLib.id(folder);;

	public LootModifierManager() {
		super(GSON, folder);
	}

	public void injectContext(class_7225.class_7874 registries) {
		this.registries = registries;
	}

	@Override
	protected Map<class_2960, JsonElement> method_20731(class_3300 resourceManager, class_3695 profilerFiller) {
		Map<class_2960, JsonElement> map = super.method_20731(resourceManager, profilerFiller);
		List<class_2960> finalLocations = new ArrayList<>();
		class_2960 resourceLocation = PortingLib.neo("loot_modifiers/global_loot_modifiers.json");
		//read in all data files from neoforge:loot_modifiers/global_loot_modifiers in order to do layering
		for (class_3298 resource : resourceManager.method_14489(resourceLocation)) {
			try (Reader reader = resource.method_43039()) {
				JsonObject jsonobject = class_3518.method_15276(GSON, reader, JsonObject.class);
				boolean replace = class_3518.method_15258(jsonobject, "replace", false);
				if (replace)
					finalLocations.clear();
				JsonArray entries = class_3518.method_15261(jsonobject, "entries");
				for (int i = 0; i < entries.size(); i++) {
					class_2960 loc = class_2960.method_60654(class_3518.method_15287(entries.get(i), "entries[" + i + "]"));
					finalLocations.remove(loc); //remove and re-add if needed, to update the ordering.
					finalLocations.add(loc);
				}
			} catch (RuntimeException | IOException ioexception) {
				LOGGER.error("Couldn't read global loot modifier list {} in data pack {}", resourceLocation, resource.method_14480(), ioexception);
			}
		}
		Map<class_2960, JsonElement> finalMap = new HashMap<>();
		//use layered config to fetch modifier data files (modifiers missing from config are disabled)
		for (class_2960 location : finalLocations) {
			finalMap.put(location, map.get(location));
		}
		return finalMap;
	}

	@Override
	protected void apply(Map<class_2960, JsonElement> resourceList, class_3300 resourceManagerIn, class_3695 profilerIn) {
		DynamicOps<JsonElement> ops = new ConditionalOps<>(class_6903.method_46632(JsonOps.INSTANCE, registries), ICondition.IContext.EMPTY);
		Builder<class_2960, IGlobalLootModifier> builder = ImmutableMap.builder();
		for (Map.Entry<class_2960, JsonElement> entry : resourceList.entrySet()) {
			class_2960 location = entry.getKey();
			JsonElement json = entry.getValue();
			IGlobalLootModifier.CONDITIONAL_CODEC.parse(ops, json)
					// log error if parse fails
					.resultOrPartial(errorMsg -> LOGGER.warn("Could not decode GlobalLootModifier with json id {} - error: {}", location, errorMsg))
					// add loot modifier if parse succeeds
					.flatMap(Function.identity())
					.ifPresent(carrier -> builder.put(location, carrier.carrier()));
		}
		this.registeredLootModifiers = builder.build();
	}

	/**
	 * An immutable collection of the registered loot modifiers in layered order.
	 */
	public Collection<IGlobalLootModifier> getAllLootMods() {
		return registeredLootModifiers.values();
	}

	@Override
	public class_2960 getFabricId() {
		return ID;
	}
}
