package io.github.fabricators_of_create.porting_lib.loot.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;

import io.github.fabricators_of_create.porting_lib.loot.extensions.LootPoolBuilderExtension;
import io.github.fabricators_of_create.porting_lib.loot.extensions.LootPoolExtensions;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Optional;
import net.minecraft.class_55;

@Mixin(class_55.class)
public class LootPoolMixin implements LootPoolExtensions {
	@Unique
	private String name;

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@ModifyExpressionValue(
			method = "<clinit>",
			at = @At(value = "INVOKE", target = "Lcom/mojang/serialization/codecs/RecordCodecBuilder;create(Ljava/util/function/Function;)Lcom/mojang/serialization/Codec;")
	)
	private static Codec<class_55> modifyCodec(Codec<class_55> original) {
		// TODO: test this
		return Codec.pair(original, Codec.STRING.optionalFieldOf("name").codec()).xmap(pair -> {
			class_55 pool = pair.getFirst();
			pool.setName(pair.getSecond().filter(name -> !name.startsWith("custom#")).orElse(null));
			return pool;
		}, pool -> {
			String name = pool.getName();
			return Pair.of(pool, Optional.ofNullable(name));
		});
	}

	@Mixin(class_55.class_56.class)
	public static class LootPoolBuilderMixin implements LootPoolBuilderExtension {
		@Unique
		private String name;

		@Override
		public class_55.class_56 name(String name) {
			this.name = name;
			//noinspection DataFlowIssue
			return (class_55.class_56) (Object) this;
		}

		@ModifyReturnValue(method = "build", at = @At("RETURN"))
		public class_55 setName(class_55 pool) {
			pool.setName(name);
			return pool;
		}
	}
}
