package io.github.fabricators_of_create.porting_lib.loot.extensions;

import net.minecraft.class_55;

public interface LootPoolBuilderExtension {
	default class_55.class_56 name(String name) {
		throw new RuntimeException();
	}
}
