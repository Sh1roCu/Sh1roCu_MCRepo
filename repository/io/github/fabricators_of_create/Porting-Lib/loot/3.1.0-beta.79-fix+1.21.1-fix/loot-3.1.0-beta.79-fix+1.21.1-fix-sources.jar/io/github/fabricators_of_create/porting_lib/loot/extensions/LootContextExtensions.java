package io.github.fabricators_of_create.porting_lib.loot.extensions;

import net.minecraft.class_2960;

public interface LootContextExtensions {
	default void setQueriedLootTableId(class_2960 queriedLootTableId) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
	default class_2960 getQueriedLootTableId() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}
