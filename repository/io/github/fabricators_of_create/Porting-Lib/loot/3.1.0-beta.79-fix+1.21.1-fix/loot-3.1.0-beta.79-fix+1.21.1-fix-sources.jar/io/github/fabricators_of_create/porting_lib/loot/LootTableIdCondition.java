package io.github.fabricators_of_create.porting_lib.loot;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import net.minecraft.class_2960;
import net.minecraft.class_47;
import net.minecraft.class_5341;
import net.minecraft.class_5342;

public class LootTableIdCondition implements class_5341 {
	public static final MapCodec<LootTableIdCondition> CODEC = RecordCodecBuilder.mapCodec(
			builder -> builder
					.group(
							class_2960.field_25139.fieldOf("loot_table_id").forGetter(idCondition -> idCondition.targetLootTableId))
					.apply(builder, LootTableIdCondition::new));
	// TODO Forge Registry at some point?
	public static final class_5342 LOOT_TABLE_ID = new class_5342(CODEC);
	public static final class_2960 UNKNOWN_LOOT_TABLE = PortingLib.id("unknown_loot_table");

	private final class_2960 targetLootTableId;

	private LootTableIdCondition(final class_2960 targetLootTableId) {
		this.targetLootTableId = targetLootTableId;
	}

	@Override
	public class_5342 method_29325() {
		return LOOT_TABLE_ID;
	}

	@Override
	public boolean test(class_47 lootContext) {
		return lootContext.getQueriedLootTableId().equals(this.targetLootTableId);
	}

	public static Builder builder(final class_2960 targetLootTableId) {
		return new Builder(targetLootTableId);
	}

	public static class Builder implements class_5341.class_210 {
		private final class_2960 targetLootTableId;

		public Builder(class_2960 targetLootTableId) {
			if (targetLootTableId == null) throw new IllegalArgumentException("Target loot table must not be null");
			this.targetLootTableId = targetLootTableId;
		}

		@Override
		public class_5341 build() {
			return new LootTableIdCondition(this.targetLootTableId);
		}
	}
}
