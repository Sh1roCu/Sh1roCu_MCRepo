package io.github.fabricators_of_create.porting_lib.loot.extensions;

import net.minecraft.class_2960;

public interface PortingLibLootTableBuilder {
	default class_2960 getPortingLibLootTableId() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default void setPortingLibLootTableId(class_2960 id) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}
