package io.github.fabricators_of_create.porting_lib.loot;

import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_47;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;

public class LootCollector implements Consumer<class_1799> {
	private final Consumer<class_1799> wrapped;
	private final ObjectArrayList<class_1799> stacks = new ObjectArrayList<>();

	public LootCollector(Consumer<class_1799> wrapped) {
		this.wrapped = wrapped;
	}

	@Override
	public void accept(class_1799 stack) {
		this.stacks.add(stack);
	}

	public void finish(class_2960 tableId, class_47 ctx) {
		PortingLibLoot.modifyLoot(tableId, stacks, ctx).forEach(wrapped);
		stacks.clear();
	}
}
