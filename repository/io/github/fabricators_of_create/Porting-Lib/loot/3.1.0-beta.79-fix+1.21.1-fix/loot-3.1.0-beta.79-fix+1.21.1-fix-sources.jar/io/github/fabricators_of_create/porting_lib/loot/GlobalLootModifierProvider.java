package io.github.fabricators_of_create.porting_lib.loot;

import com.google.common.collect.ImmutableList;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ICondition;
import io.github.fabricators_of_create.porting_lib.resources.conditions.WithConditions;

/**
 * Provider for forge's GlobalLootModifier system. See {@link LootModifier}
 *
 * This provider only requires implementing {@link #start()} and calling {@link #add} from it.
 */
public abstract class GlobalLootModifierProvider implements class_2405 {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private final class_7784 output;
	private final CompletableFuture<class_7225.class_7874> registriesLookup;
	protected class_7225.class_7874 registries;
	private final String modid;
	private final Map<String, WithConditions<IGlobalLootModifier>> toSerialize = new HashMap<>();
	private boolean replace = false;

	public GlobalLootModifierProvider(class_7784 output, CompletableFuture<class_7225.class_7874> registries, String modid) {
		this.output = output;
		this.registriesLookup = registries;
		this.modid = modid;
	}

	/**
	 * Sets the "replace" key in global_loot_modifiers to true.
	 */
	protected void replacing() {
		this.replace = true;
	}

	/**
	 * Call {@link #add} here, which will pass in the necessary information to write the jsons.
	 */
	protected abstract void start();

	@Override
	public final CompletableFuture<?> method_10319(class_7403 cache) {
		return this.registriesLookup.thenCompose(registries -> this.run(cache, registries));
	}

	protected CompletableFuture<?> run(class_7403 cache, class_7225.class_7874 registries) {
		this.registries = registries;
		start();

		Path forgePath = this.output.method_45972(class_7784.class_7490.field_39367).resolve("neoforge").resolve("loot_modifiers").resolve("global_loot_modifiers.json");
		Path modifierFolderPath = this.output.method_45972(class_7784.class_7490.field_39367).resolve(this.modid).resolve("loot_modifiers");
		List<class_2960> entries = new ArrayList<>();

		ImmutableList.Builder<CompletableFuture<?>> futuresBuilder = new ImmutableList.Builder<>();

		for (var entry : toSerialize.entrySet()) {
			var name = entry.getKey();
			var lootModifier = entry.getValue();
			entries.add(class_2960.method_60655(modid, name));
			Path modifierPath = modifierFolderPath.resolve(name + ".json");
			futuresBuilder.add(class_2405.method_53496(cache, registries, IGlobalLootModifier.CONDITIONAL_CODEC, Optional.of(lootModifier), modifierPath));
		}

		JsonObject forgeJson = new JsonObject();
		forgeJson.addProperty("replace", this.replace);
		forgeJson.add("entries", GSON.toJsonTree(entries.stream().map(class_2960::toString).collect(Collectors.toList())));

		futuresBuilder.add(class_2405.method_10320(cache, forgeJson, forgePath));

		return CompletableFuture.allOf(futuresBuilder.build().toArray(CompletableFuture[]::new));
	}

	/**
	 * Passes in the data needed to create the file without any extra objects.
	 *
	 * @param modifier   the name of the modifier, which will be the file name
	 * @param instance   the instance to serialize
	 * @param conditions a list of conditions to add to the GLM file
	 */
	public <T extends IGlobalLootModifier> void add(String modifier, T instance, List<ICondition> conditions) {
		this.toSerialize.put(modifier, new WithConditions<>(conditions, instance));
	}

	/**
	 * Passes in the data needed to create the file without any extra objects.
	 *
	 * @param modifier   the name of the modifier, which will be the file name
	 * @param instance   the instance to serialize
	 * @param conditions a list of conditions to add to the GLM file
	 */
	public <T extends IGlobalLootModifier> void add(String modifier, T instance, ICondition... conditions) {
		add(modifier, instance, Arrays.asList(conditions));
	}

	@Override
	public String method_10321() {
		return "Global Loot Modifiers : " + modid;
	}
}
