package io.github.fabricators_of_create.porting_lib.loot.extensions;

import net.minecraft.class_2960;

public interface LootTableBuilderExtensions {
	void port_lib$setId(class_2960 id);
}
