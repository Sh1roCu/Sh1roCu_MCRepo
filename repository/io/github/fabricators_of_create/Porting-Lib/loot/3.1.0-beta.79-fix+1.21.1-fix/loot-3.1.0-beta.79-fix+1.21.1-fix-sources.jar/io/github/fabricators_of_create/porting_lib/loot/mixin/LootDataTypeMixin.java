package io.github.fabricators_of_create.porting_lib.loot.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import com.mojang.serialization.DynamicOps;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_52;
import net.minecraft.class_8490;

@Mixin(class_8490.class)
public class LootDataTypeMixin {
	@ModifyReturnValue(method = "deserialize", at = @At("RETURN"))
	private <V, T> Optional<T> setLootTableId(Optional<T> optional, class_2960 id, DynamicOps<V> ops, V object) {
		if (optional.isPresent() && optional.get() instanceof class_52 lootTable) {
			lootTable.setLootTableId(id);
		}
		return optional;
	}
}
