package io.github.fabricators_of_create.porting_lib.loot.extensions;

import net.minecraft.class_2960;

public interface LootTableExtensions {
	// hack to access a field defined in one mixin in another.
	default void setLootTableId(final class_2960 id) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default class_2960 getLootTableId() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}
