package io.github.fabricators_of_create.porting_lib.data.mixin;

import io.github.fabricators_of_create.porting_lib.data.extensions.RecipeOutputExtension;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ICondition;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_8779;
import net.minecraft.class_8790;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_8790.class)
public interface RecipeOutputMixin extends RecipeOutputExtension {
	@Shadow
	void accept(class_2960 location, class_1860<?> recipe, @Nullable class_8779 advancement);

	@Override
	default void accept(class_2960 id, class_1860<?> recipe, @Nullable class_8779 advancement, ICondition... conditions) {
		accept(id, recipe, advancement);
	}
}
