package io.github.fabricators_of_create.porting_lib.data;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

import com.google.gson.JsonElement;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.Encoder;
import com.mojang.serialization.JsonOps;

import io.github.fabricators_of_create.porting_lib.resources.conditions.ConditionalOps;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ICondition;
import io.github.fabricators_of_create.porting_lib.resources.conditions.WithConditions;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.event.registry.DynamicRegistries;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_5475;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7655;
import net.minecraft.class_7784;
import net.minecraft.class_7877;
import net.minecraft.class_8931;

/**
 * An extension of the {@link class_5475} which properly handles
 * referencing existing dynamic registry objects within another dynamic registry
 * object.
 */
public class DatapackBuiltinEntriesProvider extends class_5475 {
	private final CompletableFuture<class_7225.class_7874> fullRegistries;
	private final Predicate<String> namespacePredicate;
	private final Map<class_5321<?>, List<ICondition>> conditions;

	/**
	 * Constructs a new datapack provider which generates all registry objects
	 * from the provided mods using the holder.
	 *
	 * @param output     the target directory of the data generator
	 * @param registries a future of a lookup for registries and their objects
	 * @param modIds     a set of mod ids to generate the dynamic registry objects of
	 */
	public DatapackBuiltinEntriesProvider(FabricDataOutput output, CompletableFuture<class_7877.class_8993> registries, Set<String> modIds) {
		this(output, registries, (b) -> {
		}, modIds);
	}

	/**
	 * Constructs a new datapack provider which generates all registry objects
	 * from the provided mods using the holder.
	 *
	 * @param output            the target directory of the data generator
	 * @param registries        a future of a lookup for registries and their objects
	 * @param modIds            a set of mod ids to generate the dynamic registry objects of
	 * @param conditionsBuilder a builder for conditions to append to registry objects
	 */
	public DatapackBuiltinEntriesProvider(FabricDataOutput output, CompletableFuture<class_7877.class_8993> registries, Consumer<BiConsumer<class_5321<?>, ICondition>> conditionsBuilder, Set<String> modIds) {
		this(output, registries, buildConditionsMap(conditionsBuilder), modIds);
	}

	/**
	 * Constructs a new datapack provider which generates all registry objects
	 * from the provided mods using the holder.
	 *
	 * @param output     the target directory of the data generator
	 * @param registries a future of a lookup for registries and their objects
	 * @param modIds     a set of mod ids to generate the dynamic registry objects of
	 * @param conditions a map containing conditions to append to registry objects
	 */
	public DatapackBuiltinEntriesProvider(FabricDataOutput output, CompletableFuture<class_7877.class_8993> registries, Map<class_5321<?>, List<ICondition>> conditions, Set<String> modIds) {
		super(output, registries.thenApply(class_7877.class_8993::comp_2114));
		this.namespacePredicate = modIds == null ? namespace -> true : modIds::contains;
		this.conditions = conditions;
		this.fullRegistries = registries.thenApply(class_7877.class_8993::comp_2113);
	}

	/**
	 * Constructs a new datapack provider which generates all registry objects
	 * from the provided mods using the holder. All entries that need to be
	 * bootstrapped are provided within the {@link class_7877}.
	 *
	 * @param output                 the target directory of the data generator
	 * @param registries             a future of a lookup for registries and their objects
	 * @param datapackEntriesBuilder a builder containing the dynamic registry objects added by this provider
	 * @param modIds                 a set of mod ids to generate the dynamic registry objects of
	 */
	public DatapackBuiltinEntriesProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registries, class_7877 datapackEntriesBuilder, Set<String> modIds) {
		this(output, class_8931.method_54840(registries, datapackEntriesBuilder), modIds);
	}

	/**
	 * Constructs a new datapack provider which generates all registry objects
	 * from the provided mods using the holder. All entries that need to be
	 * bootstrapped are provided within the {@link class_7877}.
	 *
	 * @param output                 the target directory of the data generator
	 * @param registries             a future of a lookup for registries and their objects
	 * @param datapackEntriesBuilder a builder containing the dynamic registry objects added by this provider
	 * @param conditions             a map containing conditions to append to registry objects
	 * @param modIds                 a set of mod ids to generate the dynamic registry objects of
	 */
	public DatapackBuiltinEntriesProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registries, class_7877 datapackEntriesBuilder, Map<class_5321<?>, List<ICondition>> conditions, Set<String> modIds) {
		this(output, class_8931.method_54840(registries, datapackEntriesBuilder), conditions, modIds);
	}

	/**
	 * Constructs a new datapack provider which generates all registry objects
	 * from the provided mods using the holder. All entries that need to be
	 * bootstrapped are provided within the {@link class_7877}.
	 *
	 * @param output                 the target directory of the data generator
	 * @param registries             a future of a lookup for registries and their objects
	 * @param datapackEntriesBuilder a builder containing the dynamic registry objects added by this provider
	 * @param conditionsBuilder      a builder for conditions to append to registry objects
	 * @param modIds                 a set of mod ids to generate the dynamic registry objects of
	 */
	public DatapackBuiltinEntriesProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registries, class_7877 datapackEntriesBuilder, Consumer<BiConsumer<class_5321<?>, ICondition>> conditionsBuilder, Set<String> modIds) {
		this(output, class_8931.method_54840(registries, datapackEntriesBuilder), conditionsBuilder, modIds);
	}

	/**
	 * Get the registry holder lookup provider that includes elements added from the {@link class_7877}
	 */
	public CompletableFuture<class_7225.class_7874> getRegistryProvider() {
		return fullRegistries;
	}

	private static Map<class_5321<?>, List<ICondition>> buildConditionsMap(Consumer<BiConsumer<class_5321<?>, ICondition>> conditionBuilder) {
		Map<class_5321<?>, List<ICondition>> conditions = new IdentityHashMap<>();
		conditionBuilder.accept((key, condition) -> conditions.computeIfAbsent(key, k -> new ArrayList<>()).add(condition));
		return conditions;
	}

	@Override
	public CompletableFuture<?> method_10319(class_7403 output) {
		return this.field_40952
				.thenCompose(
						provider -> {
							DynamicOps<JsonElement> dynamicops = provider.method_57093(JsonOps.INSTANCE);
							return CompletableFuture.allOf(
									getDataPackRegistriesWithDimensions()
											.flatMap(
													data -> method_39678(output, provider, dynamicops, (class_7655.class_7657<?>) data).stream()
											)
											.toArray(CompletableFuture[]::new)
							);
						}
				);
	}

	public class_7784.class_7489 createRegistryElementsPathProvider(class_5321<? extends class_2378<?>> registryKey) {
		return this.field_40665.method_45973(class_7784.class_7490.field_39367, PortingLibDataHack.prefixNamespace(registryKey.method_29177()));
	}

	private <T> Optional<CompletableFuture<?>> method_39678(
			class_7403 output, class_7225.class_7874 provider, DynamicOps<JsonElement> dynamicOps, class_7655.class_7657<T> data
	) {
		class_5321<? extends class_2378<T>> resourcekey = data.comp_985();
		var conditionalCodec = ConditionalOps.createConditionalCodecWithConditions(data.comp_986());
		return provider.method_46759(resourcekey)
				.map(
						registryLookup -> {
							class_7784.class_7489 packoutput$pathprovider = createRegistryElementsPathProvider(resourcekey);
							return CompletableFuture.allOf(
									registryLookup.method_42017()
											.filter(holder -> this.namespacePredicate.test(holder.method_40237().method_29177().method_12836()))
											.map(
													ref -> dumpValueF(
															packoutput$pathprovider.method_44107(ref.method_40237().method_29177()),
															output,
															dynamicOps,
															conditionalCodec,
															Optional.of(new WithConditions<>(conditions.getOrDefault(ref.method_40237(), List.of()), ref.comp_349()))
													)
											)
											.toArray(CompletableFuture[]::new)
							);
						}
				);
	}

	private static <E> CompletableFuture<?> dumpValueF(
			Path path, class_7403 output, DynamicOps<JsonElement> dynamicOps, Encoder<Optional<WithConditions<E>>> encoder, Optional<WithConditions<E>> conditions
	) {
		return encoder.encodeStart(dynamicOps, conditions)
				.mapOrElse(
						json -> DataProvider.saveStable(output, json, path),
						p_351701_ -> CompletableFuture.failedFuture(new IllegalStateException("Couldn't generate file '" + path + "': " + p_351701_.message()))
				);
	}

	public static Stream<class_7655.class_7657<?>> getDataPackRegistriesWithDimensions() {
		return Stream.concat(DynamicRegistries.getDynamicRegistries().stream(), class_7655.field_39969.stream());
	}
}
