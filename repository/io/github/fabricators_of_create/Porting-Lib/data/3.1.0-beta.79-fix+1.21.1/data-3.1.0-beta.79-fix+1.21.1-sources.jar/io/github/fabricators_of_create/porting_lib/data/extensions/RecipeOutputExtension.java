package io.github.fabricators_of_create.porting_lib.data.extensions;

import io.github.fabricators_of_create.porting_lib.data.ConditionalRecipeOutput;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ICondition;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_8779;
import net.minecraft.class_8790;
import org.jetbrains.annotations.Nullable;

public interface RecipeOutputExtension {
	/**
	 * Generates a recipe with the given conditions.
	 */
	default void accept(class_2960 id, class_1860<?> recipe, @Nullable class_8779 advancement, ICondition... conditions) {
	}

	/**
	 * Builds a wrapper around this recipe output that adds conditions to all received recipes.
	 */
	default class_8790 withConditions(ICondition... conditions) {
		return new ConditionalRecipeOutput((class_8790) this, conditions);
	}
}
