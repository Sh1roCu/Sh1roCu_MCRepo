package io.github.fabricators_of_create.porting_lib.data;

import com.mojang.serialization.Lifecycle;
import org.jetbrains.annotations.ApiStatus;

import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7225;

public class PortingLibDataHack {
	@ApiStatus.Internal
	public static boolean inPatch = false;

	public static String prefixNamespace(class_2960 registryKey) {
		return registryKey.method_12836().equals("minecraft") ? registryKey.method_12832() : registryKey.method_12836() + "/" + registryKey.method_12832();
	}

	public static class DummyRegistryLookup<T> implements class_7225.class_7226<T> {

		private final class_7225.class_7226<T> registrylookup;

		public DummyRegistryLookup(class_7225.class_7226<T> registrylookup) {
			this.registrylookup = registrylookup;
		}

		@Override
		public class_5321<? extends class_2378<T>> method_46765() {
			return null;
		}

		@Override
		public Lifecycle method_46766() {
			return this.registrylookup.method_46766();
		}

		@Override
		public Stream<class_6880.class_6883<T>> method_42017() {
			return Stream.empty();
		}

		@Override
		public Stream<class_6885.class_6888<T>> method_42020() {
			return Stream.empty();
		}

		@Override
		public Optional<class_6880.class_6883<T>> method_46746(class_5321 resourceKey) {
			return Optional.empty();
		}

		@Override
		public Optional<class_6885.class_6888<T>> method_46733(class_6862 tagKey) {
			return Optional.empty();
		}
	}
}
