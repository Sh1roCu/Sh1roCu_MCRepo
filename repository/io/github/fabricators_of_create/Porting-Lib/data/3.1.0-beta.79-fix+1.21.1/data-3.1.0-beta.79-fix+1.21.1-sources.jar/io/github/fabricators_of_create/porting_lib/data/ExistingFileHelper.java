package io.github.fabricators_of_create.porting_lib.data;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import io.github.fabricators_of_create.porting_lib.data.extensions.MinecraftExtension;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_1064;
import net.minecraft.class_1065;
import net.minecraft.class_2405;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3258;
import net.minecraft.class_3259;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3268;
import net.minecraft.class_3286;
import net.minecraft.class_3288;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_5352;
import net.minecraft.class_542;
import net.minecraft.class_6861;
import net.minecraft.class_9224;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.VisibleForTesting;

/**
 * Enables data providers to check if other data files currently exist. The
 * instance provided in the {@link ExistingFileHelper#withResourcesFromArg()} utilizes the standard
 * resources (via {@link class_3268}), forge's resources, as well as any
 * extra resource packs passed in via the {@code --existing} argument,
 * or mod resources via the {@code --existing-mod} argument.
 */
public class ExistingFileHelper {
	public interface IResourceType {
		class_3264 getPackType();

		String getSuffix();

		String getPrefix();
	}

	public static class ResourceType implements IResourceType {
		final class_3264 packType;
		final String suffix, prefix;

		public ResourceType(class_3264 type, String suffix, String prefix) {
			this.packType = type;
			this.suffix = suffix;
			this.prefix = prefix;
		}

		@Override
		public class_3264 getPackType() {
			return packType;
		}

		@Override
		public String getSuffix() {
			return suffix;
		}

		@Override
		public String getPrefix() {
			return prefix;
		}
	}

	private final class_6861 clientResources, serverData;
	private final boolean enable;
	private final Multimap<class_3264, class_2960> generated = HashMultimap.create();

	// fabric: added factory methods

	public static final String EXISTING_RESOURCES = "porting_lib.datagen.existing_resources";

	public static final String EXISTING_MODS = "porting_lib.datagen.existing-mod";

	/**
	 * Create a helper with existing resources provided from a JVM argument.
	 * To use, a JVM argument mapping {@link ExistingFileHelper#EXISTING_RESOURCES the key}
	 * to the desired resource directory is required.
	 */
	public static ExistingFileHelper withResourcesFromArg() {
		String property = System.getProperty(EXISTING_RESOURCES);
		if (property == null)
			throw new IllegalArgumentException("Existing resources not specified with '" + EXISTING_RESOURCES + "' argument");
		Path path = Paths.get(property);
		if (!Files.isDirectory(path))
			throw new IllegalStateException("Path " + property + " is not a directory or does not exist");
		String mods = System.getProperty(EXISTING_MODS);
		if (mods == null)
			mods = "";
		return withResources(new HashSet<>(List.of(mods.split(","))), path);
	}

	/**
	 * Create a helper with the provided paths being used for resources.
	 */
	public static ExistingFileHelper withResources(Path... paths) {
		class_542 gameConfig = ((MinecraftExtension) class_310.method_1551()).port_lib$getGameConfig();
		List<Path> resources = List.of(paths);
		return new ExistingFileHelper(resources, Set.of(), true, gameConfig.field_3277.field_3288, gameConfig.field_3277.field_3289);
	}

	/**
	 * Create a helper with the provided paths being used for resources.
	 */
	public static ExistingFileHelper withResources(Set<String> mods, Path... paths) {
		class_542 gameConfig = ((MinecraftExtension) class_310.method_1551()).port_lib$getGameConfig();
		List<Path> resources = List.of(paths);
		return new ExistingFileHelper(resources, mods, true, gameConfig.field_3277.field_3288, gameConfig.field_3277.field_3289);
	}

	/**
	 * Create a new helper. This should probably <em>NOT</em> be used by mods, as
	 * the instance provided by forge is designed to be a central instance that
	 * tracks existence of generated data.
	 * <p>
	 * Only create a new helper if you intentionally want to ignore the existence of
	 * other generated files.
	 *
	 * @param existingPacks a collection of paths to existing packs
	 * @param existingMods  a set of mod IDs for existing mods
	 * @param enable        {@code true} if validation is enabled
	 * @param assetIndex    the identifier for the asset index, generally Minecraft's current major version
	 * @param assetsDir     the directory in which to find vanilla assets and indexes
	 */
	public ExistingFileHelper(Collection<Path> existingPacks, final Set<String> existingMods, boolean enable, @Nullable final String assetIndex, @Nullable final File assetsDir) {
		List<class_3262> candidateClientResources = new ArrayList<>();
		List<class_3262> candidateServerResources = new ArrayList<>();

		if (assetIndex != null && assetsDir != null && assetsDir.exists()) {
			candidateClientResources.add(class_1065.method_45857(class_1064.method_45858(assetsDir.toPath(), assetIndex)));
		}
		candidateServerResources.add(class_3286.method_45287());
		for (Path existing : existingPacks) {
			File file = existing.toFile();
			if (!file.exists())
				continue;
			class_3262 pack = file.isDirectory() ? new class_3259(new class_9224(file.getName(), class_2561.method_43473(), class_5352.field_25348, Optional.empty()), file.toPath()) : new class_3258(new class_9224(file.getName(), class_2561.method_43473(), class_5352.field_25348, Optional.empty()), new class_3258.class_8616(file), "");
			candidateClientResources.add(pack);
			candidateServerResources.add(pack);
		}
		for (String existingMod : existingMods) {
			Optional<ModContainer> modFileInfo = FabricLoader.getInstance().getModContainer(existingMod);
			modFileInfo.ifPresent(modContainer -> {
				// Only opens primary packs - overlays are not currently considered for datagen
				final String name = "mod/" + existingMod;
				candidateClientResources.add(createPackForMod(modContainer).method_52424(new class_9224(name, class_2561.method_43473(), class_5352.field_25348, Optional.empty())));
				candidateServerResources.add(createPackForMod(modContainer).method_52424(new class_9224(name, class_2561.method_43473(), class_5352.field_25348, Optional.empty())));
			});
		}

		this.clientResources = new class_6861(class_3264.field_14188, candidateClientResources);
		this.serverData = new class_6861(class_3264.field_14190, candidateServerResources);

		this.enable = enable;
	}

	public static class_3288.class_7680 createPackForMod(ModContainer mf) {
		return new class_3259.class_8619(mf.getRootPath());
	}

	private class_3300 getManager(class_3264 packType) {
		return packType == class_3264.field_14188 ? clientResources : serverData;
	}

	private class_2960 getLocation(class_2960 base, String suffix, String prefix) {
		return class_2960.method_60655(base.method_12836(), prefix + "/" + base.method_12832() + suffix);
	}

	/**
	 * Check if a given resource exists in the known resource packs.
	 *
	 * @param loc      the complete location of the resource, e.g.
	 *                 {@code "minecraft:textures/block/stone.png"}
	 * @param packType the type of resources to check
	 * @return {@code true} if the resource exists in any pack, {@code false}
	 *         otherwise
	 */
	public boolean exists(class_2960 loc, class_3264 packType) {
		if (!enable) {
			return true;
		}
		return generated.get(packType).contains(loc) || getManager(packType).method_14486(loc).isPresent();
	}

	/**
	 * Check if a given resource exists in the known resource packs. This is a
	 * convenience method to avoid repeating type/prefix/suffix and instead use the
	 * common definitions in {@link ResourceType}, or a custom {@link IResourceType}
	 * definition.
	 *
	 * @param loc  the base location of the resource, e.g.
	 *             {@code "minecraft:block/stone"}
	 * @param type a {@link IResourceType} describing how to form the path to the
	 *             resource
	 * @return {@code true} if the resource exists in any pack, {@code false}
	 *         otherwise
	 */
	public boolean exists(class_2960 loc, IResourceType type) {
		return exists(getLocation(loc, type.getSuffix(), type.getPrefix()), type.getPackType());
	}

	/**
	 * Check if a given resource exists in the known resource packs.
	 *
	 * @param loc        the base location of the resource, e.g.
	 *                   {@code "minecraft:block/stone"}
	 * @param packType   the type of resources to check
	 * @param pathSuffix a string to append after the path, e.g. {@code ".json"}
	 * @param pathPrefix a string to append before the path, before a slash, e.g.
	 *                   {@code "models"}
	 * @return {@code true} if the resource exists in any pack, {@code false}
	 *         otherwise
	 */
	public boolean exists(class_2960 loc, class_3264 packType, String pathSuffix, String pathPrefix) {
		return exists(getLocation(loc, pathSuffix, pathPrefix), packType);
	}

	/**
	 * Track the existence of a generated file. This is a convenience method to
	 * avoid repeating type/prefix/suffix and instead use the common definitions in
	 * {@link ResourceType}, or a custom {@link IResourceType} definition.
	 * <p>
	 * This should be called by data providers immediately when a new data object is
	 * created, i.e. not during
	 * {@link class_2405#method_10319(net.minecraft.class_7403) run} but instead
	 * when the "builder" (or whatever intermediate object) is created, such as a
	 * {@link ModelBuilder}.
	 * <p>
	 * This represents a <em>promise</em> to generate the file later, since other
	 * datagen may rely on this file existing.
	 *
	 * @param loc  the base location of the resource, e.g.
	 *             {@code "minecraft:block/stone"}
	 * @param type a {@link IResourceType} describing how to form the path to the
	 *             resource
	 */
	public void trackGenerated(class_2960 loc, IResourceType type) {
		this.generated.put(type.getPackType(), getLocation(loc, type.getSuffix(), type.getPrefix()));
	}

	/**
	 * Track the existence of a generated file.
	 * <p>
	 * This should be called by data providers immediately when a new data object is
	 * created, i.e. not during
	 * {@link class_2405#method_10319(net.minecraft.class_7403) run} but instead
	 * when the "builder" (or whatever intermediate object) is created, such as a
	 * {@link ModelBuilder}.
	 * <p>
	 * This represents a <em>promise</em> to generate the file later, since other
	 * datagen may rely on this file existing.
	 *
	 * @param loc        the base location of the resource, e.g.
	 *                   {@code "minecraft:block/stone"}
	 * @param packType   the type of resources to check
	 * @param pathSuffix a string to append after the path, e.g. {@code ".json"}
	 * @param pathPrefix a string to append before the path, before a slash, e.g.
	 *                   {@code "models"}
	 */
	public void trackGenerated(class_2960 loc, class_3264 packType, String pathSuffix, String pathPrefix) {
		this.generated.put(packType, getLocation(loc, pathSuffix, pathPrefix));
	}

	@VisibleForTesting
	public class_3298 getResource(class_2960 loc, class_3264 packType, String pathSuffix, String pathPrefix) throws FileNotFoundException {
		return getResource(getLocation(loc, pathSuffix, pathPrefix), packType);
	}

	@VisibleForTesting
	public class_3298 getResource(class_2960 loc, class_3264 packType) throws FileNotFoundException {
		return getManager(packType).getResourceOrThrow(loc);
	}

	@VisibleForTesting
	public List<class_3298> getResourceStack(class_2960 loc, class_3264 packType) {
		return getManager(packType).method_14489(loc);
	}

	/**
	 * @return {@code true} if validation is enabled, {@code false} otherwise
	 */
	public boolean isEnabled() {
		return enable;
	}
}
