package io.github.fabricators_of_create.porting_lib.data;

import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Lifecycle;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import net.minecraft.class_156;
import net.minecraft.class_173;
import net.minecraft.class_2370;
import net.minecraft.class_2385;
import net.minecraft.class_2405;
import net.minecraft.class_2438;
import net.minecraft.class_2960;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_58;
import net.minecraft.class_6673;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7871;
import net.minecraft.class_7924;
import net.minecraft.class_8564;
import net.minecraft.class_8942;
import net.minecraft.class_9248;
import org.slf4j.Logger;

public class ModdedLootTableProvider implements class_2405 {
	private static final Logger LOGGER = LogUtils.getLogger();
	private final class_7784.class_7489 pathProvider;
	private final Set<class_5321<class_52>> requiredTables;
	private final List<class_2438.class_7790> subProviders;
	private final CompletableFuture<class_7225.class_7874> registries;

	public ModdedLootTableProvider(
			class_7784 output,
			Set<class_5321<class_52>> requiredTables,
			List<class_2438.class_7790> subProviders,
			CompletableFuture<class_7225.class_7874> registries
	) {
		this.pathProvider = output.method_60917(class_7924.field_50079);
		this.subProviders = subProviders;
		this.requiredTables = requiredTables;
		this.registries = registries;
	}

	@Override
	public CompletableFuture<?> method_10319(class_7403 output) {
		return this.registries.thenCompose(provider -> this.run(output, provider));
	}

	private CompletableFuture<?> run(class_7403 output, class_7225.class_7874 provider) {
		class_2385<class_52> writableregistry = new class_2370<>(class_7924.field_50079, Lifecycle.experimental());
		Map<class_6673.class_6674, class_2960> map = new Object2ObjectOpenHashMap<>();
		getTables().forEach(entry -> entry.comp_1068().apply(provider).method_10399((key, builder) -> {
			class_2960 resourcelocation = sequenceIdForLootTable(key);
			class_2960 resourcelocation1 = map.put(class_8564.method_52171(resourcelocation), resourcelocation);
			if (resourcelocation1 != null) {
				class_156.method_33559("Loot table random sequence seed collision on " + resourcelocation1 + " and " + key.method_29177());
			}

			builder.method_51883(resourcelocation);
			class_52 loottable = builder.method_334(entry.comp_1069()).method_338();
			writableregistry.method_10272(key, loottable, class_9248.field_49136);
		}));
		writableregistry.method_40276();
		class_8942.class_8943 problemreporter$collector = new class_8942.class_8943();
		class_7871.class_7872 holdergetter$provider = new class_5455.class_6891(List.of(writableregistry)).method_40316().method_46758();
		class_58 validationcontext = new class_58(problemreporter$collector, class_173.field_1177, holdergetter$provider);

		validate(writableregistry, validationcontext, problemreporter$collector);

		Multimap<String, String> multimap = problemreporter$collector.method_54948();
		if (!multimap.isEmpty()) {
			multimap.forEach((key, id) -> field_40831.warn("Found validation problem in {}: {}", key, id));
			throw new IllegalStateException("Failed to validate loot tables, see logs");
		} else {
			return CompletableFuture.allOf(writableregistry.method_29722().stream().map(entry -> {
				class_5321<class_52> key = entry.getKey();
				class_52 loottable = entry.getValue();
				Path path = this.pathProvider.method_44107(key.method_29177());
				return class_2405.method_53496(output, provider, class_52.field_50021, loottable, path);
			}).toArray(CompletableFuture[]::new));
		}
	}

	public List<class_2438.class_7790> getTables() {
		return this.subProviders;
	}

	protected void validate(class_2385<class_52> writableregistry, class_58 validationcontext, class_8942.class_8943 problemreporter$collector) {
		for(class_5321<class_52> resourcekey : Sets.difference(this.requiredTables, writableregistry.method_42021())) {
			problemreporter$collector.method_54947("Missing built-in table: " + resourcekey.method_29177());
		}

		writableregistry.method_40270().forEach(holder -> {
			holder.comp_349().method_330(validationcontext.method_22568(holder.comp_349().method_322()).method_51219("{" + holder.method_40237().method_29177() + "}", holder.method_40237()));
		});
	}

	private static class_2960 sequenceIdForLootTable(class_5321<class_52> tableKey) {
		return tableKey.method_29177();
	}

	@Override
	public final String method_10321() {
		return "Loot Tables";
	}
}
