package io.github.fabricators_of_create.porting_lib.data;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Maps;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1887;
import net.minecraft.class_190;
import net.minecraft.class_1935;
import net.minecraft.class_2022;
import net.minecraft.class_2035;
import net.minecraft.class_2040;
import net.minecraft.class_2048;
import net.minecraft.class_2073;
import net.minecraft.class_2096;
import net.minecraft.class_215;
import net.minecraft.class_3735;
import net.minecraft.class_39;
import net.minecraft.class_44;
import net.minecraft.class_47;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5341;
import net.minecraft.class_55;
import net.minecraft.class_7106;
import net.minecraft.class_7225;
import net.minecraft.class_7378;
import net.minecraft.class_7699;
import net.minecraft.class_77;
import net.minecraft.class_7791;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_83;
import net.minecraft.class_8551;
import net.minecraft.class_9356;
import net.minecraft.class_9361;
import net.minecraft.class_9636;

public abstract class ModdedEntityLootSubProvider implements class_7791 {
	private static final Set<class_1299<?>> SPECIAL_LOOT_TABLE_TYPES = ImmutableSet.of(
			class_1299.field_6097, class_1299.field_6131, class_1299.field_6147, class_1299.field_6047, class_1299.field_6077
	);
	protected final class_7225.class_7874 registries;
	private final class_7699 allowed;
	private final class_7699 required;
	private final Map<class_1299<?>, Map<class_5321<class_52>, class_52.class_53>> map = Maps.newHashMap();

	protected final class_8551.class_8552 shouldSmeltLoot() {
		class_7225.class_7226<class_1887> registrylookup = this.registries.method_46762(class_7924.field_41265);
		return class_8551.method_51727(
				class_215.method_917(
						class_47.class_50.field_935, class_2048.class_2049.method_8916().method_8919(class_2040.class_2041.method_8897().method_8898(true))
				),
				class_215.method_917(
						class_47.class_50.field_939,
						class_2048.class_2049.method_8916()
								.method_53141(
										class_3735.class_5278.method_27965()
												.method_35195(
														class_2073.class_2074.method_8973()
																.method_58179(
																		class_9361.field_49807,
																		class_9356.method_58173(
																				List.of(new class_2035(registrylookup.method_46735(class_9636.field_51552), class_2096.class_2100.field_9708))
																		)
																)
												)
								)
				)
		);
	}

	protected ModdedEntityLootSubProvider(class_7699 required, class_7225.class_7874 registries) {
		this(required, required, registries);
	}

	protected ModdedEntityLootSubProvider(class_7699 allowed, class_7699 required, class_7225.class_7874 registries) {
		this.allowed = allowed;
		this.required = required;
		this.registries = registries;
	}

	protected static class_52.class_53 createSheepTable(class_1935 item) {
		return class_52.method_324()
				.method_336(class_55.method_347().method_352(class_44.method_32448(1.0F)).method_351(class_77.method_411(item)))
				.method_336(class_55.method_347().method_352(class_44.method_32448(1.0F)).method_351(class_83.method_428(class_1299.field_6115.method_16351())));
	}

	public abstract void generate();

	protected Stream<class_1299<?>> getKnownEntityTypes() {
		return class_7923.field_41177.method_10220();
	}

	@Override
	public void method_10399(BiConsumer<class_5321<class_52>, class_52.class_53> p_251751_) {
		this.generate();
		Set<class_5321<class_52>> set = new HashSet<>();
		this.getKnownEntityTypes()
				.map(class_1299::method_40124)
				.forEach(
						p_266624_ -> {
							class_1299<?> entitytype = p_266624_.comp_349();
							if (entitytype.method_45382(this.allowed)) {
								if (canHaveLootTable(entitytype)) {
									Map<class_5321<class_52>, class_52.class_53> tables = this.map.remove(entitytype);
									class_5321<class_52> resourcekey = entitytype.method_16351();
									if (resourcekey != class_39.field_844 && entitytype.method_45382(this.required) && (tables == null || !tables.containsKey(resourcekey))
									)
									{
										throw new IllegalStateException(
												String.format(Locale.ROOT, "Missing loottable '%s' for '%s'", resourcekey, p_266624_.method_40237().method_29177())
										);
									}

									if (tables != null) {
										tables.forEach(
												(location, builder) -> {
													if (!set.add(location)) {
														throw new IllegalStateException(
																String.format(Locale.ROOT, "Duplicate loottable '%s' for '%s'", location, p_266624_.method_40237().method_29177())
														);
													} else {
														p_251751_.accept(location, builder);
													}
												}
										);
									}
								} else {
									Map<class_5321<class_52>, class_52.class_53> map1 = this.map.remove(entitytype);
									if (map1 != null) {
										throw new IllegalStateException(
												String.format(
														Locale.ROOT,
														"Weird loottables '%s' for '%s', not a LivingEntity so should not have loot",
														map1.keySet().stream().map(key -> key.method_29177().toString()).collect(Collectors.joining(",")),
														p_266624_.method_40237().method_29177()
												)
										);
									}
								}
							}
						}
				);
		if (!this.map.isEmpty()) {
			throw new IllegalStateException("Created loot tables for entities not supported by datapack: " + this.map.keySet());
		}
	}

	protected boolean canHaveLootTable(class_1299<?> type) {
		return SPECIAL_LOOT_TABLE_TYPES.contains(type) || type.method_5891() != class_1311.field_17715;
	}

	protected class_5341.class_210 killedByFrog() {
		return class_190.method_837(class_2022.class_2023.method_8855().method_35131(class_2048.class_2049.method_8916().method_8921(class_1299.field_37419)));
	}

	protected class_5341.class_210 killedByFrogVariant(class_5321<class_7106> key) {
		return class_190.method_837(
				class_2022.class_2023.method_8855()
						.method_35131(
								class_2048.class_2049.method_8916()
										.method_8921(class_1299.field_37419)
										.method_43094(class_7378.method_58154(class_7923.field_41164.method_40290(key)))
						)
		);
	}

	protected void add(class_1299<?> type, class_52.class_53 builder) {
		this.add(type, type.method_16351(), builder);
	}

	protected void add(class_1299<?> type, class_5321<class_52> key, class_52.class_53 builder) {
		this.map.computeIfAbsent(type, t -> new HashMap<>()).put(key, builder);
	}
}
