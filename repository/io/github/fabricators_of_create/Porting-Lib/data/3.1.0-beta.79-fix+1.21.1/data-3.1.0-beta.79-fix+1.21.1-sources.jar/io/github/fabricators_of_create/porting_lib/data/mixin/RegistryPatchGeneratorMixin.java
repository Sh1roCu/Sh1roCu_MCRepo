package io.github.fabricators_of_create.porting_lib.data.mixin;

import io.github.fabricators_of_create.porting_lib.data.PortingLibDataHack;
import net.minecraft.class_7225;
import net.minecraft.class_7877;
import net.minecraft.class_8931;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_8931.class)
public class RegistryPatchGeneratorMixin {
	@Inject(method = "method_54839", at = @At(value = "FIELD", target = "Lnet/minecraft/resources/RegistryDataLoader;WORLDGEN_REGISTRIES:Ljava/util/List;"))
	private static void enableWithDimensions(class_7877 registrySetBuilder, class_7225.class_7874 provider, CallbackInfoReturnable<class_7877.class_8993> cir) {
		PortingLibDataHack.inPatch = true;
	}
}
