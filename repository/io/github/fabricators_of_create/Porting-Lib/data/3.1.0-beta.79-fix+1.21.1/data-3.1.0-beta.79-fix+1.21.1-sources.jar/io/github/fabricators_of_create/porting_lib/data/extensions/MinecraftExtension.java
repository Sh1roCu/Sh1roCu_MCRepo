package io.github.fabricators_of_create.porting_lib.data.extensions;

import net.minecraft.class_542;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public interface MinecraftExtension {
	class_542 port_lib$getGameConfig();
}
