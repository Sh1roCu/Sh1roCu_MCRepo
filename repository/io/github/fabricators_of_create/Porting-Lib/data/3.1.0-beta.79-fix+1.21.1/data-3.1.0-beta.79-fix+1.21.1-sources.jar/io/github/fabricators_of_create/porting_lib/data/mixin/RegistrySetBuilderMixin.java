package io.github.fabricators_of_create.porting_lib.data.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.llamalad7.mixinextras.sugar.Cancellable;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.data.PortingLibDataHack;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7877;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_7877.class)
public class RegistrySetBuilderMixin {
	@WrapOperation(
			method = "createLazyFullPatchedRegistries(Lnet/minecraft/core/HolderOwner;Lnet/minecraft/core/Cloner$Factory;Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/core/HolderLookup$Provider;Lnet/minecraft/core/HolderLookup$Provider;Lorg/apache/commons/lang3/mutable/MutableObject;)Lnet/minecraft/core/HolderLookup$RegistryLookup;",
			at = @At(
					value = "INVOKE", target = "Lnet/minecraft/core/HolderLookup$Provider;lookupOrThrow(Lnet/minecraft/resources/ResourceKey;)Lnet/minecraft/core/HolderLookup$RegistryLookup;",
					ordinal = 1
			)
	)
	private <T> class_7225.class_7226<T> bypassException(class_7225.class_7874 instance, class_5321<? extends class_2378<? extends T>> registryKey, Operation<class_7225.class_7226<T>> original, @Local(ordinal = 0) class_7225.class_7226<T> registrylookup) {
		try {
			return original.call(instance, registryKey);
		} catch (Throwable ex) {
			return new PortingLibDataHack.DummyRegistryLookup<>(registrylookup);
		}
	}
}
