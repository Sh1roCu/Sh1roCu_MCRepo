package io.github.fabricators_of_create.porting_lib.data;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2474;
import net.minecraft.class_3495;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7889;
import net.minecraft.class_7924;

public abstract class PortingLibItemTagsProvider extends class_7889<class_1792> {
	/** A function that resolves block tag builders. */
	private final CompletableFuture<class_8211<class_2248>> blockTags;
	private final Map<class_6862<class_2248>, class_6862<class_1792>> tagsToCopy = new HashMap<>();

	public PortingLibItemTagsProvider(class_7784 p_275343_, CompletableFuture<class_7225.class_7874> p_275729_, CompletableFuture<class_2474.class_8211<class_2248>> p_275322_, String modId) {
		super(p_275343_, class_7924.field_41197, p_275729_, (p_255790_) -> {
			return p_255790_.method_40131().method_40237();
		});
		this.blockTags = p_275322_;
	}

	/**
	 * Copies the entries from a block tag into an item tag.
	 */
	protected void copy(class_6862<class_2248> pBlockTag, class_6862<class_1792> pItemTag) {
		this.tagsToCopy.put(pBlockTag, pItemTag);
	}

	protected CompletableFuture<class_7225.class_7874> method_49651() {
		return super.method_49651().thenCombineAsync(this.blockTags, (p_274766_, p_274767_) -> {
			this.tagsToCopy.forEach((p_274763_, p_274764_) -> {
				class_3495 tagbuilder = this.method_27169(p_274764_);
				Optional<class_3495> optional = p_274767_.apply(p_274763_);
				optional.orElseThrow(() -> {
					return new IllegalStateException("Missing block tag " + p_274764_.comp_327());
				}).method_26782().forEach(tagbuilder::method_27064);
			});
			return p_274766_;
		});
	}
}
