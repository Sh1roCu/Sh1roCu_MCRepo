package io.github.fabricators_of_create.porting_lib.data.mixin;

import io.github.fabricators_of_create.porting_lib.resources.conditions.ICondition;
import io.github.fabricators_of_create.porting_lib.resources.conditions.PortingLibConditions;
import io.github.fabricators_of_create.porting_lib.resources.conditions.WithConditions;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1860;
import net.minecraft.class_2405;
import net.minecraft.class_2446;
import net.minecraft.class_2960;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_8779;
import net.minecraft.class_8790;

@Mixin(targets = "net.minecraft.data.recipes.RecipeProvider$1")
public abstract class RecipeProvider$RecipeOutputMixin implements class_8790 {
	@Shadow
	@Final
	Set<class_2960> val$allRecipes;

	@Shadow
	@Final
	List<CompletableFuture<?>> val$tasks;

	@Shadow
	@Final
	class_7403 val$cache;

	@Shadow
	@Final
	class_7225.class_7874 val$registries;

	@Shadow
	@Final
	class_2446 field_46148;

	public void accept(class_2960 location, class_1860<?> recipe, @Nullable class_8779 advancement, ICondition... conditions) {
		if (!val$allRecipes.add(location)) {
			throw new IllegalStateException("Duplicate recipe " + location);
		} else {
			val$tasks.add(class_2405.method_53496(val$cache, val$registries, PortingLibConditions.CONDITIONAL_RECIPES_CODEC, Optional.of(new WithConditions<>(recipe, conditions)), ((RecipeProviderAccessor) field_46148).getRecipePathProvider().method_44107(location)));
			if (advancement != null) {
				val$tasks.add(class_2405.method_53496(val$cache, val$registries, PortingLibConditions.CONDITIONAL_ADVANCEMENTS_CODEC, Optional.of(new WithConditions<>(advancement.comp_1920(), conditions)), ((RecipeProviderAccessor) field_46148).getAdvancementPathProvider().method_44107(advancement.comp_1919())));
			}

		}
	}
}
