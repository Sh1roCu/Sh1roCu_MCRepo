package io.github.fabricators_of_create.porting_lib.data;

import io.github.fabricators_of_create.porting_lib.data.extensions.RecipeOutputExtension;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ICondition;
import net.minecraft.class_161;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_8779;
import net.minecraft.class_8790;
import org.apache.commons.lang3.ArrayUtils;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * Wrapper around a {@link class_8790} that adds conditions to all received recipes.
 * Do not use directly, obtain via {@link RecipeOutputExtension#withConditions(ICondition...)}.
 */
@ApiStatus.Internal
public class ConditionalRecipeOutput implements class_8790 {
	private final class_8790 inner;
	private final ICondition[] conditions;

	public ConditionalRecipeOutput(class_8790 inner, ICondition[] conditions) {
		this.inner = inner;
		this.conditions = conditions;
	}

	@Override
	public class_161.class_162 method_53818() {
		return inner.method_53818();
	}

	@Override
	public void method_53819(class_2960 location, class_1860<?> recipe, @Nullable class_8779 advancement) {
		ICondition[] innerConditions;
		if (conditions.length == 0) {
			innerConditions = this.conditions;
		} else if (this.conditions.length == 0) {
			innerConditions = conditions;
		} else {
			innerConditions = ArrayUtils.addAll(this.conditions, conditions);
		}
		inner.method_53819(location, recipe, advancement, innerConditions);
	}

	@Override
	public void accept(class_2960 id, class_1860<?> recipe, @Nullable class_8779 advancement, ICondition... conditions) {
		ICondition[] innerConditions;
		if (conditions.length == 0) {
			innerConditions = this.conditions;
		} else if (this.conditions.length == 0) {
			innerConditions = conditions;
		} else {
			innerConditions = ArrayUtils.addAll(this.conditions, conditions);
		}
		inner.method_53819(id, recipe, advancement, innerConditions);
	}
}

