package io.github.fabricators_of_create.porting_lib.data;

import com.google.gson.JsonObject;
import java.nio.file.Path;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import net.minecraft.class_1291;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7403;
import net.minecraft.class_7784;

public abstract class LanguageProvider implements class_2405 {

	String TRANSLATION_PREFIX = "dimension";

	private final Map<String, String> data = new TreeMap<>();
	private final class_7784 output;
	private final String modid;
	private final String locale;

	public LanguageProvider(class_7784 output, String modid, String locale) {
		this.output = output;
		this.modid = modid;
		this.locale = locale;
	}

	protected abstract void addTranslations();

	@Override
	public CompletableFuture<?> method_10319(class_7403 cache) {
		addTranslations();

		if (!data.isEmpty())
			return save(cache, this.output.method_45972(class_7784.class_7490.field_39368).resolve(this.modid).resolve("lang").resolve(this.locale + ".json"));

		return CompletableFuture.allOf();
	}

	@Override
	public String method_10321() {
		return "Languages: " + locale + " for mod: " + modid;
	}

	private CompletableFuture<?> save(class_7403 cache, Path target) {
		// TODO: DataProvider.saveStable handles the caching and hashing already, but creating the JSON Object this way seems unreliable. -C
		JsonObject json = new JsonObject();
		this.data.forEach(json::addProperty);

		return class_2405.method_10320(cache, json, target);
	}

	public void addBlock(Supplier<? extends class_2248> key, String name) {
		add(key.get(), name);
	}

	public void add(class_2248 key, String name) {
		add(key.method_9539(), name);
	}

	public void addItem(Supplier<? extends class_1792> key, String name) {
		add(key.get(), name);
	}

	public void add(class_1792 key, String name) {
		add(key.method_7876(), name);
	}

	public void addItemStack(Supplier<class_1799> key, String name) {
		add(key.get(), name);
	}

	public void add(class_1799 key, String name) {
		add(key.method_7922(), name);
	}

    /*
    public void addBiome(Supplier<? extends Biome> key, String name) {
        add(key.get(), name);
    }

    public void add(Biome key, String name) {
        add(key.getTranslationKey(), name);
    }
    */

	public void addEffect(Supplier<? extends class_1291> key, String name) {
		add(key.get(), name);
	}

	public void add(class_1291 key, String name) {
		add(key.method_5567(), name);
	}

	public void addEntityType(Supplier<? extends class_1299<?>> key, String name) {
		add(key.get(), name);
	}

	public void add(class_1299<?> key, String name) {
		add(key.method_5882(), name);
	}

	public void addTag(Supplier<? extends class_6862<?>> key, String name) {
		add(key.get(), name);
	}

	public void add(class_6862<?> tagKey, String name) {
		add(getTagTranslationKey(tagKey), name);
	}

	public void add(String key, String value) {
		if (data.put(key, value) != null)
			throw new IllegalStateException("Duplicate translation key " + key);
	}

	public void addDimension(class_5321<class_1937> dimension, String value) {
		add(dimension.method_29177().method_42093(TRANSLATION_PREFIX), value);
	}

	public static String getTagTranslationKey(class_6862<?> tagKey) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("tag.");

		class_2960 registryIdentifier = tagKey.comp_326().method_29177();
		class_2960 tagIdentifier = tagKey.comp_327();

		stringBuilder.append(registryIdentifier.method_43903().replace("/", "."))
				.append(".")
				.append(tagIdentifier.method_12836())
				.append(".")
				.append(tagIdentifier.method_12832().replace("/", "."));

		return stringBuilder.toString();
	}
}
