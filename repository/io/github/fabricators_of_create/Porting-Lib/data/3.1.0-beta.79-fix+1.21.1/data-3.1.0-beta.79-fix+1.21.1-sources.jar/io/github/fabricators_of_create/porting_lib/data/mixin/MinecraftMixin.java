package io.github.fabricators_of_create.porting_lib.data.mixin;

import io.github.fabricators_of_create.porting_lib.data.extensions.MinecraftExtension;
import net.minecraft.class_310;
import net.minecraft.class_542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftMixin implements MinecraftExtension {
	private class_542 port_lib$gameConfig;

	@Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/Util;getNanos()J"))
	private void port_lib$saveGameConfig(class_542 gameConfig, CallbackInfo ci) {
		this.port_lib$gameConfig = gameConfig;
	}

	@Override
	public class_542 port_lib$getGameConfig() {
		return this.port_lib$gameConfig;
	}
}
