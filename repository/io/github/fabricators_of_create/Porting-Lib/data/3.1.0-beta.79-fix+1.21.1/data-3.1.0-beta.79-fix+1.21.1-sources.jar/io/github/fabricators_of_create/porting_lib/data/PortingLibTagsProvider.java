package io.github.fabricators_of_create.porting_lib.data;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;

import net.fabricmc.fabric.impl.datagen.FabricTagBuilder;
import net.fabricmc.fabric.impl.datagen.ForcedTagEntry;
import net.minecraft.class_156;
import net.minecraft.class_2378;
import net.minecraft.class_2405;
import net.minecraft.class_2474;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3481;
import net.minecraft.class_3483;
import net.minecraft.class_3486;
import net.minecraft.class_3489;
import net.minecraft.class_3495;
import net.minecraft.class_3497;
import net.minecraft.class_5321;
import net.minecraft.class_5698;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7475;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public abstract class PortingLibTagsProvider<T> extends class_2474<T> {
	protected final String modId;
	@Nullable
	protected final ExistingFileHelper existingFileHelper;
	private final ExistingFileHelper.IResourceType resourceType;
	private final ExistingFileHelper.IResourceType elementResourceType; // FORGE: Resource type for validating required references to datapack registry elements.

	protected PortingLibTagsProvider(FabricDataOutput output, class_5321<? extends class_2378<T>> resourceKey, CompletableFuture<class_7225.class_7874> provider, String modId, @Nullable ExistingFileHelper existingFileHelper) {
		this(output, resourceKey, provider, CompletableFuture.completedFuture(class_2474.class_8211.empty()), modId, existingFileHelper);
	}

	protected PortingLibTagsProvider(FabricDataOutput output, class_5321<? extends class_2378<T>> resourceKey, CompletableFuture<class_7225.class_7874> provider, CompletableFuture<class_2474.class_8211<T>> p_275565_, String modId, @Nullable ExistingFileHelper existingFileHelper) {
		super(output, resourceKey, provider);
		this.modId = modId;
		this.existingFileHelper = existingFileHelper;
		this.resourceType = new ExistingFileHelper.ResourceType(class_3264.field_14190, ".json", class_7924.method_60916(resourceKey));
		this.elementResourceType = new ExistingFileHelper.ResourceType(class_3264.field_14190, ".json", PortingLibDataHack.prefixNamespace(resourceKey.method_29177()));
	}

	// PL: Allow customizing the path for a given tag or returning null
	@org.jetbrains.annotations.Nullable
	protected Path getPath(class_2960 id) {
		return this.field_39380.method_44107(id);
	}

	@Override
	public String method_10321() {
		return "Tags for " + this.field_40957.method_29177() + " mod id " + this.modId;
	}

	protected class_5321<T> reverseLookup(T element) {
		class_2378 registry = class_7923.field_41167.method_29107((class_5321) field_40957);

		if (registry != null) {
			Optional<class_6880<T>> key = registry.method_29113(element);

			if (key.isPresent()) {
				return (class_5321<T>) key.get();
			}
		}

		throw new UnsupportedOperationException("Adding objects is not supported by " + getClass());
	}

	@Override
	protected PortingLibTagAppender method_10512(class_6862<T> tag) {
		return new PortingLibTagAppender(super.method_10512(tag));
	}

	@Override
	protected class_3495 method_27169(class_6862<T> tag) {
		return this.field_11481.computeIfAbsent(tag.comp_327(), (resourceLocation) -> new PortingLibTagBuilder());
	}

	@Override
	public CompletableFuture<?> method_10319(class_7403 output) {
		record CombinedData<T>(class_7225.class_7874 contents, class_2474.class_8211<T> parent) {
		}

		return this.method_49651()
				.thenApply(provider -> {
					this.field_43108.complete(null);
					return provider;
				})
				.thenCombineAsync(
						this.field_43093, CombinedData::new, class_156.method_18349()
				)
				.thenCompose(
						data -> {
							class_7225.class_7226<T> lookup = data.contents.method_46762(this.field_40957);
							Predicate<class_2960> hasRegistry = location -> lookup.method_46746(class_5321.method_29179(this.field_40957, location)).isPresent();
							Predicate<class_2960> hasTag = location -> this.field_11481.containsKey(location)
									|| data.parent.contains(class_6862.method_40092(this.field_40957, location));
							return CompletableFuture.allOf(
									this.field_11481
											.entrySet()
											.stream()
											.map(
													tagEntry -> {
														class_2960 tagId = tagEntry.getKey();
														class_3495 builder = tagEntry.getValue();
														List<class_3497> entries = builder.method_26782();
														List<class_3497> missingTags = entries.stream()
																.filter((entry) -> !entry.method_32832(hasRegistry, hasTag))
																.filter(this::missing)
																.toList();
														if (!missingTags.isEmpty()) {
															throw new IllegalArgumentException(
																	String.format(
																			Locale.ROOT,
																			"Couldn't define tag %s as it is missing following references: %s",
																			tagId,
																			missingTags.stream().map(Objects::toString).collect(Collectors.joining(","))
																	)
															);
														} else {
															Path path = getPath(tagId);
															if (path == null)
																return CompletableFuture.completedFuture(null); // PL: Allow running this data provider without writing it. Recipe provider needs valid tags.
															var removed = ((PortingLibTagBuilder) builder).getRemoveEntries().toList();
															return class_2405.method_53496(output, data.contents, class_7475.field_39269, new class_7475(entries, ((PortingLibTagBuilder) builder).isReplace()/*, removed*/), path); // TODO: Remove not support for right now
														}
													}
											)
											.toArray(CompletableFuture[]::new)
							);
						}
				);
	}

	private boolean missing(class_3497 reference) {
		// Optional tags should not be validated

		if (reference.field_39268) {
			return existingFileHelper == null || !existingFileHelper.exists(reference.field_15584, reference.field_39267 ? resourceType : elementResourceType);
		}
		return false;
	}

	public static class PortingLibTagBuilder extends class_3495 {
		/**
		 * Remove entries are used for datagen.
		 */
		private final List<class_3497> removeEntries = new ArrayList<>();
		private boolean replace = false;

		public Stream<class_3497> getRemoveEntries() {
			return this.removeEntries.stream();
		}

		/**
		 * Add an entry to be removed from this tag in datagen.
		 */
		public class_3495 remove(final class_3497 entry) {
			this.removeEntries.add(entry);
			return this;
		}

		public class_3495 replace(boolean value) {
			this.replace = value;
			return this;
		}

		/**
		 * Shorthand version of replace(true)
		 */
		public class_3495 replace() {
			return replace(true);
		}

		/**
		 * Is this tag set to replace or not?
		 */
		public boolean isReplace() {
			return this.replace;
		}
	}

	public class PortingLibTagAppender extends class_5124<T> {
		protected final class_2474.class_5124<T> parent;

		protected PortingLibTagAppender(class_5124<T> parent) {
			super(parent.field_23960);
			this.parent = parent;
		}

		/**
		 * Set the value of the `replace` flag in a Tag.
		 *
		 * <p>When set to true the tag will replace any existing tag entries.
		 *
		 * @return the {@link PortingLibTagAppender} instance
		 */
		public PortingLibTagAppender setReplace(boolean replace) {
			((PortingLibTagBuilder) field_23960).replace(replace);
			return this;
		}

		/**
		 * Add an element to the tag.
		 *
		 * @return the {@link PortingLibTagAppender} instance
		 */
		public PortingLibTagAppender add(T element) {
			method_46835(reverseLookup(element));
			return this;
		}

		/**
		 * Add multiple elements to the tag.
		 *
		 * @return the {@link PortingLibTagAppender} instance
		 */
		@SafeVarargs
		public final PortingLibTagAppender add(T... element) {
			Stream.of(element).map(PortingLibTagsProvider.this::reverseLookup).forEach(this::method_46835);
			return this;
		}

		/**
		 * Add an element to the tag.
		 *
		 * @return the {@link PortingLibTagAppender} instance
		 * @see #addTag(class_2960)
		 */
		@Override
		public PortingLibTagAppender method_46835(class_5321<T> registryKey) {
			parent.method_46835(registryKey);
			return this;
		}

		/**
		 * Add a single element to the tag.
		 *
		 * @return the {@link PortingLibTagAppender} instance
		 */
		public PortingLibTagAppender addTag(class_2960 id) {
			field_23960.addTag(id);
			return this;
		}

		/**
		 * Add an optional {@link class_2960} to the tag.
		 *
		 * @return the {@link PortingLibTagAppender} instance
		 */
		@Override
		public PortingLibTagAppender method_35922(class_2960 id) {
			parent.method_35922(id);
			return this;
		}

		/**
		 * Add an optional {@link class_5321} to the tag.
		 *
		 * @return the {@link PortingLibTagAppender} instance
		 */
		public PortingLibTagAppender addOptional(class_5321<? extends T> registryKey) {
			return method_35922(registryKey.method_29177());
		}

		/**
		 * Add another tag to this tag.
		 *
		 * <p><b>Note:</b> any vanilla tags can be added to the builder,
		 * but other tags can only be added if it has a builder registered in the same provider.
		 *
		 * <p>Use {@link #forceAddTag(class_6862)} to force add any tag.
		 *
		 * @return the {@link PortingLibTagAppender} instance
		 * @see class_3481
		 * @see class_3483
		 * @see class_3486
		 * @see class_5698
		 * @see class_3489
		 */
		@Override
		public PortingLibTagAppender method_26792(class_6862<T> tag) {
			field_23960.addTag(tag.comp_327());
			return this;
		}

		/**
		 * Add another optional tag to this tag.
		 *
		 * @return the {@link PortingLibTagAppender} instance
		 */
		@Override
		public PortingLibTagAppender method_35923(class_2960 id) {
			parent.method_35923(id);
			return this;
		}

		/**
		 * Add another optional tag to this tag.
		 *
		 * @return the {@link PortingLibTagAppender} instance
		 */
		public PortingLibTagAppender addOptionalTag(class_6862<T> tag) {
			return method_35923(tag.comp_327());
		}

		/**
		 * Add another tag to this tag, ignoring any warning.
		 *
		 * <p><b>Note:</b> only use this method if you sure that the tag will be always available at runtime.
		 * If not, use {@link #method_35923(class_2960)} instead.
		 *
		 * @return the {@link PortingLibTagAppender} instance
		 */
		public PortingLibTagAppender forceAddTag(class_6862<T> tag) {
			field_23960.add(new ForcedTagEntry(class_3497.method_43937(tag.comp_327())));
			return this;
		}

		/**
		 * Add multiple elements to this tag.
		 *
		 * @return the {@link PortingLibTagAppender} instance
		 */
		public PortingLibTagAppender add(class_2960... ids) {
			for (class_2960 id : ids) {
				add(id);
			}

			return this;
		}

		/**
		 * Add multiple elements to this tag.
		 *
		 * @return the {@link PortingLibTagAppender} instance
		 */
		@SafeVarargs
		@Override
		public final PortingLibTagAppender method_40565(class_5321<T>... registryKeys) {
			for (class_5321<T> registryKey : registryKeys) {
				method_46835(registryKey);
			}

			return this;
		}
	}
}
