package io.github.fabricators_of_create.porting_lib.data;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Maps;
import com.google.gson.JsonElement;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import net.minecraft.class_2403;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_6903;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ConditionalOps;
import io.github.fabricators_of_create.porting_lib.resources.conditions.ICondition;
import io.github.fabricators_of_create.porting_lib.resources.conditions.WithConditions;
import org.slf4j.Logger;

/**
 * <p>Dataprovider for using a Codec to generate jsons.
 * Path names for jsons are derived from the given registry folder and each entry's namespaced id, in the format:</p>
 *
 * <pre>
 * {@code <assets/data>/entryid/registryfolder/entrypath.json }
 * </pre>
 *
 * @param <T> the type of thing being generated.
 */
public abstract class JsonCodecProvider<T> implements class_2405 {
	private static final Logger LOGGER = LogUtils.getLogger();
	protected final ExistingFileHelper.ResourceType resourceType;
	protected final class_7784.class_7489 pathProvider;
	protected final ExistingFileHelper existingFileHelper;
	protected final CompletableFuture<class_7225.class_7874> lookupProvider;
	protected final String modid;
	protected final String directory;
	protected final Codec<T> codec;
	protected final Map<class_2960, WithConditions<T>> conditions = Maps.newHashMap();

	/**
	 * @param output    {@linkplain class_7784} provided by the {@link class_2403}.
	 * @param packType  PackType specifying whether to generate entries in assets or data.
	 * @param directory String representing the directory to generate jsons in, e.g. "dimension" or "cheesemod/cheese".
	 * @param codec     Codec to encode values to jsons with using the provided DynamicOps.
	 */
	public JsonCodecProvider(class_7784 output,
							 class_7784.class_7490 target,
							 String directory,
							 class_3264 packType,
							 Codec<T> codec,
							 CompletableFuture<class_7225.class_7874> lookupProvider,
							 String modId,
							 ExistingFileHelper existingFileHelper) {
		// Track generated data so other dataproviders can validate if needed.
		this.resourceType = new ExistingFileHelper.ResourceType(packType, ".json", directory);
		this.pathProvider = output.method_45973(target, directory);
		this.existingFileHelper = existingFileHelper;
		this.modid = modId;
		this.directory = directory;
		this.codec = codec;
		this.lookupProvider = lookupProvider;
	}

	@Override
	public CompletableFuture<?> method_10319(final class_7403 cache) {
		ImmutableList.Builder<CompletableFuture<?>> futuresBuilder = new ImmutableList.Builder<>();

		gather();

		return lookupProvider.thenCompose(provider -> {
			final DynamicOps<JsonElement> dynamicOps = new ConditionalOps<>(class_6903.method_46632(JsonOps.INSTANCE, provider), ICondition.IContext.EMPTY);

			this.conditions.forEach((id, withConditions) -> {
				final Path path = this.pathProvider.json(id);

				futuresBuilder.add(CompletableFuture.supplyAsync(() -> {
					final Codec<Optional<WithConditions<T>>> withConditionsCodec = ConditionalOps.createConditionalCodecWithConditions(this.codec);
					return withConditionsCodec.encodeStart(dynamicOps, Optional.of(withConditions)).getOrThrow(msg -> new RuntimeException("Failed to encode %s: %s".formatted(path, msg)));
				}).thenComposeAsync(encoded -> DataProvider.saveStable(cache, encoded, path)));
			});

			return CompletableFuture.allOf(futuresBuilder.build().toArray(CompletableFuture[]::new));
		});
	}

	protected abstract void gather();

	@Override
	public String method_10321() {
		return String.format("%s generator for %s", this.directory, this.modid);
	}

	public void unconditional(class_2960 id, T value) {
		process(id, new WithConditions<>(List.of(), value));
	}

	public void conditionally(class_2960 id, Consumer<WithConditions.Builder<T>> configurator) {
		final WithConditions.Builder<T> builder = new WithConditions.Builder<>();
		configurator.accept(builder);

		final WithConditions<T> withConditions = builder.build();
		process(id, withConditions);
	}

	private void process(class_2960 id, WithConditions<T> withConditions) {
		this.existingFileHelper.trackGenerated(id, this.resourceType);

		this.conditions.put(id, withConditions);
	}
}
