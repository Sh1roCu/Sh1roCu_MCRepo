package io.github.fabricators_of_create.porting_lib.data;

import com.google.gson.JsonObject;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3414;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7923;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Data provider for the {@code sounds.json} file, which identifies sound definitions
 * for the various sound events in Minecraft.
 */
public abstract class SoundDefinitionsProvider implements class_2405 {
	private static final Logger LOGGER = LogManager.getLogger();
	private final class_7784 output;
	private final String modId;
	private final ExistingFileHelper helper;

	private final Map<String, SoundDefinition> sounds = new LinkedHashMap<>();

	/**
	 * Creates a new instance of this data provider.
	 *
	 * @param output The {@linkplain class_7784} instance provided by the data generator.
	 * @param modId The mod ID of the current mod.
	 * @param helper The existing file helper provided by the event you are initializing this provider in.
	 */
	protected SoundDefinitionsProvider(final class_7784 output, final String modId, final ExistingFileHelper helper) {
		this.output = output;
		this.modId = modId;
		this.helper = helper;
	}

	/**
	 * Creates a new instance of this data provider.
	 *
	 * @param output The {@linkplain FabricDataOutput} instance provided by the data generator.
	 * @param helper The existing file helper provided by the event you are initializing this provider in.
	 */
	protected SoundDefinitionsProvider(final FabricDataOutput output, final ExistingFileHelper helper) {
		this(output, output.getModId(), helper);
	}

	/**
	 * Registers the sound definitions that should be generated via one of the {@code add} methods.
	 */
	public abstract void registerSounds();

	@Override
	public CompletableFuture<?> method_10319(class_7403 cache) {
		this.sounds.clear();
		this.registerSounds();
		this.validate();
		if (!this.sounds.isEmpty())
		{
			return this.save(cache, this.output.method_45972(class_7784.class_7490.field_39368).resolve(this.modId).resolve("sounds.json"));
		}

		return CompletableFuture.allOf();
	}

	@Override
	public String method_10321() {
		return "Sound Definitions";
	}

	// Quick helpers
	/**
	 * Creates a new {@link SoundDefinition}, which will host a set of
	 * {@link SoundDefinition.Sound}s and the necessary parameters.
	 */
	protected static SoundDefinition definition() {
		return SoundDefinition.definition();
	}

	/**
	 * Creates a new sound with the given name and type.
	 *
	 * @param name The name of the sound to create.
	 * @param type The type of sound to create.
	 */
	protected static SoundDefinition.Sound sound(final class_2960 name, final SoundDefinition.SoundType type) {
		return SoundDefinition.Sound.sound(name, type);
	}

	/**
	 * Creates a new sound with the given name and {@link SoundDefinition.SoundType#SOUND} as
	 * sound type.
	 *
	 * @param name The name of the sound to create.
	 */
	protected static SoundDefinition.Sound sound(final class_2960 name) {
		return sound(name, SoundDefinition.SoundType.SOUND);
	}

	/**
	 * Creates a new sound with the given name and type.
	 *
	 * @param name The name of the sound to create.
	 * @param type The type of sound to create.
	 */
	protected static SoundDefinition.Sound sound(final String name, final SoundDefinition.SoundType type) {
		return sound(class_2960.method_60654(name), type);
	}

	/**
	 * Creates a new sound with the given name and {@link SoundDefinition.SoundType#SOUND} as
	 * sound type.
	 *
	 * @param name The name of the sound to create.
	 */
	protected static SoundDefinition.Sound sound(final String name) {
		return sound(class_2960.method_60654(name));
	}

	// Addition methods
	/**
	 * Adds the entry name associated with the supplied {@link class_3414} with the given
	 * {@link SoundDefinition} to the list.
	 *
	 * <p>This method should be preferred when dealing with a {@code RegistryObject} or
	 * {@code RegistryDelegate}.</p>
	 *
	 * @param soundEvent A {@code Supplier} for the given {@link class_3414}.
	 * @param definition A {@link SoundDefinition} that defines the given sound.
	 */
	protected void add(final Supplier<class_3414> soundEvent, final SoundDefinition definition) {
		this.add(soundEvent.get(), definition);
	}

	/**
	 * Adds the entry name associated with the given {@link class_3414} with the
	 * {@link SoundDefinition} to the list.
	 *
	 * <p>This method should be preferred when a {@code SoundEvent} is already
	 * available in the method context. If you already have a {@code Supplier} for
	 * it, refer to {@link #add(Supplier, SoundDefinition)}.</p>
	 *
	 * @param soundEvent A {@link class_3414}.
	 * @param definition The {@link SoundDefinition} that defines the given event.
	 */
	protected void add(final class_3414 soundEvent, final SoundDefinition definition) {
		this.add(soundEvent.method_14833(), definition);
	}

	/**
	 * Adds the {@link class_3414} referenced by the given {@link class_2960} with the
	 * {@link SoundDefinition} to the list.
	 *
	 * @param soundEvent The {@link class_2960} that identifies the event.
	 * @param definition The {@link SoundDefinition} that defines the given event.
	 */
	protected void add(final class_2960 soundEvent, final SoundDefinition definition) {
		this.addSounds(soundEvent.method_12832(), definition);
	}

	/**
	 * Adds the {@link class_3414} with the specified name along with its {@link SoundDefinition}
	 * to the list.
	 *
	 * <p>The given sound event must NOT contain the namespace the name is a part of, since
	 * the sound definition specification doesn't allow sounds to be defined outside the
	 * namespace they're in. For this reason, any namespace will automatically be stripped
	 * from the name.</p>
	 *
	 * @param soundEvent The name of the {@link class_3414}.
	 * @param definition The {@link SoundDefinition} that defines the given event.
	 */
	protected void add(final String soundEvent, final SoundDefinition definition) {
		this.add(class_2960.method_60654(soundEvent), definition);
	}

	private void addSounds(final String soundEvent, final SoundDefinition definition) {
		if (this.sounds.put(soundEvent, definition) != null) {
			throw new IllegalStateException("Sound event '" + this.modId + ":" + soundEvent + "' already exists");
		}
	}

	// Internal handling stuff
	private void validate() {
		final List<String> notValid = this.sounds.entrySet().stream()
				.filter(it -> !this.validate(it.getKey(), it.getValue()))
				.map(Map.Entry::getKey)
				.map(it -> this.modId + ":" + it)
				.toList();
		if (!notValid.isEmpty()) {
			throw new IllegalStateException("Found invalid sound events: " + notValid);
		}
	}

	private boolean validate(final String name, final SoundDefinition def) {
		return def.soundList().stream().allMatch(it -> this.validate(name,it));
	}

	private boolean validate(final String name, final SoundDefinition.Sound sound) {
		return switch (sound.type()) {
			case SOUND -> this.validateSound(name, sound.name());
			case EVENT -> this.validateEvent(name, sound.name());
		};
		// Differently from all the other errors, this is not a 'missing sound' but rather something completely different
		// that has broken the invariants of this sound definition's provider. In fact, a sound may only be either of
		// SOUND or EVENT type. Any other values is somebody messing with the internals, reflectively adding something
		// to an enum or passing `null` to a parameter annotated with `@NotNull`.
	}

	private boolean validateSound(final String soundName, final class_2960 name) {
		final boolean valid = this.helper.exists(name, class_3264.field_14188, ".ogg", "sounds");
		if (!valid) {
			final String path = name.method_12836() + ":sounds/" + name.method_12832() + ".ogg";
			LOGGER.warn("Unable to find corresponding OGG file '{}' for sound event '{}'", path, soundName);
		}
		return valid;
	}

	private boolean validateEvent(final String soundName, final class_2960 name) {
		final boolean valid = this.sounds.containsKey(soundName) || class_7923.field_41172.method_10250(name);
		if (!valid) {
			LOGGER.warn("Unable to find event '{}' referenced from '{}'", name, soundName);
		}
		return valid;
	}

	private CompletableFuture<?> save(final class_7403 cache, final Path targetFile) {
		return class_2405.method_10320(cache, this.mapToJson(this.sounds), targetFile);
	}

	private JsonObject mapToJson(final Map<String, SoundDefinition> map) {
		final JsonObject obj = new JsonObject();
		// namespaces are ignored when serializing
		map.forEach((k, v) -> obj.add(k, v.serialize()));
		return obj;
	}
}
