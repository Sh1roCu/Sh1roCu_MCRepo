package io.github.fabricators_of_create.porting_lib.data.mixin;

import net.minecraft.class_2446;
import net.minecraft.class_7784;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2446.class)
public interface RecipeProviderAccessor {
	@Accessor
	class_7784.class_7489 getRecipePathProvider();

	@Accessor
	class_7784.class_7489 getAdvancementPathProvider();
}
