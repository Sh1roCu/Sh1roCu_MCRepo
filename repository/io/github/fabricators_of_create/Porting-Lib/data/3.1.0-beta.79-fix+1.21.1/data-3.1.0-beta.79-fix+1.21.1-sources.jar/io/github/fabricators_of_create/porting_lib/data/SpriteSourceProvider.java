package io.github.fabricators_of_create.porting_lib.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7948;
import net.minecraft.class_7952;

/**
 * <p>Data provider for atlas configuration files.<br>
 * An atlas configuration is bound to a specific texture atlas such as the {@code minecraft:blocks} atlas and
 * allows adding additional textures to the atlas by adding {@link class_7948}s to the configuration.</p>
 * <p>See {@link class_7952} for the available sources and the constants in this class for the
 * atlases used in vanilla Minecraft</p>
 */
public abstract class SpriteSourceProvider extends JsonCodecProvider<List<class_7948>> {
	protected static final class_2960 BLOCKS_ATLAS = class_2960.method_60656("blocks");
	protected static final class_2960 BANNER_PATTERNS_ATLAS = class_2960.method_60656("banner_patterns");
	protected static final class_2960 BEDS_ATLAS = class_2960.method_60656("beds");
	protected static final class_2960 CHESTS_ATLAS = class_2960.method_60656("chests");
	protected static final class_2960 SHIELD_PATTERNS_ATLAS = class_2960.method_60656("shield_patterns");
	protected static final class_2960 SHULKER_BOXES_ATLAS = class_2960.method_60656("shulker_boxes");
	protected static final class_2960 SIGNS_ATLAS = class_2960.method_60656("signs");
	protected static final class_2960 MOB_EFFECTS_ATLAS = class_2960.method_60656("mob_effects");
	protected static final class_2960 PAINTINGS_ATLAS = class_2960.method_60656("paintings");
	protected static final class_2960 PARTICLES_ATLAS = class_2960.method_60656("particles");

	private final Map<class_2960, SourceList> atlases = new HashMap<>();

	public SpriteSourceProvider(class_7784 output, CompletableFuture<class_7225.class_7874> lookupProvider, String modId, ExistingFileHelper existingFileHelper) {
		super(output, class_7784.class_7490.field_39368, "atlases", class_3264.field_14188, class_7952.field_41397, lookupProvider, modId, existingFileHelper);
	}

	/**
	 * Get or create a {@link SourceList} for the given atlas
	 *
	 * @param id The texture atlas the sources should be added to, see constants at the top for the format
	 *           and the vanilla atlases
	 * @return an existing {@code SourceList} for the given atlas or a new one if not present yet
	 */
	protected final SourceList atlas(class_2960 id) {
		return atlases.computeIfAbsent(id, i -> {
			final SourceList newAtlas = new SourceList(new ArrayList<>());
			unconditional(i, newAtlas.sources());
			return newAtlas;
		});
	}

	protected record SourceList(List<class_7948> sources) {
		/**
		 * Add the given {@link class_7948} to this atlas configuration
		 *
		 * @param source The {@code SpriteSource} to be added
		 */
		public SourceList addSource(class_7948 source) {
			sources.add(source);
			return this;
		}
	}
}
