package io.github.fabricators_of_create.porting_lib.data;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.function.BiConsumer;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_39;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7699;
import net.minecraft.class_7788;
import net.minecraft.class_7923;
import com.google.common.collect.Sets;

public abstract class ModdedBlockLootSubProvider extends class_7788 {
	protected ModdedBlockLootSubProvider(Set<class_1792> set, class_7699 featureFlagSet, class_7225.class_7874 provider) {
		super(set, featureFlagSet, provider);
	}

	@Override
	public void method_10399(BiConsumer<class_5321<class_52>, class_52.class_53> biConsumer) {
		this.method_10379();
		Set<class_5321<class_52>> set = new HashSet();

		for(class_2248 block : getKnownBlocks()) {
			if (block.method_45382(this.field_40609)) {
				class_5321<class_52> lootTable = block.method_26162();
				if (lootTable != class_39.field_844 && set.add(lootTable)) {
					class_52.class_53 builder = this.field_40610.remove(lootTable);
					if (builder == null) {
						throw new IllegalStateException(String.format(Locale.ROOT, "Missing loottable '%s' for '%s'", lootTable.method_29177(), class_7923.field_41175.method_10221(block)));
					}

					biConsumer.accept(lootTable, builder);
				}
			}
		}

		if (!this.field_40610.isEmpty()) {
			throw new IllegalStateException("Created block loot tables for non-blocks: " + String.valueOf(this.field_40610.keySet()));
		}
	}

	protected Iterable<class_2248> getKnownBlocks() {
		return class_7923.field_41175;
	}
}
