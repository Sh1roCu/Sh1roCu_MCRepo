package io.github.fabricators_of_create.porting_lib.level.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.level.events.ChunkDataEvent;
import io.github.fabricators_of_create.porting_lib.level.events.ChunkTicketLevelUpdatedEvent;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2791;
import net.minecraft.class_2818;
import net.minecraft.class_3193;
import net.minecraft.class_3218;
import net.minecraft.class_3898;
import net.minecraft.class_8563;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3898.class)
public class ChunkMapMixin {
	@Shadow
	@Final
	private class_3218 level;

	@Inject(method = "updateChunkScheduling", at = @At(value = "RETURN"))
	private void callChunkTicketLevelUpdated(long chunkPos, int newLevel, class_3193 holder, int oldLevel, CallbackInfoReturnable<class_3193> cir) {
		if ((class_8563.method_51833(oldLevel) || class_8563.method_51833(newLevel)) && oldLevel != newLevel) {
			(new ChunkTicketLevelUpdatedEvent(level, chunkPos, oldLevel, newLevel, holder)).sendEvent();
		}
	}

	@Inject(method = "save", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ChunkMap;write(Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/nbt/CompoundTag;)Ljava/util/concurrent/CompletableFuture;"))
	private void onChunkDataSave(class_2791 chunk, CallbackInfoReturnable<Boolean> cir, @Local class_2487 tag) {
		class_1937 level;
		if (chunk instanceof class_2818 levelChunk)
			level = levelChunk.method_12200() != null ? levelChunk.method_12200() : this.level;
		else
			level = this.level;
		new ChunkDataEvent.Save(chunk, level, tag).sendEvent();
	}
}
