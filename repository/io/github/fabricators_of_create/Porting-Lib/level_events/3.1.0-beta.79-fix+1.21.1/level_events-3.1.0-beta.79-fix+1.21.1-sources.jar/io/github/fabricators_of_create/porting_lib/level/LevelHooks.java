package io.github.fabricators_of_create.porting_lib.level;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomExpBlock;
import io.github.fabricators_of_create.porting_lib.level.events.BlockEvent;
import io.github.fabricators_of_create.porting_lib.level.events.LevelEvent;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1311;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2626;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_5268;
import net.minecraft.class_5483;
import net.minecraft.class_5552;
import net.minecraft.class_6012;

public class LevelHooks {
	public static boolean onCreateWorldSpawn(class_1937 level, class_5268 settings) {
		return new LevelEvent.CreateSpawnPosition(level, settings).post();
	}

	private static final class_6012<class_5483.class_1964> NO_SPAWNS = class_6012.method_34990();

	public static class_6012<class_5483.class_1964> getPotentialSpawns(class_1936 level, class_1311 category, class_2338 pos, class_6012<class_5483.class_1964> oldList) {
		LevelEvent.PotentialSpawns event = new LevelEvent.PotentialSpawns(level, category, pos, oldList);
		if (event.post())
			return NO_SPAWNS;
		else if (event.getSpawnerDataList() == oldList.method_34994())
			return oldList;
		return class_6012.method_34988(event.getSpawnerDataList());
	}

	/**
	 * Fires {@link BlockEvent.BreakEvent}, pre-emptively canceling the event based on the conditions that will cause the block to not be broken anyway.
	 * <p>
	 * Note that undoing the pre-cancel will not permit breaking the block, since the vanilla conditions will always be checked.
	 *
	 * @param level    The level
	 * @param gameType The game type of the breaking player
	 * @param player   The breaking player
	 * @param pos      The position of the block being broken
	 * @param state    The state of the block being broken
	 * @return The event
	 */
	public static BlockEvent.BreakEvent fireBlockBreak(class_1937 level, class_1934 gameType, class_3222 player, class_2338 pos, class_2680 state) {
		return fireBlockBreak(level, gameType, player, pos, state, args -> {
			return ((class_1792) args[0]).method_7885((class_2680) args[1], (class_1937) args[2], (class_2338) args[3], (class_1657) args[4]);
		});
	}

	public static BlockEvent.BreakEvent fireBlockBreak(class_1937 level, class_1934 gameType, class_3222 player, class_2338 pos, class_2680 state, Operation<Boolean> original) {
		boolean preCancelEvent = false;

		class_1799 itemstack = player.method_6047();
		if (!itemstack.method_7960() && !original.call(itemstack.method_7909(), state, level, pos, player)) {
			preCancelEvent = true;
		}

		if (player.method_21701(level, pos, gameType)) {
			preCancelEvent = true;
		}

		if (state.method_26204() instanceof class_5552 && !player.method_7338()) {
			preCancelEvent = true;
		}

		// Post the block break event
		BlockEvent.BreakEvent event = new BlockEvent.BreakEvent(level, pos, state, player);
		event.setCanceled(preCancelEvent);
		event.sendEvent();

		// If the event is canceled, let the client know the block still exists
		if (event.isCanceled()) {
			player.field_13987.method_14364(new class_2626(pos, state));
		}

		return event;
	}

	public static boolean onMultiBlockPlace(@Nullable class_1297 entity, List<BlockSnapshot> blockSnapshots, class_2350 direction) {
		BlockSnapshot snap = blockSnapshots.get(0);
		class_2680 placedAgainst = snap.getLevel().method_8320(snap.getPos().method_10093(direction.method_10153()));
		BlockEvent.EntityMultiPlaceEvent event = new BlockEvent.EntityMultiPlaceEvent(blockSnapshots, placedAgainst, entity);
		return event.post();
	}

	public static boolean onBlockPlace(@Nullable class_1297 entity, BlockSnapshot blockSnapshot, class_2350 direction) {
		class_2680 placedAgainst = blockSnapshot.getLevel().method_8320(blockSnapshot.getPos().method_10093(direction.method_10153()));
		BlockEvent.EntityPlaceEvent event = new BlockEvent.EntityPlaceEvent(blockSnapshot, placedAgainst, entity);
		return event.post();
	}

	public static BlockEvent.NeighborNotifyEvent onNeighborNotify(class_1937 level, class_2338 pos, class_2680 state, EnumSet<class_2350> notifiedSides, boolean forceRedstoneUpdate) {
		BlockEvent.NeighborNotifyEvent event = new BlockEvent.NeighborNotifyEvent(level, pos, state, notifiedSides, forceRedstoneUpdate);
		event.sendEvent();
		return event;
	}

	public static class_2680 fireFluidPlaceBlockEvent(class_1936 level, class_2338 pos, class_2338 liquidPos, class_2680 state) {
		BlockEvent.FluidPlaceBlockEvent event = new BlockEvent.FluidPlaceBlockEvent(level, pos, liquidPos, state);
		event.sendEvent();
		return event.getNewState();
	}

	public static int getExpDrop(class_2680 state, class_1936 level, class_2338 pos, @Nullable class_2586 blockEntity, @Nullable class_1297 breaker, class_1799 tool) {
		class_2248 block = state.method_26204();
		if (block instanceof CustomExpBlock customExpBlock)
			return customExpBlock.getExpDrop(state, level, pos, blockEntity, breaker, tool);
		return 0; // Ignore Vanilla exp because vanilla blocks already handle that
	}
}
