package io.github.fabricators_of_create.porting_lib.level.events;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1311;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2794;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_3536;
import net.minecraft.class_434;
import net.minecraft.class_437;
import net.minecraft.class_5138;
import net.minecraft.class_5268;
import net.minecraft.class_5483;
import net.minecraft.class_6012;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

/**
 * This event is fired whenever an event involving a {@link class_1936} occurs.
 */
public abstract class LevelEvent extends BaseEvent {
	private final class_1936 level;

	public LevelEvent(class_1936 level) {
		this.level = level;
	}

	/**
	 * {@return the level this event is affecting}
	 */
	public class_1936 getLevel() {
		return level;
	}

	/**
	 * This event is fired whenever a level loads.
	 * This event is fired whenever a level loads in ClientLevel's constructor and
	 * {@literal MinecraftServer#createLevels(ChunkProgressListener)}.
	 * <p>
	 * This event is not {@linkplain CancellableEvent cancellable}.
	 * <p>
	 * This event is fired on both logical sides.
	 **/
	public static class Load extends LevelEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks)
				callback.onLoad(event);
		});

		public Load(class_1936 level) {
			super(level);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onLoad(this);
		}

		public interface Callback {
			void onLoad(Load event);
		}
	}

	/**
	 * This event is fired whenever a level unloads.
	 * This event is fired whenever a level unloads in
	 * {@link class_310#method_1481(class_638, class_434.class_9678)},
	 * {@link MinecraftServer#method_3782()},
	 * {@link class_310#method_18096(class_437, boolean)}.
	 * <p>
	 * This event is not {@linkplain CancellableEvent cancellable}.
	 * <p>
	 * This event is fired on both logical sides.
	 **/
	public static class Unload extends LevelEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks)
				callback.onUnload(event);
		});

		public Unload(class_1936 level) {
			super(level);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onUnload(this);
		}

		public interface Callback {
			void onUnload(Unload event);
		}
	}

	/**
	 * This event fires whenever a level is saved.
	 * This event is fired when a level is saved in
	 * {@link class_3218#method_14176(class_3536, boolean, boolean)}.
	 * <p>
	 * This event is not {@linkplain CancellableEvent cancellable}.
	 * <p>
	 * This event is fired only on the {@linkplain EnvType#SERVER logical server}.
	 **/
	public static class Save extends LevelEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks)
				callback.onSave(event);
		});

		public Save(class_1936 level) {
			super(level);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onSave(this);
		}

		public interface Callback {
			void onSave(Save event);
		}
	}

	/**
	 * This event fires whenever a {@link class_3218} is initialized for the first time
	 * and a spawn position needs to be chosen.
	 * <p>
	 * This event is {@linkplain CancellableEvent cancellable}.
	 * If the event is canceled, the vanilla logic to choose a spawn position will be skipped.
	 * <p>
	 * This event is fired only on the {@linkplain EnvType#SERVER logical server}.
	 *
	 * @see class_5268#method_222()
	 */
	public static class CreateSpawnPosition extends LevelEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks)
				callback.onCreateSpawnPosition(event);
		});

		private final class_5268 settings;

		public CreateSpawnPosition(class_1936 level, class_5268 settings) {
			super(level);
			this.settings = settings;
		}

		public class_5268 getSettings() {
			return settings;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onCreateSpawnPosition(this);
		}

		public interface Callback {
			void onCreateSpawnPosition(CreateSpawnPosition event);
		}
	}

	/**
	 * Fired when building a list of all possible entities that can spawn at the specified location.
	 *
	 * <p>If an entry is added to the list, it needs to be a globally unique instance.</p>
	 *
	 * The event is called in {@link net.minecraft.class_1948#method_29950(class_3218,
	 * class_5138, class_2794, class_1311, class_2338, class_6880)}.</p>
	 *
	 * <p>This event is {@linkplain CancellableEvent cancellable},.
	 * Canceling the event will result in an empty list, meaning no entity will be spawned.</p>
	 */
	public static class PotentialSpawns extends LevelEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks)
				callback.onPotentialSpawn(event);
		});

		private final class_1311 mobcategory;
		private final class_2338 pos;
		@Nullable
		private List<class_5483.class_1964> list;
		private List<class_5483.class_1964> view;

		public PotentialSpawns(class_1936 level, class_1311 category, class_2338 pos, class_6012<class_5483.class_1964> oldList) {
			super(level);
			this.pos = pos;
			this.mobcategory = category;
			this.list = null;
			this.view = oldList.method_34994();
		}

		/**
		 * {@return the category of the mobs in the spawn list.}
		 */
		public class_1311 getMobCategory() {
			return mobcategory;
		}

		/**
		 * {@return the block position where the chosen mob will be spawned.}
		 */
		public class_2338 getPos() {
			return pos;
		}

		/**
		 * {@return the list of mobs that can potentially be spawned.}
		 */
		public List<class_5483.class_1964> getSpawnerDataList() {
			return view;
		}

		private void makeList() {
			if (list == null) {
				list = new ArrayList<>(view);
				view = Collections.unmodifiableList(list);
			}
		}

		/**
		 * Appends a SpawnerData entry to the spawn list.
		 *
		 * @param data SpawnerData entry to be appended to the spawn list.
		 */
		public void addSpawnerData(class_5483.class_1964 data) {
			makeList();
			list.add(data);
		}

		/**
		 * Removes a SpawnerData entry from the spawn list.
		 *
		 * @param data SpawnerData entry to be removed from the spawn list.
		 *
		 *             {@return {@code true} if the spawn list contained the specified element.}
		 */
		public boolean removeSpawnerData(class_5483.class_1964 data) {
			makeList();
			return list.remove(data);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onPotentialSpawn(this);
		}

		public interface Callback {
			void onPotentialSpawn(PotentialSpawns event);
		}
	}
}
