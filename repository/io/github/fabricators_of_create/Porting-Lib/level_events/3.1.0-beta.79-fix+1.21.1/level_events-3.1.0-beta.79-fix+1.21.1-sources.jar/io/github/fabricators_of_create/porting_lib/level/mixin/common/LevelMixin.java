package io.github.fabricators_of_create.porting_lib.level.mixin.common;

import io.github.fabricators_of_create.porting_lib.level.events.BlockEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.EnumSet;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

@Mixin(class_1937.class)
public abstract class LevelMixin {
	@Shadow
	public abstract class_2680 getBlockState(class_2338 blockPos);

	@Inject(method = "updateNeighborsAt", at = @At("HEAD"))
	private void neighborNotify(class_2338 pPos, class_2248 block, CallbackInfo ci) {
		BlockEvent.NeighborNotifyEvent event = new BlockEvent.NeighborNotifyEvent((class_1937) (Object) this, pPos, getBlockState(pPos), EnumSet.allOf(class_2350.class), false);
		event.sendEvent();
	}
}
