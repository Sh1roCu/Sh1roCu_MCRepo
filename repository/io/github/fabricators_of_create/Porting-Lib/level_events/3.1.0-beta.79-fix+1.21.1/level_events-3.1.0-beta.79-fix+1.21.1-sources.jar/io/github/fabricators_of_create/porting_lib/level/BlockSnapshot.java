/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package io.github.fabricators_of_create.porting_lib.level;

import java.lang.ref.WeakReference;
import java.util.Objects;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import io.github.fabricators_of_create.porting_lib.core.util.ServerLifecycleHooks;
import io.github.fabricators_of_create.porting_lib.level.events.BlockEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Nullable;

/**
 * Represents a captured snapshot of a block, including the level, position, state, BE data, and setBlock flags.
 * <p>
 * Used to record the prior state and unwind changes if the change was denied, such as during {@link BlockEvent.BreakEvent}.
 */
public class BlockSnapshot {
	private static final boolean DEBUG = Boolean.parseBoolean(System.getProperty("porting-lib.debugBlockSnapshot", "false"));
	private static final Logger LOGGER = LogManager.getLogger();

	private final class_5321<class_1937> dim;
	private final class_2338 pos;
	private final int flags;
	private final class_2680 state;
	@Nullable
	private final class_2487 nbt;

	private WeakReference<class_1936> level;
	@Nullable
	private String toString = null;

	private BlockSnapshot(class_5321<class_1937> dim, class_1936 level, class_2338 pos, class_2680 state, @Nullable class_2487 nbt, int flags) {
		this.dim = dim;
		this.pos = pos.method_10062();
		this.state = state;
		this.flags = flags;
		this.nbt = nbt;

		this.level = new WeakReference<>(level);

		if (DEBUG) {
			LOGGER.debug("Created " + this.toString());
		}
	}

	/**
	 * Creates a new snapshot of the data at the given position.
	 *
	 * @param dim   The dimension of the changed block
	 * @param level The level of the changed block
	 * @param pos   The position of the changed block
	 * @param flag  The {@link class_1937#method_8652(class_2338, class_2680, int)} flags that the block was changed with.
	 * @return A captured block snapshot, containing the state and BE data from the given position.
	 */
	public static BlockSnapshot create(class_5321<class_1937> dim, class_1936 level, class_2338 pos, int flag) {
		return new BlockSnapshot(dim, level, pos, level.method_8320(pos), getBlockEntityTag(level, pos), flag);
	}

	/**
	 * Creates a new snapshot with the default block flags ({@link class_2248#field_31027 and Block#UPDATE_CLIENTS}.
	 *
	 * @see #create(class_5321, class_1936, class_2338, int)
	 */
	public static BlockSnapshot create(class_5321<class_1937> dim, class_1936 level, class_2338 pos) {
		return create(dim, level, pos, 3);
	}

	/**
	 * {@return the recorded dimension key}
	 */
	public class_5321<class_1937> getDimension() {
		return this.dim;
	}

	/**
	 * {@return the recorded position}
	 */
	public class_2338 getPos() {
		return pos;
	}

	/**
	 * @return the recorded {@link class_1937#method_8652(class_2338, class_2680, int)} flags
	 */
	public int getFlags() {
		return flags;
	}

	/**
	 * {@return the recorded block entity NBT data, if one was present}
	 */
	@Nullable
	public class_2487 getTag() {
		return nbt;
	}

	/**
	 * {@return the snapshot's recorded block state}
	 */
	public class_2680 getState() {
		return this.state;
	}

	/**
	 * {@return the stored level, attempting to resolve it from the current server if it has gone out of scope}
	 */
	@Nullable
	public class_1936 getLevel() {
		class_1936 level = this.level.get();
		if (level == null) {
			level = ServerLifecycleHooks.getCurrentServer().method_3847(this.dim);
			this.level = new WeakReference<>(level);
		}
		return level;
	}

	/**
	 * {@return the current (live) block state at the recorded position, not the snapshot's recorded state}
	 */
	public class_2680 getCurrentState() {
		class_1936 level = this.getLevel();
		return level == null ? class_2246.field_10124.method_9564() : level.method_8320(this.pos);
	}

	/**
	 * Recreates a block entity from the stored data (pos/state/NBT) of this block snapshot.
	 *
	 * @return The newly created block entity, or null if no NBT data was present, or it was invalid.
	 */
	@Nullable
	public class_2586 recreateBlockEntity(class_7225.class_7874 provider) {
		return getTag() != null ? class_2586.method_11005(getPos(), getState(), getTag(), provider) : null;
	}

	/**
	 * Restores this block snapshot to the target level and position with the specified flags.
	 *
	 * @return true if the block was successfully updated, false otherwise.
	 */
	public boolean restoreToLocation(class_1936 level, class_2338 pos, int flags) {
		class_2680 replaced = getState();

		if (!level.method_8652(pos, replaced, flags)) {
			return false;
		}

		if (level instanceof class_1937 realLevel) {
			class_2680 current = getCurrentState();
			realLevel.method_8413(pos, current, replaced, flags);
		}

		restoreBlockEntity(level, pos);

		if (DEBUG) {
			LOGGER.debug("Restored " + this.toString());
		}

		return true;
	}

	/**
	 * Calls {@link #restoreToLocation} with the stored level, position, but custom block flags.
	 */
	public boolean restore(int flags) {
		return restoreToLocation(getLevel(), getPos(), flags);
	}

	/**
	 * Calls {@link #restoreToLocation} with the stored level, position, and block flags.
	 */
	public boolean restore() {
		return restore(this.getFlags());
	}

	/**
	 * Loads the stored {@link class_2586} data if one exists at the given position.
	 *
	 * @return true if any data was loaded
	 */
	public boolean restoreBlockEntity(class_1936 level, class_2338 pos) {
		class_2586 be = null;
		if (getTag() != null) {
			be = level.method_8321(pos);
			if (be != null) {
				be.method_58690(getTag(), level.method_30349());
				be.method_5431();
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (obj == null || getClass() != obj.getClass())
			return false;

		final BlockSnapshot other = (BlockSnapshot) obj;
		return this.dim.equals(other.dim) &&
				this.pos.equals(other.pos) &&
				this.state == other.state &&
				this.flags == other.flags &&
				Objects.equals(this.nbt, other.nbt);
	}

	@Override
	public int hashCode() {
		int hash = 7;
		hash = 73 * hash + this.dim.hashCode();
		hash = 73 * hash + this.pos.hashCode();
		hash = 73 * hash + this.state.hashCode();
		hash = 73 * hash + this.flags;
		hash = 73 * hash + Objects.hashCode(this.getTag());
		return hash;
	}

	@Override
	public String toString() {
		if (toString == null) {
			this.toString = "BlockSnapshot[" +
					"Level:" + this.dim.method_29177() + ',' +
					"Pos: " + this.pos + ',' +
					"State: " + this.state + ',' +
					"Flags: " + this.flags + ',' +
					"NBT: " + (this.nbt == null ? "null" : this.nbt.toString()) +
					']';
		}
		return this.toString;
	}

	/**
	 * Checks for a block entity at a given position, and saves it to NBT with full metadata if it exists.
	 */
	@Nullable
	private static class_2487 getBlockEntityTag(class_1936 level, class_2338 pos) {
		class_2586 be = level.method_8321(pos);
		return be == null ? null : be.method_38242(level.method_30349());
	}
}
