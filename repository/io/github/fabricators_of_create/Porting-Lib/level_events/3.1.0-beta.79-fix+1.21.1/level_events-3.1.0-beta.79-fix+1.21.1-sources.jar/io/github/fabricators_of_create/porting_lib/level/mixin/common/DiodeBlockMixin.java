package io.github.fabricators_of_create.porting_lib.level.mixin.common;

import io.github.fabricators_of_create.porting_lib.level.events.BlockEvent;
import net.minecraft.class_1937;
import net.minecraft.class_2312;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2312.class)
public class DiodeBlockMixin {
	@Inject(method = "updateNeighborsInFront", at = @At("HEAD"), cancellable = true)
	private void notifyNeighborsEvent(class_1937 pLevel, class_2338 pPos, class_2680 blockState, CallbackInfo ci) {
		class_2350 direction = blockState.method_11654(class_2383.field_11177);
		BlockEvent.NeighborNotifyEvent event = new BlockEvent.NeighborNotifyEvent(pLevel, pPos, pLevel.method_8320(pPos), java.util.EnumSet.of(direction.method_10153()), false);
		event.sendEvent();
		if (event.isCanceled())
			ci.cancel();
	}
}
