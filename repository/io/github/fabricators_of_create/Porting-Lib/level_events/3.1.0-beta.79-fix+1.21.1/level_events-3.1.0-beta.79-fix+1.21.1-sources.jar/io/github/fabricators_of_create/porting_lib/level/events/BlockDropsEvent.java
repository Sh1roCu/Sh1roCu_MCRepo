package io.github.fabricators_of_create.porting_lib.level.events;

import com.google.common.base.Preconditions;
import java.util.List;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.level.LevelHooks;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.jetbrains.annotations.Nullable;

/**
 * Fired when a block is broken and the drops have been determined, but before they have been added to the world. This event can be used to manipulate the dropped items and experience.
 * <p>
 * No guarantees can be made about the block. It will either have already been removed from the world, or will be removed after the event terminates.
 * <p>
 * If you wish to edit the state of the block in-world, use {@link BreakEvent}.
 */
public class BlockDropsEvent extends BlockEvent implements CancellableEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (Callback callback : callbacks) {
			callback.onBlockDropsCallback(event);
		}
	});

	@Nullable
	private final class_2586 blockEntity;
	private final List<class_1542> drops;
	@Nullable
	private final class_1297 breaker;
	private final class_1799 tool;
	private int experience;

	/**
	 * Constructs a new BlockDropsEvent
	 *
	 * @param level       The level of the broken block
	 * @param pos         The position of the broken block
	 * @param state       The state of the broken block
	 * @param blockEntity The block entity of the broken block, if available
	 * @param drops       The list of drops from {@link class_2248#method_9560}
	 * @param breaker     The entity who broke the block, if any
	 * @param tool        The tool used to break the block. May be empty
	 */
	public BlockDropsEvent(class_3218 level, class_2338 pos, class_2680 state, @Nullable class_2586 blockEntity, List<class_1542> drops, @Nullable class_1297 breaker, class_1799 tool) {
		super(level, pos, state);
		this.blockEntity = blockEntity;
		this.drops = drops;
		this.breaker = breaker;
		this.tool = tool;

		this.experience = class_1890.method_60157(level, tool, LevelHooks.getExpDrop(state, level, pos, blockEntity, breaker, tool));
	}

	/**
	 * Returns a mutable list of item entities that will be dropped by this block.
	 * <p>
	 * When this event completes successfully, all entities in this list will be added to the world.
	 *
	 * @return A mutable list of item entities.
	 * @apiNote Prefer using {@link LootModifier}s to add additional loot drops.
	 */
	public List<class_1542> getDrops() {
		return this.drops;
	}

	/**
	 * {@return the block entity from the current position, if available}
	 */
	@Nullable
	public class_2586 getBlockEntity() {
		return blockEntity;
	}

	/**
	 * {@return the entity that broke the block, or null if unknown}
	 */
	@Nullable
	public class_1297 getBreaker() {
		return this.breaker;
	}

	/**
	 * {@return the tool used when breaking this block; may be empty}
	 */
	public class_1799 getTool() {
		return this.tool;
	}

	/**
	 * Cancels this event, preventing any drops from being spawned and preventing {@link class_2248#method_9565} from being called.
	 * <p>
	 * Also prevents experience from being spawned.
	 */
	@Override
	public void setCanceled(boolean canceled) {
		CancellableEvent.super.setCanceled(canceled);
	}

	@Override
	public class_3218 getLevel() {
		return (class_3218) super.getLevel();
	}

	/**
	 * {@return the amount of experience points that will be dropped by the block}
	 */
	public int getDroppedExperience() {
		return experience;
	}

	/**
	 * Set the amount of experience points that will be dropped by the block. This is the true value, after enchantments have been applied.
	 *
	 * @param experience The new amount. Must not be negative.
	 * @apiNote When cancelled, no experience is dropped, regardless of this value.
	 */
	public void setDroppedExperience(int experience) {
		Preconditions.checkArgument(experience >= 0, "May not set a negative experience drop.");
		this.experience = experience;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onBlockDropsCallback(this);
	}

	public interface Callback {
		void onBlockDropsCallback(BlockDropsEvent event);
	}
}
