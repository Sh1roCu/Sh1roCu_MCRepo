package io.github.fabricators_of_create.porting_lib.level.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.level.LevelHooks;
import io.github.fabricators_of_create.porting_lib.level.events.LevelEvent;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3949;
import net.minecraft.class_5268;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;

@Mixin(MinecraftServer.class)
public class MinecraftServerMixin {
	@Shadow
	@Final
	private Map<class_5321<class_1937>, class_3218> levels;

	@Inject(method = "createLevels", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/storage/ServerLevelData;isInitialized()Z"))
	private void onLoadOverworld(class_3949 chunkProgressListener, CallbackInfo ci) {
		new LevelEvent.Load(this.levels.get(class_1937.field_25179)).sendEvent();
	}

	@Inject(method = "createLevels", at = @At(
			value = "INVOKE",
			target = "Ljava/util/Map;put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",
			ordinal = 1,
			shift = At.Shift.AFTER
	))
	private void onLoadWorld(class_3949 chunkProgressListener, CallbackInfo ci, @Local(index = 18) class_5321<class_1937> key) {
		new LevelEvent.Load(levels.get(key)).sendEvent();
	}

	@Inject(method = "stopServer", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;close()V"))
	private void onStopServer(CallbackInfo ci, @Local(index = 2) class_3218 serverLevel) {
		new LevelEvent.Unload(serverLevel).sendEvent();
	}

	@Inject(method = "setInitialSpawn", at = @At(value = "NEW", target = "(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/ChunkPos;"), cancellable = true)
	private static void onCreateWorldSpawn(class_3218 serverLevel, class_5268 serverLevelData, boolean bl, boolean bl2, CallbackInfo ci) {
		if (LevelHooks.onCreateWorldSpawn(serverLevel, serverLevelData))
			ci.cancel();
	}
}
