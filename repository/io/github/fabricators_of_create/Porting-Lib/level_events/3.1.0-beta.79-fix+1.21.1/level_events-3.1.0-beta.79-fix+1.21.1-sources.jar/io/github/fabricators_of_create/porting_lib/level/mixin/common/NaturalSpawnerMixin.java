package io.github.fabricators_of_create.porting_lib.level.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import io.github.fabricators_of_create.porting_lib.level.LevelHooks;
import net.minecraft.class_1311;
import net.minecraft.class_1948;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2794;
import net.minecraft.class_3218;
import net.minecraft.class_5138;
import net.minecraft.class_5483;
import net.minecraft.class_6012;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1948.class)
public class NaturalSpawnerMixin {
	@ModifyReturnValue(method = "mobsAt", at = @At("RETURN"))
	private static class_6012<class_5483.class_1964> modifyMobs(class_6012<class_5483.class_1964> original, class_3218 serverLevel, class_5138 structureManager, class_2794 chunkGenerator, class_1311 mobCategory, class_2338 blockPos, @Nullable class_6880<class_1959> holder) {
		return LevelHooks.getPotentialSpawns(serverLevel, mobCategory, blockPos, original);
	}
}
