package io.github.fabricators_of_create.porting_lib.level.events;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1923;
import net.minecraft.class_1936;
import net.minecraft.class_2487;
import net.minecraft.class_2791;
import net.minecraft.class_2808;
import net.minecraft.class_2852;
import net.minecraft.class_3218;
import net.minecraft.class_3898;
import net.minecraft.class_4153;
import net.minecraft.class_9240;

/**
 * ChunkDataEvent is fired when an event involving chunk data occurs.<br>
 * If a method utilizes this {@link BaseEvent} as its parameter, the method will
 * receive every child event of this class.<br>
 * <br>
 * {@link #data} contains the CompoundTag containing the chunk data for this event.<br>
 * <br>
 **/
public abstract class ChunkDataEvent extends ChunkEvent {
	private final class_2487 data;

	public ChunkDataEvent(class_2791 chunk, class_2487 data) {
		super(chunk);
		this.data = data;
	}

	public ChunkDataEvent(class_2791 chunk, class_1936 world, class_2487 data) {
		super(chunk, world);
		this.data = data;
	}

	public class_2487 getData() {
		return data;
	}

	/**
	 * ChunkDataEvent.Load is fired when vanilla Minecraft attempts to load Chunk data.<br>
	 * This event is fired during chunk loading in
	 * {@link class_2852#method_12395(class_3218, class_4153, class_9240, class_1923, class_2487)} which means it is async, so be careful.<br>
	 * <br>
	 * This event is not {@link CancellableEvent}.<br>
	 * <br>
	 * This event does not have a result. <br>
	 * <br>
	 **/
	public static class Load extends ChunkDataEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks) {
				callback.onChunkDataLoad(event);
			}
		});

		private class_2808 status;

		public Load(class_2791 chunk, class_2487 data, class_2808 type) {
			super(chunk, data);
			this.status = type;
		}

		public class_2808 getType() {
			return this.status;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onChunkDataLoad(this);
		}

		public interface Callback {
			void onChunkDataLoad(io.github.fabricators_of_create.porting_lib.level.events.ChunkDataEvent.Load event);
		}
	}

	/**
	 * ChunkDataEvent.Save is fired when vanilla Minecraft attempts to save Chunk data.<br>
	 * This event is fired during chunk saving in
	 * {@link class_3898#method_17228(class_2791)}. <br>
	 * <br>
	 * This event is not {@link CancellableEvent}.<br>
	 * <br>
	 * This event does not have a result. <br>
	 * <br>
	 **/
	public static class Save extends ChunkDataEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks) {
				callback.onChunkDataSave(event);
			}
		});

		public Save(class_2791 chunk, class_1936 world, class_2487 data) {
			super(chunk, world, data);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onChunkDataSave(this);
		}

		public interface Callback {
			void onChunkDataSave(io.github.fabricators_of_create.porting_lib.level.events.ChunkDataEvent.Save event);
		}
	}
}
