package io.github.fabricators_of_create.porting_lib.level.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.level.BlockSnapshot;
import io.github.fabricators_of_create.porting_lib.level.LevelHooks;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1747.class)
public abstract class BlockItemMixin {
	@WrapOperation(method = "place", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/BlockItem;placeBlock(Lnet/minecraft/world/item/context/BlockPlaceContext;Lnet/minecraft/world/level/block/state/BlockState;)Z"))
	private boolean port_lib$callEntityPlaceEvent(class_1747 instance, class_1750 context, class_2680 placedState, Operation<Boolean> original) {
		BlockSnapshot snapshot = BlockSnapshot.create(context.method_8045().method_27983(), context.method_8045(), context.method_8037());
		boolean value = original.call(instance, context, placedState);

		if (value && LevelHooks.onBlockPlace(context.method_8036(), snapshot, context.method_7715())) {
			snapshot.restore();
			return false;
		}

		return value;
	}
}
