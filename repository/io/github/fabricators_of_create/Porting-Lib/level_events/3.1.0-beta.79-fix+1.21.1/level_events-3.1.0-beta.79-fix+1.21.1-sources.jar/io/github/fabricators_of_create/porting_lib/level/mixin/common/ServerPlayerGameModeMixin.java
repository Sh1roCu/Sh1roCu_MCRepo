package io.github.fabricators_of_create.porting_lib.level.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.level.LevelHooks;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_3225.class)
public class ServerPlayerGameModeMixin {
	@Shadow
	private class_1934 gameModeForPlayer;

	@WrapOperation(method = "destroyBlock", at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/item/Item;canAttackBlock(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)Z"
	))
	private boolean onBlockBreak(class_1792 instance, class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player, Operation<Boolean> original) {
		return !LevelHooks.fireBlockBreak(level, this.gameModeForPlayer, (class_3222) player, blockPos, blockState, original).isCanceled();
	}
}
