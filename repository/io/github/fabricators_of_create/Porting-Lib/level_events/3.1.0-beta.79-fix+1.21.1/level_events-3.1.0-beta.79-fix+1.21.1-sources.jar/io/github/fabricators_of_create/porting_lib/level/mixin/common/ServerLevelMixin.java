package io.github.fabricators_of_create.porting_lib.level.mixin.common;

import io.github.fabricators_of_create.porting_lib.level.events.BlockEvent;
import io.github.fabricators_of_create.porting_lib.level.events.LevelEvent;
import io.github.fabricators_of_create.porting_lib.level.events.SleepFinishedTimeEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.EnumSet;
import java.util.function.Supplier;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2874;
import net.minecraft.class_3218;
import net.minecraft.class_3536;
import net.minecraft.class_3695;
import net.minecraft.class_5269;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6880;

@Mixin(class_3218.class)
public abstract class ServerLevelMixin extends class_1937 {
	protected ServerLevelMixin(class_5269 writableLevelData, class_5321<class_1937> resourceKey, class_5455 registryAccess, class_6880<class_2874> holder, Supplier<class_3695> supplier, boolean bl, boolean bl2, long l, int i) {
		super(writableLevelData, resourceKey, registryAccess, holder, supplier, bl, bl2, l, i);
	}

	@ModifyArg(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerLevel;setDayTime(J)V"))
	private long sleepFinishedEvent(long newTime) {
		SleepFinishedTimeEvent event = new SleepFinishedTimeEvent((class_3218) (Object) this, newTime, method_8532());
		event.sendEvent();
		return event.getNewTime();
	}

	@Inject(method = "save", at = @At("TAIL"))
	private void onSave(class_3536 progressListener, boolean bl, boolean bl2, CallbackInfo ci) {
		if (!bl2) {
			new LevelEvent.Save(this).sendEvent();
		}
	}

	@Inject(method = "updateNeighborsAt", at = @At("HEAD"))
	private void neighborNotify(class_2338 pPos, class_2248 block, CallbackInfo ci) {
		BlockEvent.NeighborNotifyEvent event = new BlockEvent.NeighborNotifyEvent(this, pPos, this.method_8320(pPos), EnumSet.allOf(class_2350.class), false);
		event.sendEvent();
	}

	@Inject(method = "updateNeighborsAtExceptFromFacing", at = @At("HEAD"), cancellable = true)
	private void neighborNotifyExpectFacing(class_2338 pPos, class_2248 block, class_2350 pSkipSide, CallbackInfo ci) {
		EnumSet<class_2350> directions =EnumSet.allOf(class_2350.class);
		directions.remove(pSkipSide);
		BlockEvent.NeighborNotifyEvent event = new BlockEvent.NeighborNotifyEvent(this, pPos, this.method_8320(pPos), directions, false);
		event.sendEvent();
		if (event.isCanceled())
			ci.cancel();
	}
}
