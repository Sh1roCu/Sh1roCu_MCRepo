package io.github.fabricators_of_create.porting_lib.level.mixin.client;

import io.github.fabricators_of_create.porting_lib.level.events.LevelEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Supplier;
import net.minecraft.class_1937;
import net.minecraft.class_2874;
import net.minecraft.class_3695;
import net.minecraft.class_5269;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_761;

@Mixin(class_638.class)
public abstract class ClientLevelMixin extends class_1937 {
	protected ClientLevelMixin(class_5269 writableLevelData, class_5321<class_1937> resourceKey, class_5455 registryAccess, class_6880<class_2874> holder, Supplier<class_3695> supplier, boolean bl, boolean bl2, long l, int i) {
		super(writableLevelData, resourceKey, registryAccess, holder, supplier, bl, bl2, l, i);
	}

	@Inject(method = "<init>", at = @At("TAIL"))
	private void onLoad(class_634 clientPacketListener, class_638.class_5271 clientLevelData, class_5321<class_1937> resourceKey, class_6880<class_2874> holder, int i, int j, Supplier<class_3695> supplier, class_761 levelRenderer, boolean bl, long l, CallbackInfo ci) {
		new LevelEvent.Load(this).sendEvent();
	}
}
