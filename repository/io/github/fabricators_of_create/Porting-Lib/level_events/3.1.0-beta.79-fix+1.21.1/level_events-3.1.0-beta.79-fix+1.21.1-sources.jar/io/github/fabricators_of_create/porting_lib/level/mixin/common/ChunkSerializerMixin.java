package io.github.fabricators_of_create.porting_lib.level.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.level.events.ChunkDataEvent;
import net.minecraft.class_1923;
import net.minecraft.class_2487;
import net.minecraft.class_2791;
import net.minecraft.class_2808;
import net.minecraft.class_2839;
import net.minecraft.class_2852;
import net.minecraft.class_3218;
import net.minecraft.class_4153;
import net.minecraft.class_9240;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2852.class)
public class ChunkSerializerMixin {
	@Inject(method = "read", at = @At(value = "RETURN", ordinal = 0))
	private static void onChunkDataLoad0(class_3218 level, class_4153 poiManager, class_9240 regionStorageInfo, class_1923 pos, class_2487 tag, CallbackInfoReturnable<class_2839> cir, @Local class_2791 chunkAccess, @Local class_2808 chunktype) {
		new ChunkDataEvent.Load(chunkAccess, tag, chunktype).sendEvent();
	}

	@Inject(method = "read", at = @At(value = "RETURN", ordinal = 1))
	private static void onChunkDataLoad1(class_3218 level, class_4153 poiManager, class_9240 regionStorageInfo, class_1923 pos, class_2487 tag, CallbackInfoReturnable<class_2839> cir, @Local class_2791 chunkAccess, @Local class_2808 chunktype) {
		new ChunkDataEvent.Load(chunkAccess, tag, chunktype).sendEvent();
	}
}
