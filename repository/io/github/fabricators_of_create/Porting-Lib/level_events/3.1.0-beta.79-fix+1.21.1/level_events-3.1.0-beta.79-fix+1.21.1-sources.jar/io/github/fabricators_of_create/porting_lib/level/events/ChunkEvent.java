package io.github.fabricators_of_create.porting_lib.level.events;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import net.minecraft.class_1936;
import net.minecraft.class_2791;
import net.minecraft.class_2818;

/**
 * ChunkEvent is fired when an event involving a chunk occurs.<br>
 * If a method utilizes this {@link BaseEvent} as its parameter, the method will
 * receive every child event of this class.<br>
 * <br>
 * {@link #chunk} contains the Chunk this event is affecting.<br>
 * <br>
 **/
public abstract class ChunkEvent extends LevelEvent {
	private final class_2791 chunk;

	public ChunkEvent(class_2791 chunk) {
		super(chunk instanceof class_2818 levelChunk ? levelChunk.method_12200() : null);
		this.chunk = chunk;
	}

	public ChunkEvent(class_2791 chunk, class_1936 level) {
		super(level);
		this.chunk = chunk;
	}

	public class_2791 getChunk() {
		return chunk;
	}
}
