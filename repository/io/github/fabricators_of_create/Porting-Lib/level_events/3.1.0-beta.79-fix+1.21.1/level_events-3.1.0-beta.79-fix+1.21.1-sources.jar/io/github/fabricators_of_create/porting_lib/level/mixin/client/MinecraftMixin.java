package io.github.fabricators_of_create.porting_lib.level.mixin.client;

import io.github.fabricators_of_create.porting_lib.level.events.LevelEvent;
import net.minecraft.class_310;
import net.minecraft.class_434;
import net.minecraft.class_437;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftMixin {
	@Shadow
	@Nullable
	public class_638 level;

	@Inject(method = "setLevel", at = @At("HEAD"))
	private void onUnload(class_638 clientLevel, class_434.class_9678 reason, CallbackInfo ci) {
		if (this.level != null) new LevelEvent.Unload(this.level).sendEvent();
	}

	@Inject(method = "disconnect(Lnet/minecraft/client/gui/screens/Screen;Z)V", at = @At(
			value = "FIELD",
			target = "Lnet/minecraft/client/Minecraft;level:Lnet/minecraft/client/multiplayer/ClientLevel;",
			ordinal = 0,
			shift = At.Shift.AFTER
	))
	private void onDisconnect(class_437 screen, boolean bl, CallbackInfo ci) {
		if (this.level != null) {
			new LevelEvent.Unload(this.level).sendEvent();
		}
	}
}
