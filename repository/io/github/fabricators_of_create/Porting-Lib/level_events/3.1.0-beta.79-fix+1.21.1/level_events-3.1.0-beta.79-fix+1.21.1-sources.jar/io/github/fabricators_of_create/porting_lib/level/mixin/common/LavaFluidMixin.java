package io.github.fabricators_of_create.porting_lib.level.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.level.LevelHooks;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3616;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_3616.class)
public class LavaFluidMixin {
	@WrapOperation(method = "randomTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;setBlockAndUpdate(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Z"))
	private boolean onFluidPlace(class_1937 instance, class_2338 blockPos, class_2680 blockState, Operation<Boolean> original, class_1937 p_230572_, class_2338 p_230573_) {
		return original.call(instance, blockPos, LevelHooks.fireFluidPlaceBlockEvent(instance, blockPos, p_230573_, blockState));
	}

	@WrapOperation(method = "spreadTo", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/LevelAccessor;setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z"))
	private boolean onFluidPlaceSpread(class_1936 instance, class_2338 blockPos, class_2680 blockState, int updateType, Operation<Boolean> original) {
		return original.call(instance, blockPos, LevelHooks.fireFluidPlaceBlockEvent(instance, blockPos, blockPos, blockState), updateType);
	}
}
