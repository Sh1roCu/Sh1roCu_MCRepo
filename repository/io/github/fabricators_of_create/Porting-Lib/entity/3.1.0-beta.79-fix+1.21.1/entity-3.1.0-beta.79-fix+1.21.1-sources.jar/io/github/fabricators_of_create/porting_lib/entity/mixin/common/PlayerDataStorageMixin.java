package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.io.File;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_29;

@Mixin(class_29.class)
public class PlayerDataStorageMixin {
	@Shadow
	@Final
	private File playerDir;

	@Inject(method = "save", at = @At(value = "INVOKE", target = "Lnet/minecraft/Util;safeReplaceFile(Ljava/nio/file/Path;Ljava/nio/file/Path;Ljava/nio/file/Path;)V", shift = At.Shift.AFTER))
	private void onPlayerSaving(class_1657 player, CallbackInfo ci) {
		EntityHooks.firePlayerSavingEvent(player, this.playerDir, player.method_5845());
	}

	@Inject(method = "method_55788", at = @At("RETURN"))
	private void onPlayerLoading(class_1657 player, class_2487 tag, CallbackInfoReturnable<class_2487> cir) {
		EntityHooks.firePlayerLoadingEvent(player, this.playerDir, player.method_5845());
	}
}
