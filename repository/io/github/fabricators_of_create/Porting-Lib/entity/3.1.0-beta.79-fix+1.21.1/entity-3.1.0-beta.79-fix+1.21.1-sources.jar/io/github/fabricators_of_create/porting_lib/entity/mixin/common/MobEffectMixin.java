package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.injects.MobEffectInjection;
import net.minecraft.class_1291;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1291.class)
public class MobEffectMixin implements MobEffectInjection {
}
