package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.extensions.VanillaIShearable;
import net.minecraft.class_1438;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1438.class)
public abstract class MushroomCowMixin implements VanillaIShearable {
}
