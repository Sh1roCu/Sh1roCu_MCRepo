package io.github.fabricators_of_create.porting_lib.entity.client;

import io.github.fabricators_of_create.porting_lib.entity.IEntityWithComplexSpawn;
import io.github.fabricators_of_create.porting_lib.entity.MultiPartEntity;
import io.github.fabricators_of_create.porting_lib.entity.PartEntity;
import io.github.fabricators_of_create.porting_lib.entity.mixin.common.BlockableEventLoopAccessor;
import io.github.fabricators_of_create.porting_lib.entity.network.AdvancedAddEntityPayload;
import io.netty.buffer.Unpooled;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_9129;

public class PortingLibEntityClient implements ClientModInitializer {
	public static void handleAddComplexEntity(AdvancedAddEntityPayload advancedAddEntityPayload, ClientPlayNetworking.Context context) {
		try {
			class_1297 entity = context.player().method_37908().method_8469(advancedAddEntityPayload.entityId());
			if (entity instanceof IEntityWithComplexSpawn entityAdditionalSpawnData) {
				final class_9129 buf = new class_9129(Unpooled.wrappedBuffer(advancedAddEntityPayload.customPayload()), entity.method_56673());
				try {
					execute(context.client(), () -> entityAdditionalSpawnData.readSpawnData(buf));
				} finally {
					buf.release();
				}
			}
		} catch (Throwable t) {
			context.responseSender().disconnect(class_2561.method_43469("porting_lib.network.advanced_add_entity.failed", t.getMessage()));
		}
	}

	private static void execute(class_310 mc, Runnable task) {
		// sometimes MC will defer a task even if already on the right thread.
		// Forge avoids this when calling enqueueWork.
		// We need to replicate this behavior for proper packet ordering.
		if (mc.method_18854()) {
			task.run();
		} else {
			// Forge also bypasses public methods
			((BlockableEventLoopAccessor) mc).callSubmitAsync(task);
		}
	}

	@Override
	public void onInitializeClient() {
		ClientPlayNetworking.registerGlobalReceiver(AdvancedAddEntityPayload.TYPE, PortingLibEntityClient::handleAddComplexEntity);
		ClientEntityEvents.ENTITY_LOAD.register((entity, world) -> {
			if (entity instanceof MultiPartEntity partEntity && partEntity.isMultipartEntity()) {
				for (PartEntity<?> part : partEntity.getParts()) {
					world.getPartEntityMap().put(part.method_5628(), part);
				}
			}
		});
		ClientEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
			if (entity instanceof MultiPartEntity partEntity && partEntity.isMultipartEntity()) {
				for (PartEntity<?> part : partEntity.getParts()) {
					world.getPartEntityMap().remove(part.method_5628());
				}
			}
		});
	}
}
