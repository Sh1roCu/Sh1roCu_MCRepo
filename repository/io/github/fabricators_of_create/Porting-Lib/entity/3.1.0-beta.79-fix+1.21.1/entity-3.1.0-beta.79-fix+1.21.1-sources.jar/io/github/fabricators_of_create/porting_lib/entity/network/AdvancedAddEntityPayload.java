package io.github.fabricators_of_create.porting_lib.entity.network;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.entity.IEntityWithComplexSpawn;
import io.netty.buffer.Unpooled;
import net.minecraft.class_1297;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.ApiStatus;

/**
 * Payload that can be sent from the server to the client to add an entity to the world, with custom data.
 *
 * @param entityId      The id of the entity to add.
 * @param customPayload The custom data of the entity to add.
 */
@ApiStatus.Internal
public record AdvancedAddEntityPayload(int entityId, byte[] customPayload) implements class_8710 {

	public static final class_9154<AdvancedAddEntityPayload> TYPE = new class_9154<>(PortingLib.id("advanced_add_entity"));
	public static final class_9139<class_2540, AdvancedAddEntityPayload> STREAM_CODEC = class_9139.method_56435(
			class_9135.field_48550,
			AdvancedAddEntityPayload::entityId,
			class_9135.field_48987,
			AdvancedAddEntityPayload::customPayload,
			AdvancedAddEntityPayload::new);
	public AdvancedAddEntityPayload(class_1297 e) {
		this(e.method_5628(), writeCustomData(e));
	}

	private static byte[] writeCustomData(final class_1297 entity) {
		if (!(entity instanceof IEntityWithComplexSpawn additionalSpawnData)) {
			return new byte[0];
		}

		final class_9129 buf = new class_9129(Unpooled.buffer(), entity.method_56673());
		try {
			additionalSpawnData.writeSpawnData(buf);
			return buf.array();
		} finally {
			buf.release();
		}
	}

	@Override
	public class_9154<AdvancedAddEntityPayload> method_56479() {
		return TYPE;
	}
}
