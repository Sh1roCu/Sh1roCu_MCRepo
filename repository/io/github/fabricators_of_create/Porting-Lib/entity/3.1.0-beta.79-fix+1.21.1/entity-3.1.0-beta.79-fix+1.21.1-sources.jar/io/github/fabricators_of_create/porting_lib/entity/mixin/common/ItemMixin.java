package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.injects.ItemInjection;
import net.minecraft.class_1792;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1792.class)
public class ItemMixin implements ItemInjection {
}
