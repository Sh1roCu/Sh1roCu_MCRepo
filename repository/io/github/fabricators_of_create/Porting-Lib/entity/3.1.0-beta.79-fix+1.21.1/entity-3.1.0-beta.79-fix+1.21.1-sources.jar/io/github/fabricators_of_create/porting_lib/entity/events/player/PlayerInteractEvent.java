package io.github.fabricators_of_create.porting_lib.entity.events.player;

import com.google.common.base.Preconditions;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.player.PlayerEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_3965;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * PlayerInteractEvent is fired when a player interacts in some way.
 * See the individual documentation on each subevent for more details.
 **/
public abstract class PlayerInteractEvent extends PlayerEvent {
	private final class_1268 hand;
	private final class_2338 pos;
	@Nullable
	private final class_2350 face;

	protected PlayerInteractEvent(class_1657 player, class_1268 hand, class_2338 pos, @Nullable class_2350 face) {
		super(Preconditions.checkNotNull(player, "Null player in PlayerInteractEvent!"));
		this.hand = Preconditions.checkNotNull(hand, "Null hand in PlayerInteractEvent!");
		this.pos = Preconditions.checkNotNull(pos, "Null position in PlayerInteractEvent!");
		this.face = face;
	}

	/**
	 * This event is fired on both sides whenever a player right clicks an entity.
	 *
	 * "Interact at" is an interact where the local vector (which part of the entity you clicked) is known.
	 * The state of this event affects whether {@link class_1297#method_5664(class_1657, class_243, class_1268)} is called.
	 *
	 * Let result be the return value of {@link class_1297#method_5664(class_1657, class_243, class_1268)}, or {@link #cancellationResult} if the event is cancelled.
	 * If we are on the client and result is not {@link class_1269#field_5812}, the client will then try {@link EntityInteract}.
	 */
	public static class EntityInteractSpecific extends PlayerInteractEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks)
				callback.onEntityInteractSpecific(event);
		});

		private class_1269 cancellationResult = class_1269.field_5811;

		private final class_243 localPos;
		private final class_1297 target;

		public EntityInteractSpecific(class_1657 player, class_1268 hand, class_1297 target, class_243 localPos) {
			super(player, hand, target.method_24515(), null);
			this.localPos = localPos;
			this.target = target;
		}

		/**
		 * Returns the local interaction position. This is a 3D vector, where (0, 0, 0) is centered exactly at the
		 * center of the entity's bounding box at their feet. This means the X and Z values will be in the range
		 * [-width / 2, width / 2] while Y values will be in the range [0, height]
		 *
		 * @return The local position
		 */
		public class_243 getLocalPos() {
			return localPos;
		}

		public class_1297 getTarget() {
			return target;
		}

		/**
		 * @return The InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
		 *         method of the event. By default, this is {@link class_1269#field_5811}, meaning cancelled events will cause
		 *         the client to keep trying more interactions until something works.
		 */
		public class_1269 getCancellationResult() {
			return cancellationResult;
		}

		/**
		 * Set the InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
		 * method of the event.
		 */
		public void setCancellationResult(class_1269 result) {
			this.cancellationResult = result;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onEntityInteractSpecific(this);
		}

		public interface Callback {
			void onEntityInteractSpecific(EntityInteractSpecific event);
		}
	}

	/**
	 * This event is fired on both sides when the player right clicks an entity.
	 * It is responsible for all general entity interactions.
	 *
	 * This event is fired only if the result of the above {@link EntityInteractSpecific} is not {@link class_1269#field_5812}.
	 * This event's state affects whether {@link class_1297#method_5688(class_1657, class_1268)} and
	 * {@link class_1792#method_7847(class_1799, class_1657, class_1309, class_1268)} are called.
	 *
	 * Let result be {@link class_1269#field_5812} if {@link class_1297#method_5688(class_1657, class_1268)} or
	 * {@link class_1792#method_7847(class_1799, class_1657, class_1309, class_1268)} return true,
	 * or {@link #cancellationResult} if the event is cancelled.
	 * If we are on the client and result is not {@link class_1269#field_5812}, the client will then try {@link RightClickItem}.
	 */
	public static class EntityInteract extends PlayerInteractEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks)
				callback.onEntityInteract(event);
		});

		private class_1269 cancellationResult = class_1269.field_5811;

		private final class_1297 target;

		public EntityInteract(class_1657 player, class_1268 hand, class_1297 target) {
			super(player, hand, target.method_24515(), null);
			this.target = target;
		}

		public class_1297 getTarget() {
			return target;
		}

		/**
		 * @return The InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
		 *         method of the event. By default, this is {@link class_1269#field_5811}, meaning cancelled events will cause
		 *         the client to keep trying more interactions until something works.
		 */
		public class_1269 getCancellationResult() {
			return cancellationResult;
		}

		/**
		 * Set the InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
		 * method of the event.
		 */
		public void setCancellationResult(class_1269 result) {
			this.cancellationResult = result;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onEntityInteract(this);
		}

		public interface Callback {
			void onEntityInteract(EntityInteract event);
		}
	}

	/**
	 * This event is fired on both sides whenever the player right clicks while targeting a block. <br>
	 * This event controls which of {@link class_1792#onItemUseFirst}, {@link class_2248#use(BlockState, Level, BlockPos, Player, InteractionHand, BlockHitResult)},
	 * and {@link class_1792#method_7884(class_1838)} will be called. <br>
	 * Canceling the event will cause none of the above three to be called. <br>
	 * <br>
	 * Let result be the first non-pass return value of the above three methods, or pass, if they all pass. <br>
	 * Or {@link #cancellationResult} if the event is cancelled. <br>
	 * If result equals {@link class_1269#field_5811}, we proceed to {@link RightClickItem}. <br>
	 * <br>
	 * There are various results to this event, see the getters below. <br>
	 * Note that handling things differently on the client vs server may cause desynchronizations!
	 */
	public static class RightClickBlock extends PlayerInteractEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks)
				callback.onRightClickBlock(event);
		});

		private class_1269 cancellationResult = class_1269.field_5811;

		private TriState useBlock = TriState.DEFAULT;
		private TriState useItem = TriState.DEFAULT;
		private class_3965 hitVec;

		public RightClickBlock(class_1657 player, class_1268 hand, class_2338 pos, class_3965 hitVec) {
			super(player, hand, pos, hitVec.method_17780());
			this.hitVec = hitVec;
		}

		/**
		 * @return If {@link class_2248#use(BlockState, Level, BlockPos, Player, InteractionHand, BlockHitResult)} should be called
		 */
		public TriState getUseBlock() {
			return useBlock;
		}

		/**
		 * @return If {@link class_1792#onItemUseFirst} and {@link class_1792#method_7884(class_1838)} should be called
		 */
		public TriState getUseItem() {
			return useItem;
		}

		/**
		 * @return The ray trace result targeting the block.
		 */
		public class_3965 getHitVec() {
			return hitVec;
		}

		/**
		 * FALSE: {@link class_2248#use(BlockState, Level, BlockPos, Player, InteractionHand, BlockHitResult)} will never be called. <br>
		 * DEFAULT: {@link class_2248#use(BlockState, Level, BlockPos, Player, InteractionHand, BlockHitResult)} will be called if {@link class_1792#onItemUseFirst} passes. <br>
		 * Note that default activation can be blocked if the user is sneaking and holding an item that does not return true to {@link class_1792#doesSneakBypassUse}. <br>
		 * TRUE: {@link class_2248#method_9611(class_2680, class_2680, class_1936, class_2338, int, int)} will always be called, unless {@link class_1792#onItemUseFirst} does not pass. <br>
		 */
		public void setUseBlock(TriState triggerBlock) {
			this.useBlock = triggerBlock;
		}

		/**
		 * FALSE: Neither {@link class_1792#method_7884(class_1838)} or {@link class_1792#onItemUseFirst} will be called. <br>
		 * DEFAULT: {@link class_1792#onItemUseFirst} will always be called, and {@link class_1792#method_7884(class_1838)} will be called if the block passes. <br>
		 * TRUE: {@link class_1792#onItemUseFirst} will always be called, and {@link class_1792#method_7884(class_1838)} will be called if the block passes, regardless of cooldowns or emptiness. <br>
		 */
		public void setUseItem(TriState triggerItem) {
			this.useItem = triggerItem;
		}

		@Override
		public void setCanceled(boolean canceled) {
			CancellableEvent.super.setCanceled(canceled);
			if (canceled) {
				useBlock = TriState.FALSE;
				useItem = TriState.FALSE;
			}
		}

		/**
		 * @return The InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
		 *         method of the event. By default, this is {@link class_1269#field_5811}, meaning cancelled events will cause
		 *         the client to keep trying more interactions until something works.
		 */
		public class_1269 getCancellationResult() {
			return cancellationResult;
		}

		/**
		 * Set the InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
		 * method of the event.
		 */
		public void setCancellationResult(class_1269 result) {
			this.cancellationResult = result;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onRightClickBlock(this);
		}

		public interface Callback {
			void onRightClickBlock(RightClickBlock event);
		}
	}

	/**
	 * This event is fired on both sides before the player triggers {@link class_1792#method_7836(class_1937, class_1657, class_1268)}.
	 * Note that this is NOT fired if the player is targeting a block {@link RightClickBlock} or entity {@link EntityInteract} {@link EntityInteractSpecific}.
	 *
	 * Let result be the return value of {@link class_1792#method_7836(class_1937, class_1657, class_1268)}, or {@link #cancellationResult} if the event is cancelled.
	 * If we are on the client and result is not {@link class_1269#field_5812}, the client will then continue to other hands.
	 */
	public static class RightClickItem extends PlayerInteractEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks)
				callback.onRightClickItem(event);
		});

		private class_1269 cancellationResult = class_1269.field_5811;

		public RightClickItem(class_1657 player, class_1268 hand) {
			super(player, hand, player.method_24515(), null);
		}

		/**
		 * @return The InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
		 *         method of the event. By default, this is {@link class_1269#field_5811}, meaning cancelled events will cause
		 *         the client to keep trying more interactions until something works.
		 */
		public class_1269 getCancellationResult() {
			return cancellationResult;
		}

		/**
		 * Set the InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
		 * method of the event.
		 */
		public void setCancellationResult(class_1269 result) {
			this.cancellationResult = result;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onRightClickItem(this);
		}

		public interface Callback {
			void onRightClickItem(RightClickItem event);
		}
	}

	/**
	 * This event is fired on the client side when the player right clicks empty space with an empty hand.
	 * The server is not aware of when the client right clicks empty space with an empty hand, you will need to tell the server yourself.
	 * This event cannot be canceled.
	 */
	public static class RightClickEmpty extends PlayerInteractEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks)
				callback.onRightClickEmpty(event);
		});

		public RightClickEmpty(class_1657 player, class_1268 hand) {
			super(player, hand, player.method_24515(), null);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onRightClickEmpty(this);
		}

		public interface Callback {
			void onRightClickEmpty(RightClickEmpty event);
		}
	}

	/**
	 * This event is fired when a player left clicks while targeting a block.
	 * This event controls which of {@link class_2248#method_9606(class_2680, class_1937, class_2338, class_1657)} and/or the item harvesting methods will be called
	 * Canceling the event will cause none of the above noted methods to be called.
	 * There are various results to this event, see the getters below.
	 * <p>
	 * This event is fired at various points during left clicking on blocks, at both the start and end on the server, and at the start and while held down on the client.
	 * Use {@link #getAction()} to check which type of action triggered this event.
	 * <p>
	 * Note that if the event is canceled and the player holds down left mouse, the event will continue to fire.
	 * This is due to how vanilla calls the left click handler methods.
	 * <p>
	 * Also note that creative mode directly breaks the block without running any other logic.
	 * Therefore, in creative mode, {@link #setUseBlock} and {@link #setUseItem} have no effect.
	 */
	public static class LeftClickBlock extends PlayerInteractEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks)
				callback.onLeftClickBlock(event);
		});

		private TriState useBlock = TriState.DEFAULT;
		private TriState useItem = TriState.DEFAULT;
		private final Action action;

		@ApiStatus.Internal
		public LeftClickBlock(class_1657 player, class_2338 pos, class_2350 face, Action action) {
			super(player, class_1268.field_5808, pos, face);
			this.action = action;
		}

		/**
		 * @return If {@link class_2248#method_9606(class_2680, class_1937, class_2338, class_1657)} should be called. Changing this has no effect in creative mode
		 */
		public TriState getUseBlock() {
			return useBlock;
		}

		/**
		 * @return If the block should be attempted to be mined with the current item. Changing this has no effect in creative mode
		 */
		public TriState getUseItem() {
			return useItem;
		}

		/**
		 * @return The action type for this interaction. Will never be null.
		 */
		public Action getAction() {
			return this.action;
		}

		public void setUseBlock(TriState triggerBlock) {
			this.useBlock = triggerBlock;
		}

		public void setUseItem(TriState triggerItem) {
			this.useItem = triggerItem;
		}

		@Override
		public void setCanceled(boolean canceled) {
			CancellableEvent.super.setCanceled(canceled);
			if (canceled) {
				useBlock = TriState.FALSE;
				useItem = TriState.FALSE;
			}
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onLeftClickBlock(this);
		}

		public enum Action {
			/**
			 * When the player first left clicks a block
			 */
			START,
			/**
			 * When the player stops left clicking a block by completely breaking it
			 */
			STOP,
			/**
			 * When the player stops left clicking a block by releasing the button, or no longer targeting the same block before it breaks.
			 */
			ABORT,
			/**
			 * When the player is actively mining a block on the client side
			 * Warning: The event is fired every tick on the client
			 */
			CLIENT_HOLD;

			public static Action convert(class_2846.class_2847 action) {
				return switch (action) {
					default -> START;
					case field_12968 -> START;
					case field_12973 -> STOP;
					case field_12971 -> ABORT;
				};
			}
		}

		public interface Callback {
			void onLeftClickBlock(LeftClickBlock event);
		}
	}

	/**
	 * This event is fired on the client side when the player left clicks empty space with any ItemStack.
	 * The server is not aware of when the client left clicks empty space, you will need to tell the server yourself.
	 * This event cannot be canceled.
	 */
	public static class LeftClickEmpty extends PlayerInteractEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks)
				callback.onLeftClickEmpty(event);
		});

		public LeftClickEmpty(class_1657 player) {
			super(player, class_1268.field_5808, player.method_24515(), null);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onLeftClickEmpty(this);
		}

		public interface Callback {
			void onLeftClickEmpty(LeftClickEmpty event);
		}
	}

	/**
	 * @return The hand involved in this interaction. Will never be null.
	 */
	public class_1268 getHand() {
		return hand;
	}

	/**
	 * @return The itemstack involved in this interaction, {@code ItemStack.EMPTY} if the hand was empty.
	 */
	public class_1799 getItemStack() {
		return getEntity().method_5998(hand);
	}

	/**
	 * If the interaction was on an entity, will be a BlockPos centered on the entity.
	 * If the interaction was on a block, will be the position of that block.
	 * Otherwise, will be a BlockPos centered on the player.
	 * Will never be null.
	 *
	 * @return The position involved in this interaction.
	 */
	public class_2338 getPos() {
		return pos;
	}

	/**
	 * @return The face involved in this interaction. For all non-block interactions, this will return null.
	 */
	@Nullable
	public class_2350 getFace() {
		return face;
	}

	/**
	 * @return Convenience method to get the level of this interaction.
	 */
	public class_1937 getLevel() {
		return getEntity().method_37908();
	}

	/**
	 * @return The effective, i.e. logical, side of this interaction. This will be {@link EnvType#CLIENT} on the client thread, and {@link EnvType#SERVER} on the server thread.
	 */
	public EnvType getSide() {
		return getLevel().field_9236 ? EnvType.CLIENT : EnvType.SERVER;
	}
}
