package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.injects.AbstractMinecartInjection;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3481;
import net.minecraft.class_3532;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1688.class)
public abstract class AbstractMinecartMixin extends class_1297 implements AbstractMinecartInjection {
	@Shadow
	protected abstract double getMaxSpeed();

	public AbstractMinecartMixin(class_1299<?> variant, class_1937 world) {
		super(variant, world);
	}

	@Override
	public void moveMinecartOnRail(class_2338 pos) {
		double d24 = method_5782() ? 0.75D : 1.0D;
		double d25 = getMaxSpeed(); // getMaxSpeed instead of getMaxSpeedWithRail *should* be fine after intense pain looking at Forge patches
		class_243 vec3d1 = method_18798();
		method_5784(class_1313.field_6308, new class_243(class_3532.method_15350(d24 * vec3d1.field_1352, -d25, d25), 0.0D, class_3532.method_15350(d24 * vec3d1.field_1350, -d25, d25)));
	}

	@Override
	public class_2338 getCurrentRailPos() {
		class_2338 pos = new class_2338(class_3532.method_15357(method_23317()), class_3532.method_15357(method_23318()), class_3532.method_15357(method_23321()));
		class_2338 below = pos.method_10074();
		if (method_37908().method_8320(below).method_26164(class_3481.field_15463)) {
			pos = below;
		}

		return pos;
	}
}
