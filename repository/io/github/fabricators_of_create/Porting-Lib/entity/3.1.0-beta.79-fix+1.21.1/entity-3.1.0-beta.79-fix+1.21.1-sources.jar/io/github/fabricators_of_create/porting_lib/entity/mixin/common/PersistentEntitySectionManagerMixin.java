package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.events.EntityJoinLevelEvent;
import net.minecraft.class_1297;
import net.minecraft.class_5568;
import net.minecraft.class_5579;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5579.class)
public class PersistentEntitySectionManagerMixin<T extends class_5568> {
	@Inject(method = "addEntity", at = @At("HEAD"), cancellable = true)
	public void port_lib$addEntityEvent(T entityAccess, boolean loadedFromDisk, CallbackInfoReturnable<Boolean> cir) {
		if (entityAccess instanceof class_1297 entity) {
			EntityJoinLevelEvent event = new EntityJoinLevelEvent(entity, entity.method_37908(), loadedFromDisk);
			event.sendEvent();
			if (event.isCanceled())
				cir.setReturnValue(false);
		}
	}
}
