package io.github.fabricators_of_create.porting_lib.entity.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import io.github.fabricators_of_create.porting_lib.entity.events.player.PlayerInteractEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public class MinecraftMixin {
	@Shadow
	@Nullable
	public class_746 player;

	@Shadow
	@Nullable
	public class_239 hitResult;

	@Inject(method = "startUseItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;isEmpty()Z", ordinal = 1))
	private void onEmptyClick(CallbackInfo ci, @Local(index = 5) class_1799 itemStack, @Local(index = 4) class_1268 hand) {
		if (itemStack.method_7960() && (this.hitResult == null || this.hitResult.method_17783() == class_239.class_240.field_1333))
			EntityHooks.onEmptyClick(this.player, hand);
	}

	@Inject(method = "startAttack", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;resetAttackStrengthTicker()V", shift = At.Shift.AFTER))
	private void leftClickEmpty(CallbackInfoReturnable<Boolean> cir) {
		EntityHooks.onEmptyLeftClick(this.player);
	}
}
