package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.datafixers.kinds.App;

import com.mojang.serialization.codecs.RecordCodecBuilder;

import io.github.fabricators_of_create.porting_lib.core.util.PortingLibExtraCodecs;
import io.github.fabricators_of_create.porting_lib.entity.EffectCure;
import io.github.fabricators_of_create.porting_lib.entity.injects.MobEffectInstance$DetailsInjection;
import io.github.fabricators_of_create.porting_lib.entity.injects.MobEffectInstance.DetailsInjection;
import io.netty.buffer.ByteBuf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import net.minecraft.class_1293;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

@Mixin(class_1293.class_9195.class)
public class MobEffectInstance$DetailsMixin implements DetailsInjection {
	@Unique
	private Optional<Set<EffectCure>> port_lib$cures = Optional.empty();

	@Override
	public Optional<Set<EffectCure>> port_lib$getCures() {
		return port_lib$cures;
	}

	@Override
	public void port_lib$setCures(Optional<Set<EffectCure>> cures) {
		port_lib$cures = cures;
	}

	@ModifyReturnValue(method = "method_56672", at = @At("RETURN"))
	private static App<RecordCodecBuilder.Mu<class_1293.class_9195>, class_1293.class_9195> appendEffectCureCodec(App<RecordCodecBuilder.Mu<class_1293.class_9195>, class_1293.class_9195> original, @Local(argsOnly = true) RecordCodecBuilder.Instance<class_1293.class_9195> instance) {
		return instance.group(
				original,
				PortingLibExtraCodecs.setOf(EffectCure.CODEC)
						.optionalFieldOf("porting_lib:cures")
						.forGetter(details -> ((DetailsInjection) (Object) details).port_lib$getCures())
		)
				.apply(instance, (details, cures) -> {
					((DetailsInjection) (Object) details).port_lib$setCures(cures);
					return details;
				});
	}

	@ModifyReturnValue(method = "method_57279", at = @At("RETURN"))
	private static class_9139<ByteBuf, class_1293.class_9195> appendEffectCureStreamCodec(class_9139<ByteBuf, class_1293.class_9195> original) {
		return class_9139.method_56435(
				original,
				d -> d,
				class_9135.method_56382(EffectCure.STREAM_CODEC.method_56433(class_9135.method_56374(HashSet::new))),
				d -> ((DetailsInjection) (Object) d).port_lib$getCures(),
				(details, cures) -> {
					((DetailsInjection) (Object) details).port_lib$setCures(cures);
					return details;
				}
		);
	}
}
