package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1255;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1255.class)
public interface BlockableEventLoopAccessor {
	@Invoker
	CompletableFuture<Void> callSubmitAsync(Runnable task);
}
