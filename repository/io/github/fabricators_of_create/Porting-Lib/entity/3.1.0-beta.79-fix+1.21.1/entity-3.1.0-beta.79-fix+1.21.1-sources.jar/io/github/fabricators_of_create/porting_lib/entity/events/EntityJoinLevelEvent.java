package io.github.fabricators_of_create.porting_lib.entity.events;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.EntityEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2806;
import net.minecraft.class_2818;

/**
 * This event is fired whenever an {@link class_1297} joins a {@link class_1937}.
 * This event is fired whenever an entity is added to a level in {@link class_1937#method_8649(class_1297)}
 * and {@code PersistentEntitySectionManager#addNewEntity(Entity, boolean)}.
 * <p>
 * <strong>Note:</strong> This event may be called before the underlying {@link class_2818} is promoted to {@link class_2806#field_12803}.
 * You will cause chunk loading deadlocks if you do not delay your world interactions.
 * <p>
 * This event is {@linkplain CancellableEvent cancellable}.
 * If the event is canceled, the entity will not be added to the level.
 * <p>
 * This event is fired on both logical sides.
 **/
public class EntityJoinLevelEvent extends EntityEvent implements CancellableEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (final Callback callback : callbacks)
			callback.onEntityJoin(event);
	});

	private final class_1937 level;
	private final boolean loadedFromDisk;

	public EntityJoinLevelEvent(class_1297 entity, class_1937 level) {
		this(entity, level, false);
	}

	public EntityJoinLevelEvent(class_1297 entity, class_1937 level, boolean loadedFromDisk) {
		super(entity);
		this.level = level;
		this.loadedFromDisk = loadedFromDisk;
	}

	/**
	 * {@return the level that the entity is set to join}
	 */
	public class_1937 getLevel() {
		return level;
	}

	/**
	 * @return {@code true} if the entity was loaded from disk, {@code false} otherwise.
	 *         On the {@linkplain EnvType#CLIENT logical client}, this will always return {@code false}.
	 */
	public boolean loadedFromDisk() {
		return loadedFromDisk;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onEntityJoin(this);
	}

	public interface Callback {
		void onEntityJoin(EntityJoinLevelEvent event);
	}
}
