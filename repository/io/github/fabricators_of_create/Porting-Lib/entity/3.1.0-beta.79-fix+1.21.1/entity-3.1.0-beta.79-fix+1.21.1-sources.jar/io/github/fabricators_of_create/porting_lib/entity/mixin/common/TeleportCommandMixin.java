package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_2168;
import net.minecraft.class_2709;
import net.minecraft.class_3143;
import net.minecraft.class_3218;
import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;

import io.github.fabricators_of_create.porting_lib.entity.events.EntityTeleportEvent;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3143.class)
public abstract class TeleportCommandMixin {
	@Inject(method = "performTeleport", at = @At("HEAD"), cancellable = true)
	private static void onEntityTeleportCommand(class_2168 source, class_1297 target, class_3218 world, double x, double y, double z, Set<class_2709> movementFlags, float yaw, float pitch, class_3143.class_3144 facingLocation, CallbackInfo ci) {
		EntityTeleportEvent.TeleportCommand event = EntityHooks.onEntityTeleportCommand(target, x, y, z);
		if (event.isCanceled())
			ci.cancel();
	}
}
