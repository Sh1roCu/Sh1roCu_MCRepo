package io.github.fabricators_of_create.porting_lib.entity.events.tick;

import io.github.fabricators_of_create.porting_lib.core.event.entity.player.PlayerEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_3244;

/**
 * Base class of the two player tick events.
 * <p>
 * These events are separate from {@link EntityTickEvent} due to the semantics of player ticks.
 * On the client, players tick from the usual {@link class_1297#method_5773()} method, but on the server, they rely
 * on {@link class_3222#method_14226()} which is called from {@link class_3244#method_18784()}.
 * <p>
 * Use of these events should only be necessary if you rely on this specific timing.
 *
 * @see PlayerTickEvent.Pre
 * @see PlayerTickEvent.Post
 */
public abstract class PlayerTickEvent extends PlayerEvent {
	protected PlayerTickEvent(class_1657 player) {
		super(player);
	}

	/**
	 * {@link PlayerTickEvent.Pre} is fired once per game tick, per player, before the player performs work for the current tick.
	 * <p>
	 * This event will fire on both the logical server and logical client, for subclasses of {@link class_1657} on their respective sides.
	 * <p>
	 * As such, be sure to check {@link class_1937#method_8608()} before performing any operations.
	 */
	public static class Pre extends PlayerTickEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onPreTick(event);
		});

		public Pre(class_1657 player) {
			super(player);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onPreTick(this);
		}

		public interface Callback {
			void onPreTick(Pre event);
		}
	}

	/**
	 * {@link PlayerTickEvent.Post} is fired once per game tick, per player, after the player performs work for the current tick.
	 * <p>
	 * This event will fire on both the logical server and logical client, for subclasses of {@link class_1657} on their respective sides.
	 * <p>
	 * As such, be sure to check {@link class_1937#method_8608()} before performing any operations.
	 */
	public static class Post extends PlayerTickEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onPostTick(event);
		});

		public Post(class_1657 player) {
			super(player);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onPostTick(this);
		}

		public interface Callback {
			void onPostTick(Post event);
		}
	}
}
