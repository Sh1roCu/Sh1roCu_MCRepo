package io.github.fabricators_of_create.porting_lib.entity.injects;

import io.github.fabricators_of_create.porting_lib.core.util.MixinHelper;
import io.github.fabricators_of_create.porting_lib.entity.IEntityWithComplexSpawn;
import io.github.fabricators_of_create.porting_lib.entity.network.AdvancedAddEntityPayload;
import java.util.Collection;
import java.util.function.Consumer;
import net.minecraft.class_1542;
import net.minecraft.class_2487;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

public interface EntityInjection {
	default class_2487 getCustomData() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default Collection<class_1542> captureDrops() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default Collection<class_1542> captureDrops(Collection<class_1542> value) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	/**
	 * If a rider of this entity can interact with this entity. Should return true on the
	 * ridden entity if so.
	 *
	 * @return if the entity can be interacted with from a rider
	 */
	default boolean canRiderInteract() {
		return false;
	}

	/**
	 * Sends the pairing data to the client.
	 *
	 * @param serverPlayer  The player to send the data to.
	 * @param bundleBuilder Callback to add a custom payload to the packet.
	 */
	default void sendPairingData(class_3222 serverPlayer, Consumer<class_8710> bundleBuilder) {
		if (this instanceof IEntityWithComplexSpawn) {
			bundleBuilder.accept(new AdvancedAddEntityPayload(MixinHelper.cast(this)));
		}
	}
}
