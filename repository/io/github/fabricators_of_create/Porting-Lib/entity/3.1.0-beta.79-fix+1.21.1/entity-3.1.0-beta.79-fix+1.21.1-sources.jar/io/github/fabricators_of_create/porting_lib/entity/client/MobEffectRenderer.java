package io.github.fabricators_of_create.porting_lib.entity.client;

import net.minecraft.class_1293;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_485;

public interface MobEffectRenderer {
	MobEffectRenderer DEFAULT = new MobEffectRenderer() { };

	/**
	 * Queries whether the given effect should be shown in the player's inventory.
	 * <p>
	 * By default, this returns {@code true}.
	 */
	default boolean isVisibleInInventory(class_1293 instance) {
		return true;
	}

	/**
	 * Queries whether the given effect should be shown in the HUD.
	 * <p>
	 * By default, this returns {@code true}.
	 */
	default boolean isVisibleInGui(class_1293 instance) {
		return true;
	}

	/**
	 * Renders the icon of the specified effect in the player's inventory.
	 * This can be used to render icons from your own texture sheet.
	 *
	 * @param instance     The effect instance
	 * @param screen       The effect-rendering screen
	 * @param guiGraphics  The gui graphics
	 * @param x            The x coordinate
	 * @param y            The y coordinate
	 * @param blitOffset   The blit offset
	 * @return true to prevent default rendering, false otherwise
	 */
	default boolean renderInventoryIcon(class_1293 instance, class_485<?> screen, class_332 guiGraphics, int x, int y, int blitOffset) {
		return false;
	}

	/**
	 * Renders the text of the specified effect in the player's inventory.
	 *
	 * @param instance     The effect instance
	 * @param screen       The effect-rendering screen
	 * @param guiGraphics  The gui graphics
	 * @param x            The x coordinate
	 * @param y            The y coordinate
	 * @param blitOffset   The blit offset
	 * @return true to prevent default rendering, false otherwise
	 */
	default boolean renderInventoryText(class_1293 instance, class_485<?> screen, class_332 guiGraphics, int x, int y, int blitOffset) {
		return false;
	}

	/**
	 * Renders the icon of the specified effect on the player's HUD.
	 * This can be used to render icons from your own texture sheet.
	 *
	 * @param instance    The effect instance
	 * @param gui         The gui
	 * @param guiGraphics The gui graphics
	 * @param x           The x coordinate
	 * @param y           The y coordinate
	 * @param z           The z depth
	 * @param alpha       The alpha value. Blinks when the effect is about to run out
	 * @return true to prevent default rendering, false otherwise
	 */
	default boolean renderGuiIcon(class_1293 instance, class_329 gui, class_332 guiGraphics, int x, int y, float z, float alpha) {
		return false;
	}
}
