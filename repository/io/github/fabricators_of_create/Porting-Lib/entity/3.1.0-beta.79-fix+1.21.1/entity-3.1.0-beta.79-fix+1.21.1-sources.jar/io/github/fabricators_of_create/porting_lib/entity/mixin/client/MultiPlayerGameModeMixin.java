package io.github.fabricators_of_create.porting_lib.entity.mixin.client;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import io.github.fabricators_of_create.porting_lib.entity.events.player.PlayerInteractEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.player.PlayerInteractEvent.LeftClickBlock;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_2886;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.apache.commons.lang3.mutable.MutableObject;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Environment(EnvType.CLIENT)
@Mixin(class_636.class)
public class MultiPlayerGameModeMixin {
	@Shadow
	@Final
	private class_310 minecraft;

	@WrapOperation(method = "interactAt", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;interactAt(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResult;"))
	public class_1269 onEntityInteractAt(class_1297 instance, class_1657 player, class_243 vec3, class_1268 hand, Operation<class_1269> original, class_1657 p_105231_, class_1297 p_105232_, class_3966 p_105233_) {
		class_1269 cancelResult = EntityHooks.onInteractEntityAt(player, instance, p_105233_, hand);
		if (cancelResult != null) return cancelResult;
		return original.call(instance, player, vec3, hand);
	}

	@WrapWithCondition(method = "method_41936", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/MultiPlayerGameMode;destroyBlock(Lnet/minecraft/core/BlockPos;)Z"))
	private boolean wrapBlockLeftClick(class_636 instance, class_2338 pLoc, class_2338 other, class_2350 pFace, int i) {
		return !EntityHooks.onLeftClickBlock(this.minecraft.field_1724, pLoc, pFace, class_2846.class_2847.field_12968).isCanceled();
	}

	@WrapWithCondition(method = "method_41935", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/MultiPlayerGameMode;destroyBlock(Lnet/minecraft/core/BlockPos;)Z"))
	private boolean continueWrapBlockLeftClick(class_636 instance, class_2338 pLoc, class_2338 other, class_2350 pFace, int i) {
		return !EntityHooks.onLeftClickBlock(this.minecraft.field_1724, pLoc, pFace, class_2846.class_2847.field_12968).isCanceled();
	}

	@Inject(method = "continueDestroyBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/tutorial/Tutorial;onDestroyBlock(Lnet/minecraft/client/multiplayer/ClientLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;F)V", ordinal = 1, shift = At.Shift.AFTER), cancellable = true)
	private void continueLeftClickBlock(class_2338 pPosBlock, class_2350 pDirectionFacing, CallbackInfoReturnable<Boolean> cir) {
		if (EntityHooks.onClientMineHold(this.minecraft.field_1724, pPosBlock, pDirectionFacing).getUseItem() == TriState.FALSE)
			cir.setReturnValue(true);
	}

	@Unique
	private final ThreadLocal<PlayerInteractEvent.LeftClickBlock> capturedEvent = new ThreadLocal<>();

	@Inject(method = "startDestroyBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/ClientLevel;getBlockState(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;", ordinal = 1))
	public void port_lib$startDestroy(class_2338 loc, class_2350 face, CallbackInfoReturnable<Boolean> cir) {
		var e = EntityHooks.onLeftClickBlock(minecraft.field_1724, loc, face, class_2846.class_2847.field_12968);
		capturedEvent.set(e);
	}

	@WrapWithCondition(method = "method_41930", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;attack(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V"))
	private boolean cancelLeftClickAttack(class_2680 blockState, class_1937 level, class_2338 blockPos, class_1657 player) {
		return capturedEvent.get().getUseBlock() != TriState.FALSE;
	}

	@Inject(method = "method_41930", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getDestroyProgress(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)F"), cancellable = true)
	private void cancelUsePacket(class_2680 blockState, class_2338 blockPos, class_2350 direction, int i, CallbackInfoReturnable<class_2596<?>> cir) {
		if (capturedEvent.get().getUseItem() == TriState.FALSE)
			cir.setReturnValue(new class_2846(class_2846.class_2847.field_12968, blockPos, direction, i));
	}

	@Inject(method = "method_41929", at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/item/ItemStack;use(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder;"
	), cancellable = true)
	private void onItemRightClick(class_1268 hand, class_1657 player, MutableObject<class_1269> result, int sequence, CallbackInfoReturnable<class_2596<?>> cir, @Local class_2886 packet) {
		class_1269 cancelResult = EntityHooks.onItemRightClick(player, hand);
		if (cancelResult != null) {
			result.setValue(cancelResult);
			cir.setReturnValue(packet);
		}
	}

	@Inject(method = "method_41929", at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/entity/player/Player;setItemInHand(Lnet/minecraft/world/InteractionHand;Lnet/minecraft/world/item/ItemStack;)V",
			shift = At.Shift.AFTER
	))
	private void onPlayerDestroyItem(class_1268 hand, class_1657 player, MutableObject<class_1269> result, int sequence, CallbackInfoReturnable<class_2596> cir, @Local(index = 6) class_1799 destroyed, @Local(index = 8) class_1799 item) {
		if (item.method_7960())
			EntityHooks.onPlayerDestroyItem(player, destroyed, hand);
	}

	@Inject(method = "performUseItemOn", at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/player/LocalPlayer;getItemInHand(Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/item/ItemStack;",
			ordinal = 0
	), cancellable = true)
	private void onRightClickBlock(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir, @Local class_2338 pos) {
		PlayerInteractEvent.RightClickBlock event = EntityHooks.onRightClickBlock(player, hand, pos, hitResult);
		if (event.isCanceled()) {
			cir.setReturnValue(event.getCancellationResult());
		}
	}
}
