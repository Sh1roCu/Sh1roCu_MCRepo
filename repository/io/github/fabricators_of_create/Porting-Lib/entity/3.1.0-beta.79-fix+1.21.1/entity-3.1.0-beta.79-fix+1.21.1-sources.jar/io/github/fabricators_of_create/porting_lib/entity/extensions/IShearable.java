package io.github.fabricators_of_create.porting_lib.entity.extensions;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1438;
import net.minecraft.class_1473;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3419;
import net.minecraft.class_5147;
import net.minecraft.class_5819;
import net.minecraft.class_9254;
import org.jetbrains.annotations.Nullable;

/**
 * This interfaces allows shears (modded & vanilla) and {@linkplain class_1297 entities} (modded & vanilla) to cooperate
 * without needing advance knowledge of each other.
 * <p>
 * In the future, this system may function for implementations on {@link class_2248}s as well.
 *
 * TODO: Implement support for {@link class_2248} or remove default implementations from vanilla block classes.
 */
public interface IShearable {
	/**
	 * Checks if this object can be sheared.
	 * <p>
	 * For example, Sheep return false when they have no wool.
	 *
	 * @param item  The shear tool that is being used, may be empty.
	 * @param level The current level.
	 * @param pos   The block position of this object (if this is an entity, the value of {@link class_1297#method_24515()}.
	 * @return If this is shearable, and {@link #onSheared} may be called.
	 */
	default boolean isShearable(@Nullable class_1657 player, class_1799 item, class_1937 level, class_2338 pos) {
		// Default to checking readyForShearing if we are the vanilla shearable interface, and if we aren't assume a default of true
		return !(this instanceof class_5147 shearable) || shearable.method_27072();
	}

	/**
	 * Shears this object. This function is called on both sides, and is responsible for performing any and all actions that happen when sheared, except spawning drops.
	 * <p>
	 * Drops that are spawned as a result of being sheared should be returned from this method, and will be spawned on the server using {@link #spawnShearedDrop}.
	 * <p>
	 * {@linkplain class_1297 Entities} may respect their internal position values instead of relying on the {@code pos} parameter.
	 *
	 * @param item  The shear tool that is being used, may be empty.
	 * @param level The current level.
	 * @param pos   The block position of this object (if this is an entity, the value of {@link class_1297#method_24515()}.
	 * @return A list holding all dropped items resulting from the shear operation, or an empty list if nothing dropped.
	 */
	@SuppressWarnings("deprecation") // Expected call to deprecated vanilla Shearable#shear
	default List<class_1799> onSheared(@Nullable class_1657 player, class_1799 item, class_1937 level, class_2338 pos) {
		if (this instanceof class_1309 entity && this instanceof class_5147 shearable) {
			if (!level.field_9236) {
				Collection<class_1542> previous = entity.captureDrops(new ArrayList<>());
				shearable.method_6636(player == null ? class_3419.field_15245 : class_3419.field_15248);
				return entity.captureDrops(previous).stream().map(class_1542::method_6983).toList();
			}
		}
		return Collections.emptyList();
	}

	/**
	 * Performs the logic used to drop a shear result into the world at the correct position and with the proper movement.
	 * <br>
	 * {@linkplain class_1297 Entities} may respect their internal position values instead of relying on the {@code pos} parameter.
	 *
	 * @param level The current level.
	 * @param pos   The block position of this object (if this is an entity, the value of {@link class_1297#method_24515()}.
	 * @param drop  The stack to drop, from the list of drops returned by {@link #onSheared}.
	 */
	default void spawnShearedDrop(class_1937 level, class_2338 pos, class_1799 drop) {
		if (this instanceof class_1473 golem) {
			// SnowGolem#shear uses spawnAtLocation(..., this.getEyeHeight());
			golem.method_5699(drop, golem.method_5751());
		} else if (this instanceof class_9254 bogged) {
			// Bogged#spawnShearedMushrooms uses spawnAtLocation(..., this.getBbHeight());
			bogged.method_5699(drop, bogged.method_17682());
		} else if (this instanceof class_1438 cow) {
			// We patch Mooshrooms from using addFreshEntity to spawnAtLocation to spawnAtLocation to capture the drops.
			// In case a mod is also capturing drops, we also replicate that logic here.
			class_1542 itemEntity = cow.method_5699(drop, cow.method_17682());
			if (itemEntity != null) {
				itemEntity.method_6975();
			}
		} else if (this instanceof class_1297 entity) {
			// Everything else uses the "default" rules invented by Sheep#shear, which uses a y-offset of 1 and these random delta movement values.
			class_1542 itemEntity = entity.method_5699(drop, 1);
			if (itemEntity != null) {
				class_5819 rand = entity.method_59922();
				class_243 newDelta = itemEntity.method_18798().method_1031(
						(rand.method_43057() - rand.method_43057()) * 0.1F,
						rand.method_43057() * 0.05F,
						(rand.method_43057() - rand.method_43057()) * 0.1F);
				itemEntity.method_18799(newDelta);
			}
		} else {
			// If we aren't an entity, fallback to spawning the item at the given position.
			level.method_8649(new class_1542(level, pos.method_10263(), pos.method_10264(), pos.method_10260(), drop));
		}
	}
}
