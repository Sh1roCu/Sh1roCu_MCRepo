package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.entity.PartEntity;
import io.github.fabricators_of_create.porting_lib.entity.injects.LevelInjection;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_5575;

@Mixin(value = class_1937.class, priority = 1100) // need to apply after lithium
public class LevelMixin implements LevelInjection {
	@Unique
	final Int2ObjectMap<PartEntity<?>> port_lib$multiparts = new Int2ObjectOpenHashMap<>();

	@Inject(
			method = "getEntities(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Ljava/util/function/Predicate;)Ljava/util/List;",
			at = @At("TAIL")
	)
	private void appendPartEntitiesPredicate(@Nullable class_1297 entity, class_238 area, Predicate<? super class_1297> predicate, CallbackInfoReturnable<List<class_1297>> cir, @Local List<class_1297> list) {
		for (PartEntity<?> p : this.getPartEntities()) {
			if (p != entity && p.method_5829().method_994(area) && predicate.test(p)) {
				list.add(p);
			}
		}
	}

	@Inject(
			method = "getEntities(Lnet/minecraft/world/level/entity/EntityTypeTest;Lnet/minecraft/world/phys/AABB;Ljava/util/function/Predicate;)Ljava/util/List;",
			at = @At("TAIL")
	)
	private <T extends class_1297> void appendPartEntitiesTypeTest(class_5575<class_1297, T> test, class_238 area, Predicate<? super T> predicate, CallbackInfoReturnable<List<T>> cir, @Local List<class_1297> list) {
		for (PartEntity<?> p : this.getPartEntities()) {
			T t = test.method_31796(p);
			if (t != null && t.method_5829().method_994(area) && predicate.test(t)) {
				list.add(t);
			}
		}
	}

	@Override
	public Int2ObjectMap<PartEntity<?>> getPartEntityMap() {
		return port_lib$multiparts;
	}
}
