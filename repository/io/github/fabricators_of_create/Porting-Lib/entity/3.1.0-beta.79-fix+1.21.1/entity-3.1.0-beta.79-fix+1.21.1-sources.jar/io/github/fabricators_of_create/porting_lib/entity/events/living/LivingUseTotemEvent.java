package io.github.fabricators_of_create.porting_lib.entity.events.living;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.living.LivingEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

/**
 * Fired when an Entity attempts to use a totem to prevent its death.
 *
 * <p>This event is {@linkplain CancellableEvent cancellable}.
 * If this event is cancelled, the totem will not prevent the entity's death.</p>
 *
 * <p>
 * This event is fired on the  {@linkplain EnvType#SERVER logical server}.
 * </p>
 */
public class LivingUseTotemEvent extends LivingEvent implements CancellableEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (final Callback callback : callbacks)
			callback.onUseTotem(event);
	});

	private final class_1282 source;
	private final class_1799 totem;
	private final class_1268 hand;

	public LivingUseTotemEvent(class_1309 entity, class_1282 source, class_1799 totem, class_1268 hand) {
		super(entity);
		this.source = source;
		this.totem = totem;
		this.hand = hand;
	}

	/**
	 * {@return the damage source that caused the entity to die}
	 */
	public class_1282 getSource() {
		return source;
	}

	/**
	 * {@return the totem of undying being used from the entity's inventory}
	 */
	public class_1799 getTotem() {
		return totem;
	}

	/**
	 * {@return the hand holding the totem}
	 */
	public class_1268 getHandHolding() {
		return hand;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onUseTotem(this);
	}

	public interface Callback {
		void onUseTotem(LivingUseTotemEvent event);
	}
}
