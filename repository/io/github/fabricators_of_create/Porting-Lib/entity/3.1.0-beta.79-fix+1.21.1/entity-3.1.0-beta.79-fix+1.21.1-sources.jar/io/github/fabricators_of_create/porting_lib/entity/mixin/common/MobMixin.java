package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.core.util.MixinHelper;
import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;

import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingChangeTargetEvent;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1308.class)
public abstract class MobMixin {
	@Shadow
	@Nullable
	private class_1309 target;

	@ModifyVariable(method = "setTarget", at = @At("HEAD"), argsOnly = true)
	private class_1309 port_lib$onChangeTarget(class_1309 value) {
		LivingChangeTargetEvent changeTargetEvent = EntityHooks.onLivingChangeTarget(MixinHelper.cast(this), value, LivingChangeTargetEvent.LivingTargetType.MOB_TARGET);
		if(!changeTargetEvent.isCanceled()) {
			return changeTargetEvent.getNewTarget();
		}
		return this.target;
	}
}
