package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.extensions.IShearable;
import net.minecraft.class_5147;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_5147.class)
public interface ShearableMixin extends IShearable {
}
