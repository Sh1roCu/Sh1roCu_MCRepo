package io.github.fabricators_of_create.porting_lib.entity.events;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.EntityEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_5576;

/**
 * This event is fired whenever an {@link class_1297} leaves a {@link class_1937}.
 * This event is fired whenever an entity is removed from the level in {@link class_5576#method_31797(Object)}.
 * <p>
 * This event is not {@linkplain CancellableEvent cancellable} and does not have a result.
 * <p>
 * This event is fired on both logical sides.
 **/
public class EntityLeaveLevelEvent extends EntityEvent {
	public static final Event<EntityLeaveLevelCallback> EVENT = EventFactory.createArrayBacked(EntityLeaveLevelCallback.class, callbacks -> event -> {
		for (EntityLeaveLevelCallback callback : callbacks) {
			callback.onEntityLeaveLevel(event);
		}
	});

	private final class_1937 level;

	public EntityLeaveLevelEvent(class_1297 entity, class_1937 level) {
		super(entity);
		this.level = level;
	}

	/**
	 * {@return the level the entity is set to leave}
	 */
	public class_1937 getLevel() {
		return level;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onEntityLeaveLevel(this);
	}

	@FunctionalInterface
	public interface EntityLeaveLevelCallback {
		void onEntityLeaveLevel(EntityLeaveLevelEvent event);
	}
}

