package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import com.google.common.collect.Sets;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import io.github.fabricators_of_create.porting_lib.core.util.MixinHelper;
import io.github.fabricators_of_create.porting_lib.entity.EffectCure;
import io.github.fabricators_of_create.porting_lib.entity.injects.MobEffectInstance$DetailsInjection;
import io.github.fabricators_of_create.porting_lib.entity.injects.MobEffectInstance.DetailsInjection;
import io.github.fabricators_of_create.porting_lib.entity.injects.MobEffectInstanceInjection;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;
import java.util.Set;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_6880;

@Mixin(class_1293.class)
public class MobEffectInstanceMixin implements MobEffectInstanceInjection {
	@Shadow
	@Final
	private class_6880<class_1291> effect;

	@Unique
	private final Set<EffectCure> porting_lib$cures = Sets.newIdentityHashSet();

	/**
	 * {@return the {@link EffectCure}s which can cure the {@link class_1291} held by this {@link class_1293}}
	 */
	public Set<EffectCure> getCures() {
		return porting_lib$cures;
	}

	@Inject(method = "<init>(Lnet/minecraft/core/Holder;IIZZZLnet/minecraft/world/effect/MobEffectInstance;)V", at = @At("TAIL"))
	private void addEffects(class_6880<class_1291> holder, int duration, int amplifier, boolean ambient, boolean visible, boolean showIcon, class_1293 hiddenEffect, CallbackInfo ci) {
		this.effect.comp_349().fillEffectCures(this.porting_lib$cures, MixinHelper.cast(this));
	}

	@Inject(method = "<init>(Lnet/minecraft/core/Holder;Lnet/minecraft/world/effect/MobEffectInstance$Details;)V", at = @At("TAIL"))
	private void loadEffects(class_6880<class_1291> effect, class_1293.class_9195 details, CallbackInfo ci) {
		Set<EffectCure> cures = getCures();
		cures.clear();
		((DetailsInjection) (Object) details).port_lib$getCures().ifPresent(cures::addAll);
	}

	@ModifyReturnValue(method = "asDetails", at = @At("RETURN"))
	private class_1293.class_9195 addEffectsToDetails(class_1293.class_9195 original) {
		((DetailsInjection) (Object) original).port_lib$setCures(Optional.of(getCures()).filter(cures -> !cures.isEmpty()));
		return original;
	}

	@Inject(method = "setDetailsFrom", at = @At("TAIL"))
	private void copyEffects(class_1293 effectInstance, CallbackInfo ci) {
		getCures().clear();
		getCures().addAll(effectInstance.getCures());
	}
}
