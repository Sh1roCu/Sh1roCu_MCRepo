package io.github.fabricators_of_create.porting_lib.entity.events.living;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.living.LivingEvent;
import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1282;
import net.minecraft.class_1309;

/**
 * LivingHurtEvent is fired when an Entity is set to be hurt. <br>
 * This event is fired whenever an Entity is hurt in
 * {@code LivingEntity#actuallyHurt(DamageSource, float)} and
 * {@code Player#actuallyHurt(DamageSource, float)}.<br>
 * <br>
 * This event is fired via the {@link EntityHooks#onLivingHurt(class_1309, class_1282, float)}.<br>
 * <br>
 * {@link #source} contains the DamageSource that caused this Entity to be hurt. <br>
 * {@link #amount} contains the amount of damage dealt to the Entity that was hurt. <br>
 * <br>
 * This event is {@link CancellableEvent}.<br>
 * If this event is canceled, the Entity is not hurt.<br>
 *
 * @see LivingDamageEvent
 **/
public class LivingHurtEvent extends LivingEvent implements CancellableEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (final Callback callback : callbacks)
			callback.onLivingHurt(event);
	});

	private final class_1282 source;
	private float amount;

	public LivingHurtEvent(class_1309 entity, class_1282 source, float amount) {
		super(entity);
		this.source = source;
		this.amount = amount;
	}

	public class_1282 getSource() {
		return source;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onLivingHurt(this);
	}

	public interface Callback {
		void onLivingHurt(LivingHurtEvent event);
	}
}
