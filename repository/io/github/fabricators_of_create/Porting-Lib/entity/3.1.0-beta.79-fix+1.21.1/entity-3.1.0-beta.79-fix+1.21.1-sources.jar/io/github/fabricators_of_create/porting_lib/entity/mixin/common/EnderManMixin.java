package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.llamalad7.mixinextras.sugar.Share;

import com.llamalad7.mixinextras.sugar.ref.LocalRef;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import io.github.fabricators_of_create.porting_lib.entity.events.EntityTeleportEvent;
import net.minecraft.class_1299;
import net.minecraft.class_1560;
import net.minecraft.class_1588;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1560.class)
public abstract class EnderManMixin extends class_1588 {
	protected EnderManMixin(class_1299<? extends class_1588> entityType, class_1937 level) {
		super(entityType, level);
	}

	@WrapOperation(method = "teleport(DDD)Z", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/monster/EnderMan;randomTeleport(DDDZ)Z"))
	private boolean onEnderTeleport(class_1560 instance, double x, double y, double z, boolean fireEvent, Operation<Boolean> original) {
		EntityTeleportEvent.EnderEntity event = EntityHooks.onEnderTeleport(instance, x, y, z);
		if (!event.isCanceled())
			return original.call(instance, event.getTargetX(), event.getTargetY(), event.getTargetZ(), fireEvent);
		return false;
	}
}
