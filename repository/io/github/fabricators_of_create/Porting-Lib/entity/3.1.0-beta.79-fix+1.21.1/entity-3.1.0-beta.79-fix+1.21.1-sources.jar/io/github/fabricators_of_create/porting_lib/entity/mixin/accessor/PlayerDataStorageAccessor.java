package io.github.fabricators_of_create.porting_lib.entity.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.io.File;
import net.minecraft.class_29;

@Mixin(class_29.class)
public interface PlayerDataStorageAccessor {
	@Accessor
	File getPlayerDir();
}
