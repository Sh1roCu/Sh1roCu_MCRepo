package io.github.fabricators_of_create.porting_lib.entity.events.living;

import java.util.Collection;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.living.LivingEvent;
import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1542;

/**
 * LivingDropsEvent is fired when an Entity's death causes dropped items to appear.<br>
 * This event is fired whenever an Entity dies and drops items in
 * {@link class_1309#method_6078(class_1282)}.<br>
 * <br>
 * This event is fired via the {@link EntityHooks#onLivingDrops(class_1309, class_1282, Collection, boolean)} .<br>
 * <br>
 * {@link #source} contains the DamageSource that caused the drop to occur.<br>
 * {@link #drops} contains the ArrayList of EntityItems that will be dropped.<br>
 * {@link #recentlyHit} determines whether the Entity doing the drop has recently been damaged.<br>
 * <br>
 * This event is {@link CancellableEvent}.<br>
 * If this event is canceled, the Entity does not drop anything.<br>
 **/
public class LivingDropsEvent extends LivingEvent implements CancellableEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (final Callback callback : callbacks)
			callback.onLivingDrop(event);
	});

	private final class_1282 source;
	private final Collection<class_1542> drops;
	private final boolean recentlyHit;

	public LivingDropsEvent(class_1309 entity, class_1282 source, Collection<class_1542> drops, boolean recentlyHit) {
		super(entity);
		this.source = source;
		this.drops = drops;
		this.recentlyHit = recentlyHit;
	}

	public class_1282 getSource() {
		return source;
	}

	public Collection<class_1542> getDrops() {
		return drops;
	}

	public boolean isRecentlyHit() {
		return recentlyHit;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onLivingDrop(this);
	}

	public interface Callback {
		void onLivingDrop(LivingDropsEvent event);
	}
}
