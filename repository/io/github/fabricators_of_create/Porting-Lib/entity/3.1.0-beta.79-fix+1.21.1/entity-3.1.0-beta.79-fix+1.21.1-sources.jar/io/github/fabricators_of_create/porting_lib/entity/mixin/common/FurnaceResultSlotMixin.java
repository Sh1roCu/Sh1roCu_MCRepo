package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import net.minecraft.class_1657;
import net.minecraft.class_1719;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1719.class)
public class FurnaceResultSlotMixin {
	@Shadow
	@Final
	private class_1657 player;

	@Inject(method = "checkTakeAchievements", at = @At("TAIL"))
	private void onItemSmelted(class_1799 itemStack, CallbackInfo ci) {
		EntityHooks.firePlayerSmeltedEvent(this.player, itemStack);
	}
}
