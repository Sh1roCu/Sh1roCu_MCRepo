package io.github.fabricators_of_create.porting_lib.entity.events.player;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.player.PlayerEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

/**
 * AttackEntityEvent is fired when a player attacks an Entity.<br>
 * This event is fired whenever a player attacks an Entity in
 * {@link class_1657#method_7324(class_1297)}.<br>
 * <br>
 * {@link #target} contains the Entity that was damaged by the player. <br>
 * <br>
 * This event is {@link CancellableEvent}.<br>
 * If this event is canceled, the player does not attack the Entity.<br>
 **/
public class AttackEntityEvent extends PlayerEvent implements CancellableEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (final Callback callback : callbacks)
			callback.onAttackEntity(event);
	});

	private final class_1297 target;

	public AttackEntityEvent(class_1657 player, class_1297 target) {
		super(player);
		this.target = target;
	}

	public class_1297 getTarget() {
		return target;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onAttackEntity(this);
	}

	public interface Callback {
		void onAttackEntity(AttackEntityEvent event);
	}
}
