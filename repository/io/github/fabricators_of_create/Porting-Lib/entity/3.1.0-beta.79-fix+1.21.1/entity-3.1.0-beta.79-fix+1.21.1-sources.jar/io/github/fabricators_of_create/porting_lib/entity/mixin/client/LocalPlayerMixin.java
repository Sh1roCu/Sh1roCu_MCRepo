package io.github.fabricators_of_create.porting_lib.entity.mixin.client;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_746.class)
public abstract class LocalPlayerMixin {
	@Inject(method = "hurt", at = @At("HEAD"))
	public void port_lib$attackEvent(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
		EntityHooks.onPlayerAttack((class_1309) (Object) this, source, amount);
	}
}
