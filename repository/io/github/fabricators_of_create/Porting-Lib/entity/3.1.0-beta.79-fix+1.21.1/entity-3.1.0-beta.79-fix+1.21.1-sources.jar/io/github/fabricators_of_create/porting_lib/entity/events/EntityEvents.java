package io.github.fabricators_of_create.porting_lib.entity.events;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.EntityEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_4076;

public final class EntityEvents {
	private EntityEvents() {}

	/**
	 * EntityConstructing is fired when an Entity is being created. <br>
	 * This event is fired within the constructor of the Entity.<br>
	 * <br>
	 * This event is not {@link CancellableEvent}.<br>
	 **/
	public static class EntityConstructing extends EntityEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onConstructing(event);
		});

		public EntityConstructing(class_1297 entity) {
			super(entity);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onConstructing(this);
		}

		public interface Callback {
			void onConstructing(EntityConstructing event);
		}
	}

	/**
	 * This event is fired on server and client after an Entity has entered a different section. <br>
	 * Sections are 16x16x16 block grids of the world.<br>
	 * This event does not fire when a new entity is spawned, only when an entity moves from one section to another one.
	 * Use {@link EntityJoinLevelEvent} to detect new entities joining the world.
	 * <br>
	 * This event is not {@link CancellableEvent}.<br>
	 **/
	public static class EnteringSection extends EntityEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onEnteringSection(event);
		});

		private final long packedOldPos;
		private final long packedNewPos;

		public EnteringSection(class_1297 entity, long packedOldPos, long packedNewPos) {
			super(entity);
			this.packedOldPos = packedOldPos;
			this.packedNewPos = packedNewPos;
		}

		/**
		 * A packed version of the old section's position. This is to be used with the various methods in {@link class_4076},
		 * such as {@link class_4076#method_18677(long)} or {@link class_4076#method_18686(long)} to avoid allocation.
		 *
		 * @return the packed position of the old section
		 */
		public long getPackedOldPos() {
			return packedOldPos;
		}

		/**
		 * A packed version of the new section's position. This is to be used with the various methods in {@link class_4076},
		 * such as {@link class_4076#method_18677(long)} or {@link class_4076#method_18686(long)} to avoid allocation.
		 *
		 * @return the packed position of the new section
		 */
		public long getPackedNewPos() {
			return packedNewPos;
		}

		/**
		 * @return the position of the old section
		 */
		public class_4076 getOldPos() {
			return class_4076.method_18677(packedOldPos);
		}

		/**
		 * @return the position of the new section
		 */
		public class_4076 getNewPos() {
			return class_4076.method_18677(packedNewPos);
		}

		/**
		 * Whether the chunk has changed as part of this event. If this method returns false, only the Y position of the
		 * section has changed.
		 */
		public boolean didChunkChange() {
			return class_4076.method_18686(packedOldPos) != class_4076.method_18686(packedNewPos) || class_4076.method_18690(packedOldPos) != class_4076.method_18690(packedNewPos);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onEnteringSection(this);
		}

		public interface Callback {
			void onEnteringSection(EnteringSection event);
		}
	}

	/**
	 * This event is fired whenever the {@link class_4050} changes, and in a few other hardcoded scenarios.<br>
	 * CAREFUL: This is also fired in the Entity constructor. Therefore the entity(subclass) might not be fully initialized. Check Entity#isAddedToWorld() or !Entity#firstUpdate.<br>
	 * If you change the player's size, you probably want to set the eye height accordingly as well<br>
	 **/
	public static class Size extends EntityEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onEntitySizeChange(event);
		});

		private final class_4050 pose;
		private final class_4048 oldSize;
		private class_4048 newSize;
		private final float oldEyeHeight;
		private float newEyeHeight;

		public Size(class_1297 entity, class_4050 pose, class_4048 size, float defaultEyeHeight) {
			this(entity, pose, size, size, defaultEyeHeight, defaultEyeHeight);
		}

		public Size(class_1297 entity, class_4050 pose, class_4048 oldSize, class_4048 newSize, float oldEyeHeight, float newEyeHeight) {
			super(entity);
			this.pose = pose;
			this.oldSize = oldSize;
			this.newSize = newSize;
			this.oldEyeHeight = oldEyeHeight;
			this.newEyeHeight = newEyeHeight;
		}

		public class_4050 getPose() {
			return pose;
		}

		public class_4048 getOldSize() {
			return oldSize;
		}

		public class_4048 getNewSize() {
			return newSize;
		}

		public void setNewSize(class_4048 size) {
			setNewSize(size, false);
		}

		/**
		 * Set the new size of the entity. Set updateEyeHeight to true to also update the eye height according to the new size.
		 */
		public void setNewSize(class_4048 size, boolean updateEyeHeight) {
			this.newSize = size;
			if (updateEyeHeight) {
				this.newEyeHeight = this.getEntity().method_18381(this.getPose());
			}
		}

		public float getOldEyeHeight() {
			return oldEyeHeight;
		}

		public float getNewEyeHeight() {
			return newEyeHeight;
		}

		public void setNewEyeHeight(float newHeight) {
			this.newEyeHeight = newHeight;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onEntitySizeChange(this);
		}

		public interface Callback {
			void onEntitySizeChange(Size event);
		}
	}
}
