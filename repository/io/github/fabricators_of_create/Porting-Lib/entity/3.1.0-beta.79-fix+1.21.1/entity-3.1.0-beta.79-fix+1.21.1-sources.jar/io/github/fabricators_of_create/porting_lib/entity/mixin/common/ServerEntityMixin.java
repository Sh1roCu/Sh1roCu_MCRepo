package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_2596;
import net.minecraft.class_3222;
import net.minecraft.class_3231;

@Mixin(class_3231.class)
public abstract class ServerEntityMixin {
	@Shadow
	@Final
	private class_1297 entity;

	@Inject(method = "addPairing", at = @At("TAIL"))
	private void addPairing(class_3222 player, CallbackInfo ci) {
		EntityHooks.onStartEntityTracking(this.entity, player);
	}

	@Inject(method = "removePairing", at = @At("TAIL"))
	private void onStopEntityTracking(class_3222 player, CallbackInfo ci) {
		EntityHooks.onStopEntityTracking(this.entity, player);
	}

	@Inject(method = "sendPairingData", at = @At(
			value = "INVOKE",
			target = "Ljava/util/function/Consumer;accept(Ljava/lang/Object;)V",
			shift = At.Shift.AFTER,
			ordinal = 0
	))
	private void sendComplexSpawnData(class_3222 serverPlayer, Consumer<class_2596<?>> consumer, CallbackInfo ci) {
		this.entity.sendPairingData(serverPlayer, customPacketPayload -> consumer.accept(new ClientboundCustomPayloadPacket(customPacketPayload)));
	}
}
