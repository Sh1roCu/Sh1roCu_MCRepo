package io.github.fabricators_of_create.porting_lib.entity.events;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.EntityEvent;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1684;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * EntityTeleportEvent is fired when an event involving any teleportation of an Entity occurs.<br>
 * If a method utilizes this {@link BaseEvent} as its parameter, the method will
 * receive every child event of this class.<br>
 * <br>
 * {@link #getTarget()} contains the target destination.<br>
 * {@link #getPrev()} contains the entity's current position.<br>
 * <br>
 **/
public abstract class EntityTeleportEvent extends EntityEvent implements CancellableEvent {
	protected double targetX;
	protected double targetY;
	protected double targetZ;

	public EntityTeleportEvent(class_1297 entity, double targetX, double targetY, double targetZ) {
		super(entity);
		this.targetX = targetX;
		this.targetY = targetY;
		this.targetZ = targetZ;
	}

	public double getTargetX() {
		return targetX;
	}

	public void setTargetX(double targetX) {
		this.targetX = targetX;
	}

	public double getTargetY() {
		return targetY;
	}

	public void setTargetY(double targetY) {
		this.targetY = targetY;
	}

	public double getTargetZ() {
		return targetZ;
	}

	public void setTargetZ(double targetZ) {
		this.targetZ = targetZ;
	}

	public class_243 getTarget() {
		return new class_243(this.targetX, this.targetY, this.targetZ);
	}

	public double getPrevX() {
		return getEntity().method_23317();
	}

	public double getPrevY() {
		return getEntity().method_23318();
	}

	public double getPrevZ() {
		return getEntity().method_23321();
	}

	public class_243 getPrev() {
		return getEntity().method_19538();
	}

	/**
	 * EntityTeleportEvent.TeleportCommand is fired before a living entity is teleported
	 * from use of {@link net.minecraft.class_3143}.
	 * <br>
	 * This event is {@link CancellableEvent}.<br>
	 * If the event is not canceled, the entity will be teleported.
	 * <br>
	 * This event is only fired on the {@link EnvType#SERVER} side.<br>
	 * <br>
	 * If this event is canceled, the entity will not be teleported.
	 */
	public static class TeleportCommand extends EntityTeleportEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onTeleportCommand(event);
		});

		public TeleportCommand(class_1297 entity, double targetX, double targetY, double targetZ) {
			super(entity, targetX, targetY, targetZ);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onTeleportCommand(this);
		}

		public interface Callback {
			void onTeleportCommand(TeleportCommand event);
		}
	}

	/**
	 * EntityTeleportEvent.SpreadPlayersCommand is fired before a living entity is teleported
	 * from use of {@link net.minecraft.class_3131}.
	 * <br>
	 * This event is {@link CancellableEvent}.<br>
	 * If the event is not canceled, the entity will be teleported.
	 * <br>
	 * This event is only fired on the {@link EnvType#SERVER} side.<br>
	 * <br>
	 * If this event is canceled, the entity will not be teleported.
	 */
	public static class SpreadPlayersCommand extends EntityTeleportEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onSpreadPlayersCommand(event);
		});

		public SpreadPlayersCommand(class_1297 entity, double targetX, double targetY, double targetZ) {
			super(entity, targetX, targetY, targetZ);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onSpreadPlayersCommand(this);
		}

		public interface Callback {
			void onSpreadPlayersCommand(SpreadPlayersCommand event);
		}
	}

	/**
	 * EntityTeleportEvent.EnderEntity is fired before an Enderman or Shulker randomly teleports.
	 * <br>
	 * This event is {@link CancellableEvent}.<br>
	 * If the event is not canceled, the entity will be teleported.
	 * <br>
	 * This event is only fired on the {@link EnvType#SERVER} side.<br>
	 * <br>
	 * If this event is canceled, the entity will not be teleported.
	 */
	public static class EnderEntity extends EntityTeleportEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onEnderEntityTeleport(event);
		});

		private final class_1309 entityLiving;

		public EnderEntity(class_1309 entity, double targetX, double targetY, double targetZ) {
			super(entity, targetX, targetY, targetZ);
			this.entityLiving = entity;
		}

		public class_1309 getEntityLiving() {
			return entityLiving;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onEnderEntityTeleport(this);
		}

		public interface Callback {
			void onEnderEntityTeleport(EnderEntity event);
		}
	}

	/**
	 * EntityTeleportEvent.EnderPearl is fired before an Entity is teleported from an EnderPearlEntity.
	 * <br>
	 * This event is {@link CancellableEvent}.<br>
	 * If the event is not canceled, the entity will be teleported.
	 * <br>
	 * This event is only fired on the {@link EnvType#SERVER} side.<br>
	 * <br>
	 * If this event is canceled, the entity will not be teleported.
	 */
	public static class EnderPearl extends EntityTeleportEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onEnderPearlTeleport(event);
		});

		private final class_3222 player;
		private final class_1684 pearlEntity;
		private float attackDamage;
		private final class_239 hitResult;

		@ApiStatus.Internal
		public EnderPearl(class_3222 entity, double targetX, double targetY, double targetZ, class_1684 pearlEntity, float attackDamage, class_239 hitResult) {
			super(entity, targetX, targetY, targetZ);
			this.pearlEntity = pearlEntity;
			this.player = entity;
			this.attackDamage = attackDamage;
			this.hitResult = hitResult;
		}

		public class_1684 getPearlEntity() {
			return pearlEntity;
		}

		public class_3222 getPlayer() {
			return player;
		}

		@Nullable
		public class_239 getHitResult() {
			return this.hitResult;
		}

		public float getAttackDamage() {
			return attackDamage;
		}

		public void setAttackDamage(float attackDamage) {
			this.attackDamage = attackDamage;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onEnderPearlTeleport(this);
		}

		public interface Callback {
			void onEnderPearlTeleport(EnderPearl event);
		}
	}

	/**
	 * EntityTeleportEvent.ChorusFruit is fired before a LivingEntity is teleported due to consuming Chorus Fruit.
	 * <br>
	 * This event is {@link CancellableEvent}.<br>
	 * If the event is not canceled, the entity will be teleported.
	 * <br>
	 * This event is only fired on the {@link EnvType#SERVER} side.<br>
	 * <br>
	 * If this event is canceled, the entity will not be teleported.
	 */
	public static class ChorusFruit extends EntityTeleportEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (Callback callback : callbacks)
				callback.onChorusFruitTeleport(event);
		});

		private final class_1309 entityLiving;

		public ChorusFruit(class_1309 entity, double targetX, double targetY, double targetZ) {
			super(entity, targetX, targetY, targetZ);
			this.entityLiving = entity;
		}

		public class_1309 getEntityLiving() {
			return entityLiving;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onChorusFruitTeleport(this);
		}

		public interface Callback {
			void onChorusFruitTeleport(ChorusFruit event);
		}
	}
}
