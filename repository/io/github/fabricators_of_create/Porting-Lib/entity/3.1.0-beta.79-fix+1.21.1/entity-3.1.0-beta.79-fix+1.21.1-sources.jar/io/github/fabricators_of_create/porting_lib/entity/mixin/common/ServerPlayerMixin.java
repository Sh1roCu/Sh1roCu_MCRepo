package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.authlib.GameProfile;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import io.github.fabricators_of_create.porting_lib.entity.events.ServerPlayerCreationCallback;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8791;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3222.class)
public abstract class ServerPlayerMixin extends class_1657 {
	public ServerPlayerMixin(class_1937 world, class_2338 pos, float yaw, GameProfile gameProfile) {
		super(world, pos, yaw, gameProfile);
	}

	@Shadow
	@Final
	public MinecraftServer server;

	@Inject(method = "<init>", at = @At("RETURN"))
	private void init(MinecraftServer server, class_3218 world, GameProfile gameProfile, class_8791 clientInformation, CallbackInfo ci) {
		ServerPlayerCreationCallback.EVENT.invoker().onCreate((class_3222) (Object) this);
	}

	@Inject(method = "restoreFrom", at = @At("TAIL"))
	private void copyPersistentData(class_3222 oldPlayer, boolean alive, CallbackInfo ci) {
		class_2487 oldData = oldPlayer.getCustomData();
		class_2487 persistent = oldData.method_10562("PlayerPersisted");
		if (persistent != null) {
			class_2487 thisData = this.getCustomData();
			thisData.method_10566("PlayerPersisted", persistent);
		}
	}

	@Inject(method = "die", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;gameEvent(Lnet/minecraft/core/Holder;)V", shift = At.Shift.AFTER), cancellable = true)
	private void onPlayerDie(class_1282 cause, CallbackInfo ci) {
		if (EntityHooks.onLivingDeath(this, cause))
			ci.cancel();
	}

	@WrapOperation(method = "drop(Lnet/minecraft/world/item/ItemStack;ZZ)Lnet/minecraft/world/entity/item/ItemEntity;", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;addFreshEntity(Lnet/minecraft/world/entity/Entity;)Z"))
	private boolean captureDrops(class_1937 instance, class_1297 entity, Operation<Boolean> original, @Local(ordinal = 0) class_1542 item) {
		if (captureDrops() != null) {
			captureDrops().add(item);
			return false;
		}
		return original.call(instance, entity);
	}
}
