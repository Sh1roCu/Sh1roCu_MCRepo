package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = "net/minecraft/server/network/ServerGamePacketListenerImpl$1")
public class ServerGamePacketListenerImpl$1Mixin {
	@Inject(method = "method_33898", at = @At("HEAD"))
	private static void onInteractEntityAt(class_243 vec3, class_3222 player, class_1297 entity, class_1268 interactionHand, CallbackInfoReturnable<class_1269> cir) {
		class_1269 onInteractEntityAtResult = EntityHooks.onInteractEntityAt(player, entity, vec3, interactionHand);
		if (onInteractEntityAtResult != null) cir.setReturnValue(onInteractEntityAtResult);
	}
}
