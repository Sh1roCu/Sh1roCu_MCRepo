package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import io.github.fabricators_of_create.porting_lib.entity.events.OnDatapackSyncCallback;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_2487;
import net.minecraft.class_2535;
import net.minecraft.class_29;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_8792;

@Mixin(class_3324.class)
public abstract class PlayerListMixin {
	@Shadow
	@Final
	private class_29 playerIo;

	@Inject(
			method = "placeNewPlayer",
			at = @At(value = "INVOKE", shift = At.Shift.AFTER, target = "Lnet/minecraft/network/protocol/game/ClientboundSetCarriedItemPacket;<init>(I)V")
	)
	private void port_lib$placeNewPlayer(class_2535 netManager, class_3222 player, class_8792 cookie, CallbackInfo ci) {
		OnDatapackSyncCallback.EVENT.invoker().onDatapackSync((class_3324) (Object) this, player);
	}

	@Inject(
			method = "reloadResources",
			at = @At(value = "INVOKE", shift = At.Shift.BEFORE, target = "Lnet/minecraft/server/players/PlayerList;broadcastAll(Lnet/minecraft/network/protocol/Packet;)V")
	)
	private void port_lib$placeNewPlayer(CallbackInfo ci) {
		OnDatapackSyncCallback.EVENT.invoker().onDatapackSync((class_3324) (Object) this, null);
	}

	@Inject(method = "placeNewPlayer", at = @At("TAIL"))
	private void onPlayerLoggedIn(class_2535 connection, class_3222 serverPlayer, class_8792 cookie, CallbackInfo ci) {
		EntityHooks.firePlayerLoggedIn(serverPlayer);
	}

	@Inject(method = "remove", at = @At("HEAD"))
	private void onPlayerLoggedOut(class_3222 serverPlayer, CallbackInfo ci) {
		EntityHooks.firePlayerLoggedOut(serverPlayer);
	}

	@Inject(method = "load", at = @At(value = "INVOKE", target = "Lorg/slf4j/Logger;debug(Ljava/lang/String;)V", shift = At.Shift.AFTER))
	private void onPlayerLoad(class_3222 player, CallbackInfoReturnable<Optional<class_2487>> cir) {
		EntityHooks.firePlayerLoadingEvent(player, this.playerIo, player.method_5667().toString());
	}
}
