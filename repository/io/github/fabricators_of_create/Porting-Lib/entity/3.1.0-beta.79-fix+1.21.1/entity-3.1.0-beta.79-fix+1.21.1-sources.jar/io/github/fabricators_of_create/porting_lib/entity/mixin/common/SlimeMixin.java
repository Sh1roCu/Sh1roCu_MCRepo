package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.injects.SlimeInjection;
import net.minecraft.class_1621;
import net.minecraft.class_4048;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

@Mixin(class_1621.class)
public class SlimeMixin implements SlimeInjection {
	@WrapOperation(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/EntityDimensions;width()F"))
	private float handleParticles(class_4048 instance, Operation<Float> original) {
		if (!spawnCustomParticles())
			return original.call(instance);
		return 0; // Return 0 to prevent adding particles
	}
}
