package io.github.fabricators_of_create.porting_lib.entity.mixin.client;

import java.util.Collection;
import java.util.stream.Collectors;
import net.minecraft.class_1058;
import net.minecraft.class_1293;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_485;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import com.llamalad7.mixinextras.sugar.Share;

import com.llamalad7.mixinextras.sugar.ref.LocalRef;

import io.github.fabricators_of_create.porting_lib.entity.client.MobEffectRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_485.class)
public class EffectRenderingInventoryScreenMixin {
	@ModifyArg(method = "renderEffects", at = @At(value = "INVOKE", target = "Lcom/google/common/collect/Ordering;sortedCopy(Ljava/lang/Iterable;)Ljava/util/List;"))
	private <E extends class_1293> Iterable<E> shouldRenderEffect(Iterable<E> elements) {
		Collection<E> effectInstances = (Collection<E>) elements;

		return effectInstances.stream().filter(mobEffectInstance -> {
			if (mobEffectInstance.method_5579().method_40227()) {
				MobEffectRenderer renderer = mobEffectInstance.method_5579().comp_349().getRenderer();
				if (renderer != null)
					return renderer.isVisibleInInventory(mobEffectInstance);
			}

			return true;
		}).collect(Collectors.toList());
	}

	@WrapOperation(method = "renderIcons", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blit(IIIIILnet/minecraft/client/renderer/texture/TextureAtlasSprite;)V"))
	private void handleCustomRenderers(class_332 graphics, int blitX, int blitY, int z, int width, int height, class_1058 sprite, Operation<Void> original, @Local(index = 2) int x, @Local(index = 3) int offsetDelta, @Local(index = 5) boolean wide, @Local(index = 9) class_1293 mobEffectInstance, @Local(index = 7) int i, @Share("offset") LocalRef<Integer> offset) {
		if (offset.get() == null)
			offset.set(0);
		if (mobEffectInstance.method_5579().method_40227()) {
			MobEffectRenderer renderer = mobEffectInstance.method_5579().comp_349().getRenderer();
			if (renderer != null && renderer.renderInventoryIcon(mobEffectInstance, (class_485) (Object) this, graphics, x + (wide ? 6 : 7), offset.get() + i, 0)) {
				offset.set(offset.get() + offsetDelta);
				return;
			}
		}
		original.call(graphics, blitX, blitY + offset.get(), z, width, height, sprite);
	}

	@Inject(method = "renderLabels", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/inventory/EffectRenderingInventoryScreen;getEffectName(Lnet/minecraft/world/effect/MobEffectInstance;)Lnet/minecraft/network/chat/Component;"))
	private void renderCustomInventoryText(class_332 graphics, int x, int height, Iterable<class_1293> statusEffects, CallbackInfo ci, @Local(index = 7) class_1293 mobEffectInstance, @Local(index = 5) int i, @Share("custom") LocalRef<Boolean> cancelled) {
		if (mobEffectInstance.method_5579().method_40227()) {
			MobEffectRenderer renderer = mobEffectInstance.method_5579().comp_349().getRenderer();
			if (renderer != null && renderer.renderInventoryText(mobEffectInstance, (class_485<?>) (Object) this, graphics, x, i, 0)) {
				cancelled.set(true);
				return;
			}
		}

		cancelled.set(false);
	}

	@WrapWithCondition(method = "renderLabels", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;drawString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;III)I"))
	private boolean cancelInventoryText(class_332 graphics, class_327 renderer, class_2561 text, int x, int y, int color, @Share("custom") LocalRef<Boolean> cancelled) {
		return !cancelled.get();
	}
}
