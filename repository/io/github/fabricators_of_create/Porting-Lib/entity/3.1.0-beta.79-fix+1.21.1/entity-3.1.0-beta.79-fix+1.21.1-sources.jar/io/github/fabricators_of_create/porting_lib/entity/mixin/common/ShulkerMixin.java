package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import com.llamalad7.mixinextras.sugar.Share;

import com.llamalad7.mixinextras.sugar.ref.LocalRef;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import io.github.fabricators_of_create.porting_lib.entity.events.EntityTeleportEvent;
import net.minecraft.class_1606;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1606.class)
public class ShulkerMixin {
	@ModifyVariable(method = "teleportSomewhere", at = @At(value = "JUMP", opcode = Opcodes.IFNULL), index = 4)
	private class_2350 onEnderTeleport(class_2350 direction, @Local(index = 3) class_2338 pos, @Share("event") LocalRef<EntityTeleportEvent.EnderEntity> eventRef) {
		if (direction != null) {
			EntityTeleportEvent.EnderEntity event = EntityHooks.onEnderTeleport((class_1606) (Object) this, pos.method_10263(), pos.method_10264(), pos.method_10260());
			eventRef.set(event);
			if (event.isCanceled())
				return null;
		}
		return direction;
	}

	@ModifyVariable(method = "teleportSomewhere", at = @At(value = "JUMP", opcode = Opcodes.IFNULL, by = 1), index = 3) // Shift by 1 so we apply after the above code
	private class_2338 changeTeleportTarget(class_2338 pos, @Local(index = 4) class_2350 direction, @Share("event") LocalRef<EntityTeleportEvent.EnderEntity> eventRef) {
		if (direction != null) {
			EntityTeleportEvent.EnderEntity event = eventRef.get();
			return class_2338.method_49637(event.getTargetX(), event.getTargetY(), event.getTargetZ());
		}
		return pos;
	}
}
