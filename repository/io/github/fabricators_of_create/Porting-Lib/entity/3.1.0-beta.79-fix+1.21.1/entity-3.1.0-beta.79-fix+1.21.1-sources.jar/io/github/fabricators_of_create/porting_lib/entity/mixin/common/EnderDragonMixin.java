package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1510;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(class_1510.class)
public abstract class EnderDragonMixin extends class_1308 {
	// I actually have no idea why this is a thing ._.
	/**
	 * Called frequently so the entity can update its state every tick as required. For example, zombies and skeletons
	 * use this to react to sunlight and start to burn.
	 */
	@Nullable
	private class_1657 port_lib$unlimitedLastHurtByPlayer = null;

	protected EnderDragonMixin(class_1299<? extends class_1308> entityType, class_1937 level) {
		super(entityType, level);
	}

	@Inject(method = "aiStep", at = @At("HEAD"))
	private void unlimitedLastHurtStep(CallbackInfo ci) {
		// lastHurtByPlayer is cleared after 100 ticks, capture it indefinitely in unlimitedLastHurtByPlayer for LivingExperienceDropEvent
		if (this.field_6258 != null) this.port_lib$unlimitedLastHurtByPlayer = field_6258;
		if (this.port_lib$unlimitedLastHurtByPlayer != null && this.port_lib$unlimitedLastHurtByPlayer.method_31481()) this.port_lib$unlimitedLastHurtByPlayer = null;
	}

	@ModifyArgs(method = "tickDeath", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/ExperienceOrb;award(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/phys/Vec3;I)V"))
	private void dropExperience(Args args) {
		int amount = args.get(2);
		int newAmount = EntityHooks.getExperienceDrop(this, port_lib$unlimitedLastHurtByPlayer, amount);
		if (amount != newAmount) args.set(2, newAmount);
	}
}
