package io.github.fabricators_of_create.porting_lib.entity.injects;

import net.minecraft.class_2338;

public interface AbstractMinecartInjection {
	default void moveMinecartOnRail(class_2338 pos) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default class_2338 getCurrentRailPos() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default float getMaxSpeedOnRail() {
		return 1.2f; // default in Forge
	}
}
