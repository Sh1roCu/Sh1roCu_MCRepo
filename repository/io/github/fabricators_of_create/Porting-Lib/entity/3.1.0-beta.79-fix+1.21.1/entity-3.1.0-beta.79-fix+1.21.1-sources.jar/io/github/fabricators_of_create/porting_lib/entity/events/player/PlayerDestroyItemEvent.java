package io.github.fabricators_of_create.porting_lib.entity.events.player;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.player.PlayerEvent;
import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;

/**
 * PlayerDestroyItemEvent is fired when a player destroys an item.<br>
 * This event is fired whenever a player destroys an item in
 * {@link class_636#method_2899(class_2338)},
 * {@link class_636#method_2919(class_1657, class_1268)},
 * {@link class_636#method_2896(class_746, class_1268, class_3965)} ,
 * {@link class_1657#method_7324(class_1297)},
 * {@code Player#hurtCurrentlyUsedShield(float)},
 * {@link class_1657#method_7287(class_1297, class_1268)},
 * {@link class_3225#method_14256(class_3222, class_1937, class_1799, class_1268)} ,
 * {@link class_3225#method_14262(class_3222, class_1937, class_1799, class_1268, class_3965)}
 * and {@link class_3225#method_14266(class_2338)}.<br>
 * <br>
 * {@link #original} contains the original ItemStack before the item was destroyed. <br>
 * (@link #hand) contains the hand that the current item was held in.<br>
 * <br>
 * This event is not {@link CancellableEvent}.<br>
 * <br>
 * This event is fired from {@link EntityHooks#onPlayerDestroyItem(class_1657, class_1799, class_1268)}.<br>
 **/
public class PlayerDestroyItemEvent extends PlayerEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (Callback callback : callbacks)
			callback.onPlayerDestroyItem(event);
	});

	private final class_1799 original;
	@Nullable
	private final class_1268 hand; // May be null if this player destroys the item by any use besides holding it.

	public PlayerDestroyItemEvent(class_1657 player, class_1799 original, @Nullable class_1268 hand) {
		super(player);
		this.original = original;
		this.hand = hand;
	}

	public class_1799 getOriginal() {
		return this.original;
	}

	@Nullable
	public class_1268 getHand() {
		return this.hand;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onPlayerDestroyItem(this);
	}

	public interface Callback {
		void onPlayerDestroyItem(PlayerDestroyItemEvent event);
	}
}
