package io.github.fabricators_of_create.porting_lib.entity;

import io.github.fabricators_of_create.porting_lib.entity.events.EntityEvents;
import io.github.fabricators_of_create.porting_lib.entity.events.EntityMountEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.EntityStruckByLightningEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.EntityTeleportEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingDeathEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingAttackEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingDropsEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingEntityUseItemEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingEntityUseItemEvent.Start;
import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingEntityUseItemEvent.Tick;
import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingExperienceDropEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingKnockBackEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.living.MobEffectEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.living.MobEffectEvent.Applicable;
import io.github.fabricators_of_create.porting_lib.entity.events.living.MobEffectEvent.Remove;
import io.github.fabricators_of_create.porting_lib.entity.events.living.ShieldBlockEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.player.AttackEntityEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.player.CriticalHitEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.player.PlayerDestroyItemEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.player.PlayerEvents;
import io.github.fabricators_of_create.porting_lib.entity.events.player.PlayerInteractEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.ProjectileImpactEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingChangeTargetEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingEvents;
import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingFallEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingHurtEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.living.LivingUseTotemEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.tick.EntityTickEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.tick.PlayerTickEvent;
import io.github.fabricators_of_create.porting_lib.entity.mixin.accessor.PlayerDataStorageAccessor;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.Collection;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1684;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_29;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_6880;

public final class EntityHooks {
	public static float getBreakSpeed(class_1657 player, class_2680 state, float original, class_2338 pos) {
		PlayerEvents.BreakSpeed event = new PlayerEvents.BreakSpeed(player, state, original, pos);
		event.sendEvent();
		return (event.isCanceled() ? -1 : event.getNewSpeed());
	}

	public static void onPlayerDestroyItem(class_1657 player, class_1799 stack, @Nullable class_1268 hand) {
		new PlayerDestroyItemEvent(player, stack, hand).sendEvent();
	}

	public static int getExperienceDrop(class_1309 entity, class_1657 attackingPlayer, int originalExperience) {
		LivingExperienceDropEvent event = new LivingExperienceDropEvent(entity, attackingPlayer, originalExperience);
		event.sendEvent();
		if (event.isCanceled()) {
			return 0;
		}
		return event.getDroppedExperience();
	}

	public static boolean canMountEntity(class_1297 entityMounting, class_1297 entityBeingMounted, boolean isMounting) {
		EntityMountEvent event = new EntityMountEvent(entityMounting, entityBeingMounted, entityMounting.method_37908(), isMounting);
		event.sendEvent();

		if (event.isCanceled()) {
			entityMounting.method_5641(entityMounting.method_23317(), entityMounting.method_23318(), entityMounting.method_23321(), entityMounting.field_5982, entityMounting.field_6004);
			return false;
		} else
			return true;
	}

	public static LivingChangeTargetEvent onLivingChangeTarget(class_1309 entity, class_1309 originalTarget, LivingChangeTargetEvent.ILivingTargetType targetType) {
		LivingChangeTargetEvent event = new LivingChangeTargetEvent(entity, originalTarget, targetType);
		event.sendEvent();

		return event;
	}

	public static boolean onLivingAttack(class_1309 entity, class_1282 src, float amount) {
		return entity instanceof class_1657 || !new LivingAttackEvent(entity, src, amount).post();
	}

	public static boolean onPlayerAttack(class_1309 entity, class_1282 src, float amount) {
		return !new LivingAttackEvent(entity, src, amount).post();
	}

	public static LivingKnockBackEvent onLivingKnockBack(class_1309 target, float strength, double ratioX, double ratioZ) {
		LivingKnockBackEvent event = new LivingKnockBackEvent(target, strength, ratioX, ratioZ);
		event.sendEvent();
		return event;
	}

	public static boolean onLivingUseTotem(class_1309 entity, class_1282 damageSource, class_1799 totem, class_1268 hand) {
		LivingUseTotemEvent event = new LivingUseTotemEvent(entity, damageSource, totem, hand);
		event.sendEvent();
		return !event.isCanceled();
	}

	public static float onLivingHurt(class_1309 entity, class_1282 src, float amount) {
		LivingHurtEvent event = new LivingHurtEvent(entity, src, amount);
		event.sendEvent();
		return (event.isCanceled() ? 0 : event.getAmount());
	}

//	public static float onLivingDamage(LivingEntity entity, DamageSource src, float amount) {
//		LivingDamageEvent event = new LivingDamageEvent(entity, src, amount);
//		event.sendEvent();
//		return (event.isCanceled() ? 0 : event.getAmount());
//	}

	public static boolean onLivingDeath(class_1309 entity, class_1282 src) {
		var event = new LivingDeathEvent(entity, src);
		event.sendEvent();
		return event.isCanceled();
	}

	public static boolean onLivingDrops(class_1309 entity, class_1282 source, Collection<class_1542> drops, boolean recentlyHit) {
		return new LivingDropsEvent(entity, source, drops, recentlyHit).post();
	}

	@Nullable
	public static float[] onLivingFall(class_1309 entity, float distance, float damageMultiplier) {
		LivingFallEvent event = new LivingFallEvent(entity, distance, damageMultiplier);
		event.sendEvent();
		return event.isCanceled() ? null : new float[] { event.getDistance(), event.getDamageMultiplier() };
	}

	public static double getEntityVisibilityMultiplier(class_1309 entity, class_1297 lookingEntity, double originalMultiplier) {
		LivingEvents.LivingVisibilityEvent event = new LivingEvents.LivingVisibilityEvent(entity, lookingEntity, originalMultiplier);
		event.sendEvent();
		return Math.max(0, event.getVisibilityModifier());
	}

	public static void onLivingJump(class_1309 entity) {
		new LivingEvents.LivingJumpEvent(entity).sendEvent();
	}

	public static boolean onPlayerAttackTarget(class_1657 player, class_1297 target) {
		var event = new AttackEntityEvent(player, target);
		event.sendEvent();
		if (event.isCanceled())
			return false;
		class_1799 stack = player.method_6047();
		return stack.method_7960() || !stack.method_7909().onLeftClickEntity(stack, player, target);
	}

	@Nullable
	public static class_1269 onInteractEntityAt(class_1657 player, class_1297 entity, class_239 ray, class_1268 hand) {
		class_243 vec3d = ray.method_17784().method_1020(entity.method_19538());
		return onInteractEntityAt(player, entity, vec3d, hand);
	}

	@Nullable
	public static class_1269 onInteractEntityAt(class_1657 player, class_1297 entity, class_243 vec3d, class_1268 hand) {
		PlayerInteractEvent.EntityInteractSpecific evt = new PlayerInteractEvent.EntityInteractSpecific(player, hand, entity, vec3d);
		evt.sendEvent();
		return evt.isCanceled() ? evt.getCancellationResult() : null;
	}

	@Nullable
	public static class_1269 onInteractEntity(class_1657 player, class_1297 entity, class_1268 hand) {
		PlayerInteractEvent.EntityInteract evt = new PlayerInteractEvent.EntityInteract(player, hand, entity);
		evt.sendEvent();
		return evt.isCanceled() ? evt.getCancellationResult() : null;
	}

	@Nullable
	public static class_1269 onItemRightClick(class_1657 player, class_1268 hand) {
		PlayerInteractEvent.RightClickItem evt = new PlayerInteractEvent.RightClickItem(player, hand);
		evt.sendEvent();
		return evt.isCanceled() ? evt.getCancellationResult() : null;
	}

	public static PlayerInteractEvent.LeftClickBlock onLeftClickBlock(class_1657 player, class_2338 pos, class_2350 face, class_2846.class_2847 action) {
		PlayerInteractEvent.LeftClickBlock evt = new PlayerInteractEvent.LeftClickBlock(player, pos, face, PlayerInteractEvent.LeftClickBlock.Action.convert(action));
		evt.sendEvent();
		return evt;
	}

	public static PlayerInteractEvent.LeftClickBlock onClientMineHold(class_1657 player, class_2338 pos, class_2350 face) {
		PlayerInteractEvent.LeftClickBlock evt = new PlayerInteractEvent.LeftClickBlock(player, pos, face, PlayerInteractEvent.LeftClickBlock.Action.CLIENT_HOLD);
		evt.sendEvent();
		return evt;
	}

	public static PlayerInteractEvent.RightClickBlock onRightClickBlock(class_1657 player, class_1268 hand, class_2338 pos, class_3965 hitVec) {
		PlayerInteractEvent.RightClickBlock evt = new PlayerInteractEvent.RightClickBlock(player, hand, pos, hitVec);
		evt.sendEvent();
		return evt;
	}

	public static void onEmptyClick(class_1657 player, class_1268 hand) {
		new PlayerInteractEvent.RightClickEmpty(player, hand).sendEvent();
	}

	public static void onEmptyLeftClick(class_1657 player) {
		new PlayerInteractEvent.LeftClickEmpty(player).sendEvent();
	}

	public static EntityEvents.Size getEntitySizeForge(class_1297 entity, class_4050 pose, class_4048 size, float eyeHeight) {
		EntityEvents.Size evt = new EntityEvents.Size(entity, pose, size, eyeHeight);
		evt.sendEvent();
		return evt;
	}

	public static EntityEvents.Size getEntitySizeForge(class_1297 entity, class_4050 pose, class_4048 oldSize, class_4048 newSize, float newEyeHeight) {
		EntityEvents.Size evt = new EntityEvents.Size(entity, pose, oldSize, newSize, entity.method_5751(), newEyeHeight);
		evt.sendEvent();
		return evt;
	}

	public static EntityTeleportEvent.TeleportCommand onEntityTeleportCommand(class_1297 entity, double targetX, double targetY, double targetZ) {
		EntityTeleportEvent.TeleportCommand event = new EntityTeleportEvent.TeleportCommand(entity, targetX, targetY, targetZ);
		event.sendEvent();
		return event;
	}

	public static EntityTeleportEvent.SpreadPlayersCommand onEntityTeleportSpreadPlayersCommand(class_1297 entity, double targetX, double targetY, double targetZ) {
		EntityTeleportEvent.SpreadPlayersCommand event = new EntityTeleportEvent.SpreadPlayersCommand(entity, targetX, targetY, targetZ);
		event.sendEvent();
		return event;
	}

	public static EntityTeleportEvent.EnderEntity onEnderTeleport(class_1309 entity, double targetX, double targetY, double targetZ) { // TODO: implement on shulker
		EntityTeleportEvent.EnderEntity event = new EntityTeleportEvent.EnderEntity(entity, targetX, targetY, targetZ);
		event.sendEvent();
		return event;
	}

	@ApiStatus.Internal
	public static EntityTeleportEvent.EnderPearl onEnderPearlLand(class_3222 entity, double targetX, double targetY, double targetZ, class_1684 pearlEntity, float attackDamage, class_239 hitResult) {
		EntityTeleportEvent.EnderPearl event = new EntityTeleportEvent.EnderPearl(entity, targetX, targetY, targetZ, pearlEntity, attackDamage, hitResult);
		event.sendEvent();
		return event;
	}

	public static EntityTeleportEvent.ChorusFruit onChorusFruitTeleport(class_1309 entity, double targetX, double targetY, double targetZ) {
		EntityTeleportEvent.ChorusFruit event = new EntityTeleportEvent.ChorusFruit(entity, targetX, targetY, targetZ);
		event.sendEvent();
		return event;
	}

	public static void firePlayerLoggedIn(class_1657 player) {
		new PlayerEvents.PlayerLoggedInEvent(player).sendEvent();
	}

	public static void firePlayerLoggedOut(class_1657 player) {
		new PlayerEvents.PlayerLoggedOutEvent(player).sendEvent();
	}

	public static boolean onEntityStruckByLightning(class_1297 entity, class_1538 bolt) {
		EntityStruckByLightningEvent event = new EntityStruckByLightningEvent(entity, bolt);
		event.sendEvent();
		return event.isCanceled();
	}

	public static int onItemUseStart(class_1309 entity, class_1799 item, int duration) {
		var event = new LivingEntityUseItemEvent.Start(entity, item, duration);
		return event.post() ? -1 : event.getDuration();
	}

	public static int onItemUseTick(class_1309 entity, class_1799 item, int duration) {
		var event = new LivingEntityUseItemEvent.Tick(entity, item, duration);
		return event.post() ? -1 : event.getDuration();
	}

	public static boolean onUseItemStop(class_1309 entity, class_1799 item, int duration) {
		return new LivingEntityUseItemEvent.Stop(entity, item, duration).post();
	}

	public static class_1799 onItemUseFinish(class_1309 entity, class_1799 item, int duration, class_1799 result) {
		LivingEntityUseItemEvent.Finish event = new LivingEntityUseItemEvent.Finish(entity, item, duration, result);
		event.sendEvent();
		return event.getResultStack();
	}

	public static void onStartEntityTracking(class_1297 entity, class_1657 player) {
		new PlayerEvents.StartTracking(player, entity).sendEvent();
	}

	public static void onStopEntityTracking(class_1297 entity, class_1657 player) {
		new PlayerEvents.StopTracking(player, entity).sendEvent();
	}

	public static void firePlayerLoadingEvent(class_1657 player, File playerDirectory, String uuidString) {
		new PlayerEvents.LoadFromFile(player, playerDirectory, uuidString).sendEvent();
	}

	public static void firePlayerSavingEvent(class_1657 player, File playerDirectory, String uuidString) {
		new PlayerEvents.SaveToFile(player, playerDirectory, uuidString).sendEvent();
	}

	public static void firePlayerLoadingEvent(class_1657 player, class_29 playerFileData, String uuidString) {
		new PlayerEvents.LoadFromFile(player, ((PlayerDataStorageAccessor) playerFileData).getPlayerDir(), uuidString).sendEvent();
	}

	public static boolean onProjectileImpact(class_1676 projectile, class_239 ray) {
		ProjectileImpactEvent event = new ProjectileImpactEvent(projectile, ray);
		event.sendEvent();
		return event.isCanceled();
	}

	public static void firePlayerCraftingEvent(class_1657 player, class_1799 crafted, class_1263 craftMatrix) {
		new PlayerEvents.ItemCraftedEvent(player, crafted, craftMatrix).sendEvent();
	}

	public static void firePlayerSmeltedEvent(class_1657 player, class_1799 smelted) {
		new PlayerEvents.ItemSmeltedEvent(player, smelted).sendEvent();
	}

	/**
	 * Fires {@link EntityTickEvent.Pre}. Called from the head of {@link class_1309#method_5773()}.
	 *
	 * @param entity The entity being ticked
	 * @return The event
	 */
	public static EntityTickEvent.Pre fireEntityTickPre(class_1297 entity) {
		EntityTickEvent.Pre event = new EntityTickEvent.Pre(entity);
		event.sendEvent();
		return event;
	}

	/**
	 * Fires {@link EntityTickEvent.Post}. Called from the tail of {@link class_1309#method_5773()}.
	 *
	 * @param entity The entity being ticked
	 */
	public static void fireEntityTickPost(class_1297 entity) {
		new EntityTickEvent.Post(entity).sendEvent();
	}

	/**
	 * Fires {@link PlayerTickEvent.Pre}. Called from the head of {@link class_1657#method_5773()}.
	 *
	 * @param player The player being ticked
	 */
	public static void firePlayerTickPre(class_1657 player) {
		new PlayerTickEvent.Pre(player).sendEvent();
	}

	/**
	 * Fires {@link PlayerTickEvent.Post}. Called from the tail of {@link class_1657#method_5773()}.
	 *
	 * @param player The player being ticked
	 */
	public static void firePlayerTickPost(class_1657 player) {
		new PlayerTickEvent.Post(player).sendEvent();
	}

	/**
	 * Fires the {@link CriticalHitEvent} and returns the resulting event.
	 *
	 * @param player          The attacking player
	 * @param target          The attack target
	 * @param vanillaCritical If the attack would have been a critical hit by vanilla's rules in {@link class_1657#method_7324(class_1297)}.
	 * @param damageModifier  The base damage modifier. Vanilla critical hits have a damage modifier of 1.5.
	 */
	public static CriticalHitEvent fireCriticalHit(class_1657 player, class_1297 target, boolean vanillaCritical, float damageModifier) {
		CriticalHitEvent event = new CriticalHitEvent(player, target, damageModifier, vanillaCritical);
		event.sendEvent();
		return event;
	}

	public static void onEntityEnterSection(class_1297 entity, long packedOldPos, long packedNewPos) {
		new EntityEvents.EnteringSection(entity, packedOldPos, packedNewPos).sendEvent();
	}

	public static ShieldBlockEvent onShieldBlock(class_1309 blocker, class_1282 source, float blocked) {
		ShieldBlockEvent e = new ShieldBlockEvent(blocker, source, blocked);
		e.sendEvent();
		return e;
	}

	public static boolean onEffectRemoved(class_1309 entity, class_6880<class_1291> effect, @Nullable EffectCure cure) {
		var event = new MobEffectEvent.Remove(entity, effect, cure);
		event.sendEvent();
		return event.isCanceled();
	}

	public static boolean onEffectRemoved(class_1309 entity, class_1293 effectInstance, @Nullable EffectCure cure) {
		var event = new MobEffectEvent.Remove(entity, effectInstance, cure);
		event.sendEvent();
		return event.isCanceled();
	}

	/**
	 * Checks if a mob effect can be applied to an entity by firing {@link MobEffectEvent.Applicable}.
	 *
	 * @param entity The target entity the mob effect is being applied to.
	 * @param effect The mob effect being applied.
	 * @return True if the mob effect can be applied, otherwise false.
	 */
	public static boolean canMobEffectBeApplied(class_1309 entity, class_1293 effect) {
		var event = new MobEffectEvent.Applicable(entity, effect);
		event.sendEvent();
		return event.getApplicationResult();
	}
}
