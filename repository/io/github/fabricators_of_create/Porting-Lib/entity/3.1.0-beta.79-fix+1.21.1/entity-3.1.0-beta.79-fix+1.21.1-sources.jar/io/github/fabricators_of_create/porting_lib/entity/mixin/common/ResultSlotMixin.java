package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import net.minecraft.class_1657;
import net.minecraft.class_1734;
import net.minecraft.class_1799;
import net.minecraft.class_8566;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1734.class)
public class ResultSlotMixin {
	@Shadow
	@Final
	private class_1657 player;

	@Shadow
	@Final
	private class_8566 craftSlots;

	@Inject(method = "checkTakeAchievements", at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/item/ItemStack;onCraftedBy(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;I)V",
			shift = At.Shift.AFTER
	))
	private void onItemCrafted(class_1799 itemStack, CallbackInfo ci) {
		EntityHooks.firePlayerCraftingEvent(this.player, itemStack, this.craftSlots);
	}
}
