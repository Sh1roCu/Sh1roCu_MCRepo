package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class)
public abstract class BlockBehaviourMixin {
	@Inject(method = "getDestroyProgress", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;hasCorrectToolForDrops(Lnet/minecraft/world/level/block/state/BlockState;)Z"))
	public void getDestroySpeed(class_2680 blockState, class_1657 player, class_1922 blockGetter, class_2338 pos, CallbackInfoReturnable<Float> cir) {
		player.setDigSpeedContext(pos);
	}
}
