package io.github.fabricators_of_create.porting_lib.entity;

import com.mojang.logging.LogUtils;

import io.github.fabricators_of_create.porting_lib.core.util.LogicalSidedProvider;
import io.github.fabricators_of_create.porting_lib.entity.events.EntityJoinLevelEvent;
import io.github.fabricators_of_create.porting_lib.entity.network.AdvancedAddEntityPayload;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_1255;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3738;
import org.slf4j.Logger;

public class PortingLibEntity implements ModInitializer {
	public static final Logger LOGGER = LogUtils.getLogger();

	@Override
	public void onInitialize() {
		ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
			if (entity instanceof MultiPartEntity partEntity && partEntity.isMultipartEntity()) {
				PartEntity<?>[] parts = partEntity.getParts();
				if (parts != null) {
					for (PartEntity<?> part : parts) {
						world.getPartEntityMap().put(part.method_5628(), part);
					}
				}
			}
		});
		ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
			if (entity instanceof MultiPartEntity partEntity && partEntity.isMultipartEntity()) {
				PartEntity<?>[] parts = partEntity.getParts();
				if (parts != null) {
					for (PartEntity<?> part : parts) {
						world.getPartEntityMap().remove(part.method_5628());
					}
				}
			}
		});
		PayloadTypeRegistry.playS2C().register(AdvancedAddEntityPayload.TYPE, AdvancedAddEntityPayload.STREAM_CODEC);
		EntityJoinLevelEvent.EVENT.register(PortingLibEntity::onEntityJoinWorld);
	}

	public static void onEntityJoinWorld(EntityJoinLevelEvent event) {
		class_1297 entity = event.getEntity();
		if (entity.getClass().equals(class_1542.class)) {
			class_1799 stack = ((class_1542) entity).method_6983();
			class_1792 item = stack.method_7909();
			if (item.hasCustomEntity(stack)) {
				class_1297 newEntity = item.createEntity(event.getLevel(), entity, stack);
				if (newEntity != null) {
					entity.method_31472();
					event.setCanceled(true);
					var executor = LogicalSidedProvider.WORKQUEUE.get(event.getLevel().field_9236 ? EnvType.CLIENT : EnvType.SERVER);
					executor.method_18858(new class_3738(0, () -> event.getLevel().method_8649(newEntity)));
				}
			}
		}
	}
}
