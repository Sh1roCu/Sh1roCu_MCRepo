package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.extensions.VanillaIShearable;
import net.minecraft.class_1472;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1472.class)
public class SheepMixin implements VanillaIShearable {
}
