package io.github.fabricators_of_create.porting_lib.entity.events.living;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.living.LivingEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_3532;

/**
 * The ShieldBlockEvent is fired when an entity successfully blocks with a shield.<br>
 * Cancelling this event will have the same impact as if the shield was not eligible to block.<br>
 * The damage blocked cannot be set lower than zero or greater than the original value.<br>
 * Note: The shield item stack "should" be available from {@link class_1309#method_6030()}
 * at least for players.
 */
public class ShieldBlockEvent extends LivingEvent implements CancellableEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (final Callback callback : callbacks)
			callback.onShieldBlock(event);
	});

	private final class_1282 source;
	private final float originalBlocked;
	private float dmgBlocked;
	private boolean shieldTakesDamage = true;

	public ShieldBlockEvent(class_1309 blocker, class_1282 source, float blocked) {
		super(blocker);
		this.source = source;
		this.originalBlocked = blocked;
		this.dmgBlocked = blocked;
	}

	/**
	 * @return The damage source.
	 */
	public class_1282 getDamageSource() {
		return this.source;
	}

	/**
	 * @return The original amount of damage blocked, which is the same as the original
	 * incoming damage value.
	 */
	public float getOriginalBlockedDamage() {
		return this.originalBlocked;
	}

	/**
	 * @return The current amount of damage blocked, as a result of this event.
	 */
	public float getBlockedDamage() {
		return this.dmgBlocked;
	}

	/**
	 * Controls if {@link class_1309#method_6056} is called.
	 *
	 * @return If the shield item will take durability damage or not.
	 */
	public boolean shieldTakesDamage() {
		return this.shieldTakesDamage;
	}

	/**
	 * Set how much damage is blocked by this action.<br>
	 * Note that initially the blocked amount is the entire attack.<br>
	 */
	public void setBlockedDamage(float blocked) {
		this.dmgBlocked = class_3532.method_15363(blocked, 0, this.originalBlocked);
	}

	/**
	 * Set if the shield will take durability damage or not.
	 */
	public void setShieldTakesDamage(boolean damage) {
		this.shieldTakesDamage = damage;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onShieldBlock(this);
	}

	public interface Callback {
		void onShieldBlock(ShieldBlockEvent event);
	}
}
