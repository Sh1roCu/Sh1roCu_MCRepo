package io.github.fabricators_of_create.porting_lib.entity.events;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.EntityEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_1937;

/**
 * This event gets fired whenever a entity mounts/dismounts another entity.<br>
 * <b>entityBeingMounted can be null</b>, be sure to check for that.
 * <br>
 * <br>
 * This event is {@link CancellableEvent}.<br>
 * If this event is canceled, the entity does not mount/dismount the other entity.<br>
 *
 */
public class EntityMountEvent extends EntityEvent implements CancellableEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (final Callback callback : callbacks)
			callback.onEntityMounting(event);
	});

	private final class_1297 entityMounting;
	private final class_1297 entityBeingMounted;
	private final class_1937 level;

	private final boolean isMounting;

	public EntityMountEvent(class_1297 entityMounting, class_1297 entityBeingMounted, class_1937 level, boolean isMounting) {
		super(entityMounting);
		this.entityMounting = entityMounting;
		this.entityBeingMounted = entityBeingMounted;
		this.level = level;
		this.isMounting = isMounting;
	}

	public boolean isMounting() {
		return isMounting;
	}

	public boolean isDismounting() {
		return !isMounting;
	}

	public class_1297 getEntityMounting() {
		return entityMounting;
	}

	public class_1297 getEntityBeingMounted() {
		return entityBeingMounted;
	}

	public class_1937 getLevel() {
		return level;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onEntityMounting(this);
	}

	public interface Callback {
		void onEntityMounting(EntityMountEvent event);
	}
}
