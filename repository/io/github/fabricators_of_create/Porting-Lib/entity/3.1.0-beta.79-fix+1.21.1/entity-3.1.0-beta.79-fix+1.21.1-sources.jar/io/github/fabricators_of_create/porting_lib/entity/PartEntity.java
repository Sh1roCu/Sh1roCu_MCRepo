package io.github.fabricators_of_create.porting_lib.entity;

import net.minecraft.class_1297;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_3231;

/**
 * An entity which is part of a parent entity, like the Ender Dragon.
 * <p>
 *     These entities are not saved and are not synced. Their parent is responsible for managing them.
 * </p>
 * @param <T> the type of the parent entity
 */
public abstract class PartEntity<T extends class_1297> extends class_1297 {
	private final T parent;

	public PartEntity(T parent) {
		super(parent.method_5864(), parent.method_37908());
		this.parent = parent;
	}

	public T getParent() {
		return parent;
	}

	@Override
	public class_2596<class_2602> method_18002(class_3231 entity) {
		throw new UnsupportedOperationException();
	}
}
