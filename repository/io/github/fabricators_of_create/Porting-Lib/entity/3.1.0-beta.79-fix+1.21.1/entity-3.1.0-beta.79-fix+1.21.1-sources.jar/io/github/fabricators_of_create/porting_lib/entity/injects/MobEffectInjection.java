package io.github.fabricators_of_create.porting_lib.entity.injects;

import io.github.fabricators_of_create.porting_lib.core.util.MixinHelper;
import io.github.fabricators_of_create.porting_lib.entity.EffectCure;
import io.github.fabricators_of_create.porting_lib.entity.EffectCures;
import io.github.fabricators_of_create.porting_lib.entity.client.MobEffectRenderer;
import org.jetbrains.annotations.Nullable;

import java.util.Set;
import net.minecraft.class_1293;
import net.minecraft.class_1294;

public interface MobEffectInjection {
	/***
	 * Fill the given set with the {@link EffectCure}s this effect should be curable with by default
	 */
	default void fillEffectCures(Set<EffectCure> cures, class_1293 effectInstance) {
		cures.addAll(EffectCures.DEFAULT_CURES);
		if (MixinHelper.cast(this) == class_1294.field_5899.comp_349()) {
			cures.add(EffectCures.HONEY);
		}
	}

	@Nullable
	default MobEffectRenderer getRenderer() {
		return null;
	}
}
