package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.entity.extensions.IShearable;
import io.github.fabricators_of_create.porting_lib.entity.extensions.VanillaIShearable;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_3218;
import net.minecraft.class_5147;
import net.minecraft.class_5168;
import net.minecraft.class_5712;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5168.class)
public class ShearsDispenseItemBehaviorMixin {
	private static final ThreadLocal<class_1799> port_lib$passed_stack = new ThreadLocal<>();

	@Inject(method = "execute", at = @At(value = "INVOKE", target = "Lnet/minecraft/core/dispenser/ShearsDispenseItemBehavior;tryShearLivingEntity(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;)Z"))
	private void setPassedStack(class_2342 blockSource, class_1799 item, CallbackInfoReturnable<class_1799> cir) {
		port_lib$passed_stack.set(item);
	}

	@Definition(id = "livingEntity", local = @Local(type = class_1309.class))
	@Definition(id = "Shearable", type = class_5147.class)
	@Expression("livingEntity instanceof Shearable")
	@ModifyExpressionValue(method = "tryShearLivingEntity", at = @At("MIXINEXTRAS:EXPRESSION"))
	private static boolean supportIShearable(boolean original, class_3218 level, class_2338 pos, @Local class_1309 livingEntity) {
		if (livingEntity instanceof IShearable shearable && !(livingEntity instanceof VanillaIShearable)) {
			shearable.onSheared(null, port_lib$passed_stack.get(), level, pos)
					.forEach(drop -> shearable.spawnShearedDrop(level, pos, drop));
			level.method_33596(null, class_5712.field_28730, pos);
		}

		return original;
	}

	@Inject(method = "tryShearLivingEntity", at = @At("TAIL"))
	private static void freeItemStack(class_3218 level, class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
		port_lib$passed_stack.set(null);
	}
}
