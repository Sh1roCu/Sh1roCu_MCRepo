package io.github.fabricators_of_create.porting_lib.entity;

import com.mojang.serialization.Codec;

import io.github.fabricators_of_create.porting_lib.entity.events.living.MobEffectEvent;
import io.netty.buffer.ByteBuf;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Defines a cure that is used to remove {@link class_1291}s from a {@link class_1309}.
 * <p>Cures can be added to or removed from your own effects via {@link class_1291#fillEffectCures(Set, MobEffectInstance)}
 * or any effect by modifying the set of cures on the {@link class_1293} in {@link MobEffectEvent.Added}
 */
public final class EffectCure {
	private static final Map<String, EffectCure> CURES = new ConcurrentHashMap<>();

	public static Codec<EffectCure> CODEC = Codec.STRING.xmap(EffectCure::get, EffectCure::name);
	public static final class_9139<ByteBuf, EffectCure> STREAM_CODEC = class_9135.field_48554.method_56432(EffectCure::get, EffectCure::name);

	/**
	 * {@return all registered cures}
	 * This collection can be kept around, and will update itself in response to changes to the map.
	 * See {@link ConcurrentHashMap#values()} for details.
	 */
	public static Collection<EffectCure> getAllCures() {
		return Collections.unmodifiableCollection(CURES.values());
	}

	/**
	 * Gets or creates a new EffectCure for the given name.
	 */
	public static EffectCure get(String name) {
		return CURES.computeIfAbsent(name, EffectCure::new);
	}

	/**
	 * {@return the name of this cure}
	 */
	public String name() {
		return name;
	}

	@Override
	public String toString() {
		return "EffectCure[" + name + "]";
	}

	private final String name;

	/**
	 * Use {@link #get(String)} to get or create an EffectCure
	 */
	private EffectCure(String name) {
		this.name = name;
	}
}
