package io.github.fabricators_of_create.porting_lib.entity.mixin.client;

import io.github.fabricators_of_create.porting_lib.entity.MultiPartEntity;
import io.github.fabricators_of_create.porting_lib.entity.PartEntity;
import net.minecraft.class_1297;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_761;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_898.class)
public abstract class EntityRenderDispatcherMixin {
	@Inject(method = "renderHitbox", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/LevelRenderer;renderLineBox(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/world/phys/AABB;FFFF)V", ordinal = 0, shift = At.Shift.AFTER))
	private static void renderMultipartHitboxes(class_4587 poseStack, class_4588 vertexConsumer, class_1297 entity, float pPartialTicks, float g, float h, float i, CallbackInfo ci) {
		if (entity instanceof MultiPartEntity pEntity && pEntity.isMultipartEntity()) {
			double d0 = -class_3532.method_16436(pPartialTicks, entity.field_6038, entity.method_23317());
			double d1 = -class_3532.method_16436(pPartialTicks, entity.field_5971, entity.method_23318());
			double d2 = -class_3532.method_16436(pPartialTicks, entity.field_5989, entity.method_23321());

			for(PartEntity<?> part : pEntity.getParts()) {
				poseStack.method_22903();
				double d3 = d0 + class_3532.method_16436(pPartialTicks, part.field_6038, part.method_23317());
				double d4 = d1 + class_3532.method_16436(pPartialTicks, part.field_5971, part.method_23318());
				double d5 = d2 + class_3532.method_16436(pPartialTicks, part.field_5989, part.method_23321());
				poseStack.method_22904(d3, d4, d5);
				class_761.method_22982(poseStack, vertexConsumer, part.method_5829().method_989(-part.method_23317(), -part.method_23318(), -part.method_23321()), 0.25F, 1.0F, 0.0F, 1.0F);
				poseStack.method_22909();
			}
		}
	}
}
