package io.github.fabricators_of_create.porting_lib.entity.injects;

import javax.annotation.Nullable;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface PlayerInjection {
	default float getDigSpeed(class_2680 state, @Nullable class_2338 pos) {
		setDigSpeedContext(pos);
		return ((class_1657) this).method_7351(state);
	}

	default void setDigSpeedContext(@Nullable class_2338 pos) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}
