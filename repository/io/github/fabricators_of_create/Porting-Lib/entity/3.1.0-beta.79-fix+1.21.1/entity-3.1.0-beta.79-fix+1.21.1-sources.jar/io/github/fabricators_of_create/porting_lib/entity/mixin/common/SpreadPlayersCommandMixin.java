package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import io.github.fabricators_of_create.porting_lib.entity.events.EntityTeleportEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_2709;
import net.minecraft.class_3131;
import net.minecraft.class_3218;

@Mixin(class_3131.class)
public abstract class SpreadPlayersCommandMixin {
	@WrapOperation(method = "setPlayerPositions", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;teleportTo(Lnet/minecraft/server/level/ServerLevel;DDDLjava/util/Set;FF)Z"))
	private static boolean onSpreadPlayers(class_1297 instance, class_3218 serverLevel, double x, double y, double z, Set<class_2709> set, float yRot, float xRot, Operation<Boolean> original) {
		EntityTeleportEvent.SpreadPlayersCommand event = EntityHooks.onEntityTeleportSpreadPlayersCommand(instance, x, y, z);

		if (!event.isCanceled()) {
			return original.call(instance,
					serverLevel,
					event.getTargetX(),
					event.getTargetY(),
					event.getTargetZ(),
					set,
					yRot,
					xRot
			);
		}
		return !event.isCanceled();
	}
}
