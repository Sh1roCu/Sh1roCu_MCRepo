package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import java.util.Collection;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;

import io.github.fabricators_of_create.porting_lib.entity.events.EntityInvulnerabilityCheckEvent;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.entity.events.EntityDataEvents;
import io.github.fabricators_of_create.porting_lib.entity.events.EntityEvents;
import io.github.fabricators_of_create.porting_lib.entity.events.MinecartEvents;
import io.github.fabricators_of_create.porting_lib.entity.injects.EntityInjection;

@Mixin(class_1297.class)
public abstract class EntityMixin implements EntityInjection {
	@Unique
	private Collection<class_1542> port_lib$captureDrops = null;

	@Inject(method = "<init>", at = @At("TAIL"))
	private void entitySizeConstructEvent(class_1299<?> entityType, class_1937 level, CallbackInfo ci) {
		EntityEvents.Size sizeEvent = EntityHooks.getEntitySizeForge((class_1297) (Object) this, class_4050.field_18076, this.dimensions, this.eyeHeight);
		this.dimensions = sizeEvent.getNewSize();
		this.eyeHeight = sizeEvent.getNewEyeHeight();
		new EntityEvents.EntityConstructing((class_1297) (Object) this).sendEvent();
	}

	@WrapOperation(method = "refreshDimensions", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getDimensions(Lnet/minecraft/world/entity/Pose;)Lnet/minecraft/world/entity/EntityDimensions;"))
	private class_4048 entitySizeEvent(class_1297 instance, class_4050 pose, Operation<class_4048> original, @Local(index = 1) class_4048 old) {
		class_4048 newD = original.call(instance, pose);
		EntityEvents.Size sizeEvent = EntityHooks.getEntitySizeForge(instance, pose, old, newD, newD.comp_2187());
		return sizeEvent.getNewSize();
	}

	// CAPTURE DROPS

	@WrapWithCondition(
			method = "spawnAtLocation(Lnet/minecraft/world/item/ItemStack;F)Lnet/minecraft/world/entity/item/ItemEntity;",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/Level;addFreshEntity(Lnet/minecraft/world/entity/Entity;)Z"
			)
	)
	public boolean port_lib$captureDrops(class_1937 level, class_1297 entity) {
		if (port_lib$captureDrops != null && entity instanceof class_1542 item) {
			port_lib$captureDrops.add(item);
			return false;
		}
		return true;
	}

	@Unique
	@Override
	public Collection<class_1542> captureDrops() {
		return port_lib$captureDrops;
	}

	@Unique
	@Override
	public Collection<class_1542> captureDrops(Collection<class_1542> value) {
		Collection<class_1542> ret = port_lib$captureDrops;
		port_lib$captureDrops = value;
		return ret;
	}

	@Shadow
	@Nullable
	private class_1297 vehicle;

	@Shadow
	private class_1937 level;

	@Shadow
	public abstract class_1299<?> getType();

	@Shadow
	public abstract int getId();

	@Shadow
	private class_4048 dimensions;

	@Shadow
	public abstract float getEyeHeight();

	@Shadow
	private float eyeHeight;

	@Inject(
			method = "startRiding(Lnet/minecraft/world/entity/Entity;Z)Z",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/entity/Entity;canRide(Lnet/minecraft/world/entity/Entity;)Z",
					shift = At.Shift.BEFORE
			),
			cancellable = true
	)
	public void port_lib$startRiding(class_1297 entity, boolean bl, CallbackInfoReturnable<Boolean> cir) {
		if (!EntityHooks.canMountEntity((class_1297) (Object) this, entity, true))
			cir.setReturnValue(false);
	}

	@Inject(method = "removeVehicle", at = @At(value = "CONSTANT", args = "nullValue=true"), cancellable = true)
	public void port_lib$removeRidingEntity(CallbackInfo ci) {
		if (!EntityHooks.canMountEntity((class_1297) (Object) this, this.vehicle, false))
			ci.cancel();
	}

	@Inject(method = "remove", at = @At("TAIL"))
	public void port_lib$onEntityRemove(class_1297.class_5529 reason, CallbackInfo ci) {
//		EntityEvent.ON_REMOVE.invoker().onRemove((Entity) (Object) this, reason); TODO: PORT
		if ((Object) this instanceof class_1688 cart) {
			MinecartEvents.REMOVE.invoker().minecartRemove(cart, level);
		}
	}

	// custom data

	@Unique
	private class_2487 customData;

	@Inject(
			method = "saveWithoutId",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/entity/Entity;addAdditionalSaveData(Lnet/minecraft/nbt/CompoundTag;)V"
			)
	)
	private void saveCustomData(class_2487 tag, CallbackInfoReturnable<class_2487> cir) {
		if (customData != null && !customData.method_33133()) {
			tag.method_10566("ForgeData", customData);
		}
	}

	@Inject(
			method = "load",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/entity/Entity;readAdditionalSaveData(Lnet/minecraft/nbt/CompoundTag;)V"
			)
	)
	private void loadCustomData(class_2487 tag, CallbackInfo ci) {
		if (tag.method_10545("ForgeData")) {
			customData = tag.method_10562("ForgeData");
		}
	}

	@Override
	public class_2487 getCustomData() {
		if (customData == null)
			customData = new class_2487();
		return customData;
	}

	// data events

	@Inject(method = "saveWithoutId", at = @At("RETURN"))
	public void afterSave(class_2487 nbt, CallbackInfoReturnable<class_2487> cir) {
		EntityDataEvents.SAVE.invoker().onSave((class_1297) (Object) this, nbt);
	}

	@Inject(method = "load", at = @At("RETURN"))
	public void afterLoad(class_2487 nbt, CallbackInfo ci) {
		EntityDataEvents.LOAD.invoker().onLoad((class_1297) (Object) this, nbt);
	}

	@WrapOperation(method = "rideTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;tick()V"))
	private void preEntityTick(class_1297 instance, Operation<Void> original) {
		if (!EntityHooks.fireEntityTickPre(instance).isCanceled()) {
			original.call(instance);
			EntityHooks.fireEntityTickPost(instance);
		}
	}

	// damage events
	@ModifyReturnValue(method = "isInvulnerableTo", at = @At("RETURN"))
	private boolean checkEntityInvulnerableEvent(boolean original, @Local(argsOnly = true) class_1282 damageSource) {
		EntityInvulnerabilityCheckEvent event = new EntityInvulnerabilityCheckEvent((class_1297) (Object) this, damageSource, original);
		event.sendEvent();

		return event.isInvulnerable();
	}
}
