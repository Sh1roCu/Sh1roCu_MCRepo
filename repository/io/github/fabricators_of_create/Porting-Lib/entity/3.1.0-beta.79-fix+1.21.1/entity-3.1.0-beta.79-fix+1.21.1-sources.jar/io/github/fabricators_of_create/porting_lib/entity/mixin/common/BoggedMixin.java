package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.extensions.VanillaIShearable;
import net.minecraft.class_9254;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_9254.class)
public class BoggedMixin implements VanillaIShearable {
}
