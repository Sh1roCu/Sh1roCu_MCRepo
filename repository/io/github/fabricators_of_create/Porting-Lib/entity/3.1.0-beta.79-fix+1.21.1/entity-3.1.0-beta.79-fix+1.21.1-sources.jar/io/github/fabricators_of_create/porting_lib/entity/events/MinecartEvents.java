package io.github.fabricators_of_create.porting_lib.entity.events;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_2487;

public class MinecartEvents {
	public static final Event<Spawn> SPAWN = EventFactory.createArrayBacked(Spawn.class, callbacks -> (cart, level) -> {
		for (Spawn callback : callbacks) {
			callback.minecartSpawn(cart, level);
		}
	});

	public static final Event<Read> READ = EventFactory.createArrayBacked(Read.class, callbacks -> (cart, data) -> {
		for (Read callback : callbacks) {
			callback.minecartRead(cart, data);
		}
	});

	public static final Event<Write> WRITE = EventFactory.createArrayBacked(Write.class, callbacks -> (cart, data) -> {
		for (Write callback : callbacks) {
			callback.minecartWrite(cart, data);
		}
	});

	public static final Event<Remove> REMOVE = EventFactory.createArrayBacked(Remove.class, callbacks -> (cart, level) -> {
		for (Remove callback : callbacks) {
			callback.minecartRemove(cart, level);
		}
	});

	public interface Spawn {
		void minecartSpawn(class_1688 cart, class_1937 level);
	}

	public interface Read {
		void minecartRead(class_1688 cart, class_2487 data);
	}

	public interface Write {
		void minecartWrite(class_1688 cart, class_2487 data);
	}

	public interface Remove {
		void minecartRemove(class_1688 cart, class_1937 level);
	}
}
