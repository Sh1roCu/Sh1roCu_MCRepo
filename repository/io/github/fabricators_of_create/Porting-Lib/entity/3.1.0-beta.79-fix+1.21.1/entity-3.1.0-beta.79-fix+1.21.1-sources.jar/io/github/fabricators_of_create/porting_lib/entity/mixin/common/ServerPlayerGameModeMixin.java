package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.sugar.Local;

import com.llamalad7.mixinextras.sugar.Share;

import com.llamalad7.mixinextras.sugar.ref.LocalRef;

import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import io.github.fabricators_of_create.porting_lib.entity.events.player.PlayerInteractEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.player.PlayerInteractEvent.RightClickBlock;
import net.fabricmc.fabric.api.util.TriState;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3225.class)
public abstract class ServerPlayerGameModeMixin {
	@Shadow
	public abstract boolean isCreative();

	@Shadow
	@Final
	protected class_3222 player;

	@Inject(method = "handleBlockBreakAction", at = @At("HEAD"), cancellable = true)
	public void port_lib$blockBreak(class_2338 pos, class_2846.class_2847 action, class_2350 direction, int worldHeight, int i, CallbackInfo ci, @Share("event")LocalRef<PlayerInteractEvent.LeftClickBlock> eventRef) {
		PlayerInteractEvent.LeftClickBlock event = EntityHooks.onLeftClickBlock(player, pos, direction, action);
		eventRef.set(event);
		if (event.isCanceled()) {
			ci.cancel();
		}
	}

	@WrapWithCondition(method = "handleBlockBreakAction", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;attack(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)V"))
	private boolean canAttack(class_2680 instance, class_1937 level, class_2338 blockPos, class_1657 player, @Share("event")LocalRef<PlayerInteractEvent.LeftClickBlock> eventRef) {
		return eventRef.get().getUseBlock() != TriState.FALSE;
	}

	@Inject(method = "useItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getCount()I", ordinal = 0), cancellable = true)
	private void onItemRightClick(class_3222 player, class_1937 level, class_1799 itemStack, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
		class_1269 cancelResult = EntityHooks.onItemRightClick(player, hand);
		if (cancelResult != null)
			cir.setReturnValue(cancelResult);
	}

	@ModifyExpressionValue(method = "useItemOn", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/Block;isEnabled(Lnet/minecraft/world/flag/FeatureFlagSet;)Z"))
	private boolean onRightClickBlock(
			boolean original, class_3222 player, class_1937 level, class_1799 itemStack, class_1268 hand, class_3965 hitResult, @Local(index = 6) class_2338 pos,
			@Share("event") LocalRef<PlayerInteractEvent.RightClickBlock> eventRef
			) {
		if (original) {
			PlayerInteractEvent.RightClickBlock event = EntityHooks.onRightClickBlock(player, hand, pos, hitResult);
			eventRef.set(event);
			if (event.isCanceled())
				return false;
		}
		return original;
	}

	@ModifyReturnValue(method = "useItemOn", at = @At(value = "RETURN", ordinal = 0))
	private class_1269 changeRightClickResult(class_1269 original, @Share("event") LocalRef<PlayerInteractEvent.RightClickBlock> eventRef) {
		var event = eventRef.get();
		if (event.isCanceled())
			return event.getCancellationResult();
		return original;
	}
}
