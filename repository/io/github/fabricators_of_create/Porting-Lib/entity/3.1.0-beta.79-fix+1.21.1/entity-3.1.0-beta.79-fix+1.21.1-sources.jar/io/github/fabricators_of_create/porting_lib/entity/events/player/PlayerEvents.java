package io.github.fabricators_of_create.porting_lib.entity.events.player;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.player.PlayerEvent;
import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.Optional;

/**
 * All player related events
 **/
public final class PlayerEvents {
	private PlayerEvents() {}

	/**
	 * BreakSpeed is fired when a player attempts to harvest a block.<br>
	 * This event is fired whenever a player attempts to harvest a block in
	 * {@link class_1657#getDigSpeed(BlockState, BlockPos)}.<br>
	 * <br>
	 * This event is fired via the {@link EntityHooks#getBreakSpeed(class_1657, class_2680, float, class_2338)}.<br>
	 * <br>
	 * {@link #state} contains the block being broken. <br>
	 * {@link #originalSpeed} contains the original speed at which the player broke the block. <br>
	 * {@link #newSpeed} contains the newSpeed at which the player will break the block. <br>
	 * {@link #pos} contains the coordinates at which this event is occurring. Optional value.<br>
	 * <br>
	 * This event is {@link CancellableEvent}.<br>
	 * If it is canceled, the player is unable to break the block.<br>
	 **/
	public static class BreakSpeed extends PlayerEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onBreakSpeed(event);
		});

		private static final class_2338 LEGACY_UNKNOWN = new class_2338(0, -1, 0);
		private final class_2680 state;
		private final float originalSpeed;
		private float newSpeed = 0.0f;
		private final Optional<class_2338> pos; // Y position of -1 notes unknown location

		public BreakSpeed(class_1657 player, class_2680 state, float original, @Nullable class_2338 pos) {
			super(player);
			this.state = state;
			this.originalSpeed = original;
			this.setNewSpeed(original);
			this.pos = Optional.ofNullable(pos);
		}

		public class_2680 getState() {
			return state;
		}

		public float getOriginalSpeed() {
			return originalSpeed;
		}

		public float getNewSpeed() {
			return newSpeed;
		}

		public void setNewSpeed(float newSpeed) {
			this.newSpeed = newSpeed;
		}

		public Optional<class_2338> getPosition() {
			return this.pos;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onBreakSpeed(this);
		}

		public interface Callback {
			void onBreakSpeed(BreakSpeed event);
		}
	}

	/**
	 * NameFormat is fired when a player's display name is retrieved.<br>
	 * This event is fired whenever a player's name is retrieved in
	 * {@link class_1657#method_5476()} or {@link class_1657#refreshDisplayName()}.<br>
	 * <br>
	 * This event is fired via the {@link EntityHooks#getPlayerDisplayName(Player, Component)}.<br>
	 * <br>
	 * {@link #username} contains the username of the player.
	 * {@link #displayname} contains the display name of the player.
	 * <br>
	 * This event is not {@link CancellableEvent}.
	 **/
	public static class NameFormat extends PlayerEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onNameFormat(event);
		});

		private final class_2561 username;
		private class_2561 displayname;

		public NameFormat(class_1657 player, class_2561 username) {
			super(player);
			this.username = username;
			this.setDisplayname(username);
		}

		public class_2561 getUsername() {
			return username;
		}

		public class_2561 getDisplayname() {
			return displayname;
		}

		public void setDisplayname(class_2561 displayname) {
			this.displayname = displayname;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onNameFormat(this);
		}

		public interface Callback {
			void onNameFormat(NameFormat event);
		}
	}

	/**
	 * TabListNameFormat is fired when a player's display name for the tablist is retrieved.<br>
	 * This event is fired whenever a player's display name for the tablist is retrieved in
	 * {@link class_3222#method_14206()} or {@link class_3222#refreshTabListName()}.<br>
	 * <br>
	 * This event is fired via the {@link EntityHooks#getPlayerTabListDisplayName(Player)}.<br>
	 * <br>
	 * {@link #getDisplayName()} contains the display name of the player or null if the client should determine the display name itself.
	 * <br>
	 * This event is not {@link CancellableEvent}.
	 **/
	public static class TabListNameFormat extends PlayerEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onTabListNameFormat(event);
		});

		@Nullable
		private class_2561 displayName;

		public TabListNameFormat(class_1657 player) {
			super(player);
		}

		@Nullable
		public class_2561 getDisplayName() {
			return displayName;
		}

		public void setDisplayName(@Nullable class_2561 displayName) {
			this.displayName = displayName;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onTabListNameFormat(this);
		}

		public interface Callback {
			void onTabListNameFormat(TabListNameFormat event);
		}
	}

	/**
	 * Fired when the EntityPlayer is cloned, typically caused by the impl sending a RESPAWN_PLAYER event.
	 * Either caused by death, or by traveling from the End to the overworld.
	 */
	public static class Clone extends PlayerEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onClone(event);
		});

		private final class_1657 original;
		private final boolean wasDeath;

		public Clone(class_1657 _new, class_1657 oldPlayer, boolean wasDeath) {
			super(_new);
			this.original = oldPlayer;
			this.wasDeath = wasDeath;
		}

		/**
		 * The old EntityPlayer that this new entity is a clone of.
		 */
		public class_1657 getOriginal() {
			return original;
		}

		/**
		 * True if this event was fired because the player died.
		 * False if it was fired because the entity switched dimensions.
		 */
		public boolean isWasDeath() {
			return wasDeath;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onClone(this);
		}

		public interface Callback {
			void onClone(Clone event);
		}
	}

	/**
	 * Fired when an Entity is started to be "tracked" by this player (the player receives updates about this entity, e.g. motion).
	 *
	 */
	public static class StartTracking extends PlayerEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onStartTracking(event);
		});

		private final class_1297 target;

		public StartTracking(class_1657 player, class_1297 target) {
			super(player);
			this.target = target;
		}

		/**
		 * The Entity now being tracked.
		 */
		public class_1297 getTarget() {
			return target;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onStartTracking(this);
		}

		public interface Callback {
			void onStartTracking(StartTracking event);
		}
	}

	/**
	 * Fired when an Entity is stopped to be "tracked" by this player (the player no longer receives updates about this entity, e.g. motion).
	 *
	 */
	public static class StopTracking extends PlayerEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onStopTracking(event);
		});

		private final class_1297 target;

		public StopTracking(class_1657 player, class_1297 target) {
			super(player);
			this.target = target;
		}

		/**
		 * The Entity no longer being tracked.
		 */
		public class_1297 getTarget() {
			return target;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onStopTracking(this);
		}

		public interface Callback {
			void onStopTracking(StopTracking event);
		}
	}

	/**
	 * The player is being loaded from the world save. Note that the
	 * player won't have been added to the world yet. Intended to
	 * allow mods to load an additional file from the players directory
	 * containing additional mod related player data.
	 */
	public static class LoadFromFile extends PlayerEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onLoadFromFile(event);
		});

		private final File playerDirectory;
		private final String playerUUID;

		public LoadFromFile(class_1657 player, File originDirectory, String playerUUID) {
			super(player);
			this.playerDirectory = originDirectory;
			this.playerUUID = playerUUID;
		}

		/**
		 * Construct and return a recommended file for the supplied suffix
		 *
		 * @param suffix The suffix to use.
		 */
		public File getPlayerFile(String suffix) {
			if ("dat".equals(suffix)) throw new IllegalArgumentException("The suffix 'dat' is reserved");
			return new File(this.getPlayerDirectory(), this.getPlayerUUID() + "." + suffix);
		}

		/**
		 * The directory where player data is being stored. Use this
		 * to locate your mod additional file.
		 */
		public File getPlayerDirectory() {
			return playerDirectory;
		}

		/**
		 * The UUID is the standard for player related file storage.
		 * It is broken out here for convenience for quick file generation.
		 */
		public String getPlayerUUID() {
			return playerUUID;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onLoadFromFile(this);
		}

		public interface Callback {
			void onLoadFromFile(LoadFromFile event);
		}
	}

	/**
	 * The player is being saved to the world store. Note that the
	 * player may be in the process of logging out or otherwise departing
	 * from the world. Don't assume it's association with the world.
	 * This allows mods to load an additional file from the players directory
	 * containing additional mod related player data.
	 * <br>
	 * Use this event to save the additional mod related player data to the world.
	 *
	 * <br>
	 * <em>WARNING</em>: Do not overwrite the player's .dat file here. You will
	 * corrupt the world state.
	 */
	public static class SaveToFile extends PlayerEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onSaveToFile(event);
		});

		private final File playerDirectory;
		private final String playerUUID;

		public SaveToFile(class_1657 player, File originDirectory, String playerUUID) {
			super(player);
			this.playerDirectory = originDirectory;
			this.playerUUID = playerUUID;
		}

		/**
		 * Construct and return a recommended file for the supplied suffix
		 *
		 * @param suffix The suffix to use.
		 */
		public File getPlayerFile(String suffix) {
			if ("dat".equals(suffix)) throw new IllegalArgumentException("The suffix 'dat' is reserved");
			return new File(this.getPlayerDirectory(), this.getPlayerUUID() + "." + suffix);
		}

		/**
		 * The directory where player data is being stored. Use this
		 * to locate your mod additional file.
		 */
		public File getPlayerDirectory() {
			return playerDirectory;
		}

		/**
		 * The UUID is the standard for player related file storage.
		 * It is broken out here for convenience for quick file generation.
		 */
		public String getPlayerUUID() {
			return playerUUID;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onSaveToFile(this);
		}

		public interface Callback {
			void onSaveToFile(SaveToFile event);
		}
	}

	public static class ItemCraftedEvent extends PlayerEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onItemCrafted(event);
		});

		private final class_1799 crafting;
		private final class_1263 craftMatrix;

		public ItemCraftedEvent(class_1657 player, class_1799 crafting, class_1263 craftMatrix) {
			super(player);
			this.crafting = crafting;
			this.craftMatrix = craftMatrix;
		}

		public class_1799 getCrafting() {
			return this.crafting;
		}

		public class_1263 getInventory() {
			return this.craftMatrix;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onItemCrafted(this);
		}

		public interface Callback {
			void onItemCrafted(ItemCraftedEvent event);
		}
	}

	public static class ItemSmeltedEvent extends PlayerEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onItemSmelted(event);
		});

		private final class_1799 smelting;

		public ItemSmeltedEvent(class_1657 player, class_1799 crafting) {
			super(player);
			this.smelting = crafting;
		}

		public class_1799 getSmelting() {
			return this.smelting;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onItemSmelted(this);
		}

		public interface Callback {
			void onItemSmelted(ItemSmeltedEvent event);
		}
	}

	public static class PlayerLoggedInEvent extends PlayerEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onPlayerLoggedIn(event);
		});

		public PlayerLoggedInEvent(class_1657 player) {
			super(player);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onPlayerLoggedIn(this);
		}

		public interface Callback {
			void onPlayerLoggedIn(PlayerLoggedInEvent event);
		}
	}

	public static class PlayerLoggedOutEvent extends PlayerEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onPlayerLoggedOut(event);
		});

		public PlayerLoggedOutEvent(class_1657 player) {
			super(player);
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onPlayerLoggedOut(this);
		}

		public interface Callback {
			void onPlayerLoggedOut(PlayerLoggedOutEvent event);
		}
	}

	/**
	 * Fired when the game type of a server player is changed to a different value than what it was previously. Eg Creative to Survival, not Survival to Survival.
	 * If the event is cancelled the game mode of the player is not changed and the value of <code>newGameMode</code> is ignored.
	 */
	public static class PlayerChangeGameModeEvent extends PlayerEvent implements CancellableEvent {
		public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
			for (final Callback callback : callbacks)
				callback.onPlayerChangeGameMode(event);
		});

		private final class_1934 currentGameMode;
		private class_1934 newGameMode;

		public PlayerChangeGameModeEvent(class_1657 player, class_1934 currentGameMode, class_1934 newGameMode) {
			super(player);
			this.currentGameMode = currentGameMode;
			this.newGameMode = newGameMode;
		}

		public class_1934 getCurrentGameMode() {
			return currentGameMode;
		}

		public class_1934 getNewGameMode() {
			return newGameMode;
		}

		/**
		 * Sets the game mode the player will be changed to if this event is not cancelled.
		 */
		public void setNewGameMode(class_1934 newGameMode) {
			this.newGameMode = newGameMode;
		}

		@Override
		public void sendEvent() {
			EVENT.invoker().onPlayerChangeGameMode(this);
		}

		public interface Callback {
			void onPlayerChangeGameMode(PlayerChangeGameModeEvent event);
		}
	}
}
