package io.github.fabricators_of_create.porting_lib.entity.events.living;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.living.LivingEvent;
import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

/**
 * LivingAttackEvent is fired when a living Entity is attacked. <br>
 * This event is fired whenever an Entity is attacked in
 * {@link class_1309#method_5643(class_1282, float)} and
 * {@link class_1657#method_5643(class_1282, float)}. <br>
 * <br>
 * This event is fired via the {@link EntityHooks#onLivingAttack(class_1309, class_1282, float)}.<br>
 * <br>
 * {@link #source} contains the DamageSource of the attack. <br>
 * {@link #amount} contains the amount of damage dealt to the entity. <br>
 * <br>
 * This event is {@link CancellableEvent}.<br>
 * If this event is canceled, the Entity does not take attack damage.<br>
 **/
public class LivingAttackEvent extends LivingEvent implements CancellableEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (Callback callback : callbacks)
			callback.onLivingAttack(event);
	});

	private final class_1282 source;
	private final float amount;

	public LivingAttackEvent(class_1309 entity, class_1282 source, float amount) {
		super(entity);
		this.source = source;
		this.amount = amount;
	}

	public class_1282 getSource() {
		return source;
	}

	public float getAmount() {
		return amount;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onLivingAttack(this);
	}

	public interface Callback {
		void onLivingAttack(LivingAttackEvent event);
	}
}
