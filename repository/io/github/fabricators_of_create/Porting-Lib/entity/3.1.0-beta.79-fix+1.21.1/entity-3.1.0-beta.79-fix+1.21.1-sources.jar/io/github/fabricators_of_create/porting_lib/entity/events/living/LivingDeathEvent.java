package io.github.fabricators_of_create.porting_lib.entity.events.living;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.living.LivingEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_3222;

/**
 * Note this event is fired after fabrics {@link net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents#ALLOW_DEATH}.
 * You should generally try to use fabric's event
 * LivingDeathEvent is fired when an Entity dies. <br>
 * This event is fired whenever an Entity dies in
 * {@link class_1309#method_6078(class_1282)},
 * {@link class_1657#method_6078(class_1282)}, and
 * {@link class_3222#method_6078(class_1282)}. <br>
 * <br>
 * {@link #source} contains the DamageSource that caused the entity to die. <br>
 * <br>
 * This event is {@link CancellableEvent}.<br>
 * If this event is canceled, the Entity does not die.<br>
 * <br>
 * This event does not have a result.<br>
 * <br>
 **/
@Deprecated
public class LivingDeathEvent extends LivingEvent implements CancellableEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (Callback e : callbacks)
			e.onLivingDeath(event);
	});

	private final class_1282 source;

	public LivingDeathEvent(class_1309 entity, class_1282 source) {
		super(entity);
		this.source = source;
	}

	public class_1282 getSource() {
		return source;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onLivingDeath(this);
	}

	@FunctionalInterface
	public interface Callback {
		void onLivingDeath(LivingDeathEvent event);
	}
}
