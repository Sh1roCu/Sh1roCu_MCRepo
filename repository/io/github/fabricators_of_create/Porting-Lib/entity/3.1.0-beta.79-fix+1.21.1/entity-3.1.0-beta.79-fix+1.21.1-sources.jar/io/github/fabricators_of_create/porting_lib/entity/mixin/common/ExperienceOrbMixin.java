package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.events.player.PlayerXpEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.player.PlayerXpEvent.PickupXp;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1303;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1303.class)
public abstract class ExperienceOrbMixin extends class_1297 {
	public ExperienceOrbMixin(class_1299<?> variant, class_1937 world) {
		super(variant, world);
	}

	@Inject(method = "playerTouch", at = @At(value = "FIELD", target = "Lnet/minecraft/world/entity/player/Player;takeXpDelay:I", ordinal = 1), cancellable = true)
	private void port_lib$onPlayerPickupXp(class_1657 player, CallbackInfo ci) {
		var pickupXp = new PlayerXpEvent.PickupXp(player, (class_1303) (Object) this);
		pickupXp.sendEvent();
		if (pickupXp.isCanceled())
			ci.cancel();
	}
}
