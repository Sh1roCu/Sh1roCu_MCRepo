package io.github.fabricators_of_create.porting_lib.entity.events;

import io.github.fabricators_of_create.porting_lib.core.event.CancellableEvent;
import io.github.fabricators_of_create.porting_lib.core.event.entity.EntityEvent;
import io.github.fabricators_of_create.porting_lib.entity.EntityHooks;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1676;
import net.minecraft.class_239;

/**
 * This event is fired when a projectile entity impacts something.<br>
 * This event is fired via {@link EntityHooks#onProjectileImpact(class_1676, class_239)}
 * This event is fired for all vanilla projectiles by Porting Lib,
 * custom projectiles should fire this event and check the result in a similar fashion.
 * This event is cancelable. When canceled, the impact will not be processed and the projectile will continue flying.
 * Killing or other handling of the entity after event cancellation is up to the modder.
 */
public class ProjectileImpactEvent extends EntityEvent implements CancellableEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (final Callback callback : callbacks)
			callback.onImpact(event);
	});

	private final class_239 ray;
	private final class_1676 projectile;

	public ProjectileImpactEvent(class_1676 projectile, class_239 ray) {
		super(projectile);
		this.ray = ray;
		this.projectile = projectile;
	}

	public class_239 getRayTraceResult() {
		return ray;
	}

	public class_1676 getProjectile() {
		return projectile;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onImpact(this);
	}

	public interface Callback {
		void onImpact(ProjectileImpactEvent event);
	}
}
