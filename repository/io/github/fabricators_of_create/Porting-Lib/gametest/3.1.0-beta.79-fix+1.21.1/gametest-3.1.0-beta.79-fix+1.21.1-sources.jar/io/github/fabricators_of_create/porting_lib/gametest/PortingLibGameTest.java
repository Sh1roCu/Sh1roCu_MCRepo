package io.github.fabricators_of_create.porting_lib.gametest;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Comparator;
import java.util.Objects;
import java.util.stream.Stream;

import io.github.fabricators_of_create.porting_lib.gametest.quickexport.AreaSelection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

import io.github.fabricators_of_create.porting_lib.gametest.infrastructure.CustomGameTestHelper;
import io.github.fabricators_of_create.porting_lib.gametest.infrastructure.ExtendedTestFunction;
import io.github.fabricators_of_create.porting_lib.gametest.infrastructure.GameTestGroup;
import io.github.fabricators_of_create.porting_lib.gametest.quickexport.AreaSelectorItem;
import io.github.fabricators_of_create.porting_lib.gametest.quickexport.QuickExportCommand;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4529;
import net.minecraft.class_7923;
import net.minecraft.class_9331;

public class PortingLibGameTest implements ModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("Porting Lib GameTest");
	public static final boolean AREA_SELECTOR_ENABLED = checkEnabled();
	public static final class_1792 AREA_SELECTOR = AREA_SELECTOR_ENABLED ? new AreaSelectorItem(new class_1792.class_1793()) : null;
	public static final class_9331<AreaSelection> AREA_SELECTOR_DATA_COMPONENT = AREA_SELECTOR_ENABLED ? class_9331.<AreaSelection>method_57873().method_57881(AreaSelection.CODEC).method_57882(AreaSelection.STREAM_CODEC).method_57880() : null;

	@Override
	public void onInitialize() {
		if (AREA_SELECTOR_ENABLED) {
			class_2378.method_10230(class_7923.field_41178, class_2960.method_60655("porting_lib", "area_selector"), AREA_SELECTOR);
			class_2378.method_10230(class_7923.field_49658, class_2960.method_60655("porting_lib", "area_selector"), AREA_SELECTOR_DATA_COMPONENT);
			QuickExportCommand.register();
		} else {
			LOGGER.info("Porting Lib GameTest: Area Selector and quickexport disabled.");
		}
	}

	/**
	 * Get all test functions from the given classes. This enables the functionality
	 * of {@link CustomGameTestHelper} and {@link GameTestGroup}.
	 */
	public static Collection<class_4529> getTestsFrom(Class<?>... classes) {
		return Stream.of(classes)
				.map(Class::getDeclaredMethods)
				.flatMap(Stream::of)
				.map(ExtendedTestFunction::of)
				.filter(Objects::nonNull)
				.sorted(Comparator.comparing(class_4529::comp_2219))
				.toList();
	}

	private static boolean checkEnabled() {
		Path config = FabricLoader.getInstance().getConfigDir().resolve("porting_lib").resolve("gametest.json");
		if (!Files.exists(config))
			return true;
		try {
			JsonElement element = JsonParser.parseString(Files.readString(config));
			if (!(element instanceof JsonObject json))
				throw new JsonParseException("Config is not a JSON object");
			JsonElement disableElement = json.get("disable_area_selector");
			if (disableElement == null)
				return true;
			if (!(disableElement instanceof JsonPrimitive disabled) || !disabled.isBoolean())
				throw new JsonParseException("Element 'disable_area_selector' must be a boolean");
			return !disabled.getAsBoolean();
		} catch (IOException | JsonParseException e) {
			throw new RuntimeException("Porting Lib GameTest: Failed to read config", e);
		}
	}
}
