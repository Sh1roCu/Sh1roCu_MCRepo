package io.github.fabricators_of_create.porting_lib.gametest.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import io.github.fabricators_of_create.porting_lib.gametest.extensions.StructureBlockEntityExtensions;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2633;
import net.minecraft.class_7225;

@Mixin(class_2633.class)
public class StructureBlockEntityMixin implements StructureBlockEntityExtensions {
	@Unique
	private String qualifiedTestName;

	@Override
	public void setQualifiedTestName(String qualifiedTestName) {
		this.qualifiedTestName = qualifiedTestName;
	}

	@Override
	public String getQualifiedTestName() {
		return qualifiedTestName;
	}

	@Inject(method = "saveAdditional", at = @At("RETURN"))
	private void saveQualifiedTestName(class_2487 nbt, class_7225.class_7874 provider, CallbackInfo ci) {
		if (qualifiedTestName != null)
			nbt.method_10582("PortingLib$ExtendedGameTestFunction", qualifiedTestName);
	}

	@Inject(method = "loadAdditional", at = @At("RETURN"))
	private void loadQualifiedTestName(class_2487 nbt, class_7225.class_7874 provider, CallbackInfo ci) {
		if (nbt.method_10573("PortingLib$ExtendedGameTestFunction", class_2520.field_33258))
			this.qualifiedTestName = nbt.method_10558("PortingLib$ExtendedGameTestFunction");
	}
}
