package io.github.fabricators_of_create.porting_lib.gametest.infrastructure;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_2338;
import net.minecraft.class_2470;
import net.minecraft.class_4516;
import net.minecraft.class_4525;
import net.minecraft.class_4529;
import net.minecraft.class_6302;
import net.minecraft.class_6303;
import org.jetbrains.annotations.ApiStatus.Internal;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import io.github.fabricators_of_create.porting_lib.gametest.PortingLibGameTest;
import io.github.fabricators_of_create.porting_lib.gametest.extensions.StructureBlockEntityExtensions;

/**
 * An extension to game tests implementing functionality for {@link CustomGameTestHelper} and {@link GameTestGroup}.
 * To use, create a {@link class_6303} that provides tests using {@link PortingLibGameTest#getTestsFrom(Class[])}.
 */
public class ExtendedTestFunction {
	@Internal
	public static final Map<String, ExtendedTestFunction> NAMES_TO_FUNCTIONS = new HashMap<>();

	public final String fullName;
	public final String simpleName;
	public final class_4529 testFunction;

	protected ExtendedTestFunction(String fullName, String simpleName, String pBatchName,
								 String pStructureName, class_2470 pRotation, int pMaxTicks, long pSetupTicks,
								 boolean pRequired, int pMaxAttempts, int pRequiredSuccesses, Consumer<class_4516> pFunction) {
		testFunction = new class_4529(pBatchName, simpleName, pStructureName, pRotation, pMaxTicks, pSetupTicks, pRequired, false, pMaxAttempts, pRequiredSuccesses, true, pFunction);
		this.fullName = fullName;
		this.simpleName = simpleName;
		NAMES_TO_FUNCTIONS.put(fullName, this);
	}

	@Nullable
	public static class_4529 of(Method method) {
		class_6302 gt = method.getAnnotation(class_6302.class);
		if (gt == null) // skip non-test methods
			return null;
		Class<?> owner = method.getDeclaringClass();
		String qualifiedName = owner.getSimpleName() + "." + method.getName();
		CustomGameTestHelper customHelper = getCustomHelper(method, owner);
		validateTestMethod(method, gt, owner, customHelper, qualifiedName);

		String structure = getStructure(gt, owner);
		class_2470 rotation = class_4525.method_29408(gt.method_35934());

		String fullName = owner.getName() + '.' + method.getName();
		String simpleName = owner.getSimpleName() + '.' + method.getName();
		return new ExtendedTestFunction(
				// use structure for test name since that's what MC fills structure blocks with for some reason
				fullName, simpleName, gt.method_35933(), structure, rotation, gt.method_35932(), gt.method_35937(),
				gt.method_35935(), gt.method_35938(), gt.method_35939(), run(fullName, asConsumer(method))
		).testFunction;
	}

	private static void validateTestMethod(Method method, class_6302 gt, Class<?> owner, CustomGameTestHelper customHelper, String qualifiedName) {
		if (gt.method_35936().isEmpty())
			throw new IllegalArgumentException(qualifiedName + " must provide a template structure");

		int modifiers = method.getModifiers();
		if (!Modifier.isStatic(modifiers) || !Modifier.isPublic(modifiers))
			throw new IllegalArgumentException(qualifiedName + " must be public and static");

		if (!Modifier.isPublic(owner.getModifiers()))
			throw new IllegalStateException(owner.getName() + " must be public");

		if (method.getReturnType() != void.class)
			throw new IllegalArgumentException(qualifiedName + " must return void");

		Class<? extends class_4516> helperClass = customHelper != null ? customHelper.value() : class_4516.class;
		if (method.getParameterCount() != 1 || method.getParameterTypes()[0] != helperClass)
			throw new IllegalArgumentException(qualifiedName + " must take 1 parameter of type " + helperClass.getSimpleName());
	}

	private static String getStructure(class_6302 gt, Class<?> owner) {
		GameTestGroup group = owner.getAnnotation(GameTestGroup.class);
		String structure = gt.method_35936();
		if (group == null || structure.contains(":")) // override group if a full ID
			return structure;
		String groupDir = group.path();
		String path = groupDir.isEmpty() ? structure : groupDir + '/' + structure;
		// namespace:gametest/path/structure || namespace:gametest/structure
		return group.namespace() + ":gametest/" + path;
	}

	private static CustomGameTestHelper getCustomHelper(Method method, Class<?> owner) {
		CustomGameTestHelper methodCustom = method.getAnnotation(CustomGameTestHelper.class);
		return methodCustom != null ? methodCustom : owner.getAnnotation(CustomGameTestHelper.class);
	}

	private static Consumer<class_4516> asConsumer(Method method) {
		return (helper) -> {
			try {
				method.invoke(null, helper);
			} catch (IllegalAccessException | InvocationTargetException e) {
				throw new RuntimeException(e);
			}
		};
	}

	public static Consumer<class_4516> run(String fullName, @NotNull Consumer<class_4516> helper) {
		return consumer -> {
			helper.andThen(gameTestHelper -> {
				// give structure block test info
				StructureBlockEntityExtensions be = (StructureBlockEntityExtensions) gameTestHelper.method_36014(class_2338.field_10980);
				be.setQualifiedTestName(fullName);
			}).accept(consumer);
		};
	}
}
