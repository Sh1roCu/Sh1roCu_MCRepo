package io.github.fabricators_of_create.porting_lib.gametest.quickexport;

import io.github.fabricators_of_create.porting_lib.gametest.PortingLibGameTest;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class AreaSelectorItem extends class_1792 {
	public static final String AREA_KEY = "area";

	public static final class_2561 REQUIRES_OP = lang("requires_op");
	public static final class_2561 SUCCESS_FIRST = lang("success_first");
	public static final class_2561 SUCCESS_SECOND = lang("success_second");
	public static final class_2561 TO_RESET = lang("to_reset");
	public static final class_2561 RESET = lang("reset");

	public AreaSelectorItem(class_1793 settings) {
		super(settings);
	}

	@Override
	@NotNull
	public class_1271<class_1799> method_7836(@NotNull class_1937 world, @NotNull class_1657 user, @NotNull class_1268 hand) {
		class_1799 held = user.method_5998(hand);
		if (!(user instanceof class_3222 player))
			return class_1271.method_22427(held);
		class_1269 baseResult = baseUse(player, held);
		if (baseResult != null)
			return new class_1271<>(baseResult, held);
		selectArea(player, held, getLookTarget(player));
		return class_1271.method_22427(held);
	}

	@Override
	@NotNull
	public class_1269 method_7884(@NotNull class_1838 context) {
		if (!(context.method_8036() instanceof class_3222 player))
			return class_1269.field_5812;
		class_1799 held = context.method_8041();
		class_1269 baseResult = baseUse(player, held);
		if (baseResult != null)
			return baseResult;

		class_2338 pos = context.method_8037();
		selectArea(player, held, pos);

		return class_1269.field_5812;
	}

	@Nullable
	private class_1269 baseUse(class_3222 player, class_1799 held) {
		if (!player.method_7338()) {
			player.method_43502(REQUIRES_OP, true);
			return class_1269.field_5811;
		}
		if (player.method_5715()) {
			held.method_57381(PortingLibGameTest.AREA_SELECTOR_DATA_COMPONENT);
			player.method_43502(RESET, true);
			return class_1269.field_5812;
		}
		return null;
	}

	private void selectArea(class_3222 player, class_1799 held, class_2338 pos) {
		AreaSelection area = getArea(held);
		if (area == null)
			area = new AreaSelection(null, null);

		if (area.first == null) {
			area.first = pos;
			player.method_43502(SUCCESS_FIRST, true);
			setArea(held, area);
		} else if (area.second == null) {
			area.second = pos;
			player.method_43502(SUCCESS_SECOND, true);
			setArea(held, area);
		} else {
			player.method_43502(TO_RESET, true);
		}
	}

	@Override
	public boolean method_7886(@NotNull class_1799 stack) {
		return true;
	}

	public static AreaSelection getArea(class_1799 stack) {
		AreaSelection area = stack.method_57824(PortingLibGameTest.AREA_SELECTOR_DATA_COMPONENT);
		if (area != null)
			return area.first != null ? area : null;
		return null;
	}

	public static void setArea(class_1799 stack, AreaSelection area) {
		stack.method_57379(PortingLibGameTest.AREA_SELECTOR_DATA_COMPONENT, area);
	}

	public static class_2338 getLookTarget(class_1657 player) {
		class_239 hit = player.method_5745(5, 0, false);
		if (hit instanceof class_3965 blockHit)
			return blockHit.method_17777();
		return class_2338.method_49638(hit.method_17784());
	}

	private static class_2561 lang(String type) {
		return class_2561.method_43471("area_selector.use.feedback." + type);
	}
}
