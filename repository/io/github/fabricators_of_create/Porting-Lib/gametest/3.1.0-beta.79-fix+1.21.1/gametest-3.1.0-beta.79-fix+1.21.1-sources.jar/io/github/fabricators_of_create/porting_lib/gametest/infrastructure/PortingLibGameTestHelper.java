package io.github.fabricators_of_create.porting_lib.gametest.infrastructure;

import java.util.Arrays;
import java.util.List;

import net.fabricmc.fabric.api.transfer.v1.storage.StorageUtil;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;

import it.unimi.dsi.fastutil.objects.Object2LongArrayMap;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2401;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3341;
import net.minecraft.class_4516;
import net.minecraft.class_4517;
import net.minecraft.class_7923;

/**
 * An extension to vanilla's {@link class_4516} that provides many more helper methods.
 * To use this, see {@link ExtendedTestFunction}.
 */
public class PortingLibGameTestHelper extends class_4516 {
	public static final int TICKS_PER_SECOND = 20;
	public static final int TEN_SECONDS = 10 * TICKS_PER_SECOND;
	public static final int FIFTEEN_SECONDS = 15 * TICKS_PER_SECOND;
	public static final int TWENTY_SECONDS = 20 * TICKS_PER_SECOND;

	public PortingLibGameTestHelper(class_4517 test) {
		super(test);
	}

	// blocks

	/**
	 * Flip the direction of any block with the {@link class_2741#field_12525} property.
	 */
	public void flipBlock(class_2338 pos) {
		class_2680 original = method_35980(pos);
		if (!original.method_28498(class_2741.field_12525))
			method_35995("FACING property not in block: " + class_7923.field_41175.method_10206(original.method_26204()));
		class_2350 facing = original.method_11654(class_2741.field_12525);
		class_2680 reversed = original.method_11657(class_2741.field_12525, facing.method_10153());
		method_35986(pos, reversed);
	}

	/**
	 * Turn on a lever.
	 */
	public void powerLever(class_2338 pos) {
		method_35972(class_2246.field_10363, pos);
		if (!method_35980(pos).method_11654(class_2401.field_11265)) {
			method_36039(pos);
		}
	}

	/**
	 * Turn off a lever.
	 */
	public void unpowerLever(class_2338 pos) {
		method_35972(class_2246.field_10363, pos);
		if (method_35980(pos).method_11654(class_2401.field_11265)) {
			method_36039(pos);
		}
	}

	// block entities

	/**
	 * Get the block entity of the expected type. If the type does not match, this fails the test.
	 */
	public <T extends class_2586> T getBlockEntity(class_2591<T> type, class_2338 pos) {
		class_2586 be = method_36014(pos);
		class_2591<?> actualType = be == null ? null : be.method_11017();
		if (actualType != type) {
			String actualId = actualType == null ? "null" : class_7923.field_41181.method_10221(actualType).toString();
			String error = "Expected block entity at pos [%s] with type [%s], got [%s]".formatted(
					pos, class_7923.field_41181.method_10221(type), actualId
			);
			method_35995(error);
		}
		return (T) be;
	}

	// entities

	/**
	 * Spawn an item entity at the given position with no velocity.
	 */
	public class_1542 spawnItem(class_2338 pos, class_1799 stack) {
		class_243 spawn = class_243.method_24953(method_36052(pos));
		class_3218 level = method_35943();
		class_1542 item = new class_1542(level, spawn.field_1352, spawn.field_1351, spawn.field_1350, stack, 0, 0, 0);
		level.method_8649(item);
		return item;
	}

	/**
	 * Spawn item entities given an item and amount. The amount will be split into multiple entities if
	 * larger than the item's max stack size.
	 */
	public void spawnItems(class_2338 pos, class_1792 item, int amount) {
		while (amount > 0) {
			int toSpawn = Math.min(amount, item.method_7882());
			amount -= toSpawn;
			class_1799 stack = new class_1799(item, toSpawn);
			spawnItem(pos, stack);
		}
	}

	/**
	 * Get the first entity found at the given position.
	 */
	public <T extends class_1297> T getFirstEntity(class_1299<T> type, class_2338 pos) {
		List<T> list = getEntitiesBetween(type, pos.method_10095().method_10078().method_10084(), pos.method_10072().method_10067().method_10074());
		if (list.isEmpty())
			method_35995("No entities at pos: " + pos);
		return list.get(0);
	}

	/**
	 * Get a list of all entities between two positions, inclusive.
	 */
	public <T extends class_1297> List<T> getEntitiesBetween(class_1299<T> type, class_2338 pos1, class_2338 pos2) {
		class_3341 box = class_3341.method_34390(method_36052(pos1), method_36052(pos2));
		List<? extends T> entities = method_35943().method_18198(type, e -> box.method_14662(e.method_24515()));
		return (List<T>) entities;
	}


	// storage lookups

	public Storage<FluidVariant> getFluidStorage(class_2338 pos) {
		Storage<FluidVariant> storage = FluidStorage.SIDED.find(method_35943(), method_36052(pos), null);
		if (storage == null)
			method_35995("fluid storage not present");
		return storage;
	}

	public Storage<ItemVariant> getItemStorage(class_2338 pos) {
		Storage<ItemVariant> storage = ItemStorage.SIDED.find(method_35943(), method_36052(pos), null);
		if (storage == null)
			method_35995("item storage not present");
		return storage;
	}

	// transfer - items

	/**
	 * Get a map of contained items to their amounts. This is not safe for NBT!
	 */
	public Object2LongMap<class_1792> getItemContent(class_2338 pos) {
		Storage<ItemVariant> storage = getItemStorage(pos);
		Object2LongMap<class_1792> map = new Object2LongArrayMap<>();
		for (StorageView<ItemVariant> view : storage.nonEmptyViews()) {
			class_1792 item = view.getResource().getItem();
			long existing = map.getLong(item);
			map.put(item, existing + view.getAmount());
		}
		return map;
	}

	/**
	 * Get the combined total of all ItemStacks inside the inventory.
	 */
	public long getTotalItems(class_2338 pos) {
		Storage<ItemVariant> storage = getItemStorage(pos);
		long total = 0;
		for (StorageView<ItemVariant> view : storage.nonEmptyViews())
			total += view.getAmount();
		return total;
	}

	/**
	 * Of the provided items, assert that at least one is present in the given inventory.
	 */
	public void assertAnyContained(class_2338 pos, class_1792... items) {
		Storage<ItemVariant> storage = getItemStorage(pos);
		for (class_1792 item : items) {
			long extracted = StorageUtil.simulateExtract(storage, ItemVariant.of(item), 1, null);
			if (extracted != 0)
				return; // found one
		}
		// did not find any
		method_35995("No matching items " + Arrays.toString(items) + " found in handler at pos: " + pos);
	}

	/**
	 * Assert that the inventory contains all the provided content.
	 */
	public void assertContentPresent(Object2LongMap<class_1792> content, class_2338 pos) {
		Storage<ItemVariant> storage = getItemStorage(pos);
		content.forEach((item, expectedAmount) -> {
			long extracted = StorageUtil.simulateExtract(storage, ItemVariant.of(item), expectedAmount, null);
			if (extracted != expectedAmount)
				method_35995("Storage missing " + item + ", only got " + extracted);
		});
	}

	/**
	 * Assert that all the given inventories hold no items.
	 */
	public void assertContainersEmpty(List<class_2338> positions) {
		for (class_2338 pos : positions) {
			method_36047(pos);
		}
	}

	/**
	 * Assert that the given inventory holds no items.
	 */
	@Override
	public void method_36047(@NotNull class_2338 pos) {
		Storage<ItemVariant> storage = getItemStorage(pos);
		for (StorageView<ItemVariant> ignored : storage.nonEmptyViews())
			method_35995("Storage not empty");
	}

	/** @see PortingLibGameTestHelper#assertContainerContains(class_2338, class_1799) */
	public void assertContainerContains(class_2338 pos, class_1935 item) {
		method_35983(pos, item.method_8389());
	}

	/** @see PortingLibGameTestHelper#assertContainerContains(class_2338, class_1799) */
	@Override
	public void method_35983(@NotNull class_2338 pos, @NotNull class_1792 item) {
		assertContainerContains(pos, new class_1799(item));
	}

	/**
	 * Assert that the inventory holds at least the given ItemStack. It may also hold more than the stack.
	 */
	public void assertContainerContains(class_2338 pos, class_1799 item) {
		Storage<ItemVariant> storage = getItemStorage(pos);
		int count = item.method_7947();
		long extracted = StorageUtil.simulateExtract(storage, ItemVariant.of(item), count, null);
		if (extracted != count)
			method_35995("expected " + item + ", got " + extracted);
	}

	// time

	/**
	 * Fail unless the desired number seconds have passed since test start.
	 */
	public void assertSecondsPassed(int seconds) {
		if (method_36045() < (long) seconds * TICKS_PER_SECOND)
			method_35995("Waiting for %s seconds to pass".formatted(seconds));
	}

	/**
	 * Get the total number of seconds that have passed since test start.
	 */
	public long secondsPassed() {
		return method_36045() % 20;
	}

	/**
	 * Run an action later, once enough time has passed.
	 */
	public void whenSecondsPassed(int seconds, Runnable run) {
		method_36003((long) seconds * TICKS_PER_SECOND, run);
	}

	// numbers

	/**
	 * Assert that a number is <1 away from its expected value
	 */
	public void assertCloseEnoughTo(double value, double expected) {
		assertInRange(value, expected - 1, expected + 1);
	}

	public void assertInRange(double value, double min, double max) {
		if (value < min)
			method_35995("Value %s below expected min of %s".formatted(value, min));
		if (value > max)
			method_35995("Value %s greater than expected max of %s".formatted(value, max));
	}

	@Contract("_->fail") // make IDEA happier
	@Override
	public void method_35995(@NotNull String exceptionMessage) {
		super.method_35995(exceptionMessage);
	}
}
