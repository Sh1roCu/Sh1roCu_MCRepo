package io.github.fabricators_of_create.porting_lib.gametest.quickexport;

import java.util.Objects;
import io.github.fabricators_of_create.porting_lib.gametest.PortingLibGameTest;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents.AfterEntities;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3341;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_746;
import net.minecraft.class_761;

public enum AreaSelectionRenderer implements AfterEntities {
	INSTANCE;

	private static final double tinyOffset = 0.01; // z fighting

	@Override
	public void afterEntities(WorldRenderContext context) {
		class_746 player = Objects.requireNonNull(class_310.method_1551().field_1724);
		for (class_1268 hand : class_1268.values()) {
			class_1799 held = player.method_5998(hand);
			if (!held.method_31574(PortingLibGameTest.AREA_SELECTOR))
				continue;

			AreaSelection area = AreaSelectorItem.getArea(held);
			class_4587 poseStack = context.matrixStack();
			class_4597 buffers = Objects.requireNonNull(context.consumers());
			class_4184 camera = context.camera();

			if (area == null) { // nothing selected, render selection
				renderLookTarget(poseStack, buffers, camera, player);
			} else {
				class_2338 second = area.second != null ? area.second : AreaSelectorItem.getLookTarget(player);
				class_3341 box = class_3341.method_34390(area.first, second);
				renderBox(poseStack, buffers, camera, box);
			}
		}
	}

	public static void renderLookTarget(class_4587 poseStack, class_4597 buffers, class_4184 camera, class_1657 player) {
		class_2338 pos = AreaSelectorItem.getLookTarget(player);
		renderBox(poseStack, buffers, camera, new class_3341(pos));
	}

	public static void renderBox(class_4587 poseStack, class_4597 buffers, class_4184 camera, class_3341 box) {
		poseStack.method_22903();

		class_243 camPos = camera.method_19326();
		poseStack.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
		poseStack.method_46416(box.method_35415(), box.method_35416(), box.method_35417());

		class_4588 consumer = buffers.getBuffer(class_1921.method_23594());
		class_761.method_22980(
				poseStack,
				consumer,
				-tinyOffset, -tinyOffset, -tinyOffset,
				box.method_35414() + tinyOffset, box.method_14660() + tinyOffset, box.method_14663() + tinyOffset,
				1, 1, 1, 1
		);
		poseStack.method_22909();
	}


}
