package io.github.fabricators_of_create.porting_lib.gametest.quickexport;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2168;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3341;
import net.minecraft.class_3499;

public class QuickExportCommand {
	public static final String OUTPUT_PROPERTY = "porting_lib.gametest.quickexport.output";
	private static final String property = System.getProperty(OUTPUT_PROPERTY);
	private static final Path output = property != null ? Paths.get(property)
			: FabricLoader.getInstance().getGameDir().resolve("gametests");

	public static final class_2561 HOLD_SELECTOR = lang("hold_selector");
	public static final class_2561 FAILED = lang("failed");
	public static final class_2561 ESCAPE = lang("escape");

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, buildCtx, env) -> dispatcher.register(
						method_9247("porting_lib")
								.then(method_9247("quickexport")
										.then(method_9244("path", StringArgumentType.greedyString())
												.requires(source -> source.method_9259(2))
												.suggests(QuickExportCommand::getSuggestions)
												.executes(
														ctx -> handleExport(ctx.getSource(), StringArgumentType.getString(ctx, "path"))
												)
										)
								)
				)
		);
	}

	// find existing tests and folders for autofill
	private static CompletableFuture<Suggestions> getSuggestions(CommandContext<class_2168> context, SuggestionsBuilder builder) {
		String path = builder.getRemaining();
		if (!path.contains("/") || path.contains(".."))
			return findInDir(output, builder);
		int lastSlash = path.lastIndexOf("/");
		Path subDir = output.resolve(path.substring(0, lastSlash));
		return findInDir(subDir, builder);
	}

	private static CompletableFuture<Suggestions> findInDir(Path dir, SuggestionsBuilder builder) {
		if (!Files.exists(dir))
			return builder.buildFuture();
		try (Stream<Path> paths = Files.list(dir)) {
			paths.filter(p -> Files.isDirectory(p) || p.toString().endsWith(".nbt"))
					.forEach(path -> {
						String file = path.toString()
								.replaceAll("\\\\", "/")
								.substring(output.toString().length() + 1);
						if (Files.isDirectory(path))
							file += "/";
						builder.suggest(file);
					});
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return builder.buildFuture();
	}

	private static int handleExport(class_2168 source, String path) throws CommandSyntaxException {
		if (path.contains("..")) {
			source.method_9213(ESCAPE);
			return 0;
		}

		class_3222 player = source.method_9207();
		AreaSelection area = AreaSelectorItem.getArea(player.method_6047());
		if (area == null || area.second == null) {
			source.method_9213(HOLD_SELECTOR);
			return 0;
		}
		class_3341 box = area.asBoundingBox();
		class_2338 origin = new class_2338(box.method_35415(), box.method_35416(), box.method_35417());
		class_2382 bounds = new class_2382(box.method_35414(), box.method_14660(), box.method_14663());

		class_3218 level = source.method_9225();
		class_3499 structure = new class_3499();
		structure.method_15174(level, origin, bounds, true, class_2246.field_10124);
		class_2487 data = structure.method_15175(new class_2487());

		if (!path.endsWith(".nbt"))
			path += ".nbt";

		Path file = output.resolve(path).toAbsolutePath();
		try {
			Files.createDirectories(file.getParent());
			Files.deleteIfExists(file);
			try (OutputStream out = Files.newOutputStream(file, StandardOpenOption.CREATE)) {
				class_2507.method_10634(data, out);
			}
			String cleanPath = file.toString().replace('\\', '/');
			source.method_9226(() -> lang("exported", cleanPath), false);
			return 1;
		} catch (IOException e) {
			e.printStackTrace();
			source.method_9213(FAILED);
			return 0;
		}
	}

	private static class_2561 lang(String type, Object... args) {
		return class_2561.method_43469("quickexport.command.feedback." + type, args);
	}
}
