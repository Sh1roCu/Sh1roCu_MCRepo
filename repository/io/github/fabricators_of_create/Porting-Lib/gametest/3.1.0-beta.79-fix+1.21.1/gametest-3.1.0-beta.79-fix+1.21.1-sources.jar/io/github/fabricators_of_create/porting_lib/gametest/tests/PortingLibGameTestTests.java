package io.github.fabricators_of_create.porting_lib.gametest.tests;

import java.util.Collection;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_4529;
import net.minecraft.class_6302;
import net.minecraft.class_6303;
import io.github.fabricators_of_create.porting_lib.gametest.PortingLibGameTest;
import io.github.fabricators_of_create.porting_lib.gametest.infrastructure.CustomGameTestHelper;
import io.github.fabricators_of_create.porting_lib.gametest.infrastructure.GameTestGroup;
import io.github.fabricators_of_create.porting_lib.gametest.infrastructure.PortingLibGameTestHelper;

public class PortingLibGameTestTests {
	@class_6303
	public static Collection<class_4529> generateTests() {
		return PortingLibGameTest.getTestsFrom(Tests.class);
	}

	@CustomGameTestHelper(PortingLibGameTestHelper.class)
	@GameTestGroup(namespace = "porting_lib_gametest", path = "test_testing")
	public static class Tests {
		@class_6302(method_35936 = "test")
		public static void test(PortingLibGameTestHelper helper) {
			class_2338 grass = new class_2338(0, 1, 0);
			helper.method_35972(class_2246.field_10219, grass);
			class_2338 flower = grass.method_10084();
			helper.method_35984(flower, class_2246.field_10449);
			helper.method_36018(() -> {
				helper.assertSecondsPassed(2);
				helper.method_35972(class_2246.field_10449, flower);
			});
		}
	}
}
