package io.github.fabricators_of_create.porting_lib.gametest.infrastructure;


import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import net.minecraft.class_4516;
import net.minecraft.class_4517;

/**
 * Allows test methods or entire classes to use a custom subclass of {@link class_4516}.
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface CustomGameTestHelper {
	/**
	 * The class of the custom {@link class_4516} subclass.
	 * This subclass must have a constructor taking one parameter: {@link class_4517}.
	 */
	Class<? extends class_4516> value();
}
