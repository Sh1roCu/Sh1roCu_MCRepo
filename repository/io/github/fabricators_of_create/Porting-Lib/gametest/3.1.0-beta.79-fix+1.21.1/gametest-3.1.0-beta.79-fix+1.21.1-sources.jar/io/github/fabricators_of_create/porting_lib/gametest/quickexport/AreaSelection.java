package io.github.fabricators_of_create.porting_lib.gametest.quickexport;

import com.mojang.serialization.Codec;

import com.mojang.serialization.codecs.RecordCodecBuilder;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2338;
import net.minecraft.class_3341;
import net.minecraft.class_9139;

public class AreaSelection {
	public static Codec<AreaSelection> CODEC = RecordCodecBuilder.create(i -> i.group(
			class_2338.field_25064.fieldOf("first_pos").forGetter(a -> a.first),
			class_2338.field_25064.fieldOf("second_pos").forGetter(a -> a.second)
	).apply(i, AreaSelection::new));

	public static class_9139<ByteBuf, AreaSelection> STREAM_CODEC = class_9139.method_56435(
			class_2338.field_48404, a -> a.first,
			class_2338.field_48404, a -> a.second,
			AreaSelection::new
	);

	public class_2338 first, second;

	public AreaSelection(class_2338 first, class_2338 second) {
		this.first = first;
		this.second = second;
	}

	public class_3341 asBoundingBox() {
		return class_3341.method_34390(first, second);
	}
}
