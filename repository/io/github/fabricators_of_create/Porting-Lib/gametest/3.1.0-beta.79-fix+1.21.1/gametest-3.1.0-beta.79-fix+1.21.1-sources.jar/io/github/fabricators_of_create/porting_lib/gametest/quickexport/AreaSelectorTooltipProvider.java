package io.github.fabricators_of_create.porting_lib.gametest.quickexport;

import java.util.List;

import io.github.fabricators_of_create.porting_lib.gametest.PortingLibGameTest;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3341;

public enum AreaSelectorTooltipProvider implements ItemTooltipCallback {
	INSTANCE;

	@Override
	public void getTooltip(class_1799 stack, class_1792.class_9635 tooltipContext, class_1836 tooltipType, List<class_2561> lines) {
		if (!stack.method_31574(PortingLibGameTest.AREA_SELECTOR))
			return;
		AreaSelection area = AreaSelectorItem.getArea(stack);
		class_2561 tooltip;

		if (area == null) {
			tooltip = lang("no", class_124.field_1061);
		} else if (area.second == null) {
			tooltip = lang("partial", class_124.field_1060, formatPos(area.first));
		} else {
			class_3341 box = area.asBoundingBox();
			class_2338 min = new class_2338(box.method_35415(), box.method_35416(), box.method_35417());
			class_2338 max = new class_2338(box.method_35418(), box.method_35419(), box.method_35420());
			tooltip = lang("complete", class_124.field_1060, formatPos(min), formatPos(max));
		}

		lines.add(1, tooltip);
	}

	private static class_2561 lang(String selectionType, class_124 color, Object... args) {
		String key = "area_selector.tooltip." + selectionType + "_selection";
		return class_2561.method_43469(key, args).method_27692(color);
	}

	private static String formatPos(class_2338 pos) {
		return "[%s, %s, %s]".formatted(pos.method_10263(), pos.method_10264(), pos.method_10260());
	}
}
