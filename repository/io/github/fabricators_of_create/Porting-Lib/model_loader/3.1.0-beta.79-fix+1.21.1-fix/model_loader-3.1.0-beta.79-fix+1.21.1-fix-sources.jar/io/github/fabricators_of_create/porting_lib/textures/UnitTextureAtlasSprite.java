package io.github.fabricators_of_create.porting_lib.textures;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import net.minecraft.class_1011;
import net.minecraft.class_1058;
import net.minecraft.class_2960;
import net.minecraft.class_7368;
import net.minecraft.class_7764;
import net.minecraft.class_7771;

/**
 * A helper sprite with UVs spanning the entire texture.
 * <p>
 * Useful for baking quads that won't be used with an atlas.
 */
public class UnitTextureAtlasSprite extends class_1058 {
	public static final class_2960 LOCATION = PortingLib.id("unit");
	public static final UnitTextureAtlasSprite INSTANCE = new UnitTextureAtlasSprite();

	private UnitTextureAtlasSprite() {
		super(LOCATION, new class_7764(LOCATION, new class_7771(1, 1), new class_1011(1, 1, false), class_7368.field_38688), 1, 1, 0, 0);
	}

	@Override
	public float method_4580(float u) {
		return u;
	}

	@Override
	public float method_4570(float v) {
		return v;
	}
}
