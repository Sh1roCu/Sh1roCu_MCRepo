package io.github.fabricators_of_create.porting_lib.models.renderable;

import net.minecraft.class_3902;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

/**
 * A standard interface for things that can be rendered to a {@link class_4597}.
 *
 * @param <T> The type of context object used by the rendering logic
 */
@FunctionalInterface
public interface IRenderable<T> {
	/**
	 * Draws the renderable by adding the geometry to the provided {@link class_4597}
	 *
	 * @param poseStack               The pose stack
	 * @param bufferSource            The buffer source where the vertex data should be output
	 * @param textureRenderTypeLookup A function that provides a RenderType for the given texture
	 * @param lightmap                The lightmap coordinates representing the current lighting conditions. See {@link net.minecraft.class_765}
	 * @param overlay                 The overlay coordinates representing the current overlay status. See {@link net.minecraft.class_4608}
	 * @param partialTick             The current time expressed in the fraction of a tick elapsed since the last client tick
	 * @param context                 The context used for rendering
	 */
	void render(class_4587 poseStack, class_4597 bufferSource, ITextureRenderTypeLookup textureRenderTypeLookup, int lightmap, int overlay, float partialTick, T context);

	/**
	 * Wraps the current renderable along with a context.
	 * Useful for keeping a list of various renderables paired with their contexts.
	 *
	 * @param context The context used for rendering
	 * @return A renderable that accepts {@link class_3902#field_17274} as context, but uses the provided {@code context} instead
	 */
	default IRenderable<class_3902> withContext(T context) {
		return (poseStack, bufferSource, textureRenderTypeLookup, lightmap, overlay, partialTick, unused) -> this.render(poseStack, bufferSource, textureRenderTypeLookup, lightmap, overlay, partialTick, context);
	}
}
