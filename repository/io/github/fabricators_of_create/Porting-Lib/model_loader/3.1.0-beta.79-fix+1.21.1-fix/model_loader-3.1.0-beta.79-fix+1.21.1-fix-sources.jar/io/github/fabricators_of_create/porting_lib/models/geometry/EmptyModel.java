package io.github.fabricators_of_create.porting_lib.models.geometry;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1047;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1087;
import net.minecraft.class_1093;
import net.minecraft.class_2350;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_777;
import net.minecraft.class_7775;
import net.minecraft.class_806;
import net.minecraft.class_809;
import io.github.fabricators_of_create.porting_lib.models.IModelBuilder;
import io.github.fabricators_of_create.porting_lib.textures.UnitTextureAtlasSprite;

/**
 * A completely empty model with no quads or texture dependencies.
 * <p>
 * You can access it as a {@link class_1087}, an {@link IUnbakedGeometry} or an {@link IGeometryLoader}.
 */
public class EmptyModel extends SimpleUnbakedGeometry<EmptyModel> {
	public static final class_1087 BAKED = new Baked();
	public static final EmptyModel INSTANCE = new EmptyModel();
	public static final IGeometryLoader<EmptyModel> LOADER = (json, ctx) -> INSTANCE;

	private EmptyModel() {}

	@Override
	protected void addQuads(IGeometryBakingContext owner, IModelBuilder<?> modelBuilder, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelTransform) {
		// NO-OP
	}

	@Override
	public class_1087 bake(IGeometryBakingContext context, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelState, class_806 overrides) {
		return BAKED;
	}

	private static class Baked extends class_1093 {
		private static final class_4730 MISSING_TEXTURE = new class_4730(class_1059.field_5275, class_1047.method_4539());

		// SimpleBakedModel must have a quad list per face in its map.
		private static Map<class_2350, List<class_777>> makeEmptyCulledFaces() {
			Map<class_2350, List<class_777>> map = new EnumMap<>(class_2350.class);
			for (class_2350 direction : class_2350.values()) {
				map.put(direction, List.of());
			}
			return map;
		}

		public Baked() {
			super(List.of(), makeEmptyCulledFaces(), false, false, false, UnitTextureAtlasSprite.INSTANCE, class_809.field_4301, class_806.field_4292/*, RenderTypeGroup.EMPTY*/);
		}

		@Override
		public class_1058 method_4711() {
			return MISSING_TEXTURE.method_24148();
		}
	}
}
