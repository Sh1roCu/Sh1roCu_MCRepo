package io.github.fabricators_of_create.porting_lib.models.renderable;

import net.minecraft.class_1921;
import net.minecraft.class_2960;

/**
 * A generic lookup for {@link class_1921} implementations that use the specified texture.
 */
@FunctionalInterface
public interface ITextureRenderTypeLookup {
	class_1921 get(class_2960 name);
}
