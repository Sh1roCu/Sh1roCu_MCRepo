package io.github.fabricators_of_create.porting_lib.models.geometry.mixin.common;

import io.github.fabricators_of_create.porting_lib.models.geometry.extensions.TransformationExtension;
import net.minecraft.class_2350;
import net.minecraft.class_4590;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_4590.class)
public abstract class TransformationMixin implements TransformationExtension {
	@Shadow
	@Final
	private Matrix4f matrix;

	@Shadow
	public abstract Matrix4f getMatrix();

	@Unique
	private Matrix3f normalTransform = null;

	@Override
	public Matrix3f getNormalMatrix() {
		port_lib$checkNormalTransform();
		return normalTransform;
	}

	@Unique
	private void port_lib$checkNormalTransform() {
		if (normalTransform == null) {
			normalTransform = new Matrix3f(this.matrix);
			normalTransform.invert();
			normalTransform.transpose();
		}
	}

	@Override
	public void transformPosition(Vector4f position) {
		position.mul(this.getMatrix());
	}

	@Override
	public class_2350 rotateTransform(class_2350 facing) {
		return class_2350.method_23225(getMatrix(), facing);
	}

	@Override
	public class_4590 applyOrigin(Vector3f origin) {
		if (isIdentity()) return class_4590.method_22931();

		Matrix4f ret = this.getMatrix();
		Matrix4f tmp = new Matrix4f().translation(origin.x(), origin.y(), origin.z());
		tmp.mul(ret, ret);
		tmp.translation(-origin.x(), -origin.y(), -origin.z());
		ret.mul(tmp);
		return new class_4590(ret);
	}
}
