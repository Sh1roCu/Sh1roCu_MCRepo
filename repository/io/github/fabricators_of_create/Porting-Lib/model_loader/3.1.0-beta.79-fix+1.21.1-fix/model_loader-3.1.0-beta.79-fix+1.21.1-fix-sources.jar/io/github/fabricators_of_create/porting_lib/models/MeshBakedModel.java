package io.github.fabricators_of_create.porting_lib.models;

import net.fabricmc.fabric.api.renderer.v1.mesh.Mesh;
import net.fabricmc.fabric.api.renderer.v1.model.ModelHelper;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;

/**
 * Based off of {@link net.minecraft.class_1093}
 */
public class MeshBakedModel implements class_1087 {
	protected final Mesh mesh;
	protected final boolean hasAmbientOcclusion;
	protected final boolean isGui3d;
	protected final boolean usesBlockLight;
	protected final class_1058 particleIcon;
	protected final class_809 transforms;
	protected final class_806 overrides;

	public MeshBakedModel(Mesh mesh, boolean hasAmbientOcclusion, boolean usesBlockLight, boolean isGui3d, class_1058 particleIcon, class_809 transforms, class_806 overrides) {
		this.mesh = mesh;
		this.hasAmbientOcclusion = hasAmbientOcclusion;
		this.isGui3d = isGui3d;
		this.usesBlockLight = usesBlockLight;
		this.particleIcon = particleIcon;
		this.transforms = transforms;
		this.overrides = overrides;
	}

	@Override
	public List<class_777> method_4707(@Nullable class_2680 blockState, @Nullable class_2350 direction, class_5819 randomSource) {
		return ModelHelper.toQuadLists(mesh)[ModelHelper.toFaceIndex(direction)];
	}

	@Override
	public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
		mesh.outputTo(context.getEmitter());
	}

	@Override
	public void emitItemQuads(class_1799 stack, Supplier<class_5819> randomSupplier, RenderContext context) {
		mesh.outputTo(context.getEmitter());
	}

	@Override
	public boolean isVanillaAdapter() {
		return false;
	}

	@Override
	public boolean method_4708() {
		return this.hasAmbientOcclusion;
	}

	@Override
	public boolean method_4712() {
		return this.isGui3d;
	}

	@Override
	public boolean method_24304() {
		return this.usesBlockLight;
	}

	@Override
	public boolean method_4713() {
		return false;
	}

	@Override
	public class_1058 method_4711() {
		return this.particleIcon;
	}

	@Override
	public class_809 method_4709() {
		return this.transforms;
	}

	@Override
	public class_806 method_4710() {
		return this.overrides;
	}
}
