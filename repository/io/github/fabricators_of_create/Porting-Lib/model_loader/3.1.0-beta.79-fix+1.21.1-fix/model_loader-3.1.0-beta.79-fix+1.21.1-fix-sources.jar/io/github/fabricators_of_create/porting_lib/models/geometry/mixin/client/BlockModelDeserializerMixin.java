package io.github.fabricators_of_create.porting_lib.models.geometry.mixin.client;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_4590;
import net.minecraft.class_785;
import net.minecraft.class_793;
import com.google.gson.JsonParseException;
import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.models.geometry.GeometryLoaderManager;
import io.github.fabricators_of_create.porting_lib.models.geometry.IGeometryLoader;
import io.github.fabricators_of_create.porting_lib.models.geometry.IUnbakedGeometry;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

@Mixin(class_793.class_795.class)
public abstract class BlockModelDeserializerMixin {

	@Inject(method = "deserialize(Lcom/google/gson/JsonElement;Ljava/lang/reflect/Type;Lcom/google/gson/JsonDeserializationContext;)Lnet/minecraft/client/renderer/block/model/BlockModel;", at = @At("RETURN"), cancellable = true)
	public void modelLoading(JsonElement element, Type type, JsonDeserializationContext deserializationContext, CallbackInfoReturnable<class_793> cir) {
		class_793 model = cir.getReturnValue();
		JsonObject jsonobject = element.getAsJsonObject();
		IUnbakedGeometry<?> geometry = deserializeGeometry(deserializationContext, jsonobject);

		List<class_785> elements = model.method_3433();
		if (geometry != null) {
			elements.clear();
			model.port_lib$getCustomData().setCustomGeometry(geometry);
		}

		if (jsonobject.has("transform")) {
			JsonObject transform = class_3518.method_15296(jsonobject, "transform");
			model.port_lib$getCustomData().setRootTransform(deserializationContext.deserialize(transform, class_4590.class));
		}

		if (jsonobject.has("render_type")) {
			var renderTypeHintName = class_3518.method_15265(jsonobject, "render_type");
			model.port_lib$getCustomData().setRenderTypeHint(class_2960.method_60654(renderTypeHintName));
		}

		if (jsonobject.has("visibility")) {
			JsonObject visibility = class_3518.method_15296(jsonobject, "visibility");
			for (Map.Entry<String, JsonElement> part : visibility.entrySet()) {
				model.port_lib$getCustomData().visibilityData.setVisibilityState(part.getKey(), part.getValue().getAsBoolean());
			}
		}

	}

	@Unique
	@Nullable
	private static IUnbakedGeometry<?> deserializeGeometry(JsonDeserializationContext deserializationContext, JsonObject object) throws JsonParseException {
		if (!GeometryLoaderManager.hasModelLoader(object))
			return null;

		class_2960 name;
		boolean optional;
		if (GeometryLoaderManager.getModelLoader(object).isJsonObject()) {
			JsonObject loaderObj = GeometryLoaderManager.getModelLoader(object).getAsJsonObject();
			name = class_2960.method_60654(class_3518.method_15265(loaderObj, "id"));
			optional = class_3518.method_15258(loaderObj, "optional", false);
		} else {
			name = class_2960.method_60654(GeometryLoaderManager.getModelLoader(object).getAsString());
			optional = false;
		}

		var loader = GeometryLoaderManager.get(name);
		if (loader == null) {
			if (optional) {
				return null;
			}
			if (!GeometryLoaderManager.KNOWN_MISSING_LOADERS.contains(name)) {
				GeometryLoaderManager.KNOWN_MISSING_LOADERS.add(name);
				PortingLib.LOGGER.warn(String.format(Locale.ENGLISH, "Model loader '%s' not found. Registered loaders: %s", name, GeometryLoaderManager.getLoaderList()));
				PortingLib.LOGGER.warn("Falling back to vanilla logic.");
			}
			return null;
		}

		return loader.read(object, deserializationContext);
	}
}
