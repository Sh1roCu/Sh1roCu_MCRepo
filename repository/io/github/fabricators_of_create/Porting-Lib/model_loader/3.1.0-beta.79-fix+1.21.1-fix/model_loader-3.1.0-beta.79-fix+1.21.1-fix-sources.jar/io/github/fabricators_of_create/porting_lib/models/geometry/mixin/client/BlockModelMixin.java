package io.github.fabricators_of_create.porting_lib.models.geometry.mixin.client;

import java.util.List;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_799;
import net.minecraft.class_806;
import io.github.fabricators_of_create.porting_lib.models.ExtendedItemOverrides;
import io.github.fabricators_of_create.porting_lib.models.geometry.BlockGeometryBakingContext;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import io.github.fabricators_of_create.porting_lib.models.geometry.extensions.BlockModelExtension;

@Mixin(class_793.class)
public class BlockModelMixin implements BlockModelExtension {
	@Shadow
	@Final
	private List<class_799> overrides;
	@Shadow
	@Nullable
	public class_793 parent;
	private final BlockGeometryBakingContext port_lib$customData = new BlockGeometryBakingContext((class_793) (Object) this);

	@Override
	public BlockGeometryBakingContext port_lib$getCustomData() {
		return port_lib$customData;
	}

	@Inject(
			method = "bake(Lnet/minecraft/client/resources/model/ModelBaker;Lnet/minecraft/client/renderer/block/model/BlockModel;Ljava/util/function/Function;Lnet/minecraft/client/resources/model/ModelState;Z)Lnet/minecraft/client/resources/model/BakedModel;",
			at = @At("HEAD"),
			cancellable = true
	)
	public void handleCustomModels(class_7775 modelBaker, class_793 owner, Function<class_4730, class_1058> spriteGetter, class_3665 modelState, boolean guiLight3d, CallbackInfoReturnable<class_1087> cir) {
		if (port_lib$customData.hasCustomGeometry()) {
			cir.setReturnValue(port_lib$customData.getCustomGeometry().bake(
					port_lib$customData, modelBaker, spriteGetter, modelState, getOverrides(modelBaker, owner, spriteGetter)
			));
		}
	}

	@Inject(method = "resolveParents", at = @At(value = "INVOKE", target = "Ljava/util/List;forEach(Ljava/util/function/Consumer;)V"))
	private void handleCustomResolveParents(Function<class_2960, class_1100> function, CallbackInfo ci) {
		if (port_lib$customData.hasCustomGeometry())
			port_lib$customData.getCustomGeometry().resolveParents(function, port_lib$customData);
	}

	@Override
	public class_806 getOverrides(class_7775 bakery, class_793 model, Function<class_4730, class_1058> spriteGetter) {
		return this.overrides.isEmpty() ? class_806.field_4292 : new ExtendedItemOverrides(bakery, model, this.overrides, spriteGetter);
	}
}
