package io.github.fabricators_of_create.porting_lib.models.geometry.extensions;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.models.geometry.BlockGeometryBakingContext;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_806;

public interface BlockModelExtension {
	default BlockGeometryBakingContext port_lib$getCustomData() {
		throw PortingLib.createMixinException("BlockModelExtensions#port_lib$getCustomData()");
	}

	default class_806 getOverrides(class_7775 bakery, class_793 model, Function<class_4730, class_1058> spriteGetter) {
		throw PortingLib.createMixinException("BlockModelExtensions#getOverrides(ModelBaker, BlockModel, Function<Material, TextureAtlasSprite>)");
	}
}
