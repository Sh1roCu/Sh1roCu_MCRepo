package io.github.fabricators_of_create.porting_lib.models;

import ;
import java.util.Arrays;
import java.util.List;

import net.fabricmc.fabric.api.renderer.v1.mesh.QuadView;
import net.minecraft.class_290;
import net.minecraft.class_296;
import net.minecraft.class_777;

/**
 * Transformer for {@link class_777 baked quads}.
 *
 * @see FabricQuadTransformers
 */
public interface IQuadTransformer {
	int STRIDE = QuadView.VANILLA_VERTEX_STRIDE;
	int POSITION = findOffset(class_296.field_52107);
	int COLOR = findOffset(class_296.field_52108);
	int UV0 = findOffset(class_296.field_52109);
	int UV1 = findOffset(class_296.field_52111);
	int UV2 = findOffset(class_296.field_52112);
	int NORMAL = findOffset(class_296.field_52113);

	void processInPlace(class_777 quad);

	default void processInPlace(List<class_777> quads) {
		for (class_777 quad : quads)
			processInPlace(quad);
	}

	default class_777 process(class_777 quad) {
		var copy = copy(quad);
		processInPlace(copy);
		return copy;
	}

	default List<class_777> process(List<class_777> inputs) {
		return inputs.stream().map(IQuadTransformer::copy).peek(this::processInPlace).toList();
	}

	default IQuadTransformer andThen(IQuadTransformer other) {
		return quad -> {
			processInPlace(quad);
			other.processInPlace(quad);
		};
	}

	private static class_777 copy(class_777 quad) {
		var vertices = quad.method_3357();
		return new class_777(Arrays.copyOf(vertices, vertices.length), quad.method_3359(), quad.method_3358(), quad.method_35788(), quad.method_24874()/*, quad.hasAmbientOcclusion()*/);
	}

	private static int findOffset(class_296 element) {
		if (class_290.field_1590.method_60836(element)) {
			// Divide by 4 because we want the int offset
			return class_290.field_1590.method_60835(element) / 4;
		}
		return -1;
	}
}
