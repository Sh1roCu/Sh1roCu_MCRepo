package io.github.fabricators_of_create.porting_lib.models.geometry.mixin.client;

import io.github.fabricators_of_create.porting_lib.models.ExtraFaceData;
import io.github.fabricators_of_create.porting_lib.models.geometry.extensions.BlockElementExtension;
import net.minecraft.class_785;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_785.class)
public class BlockElementMixin implements BlockElementExtension {

	private ExtraFaceData port_lib$faceData = ExtraFaceData.DEFAULT;

	@Override
	public ExtraFaceData port_lib$getFaceData() {
		return this.port_lib$faceData;
	}

	@Override
	public void port_lib$setFaceData(ExtraFaceData faceData) {
		this.port_lib$faceData = java.util.Objects.requireNonNull(faceData);
	}
}
