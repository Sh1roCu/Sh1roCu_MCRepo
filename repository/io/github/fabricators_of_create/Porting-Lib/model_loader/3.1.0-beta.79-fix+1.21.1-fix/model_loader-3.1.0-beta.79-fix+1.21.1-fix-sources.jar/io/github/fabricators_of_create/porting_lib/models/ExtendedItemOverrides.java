package io.github.fabricators_of_create.porting_lib.models;

import java.util.List;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_799;
import net.minecraft.class_806;

public class ExtendedItemOverrides extends class_806 {
	// I'm honestly not sure why this is pass here, forge doesn't document why it does this at all and vanilla already uses a TextureGetter
	public ExtendedItemOverrides(class_7775 modelBaker, class_793 blockModel, List<class_799> list, Function<class_4730, class_1058> spriteGetter) {
		super(modelBaker, blockModel, list);
	}
}
