package io.github.fabricators_of_create.porting_lib.models.geometry;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4590;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_806;
import net.minecraft.class_809;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * A {@linkplain IGeometryBakingContext geometry baking context} that is bound to a {@link class_793}.
 * <p>
 * Users should not be instantiating this themselves.
 */
public class BlockGeometryBakingContext implements IGeometryBakingContext {
	public final class_793 owner;
	public final VisibilityData visibilityData = new VisibilityData();
	@Nullable
	private IUnbakedGeometry<?> customGeometry;
	@Nullable
	private class_4590 rootTransform;
	@Nullable
	private class_2960 renderTypeHint;
	private boolean gui3d = true;

	@ApiStatus.Internal
	public BlockGeometryBakingContext(class_793 owner) {
		this.owner = owner;
	}

	@Override
	public String getModelName() {
		return owner.field_4252;
	}

	public boolean hasCustomGeometry() {
		return getCustomGeometry() != null;
	}

	@Nullable
	public IUnbakedGeometry<?> getCustomGeometry() {
		return owner.field_4253 != null && customGeometry == null ? owner.field_4253.port_lib$getCustomData().getCustomGeometry() : customGeometry;
	}

	public void setCustomGeometry(IUnbakedGeometry<?> geometry) {
		this.customGeometry = geometry;
	}

	@Override
	public boolean isComponentVisible(String part, boolean fallback) {
		return owner.field_4253 != null && !visibilityData.hasCustomVisibility(part) ? owner.field_4253.port_lib$getCustomData().isComponentVisible(part, fallback) : visibilityData.isVisible(part, fallback);
	}

	@Override
	public boolean hasMaterial(String name) {
		return owner.method_3432(name);
	}

	@Override
	public class_4730 getMaterial(String name) {
		return owner.method_24077(name);
	}

	@Override
	public boolean isGui3d() {
		return gui3d;
	}

	@Override
	public boolean useBlockLight() {
		return owner.method_24298().method_24299();
	}

	@Override
	public boolean useAmbientOcclusion() {
		return owner.method_3444();
	}

	@Override
	public class_809 getTransforms() {
		return owner.method_3443();
	}

	@Override
	public class_4590 getRootTransform() {
		if (rootTransform != null)
			return rootTransform;
		return owner.field_4253 != null ? owner.field_4253.port_lib$getCustomData().getRootTransform() : class_4590.method_22931();
	}

	public void setRootTransform(class_4590 rootTransform) {
		this.rootTransform = rootTransform;
	}

	@Nullable
	@Override
	public class_2960 getRenderTypeHint() {
		if (renderTypeHint != null)
			return renderTypeHint;
		return owner.field_4253 != null ? owner.field_4253.port_lib$getCustomData().getRenderTypeHint() : null;
	}

	public void setRenderTypeHint(class_2960 renderTypeHint) {
		this.renderTypeHint = renderTypeHint;
	}

	public void setGui3d(boolean gui3d) {
		this.gui3d = gui3d;
	}

	public void copyFrom(BlockGeometryBakingContext other) {
		this.customGeometry = other.customGeometry;
		this.rootTransform = other.rootTransform;
		this.visibilityData.copyFrom(other.visibilityData);
		this.renderTypeHint = other.renderTypeHint;
		this.gui3d = other.gui3d;
	}

	public class_1087 bake(class_7775 baker, Function<class_4730, class_1058> bakedTextureGetter, class_3665 modelTransform, class_806 overrides) {
		IUnbakedGeometry<?> geometry = getCustomGeometry();
		if (geometry == null)
			throw new IllegalStateException("Can not use custom baking without custom geometry");
		return geometry.bake(this, baker, bakedTextureGetter, modelTransform, overrides);
	}

	public static class VisibilityData {
		private final Map<String, Boolean> data = new HashMap<>();

		public boolean hasCustomVisibility(String part) {
			return data.containsKey(part);
		}

		public boolean isVisible(String part, boolean fallback) {
			return data.getOrDefault(part, fallback);
		}

		public void setVisibilityState(String partName, boolean type) {
			data.put(partName, type);
		}

		public void copyFrom(VisibilityData visibilityData) {
			data.clear();
			data.putAll(visibilityData.data);
		}
	}
}
