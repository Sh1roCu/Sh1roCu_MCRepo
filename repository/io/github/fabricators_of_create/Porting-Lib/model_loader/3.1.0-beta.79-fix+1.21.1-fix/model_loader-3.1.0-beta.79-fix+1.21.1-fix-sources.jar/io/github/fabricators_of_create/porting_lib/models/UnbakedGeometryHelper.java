package io.github.fabricators_of_create.porting_lib.models;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.List;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import Z;
import io.github.fabricators_of_create.porting_lib.models.geometry.IGeometryBakingContext;
import io.github.fabricators_of_create.porting_lib.models.geometry.IUnbakedGeometry;
import io.github.fabricators_of_create.porting_lib.models.geometry.SimpleModelState;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1047;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1090;
import net.minecraft.class_156;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4590;
import net.minecraft.class_4730;
import net.minecraft.class_7764;
import net.minecraft.class_777;
import net.minecraft.class_7775;
import net.minecraft.class_783;
import net.minecraft.class_785;
import net.minecraft.class_787;
import net.minecraft.class_793;
import net.minecraft.class_796;
import net.minecraft.class_801;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

/**
 * Helper for dealing with unbaked models and geometries.
 */
public class UnbakedGeometryHelper {
	private static final class_801 ITEM_MODEL_GENERATOR = new class_801();
	private static final class_796 FACE_BAKERY = new class_796();

	/**
	 * Explanation:
	 * This takes anything that looks like a valid resourcepack texture location, and tries to extract a resourcelocation out of it.
	 * 1. it will ignore anything up to and including an /assets/ folder,
	 * 2. it will take the next path component as a namespace,
	 * 3. it will match but skip the /textures/ part of the path,
	 * 4. it will take the rest of the path up to but excluding the .png extension as the resource path
	 * It's a best-effort situation, to allow model files exported by modelling software to be used without post-processing.
	 * Example:
	 * C:\Something\Or Other\src\main\resources\assets\mymodid\textures\item\my_thing.png
	 * ........................................--------_______----------_____________----
	 * <namespace> <path>
	 * Result after replacing '\' to '/': mymodid:item/my_thing
	 */
	private static final Pattern FILESYSTEM_PATH_TO_RESLOC = Pattern.compile("(?:.*[\\\\/]assets[\\\\/](?<namespace>[a-z_-]+)[\\\\/]textures[\\\\/])?(?<path>[a-z_\\\\/-]+)\\.png");

	/**
	 * Resolves a material that may have been defined with a filesystem path instead of a proper {@link class_2960}.
	 * <p>
	 * The target atlas will always be {@link class_1059#field_5275}.
	 */
	public static class_4730 resolveDirtyMaterial(@Nullable String tex, IGeometryBakingContext owner) {
		if (tex == null)
			return new class_4730(class_1059.field_5275, class_1047.method_4539());
		if (tex.startsWith("#"))
			return owner.getMaterial(tex);

		// Attempt to convert a common (windows/linux/mac) filesystem path to a ResourceLocation.
		// This makes no promises, if it doesn't work, too bad, fix your mtl file.
		Matcher match = FILESYSTEM_PATH_TO_RESLOC.matcher(tex);
		if (match.matches()) {
			String namespace = match.group("namespace");
			String path = match.group("path").replace("\\", "/");
			tex = namespace != null ? namespace + ":" + path : path;
		}

		return new class_4730(class_1059.field_5275, class_2960.method_60654(tex));
	}

	/**
	 * Helper for baking {@link class_793} instances. Handles baking custom geometries and deferring item model baking.
	 */
	@ApiStatus.Internal
	public static class_1087 bake(class_793 blockModel, class_7775 modelBaker, class_793 owner, Function<class_4730, class_1058> spriteGetter, class_3665 modelState, boolean guiLight3d) {
		IUnbakedGeometry<?> customModel = blockModel.port_lib$getCustomData().getCustomGeometry();
		if (customModel != null)
			return customModel.bake(blockModel.port_lib$getCustomData(), modelBaker, spriteGetter, modelState, blockModel.method_3434(modelBaker, owner, spriteGetter));

		// Handle vanilla item models here, since vanilla has a shortcut for them
		if (blockModel.method_3431() == class_1088.field_5400)
			return ITEM_MODEL_GENERATOR.method_3479(spriteGetter, blockModel).method_3446(modelBaker, blockModel, spriteGetter, modelState, guiLight3d);

		if (blockModel.method_3431() == class_1088.field_5389) {
			var particleSprite = spriteGetter.apply(blockModel.method_24077("particle"));
			return new class_1090(blockModel.method_3443(), blockModel.method_3434(modelBaker, owner, spriteGetter), particleSprite, blockModel.method_24298().method_24299());
		}

		var elementsModel = new ElementsModel(blockModel.method_3433());
		return elementsModel.bake(blockModel.port_lib$getCustomData(), modelBaker, spriteGetter, modelState, blockModel.method_3434(modelBaker, owner, spriteGetter));
	}

	/**
	 * @see #createUnbakedItemElements(int, class_1058, ExtraFaceData)
	 */
	public static List<class_785> createUnbakedItemElements(int layerIndex, class_1058 sprite) {
		return createUnbakedItemElements(layerIndex, sprite, null);
	}

	/**
	 * Creates a list of {@linkplain class_785 block elements} in the shape of the specified sprite contents.
	 * These can later be baked using the same, or another texture.
	 * <p>
	 * The {@link class_2350#field_11043} and {@link class_2350#field_11035} faces take up the whole surface.
	 */
	public static List<class_785> createUnbakedItemElements(int layerIndex, class_1058 sprite, @Nullable ExtraFaceData faceData) {
		var elements = ITEM_MODEL_GENERATOR.method_3480(layerIndex, "layer" + layerIndex, sprite.method_45851());
//		ClientHooks.fixItemModelSeams(elements, sprite); We could implement this but meh
		if (faceData != null) {
			elements.forEach(element -> element.port_lib$setFaceData(faceData));
		}
		return elements;
	}

	/**
	 * @see #createUnbakedItemMaskElements(int, class_1058, ExtraFaceData)
	 */
	public static List<class_785> createUnbakedItemMaskElements(int layerIndex, class_1058 sprite) {
		return createUnbakedItemMaskElements(layerIndex, sprite, null);
	}

	/**
	 * Creates a list of {@linkplain class_785 block elements} in the shape of the specified sprite contents.
	 * These can later be baked using the same, or another texture.
	 * <p>
	 * The {@link class_2350#field_11043} and {@link class_2350#field_11035} faces take up only the pixels the texture uses.
	 */
	public static List<class_785> createUnbakedItemMaskElements(int layerIndex, class_1058 sprite, @Nullable ExtraFaceData faceData) {
		var elements = createUnbakedItemElements(layerIndex, sprite, faceData);
		elements.remove(0); // Remove north and south faces

		class_7764 spriteContents = sprite.method_45851();
		int width = spriteContents.method_45807(), height = spriteContents.method_45815();
		var bits = new BitSet(width * height);

		// For every frame in the texture, mark all the opaque pixels (this is what vanilla does too)
		spriteContents.method_45817().forEach(frame -> {
			for (int x = 0; x < width; x++)
				for (int y = 0; y < height; y++)
					if (!spriteContents.method_45810(frame, x, y))
						bits.set(x + y * width);
		});

		// Scan in search of opaque pixels
		for (int y = 0; y < height; y++) {
			int xStart = -1;
			for (int x = 0; x < width; x++) {
				var opaque = bits.get(x + y * width);
				if (opaque == (xStart == -1)) // (opaque && -1) || (!opaque && !-1)
				{
					if (xStart == -1) {
						// We have found the start of a new segment, continue
						xStart = x;
						continue;
					}

					// The segment is over, expand down as far as possible
					int yEnd = y + 1;
					expand:
					for (; yEnd < height; yEnd++)
						for (int x2 = xStart; x2 <= x; x2++)
							if (!bits.get(x2 + yEnd * width))
								break expand;

					// Mark all pixels in the area as visited
					for (int i = xStart; i < x; i++)
						for (int j = y; j < yEnd; j++)
							bits.clear(i + j * width);

					// Create element
					elements.add(new class_785(
							new Vector3f(16 * xStart / (float) width, 16 - 16 * yEnd / (float) height, 7.5F),
							new Vector3f(16 * x / (float) width, 16 - 16 * y / (float) height, 8.5F),
							class_156.method_654(new HashMap<>(), map -> {
								for (class_2350 direction : class_2350.values())
									map.put(direction, new class_783(null, layerIndex, "layer" + layerIndex, new class_787(null, 0)));
							}),
							null,
							true));

					// Reset xStart
					xStart = -1;
				}
			}
		}
		return elements;
	}

	/**
	 * Bakes a list of {@linkplain class_785 block elements} and feeds the baked quads to a {@linkplain IModelBuilder model builder}.
	 */
	public static void bakeElements(IModelBuilder<?> builder, List<class_785> elements, Function<class_4730, class_1058> spriteGetter, class_3665 modelState) {
		for (class_785 element : elements) {
			element.field_4230.forEach((side, face) -> {
				var sprite = spriteGetter.apply(new class_4730(class_1059.field_5275, class_2960.method_60654(face.comp_2869())));
				var quad = bakeElementFace(element, face, sprite, side, modelState);
				if (face.comp_2867() == null)
					builder.addUnculledFace(quad);
				else
					builder.addCulledFace(class_2350.method_23225(modelState.method_3509().method_22936(), face.comp_2867()), quad);
			});
		}
	}

	/**
	 * Bakes a list of {@linkplain class_785 block elements} and returns the list of baked quads.
	 */
	public static List<class_777> bakeElements(List<class_785> elements, Function<class_4730, class_1058> spriteGetter, class_3665 modelState) {
		if (elements.isEmpty())
			return List.of();
		var list = new ArrayList<class_777>();
		bakeElements(IModelBuilder.collecting(list), elements, spriteGetter, modelState);
		return list;
	}

	/**
	 * Turns a single {@link class_783} into a {@link class_777}.
	 */
	public static class_777 bakeElementFace(class_785 element, class_783 face, class_1058 sprite, class_2350 direction, class_3665 state) {
		return FACE_BAKERY.method_3468(element.field_4228, element.field_4231, face, sprite, direction, state, element.field_4232, element.field_4229);
	}

	/**
	 * Create an {@link IQuadTransformer} to apply a {@link class_4590} that undoes the {@link class_3665}
	 * transform (blockstate transform), applies the given root transform and then re-applies the
	 * blockstate transform.
	 *
	 * @return an {@code IQuadTransformer} that applies the root transform to a baked quad that already has the
	 *         transformation of the given {@code ModelState} applied to it
	 */
	public static IQuadTransformer applyRootTransform(class_3665 modelState, class_4590 rootTransform) {
		// Move the origin of the ModelState transform and its inverse from the negative corner to the block center
		// to replicate the way the ModelState transform is applied in the FaceBakery by moving the vertices such that
		// the negative corner acts as the block center
		class_4590 transform = modelState.method_3509().applyOrigin(new Vector3f(.5F, .5F, .5F));
		return QuadTransformers.applying(transform.method_22933(rootTransform).method_22933(transform.method_22935()));
	}

	/**
	 * Create an {@link RenderContext.QuadTransform} to apply a {@link class_4590} that undoes the {@link class_3665}
	 * transform (blockstate transform), applies the given root transform and then re-applies the
	 * blockstate transform.
	 *
	 * @return an {@code IQuadTransformer} that applies the root transform to a baked quad that already has the
	 *         transformation of the given {@code ModelState} applied to it
	 */
	public static RenderContext.QuadTransform applyFabricRootTransform(class_3665 modelState, class_4590 rootTransform) {
		// Move the origin of the ModelState transform and its inverse from the negative corner to the block center
		// to replicate the way the ModelState transform is applied in the FaceBakery by moving the vertices such that
		// the negative corner acts as the block center
		class_4590 transform = modelState.method_3509().applyOrigin(new Vector3f(.5F, .5F, .5F));
		return FabricQuadTransformers.applying(transform.method_22933(rootTransform).method_22933(transform.method_22935()));
	}

	/**
	 * {@return a {@link class_3665} that combines the existing model state and the {@linkplain class_4590 root transform}}
	 */
	public static class_3665 composeRootTransformIntoModelState(class_3665 modelState, class_4590 rootTransform) {
		// Move the origin of the root transform as if the negative corner were the block center to match the way the
		// ModelState transform is applied in the FaceBakery by moving the vertices to be centered on that corner
		rootTransform = rootTransform.applyOrigin(new Vector3f(-.5F, -.5F, -.5F));
		return new SimpleModelState(modelState.method_3509().method_22933(rootTransform), modelState.method_3512());
	}
}
