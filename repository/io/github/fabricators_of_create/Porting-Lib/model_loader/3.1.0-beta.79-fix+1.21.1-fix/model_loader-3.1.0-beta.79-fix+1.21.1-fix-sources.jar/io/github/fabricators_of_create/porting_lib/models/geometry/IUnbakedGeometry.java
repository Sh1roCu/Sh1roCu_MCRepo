package io.github.fabricators_of_create.porting_lib.models.geometry;

import java.util.Set;
import java.util.function.Function;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_806;

/**
 * General interface for any model that can be baked, superset of vanilla {@link class_1100}.
 * <p>
 * Instances of this class ar usually created via {@link IGeometryLoader}.
 *
 * @see IGeometryLoader
 * @see IGeometryBakingContext
 */
public interface IUnbakedGeometry<T extends IUnbakedGeometry<T>> {
	class_1087 bake(IGeometryBakingContext context, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelState, class_806 overrides);

	/**
	 * Resolve parents of nested {@link class_793}s which are later used in
	 * {@link IUnbakedGeometry#bake(IGeometryBakingContext, class_7775, Function, class_3665, class_806)}
	 * via {@link class_793#method_45785(Function)}
	 */
	default void resolveParents(Function<class_2960, class_1100> modelGetter, IGeometryBakingContext context) {}

	/**
	 * {@return a set of all the components whose visibility may be configured via {@link IGeometryBakingContext}}
	 */
	default Set<String> getConfigurableComponentNames() {
		return Set.of();
	}
}
