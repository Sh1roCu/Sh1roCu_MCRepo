package io.github.fabricators_of_create.porting_lib.models;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import io.github.fabricators_of_create.porting_lib.models.geometry.IGeometryBakingContext;
import io.github.fabricators_of_create.porting_lib.models.geometry.IGeometryLoader;
import io.github.fabricators_of_create.porting_lib.models.geometry.SimpleUnbakedGeometry;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.minecraft.class_1058;
import net.minecraft.class_2350;
import net.minecraft.class_3518;
import net.minecraft.class_3665;
import net.minecraft.class_4590;
import net.minecraft.class_4730;
import net.minecraft.class_777;
import net.minecraft.class_7775;
import net.minecraft.class_783;
import net.minecraft.class_785;
import net.minecraft.class_793;

/**
 * A model composed of vanilla {@linkplain class_785 block elements}.
 */
public class ElementsModel extends SimpleUnbakedGeometry<ElementsModel> {
	private final List<class_785> elements;

	public ElementsModel(List<class_785> elements) {
		this.elements = elements;
	}

	@Override
	protected void addQuads(IGeometryBakingContext context, IModelBuilder<?> modelBuilder, class_7775 baker, Function<class_4730, class_1058> spriteGetter, class_3665 modelState) {
		// If there is a root transform, undo the ModelState transform, apply it, then re-apply the ModelState transform.
		// This is necessary because of things like UV locking, which should only respond to the ModelState, and as such
		// that is the only transform that should be applied during face bake.
		var postTransform = QuadTransformers.empty();
		var rootTransform = context.getRootTransform();
		if (!rootTransform.isIdentity())
			postTransform = UnbakedGeometryHelper.applyRootTransform(modelState, rootTransform);

		QuadEmitter emitter = RendererAccess.INSTANCE.getRenderer().meshBuilder().getEmitter();

		for (class_785 element : elements) {
			for (class_2350 direction : element.field_4230.keySet()) {
				var face = element.field_4230.get(direction);
				var sprite = spriteGetter.apply(context.getMaterial(face.comp_2869()));
				var quad = class_793.method_3447(element, face, sprite, direction, modelState);
				postTransform.processInPlace(quad);

				if (face.comp_2867() == null)
					modelBuilder.addUnculledFace(quad);
				else
					modelBuilder.addCulledFace(modelState.method_3509().rotateTransform(face.comp_2867()), quad);
			}
		}
	}

	public static final class Loader implements IGeometryLoader<ElementsModel> {
		public static final Loader INSTANCE = new Loader();

		private Loader() {}

		@Override
		public ElementsModel read(JsonObject jsonObject, JsonDeserializationContext deserializationContext) throws JsonParseException {
			if (!jsonObject.has("elements"))
				throw new JsonParseException("An element model must have an \"elements\" member.");

			List<class_785> elements = new ArrayList<>();
			for (JsonElement element : class_3518.method_15261(jsonObject, "elements")) {
				elements.add(deserializationContext.deserialize(element, class_785.class));
			}

			return new ElementsModel(elements);
		}
	}
}
