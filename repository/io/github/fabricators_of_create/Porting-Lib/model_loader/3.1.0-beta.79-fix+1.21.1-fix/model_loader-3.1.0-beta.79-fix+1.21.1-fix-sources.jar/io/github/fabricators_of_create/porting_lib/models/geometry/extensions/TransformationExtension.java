package io.github.fabricators_of_create.porting_lib.models.geometry.extensions;

import net.minecraft.class_2350;
import net.minecraft.class_4590;
import org.joml.Matrix3f;
import org.joml.Vector3f;
import org.joml.Vector4f;

public interface TransformationExtension {
	/**
	 * Apply this transformation to a different origin.
	 * Can be used for switching between coordinate systems.
	 * Parameter is relative to the current origin.
	 */
	default class_4590 applyOrigin(Vector3f origin) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default Matrix3f getNormalMatrix() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default void transformPosition(Vector4f position) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default class_2350 rotateTransform(class_2350 facing) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default boolean isIdentity() {
		return this.equals(class_4590.method_22931());
	}

	default void transformNormal(Vector3f normal) {
		normal.mul(getNormalMatrix());
		normal.normalize();
	}

	/**
	 * convert transformation from assuming center-block system to opposing-corner-block system
	 */
	default class_4590 blockCenterToCorner() {
		return applyOrigin(new Vector3f(.5f, .5f, .5f));
	}

	/**
	 * convert transformation from assuming opposing-corner-block system to center-block system
	 */
	default class_4590 blockCornerToCenter() {
		return applyOrigin(new Vector3f(-.5f, -.5f, -.5f));
	}
}
