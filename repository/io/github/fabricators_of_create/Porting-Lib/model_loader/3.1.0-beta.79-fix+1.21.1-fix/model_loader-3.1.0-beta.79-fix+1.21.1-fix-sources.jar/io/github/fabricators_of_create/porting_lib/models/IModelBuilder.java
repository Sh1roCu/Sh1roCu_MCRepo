package io.github.fabricators_of_create.porting_lib.models;

import java.util.List;

import io.github.fabricators_of_create.porting_lib.models.geometry.EmptyModel;
import io.github.fabricators_of_create.porting_lib.render_types.RenderTypeGroup;
import io.github.fabricators_of_create.porting_lib.textures.UnitTextureAtlasSprite;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.Mesh;
import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadView;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;

/**
 * Base interface for any object that collects culled and unculled faces and bakes them into a model.
 * <p>
 * Provides a generic base implementation via {@link #of(boolean, boolean, boolean, ItemTransforms, ItemOverrides, TextureAtlasSprite, RenderTypeGroup)}
 * and a quad-collecting alternative via {@link #collecting(List)}.
 */
public interface IModelBuilder<T extends IModelBuilder<T>> {
	/**
	 * Creates a new model builder that uses the provided attributes in the final baked model.
	 */
	static IModelBuilder<?> of(boolean hasAmbientOcclusion, boolean usesBlockLight, boolean isGui3d,
							   class_809 transforms, class_806 overrides, class_1058 particle,
							   RenderTypeGroup renderTypes) {
		return new Simple(hasAmbientOcclusion, usesBlockLight, isGui3d, transforms, overrides, particle, renderTypes);
	}

	/**
	 * Creates a new model builder that collects quads to the provided list, returning
	 * {@linkplain EmptyModel#BAKED an empty model} if you call {@link #build()}.
	 */
	static IModelBuilder<?> collecting(List<class_777> quads) {
		return new Collecting(quads);
	}

	T addCulledFace(class_2350 facing, class_777 quad);

	T addUnculledFace(class_777 quad);

	T addFace(QuadView quad);

	class_1087 build();

	class Simple implements IModelBuilder<Simple> {
		private final MeshBuilder builder;
		private final boolean hasAmbientOcclusion, usesBlockLight, isGui3d;
		private final class_809 transforms;
		private final class_806 overrides;
		private final class_1058 particle;
		private final RenderTypeGroup renderTypes;
		private final RenderMaterial material;

		private Simple(boolean hasAmbientOcclusion, boolean usesBlockLight, boolean isGui3d,
					   class_809 transforms, class_806 overrides, class_1058 particle,
					   RenderTypeGroup renderTypes) {
			this.builder = RendererAccess.INSTANCE.getRenderer().meshBuilder();//new SimpleBakedModel.Builder(hasAmbientOcclusion, usesBlockLight, isGui3d, transforms, overrides).particle(particle);
			this.hasAmbientOcclusion = hasAmbientOcclusion;
			this.usesBlockLight = usesBlockLight;
			this.isGui3d = isGui3d;
			this.transforms = transforms;
			this.overrides = overrides;
			this.particle = particle;
			this.renderTypes = renderTypes;
			this.material = renderTypes.material();
		}

		@Override
		public Simple addCulledFace(class_2350 facing, class_777 quad) {
			builder.getEmitter().fromVanilla(quad, material, facing).emit();
			return this;
		}

		@Override
		public Simple addUnculledFace(class_777 quad) {
			builder.getEmitter().fromVanilla(quad, material, null).emit();
			return this;
		}

		@Override
		public Simple addFace(QuadView quad) {
			builder.getEmitter().copyFrom(quad).emit();
			return this;
		}

		@Deprecated
		@Override
		public class_1087 build() {
			return new MeshBakedModel(builder.build(), hasAmbientOcclusion, usesBlockLight, isGui3d, particle, transforms, overrides);
		}
	}

	class Collecting implements IModelBuilder<Collecting> {
		private final List<class_777> quads;

		private Collecting(List<class_777> quads) {
			this.quads = quads;
		}

		@Override
		public Collecting addCulledFace(class_2350 facing, class_777 quad) {
			quads.add(quad);
			return this;
		}

		@Override
		public Collecting addUnculledFace(class_777 quad) {
			quads.add(quad);
			return this;
		}

		@Override
		public Collecting addFace(QuadView quad) {
			quads.add(quad.toBakedQuad(UnitTextureAtlasSprite.INSTANCE));
			return this;
		}

		@Override
		public class_1087 build() {
			return EmptyModel.BAKED;
		}
	}
}
