package io.github.fabricators_of_create.porting_lib.tool.mixin;

import com.google.common.collect.ImmutableList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_52;
import net.minecraft.class_55;

@Mixin(class_52.class_53.class)
public interface BuilderAccessor {
	@Accessor
	ImmutableList.Builder<class_55> getPools();
}
