package io.github.fabricators_of_create.porting_lib.tool.mixin;

import io.github.fabricators_of_create.porting_lib.tool.ItemAbility;
import io.github.fabricators_of_create.porting_lib.tool.addons.ItemAbilityItem;
import io.github.fabricators_of_create.porting_lib.tool.extensions.ItemStackExtensions;
import io.github.fabricators_of_create.porting_lib.tool.extensions.VanillaItemAbilityItem;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1799.class)
public abstract class ItemStackMixin implements ItemStackExtensions {
	@Shadow
	public abstract class_1792 getItem();

	@Override
	public boolean canPerformAction(ItemAbility toolAction) {
		var item = getItem();
		if (item instanceof ItemAbilityItem toolActionItem)
			return toolActionItem.canPerformAction((class_1799) (Object) this, toolAction);
		if (item instanceof VanillaItemAbilityItem toolActionItem)
			return toolActionItem.port_lib$canPerformAction((class_1799) (Object) this, toolAction);
		return false;
	}
}
