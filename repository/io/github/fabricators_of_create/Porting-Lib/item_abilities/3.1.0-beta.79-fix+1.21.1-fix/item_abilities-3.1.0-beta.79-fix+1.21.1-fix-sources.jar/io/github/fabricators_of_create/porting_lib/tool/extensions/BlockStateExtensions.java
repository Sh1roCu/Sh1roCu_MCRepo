package io.github.fabricators_of_create.porting_lib.tool.extensions;

import io.github.fabricators_of_create.porting_lib.tool.ItemAbility;
import io.github.fabricators_of_create.porting_lib.tool.ItemAbilities;
import io.github.fabricators_of_create.porting_lib.tool.ItemAbilityHooks;
import io.github.fabricators_of_create.porting_lib.tool.addons.ItemAbilityBlock;
import net.minecraft.class_1838;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public interface BlockStateExtensions {
	/**
	 * Returns the state that this block should transform into when right-clicked by a tool.
	 * For example: Used to determine if {@link ItemAbilities#AXE_STRIP an axe can strip},
	 * {@link ItemAbilities#SHOVEL_FLATTEN a shovel can path}, or {@link ItemAbilities#HOE_TILL a hoe can till}.
	 * Returns {@code null} if nothing should happen.
	 *
	 * @param context     The use on context that the action was performed in
	 * @param itemAbility The action being performed by the tool
	 * @param simulate    If {@code true}, no actions that modify the world in any way should be performed. If {@code false}, the world may be modified.
	 * @return The resulting state after the action has been performed
	 */
	@Nullable
	default class_2680 getToolModifiedState(class_1838 context, ItemAbility itemAbility, boolean simulate) {
		var blockState = (class_2680) this;
		class_2680 eventState = ItemAbilityHooks.onToolUse(blockState, context, itemAbility, simulate);
		return eventState != blockState ? eventState : (blockState.method_26204() instanceof ItemAbilityBlock abilityBlock ? abilityBlock.getToolModifiedState(blockState, context, itemAbility, simulate) : null);
	}
}
