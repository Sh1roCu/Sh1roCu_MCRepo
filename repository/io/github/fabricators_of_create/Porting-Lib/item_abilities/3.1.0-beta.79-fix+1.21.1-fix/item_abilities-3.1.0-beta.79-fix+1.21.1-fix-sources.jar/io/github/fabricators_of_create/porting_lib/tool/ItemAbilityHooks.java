package io.github.fabricators_of_create.porting_lib.tool;

import io.github.fabricators_of_create.porting_lib.tool.events.BlockToolModificationEvent;
import net.minecraft.class_1743;
import net.minecraft.class_1821;
import net.minecraft.class_1838;
import net.minecraft.class_2248;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public class ItemAbilityHooks {
	@Nullable
	public static class_2680 onToolUse(class_2680 originalState, class_1838 context, ItemAbility itemAbility, boolean simulate) {
        BlockToolModificationEvent event = new BlockToolModificationEvent(originalState, context, itemAbility, simulate);
		return event.post() ? null : event.getFinalState();
	}

	@Nullable
	public static class_2680 getAxeStrippingState(class_2680 originalState) {
		class_2248 block = class_1743.field_7898.get(originalState.method_26204());
		return block != null ? block.method_9564().method_11657(class_2465.field_11459, originalState.method_11654(class_2465.field_11459)) : null;
	}

	@Nullable
	public static class_2680 getShovelPathingState(class_2680 originalState) {
		return class_1821.field_8912.get(originalState.method_26204());
	}
}
