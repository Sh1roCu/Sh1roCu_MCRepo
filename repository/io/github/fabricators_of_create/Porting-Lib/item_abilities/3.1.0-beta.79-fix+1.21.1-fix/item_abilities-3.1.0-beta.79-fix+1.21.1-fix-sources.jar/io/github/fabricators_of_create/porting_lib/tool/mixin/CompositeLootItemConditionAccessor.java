package io.github.fabricators_of_create.porting_lib.tool.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_186;
import net.minecraft.class_5341;

@Mixin(class_186.class)
public interface CompositeLootItemConditionAccessor {
	@Accessor
	List<class_5341> getTerms();

	@Mutable
	@Accessor
	void setTerms(List<class_5341> terms);
}
