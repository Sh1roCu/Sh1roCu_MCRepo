package io.github.fabricators_of_create.porting_lib.tool.addons;

import io.github.fabricators_of_create.porting_lib.tool.ItemAbility;
import net.minecraft.class_1799;
import io.github.fabricators_of_create.porting_lib.tool.ItemAbilities;

public interface ItemAbilityItem {
	/**
	 * Queries if an item can perform the given action.
	 * See {@link ItemAbilities} for a description of each stock action
	 *
	 * @param stack       The stack being used
	 * @param itemAbility The action being queried
	 * @return True if the stack can perform the action
	 */
	default boolean canPerformAction(class_1799 stack, ItemAbility itemAbility) {
		return false;
	}
}
