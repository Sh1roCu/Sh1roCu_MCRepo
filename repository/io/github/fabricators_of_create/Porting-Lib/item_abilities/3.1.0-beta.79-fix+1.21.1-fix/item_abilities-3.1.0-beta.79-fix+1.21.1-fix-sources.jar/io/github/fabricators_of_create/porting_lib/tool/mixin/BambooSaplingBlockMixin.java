package io.github.fabricators_of_create.porting_lib.tool.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import io.github.fabricators_of_create.porting_lib.tool.ItemAbilities;
import io.github.fabricators_of_create.porting_lib.tool.addons.ItemAbilityItem;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_2202;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_2202.class)
public class BambooSaplingBlockMixin {
	@ModifyExpressionValue(method = "getDestroyProgress", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;getMainHandItem()Lnet/minecraft/world/item/ItemStack;"))
	private class_1799 toolActionIsSword(class_1799 original) {
		if (original.method_7909() instanceof ItemAbilityItem)
			return original.canPerformAction(ItemAbilities.SWORD_DIG) ? original.method_7909() instanceof class_1829 ? original : class_1802.field_8371.method_7854() : class_1802.field_8162.method_7854();
		return original;
	}
}
