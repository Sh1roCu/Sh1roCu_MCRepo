package io.github.fabricators_of_create.porting_lib.tool.mixin;

import io.github.fabricators_of_create.porting_lib.tool.extensions.BlockStateExtensions;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2680.class)
public class BlockStateMixin implements BlockStateExtensions {
}
