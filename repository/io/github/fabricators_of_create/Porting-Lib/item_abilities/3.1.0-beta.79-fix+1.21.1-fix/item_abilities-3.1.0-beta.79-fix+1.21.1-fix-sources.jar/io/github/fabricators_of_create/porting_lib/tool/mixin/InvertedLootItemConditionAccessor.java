package io.github.fabricators_of_create.porting_lib.tool.mixin;

import net.minecraft.class_207;
import net.minecraft.class_5341;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_207.class)
public interface InvertedLootItemConditionAccessor {
	@Accessor
	class_5341 getTerm();
}
