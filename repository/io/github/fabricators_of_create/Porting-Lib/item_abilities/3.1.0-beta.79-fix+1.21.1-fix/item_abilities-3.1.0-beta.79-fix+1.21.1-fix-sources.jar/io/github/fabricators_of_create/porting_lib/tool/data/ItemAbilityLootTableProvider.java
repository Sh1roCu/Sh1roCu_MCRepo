package io.github.fabricators_of_create.porting_lib.tool.data;

import com.google.common.collect.Multimap;
import com.mojang.datafixers.util.Either;
import java.lang.reflect.Field;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.class_117;
import net.minecraft.class_156;
import net.minecraft.class_173;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_186;
import net.minecraft.class_207;
import net.minecraft.class_2073;
import net.minecraft.class_223;
import net.minecraft.class_2370;
import net.minecraft.class_2385;
import net.minecraft.class_2405;
import net.minecraft.class_2438;
import net.minecraft.class_2960;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5341;
import net.minecraft.class_5455;
import net.minecraft.class_55;
import net.minecraft.class_58;
import net.minecraft.class_65;
import net.minecraft.class_6673;
import net.minecraft.class_67;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_69;
import net.minecraft.class_72;
import net.minecraft.class_7225;
import net.minecraft.class_73;
import net.minecraft.class_7403;
import net.minecraft.class_77;
import net.minecraft.class_7784;
import net.minecraft.class_7791;
import net.minecraft.class_7794;
import net.minecraft.class_7871;
import net.minecraft.class_79;
import net.minecraft.class_7924;
import net.minecraft.class_83;
import net.minecraft.class_85;
import net.minecraft.class_8548;
import net.minecraft.class_8551;
import net.minecraft.class_8564;
import net.minecraft.class_8942;
import net.minecraft.class_91;
import net.minecraft.class_9248;
import net.minecraft.class_93;
import com.mojang.serialization.Lifecycle;

import io.github.fabricators_of_create.porting_lib.tool.ItemAbilities;
import io.github.fabricators_of_create.porting_lib.tool.loot.CanItemPerformAbility;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import org.jetbrains.annotations.Nullable;

/**
 * Currently used only for replacing shears item to shears_dig item ability
 */
public final class ItemAbilityLootTableProvider extends class_2438 {
	private final List<Function<class_5341, class_5341.class_210>> conditionReplacers = new ArrayList<>();

	public ItemAbilityLootTableProvider(class_7784 packOutput, CompletableFuture<class_7225.class_7874> provider) {
		super(packOutput, Set.of(), class_7794.method_46184(packOutput, provider).field_11354, provider);
	}

	protected void validate(class_2385<class_52> writableregistry, class_58 validationcontext, class_8942.class_8943 problemreporter$collector) {
		// Do not validate against all registered loot tables
	}

	public List<class_2438.class_7790> getTables() {
		replaceLootItemCondition(condition -> {
			if (condition instanceof class_223 matchTool && checkMatchTool(matchTool, class_1802.field_8868)) {
				return CanItemPerformAbility.canItemPerformAbility(ItemAbilities.SHEARS_DIG);
			}
			return null;
		});
		return this.getTables().stream().map(entry -> {
			// Provides new sub provider with filtering only changed loot tables and replacing condition item to condition tag
			return new class_2438.class_7790((provider) -> replaceAndFilterChangesOnly(entry.comp_1068().apply(provider)), entry.comp_1069());
		}).collect(Collectors.toList());
	}

	private class_7791 replaceAndFilterChangesOnly(class_7791 subProvider) {
		return (newConsumer) -> subProvider.method_10399((resourceLocation, builder) -> {
			class_52.class_53 newBuilder = findAndReplaceInLootTableBuilder(builder);
			if (newBuilder != null) {
				newConsumer.accept(resourceLocation, newBuilder);
			}
		});
	}

	private void replaceLootItemCondition(Function<class_5341, class_5341.class_210> replacer) {
		conditionReplacers.add(replacer);
	}

	@Nullable
	private class_52.class_53 findAndReplaceInLootTableBuilder(class_52.class_53 builder) {
		class_52 lootTable = builder.method_338();

		Optional<class_2960> randomSequence = getPrivateValue(class_52.class, lootTable, "randomSequence");
		List<class_55> lootPools = getPrivateValue(class_52.class, lootTable, "pools");
		List<class_117> lootItemFunctions = getPrivateValue(class_52.class, lootTable, "functions");

		boolean found = false;
		class_52.class_53 newBuilder = new class_52.class_53();
		newBuilder.method_334(lootTable.method_322());
		randomSequence.ifPresent(newBuilder::method_51883);
		for (class_117 lootItemFunction : lootItemFunctions) {
			newBuilder.method_335(() -> lootItemFunction);
		}

		for (class_55 lootPool : lootPools) {
			found |= findAndReplaceInLootPool(lootPool, newBuilder);
		}

		return found ? newBuilder : null;
	}

	private boolean findAndReplaceInLootPool(class_55 lootPool, class_52.class_53 newBuilder) {
		List<class_79> lootEntries = getPrivateValue(class_55.class, lootPool, "entries");
		List<class_5341> lootConditions = getPrivateValue(class_55.class, lootPool, "conditions");
		List<class_117> lootFunctions = getPrivateValue(class_55.class, lootPool, "functions");

		class_55.class_56 poolBuilder = new class_55.class_56();
		poolBuilder.method_352(lootPool.field_957);
		poolBuilder.method_35509(lootPool.field_958);
//		poolBuilder.name(lootPool.getName());
		boolean found = false;

		for (class_79 lootEntry : lootEntries) {
			found |= findAndReplaceInLootEntry(lootEntry, poolBuilder::method_351);
		}

		for (class_5341 lootCondition : lootConditions) {
			if (lootCondition instanceof class_207 invertedLootItemCondition) {
				class_5341 invLootCondition = invertedLootItemCondition.comp_1873();

				Consumer<class_5341.class_210> consumer = cond -> poolBuilder.method_356(class_207.method_889(cond));
				if (invLootCondition instanceof class_186 compositeLootItemCondition && findAndReplaceInComposite(compositeLootItemCondition, consumer)) {
					found = true;
				} else {
					found |= replaceCondition(invLootCondition, consumer);
				}
			} else {
				found |= replaceCondition(lootCondition, poolBuilder::method_356);
			}
		}

		for (class_117 lootFunction : lootFunctions) {
			poolBuilder.method_353(() -> lootFunction);
		}

		newBuilder.method_336(poolBuilder);

		return found;
	}

	private boolean findAndReplaceInParentedLootEntry(class_69 entry, Consumer<class_79.class_80<?>> newBuilder) {
		List<class_79> lootEntries = getPrivateValue(class_69.class, entry, "children");

		boolean found = false;
		for (class_79 lootEntry : lootEntries) {
			found |= findAndReplaceInLootEntry(lootEntry, newBuilder);
		}

		return found;
	}

	private boolean findAndReplaceInLootEntry(class_79 entry, Consumer<class_79.class_80<?>> newBuilder) {
		List<class_5341> lootConditions = getPrivateValue(class_79.class, entry, "conditions");

		boolean found = false;

		class_79.class_80<?> builder;
		if (entry instanceof class_69 compositeEntryBase) {
			Consumer<class_79.class_80<?>> consumer;
			if (compositeEntryBase instanceof class_65) {
				builder = new class_65.class_66();
				consumer = builder::method_417;
			} else if (compositeEntryBase instanceof class_72) {
				builder = new class_72.class_6153();
				consumer = builder::method_35514;
			} else if (compositeEntryBase instanceof class_93) {
				builder = new class_93.class_6152();
				consumer = builder::method_35513;
			} else {
				throw new IllegalStateException("Unknown CompositeEntryBase type: " + compositeEntryBase.getClass().getName());
			}
			found |= findAndReplaceInParentedLootEntry(compositeEntryBase, consumer);
		} else if (entry instanceof class_85 singleton) {
			if (singleton instanceof class_67 dynamicLoot) {
				class_2960 name = getPrivateValue(class_67.class, dynamicLoot, "name");
				builder = class_67.method_390(name);
			} else if (singleton instanceof class_73) {
				builder = class_73.method_401();
			} else if (singleton instanceof class_77 lootItem) {
				class_6880<class_1792> item = getPrivateValue(class_77.class, lootItem, "item");
				builder = class_77.method_411(item.comp_349());
			} else if (singleton instanceof class_91 tagEntry) {
				class_6862<class_1792> tag = getPrivateValue(class_91.class, tagEntry, "tag");
				boolean expand = getPrivateValue(class_91.class, tagEntry, "expand");
				builder = expand ? class_91.method_445(tag) : class_91.method_35517(tag);
			} else if (singleton instanceof class_83 reference) {
				Either<class_5321<class_52>, class_52> contents = getPrivateValue(class_83.class, reference, "contents");
				builder = contents.map(class_83::method_428, class_83::method_57631);
			} else {
				throw new IllegalStateException("Unknown LootPoolSingletonContainer type: " + singleton.getClass().getName());
			}
			int weight = getPrivateValue(class_85.class, singleton, "weight");
			int quality = getPrivateValue(class_85.class, singleton, "quality");
			List<class_117> functions = getPrivateValue(class_85.class, singleton, "functions");
			((class_85.class_86<?>) builder).method_437(weight);
			((class_85.class_86<?>) builder).method_436(quality);
			for (class_117 function : functions) {
				((class_85.class_86<?>) builder).method_438(() -> function);
			}
		} else {
			throw new IllegalStateException("Unknown LootPoolEntryContainer type: " + entry.getClass().getName());
		}

		for (class_5341 lootCondition : lootConditions) {
			if (lootCondition instanceof class_186 composite && findAndReplaceInComposite(composite, builder::method_421)) {
				found = true;
			} else {
				found |= replaceCondition(lootCondition, builder::method_421);
			}
		}

		newBuilder.accept(builder);

		return found;
	}

	private boolean findAndReplaceInComposite(class_186 alternative, Consumer<class_5341.class_210> poolBuilder) {
		List<class_5341> lootConditions = getPrivateValue(class_186.class, alternative, "terms");
		class_186.class_187 builder = alternative instanceof class_8548 ? new class_8548.class_8549() : alternative instanceof class_8551 ? new class_8551.class_8552() : null;
		boolean found = false;

		for (class_5341 lootCondition : lootConditions) {
			found |= replaceCondition(lootCondition, builder::method_51730);
		}

		poolBuilder.accept(builder);

		return found;
	}

	private boolean checkMatchTool(class_223 lootCondition, class_1792 expected) {
		return lootCondition
				.comp_1884()
				.flatMap(class_2073::comp_1784)
				.filter(holders -> holders.method_40241(expected.method_40131()))
				.isPresent();
	}

	private boolean replaceCondition(class_5341 lootCondition, Consumer<class_5341.class_210> poolBuilder) {
		for (Function<class_5341, class_5341.class_210> conditionReplacer : conditionReplacers) {
			class_5341.class_210 newCondition = conditionReplacer.apply(lootCondition);
			if (newCondition != null) {
				poolBuilder.accept(newCondition);
				return true;
			}
		}
		poolBuilder.accept(() -> lootCondition);
		return false;
	}

	private <T, C> T getPrivateValue(Class<C> clazz, C inst, String name) {
		try {
			var field = clazz.getDeclaredField(name);
			field.setAccessible(true);
			return (T) field.get(inst);
		} catch (IllegalAccessException | NoSuchFieldException e) {
			throw new IllegalStateException(clazz.getName() + " is missing field " + name);
		}
	}

	@Override
	public CompletableFuture<?> method_10319(class_7403 output) {
		return this.field_48978.thenCompose(p_323117_ -> this.method_56883(output, p_323117_));
	}

	private CompletableFuture<?> method_56883(class_7403 output, class_7225.class_7874 provider) {
		class_2385<class_52> writableregistry = new class_2370<>(class_7924.field_50079, Lifecycle.experimental());
		Map<class_6673.class_6674, class_2960> map = new Object2ObjectOpenHashMap<>();
		getTables().forEach(subEntry -> subEntry.comp_1068().apply(provider).method_10399((key, p_335200_) -> {
			class_2960 resourcelocation = method_58574(key);
			class_2960 resourcelocation1 = map.put(class_8564.method_52171(resourcelocation), resourcelocation);
			if (resourcelocation1 != null) {
				class_156.method_33559("Loot table random sequence seed collision on " + resourcelocation1 + " and " + key.method_29177());
			}

			p_335200_.method_51883(resourcelocation);
			class_52 loottable = p_335200_.method_334(subEntry.comp_1069()).method_338();
			writableregistry.method_10272(key, loottable, class_9248.field_49136);
		}));
		writableregistry.method_40276();
		class_8942.class_8943 problemreporter$collector = new class_8942.class_8943();
		class_7871.class_7872 holdergetter$provider = new class_5455.class_6891(List.of(writableregistry)).method_40316().method_46758();
		class_58 validationcontext = new class_58(problemreporter$collector, class_173.field_1177, holdergetter$provider);

		validate(writableregistry, validationcontext, problemreporter$collector);

		Multimap<String, String> multimap = problemreporter$collector.method_54948();
		if (!multimap.isEmpty()) {
			multimap.forEach((key, id) -> field_11355.warn("Found validation problem in {}: {}", key, id));
			throw new IllegalStateException("Failed to validate loot tables, see logs");
		} else {
			return CompletableFuture.allOf(writableregistry.method_29722().stream().map(entry -> {
				class_5321<class_52> resourcekey1 = entry.getKey();
				class_52 loottable = entry.getValue();
				Path path = this.field_39374.method_44107(resourcekey1.method_29177());
				return class_2405.method_53496(output, provider, class_52.field_50021, loottable, path);
			}).toArray(CompletableFuture[]::new));
		}
	}
}
