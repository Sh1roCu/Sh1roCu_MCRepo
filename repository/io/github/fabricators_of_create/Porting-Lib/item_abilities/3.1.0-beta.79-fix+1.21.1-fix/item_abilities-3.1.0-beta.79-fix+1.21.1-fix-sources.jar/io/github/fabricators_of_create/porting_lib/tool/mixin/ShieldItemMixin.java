package io.github.fabricators_of_create.porting_lib.tool.mixin;

import io.github.fabricators_of_create.porting_lib.tool.ItemAbility;
import io.github.fabricators_of_create.porting_lib.tool.ItemAbilities;
import io.github.fabricators_of_create.porting_lib.tool.extensions.VanillaItemAbilityItem;
import net.minecraft.class_1799;
import net.minecraft.class_1819;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1819.class)
public class ShieldItemMixin implements VanillaItemAbilityItem {
	@Override
	public boolean port_lib$canPerformAction(class_1799 stack, ItemAbility ability) {
		return ItemAbilities.DEFAULT_SHIELD_ACTIONS.contains(ability);
	}
}
