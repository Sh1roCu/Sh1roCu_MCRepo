package io.github.fabricators_of_create.porting_lib.tool.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_69;
import net.minecraft.class_79;

@Mixin(class_69.class)
public interface CompositeEntryBaseAccessor {
	@Accessor
	List<class_79> getChildren();
}
