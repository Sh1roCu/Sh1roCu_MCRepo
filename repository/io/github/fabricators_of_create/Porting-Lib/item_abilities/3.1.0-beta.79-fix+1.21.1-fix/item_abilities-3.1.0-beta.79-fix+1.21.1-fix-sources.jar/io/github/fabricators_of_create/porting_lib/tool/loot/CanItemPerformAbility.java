package io.github.fabricators_of_create.porting_lib.tool.loot;

import com.google.common.collect.ImmutableSet;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.tool.ItemAbility;
import java.util.Set;
import net.minecraft.class_169;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_2378;
import net.minecraft.class_47;
import net.minecraft.class_5341;
import net.minecraft.class_5342;
import net.minecraft.class_7923;

/**
 * This LootItemCondition "porting_lib:can_item_perform_ability" can be used to check if a tool can perform a given ItemAbility.
 */
public class CanItemPerformAbility implements class_5341 {
	public static MapCodec<CanItemPerformAbility> CODEC = RecordCodecBuilder.mapCodec(
			builder -> builder
					.group(
							ItemAbility.CODEC.fieldOf("ability").forGetter(action -> action.ability))
					.apply(builder, CanItemPerformAbility::new));

	public static final class_5342 LOOT_CONDITION_TYPE = new class_5342(CODEC);

	final ItemAbility ability;

	public CanItemPerformAbility(ItemAbility ability) {
		this.ability = ability;
	}

	public class_5342 method_29325() {
		return LOOT_CONDITION_TYPE;
	}

	public Set<class_169<?>> method_293() {
		return ImmutableSet.of(class_181.field_1229);
	}

	public boolean test(class_47 lootContext) {
		class_1799 itemstack = lootContext.method_296(class_181.field_1229);
		return itemstack != null && itemstack.canPerformAction(this.ability);
	}

	public static class_5341.class_210 canItemPerformAbility(ItemAbility action) {
		return () -> new CanItemPerformAbility(action);
	}

	public static void init() {
		class_2378.method_10230(class_7923.field_41135, PortingLib.id("can_item_perform_ability"), CanItemPerformAbility.LOOT_CONDITION_TYPE);
	}
}

