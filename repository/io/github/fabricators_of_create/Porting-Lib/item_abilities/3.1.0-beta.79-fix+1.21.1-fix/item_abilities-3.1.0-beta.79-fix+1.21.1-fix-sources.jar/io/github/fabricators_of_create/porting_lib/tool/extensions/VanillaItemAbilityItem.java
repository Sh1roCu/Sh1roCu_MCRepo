package io.github.fabricators_of_create.porting_lib.tool.extensions;

import io.github.fabricators_of_create.porting_lib.tool.ItemAbility;
import net.minecraft.class_1799;

public interface VanillaItemAbilityItem {
	boolean port_lib$canPerformAction(class_1799 stack, ItemAbility ability);
}
