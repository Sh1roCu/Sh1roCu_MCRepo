package io.github.fabricators_of_create.porting_lib.tool.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import io.github.fabricators_of_create.porting_lib.tool.ItemAbilities;
import io.github.fabricators_of_create.porting_lib.tool.addons.ItemAbilityItem;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_4830;
import net.minecraft.class_4836;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_4830.class)
public class StopHoldingItemIfNoLongerAdmiringMixin {
	@ModifyExpressionValue(method = "method_47299", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;is(Lnet/minecraft/world/item/Item;)Z"))
	private static boolean isToolActionBlocking(boolean original, class_3218 level, class_4836 piglin) {
		class_1799 offHand = piglin.method_6079();
		if (offHand.method_7909() instanceof ItemAbilityItem)
			return offHand.canPerformAction(ItemAbilities.SHIELD_BLOCK);
		return original;
	}
}
