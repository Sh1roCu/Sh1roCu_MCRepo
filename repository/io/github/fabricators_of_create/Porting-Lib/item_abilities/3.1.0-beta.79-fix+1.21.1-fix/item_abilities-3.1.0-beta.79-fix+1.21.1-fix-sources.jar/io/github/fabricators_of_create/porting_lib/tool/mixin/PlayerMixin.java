package io.github.fabricators_of_create.porting_lib.tool.mixin;

import com.llamalad7.mixinextras.injector.ModifyReceiver;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import io.github.fabricators_of_create.porting_lib.tool.ItemAbilities;
import io.github.fabricators_of_create.porting_lib.tool.addons.ItemAbilityItem;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_1937;

@Mixin(class_1657.class)
public abstract class PlayerMixin extends class_1309 {
	protected PlayerMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
		super(entityType, level);
	}

	@ModifyExpressionValue(method = "hurtCurrentlyUsedShield", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;is(Lnet/minecraft/world/item/Item;)Z"))
	private boolean shieldToolAction(boolean original) {
		if (this.field_6277.method_7909() instanceof ItemAbilityItem) {
			return this.field_6277.canPerformAction(ItemAbilities.SHIELD_BLOCK);
		}
		return original;
	}

	@ModifyReceiver(method = "attack", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getItem()Lnet/minecraft/world/item/Item;"))
	private class_1799 canSwordSweep(class_1799 instance) {
		if (instance.method_7909() instanceof ItemAbilityItem) {
			if (instance.canPerformAction(ItemAbilities.SWORD_SWEEP)) {
				return instance.method_7909() instanceof class_1829 ? instance : class_1802.field_8371.method_7854();
			}
			return class_1802.field_8162.method_7854();
		}
		return instance;
	}
}
