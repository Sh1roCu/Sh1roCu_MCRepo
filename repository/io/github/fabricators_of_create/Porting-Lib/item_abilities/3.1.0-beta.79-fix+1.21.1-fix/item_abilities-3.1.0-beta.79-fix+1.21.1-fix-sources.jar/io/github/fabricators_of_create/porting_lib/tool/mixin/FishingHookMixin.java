package io.github.fabricators_of_create.porting_lib.tool.mixin;

import com.llamalad7.mixinextras.injector.ModifyReceiver;

import io.github.fabricators_of_create.porting_lib.tool.ItemAbilities;
import io.github.fabricators_of_create.porting_lib.tool.addons.ItemAbilityItem;
import net.minecraft.class_1536;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1536.class)
public class FishingHookMixin {
	@ModifyReceiver(method = "shouldStopFishing", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;is(Lnet/minecraft/world/item/Item;)Z"))
	private class_1799 toolActionCast(class_1799 instance, class_1792 item) {
		if (instance.method_7909() instanceof ItemAbilityItem) {
			if (instance.canPerformAction(ItemAbilities.FISHING_ROD_CAST)) {
				return instance.method_7909() instanceof class_1787 ? instance : class_1802.field_8378.method_7854();
			}
			return class_1802.field_8162.method_7854();
		}
		return instance;
	}
}
