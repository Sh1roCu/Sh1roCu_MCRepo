package io.github.fabricators_of_create.porting_lib.tool.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import io.github.fabricators_of_create.porting_lib.tool.ItemAbilities;
import io.github.fabricators_of_create.porting_lib.tool.addons.ItemAbilityItem;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1309.class)
public class LivingEntityMixin {
	@Shadow
	protected class_1799 useItem;

	@ModifyExpressionValue(method = "isBlocking", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/Item;getUseAnimation(Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/item/UseAnim;"))
	private class_1839 isToolActionBlocking(class_1839 original) {
		if (this.useItem.method_7909() instanceof ItemAbilityItem) {
			if (!this.useItem.canPerformAction(ItemAbilities.SHIELD_BLOCK))
				return class_1839.field_8952;
			else
				return class_1839.field_8949;
		}
		return original;
	}
}
