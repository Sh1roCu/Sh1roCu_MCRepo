package io.github.fabricators_of_create.porting_lib.tool.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_5341;
import net.minecraft.class_79;

@Mixin(class_79.class)
public interface LootPoolEntryContainerAccessor {
	@Accessor
	List<class_5341> getConditions();
}
