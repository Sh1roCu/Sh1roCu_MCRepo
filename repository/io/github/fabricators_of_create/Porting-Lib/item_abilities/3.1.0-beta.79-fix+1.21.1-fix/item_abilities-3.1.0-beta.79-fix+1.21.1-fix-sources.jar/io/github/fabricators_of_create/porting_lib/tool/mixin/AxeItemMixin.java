package io.github.fabricators_of_create.porting_lib.tool.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import io.github.fabricators_of_create.porting_lib.tool.ItemAbility;
import io.github.fabricators_of_create.porting_lib.tool.ItemAbilities;
import io.github.fabricators_of_create.porting_lib.tool.ItemAbilityHooks;
import io.github.fabricators_of_create.porting_lib.tool.extensions.VanillaItemAbilityItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import net.minecraft.class_1269;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_2680;

@Mixin(class_1743.class)
public class AxeItemMixin implements VanillaItemAbilityItem {
    @Unique
    private class_1838 porting_lib_item_abilities$context;

    @Inject(method = "useOn", at = @At("HEAD"))
    private void shareUseOnContext(class_1838 context, CallbackInfoReturnable<class_1269> cir) {
        porting_lib_item_abilities$context = context;
    }

    @WrapOperation(method = "evaluateNewBlockState", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/AxeItem;getStripped(Lnet/minecraft/world/level/block/state/BlockState;)Ljava/util/Optional;"))
    private Optional<class_2680> onStripToolAction(class_1743 instance, class_2680 blockState, Operation<Optional<class_2680>> original) {
        class_2680 eventState = ItemAbilityHooks.onToolUse(blockState, porting_lib_item_abilities$context, ItemAbilities.AXE_STRIP, false);
        return eventState != blockState ? Optional.ofNullable(eventState) : original.call(instance, blockState);
    }

    @WrapOperation(method = "evaluateNewBlockState", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/WeatheringCopper;getPrevious(Lnet/minecraft/world/level/block/state/BlockState;)Ljava/util/Optional;"))
    private Optional<class_2680> onScrapeToolAction(class_2680 blockState, Operation<Optional<class_2680>> original) {
        class_2680 eventState = ItemAbilityHooks.onToolUse(blockState, porting_lib_item_abilities$context, ItemAbilities.AXE_SCRAPE, false);
        return eventState != blockState ? Optional.ofNullable(eventState) : original.call(blockState);
    }

    @Inject(method = "useOn", at = @At("RETURN"))
    private void clearUseOnContext(class_1838 context, CallbackInfoReturnable<class_1269> cir) {
        porting_lib_item_abilities$context = null;
    }

    @Override
    public boolean port_lib$canPerformAction(class_1799 stack, ItemAbility ability) {
        return ItemAbilities.DEFAULT_AXE_ACTIONS.contains(ability);
    }
}
