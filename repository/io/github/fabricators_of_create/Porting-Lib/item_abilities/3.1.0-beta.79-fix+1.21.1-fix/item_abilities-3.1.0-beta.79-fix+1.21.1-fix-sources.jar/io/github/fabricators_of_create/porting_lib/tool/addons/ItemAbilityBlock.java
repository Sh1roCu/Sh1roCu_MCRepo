package io.github.fabricators_of_create.porting_lib.tool.addons;

import io.github.fabricators_of_create.porting_lib.tool.ItemAbilities;
import io.github.fabricators_of_create.porting_lib.tool.ItemAbility;
import javax.annotation.Nullable;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1821;
import net.minecraft.class_1838;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3922;
import net.minecraft.class_4865;
import net.minecraft.class_5544;
import net.minecraft.class_5545;
import net.minecraft.class_5953;
import net.minecraft.class_5955;
import java.util.Optional;

public interface ItemAbilityBlock {
	/**
	 * Returns the state that this block should transform into when right-clicked by a tool.
	 * For example: Used to determine if {@link ItemAbilities#AXE_STRIP an axe can strip},
	 * {@link ItemAbilities#SHOVEL_FLATTEN a shovel can path}, or {@link ItemAbilities#HOE_TILL a hoe can till}.
	 * Returns {@code null} if nothing should happen.
	 *
	 * @param state       The current state
	 * @param context     The use on context that the action was performed in
	 * @param itemAbility The action being performed by the tool
	 * @param simulate    If {@code true}, no actions that modify the world in any way should be performed. If {@code false}, the world may be modified.
	 * @return The resulting state after the action has been performed
	 */
	@Nullable
	default class_2680 getToolModifiedState(class_2680 state, class_1838 context, ItemAbility itemAbility, boolean simulate) {
		class_1799 itemStack = context.method_8041();
		if (!itemStack.canPerformAction(itemAbility))
			return null;

		if (ItemAbilities.AXE_STRIP == itemAbility) {
			class_2248 block = class_1743.field_7898.get(state.method_26204());
			return block != null ? block.method_9564().method_11657(class_2465.field_11459, state.method_11654(class_2465.field_11459)) : null;
		} else if (ItemAbilities.AXE_SCRAPE == itemAbility) {
			return class_5955.method_34735(state).orElse(null);
		} else if (ItemAbilities.AXE_WAX_OFF == itemAbility) {
			class_2248 waxOffBlock = class_5953.field_29561.get().get(state.method_26204());
			return Optional.ofNullable(waxOffBlock).map(block -> block.method_34725(state)).orElse(null);
		} else if (ItemAbilities.SHOVEL_FLATTEN == itemAbility) {
			return class_1821.field_8912.get(state.method_26204());
		} else if (ItemAbilities.HOE_TILL == itemAbility) {
			// Logic copied from HoeItem#TILLABLES; needs to be kept in sync during updating
			class_2248 block = state.method_26204();
			if (block == class_2246.field_28685) {
				if (!simulate && !context.method_8045().field_9236) {
					class_2248.method_36992(context.method_8045(), context.method_8037(), context.method_8038(), new class_1799(class_1802.field_28656));
				}
				return class_2246.field_10566.method_9564();
			} else if ((block == class_2246.field_10219 || block == class_2246.field_10194 || block == class_2246.field_10566 || block == class_2246.field_10253) &&
					context.method_8045().method_8320(context.method_8037().method_10084()).method_26215()) {
				return block == class_2246.field_10253 ? class_2246.field_10566.method_9564() : class_2246.field_10362.method_9564();
			}
		} else if (ItemAbilities.SHEARS_TRIM == itemAbility) {
			if (state.method_26204() instanceof class_4865 growingPlant && !growingPlant.method_38233(state)) {
				if (!simulate)
					context.method_8045().method_8396(context.method_8036(), context.method_8037(), class_3417.field_34896, class_3419.field_15245, 1.0F, 1.0F);
				return growingPlant.method_38232(state);
			}
		} else if (ItemAbilities.SHOVEL_DOUSE == itemAbility) {
			if (state.method_26204() instanceof class_3922 && state.method_11654(class_3922.field_17352)) {
				if (!simulate) {
					class_3922.method_29288(context.method_8036(), context.method_8045(), context.method_8037(), state);
				}
				return state.method_11657(class_3922.field_17352, false);
			}
		} else if (ItemAbilities.FIRESTARTER_LIGHT == itemAbility) {
			if (class_3922.method_30035(state) || class_5544.method_31630(state) || class_5545.method_31635(state)) {
				return state.method_11657(class_2741.field_12548, false);
			}
		}

		return null;
	}
}
