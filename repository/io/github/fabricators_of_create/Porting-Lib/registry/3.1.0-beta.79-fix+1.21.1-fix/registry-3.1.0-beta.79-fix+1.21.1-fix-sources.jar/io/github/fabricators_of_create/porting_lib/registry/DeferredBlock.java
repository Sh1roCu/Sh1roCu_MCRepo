package io.github.fabricators_of_create.porting_lib.registry;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

/**
 * Special {@link DeferredHolder} for {@link class_2248 Blocks} that implements {@link class_1935}.
 *
 * @param <T> The specific {@link class_2248} type.
 */
public class DeferredBlock<T extends class_2248> extends DeferredHolder<class_2248, T> implements class_1935 {
	/**
	 * Creates a new {@link class_1799} with a default size of 1 from this {@link class_2248}
	 */
	public class_1799 toStack() {
		return toStack(1);
	}

	/**
	 * Creates a new {@link class_1799} with the given size from this {@link class_2248}
	 *
	 * @param count The size of the stack to create
	 */
	public class_1799 toStack(int count) {
		class_1799 stack = method_8389().method_7854();
		if (stack.method_7960()) throw new IllegalStateException("Block does not have a corresponding item: " + this.key);
		stack.method_7939(count);
		return stack;
	}

	/**
	 * Creates a new {@link DeferredHolder} targeting the {@link class_2248} with the specified name.
	 *
	 * @param <T> The type of the target {@link class_2248}.
	 * @param key The name of the target {@link class_2248}.
	 */
	public static <T extends class_2248> DeferredBlock<T> createBlock(class_2960 key) {
		return createBlock(class_5321.method_29179(class_7924.field_41254, key));
	}

	/**
	 * Creates a new {@link DeferredHolder} targeting the specified {@link class_2248}.
	 *
	 * @param <T> The type of the target {@link class_2248}.
	 * @param key The resource key of the target {@link class_2248}.
	 */
	public static <T extends class_2248> DeferredBlock<T> createBlock(class_5321<class_2248> key) {
		return new DeferredBlock<>(key);
	}

	protected DeferredBlock(class_5321<class_2248> key) {
		super(key);
	}

	@Override
	public class_1792 method_8389() {
		return get().method_8389();
	}
}
