package io.github.fabricators_of_create.porting_lib.registry.mixin;

import io.github.fabricators_of_create.porting_lib.registry.injections.HolderInjection;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7876;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_6880.class)
public interface HolderMixin<T> extends HolderInjection<T> {
	@Mixin(class_6880.class_6883.class)
	public abstract static class ReferenceMixin<T> implements class_6880<T> {
		@Shadow
		@Nullable
		private class_5321<T> key;

		@Shadow
		@Final
		private class_7876<T> owner;

		@Nullable
		@Override
		public class_7225.class_7226<T> port_lib$unwrapLookup() {
			return this.owner instanceof class_7225.class_7226<T> rl ? rl : null;
		}

		@Nullable
		@Override
		public class_5321<T> port_lib$getKey() {
			return this.key;
		}
	}
}
