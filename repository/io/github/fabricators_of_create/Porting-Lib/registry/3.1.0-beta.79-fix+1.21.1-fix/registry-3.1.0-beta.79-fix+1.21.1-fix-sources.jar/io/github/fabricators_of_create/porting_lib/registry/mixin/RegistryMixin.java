package io.github.fabricators_of_create.porting_lib.registry.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;

import com.llamalad7.mixinextras.sugar.ref.LocalRef;

import io.github.fabricators_of_create.porting_lib.registry.DelegatedHolder;

import io.github.fabricators_of_create.porting_lib.registry.injections.RegistryInjection;
import net.minecraft.class_2378;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.expression.Definition;
import com.llamalad7.mixinextras.expression.Expression;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;

@Mixin(class_2378.class)
public interface RegistryMixin<T> extends RegistryInjection<T> {
	@Definition(id = "value", local = @Local(type = class_6880.class, argsOnly = true))
	@Definition(id = "Reference", type = class_6880.class_6883.class)
	@Expression("value instanceof Reference")
	@WrapOperation(method = "safeCastToReference", at = @At("MIXINEXTRAS:EXPRESSION"))
	private boolean checkDelegateHolder(Object object, Operation<Boolean> original, @Local(ordinal = 0, argsOnly = true) LocalRef<class_6880<?>> valueRef) {
		if (object instanceof DelegatedHolder<?> ref) {
			class_6880<?> delegated = ref.getDelegate();
			valueRef.set(delegated);
			return original.call(delegated);
		}
		return original.call(object);
	}
}
