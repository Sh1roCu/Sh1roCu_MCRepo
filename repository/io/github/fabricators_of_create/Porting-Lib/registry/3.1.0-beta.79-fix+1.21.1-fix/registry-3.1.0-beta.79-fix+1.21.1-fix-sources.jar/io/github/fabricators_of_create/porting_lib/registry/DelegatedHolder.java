package io.github.fabricators_of_create.porting_lib.registry;

import io.github.fabricators_of_create.porting_lib.registry.injections.HolderInjection;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

public interface DelegatedHolder<T> extends HolderInjection<T> {
	/**
	 * {@return the holder that this holder wraps}
	 *
	 * Used by {@link class_2378#method_57061} to resolve the underlying {@link class_6880.class_6883} for delegating holders.
	 */
	default class_6880<T> getDelegate() {
		return (class_6880<T>) this;
	}

	static <T> class_6880<T> getDelegate(class_6880<T> holder) {
		if (holder instanceof DelegatedHolder) {
			return ((DelegatedHolder<T>) holder).getDelegate();
		}

		return holder;
	}

	/**
	 * Attempts to resolve the underlying {@link class_7225.class_7226} from a {@link class_6880}.
	 * <p>
	 * This will only succeed if the underlying holder is a {@link class_6880.class_6883}.
	 */
	@Nullable
	default class_7225.class_7226<T> unwrapLookup() {
		return null;
	}

	/**
	 * Get the resource key held by this Holder, or null if none is present. This method will be overriden
	 * by Holder implementations to avoid allocation associated with {@link class_6880#method_40230()}
	 */
	@Nullable
	default class_5321<T> getKey() {
		return ((class_6880<T>) this).method_40230().orElse(null);
	}

	@Override
	default class_7225.@Nullable class_7226<T> port_lib$unwrapLookup() {
		return unwrapLookup();
	}

	@Override
	@Nullable
	default class_5321<T> port_lib$getKey() {
		return getKey();
	}
}
