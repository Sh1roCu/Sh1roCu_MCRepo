package io.github.fabricators_of_create.porting_lib.registry.injections;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public interface RegistryInjection<T> {
	/**
	 * {@return the key of the element, or null if it is not present in this registry}
	 *
	 * @apiNote This method is different from {@link class_2378#method_10221(Object)} as it does not return the default key for
	 *          {@link net.minecraft.class_7922 defaulted registries}
	 */
	@Nullable
	default class_2960 port_lib$getKeyOrNull(T element) {
		//Note: We override the cases when getKey would return the default rather than just going via getResourceKey to find it
		return ((class_2378<T>) this).method_10221(element);
	}
}
