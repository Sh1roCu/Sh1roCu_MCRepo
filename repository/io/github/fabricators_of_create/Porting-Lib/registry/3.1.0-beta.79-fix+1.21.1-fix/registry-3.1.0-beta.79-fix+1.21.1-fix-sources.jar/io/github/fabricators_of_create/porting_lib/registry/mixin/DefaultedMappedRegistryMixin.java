package io.github.fabricators_of_create.porting_lib.registry.mixin;

import com.mojang.serialization.Lifecycle;
import net.minecraft.class_2348;
import net.minecraft.class_2370;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2348.class)
public abstract class DefaultedMappedRegistryMixin<T> extends class_2370<T> {
	public DefaultedMappedRegistryMixin(class_5321<? extends class_2378<T>> key, Lifecycle registryLifecycle) {
		super(key, registryLifecycle);
	}

	@Nullable
	@Override
	public class_2960 port_lib$getKeyOrNull(T element) {
		return super.method_10221(element);
	}
}
