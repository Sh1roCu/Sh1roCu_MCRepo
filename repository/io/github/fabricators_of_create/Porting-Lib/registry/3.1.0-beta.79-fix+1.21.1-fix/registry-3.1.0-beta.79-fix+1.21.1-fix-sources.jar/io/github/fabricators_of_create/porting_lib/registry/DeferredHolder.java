package io.github.fabricators_of_create.porting_lib.registry;

import com.mojang.datafixers.util.Either;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7876;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

/**
 * A Deferred Holder is a {@link class_6880} that is constructed with only a ResourceKey.
 *
 * <p>It will be populated with the underlying Holder from the registry when available.
 *
 * @param <T> The type of object being held by this DeferredHolder.
 */
public class DeferredHolder<R, T extends R> implements class_6880<R>, Supplier<T>, DelegatedHolder<R> {
	/**
	 * Creates a new DeferredHolder targeting the value with the specified name in the specified registry.
	 *
	 * @param <T>         The type of the target value.
	 * @param <R>         The registry type.
	 * @param registryKey The name of the registry the target value is a member of.
	 * @param valueName   The name of the target value.
	 */
	public static <R, T extends R> DeferredHolder<R, T> create(class_5321<? extends class_2378<R>> registryKey, class_2960 valueName) {
		return create(class_5321.method_29179(registryKey, valueName));
	}

	/**
	 * Creates a new DeferredHolder targeting the value with the specified name in the specified registry.
	 *
	 * @param <T>          The registry type.
	 * @param registryName The name of the registry the target value is a member of.
	 * @param valueName    The name of the target value.
	 */
	public static <R, T extends R> DeferredHolder<R, T> create(class_2960 registryName, class_2960 valueName) {
		return create(class_5321.method_29180(registryName), valueName);
	}

	/**
	 * Creates a new DeferredHolder targeting the specified value.
	 *
	 * @param <T> The type of the target value.
	 * @param key The resource key of the target value.
	 */
	public static <R, T extends R> DeferredHolder<R, T> create(class_5321<R> key) {
		return new DeferredHolder<>(key);
	}

	/**
	 * The resource key of the target object.
	 */
	protected final class_5321<R> key;

	/**
	 * The currently cached value.
	 */
	@Nullable
	private class_6880<R> holder = null;

	/**
	 * Creates a new DeferredHolder with a ResourceKey.
	 *
	 * <p>Attempts to bind immediately if possible.
	 *
	 * @param key The resource key of the target object.
	 * @see #create(class_5321, class_2960)
	 * @see #create(class_2960, class_2960)
	 * @see #create(class_5321)
	 */
	protected DeferredHolder(class_5321<R> key) {
		this.key = Objects.requireNonNull(key);
		this.bind(false);
	}

	/**
	 * Gets the object stored by this DeferredHolder, if this holder {@linkplain #method_40227() is bound}.
	 *
	 * @throws IllegalStateException If the backing registry is unavailable.
	 * @throws NullPointerException  If the underlying Holder has not been populated (the target object is not registered).
	 */
	@SuppressWarnings("unchecked")
	@Override
	public T comp_349() {
		bind(true);
		if (this.holder == null) {
			throw new NullPointerException("Trying to access unbound value: " + this.key);
		}

		return (T) this.holder.comp_349();
	}

	/**
	 * Gets the object stored by this DeferredHolder, if this holder {@linkplain #method_40227() is bound}.
	 *
	 * @throws IllegalStateException If the backing registry is unavailable.
	 * @throws NullPointerException  If the underlying Holder has not been populated (the target object is not registered).
	 */
	@Override
	public T get() {
		return this.comp_349();
	}

	/**
	 * Returns an optional containing the target object, if {@link #method_40227() bound}; otherwise {@linkplain Optional#empty() an empty optional}.
	 *
	 * @return an optional containing the target object, if {@link #method_40227() bound}; otherwise {@linkplain Optional#empty() an empty optional}
	 */
	public Optional<T> asOptional() {
		return method_40227() ? Optional.of(comp_349()) : Optional.empty();
	}

	/**
	 * Returns the registry that this DeferredHolder is pointing at, or {@code null} if it doesn't exist.
	 *
	 * @return the registry that this DeferredHolder is pointing at, or {@code null} if it doesn't exist
	 */
	@Nullable
	@SuppressWarnings("unchecked")
	protected class_2378<R> getRegistry() {
		return (class_2378<R>) class_7923.field_41167.method_10223(this.key.method_41185());
	}

	/**
	 * Binds this DeferredHolder to the underlying registry and target object.
	 *
	 * <p>Has no effect if already bound.
	 *
	 * @param throwOnMissingRegistry If true, an exception will be thrown if the registry is absent.
	 * @throws IllegalStateException If throwOnMissingRegistry is true and the backing registry is unavailable.
	 */
	protected final void bind(boolean throwOnMissingRegistry) {
		if (this.holder != null) return;

		class_2378<R> registry = getRegistry();
		if (registry != null) {
			this.holder = registry.method_40264(this.key).orElse(null);
		} else if (throwOnMissingRegistry) {
			throw new IllegalStateException("Registry not present for " + this + ": " + this.key.method_41185());
		}
	}

	/**
	 * @return The ID of the object pointed to by this DeferredHolder.
	 */
	public class_2960 getId() {
		return this.key.method_29177();
	}

	/**
	 * @return The ResourceKey of the object pointed to by this DeferredHolder.
	 */
	@Override
	public class_5321<R> getKey() {
		return this.key;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		return obj instanceof class_6880<?> h && h.method_40231() == class_6882.field_36446 && h.method_40230().orElse(null) == this.key;
	}

	@Override
	public int hashCode() {
		return this.key.hashCode();
	}

	@Override
	public String toString() {
		return String.format(Locale.ENGLISH, "DeferredHolder{%s}", this.key);
	}

	/**
	 * {@return true if the underlying object is available}
	 *
	 * <p>If {@code true}, the underlying object was added to the registry,
	 * and {@link #comp_349()} or {@link #get()} can be called.
	 */
	@Override
	public boolean method_40227() {
		bind(false);
		return this.holder != null && this.holder.method_40227();
	}

	/**
	 * {@return true if the passed ResourceLocation is the same as the ID of the target object}
	 */
	@Override
	public boolean method_40226(class_2960 id) {
		return id.equals(this.key.method_29177());
	}

	/**
	 * {@return true if the passed ResourceKey is the same as this holder's resource key}
	 */
	@Override
	public boolean method_40225(class_5321<R> key) {
		return key == this.key;
	}

	/**
	 * Evaluates the passed predicate against this holder's resource key.
	 *
	 * @return {@code true} if the filter matches {@linkplain #getKey() this DH's resource key}
	 */
	@Override
	public boolean method_40224(Predicate<class_5321<R>> filter) {
		return filter.test(this.key);
	}

	/**
	 * {@return true if this holder is a member of the passed tag}
	 */
	@Override
	public boolean method_40220(class_6862<R> tag) {
		bind(false);
		return this.holder != null && this.holder.method_40220(tag);
	}

	/**
	 * {@return {@code true} if the {@code holder} is the same as this holder}
	 */
	@Override
	@Deprecated
	public boolean method_55838(class_6880<R> holder) {
		bind(false);
		return this.holder != null && this.holder.method_55838(holder);
	}

	/**
	 * {@return all tags present on the underlying object}
	 *
	 * <p>If the underlying object is not {@linkplain #method_40227() bound} yet, and empty stream is returned.
	 */
	@Override
	public Stream<class_6862<R>> method_40228() {
		bind(false);
		return this.holder != null ? this.holder.method_40228() : Stream.empty();
	}

	/**
	 * Returns an {@link Either#left()} containing {@linkplain #getKey() the resource key of this holder}.
	 *
	 * @apiNote This method is implemented for {@link class_6880} compatibility, but {@link #getKey()} should be preferred.
	 */
	@Override
	public Either<class_5321<R>, R> method_40229() {
		// Holder.Reference always returns the key, do the same here.
		return Either.left(this.key);
	}

	/**
	 * Returns the resource key of this holder.
	 *
	 * @return a present optional containing {@linkplain #getKey() the resource key of this holder}
	 * @apiNote This method is implemented for {@link class_6880} compatibility, but {@link #getKey()} should be preferred.
	 */
	@Override
	public Optional<class_5321<R>> method_40230() {
		return Optional.of(this.key);
	}

	@Override
	public class_6882 method_40231() {
		return class_6882.field_36446;
	}

	@Override
	public boolean method_46745(class_7876<R> owner) {
		bind(false);
		return this.holder != null && this.holder.method_46745(owner);
	}

	@Override
	public class_6880<R> getDelegate() {
		bind(false);
		return this.holder != null ? DelegatedHolder.getDelegate(this.holder) : this;
	}
}
