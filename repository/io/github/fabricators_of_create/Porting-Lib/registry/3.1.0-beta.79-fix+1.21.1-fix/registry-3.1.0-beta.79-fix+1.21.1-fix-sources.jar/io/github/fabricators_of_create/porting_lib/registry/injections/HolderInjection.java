package io.github.fabricators_of_create.porting_lib.registry.injections;

import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

public interface HolderInjection<T> {
	/**
	 * Attempts to resolve the underlying {@link class_7225.class_7226} from a {@link class_6880}.
	 * <p>
	 * This will only succeed if the underlying holder is a {@link class_6880.class_6883}.
	 */
	@Nullable
	default class_7225.class_7226<T> port_lib$unwrapLookup() {
		return null;
	}

	/**
	 * Get the resource key held by this Holder, or null if none is present. This method will be overriden
	 * by Holder implementations to avoid allocation associated with {@link class_6880#method_40230()}
	 */
	@Nullable
	default class_5321<T> port_lib$getKey() {
		return ((class_6880<T>) this).method_40230().orElse(null);
	}
}
