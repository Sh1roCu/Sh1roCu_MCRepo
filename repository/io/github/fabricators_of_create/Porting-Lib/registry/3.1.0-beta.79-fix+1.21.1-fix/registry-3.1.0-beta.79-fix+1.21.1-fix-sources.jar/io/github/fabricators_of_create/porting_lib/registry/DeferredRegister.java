package io.github.fabricators_of_create.porting_lib.registry;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

import net.fabricmc.fabric.api.event.registry.RegistryAttribute;
import net.fabricmc.fabric.api.event.registry.RegistryAttributeHolder;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2385;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9248;
import net.minecraft.class_9331;
import org.jetbrains.annotations.Nullable;

/**
 * A helper class to aid in registering objects to modded and {@linkplain class_7923 vanilla registries} and
 * provide deferred suppliers to access those objects.
 *
 * <p>This class maintains a list of all suppliers for entries and registers when {@linkplain #register() registered} is called.
 *
 * <p>Suppliers should return <em>new</em> instances every time they are invoked.
 *
 * <p>To create an instance of this helper class, use any of the three factory methods: {@link #create(class_2378, String)},
 * {@link #create(class_5321, String)}, or {@link #create(class_2960, String)}. There are also specialized
 * subclasses of this helper for {@link class_2248}s and {@link class_1792}s, created through {@link #createBlocks(String)} and
 * {@link #createItems(String)} respectively. (Be sure to <em>store the concrete type</em> of those subclasses, rather than
 * storing them generically as {@code DeferredRegister<Block>} or {@code DeferredRegister<Item>}.)
 *
 * <p>Here are some common examples for using this class:
 *
 * <pre>{@code
 * private static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
 * private static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
 * private static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, MODID);
 *
 * // If you don't care about the actual Block class, use the simple variants
 * public static final DeferredBlock<Block> ROCK_BLOCK = BLOCKS.registerSimpleBlock("rock", Block.Properties.create(Material.ROCK));
 * public static final DeferredItem<BlockItem> ROCK_ITEM = ITEMS.registerSimpleBlockItem(ROCK_BLOCK, new Item.Properties());
 *
 * // Otherwise, use the regular (non-'simple') variants
 * public static final DeferredBlock<SpecialRockBlock> SPECIAL_ROCK_BLOCK = BLOCKS.registerBlock("special_rock",
 *         SpecialRockBlock::new, Block.Properties.create(Material.ROCK));
 * // (#registerSimpleBlockItem does not have a non-'simple' variant -- register an item in the usual way)
 * public static final DeferredItem<SpecialRockItem> SPECIAL_ROCK_ITEM = ITEMS.register("special_rock",
 *         () -> new SpecialRockItem(SPECIAL_ROCK_BLOCK.get(), new Item.Properties()))
 *
 * // (Can be DeferredHolder<BlockEntityType<?>, BlockEntityType<RockBlockEntity>> if you prefer)
 * public static final Supplier<BlockEntityType<RockBlockEntity>> ROCK_BLOCK_ENTITY = BLOCK_ENTITIES.register("rock",
 *         () -> BlockEntityType.Builder.of(RockBlockEntity::new, ROCK_BLOCK.get()).build(null));
 *
 * public void onInitialize() {
 *     ITEMS.register();
 *     BLOCKS.register();
 *     BLOCK_ENTITIES.register();
 * }
 * }</pre>
 *
 * @param <T> the base registry type
 *
 * @see DeferredRegister.Blocks
 * @see DeferredRegister.Items
 */
public class DeferredRegister<T> {
	/**
	 * DeferredRegister factory for modded registries or {@linkplain class_7923 vanilla registries}.
	 * <p>
	 * If the registry is never created, any {@link DeferredHolder}s made from this DeferredRegister will throw an exception.
	 *
	 * @param registry  the registry to register to
	 * @param namespace the namespace for all objects registered to this DeferredRegister
	 * @see #create(class_5321, String)
	 * @see #create(class_2960, String)
	 * @see #createItems(String)
	 * @see #createBlocks(String)
	 */
	public static <T> DeferredRegister<T> create(class_2378<T> registry, String namespace) {
		return new DeferredRegister<>(registry.method_30517(), namespace);
	}

	/**
	 * DeferredRegister factory for modded registries or {@linkplain class_7923 vanilla registries} to lookup based on the provided registry key. Supports both registries that already exist or do not exist yet.
	 * <p>
	 * If the registry is never created, any {@link DeferredHolder}s made from this DeferredRegister will throw an exception.
	 *
	 * @param key       the key of the registry to reference. May come from another DeferredRegister through {@link #getRegistryKey()}.
	 * @param namespace the namespace for all objects registered to this DeferredRegister
	 * @see #create(class_2378, String)
	 * @see #create(class_2960, String)
	 * @see #createItems(String)
	 * @see #createBlocks(String)
	 */
	public static <T> DeferredRegister<T> create(class_5321<? extends class_2378<T>> key, String namespace) {
		return new DeferredRegister<>(key, namespace);
	}

	/**
	 * DeferredRegister factory for custom registries or {@link class_7923 vanilla registries} to lookup based on the provided registry name. Supports both registries that already exist or do not exist yet.
	 * <p>
	 * If the registry is never created, any {@link DeferredHolder}s made from this DeferredRegister will throw an exception.
	 *
	 * @param registryName The name of the registry, should include namespace. May come from another DeferredRegister through {@link #getRegistryName()}.
	 * @param modid        The namespace for all objects registered to this DeferredRegister
	 * @see #create(class_2378, String)
	 * @see #create(class_5321, String)
	 * @see #createItems(String)
	 * @see #createBlocks(String)
	 */
	public static <B> DeferredRegister<B> create(class_2960 registryName, String modid) {
		return new DeferredRegister<>(class_5321.method_29180(registryName), modid);
	}

	/**
	 * Factory for a specialized {@link DeferredRegister} for {@link class_1792 Items}.
	 *
	 * @param modid The namespace for all objects registered to this {@link DeferredRegister}
	 * @see #create(class_2378, String)
	 * @see #create(class_5321, String)
	 * @see #create(class_2960, String)
	 * @see #createBlocks(String)
	 */
	public static DeferredRegister.Items createItems(String modid) {
		return new Items(modid);
	}

	/**
	 * Factory for a specialized DeferredRegister for {@link class_2248 Blocks}.
	 *
	 * @param modid The namespace for all objects registered to this DeferredRegister
	 * @see #create(class_2378, String)
	 * @see #create(class_5321, String)
	 * @see #create(class_2960, String)
	 * @see #createItems(String)
	 */
	public static DeferredRegister.Blocks createBlocks(String modid) {
		return new Blocks(modid);
	}

	/**
	 * Factory for a specialized DeferredRegister for {@link class_9331 DataComponentTypes}.
	 *
	 * @param modid The namespace for all objects registered to this DeferredRegister
	 * @see #create(class_2378, String)
	 * @see #create(class_5321, String)
	 * @see #create(class_2960, String)
	 * @see #createItems(String)
	 */
	public static DataComponents createDataComponents(String modid) {
		return new DataComponents(modid);
	}

	private final class_5321<? extends class_2378<T>> registryKey;
	private final String namespace;
	private final Map<DeferredHolder<T, ? extends T>, Supplier<? extends T>> entries = new LinkedHashMap<>();
	private final Set<DeferredHolder<T, ? extends T>> entriesView = Collections.unmodifiableSet(entries.keySet());
	private final Map<class_2960, class_2960> aliases = new HashMap<>();

	@Nullable
	private class_2378<T> customRegistry;
	@Nullable
	private RegistryHolder<T> registryHolder;
	private boolean seenRegisterEvent = false;
	private boolean seenNewRegistryEvent = false;
	private boolean registeredEventBus = false;

	protected DeferredRegister(class_5321<? extends class_2378<T>> registryKey, String namespace) {
		this.registryKey = Objects.requireNonNull(registryKey);
		this.namespace = Objects.requireNonNull(namespace);
	}

	/**
	 * Adds a new entry to the list of entries to be registered and returns a {@link DeferredHolder} that will be populated with the created entry automatically.
	 *
	 * @param name The new entry's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
	 * @param sup  A factory for the new entry. The factory should not cache the created entry.
	 * @return A {@link DeferredHolder} that will track updates from the registry for this entry.
	 */
	public <I extends T> DeferredHolder<T, I> register(final String name, final Supplier<? extends I> sup) {
		return this.register(name, key -> sup.get());
	}

	/**
	 * Adds a new entry to the list of entries to be registered and returns a {@link DeferredHolder} that will be populated with the created entry automatically.
	 *
	 * @param name The new entry's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
	 * @param func A factory for the new entry. The factory should not cache the created entry.
	 * @return A {@link DeferredHolder} that will track updates from the registry for this entry.
	 */
	public <I extends T> DeferredHolder<T, I> register(final String name, final Function<class_2960, ? extends I> func) {
		if (seenRegisterEvent)
			throw new IllegalStateException("Cannot register new entries to DeferredRegister after RegisterEvent has been fired.");
		Objects.requireNonNull(name);
		Objects.requireNonNull(func);
		final class_2960 key = class_2960.method_60655(namespace, name);

		DeferredHolder<T, I> ret = createHolder(this.registryKey, key);

		if (entries.putIfAbsent(ret, () -> func.apply(key)) != null) {
			throw new IllegalArgumentException("Duplicate registration " + name);
		}

		return ret;
	}

	/**
	 * Create a {@link DeferredHolder} or an inheriting type to be stored.
	 *
	 * @param registryKey The key of the registry.
	 * @param key         The resource location of the entry.
	 * @return The new instance of {@link DeferredHolder} or an inheriting type.
	 * @param <I> The specific type of the entry.
	 */
	protected <I extends T> DeferredHolder<T, I> createHolder(class_5321<? extends class_2378<T>> registryKey, class_2960 key) {
		return DeferredHolder.create(registryKey, key);
	}

	/**
	 * This method is used to configure a custom modded registry. It can only be invoked by a single DeferredRegister instance for a given registry key.
	 *
	 * @param consumer A consumer that configures the provided RegistryBuilder during {@link NewRegistryEvent}
	 * @return The {@link class_2378} linked to {@link #getRegistryKey()}.
	 */
	public class_2378<T> makeRegistry(final Consumer<RegistryBuilder<T>> consumer) {
		return makeRegistry(this.registryKey.method_29177(), consumer);
	}

	/**
	 * Returns a supplier for the {@link class_2378} linked to this deferred register. For vanilla registries, this will always return a non-null registry. For modded registries, a non-null registry will only be returned after {@link NewRegistryEvent} fires, or if {@link #makeRegistry(Consumer)} is called on this same DeferredRegister instance.
	 * <p>
	 * To register additional DeferredRegisters for custom modded registries, use {@link #create(class_5321, String)} which can take a registry key from {@link #getRegistryKey()}.
	 */
	public Supplier<class_2378<T>> getRegistry() {
		if (this.registryHolder == null)
			this.registryHolder = new RegistryHolder<>(this.registryKey);

		return this.registryHolder;
	}

	/**
	 * Creates a tag key based on the current namespace and provided path as the location and the registry name linked to this DeferredRegister. To control the namespace, use {@link #createTagKey(class_2960)}.
	 *
	 * @see #createTagKey(class_2960)
	 */
	public class_6862<T> createTagKey(String path) {
		Objects.requireNonNull(path);
		return createTagKey(class_2960.method_60655(this.namespace, path));
	}

	/**
	 * Creates a tag key based on the provided resource location and the registry name linked to this DeferredRegister. To use the {@linkplain #getNamespace() current namespace} as the tag key namespace automatically, use {@link #createTagKey(String)}.
	 *
	 * @see #createTagKey(String)
	 */
	public class_6862<T> createTagKey(class_2960 location) {
		Objects.requireNonNull(location);
		return class_6862.method_40092(this.registryKey, location);
	}

	/**
	 * Adds an alias that maps from the name specified by <code>from</code> to the name specified by <code>to</code>.
	 * <p>
	 * Any registry lookups that target the first name will resolve as the second name, if the first name is not present.
	 *
	 * @param from The source registry name to alias from.
	 * @param to   The target registry name to alias to.
	 */
	public void addAlias(class_2960 from, class_2960 to) {
		if (seenRegisterEvent)
			throw new IllegalStateException("Cannot add aliases to DeferredRegister after RegisterEvent has been fired.");

		this.aliases.put(from, to);
	}

	/**
	 * Adds our event handler to the specified event bus, this MUST be called in order for this class to function. See {@link DeferredRegister the example usage}.
	 */
	public void register() {
		if (this.registeredEventBus)
			throw new IllegalStateException("Cannot register DeferredRegister to more than one event bus.");
		this.registeredEventBus = true;
		addRegistry();
		addEntries();
	}

	/**
	 * @return The unmodifiable view of registered entries. Useful for bulk operations on all values.
	 */
	public Collection<DeferredHolder<T, ? extends T>> getEntries() {
		return entriesView;
	}

	/**
	 * @return The registry key stored in this deferred register. Useful for creating new deferred registers based on an existing one.
	 */
	public class_5321<? extends class_2378<T>> getRegistryKey() {
		return this.registryKey;
	}

	/**
	 * @return The registry name stored in this deferred register. Useful for creating new deferred registers based on an existing one.
	 */
	public class_2960 getRegistryName() {
		return this.registryKey.method_29177();
	}

	/**
	 * {@return the modid/namespace associated with this deferred register}
	 */
	public String getNamespace() {
		return this.namespace;
	}

	private class_2378<T> makeRegistry(final class_2960 registryName, final Consumer<RegistryBuilder<T>> consumer) {
		if (registryName == null)
			throw new IllegalStateException("Cannot create a registry without specifying a registry name");
		if (class_7923.field_41167.method_10250(registryName) || this.customRegistry != null)
			throw new IllegalStateException("Cannot create a registry that already exists - " + this.registryKey);
		if (this.seenNewRegistryEvent)
			throw new IllegalStateException("Cannot create a registry after NewRegistryEvent was fired");

		RegistryBuilder<T> registryBuilder = new RegistryBuilder<>(this.registryKey);
		consumer.accept(registryBuilder);
		this.customRegistry = registryBuilder.create();
		this.registryHolder = new RegistryHolder<>(this.registryKey);
		this.registryHolder.registry = this.customRegistry;
		return this.customRegistry;
	}

	private void addEntries() {
		this.seenRegisterEvent = true;
		class_2378<T> registry = (class_2378<T>) class_7923.field_41167.method_10223(this.registryKey.method_29177());
//		this.aliases.forEach(registry::addAlias);
		for (Entry<DeferredHolder<T, ? extends T>, Supplier<? extends T>> e : entries.entrySet()) {
			class_2378.method_10230(registry, e.getKey().getId(), e.getValue().get());
			e.getKey().bind(false);
		}
	}

	private void addRegistry() {
		this.seenNewRegistryEvent = true;
		if (this.customRegistry != null) {
			RegistryAttributeHolder.get(this.customRegistry.method_30517()).addAttribute(RegistryAttribute.MODDED);
			((class_2385) class_7923.field_41167).method_10272(this.customRegistry.method_30517(), this.customRegistry, class_9248.field_49136);
		}
	}

	/**
	 * Specialized DeferredRegister for {@link class_2248 Blocks} that uses the specialized {@link DeferredBlock} as the return type for {@link #register}.
	 */
	public static class Blocks extends DeferredRegister<class_2248> {
		protected Blocks(String namespace) {
			super(class_7924.field_41254, namespace);
		}

		/**
		 * Adds a new block to the list of entries to be registered and returns a {@link DeferredHolder} that will be populated with the created block automatically.
		 *
		 * @param name The new block's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
		 * @param func A factory for the new block. The factory should not cache the created block.
		 * @return A {@link DeferredHolder} that will track updates from the registry for this block.
		 */
		@SuppressWarnings("unchecked")
		@Override
		public <B extends class_2248> DeferredBlock<B> register(String name, Function<class_2960, ? extends B> func) {
			return (DeferredBlock<B>) super.register(name, func);
		}

		/**
		 * Adds a new block to the list of entries to be registered and returns a {@link DeferredHolder} that will be populated with the created block automatically.
		 *
		 * @param name The new block's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
		 * @param sup  A factory for the new block. The factory should not cache the created block.
		 * @return A {@link DeferredHolder} that will track updates from the registry for this block.
		 */
		@Override
		public <B extends class_2248> DeferredBlock<B> register(String name, Supplier<? extends B> sup) {
			return this.register(name, key -> sup.get());
		}

		/**
		 * Adds a new block to the list of entries to be registered and returns a {@link DeferredHolder} that will be populated with the created block automatically.
		 *
		 * @param name  The new block's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
		 * @param func  A factory for the new block. The factory should not cache the created block.
		 * @param props The properties for the created block.
		 * @return A {@link DeferredHolder} that will track updates from the registry for this block.
		 * @see #registerSimpleBlock(String, class_4970.class_2251)
		 */
		public <B extends class_2248> DeferredBlock<B> registerBlock(String name, Function<class_4970.class_2251, ? extends B> func, class_4970.class_2251 props) {
			return this.register(name, () -> func.apply(props));
		}

		/**
		 * Adds a new simple {@link class_2248} to the list of entries to be registered and returns a {@link DeferredHolder} that will be populated with the created block automatically.
		 *
		 * @param name  The new block's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
		 * @param props The properties for the created block.
		 * @return A {@link DeferredHolder} that will track updates from the registry for this block.
		 * @see #registerBlock(String, Function, class_4970.class_2251)
		 */
		public DeferredBlock<class_2248> registerSimpleBlock(String name, class_4970.class_2251 props) {
			return this.registerBlock(name, class_2248::new, props);
		}

		@Override
		protected <I extends class_2248> DeferredBlock<I> createHolder(class_5321<? extends class_2378<class_2248>> registryKey, class_2960 key) {
			return DeferredBlock.createBlock(class_5321.method_29179(registryKey, key));
		}
	}

	/**
	 * Specialized DeferredRegister for {@link class_1792 Items} that uses the specialized {@link DeferredItem} as the return type for {@link #register}.
	 */
	public static class Items extends DeferredRegister<class_1792> {
		protected Items(String namespace) {
			super(class_7924.field_41197, namespace);
		}

		/**
		 * Adds a new item to the list of entries to be registered and returns a {@link DeferredItem} that will be populated with the created item automatically.
		 *
		 * @param name The new item's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
		 * @param func A factory for the new item. The factory should not cache the created item.
		 * @return A {@link DeferredItem} that will track updates from the registry for this item.
		 * @see #register(String, Supplier)
		 */
		@SuppressWarnings("unchecked")
		@Override
		public <I extends class_1792> DeferredItem<I> register(String name, Function<class_2960, ? extends I> func) {
			return (DeferredItem<I>) super.register(name, func);
		}

		/**
		 * Adds a new item to the list of entries to be registered and returns a {@link DeferredItem} that will be populated with the created item automatically.
		 *
		 * @param name The new item's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
		 * @param sup  A factory for the new item. The factory should not cache the created item.
		 * @return A {@link DeferredItem} that will track updates from the registry for this item.
		 * @see #register(String, Function)
		 */
		@Override
		public <I extends class_1792> DeferredItem<I> register(String name, Supplier<? extends I> sup) {
			return this.register(name, key -> sup.get());
		}

		/**
		 * Adds a new simple {@link class_1747} for the given {@link class_2248} to the list of entries to be registered and
		 * returns a {@link DeferredItem} that will be populated with the created item automatically.
		 *
		 * @param name       The new item's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
		 * @param block      The supplier for the block to create a {@link class_1747} for.
		 * @param properties The properties for the created {@link class_1747}.
		 * @return A {@link DeferredItem} that will track updates from the registry for this item.
		 * @see #registerSimpleBlockItem(String, Supplier)
		 * @see #registerSimpleBlockItem(class_6880, class_1792.class_1793)
		 * @see #registerSimpleBlockItem(class_6880)
		 */
		public DeferredItem<class_1747> registerSimpleBlockItem(String name, Supplier<? extends class_2248> block, class_1792.class_1793 properties) {
			return this.register(name, key -> new class_1747(block.get(), properties));
		}

		/**
		 * Adds a new simple {@link class_1747} for the given {@link class_2248} to the list of entries to be registered and
		 * returns a {@link DeferredItem} that will be populated with the created item automatically.
		 * This method uses the default {@link class_1792.class_1793}.
		 *
		 * @param name  The new item's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
		 * @param block The supplier for the block to create a {@link class_1747} for.
		 * @return A {@link DeferredItem} that will track updates from the registry for this item.
		 * @see #registerSimpleBlockItem(String, Supplier, class_1792.class_1793)
		 * @see #registerSimpleBlockItem(class_6880, class_1792.class_1793)
		 * @see #registerSimpleBlockItem(class_6880)
		 */
		public DeferredItem<class_1747> registerSimpleBlockItem(String name, Supplier<? extends class_2248> block) {
			return this.registerSimpleBlockItem(name, block, new class_1792.class_1793());
		}

		/**
		 * Adds a new simple {@link class_1747} for the given {@link class_2248} to the list of entries to be registered and
		 * returns a {@link DeferredItem} that will be populated with the created item automatically.
		 * Where the name is determined by the name of the given block.
		 *
		 * @param block      The {@link DeferredHolder} of the {@link class_2248} for the {@link class_1747}.
		 * @param properties The properties for the created {@link class_1747}.
		 * @return A {@link DeferredItem} that will track updates from the registry for this item.
		 * @see #registerSimpleBlockItem(String, Supplier, class_1792.class_1793)
		 * @see #registerSimpleBlockItem(String, Supplier)
		 * @see #registerSimpleBlockItem(class_6880)
		 */
		public DeferredItem<class_1747> registerSimpleBlockItem(class_6880<class_2248> block, class_1792.class_1793 properties) {
			return this.registerSimpleBlockItem(block.method_40230().orElseThrow().method_29177().method_12832(), block::comp_349, properties);
		}

		/**
		 * Adds a new simple {@link class_1747} for the given {@link class_2248} to the list of entries to be registered and
		 * returns a {@link DeferredItem} that will be populated with the created item automatically.
		 * Where the name is determined by the name of the given block and uses the default {@link class_1792.class_1793}.
		 *
		 * @param block The {@link DeferredHolder} of the {@link class_2248} for the {@link class_1747}.
		 * @return A {@link DeferredItem} that will track updates from the registry for this item.
		 * @see #registerSimpleBlockItem(String, Supplier, class_1792.class_1793)
		 * @see #registerSimpleBlockItem(String, Supplier)
		 * @see #registerSimpleBlockItem(class_6880, class_1792.class_1793)
		 */
		public DeferredItem<class_1747> registerSimpleBlockItem(class_6880<class_2248> block) {
			return this.registerSimpleBlockItem(block, new class_1792.class_1793());
		}

		/**
		 * Adds a new item to the list of entries to be registered and returns a {@link DeferredItem} that will be populated with the created item automatically.
		 *
		 * @param name  The new item's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
		 * @param func  A factory for the new item. The factory should not cache the created item.
		 * @param props The properties for the created item.
		 * @return A {@link DeferredItem} that will track updates from the registry for this item.
		 * @see #registerItem(String, Function)
		 * @see #registerSimpleItem(String, class_1792.class_1793)
		 * @see #registerSimpleItem(String)
		 */
		public <I extends class_1792> DeferredItem<I> registerItem(String name, Function<class_1792.class_1793, ? extends I> func, class_1792.class_1793 props) {
			return this.register(name, () -> func.apply(props));
		}

		/**
		 * Adds a new item to the list of entries to be registered and returns a {@link DeferredItem} that will be populated with the created item automatically.
		 * This method uses the default {@link class_1792.class_1793}.
		 *
		 * @param name The new item's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
		 * @param func A factory for the new item. The factory should not cache the created item.
		 * @return A {@link DeferredItem} that will track updates from the registry for this item.
		 * @see #registerItem(String, Function, class_1792.class_1793)
		 * @see #registerSimpleItem(String, class_1792.class_1793)
		 * @see #registerSimpleItem(String)
		 */
		public <I extends class_1792> DeferredItem<I> registerItem(String name, Function<class_1792.class_1793, ? extends I> func) {
			return this.registerItem(name, func, new class_1792.class_1793());
		}

		/**
		 * Adds a new simple {@link class_1792} with the given {@link class_1792.class_1793 properties} to the list of entries to be registered and
		 * returns a {@link DeferredItem} that will be populated with the created item automatically.
		 *
		 * @param name  The new item's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
		 * @param props A factory for the new item. The factory should not cache the created item.
		 * @return A {@link DeferredItem} that will track updates from the registry for this item.
		 * @see #registerItem(String, Function, class_1792.class_1793)
		 * @see #registerItem(String, Function)
		 * @see #registerSimpleItem(String)
		 */
		public DeferredItem<class_1792> registerSimpleItem(String name, class_1792.class_1793 props) {
			return this.registerItem(name, class_1792::new, props);
		}

		/**
		 * Adds a new simple {@link class_1792} with the default {@link class_1792.class_1793 properties} to the list of entries to be registered and
		 * returns a {@link DeferredItem} that will be populated with the created item automatically.
		 *
		 * @param name The new item's name. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
		 * @return A {@link DeferredItem} that will track updates from the registry for this item.
		 * @see #registerItem(String, Function, class_1792.class_1793)
		 * @see #registerItem(String, Function)
		 * @see #registerSimpleItem(String, class_1792.class_1793)
		 */
		public DeferredItem<class_1792> registerSimpleItem(String name) {
			return this.registerItem(name, class_1792::new, new class_1792.class_1793());
		}

		@Override
		protected <I extends class_1792> DeferredItem<I> createHolder(class_5321<? extends class_2378<class_1792>> registryKey, class_2960 key) {
			return DeferredItem.createItem(class_5321.method_29179(registryKey, key));
		}
	}

	/**
	 * Specialized DeferredRegister for {@link class_9331 DataComponentTypes}.
	 */
	public static class DataComponents extends DeferredRegister<class_9331<?>> {
		protected DataComponents(String namespace) {
			super(class_7924.field_49659, namespace);
		}

		/**
		 * Convenience method that constructs a builder for use in the operator. Use this to avoid inference issues.
		 *
		 * @param name    The name for this data component type. It will automatically have the {@linkplain #getNamespace() namespace} prefixed.
		 * @param builder The unary operator, which is passed a new builder for user operations, then builds it upon registration.
		 * @return A {@link DeferredHolder} which reflects the data that will be registered.
		 */
		public <D> DeferredHolder<class_9331<?>, class_9331<D>> registerComponentType(String name, UnaryOperator<class_9331.class_9332<D>> builder) {
			return this.register(name, () -> builder.apply(class_9331.method_57873()).method_57880());
		}
	}

	private static class RegistryHolder<V> implements Supplier<class_2378<V>> {
		private final class_5321<? extends class_2378<V>> registryKey;
		private class_2378<V> registry = null;

		private RegistryHolder(class_5321<? extends class_2378<V>> registryKey) {
			this.registryKey = registryKey;
		}

		@SuppressWarnings("unchecked")
		@Override
		public @Nullable class_2378<V> get() {
			// Keep looking up the registry until it's not null
			if (this.registry == null)
				this.registry = (class_2378<V>) class_7923.field_41167.method_10223(this.registryKey.method_29177());

			return this.registry;
		}
	}
}
