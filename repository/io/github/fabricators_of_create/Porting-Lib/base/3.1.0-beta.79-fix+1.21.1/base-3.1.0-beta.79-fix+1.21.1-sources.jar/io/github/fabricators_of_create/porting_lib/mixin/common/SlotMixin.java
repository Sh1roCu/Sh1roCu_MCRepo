package io.github.fabricators_of_create.porting_lib.mixin.common;

import com.mojang.datafixers.util.Pair;

import io.github.fabricators_of_create.porting_lib.extensions.common.SlotExtension;
import net.minecraft.class_1263;
import net.minecraft.class_1735;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1735.class)
public abstract class SlotMixin implements SlotExtension {
	@Shadow
	@Final
	private int slot;

	@Shadow
	@Final
	public class_1263 container;

	private Pair<class_2960, class_2960> port_lib$backgroundPair = null;

	@Inject(method = "getNoItemIcon", at = @At("HEAD"), cancellable = true)
	private void port_lib$setNoItemIcon(CallbackInfoReturnable<@Nullable Pair<class_2960, class_2960>> cir) {
		if (this.port_lib$backgroundPair != null) {
			cir.setReturnValue(this.port_lib$backgroundPair);
		}
	}

	@Override
	public class_1735 port_lib$setBackground(class_2960 atlas, class_2960 sprite) {
		this.port_lib$backgroundPair = Pair.of(atlas, sprite);
		return (class_1735) (Object) this;
	}

	@Override
	public int port_lib$getSlotIndex() {
		return slot;
	}

	@Override
	public boolean port_lib$isSameInventory(class_1735 other) {
		return this.container == other.field_7871;
	}
}
