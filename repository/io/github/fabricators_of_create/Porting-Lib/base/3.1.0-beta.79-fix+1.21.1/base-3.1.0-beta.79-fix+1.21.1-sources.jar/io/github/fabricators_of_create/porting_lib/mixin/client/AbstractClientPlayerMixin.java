package io.github.fabricators_of_create.porting_lib.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import io.github.fabricators_of_create.porting_lib.event.client.FieldOfViewEvents;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_742.class)
public abstract class AbstractClientPlayerMixin {
  @ModifyExpressionValue(
		  method = "getFieldOfViewModifier",
		  at = @At(
				  value = "INVOKE",
				  target = "Lnet/minecraft/util/Mth;lerp(FFF)F"
		  )
  )
  private float port_lib$modifyFovModifier(float fov) {
	  // returns original if unchanged, this is safe
	  return FieldOfViewEvents.MODIFY.invoker().modifyFov((class_742) (Object) this, fov);
  }
}
