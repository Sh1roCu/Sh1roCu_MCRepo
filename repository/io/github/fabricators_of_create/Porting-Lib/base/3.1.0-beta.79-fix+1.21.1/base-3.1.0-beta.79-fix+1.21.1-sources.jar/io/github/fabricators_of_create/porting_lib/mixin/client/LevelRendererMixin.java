package io.github.fabricators_of_create.porting_lib.mixin.client;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.fabricators_of_create.porting_lib.client.dimesnion.DimensionSpecialEffectsRenderer;
import io.github.fabricators_of_create.porting_lib.event.client.DrawSelectionEvents;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4599;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_761.class)
public abstract class LevelRendererMixin {
	@Shadow
	@Final
	private class_4599 renderBuffers;

	@Shadow
	@Final
	private class_310 minecraft;

	@Shadow
	@Nullable
	private class_638 level;

	@Shadow
	private int ticks;

	@WrapWithCondition(method = "renderLevel", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/LevelRenderer;renderHitOutline(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/world/entity/Entity;DDDLnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V"))
	private boolean renderBlockOutline(class_761 self, class_4587 poseStack, class_4588 vertexConsumer, class_1297 entity, double camX, double camY, double camZ, class_2338 blockPos, class_2680 blockState,
			/* enclosing args */class_9779 deltaTracker, boolean bl, class_4184 camera) {
		return !DrawSelectionEvents.BLOCK.invoker().onHighlightBlock(self, camera, minecraft.field_1765, deltaTracker, poseStack, renderBuffers.method_23000());
	}

	@Inject(method = "renderLevel", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/debug/DebugRenderer;render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource$BufferSource;DDD)V"))
	private void port_lib$renderEntityOutline(class_9779 deltaTracker, boolean bl, class_4184 camera, class_757 gameRenderer, class_765 lightTexture, Matrix4f matrix4f, Matrix4f matrix4f2, CallbackInfo ci, @Local(index = 24) class_4587 poseStack) {
		class_239 hitresult = minecraft.field_1765;
		if (hitresult != null && hitresult.method_17783() == class_239.class_240.field_1331) {
			DrawSelectionEvents.ENTITY.invoker().onHighlightEntity((class_761) (Object) this, camera, hitresult, deltaTracker, poseStack, this.renderBuffers.method_23000());
		}
	}

	@Inject(method = "tickRain", at = @At("HEAD"), cancellable = true)
	private void port_lib$customRainTick(class_4184 camera, CallbackInfo ci) {
		if (level.method_28103() instanceof DimensionSpecialEffectsRenderer renderer)
			if (renderer.tickRain(level, ticks, camera))
				ci.cancel();
	}

	@Inject(method = "renderClouds", at = @At("HEAD"), cancellable = true)
	private void renderCustomClouds(class_4587 poseStack, Matrix4f modelViewMatrix, Matrix4f projectionMatrix, float pPartialTick, double pCamX, double pCamY, double pCamZ, CallbackInfo ci) {
		if (level.method_28103() instanceof DimensionSpecialEffectsRenderer renderer)
			if (renderer.renderClouds(level, ticks, pPartialTick, poseStack, pCamX, pCamY, pCamZ, modelViewMatrix, projectionMatrix))
				ci.cancel();
	}

	@Inject(method = "renderSky", at = @At("HEAD"), cancellable = true)
	private void renderCustomSky(Matrix4f modelViewMatrix, Matrix4f pProjectionMatrix, float pPartialTick, class_4184 pCamera, boolean pIsFoggy, Runnable pSkyFogSetup, CallbackInfo ci) {
		if (level.method_28103() instanceof DimensionSpecialEffectsRenderer renderer)
			if (renderer.renderSky(level, ticks, pPartialTick, modelViewMatrix, pCamera, pProjectionMatrix, pIsFoggy, pSkyFogSetup))
				ci.cancel();
	}

	@Inject(method = "renderSnowAndRain", at = @At("HEAD"), cancellable = true)
	private void renderCustomWeather(class_765 pLightTexture, float pPartialTick, double pCamX, double pCamY, double pCamZ, CallbackInfo ci) {
		if (level.method_28103() instanceof DimensionSpecialEffectsRenderer renderer)
			if (renderer.renderSnowAndRain(level, ticks, pPartialTick, pLightTexture, pCamX, pCamY, pCamZ))
				ci.cancel();
	}
}
