package io.github.fabricators_of_create.porting_lib.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.event.common.ExplosionEvents;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1927;
import net.minecraft.class_1937;

@Mixin(class_1927.class)
public abstract class ExplosionMixin {

	@Shadow
	@Final
	private class_1937 level;

	@Inject(method = "explode", at = @At(value = "NEW", target = "net/minecraft/world/phys/Vec3", ordinal = 1))
	public void onExplode(CallbackInfo ci, @Local float j, @Local List<class_1297> list) {
		ExplosionEvents.DETONATE.invoker().onDetonate(this.level, (class_1927) (Object) this, list, j);
	}
}
