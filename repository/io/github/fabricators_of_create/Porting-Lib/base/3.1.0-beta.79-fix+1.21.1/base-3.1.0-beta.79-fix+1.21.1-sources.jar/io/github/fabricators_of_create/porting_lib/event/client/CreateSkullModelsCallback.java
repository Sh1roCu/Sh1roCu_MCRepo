package io.github.fabricators_of_create.porting_lib.event.client;

import com.google.common.collect.ImmutableMap;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_2484;
import net.minecraft.class_5598;
import net.minecraft.class_5599;

/**
 * @deprecated Use {@link io.github.fabricators_of_create.porting_lib.client_events.event.client.EntityRenderersEvent.CreateSkullModels} in the {@code client_events} module.
 */
@Deprecated(forRemoval = true)
public interface CreateSkullModelsCallback {
	Event<CreateSkullModelsCallback> EVENT = EventFactory.createArrayBacked(CreateSkullModelsCallback.class, callbacks -> (builder, entityModelSet) -> {
		for (CreateSkullModelsCallback e : callbacks)
			e.onSkullModelsCreated(builder, entityModelSet);
	});

	void onSkullModelsCreated(ImmutableMap.Builder<class_2484.class_2485, class_5598> builder, class_5599 entityModelSet);
}
