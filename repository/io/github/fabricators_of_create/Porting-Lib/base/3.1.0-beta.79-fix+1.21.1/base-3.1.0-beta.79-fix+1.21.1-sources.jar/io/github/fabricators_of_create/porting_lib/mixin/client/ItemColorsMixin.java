package io.github.fabricators_of_create.porting_lib.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.event.client.ColorHandlersCallback;
import net.minecraft.class_324;
import net.minecraft.class_325;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_325.class)
public abstract class ItemColorsMixin {
  @Inject(method = "createDefault", at = @At("TAIL"))
  private static void registerModdedColorHandlers(class_324 colors, CallbackInfoReturnable<class_325> cir, @Local class_325 itemcolors) {
    ColorHandlersCallback.ITEM.invoker().registerItemColors(itemcolors, colors);
  }
}
