package io.github.fabricators_of_create.porting_lib.event.common;

import io.github.fabricators_of_create.porting_lib.core.event.entity.player.PlayerEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1657;
import net.minecraft.class_167;
import net.minecraft.class_8779;

/**
 * Base class used for advancement-related events. Should not be used directly.
 *
 * @see AdvancementEarnEvent
 * @see AdvancementProgressEvent
 */
public abstract class AdvancementEvent extends PlayerEvent {
	public static final Event<EarnCallback> EARN = EventFactory.createArrayBacked(EarnCallback.class, callbacks -> event -> {
		for (EarnCallback c : callbacks)
			c.onAdvancementEarn(event);
	});
	public static final Event<ProgressCallback> PROGRESS = EventFactory.createArrayBacked(ProgressCallback.class, callbacks -> event -> {
		for (ProgressCallback c : callbacks)
			c.onAdvancementProgress(event);
	});
	private final class_8779 advancement;

	public AdvancementEvent(class_1657 player, class_8779 advancement) {
		super(player);
		this.advancement = advancement;
	}

	public class_8779 getAdvancement() {
		return advancement;
	}

	/**
	 * Fired when the player earns an advancement. An advancement is earned once its requirements are complete.
	 *
	 * <p>Note that advancements may be hidden from the player or used in background mechanics, such as recipe
	 * advancements for unlocking recipes in the recipe book.</p>
	 *
	 * @see class_167#method_740()
	 */
	public static class AdvancementEarnEvent extends AdvancementEvent {
		public AdvancementEarnEvent(class_1657 player, class_8779 earned) {
			super(player, earned);
		}

		@Override
		public void sendEvent() {
			EARN.invoker().onAdvancementEarn(this);
		}
	}

	/**
	 * Fired when the player's progress on an advancement criterion is granted or revoked.
	 *
	 * <p>This event is not cancellable, and does not have a result.</p>
	 *
	 * @see AdvancementEarnEvent
	 * @see net.minecraft.class_2985#method_12878(class_8779, String)
	 * @see net.minecraft.class_2985#method_12883(class_8779, String)
	 */
	public static class AdvancementProgressEvent extends AdvancementEvent {
		private final class_167 advancementProgress;
		private final String criterionName;
		private final AdvancementEvent.AdvancementProgressEvent.ProgressType progressType;

		public AdvancementProgressEvent(class_1657 player, class_8779 progressed, class_167 advancementProgress, String criterionName, AdvancementEvent.AdvancementProgressEvent.ProgressType progressType) {
			super(player, progressed);
			this.advancementProgress = advancementProgress;
			this.criterionName = criterionName;
			this.progressType = progressType;
		}

		/**
		 * {@return the progress of the advancement}
		 */
		public class_167 getAdvancementProgress() {
			return advancementProgress;
		}

		/**
		 * {@return name of the criterion that was progressed}
		 */
		public String getCriterionName() {
			return criterionName;
		}

		/**
		 * {@return The type of progress for the criterion in this event}
		 */
		public ProgressType getProgressType() {
			return progressType;
		}

		@Override
		public void sendEvent() {
			PROGRESS.invoker().onAdvancementProgress(this);
		}

		public enum ProgressType {
			GRANT, REVOKE
		}
	}

	@FunctionalInterface
	public interface EarnCallback {
		void onAdvancementEarn(AdvancementEarnEvent event);
	}

	@FunctionalInterface
	public interface ProgressCallback {
		void onAdvancementProgress(AdvancementProgressEvent event);
	}
}
