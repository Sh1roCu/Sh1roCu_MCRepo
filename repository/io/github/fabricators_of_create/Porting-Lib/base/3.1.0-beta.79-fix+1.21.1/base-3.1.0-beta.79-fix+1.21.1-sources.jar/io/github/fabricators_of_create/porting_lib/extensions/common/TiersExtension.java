package io.github.fabricators_of_create.porting_lib.extensions.common;

import net.minecraft.class_2248;
import net.minecraft.class_6862;
import org.jetbrains.annotations.Nullable;

public interface TiersExtension {
	@Nullable
	default class_6862<class_2248> getTag() {
		return null;
	}
}
