package io.github.fabricators_of_create.porting_lib.extensions.common;

import net.minecraft.class_2338;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_4538;

public interface StructureProcessorExtension {
	default class_3499.class_3502 port_lib$processEntity(class_4538 world, class_2338 seedPos, class_3499.class_3502 rawEntityInfo, class_3499.class_3502 entityInfo, class_3492 placementSettings, class_3499 template) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}
