package io.github.fabricators_of_create.porting_lib.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomFrictionBlock;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1690;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

@Mixin(class_1690.class)
public abstract class BoatMixin extends class_1297 {
	// you can't capture locals in a @ModifyVariable, so we have this
	@Unique
	private class_2680 port_lib$state;
	@Unique
	private class_2338.class_2339 port_lib$pos;

	public BoatMixin(class_1299<?> entityType, class_1937 level) {
		super(entityType, level);
	}

	@Inject(
			method = "getGroundFriction()F",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/block/Block;getFriction()F"
			)
	)
	public void port_lib$storeVariables(CallbackInfoReturnable<Float> cir, @Local class_2338.class_2339 mutable, @Local class_2680 blockState) {
		port_lib$state = blockState;
		port_lib$pos = mutable;
	}

	@ModifyVariable(
			method = "getGroundFriction",
			at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/world/level/block/Block;getFriction()F")
	)
	private float port_lib$setFriction(float original) {
		if (port_lib$state.method_26204() instanceof CustomFrictionBlock custom) {
			return custom.getFriction(port_lib$state, method_37908(), port_lib$pos, this);
		}
		return original;
	}
}
