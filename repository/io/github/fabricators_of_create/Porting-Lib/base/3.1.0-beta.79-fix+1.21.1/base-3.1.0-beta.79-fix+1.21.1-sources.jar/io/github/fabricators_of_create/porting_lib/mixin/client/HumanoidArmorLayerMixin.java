package io.github.fabricators_of_create.porting_lib.mixin.client;

import io.github.fabricators_of_create.porting_lib.client.armor.ArmorRenderer;
import io.github.fabricators_of_create.porting_lib.client.armor.ArmorRendererRegistry;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_970;

@Environment(EnvType.CLIENT)
@Mixin(class_970.class)
public abstract class HumanoidArmorLayerMixin extends class_3887<class_1309, class_572<class_1309>> {

	public HumanoidArmorLayerMixin(class_3883<class_1309, class_572<class_1309>> renderLayerParent) {
		super(renderLayerParent);
	}

	@Inject(method = "renderArmorPiece", at = @At("HEAD"), cancellable = true)
	public<T extends class_1309, A extends class_572<T>> void port_lib$armorRegistry(class_4587 matrices, class_4597 vertexConsumers, T entity, class_1304 armorSlot, int light, class_572<class_1309> armorModel, CallbackInfo ci) {
		class_1799 stack = entity.method_6118(armorSlot);
		ArmorRenderer renderer = ArmorRendererRegistry.get(stack.method_7909());

		if (renderer != null) {
			renderer.render(matrices, vertexConsumers, stack, entity, armorSlot, light, method_17165(), armorModel);
			ci.cancel();
		}
	}
}
