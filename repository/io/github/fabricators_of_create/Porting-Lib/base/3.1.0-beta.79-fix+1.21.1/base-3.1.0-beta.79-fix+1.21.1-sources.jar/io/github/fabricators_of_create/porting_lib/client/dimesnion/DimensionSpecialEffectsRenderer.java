package io.github.fabricators_of_create.porting_lib.client.dimesnion;

import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_638;
import net.minecraft.class_765;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Implement on {@link net.minecraft.class_5294} to support custom rendering.
 */
public interface DimensionSpecialEffectsRenderer {
	/**
	 * Renders the clouds of this dimension.
	 *
	 * @return true to prevent vanilla cloud rendering
	 */
	default boolean renderClouds(class_638 level, int ticks, float partialTick, class_4587 poseStack, double camX, double camY, double camZ, Matrix4f modelViewMatrix, Matrix4f projectionMatrix) {
		return false;
	}

	/**
	 * Renders the sky of this dimension.
	 *
	 * @return true to prevent vanilla sky rendering
	 */
	default boolean renderSky(class_638 level, int ticks, float partialTick, Matrix4f modelViewMatrix, class_4184 camera, Matrix4f projectionMatrix, boolean isFoggy, Runnable setupFog) {
		return false;
	}

	/**
	 * Renders the snow and rain effects of this dimension.
	 *
	 * @return true to prevent vanilla snow and rain rendering
	 */
	default boolean renderSnowAndRain(class_638 level, int ticks, float partialTick, class_765 lightTexture, double camX, double camY, double camZ) {
		return false;
	}

	/**
	 * Ticks the rain of this dimension.
	 *
	 * @return true to prevent vanilla rain ticking
	 */
	default boolean tickRain(class_638 level, int ticks, class_4184 camera) {
		return false;
	}

	/**
	 * Allows for manipulating the coloring of the lightmap texture.
	 * Will be called for each 16*16 combination of sky/block light values.
	 *
	 * @param level        The current level (client-side).
	 * @param partialTicks Progress between ticks.
	 * @param skyDarken    Current darkness of the sky.
	 * @param skyLight     Sky light brightness factor.
	 * @param blockLight   Block light brightness factor.
	 * @param pixelX       X-coordinate of the lightmap texture.
	 * @param pixelY       Y-coordinate of the lightmap texture.
	 * @param colors       The color values that will be used: [r, g, b].
	 * @see class_765#method_3313(float)
	 */
	default void adjustLightmapColors(class_638 level, float partialTicks, float skyDarken, float skyLight, float blockLight, int pixelX, int pixelY, Vector3f colors) {}
}
