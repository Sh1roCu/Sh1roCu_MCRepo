package io.github.fabricators_of_create.porting_lib.mixin.common;

import org.spongepowered.asm.mixin.Mixin;

import io.github.fabricators_of_create.porting_lib.extensions.common.StructureProcessorExtension;
import net.minecraft.class_2338;
import net.minecraft.class_3491;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_4538;

@Mixin(class_3491.class)
public abstract class StructureProcessorMixin implements StructureProcessorExtension {
	@Override
	public class_3499.class_3502 port_lib$processEntity(class_4538 world, class_2338 seedPos, class_3499.class_3502 rawEntityInfo,
																		class_3499.class_3502 entityInfo, class_3492 placementSettings,
																		class_3499 template) {
		return entityInfo;
	}
}
