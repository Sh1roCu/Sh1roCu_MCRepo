package io.github.fabricators_of_create.porting_lib.util;

import net.minecraft.class_2586;
import net.minecraft.class_2618;
import net.minecraft.class_2745;
import net.minecraft.class_4730;

public interface MaterialChest<T extends class_2586 & class_2618> {
	 class_4730 getMaterial(T blockEntity, class_2745 chestType);
}
