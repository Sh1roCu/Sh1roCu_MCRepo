package io.github.fabricators_of_create.porting_lib.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.util.client.ClientHooks;
import net.minecraft.class_1921;
import net.minecraft.class_2680;
import net.minecraft.class_776;

@Mixin(class_776.class)
public class BlockRenderDispatcherMixin {
	@WrapOperation(method = "renderSingleBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ItemBlockRenderTypes;getRenderType(Lnet/minecraft/world/level/block/state/BlockState;Z)Lnet/minecraft/client/renderer/RenderType;"))
	private class_1921 useCustomRenderType(class_2680 state, boolean fancy, Operation<class_1921> operation) {
		if (ClientHooks.RENDER_TYPE != null)
			return ClientHooks.RENDER_TYPE;
		return operation.call(state, fancy);
	}
}
