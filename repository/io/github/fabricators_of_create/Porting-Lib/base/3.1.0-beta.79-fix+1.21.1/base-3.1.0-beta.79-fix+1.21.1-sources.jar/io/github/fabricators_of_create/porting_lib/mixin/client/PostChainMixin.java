package io.github.fabricators_of_create.porting_lib.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_276;
import net.minecraft.class_279;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_279.class)
public abstract class PostChainMixin {
	@Shadow
	@Final
	private class_276 screenTarget;

	@Inject(
			method = "addTempTarget",
			at = @At(
					value = "INVOKE",
					target = "Lcom/mojang/blaze3d/pipeline/RenderTarget;setClearColor(FFFF)V",
					shift = At.Shift.AFTER
			)
	)
	public void port_lib$isStencil(String name, int width, int height, CallbackInfo ci, @Local class_276 rendertarget) {
		if (screenTarget.port_lib$isStencilEnabled()) {
			rendertarget.port_lib$enableStencil();
		}
	}
}
