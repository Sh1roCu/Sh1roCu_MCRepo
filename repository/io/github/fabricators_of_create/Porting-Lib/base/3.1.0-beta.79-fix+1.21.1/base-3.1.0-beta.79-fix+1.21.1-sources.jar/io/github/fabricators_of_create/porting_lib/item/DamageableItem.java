package io.github.fabricators_of_create.porting_lib.item;

import net.minecraft.class_1799;
import net.minecraft.class_3532;
import net.minecraft.class_9334;

public interface DamageableItem {
	/**
	 * Return the itemDamage represented by this ItemStack. Defaults to the Damage
	 * entry in the stack NBT, but can be overridden here for other sources.
	 *
	 * @param stack The itemstack that is damaged
	 * @return the damage value
	 */
	default int getDamage(class_1799 stack) {
		return class_3532.method_15340(stack.method_57825(class_9334.field_49629, 0), 0, stack.method_7936());
	}

	/**
	 * Return the maxDamage for this ItemStack. Defaults to the maxDamage field in
	 * this item, but can be overridden here for other sources such as NBT.
	 *
	 * @param stack The itemstack that is damaged
	 * @return the damage value
	 */
	default int getMaxDamage(class_1799 stack) {
		return stack.method_57825(class_9334.field_50072, 0);
	}

	/**
	 * Set the damage for this itemstack. Note, this method is responsible for zero
	 * checking.
	 *
	 * @param stack  the stack
	 * @param damage the new damage value
	 */
	default void setDamage(class_1799 stack, int damage) {
		stack.method_57379(class_9334.field_49629, class_3532.method_15340(damage, 0, stack.method_7936()));
	}
}
