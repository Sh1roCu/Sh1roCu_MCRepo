package io.github.fabricators_of_create.porting_lib.util;

import java.util.function.Supplier;

import javax.annotation.Nonnull;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_3414;
import io.github.fabricators_of_create.porting_lib.registry.DeferredRegister;

/**
 * A subclass of {@link class_2498} that uses {@link Supplier<SoundEvent>}s.
 * <p>
 * This class allows mod developers to safely create custom {@code SoundType}s for use in their e.g. {@link class_2248}.
 * <p>
 * The problem with using {@code SoundType} directly is it requires {@link class_3414} instances directly, because
 * {@code SoundType}s are required to be present during {@link class_2248} creation and registration. However,
 * {@code SoundEvent} must also be registered.
 * <p>
 * A possible solution of initializing {@code SoundEvent}s first would require static initialization of the
 * {@code SoundEvent} instances and later registration, which goes against the contract of the registry system and
 * prevents the use of {@link DeferredRegister} and {@link RegistryObject}s.
 * <p>
 * This class offers an alternative and preferable solution, by allowing mods to create {@link class_2498}s using
 * {@link Supplier}s of {@link class_3414}s instead, which do not require static initialization of {@code SoundEvent}s
 * and allow the direct use of {@code RegistryObject}s.
 *
 * @see class_2498
 */
public class LazySoundType extends class_2498 {
	private final Supplier<class_3414> breakSound;
	private final Supplier<class_3414> stepSound;
	private final Supplier<class_3414> placeSound;
	private final Supplier<class_3414> hitSound;
	private final Supplier<class_3414> fallSound;

	public LazySoundType(float volumeIn, float pitchIn, Supplier<class_3414> breakSoundIn, Supplier<class_3414> stepSoundIn, Supplier<class_3414> placeSoundIn, Supplier<class_3414> hitSoundIn, Supplier<class_3414> fallSoundIn) {
		super(volumeIn, pitchIn, (class_3414) null, (class_3414) null, (class_3414) null, (class_3414) null, (class_3414) null);
		this.breakSound = breakSoundIn;
		this.stepSound = stepSoundIn;
		this.placeSound = placeSoundIn;
		this.hitSound = hitSoundIn;
		this.fallSound = fallSoundIn;
	}

	@Nonnull
	@Override
	public class_3414 method_10595() {
		return breakSound.get();
	}

	@Nonnull
	@Override
	public class_3414 method_10594() {
		return stepSound.get();
	}

	@Nonnull
	@Override
	public class_3414 method_10598() {
		return placeSound.get();
	}

	@Nonnull
	@Override
	public class_3414 method_10596() {
		return hitSound.get();
	}

	@Nonnull
	@Override
	public class_3414 method_10593() {
		return fallSound.get();
	}
}
