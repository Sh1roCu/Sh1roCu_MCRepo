package io.github.fabricators_of_create.porting_lib.util;

import io.github.fabricators_of_create.porting_lib.core.util.MixinHelper;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_3675.class_306;

@Environment(EnvType.CLIENT)
public final class KeyBindingHelper {
	public static boolean isActiveAndMatches(class_304 keyMapping, class_306 keyCode) {
		return keyCode != class_3675.field_16237 && keyCode.equals(net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.getBoundKeyOf(keyMapping));
	}

	private KeyBindingHelper() { }
}
