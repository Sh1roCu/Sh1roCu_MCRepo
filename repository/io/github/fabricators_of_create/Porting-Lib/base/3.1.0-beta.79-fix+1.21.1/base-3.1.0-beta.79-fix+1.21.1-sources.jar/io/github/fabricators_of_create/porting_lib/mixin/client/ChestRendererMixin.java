package io.github.fabricators_of_create.porting_lib.mixin.client;

import java.util.function.Function;
import net.minecraft.class_1921;
import net.minecraft.class_2586;
import net.minecraft.class_2618;
import net.minecraft.class_2745;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_826;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.util.MaterialChest;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import com.llamalad7.mixinextras.injector.ModifyReceiver;

@Mixin(class_826.class)
public abstract class ChestRendererMixin<T extends class_2586 & class_2618> {

	@Unique
	private class_4730 port_lib$customMaterial = null;

	@Inject(
			method = "render(Lnet/minecraft/world/level/block/entity/BlockEntity;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;II)V",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/Sheets;chooseMaterial(Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/level/block/state/properties/ChestType;Z)Lnet/minecraft/client/resources/model/Material;")
	)
	public void port_lib$customChestMaterial(T blockEntity, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight, int packedOverlay, CallbackInfo ci, @Local class_2745 chestType) {
		if (this instanceof MaterialChest materialChest)
			port_lib$customMaterial = materialChest.getMaterial(blockEntity, chestType);
	}

	@ModifyReceiver(
			method = "render(Lnet/minecraft/world/level/block/entity/BlockEntity;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;II)V",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/client/resources/model/Material;buffer(Lnet/minecraft/client/renderer/MultiBufferSource;Ljava/util/function/Function;)Lcom/mojang/blaze3d/vertex/VertexConsumer;")
	)
	public class_4730 port_lib$customMaterial(class_4730 old, class_4597 buffer, Function<class_2960, class_1921> renderTypeGetter) {
		return port_lib$customMaterial != null ? port_lib$customMaterial : old;
	}
}
