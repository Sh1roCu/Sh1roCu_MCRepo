package io.github.fabricators_of_create.porting_lib.client.entity;

import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1690;
import net.minecraft.class_2960;
import net.minecraft.class_4595;

public interface CustomBoatModel {
	Pair<class_2960, class_4595<class_1690>> getModelWithLocation(class_1690 boat);
}
