package io.github.fabricators_of_create.porting_lib.event.client;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_2960;
import net.minecraft.class_324;
import net.minecraft.class_3695;
import net.minecraft.class_793;
import net.minecraft.class_9824;
import java.util.List;
import java.util.Map;

public interface ModelLoadCallback {
	Event<ModelLoadCallback> EVENT = EventFactory.createArrayBacked(ModelLoadCallback.class, callbacks -> (colors, profiler, modelResources, blockStateResources) -> {
		for (ModelLoadCallback e : callbacks)
			e.onModelsStartLoading(colors, profiler, modelResources, blockStateResources);
	});


	void onModelsStartLoading(class_324 colors, class_3695 profiler, Map<class_2960, class_793> modelResources, Map<class_2960, List<class_9824.class_7777>> blockStateResources);
}
