package io.github.fabricators_of_create.porting_lib.mixin.client;

import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_3300;
import net.minecraft.class_897;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import io.github.fabricators_of_create.porting_lib.event.client.EntityAddedLayerCallback;

@Mixin(class_898.class)
public abstract class EntityRenderDispatcherMixin {
	@Shadow
	private Map<class_1299<?>, class_897<?>> renderers;

	@Shadow
	private Map<String, class_897<? extends class_1657>> playerRenderers;

	@Inject(method = "onResourceManagerReload", at = @At("TAIL"))
	public void port_lib$resourceReload(class_3300 resourceManager, CallbackInfo ci) {
		EntityAddedLayerCallback.EVENT.invoker().addLayers(renderers, playerRenderers);
	}
}
