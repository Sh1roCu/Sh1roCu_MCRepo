package io.github.fabricators_of_create.porting_lib.event.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_6854;
import net.minecraft.class_758;

@Environment(EnvType.CLIENT)
public class FogEvents {
	public static final Event<SetDensity> SET_DENSITY = EventFactory.createArrayBacked(SetDensity.class, callbacks -> (info, density) -> {
		for (SetDensity callback : callbacks) {
			return callback.setDensity(info, density);
		}
		return density;
	});

	public static final Event<SetColor> SET_COLOR = EventFactory.createArrayBacked(SetColor.class, callbacks -> (data, partialTicks) -> {
		for (SetColor callback : callbacks) {
			callback.setColor(data, partialTicks);
		}
	});

	public static final Event<RenderFog> RENDER_FOG = EventFactory.createArrayBacked(RenderFog.class, callbacks -> (mode, type, camera, partialTick, renderDistance, nearDistance, farDistance, shape, fogData) -> {
		for (RenderFog callback : callbacks) {
			if (callback.onFogRender(mode, type, camera, partialTick, renderDistance, nearDistance, farDistance, shape, fogData))
				return true;
		}
		return false;
	});

	private FogEvents() {
	}

	@FunctionalInterface
	public interface SetDensity {
		float setDensity(class_4184 activeRenderInfo, float density);
	}

	@FunctionalInterface
	public interface SetColor {
		void setColor(ColorData d, float partialTicks);
	}

	@FunctionalInterface
	public interface RenderFog {
		boolean onFogRender(class_758.class_4596 mode, class_5636 type, class_4184 camera, float partialTick, float renderDistance, float nearDistance, float farDistance, class_6854 shape, FogData fogData);
	}

	public static class FogData {
		private float farPlaneDistance;
		private float nearPlaneDistance;
		private class_6854 fogShape;

		public FogData(float nearPlaneDistance, float farPlaneDistance, class_6854 fogShape) {
			setFarPlaneDistance(farPlaneDistance);
			setNearPlaneDistance(nearPlaneDistance);
			setFogShape(fogShape);
		}

		public float getFarPlaneDistance() {
			return farPlaneDistance;
		}

		public float getNearPlaneDistance() {
			return nearPlaneDistance;
		}

		public class_6854 getFogShape() {
			return fogShape;
		}

		public void setFarPlaneDistance(float distance) {
			farPlaneDistance = distance;
		}

		public void setNearPlaneDistance(float distance) {
			nearPlaneDistance = distance;
		}

		public void setFogShape(class_6854 shape) {
			fogShape = shape;
		}

		public void scaleFarPlaneDistance(float factor) {
			farPlaneDistance *= factor;
		}

		public void scaleNearPlaneDistance(float factor) {
			nearPlaneDistance *= factor;
		}
	}

	public static class ColorData {
		private final class_4184 camera;
		private float red;
		private float green;
		private float blue;

		public ColorData(class_4184 camera, float r, float g, float b) {
			this.camera = camera;
			this.red = r;
			this.green = g;
			this.blue = b;
		}

		public class_4184 getCamera() {
			return camera;
		}

		public float getRed() {
			return red;
		}

		public float getGreen() {
			return green;
		}

		public float getBlue() {
			return blue;
		}

		public void setRed(float red) {
			this.red = red;
		}

		public void setGreen(float green) {
			this.green = green;
		}

		public void setBlue(float blue) {
			this.blue = blue;
		}
	}
}
