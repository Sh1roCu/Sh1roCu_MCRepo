package io.github.fabricators_of_create.porting_lib.world;

import java.util.Iterator;
import java.util.NoSuchElementException;
import net.minecraft.class_3443;
import net.minecraft.class_5817;
import net.minecraft.class_5847;
import it.unimi.dsi.fastutil.objects.ObjectList;

public class PieceBeardifierIterator implements Iterator<class_3443> {
	private final Iterator<? extends class_3443> wrapped;
	private final ObjectList<class_5817.class_7301> rigids;

	private class_3443 next;
	private boolean nextChecked;

	public PieceBeardifierIterator(Iterator<? extends class_3443> iterator, ObjectList<class_5817.class_7301> rigids) {
		wrapped = iterator;
		this.rigids = rigids;
	}

	@Override
	public boolean hasNext() {
		ensureNextChecked();
		return next != null;
	}

	@Override
	public class_3443 next() {
		ensureNextChecked();
		if (next == null) {
			throw new NoSuchElementException();
		}
		nextChecked = false;
		return next;
	}

	@Override
	public void remove() {
		wrapped.remove();
	}

	private void ensureNextChecked() {
		if (!nextChecked) {
			next = nextPiece();
			nextChecked = true;
		}
	}

	private class_3443 nextPiece() {
		while (true) {
			if (wrapped.hasNext()) {
				class_3443 next = wrapped.next();
				if (next instanceof PieceBeardifierModifier modifier) {
					if (modifier.getTerrainAdjustment() != class_5847.field_28922) {
						rigids.add(new class_5817.class_7301(modifier.getBeardifierBox(), modifier.getTerrainAdjustment(), modifier.getGroundLevelDelta()));
					}
				} else {
					return next;
				}
			} else {
				return null;
			}
		}
	}
}
