package io.github.fabricators_of_create.porting_lib.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import io.github.fabricators_of_create.porting_lib.event.client.ModelLoadCallback;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1088;
import net.minecraft.class_2960;
import net.minecraft.class_324;
import net.minecraft.class_3695;
import net.minecraft.class_793;
import net.minecraft.class_9824;

@Mixin(class_1088.class)
public abstract class ModelBakeryMixin {
	@Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiling/ProfilerFiller;push(Ljava/lang/String;)V"))
	public void onModelLoad(class_324 colors, class_3695 profiler, Map<class_2960, class_793> modelResources, Map<class_2960, List<class_9824.class_7777>> blockStateResources, CallbackInfo ci) {
		ModelLoadCallback.EVENT.invoker().onModelsStartLoading(colors, profiler, modelResources, blockStateResources);
	}
}
