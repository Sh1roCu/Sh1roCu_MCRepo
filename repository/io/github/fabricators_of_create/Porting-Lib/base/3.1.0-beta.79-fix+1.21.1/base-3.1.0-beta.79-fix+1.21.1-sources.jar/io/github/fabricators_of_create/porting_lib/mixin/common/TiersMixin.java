package io.github.fabricators_of_create.porting_lib.mixin.common;

import io.github.fabricators_of_create.porting_lib.extensions.common.TiersExtension;
import io.github.fabricators_of_create.porting_lib.util.TagUtil;
import net.minecraft.class_1834;
import net.minecraft.class_2248;
import net.minecraft.class_6862;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1834.class)
public abstract class TiersMixin implements TiersExtension {
	@Nullable
	@Override
	public class_6862<class_2248> getTag() {
		return TagUtil.getTagFromVanillaTier((class_1834) (Object) this);
	}
}
