package io.github.fabricators_of_create.porting_lib.mixin.common;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;

import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.event.common.GrindstoneEvent;
import io.github.fabricators_of_create.porting_lib.event.common.GrindstoneEvent.OnTakeItem;
import io.github.fabricators_of_create.porting_lib.extensions.common.GrindstoneMenuExtension;
import io.github.fabricators_of_create.porting_lib.util.PortingHooks;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3803;
import net.minecraft.class_3917;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3803.class)
public abstract class GrindstoneMenuMixin extends class_1703 implements GrindstoneMenuExtension {
	@Shadow
	@Final
	private class_1263 resultSlots;

	protected GrindstoneMenuMixin(@Nullable class_3917<?> menuType, int i) {
		super(menuType, i);
	}

	@Inject(
			method = "computeResult",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/item/ItemStack;isEmpty()Z",
					ordinal = 1,
					shift = At.Shift.AFTER
			),
			cancellable = true
	)
	private void handleResult(class_1799 top, class_1799 bottom, CallbackInfoReturnable<class_1799> cir) {
		this.port_lib$xp = PortingHooks.onGrindstoneChange(top, bottom, this.resultSlots, -1);
		if (this.port_lib$xp != Integer.MIN_VALUE) cir.setReturnValue(class_1799.field_8037); // NF Porting 1.20.5 check if this is correct
	}

	private int port_lib$xp = -1;

	@Override
	public int port_lib$getXp() {
		return this.port_lib$xp;
	}

	@Mixin(targets = "net/minecraft/world/inventory/GrindstoneMenu$4")
	public abstract static class GrindstoneMenuOutputSlotMixin {
		@Shadow(aliases = "field_16780")
		@Final
		class_3803 menu;

		@Unique
		private OnTakeItem takeEvent;

		// execute lambda
		@WrapOperation(
				method = "method_17417",
				at = @At(
						value = "INVOKE",
						target = "Lnet/minecraft/world/entity/ExperienceOrb;award(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/phys/Vec3;I)V"
				)
		)
		private void onGrindStoneTake(class_3218 level, class_243 pos, int amount, Operation<Void> original) {
			class_1263 input = this.menu.field_16772;
			class_1799 top = input.method_5438(0);
			class_1799 bottom = input.method_5438(1);
			this.takeEvent = new GrindstoneEvent.OnTakeItem(top, bottom, amount);
			takeEvent.sendEvent();
			if (!takeEvent.isCanceled())
				original.call(level, pos, takeEvent.getXp());
		}

		@ModifyArg(
				method = "onTake",
				at = @At(
						value = "INVOKE",
						target = "Lnet/minecraft/world/Container;setItem(ILnet/minecraft/world/item/ItemStack;)V",
						ordinal = 0
				),
				index = 1
		)
		private class_1799 modifyTopSlotResult(class_1799 original) {
			if (takeEvent != null) {
				class_1799 topItem = takeEvent.getNewTopItem();
				if (!topItem.method_7960()) {
					return topItem;
				}
			}
			return original;
		}

		@ModifyArg(
				method = "onTake",
				at = @At(
						value = "INVOKE",
						target = "Lnet/minecraft/world/Container;setItem(ILnet/minecraft/world/item/ItemStack;)V",
						ordinal = 1
				),
				index = 1
		)
		private class_1799 modifyBottomSlotResult(class_1799 original) {
			if (takeEvent != null) {
				class_1799 bottomItem = takeEvent.getNewBottomItem();
				if (!bottomItem.method_7960()) {
					return bottomItem;
				}
			}
			return original;
		}

		@WrapWithCondition(
				method = "onTake",
				at = @At(
						value = "INVOKE",
						target = "Lnet/minecraft/world/Container;setItem(ILnet/minecraft/world/item/ItemStack;)V"
				)
		)
		private boolean cancelInputRemoval(class_1263 container, int slot, class_1799 stack) {
			return takeEvent == null || !takeEvent.isCanceled();
		}

		// forge does this, vanilla does not. Leaving just in case.
		@Inject(method = "onTake", at = @At("TAIL"))
		private void setChanged(class_1657 player, class_1799 itemStack, CallbackInfo ci) {
			this.menu.field_16772.method_5431();
		}

		@Inject(method = "getExperienceAmount", at = @At("HEAD"), cancellable = true)
		private void customXp(class_1937 level, CallbackInfoReturnable<Integer> cir) {
			int exp = ((GrindstoneMenuExtension) this.menu).port_lib$getXp();
			if (exp > -1)
				cir.setReturnValue(exp);
		}
	}
}
