package io.github.fabricators_of_create.porting_lib.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomFrictionBlock;
import net.minecraft.class_1299;
import net.minecraft.class_1307;
import net.minecraft.class_1308;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

@Mixin(class_1307.class)
public abstract class FlyingMobMixin extends class_1308 {
	protected FlyingMobMixin(class_1299<? extends class_1308> entityType, class_1937 level) {
		super(entityType, level);
	}

	@ModifyVariable(
			method = "travel",																					// first call		// first float variable
			at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/world/level/block/Block;getFriction()F", ordinal = 0), ordinal = 0
	)
	private float port_lib$setFriction(float original) {
		return port_lib$handleFriction(original);
	}

	@ModifyVariable(
			method = "travel",																					// second call		// first float variable
			at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/world/level/block/Block;getFriction()F", ordinal = 1), ordinal = 0
	)
	private float port_lib$setFriction2(float original) {
		return port_lib$handleFriction(original);
	}

	private float port_lib$handleFriction(float original) {
		class_2338 pos = class_2338.method_49637(method_23317(), method_23318() - 1, method_23321());
		class_2680 state = method_37908().method_8320(pos);
		if (state.method_26204() instanceof CustomFrictionBlock custom) {
			return custom.getFriction(state, method_37908(), pos, this);
		}
		return original;
	}
}
