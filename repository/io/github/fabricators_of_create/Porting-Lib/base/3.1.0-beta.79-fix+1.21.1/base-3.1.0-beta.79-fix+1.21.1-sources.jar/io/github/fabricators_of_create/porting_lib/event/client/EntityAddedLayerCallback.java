package io.github.fabricators_of_create.porting_lib.event.client;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_897;
import java.util.Map;

/**
 * @deprecated Use {@link io.github.fabricators_of_create.porting_lib.client_events.event.client.EntityRenderersEvent.AddLayers} in the {@code client_events} module.
 */
@Deprecated(forRemoval = true)
@FunctionalInterface
public interface EntityAddedLayerCallback {

	Event<EntityAddedLayerCallback> EVENT = EventFactory.createArrayBacked(EntityAddedLayerCallback.class, callbacks -> (renderers, skinMap) -> {
		for (EntityAddedLayerCallback event : callbacks) {
			event.addLayers(renderers, skinMap);
		}
	});

	void addLayers(final Map<class_1299<?>, class_897<?>> renderers, final Map<String, class_897<? extends class_1657>> skinMap);

}
