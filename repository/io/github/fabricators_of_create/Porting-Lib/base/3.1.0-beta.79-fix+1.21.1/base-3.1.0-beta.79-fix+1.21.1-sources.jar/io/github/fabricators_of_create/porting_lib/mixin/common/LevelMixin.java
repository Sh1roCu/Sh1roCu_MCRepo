package io.github.fabricators_of_create.porting_lib.mixin.common;

import java.util.LinkedList;
import java.util.List;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.event.common.ExplosionEvents;
import io.github.fabricators_of_create.porting_lib.extensions.common.LevelExtensions;
import net.fabricmc.fabric.api.transfer.v1.transaction.base.SnapshotParticipant;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1927;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3194;
import net.minecraft.class_3414;
import net.minecraft.class_5362;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_1937.class, priority = 1100) // need to apply after lithium
public abstract class LevelMixin implements class_1936, LevelExtensions {
	// only non-null during transactions. Is set back to null in
	// onFinalCommit on commits, and through snapshot rollbacks on aborts.
	private List<ChangedPosData> port_lib$modifiedStates = null;

	private final SnapshotParticipant<LevelSnapshotData> port_lib$snapshotParticipant = new SnapshotParticipant<>() {

		@Override
		protected LevelSnapshotData createSnapshot() {
			LevelSnapshotData data = new LevelSnapshotData(port_lib$modifiedStates);
			if (port_lib$modifiedStates == null) port_lib$modifiedStates = new LinkedList<>();
			return data;
		}

		@Override
		protected void readSnapshot(LevelSnapshotData snapshot) {
			port_lib$modifiedStates = snapshot.changedStates();
		}

		@Override
		protected void onFinalCommit() {
			super.onFinalCommit();
			List<ChangedPosData> modifications = port_lib$modifiedStates;
			port_lib$modifiedStates = null;
			for (ChangedPosData data : modifications) {
				method_8652(data.pos(), data.state(), data.flags());
			}
		}
	};

	@Shadow
	public abstract class_2680 method_8320(class_2338 blockPos);

	@Shadow
	public abstract void setBlocksDirty(class_2338 pos, class_2680 old, class_2680 updated);

	@Shadow
	@Final
	public boolean isClientSide;

	@Shadow
	public abstract void sendBlockUpdated(class_2338 pos, class_2680 oldState, class_2680 newState, int flags);

	@Shadow
	public abstract void updateNeighbourForOutputSignal(class_2338 pos, class_2248 block);

	@Shadow
	public abstract void onBlockStateChange(class_2338 pos, class_2680 oldBlock, class_2680 newBlock);

	@Override
	public SnapshotParticipant<LevelSnapshotData> snapshotParticipant() {
		return port_lib$snapshotParticipant;
	}

	@Inject(method = "getBlockState", at = @At(value = "INVOKE", shift = Shift.BEFORE,
			target = "Lnet/minecraft/world/level/Level;getChunk(II)Lnet/minecraft/world/level/chunk/LevelChunk;"), cancellable = true)
	private void getBlockState(class_2338 pos, CallbackInfoReturnable<class_2680> cir) {
		if (port_lib$modifiedStates != null) {
			// iterate in reverse order - latest changes priority
			for (ChangedPosData data : port_lib$modifiedStates) {
				if (data.pos().equals(pos)) {
					class_2680 state = data.state();
					if (state == null) {
						PortingLib.LOGGER.error("null blockstate stored in snapshots at " + pos);
						new Throwable().printStackTrace();
					} else {
						cir.setReturnValue(state);
					}
					return;
				}
			}
		}
	}

	@Inject(method = "setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;II)Z",
			at = @At(value = "INVOKE", shift = Shift.BEFORE, target = "Lnet/minecraft/world/level/Level;getChunkAt(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/chunk/LevelChunk;"), cancellable = true)
	private void setBlock(class_2338 pos, class_2680 state, int flags, int recursionLeft, CallbackInfoReturnable<Boolean> cir) {
		if (state == null) {
			PortingLib.LOGGER.error("Setting null blockstate at " + pos);
			new Throwable().printStackTrace();
		}
		if (port_lib$modifiedStates != null) {
			port_lib$modifiedStates.add(new ChangedPosData(pos, state, flags));
			cir.setReturnValue(true);
		}
	}

	@Inject(
			method = "explode(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;Lnet/minecraft/world/level/ExplosionDamageCalculator;DDDFZLnet/minecraft/world/level/Level$ExplosionInteraction;ZLnet/minecraft/core/particles/ParticleOptions;Lnet/minecraft/core/particles/ParticleOptions;Lnet/minecraft/core/Holder;)Lnet/minecraft/world/level/Explosion;",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/Explosion;explode()V"
			),
			cancellable = true
	)
	public void onStartExplosion(class_1297 source, class_1282 damageSource, class_5362 damageCalculator, double x, double y, double z, float radius, boolean fire, class_1937.class_7867 explosionInteraction, boolean spawnParticles, class_2394 smallExplosionParticles, class_2394 largeExplosionParticles, class_6880<class_3414> explosionSound, CallbackInfoReturnable<class_1927> cir, @Local(ordinal = 0) class_1927 explosion) {
		if (ExplosionEvents.START.invoker().onExplosionStart((class_1937) (Object) this, explosion)) {
			cir.setReturnValue(explosion);
		}
	}

	@Override
	public void port_lib$markAndNotifyBlock(class_2338 pos, @Nullable class_2818 levelchunk, class_2680 oldState, class_2680 newState, int flags, int recursionLeft) {
		class_2248 block = newState.method_26204();
		class_2680 blockstate1 = method_8320(pos);
		{
			{
				if (blockstate1 == newState) {
					if (oldState != blockstate1) {
						this.setBlocksDirty(pos, oldState, blockstate1);
					}

					if ((flags & 2) != 0 && (!this.isClientSide || (flags & 4) == 0) && (this.isClientSide || levelchunk.method_12225() != null && levelchunk.method_12225().method_14014(class_3194.field_44856))) {
						this.sendBlockUpdated(pos, oldState, newState, flags);
					}

					if ((flags & 1) != 0) {
						this.method_8408(pos, oldState.method_26204());
						if (!this.isClientSide && newState.method_26221()) {
							this.updateNeighbourForOutputSignal(pos, block);
						}
					}

					if ((flags & 16) == 0 && recursionLeft > 0) {
						int i = flags & -34;
						oldState.method_26198(this, pos, i, recursionLeft - 1);
						newState.method_26183(this, pos, i, recursionLeft - 1);
						newState.method_26198(this, pos, i, recursionLeft - 1);
					}

					this.onBlockStateChange(pos, oldState, blockstate1);
				}
			}
		}
	}
}
