package io.github.fabricators_of_create.porting_lib.mixin.common;

import io.github.fabricators_of_create.porting_lib.core.util.INBTSerializable;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1297.class)
public abstract class EntityMixin implements INBTSerializable<class_2487> {
	@Shadow
	private class_1937 level;
	@Shadow
	public abstract class_1299<?> getType();
	@Shadow
	@Nullable
	protected abstract String getEncodeId();
	@Shadow
	public abstract class_2487 saveWithoutId(class_2487 compoundTag);

	@Shadow
	public abstract void load(class_2487 nbt);

	@Override
	public void deserializeNBT(class_7225.class_7874 provider, class_2487 nbt) {
		load(nbt);
	}

	@Override
	public class_2487 serializeNBT(class_7225.class_7874 provider) {
		class_2487 ret = new class_2487();
		String id = getEncodeId();
		if (id != null) {
			ret.method_10582("id", getEncodeId());
		}
		return saveWithoutId(ret);
	}
}
