package io.github.fabricators_of_create.porting_lib.enchant;

import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_9304;

public interface CustomEnchantingBehaviorItem {
	/**
	 * Allow or forbid the specific book/item combination as an anvil enchant
	 *
	 * @param stack The item
	 * @param book  The book
	 * @return if the enchantment is allowed
	 */
	default boolean isBookEnchantable(class_1799 stack, class_1799 book) {
		return true;
	}

	/**
	 * Gets the level of the enchantment currently present on the stack. By default, returns the enchantment level present in NBT.
	 * Most enchantment implementations rely upon this method.
	 * The returned value must be the same as getting the enchantment from {@link #getAllEnchantments}
	 *
	 * @param stack       The item stack being checked
	 * @param enchantment The enchantment being checked for
	 * @return Level of the enchantment, or 0 if not present
	 * @see #getAllEnchantments
	 */
	default int getEnchantmentLevel(class_1799 stack, class_6880<class_1887> enchantment) {
		class_9304 itemenchantments = stack.method_58657();
		return itemenchantments.method_57536(enchantment);
	}

	/**
	 * Gets a map of all enchantments present on the stack. By default, returns the enchantments present in NBT.
	 * Used in several places in code including armor enchantment hooks.
	 * The returned value(s) must have the same level as {@link #getEnchantmentLevel}.
	 *
	 * @param stack  The item stack being checked
	 * @param lookup A registry lookup, used to resolve enchantment {@link class_6880}s.
	 * @return Map of all enchantments on the stack, empty if no enchantments are present
	 * @see #getEnchantmentLevel
	 */
	default class_9304 getAllEnchantments(class_1799 stack, class_7225.class_7226<class_1887> lookup) {
		return stack.method_58657();
	}
}
