package io.github.fabricators_of_create.porting_lib.world;

import net.minecraft.class_3341;
import net.minecraft.class_5847;

/** Implement this interface in a {@link net.minecraft.class_3443} class extension to modify its {@link net.minecraft.class_5817} behavior. */
public interface PieceBeardifierModifier {
	class_3341 getBeardifierBox();

	class_5847 getTerrainAdjustment();

	int getGroundLevelDelta();
}
