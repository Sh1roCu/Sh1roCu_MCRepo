package io.github.fabricators_of_create.porting_lib.mixin.client;

import io.github.fabricators_of_create.porting_lib.extensions.client.PoseStackExtension;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_4587.class)
public class PoseStackMixin implements PoseStackExtension {
}
