package io.github.fabricators_of_create.porting_lib.mixin.client;

import io.github.fabricators_of_create.porting_lib.event.client.RenderPlayerEvents;
import net.minecraft.class_1007;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public class PlayerRendererMixin {
	@Inject(method = "render(Lnet/minecraft/client/player/AbstractClientPlayer;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"), cancellable = true)
	private void port_lib$onRenderPlayerPre(class_742 player, float f, float partialTick, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
		if (RenderPlayerEvents.PRE.invoker().onPreRenderPlayer(player, (class_1007) (Object) this, partialTick, poseStack, buffer, packedLight))
			ci.cancel();
	}

	@Inject(method = "render(Lnet/minecraft/client/player/AbstractClientPlayer;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At("RETURN"))
	private void port_lib$onRenderPlayerPost(class_742 player, float f, float partialTick, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
		RenderPlayerEvents.POST.invoker().onPostRenderPlayer(player, (class_1007) (Object) this, partialTick, poseStack, buffer, packedLight);
	}
}
