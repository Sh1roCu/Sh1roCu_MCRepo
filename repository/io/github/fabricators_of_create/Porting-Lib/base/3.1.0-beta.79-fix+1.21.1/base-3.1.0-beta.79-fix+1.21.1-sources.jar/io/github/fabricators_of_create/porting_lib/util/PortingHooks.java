package io.github.fabricators_of_create.porting_lib.util;

import io.github.fabricators_of_create.porting_lib.core.util.ServerLifecycleHooks;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1263;
import net.minecraft.class_1303;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_3914;
import net.minecraft.class_5321;
import net.minecraft.class_6088;
import net.minecraft.class_638;
import net.minecraft.class_7225;
import net.minecraft.server.MinecraftServer;
import io.github.fabricators_of_create.porting_lib.event.common.GrindstoneEvent;
import org.jetbrains.annotations.Nullable;

import java.util.function.Function;

@SuppressWarnings({"removal", "UnstableApiUsage"})
public class PortingHooks {
	/**
	 * @return -1 to cancel, MIN_VALUE to follow vanilla logic, any other number to modify granted exp
	 */
	public static int onGrindstoneChange(class_1799 top, class_1799 bottom, class_1263 outputSlot, int xp) {
		GrindstoneEvent.OnPlaceItem e = new GrindstoneEvent.OnPlaceItem(top, bottom, xp);
		e.sendEvent();
		if (e.isCanceled()) {
			outputSlot.method_5447(0, class_1799.field_8037);
			return -1;
		}
		if (e.getOutput().method_7960())
			return Integer.MIN_VALUE;

		outputSlot.method_5447(0, e.getOutput());
		return e.getXp();
	}

	public static boolean onGrindstoneTake(class_1263 inputSlots, class_3914 access, Function<class_1937, Integer> xpFunction) {
		access.method_17393((l, p) -> {
			int xp = xpFunction.apply(l);
			GrindstoneEvent.OnTakeItem e = new GrindstoneEvent.OnTakeItem(inputSlots.method_5438(0), inputSlots.method_5438(1), xp);
			e.sendEvent();
			if (e.isCanceled()) {
				return;
			}
			if (l instanceof class_3218) {
				class_1303.method_31493((class_3218) l, class_243.method_24953(p), e.getXp());
			}
			l.method_20290(class_6088.field_31130, p, 0);
			inputSlots.method_5447(0, e.getNewTopItem());
			inputSlots.method_5447(1, e.getNewBottomItem());
			inputSlots.method_5431();
		});
		return true;
	}

	/**
	 * Attempts to resolve a {@link class_7225.class_7226} using the current global state.
	 * <p>
	 * Prioritizes the server's lookup, only attempting to retrieve it from the client if the server is unavailable.
	 *
	 * @param <T> The type of registry being looked up
	 * @param key The resource key for the target registry
	 * @return A registry access, if one was available.
	 */
	@Nullable
	public static <T> class_7225.class_7226<T> resolveLookup(class_5321<? extends class_2378<T>> key) {
		MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
		if (server != null) {
			return server.method_30611().method_46759(key).orElse(null);
		} else if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
			return resolveLookupClient(key);
		}

		return null;
	}

	@Nullable
	public static <T> class_7225.class_7226<T> resolveLookupClient(class_5321<? extends class_2378<T>> key) {
		class_638 level = class_310.method_1551().field_1687;
		if (level != null) {
			return level.method_30349().method_46759(key).orElse(null);
		}

		return null;
	}
}
