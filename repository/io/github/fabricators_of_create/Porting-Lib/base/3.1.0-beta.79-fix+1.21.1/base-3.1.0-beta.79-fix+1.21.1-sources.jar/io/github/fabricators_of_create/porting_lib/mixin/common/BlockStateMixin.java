package io.github.fabricators_of_create.porting_lib.mixin.common;

import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2680.class)
public class BlockStateMixin {
}
