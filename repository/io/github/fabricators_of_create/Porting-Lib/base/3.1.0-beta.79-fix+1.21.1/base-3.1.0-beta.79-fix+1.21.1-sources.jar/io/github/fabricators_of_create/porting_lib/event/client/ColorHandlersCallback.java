package io.github.fabricators_of_create.porting_lib.event.client;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_324;
import net.minecraft.class_325;

public interface ColorHandlersCallback {

  Event<Item> ITEM = EventFactory.createArrayBacked(Item.class, callbacks -> ((itemColors, blockColors) -> {
    for(Item event : callbacks)
      event.registerItemColors(itemColors, blockColors);
  }));

  Event<Block> BLOCK = EventFactory.createArrayBacked(Block.class, callbacks -> blockColors -> {
    for(Block event : callbacks)
      event.registerBlockColors(blockColors);
  });

  interface Item {
    void registerItemColors(class_325 itemColors, class_324 blockColors);
  }
  interface Block {
    void registerBlockColors(class_324 blockColors);
  }
}
