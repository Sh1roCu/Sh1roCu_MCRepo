package io.github.fabricators_of_create.porting_lib.mixin.common;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_3341;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_3499.class_3502;
import net.minecraft.class_5425;
import net.minecraft.class_5819;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.util.StructureTemplateUtils;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3499.class)
public abstract class StructureTemplateMixin {
	@Unique private static final ThreadLocal<class_3492> currentSettings = new ThreadLocal<>();

	@Inject(
			method = "placeInWorld",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructureTemplate;placeEntities(Lnet/minecraft/world/level/ServerLevelAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Mirror;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Z)V"
			)
	)
	private void grabSettings(class_5425 level, class_2338 pos, class_2338 pivot, class_3492 settings,
							  class_5819 random, int i, CallbackInfoReturnable<Boolean> cir) {
		currentSettings.set(settings);
	}

	@ModifyExpressionValue(
			method = "placeEntities",
			at = @At(
					value = "FIELD",
					target = "Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructureTemplate;entityInfoList:Ljava/util/List;"
			)
	)
	private List<class_3502> processEntityInfos(List<class_3502> original,
														 class_5425 level, class_2338 pos, class_2415 mirror, class_2470 rotation,
														 class_2338 pivot, @Nullable class_3341 bounds, boolean finalizeMobs) {
		class_3492 settings = currentSettings.get();

		if (PortingLib.DEBUG)
			Objects.requireNonNull(settings);

		if (settings == null)
			return original;

		return StructureTemplateUtils.processEntityInfos(
				(class_3499) (Object) this, level, pos, settings, original
		);
	}

	@ModifyExpressionValue(
			method = "placeEntities",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/core/BlockPos;offset(Lnet/minecraft/core/Vec3i;)Lnet/minecraft/core/BlockPos;"
			)
	)
	private class_2338 dontProcessBlockPosTwice(class_2338 original, @Local class_3502 info) {
		class_3492 settings = currentSettings.get();
		if (settings != null) { // pos was already processed.
			return info.field_15600;
		}
		return original;
	}

	@ModifyExpressionValue(
			method = "placeEntities",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/phys/Vec3;add(DDD)Lnet/minecraft/world/phys/Vec3;"
			)
	)
	private class_243 dontProcessVecTwice(class_243 original, @Local class_3502 info) {
		class_3492 settings = currentSettings.get();
		if (settings != null) { // pos was already processed.
			return info.field_15599;
		}
		return original;
	}

	@Inject(method = "placeEntities", at = @At("RETURN"))
	private void clearGrabbedSettings(CallbackInfo ci) {
		currentSettings.remove(); // clear the settings when done to avoid leaking it
	}
}
