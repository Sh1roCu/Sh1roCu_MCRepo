package io.github.fabricators_of_create.porting_lib.mixin.common;

import io.github.fabricators_of_create.porting_lib.extensions.common.ResourceLocationExtension;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_2960.class)
public abstract class ResourceLocationMixin implements ResourceLocationExtension {
	@Shadow
	@Final
	private String namespace;

	@Shadow
	@Final
	private String path;

	@Override
	public int port_lib$compareNamespaced(class_2960 o) {
		int ret = this.namespace.compareTo(o.method_12836());
		return ret != 0 ? ret : this.path.compareTo(o.method_12832());
	}
}
