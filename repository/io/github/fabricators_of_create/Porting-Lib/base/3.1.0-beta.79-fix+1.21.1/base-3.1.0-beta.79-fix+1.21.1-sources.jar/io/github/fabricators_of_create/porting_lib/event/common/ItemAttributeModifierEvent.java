package io.github.fabricators_of_create.porting_lib.event.common;

import com.google.common.collect.ImmutableList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import io.github.fabricators_of_create.porting_lib.core.event.BaseEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * This event is fired when the attributes for an item stack are queried (for any reason) through {@link class_1799#getAttributeModifiers()}.
 * <br>
 * This event is fired regardless of if the stack has {@link class_9334#field_49636} or not. If your attribute should be
 * ignored when attributes are overridden, you can check for the presence of the component.
 * <p>
 * This event may be fired on both the logical server and logical client.
 */
public class ItemAttributeModifierEvent extends BaseEvent {
	public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
		for (Callback callback : callbacks) {
			callback.onItemAttributes(event);
		}
	});

	private final class_1799 stack;
	private final class_9285 defaultModifiers;
	private ItemAttributeModifiersBuilder builder;

	@ApiStatus.Internal
	public ItemAttributeModifierEvent(class_1799 stack, class_9285 defaultModifiers) {
		this.stack = stack;
		this.defaultModifiers = defaultModifiers;
	}

	/**
	 * {@return the item stack whose attribute modifiers are being computed}
	 */
	public class_1799 getItemStack() {
		return this.stack;
	}

	/**
	 * {@return the default attribute modifiers before changes made by the event}
	 */
	public class_9285 getDefaultModifiers() {
		return this.defaultModifiers;
	}

	/**
	 * Returns an unmodifiable view of the attribute modifier entries. Do not use the returned value to create an {@link class_9285}
	 * since the underlying list is not immutable.
	 * <p>
	 * If you need an {@link class_9285}, you may need to call {@link #build()}
	 *
	 * @apiNote Use other methods from this event to adjust the modifiers.
	 */
	public List<class_9285.class_9287> getModifiers() {
		return this.builder == null ? this.defaultModifiers.comp_2393() : this.builder.getEntryView();
	}

	/**
	 * Adds a new attribute modifier to the given stack. Two modifiers with the same id may not exist for the same attribute, and this method will fail if one exists.
	 *
	 * @param attribute The attribute the modifier is for
	 * @param modifier  The new attribute modifier
	 * @param slot      The equipment slots for which the modifier should apply
	 * @return True if the modifier was added, false if it was already present
	 * @apiNote Modifiers must have a unique and consistent {@link class_2960} id, or the modifier will not be removed when the item is unequipped.
	 */
	public boolean addModifier(class_6880<class_1320> attribute, class_1322 modifier, class_9274 slot) {
		return getBuilder().addModifier(attribute, modifier, slot);
	}

	/**
	 * Removes an attribute modifier for the target attribute by id
	 *
	 * @return True if an attribute modifier was removed, false otherwise
	 */
	public boolean removeModifier(class_6880<class_1320> attribute, class_2960 id) {
		return getBuilder().removeModifier(attribute, id);
	}

	/**
	 * Adds a new attribute modifier to the given stack, optionally replacing any existing modifiers with the same id.
	 *
	 * @param attribute The attribute the modifier is for
	 * @param modifier  The new attribute modifier
	 * @param slot      The equipment slots for which the modifier should apply
	 * @apiNote Modifiers must have a unique and consistent {@link class_2960} id, or the modifier will not be removed when the item is unequipped.
	 */
	public void replaceModifier(class_6880<class_1320> attribute, class_1322 modifier, class_9274 slot) {
		getBuilder().replaceModifier(attribute, modifier, slot);
	}

	/**
	 * Removes modifiers based on a condition.
	 *
	 * @return true if any modifiers were removed
	 */
	public boolean removeIf(Predicate<class_9285.class_9287> condition) {
		return getBuilder().removeIf(condition);
	}

	/**
	 * Removes all modifiers for the given attribute.
	 *
	 * @return true if any modifiers were removed
	 */
	public boolean removeAllModifiersFor(class_6880<class_1320> attribute) {
		return getBuilder().removeIf(entry -> entry.comp_2395().equals(attribute));
	}

	/**
	 * Removes all modifiers for all attributes.
	 */
	public void clearModifiers() {
		getBuilder().clear();
	}

	/**
	 * Builds a new {@link class_9285} with the results of this event, returning the
	 * {@linkplain #getDefaultModifiers() default modifiers} if no changes were made.
	 */
	public class_9285 build() {
		return this.builder == null ? this.defaultModifiers : this.builder.build(this.defaultModifiers.comp_2394());
	}

	/**
	 * Returns the builder used for adjusting the attribute modifiers, creating it if it does not already exist.
	 */
	private ItemAttributeModifiersBuilder getBuilder() {
		if (this.builder == null) {
			this.builder = new ItemAttributeModifiersBuilder(this.defaultModifiers);
		}

		return this.builder;
	}

	@Override
	public void sendEvent() {
		EVENT.invoker().onItemAttributes(this);
	}

	/**
	 * Advanced version of {@link class_9285.class_9286} which supports removal and better sanity-checking.
	 * <p>
	 * The original builder only supports additions and does not guarantee that no duplicate modifiers exist for a given id.
	 */
	private static class ItemAttributeModifiersBuilder {
		private List<class_9285.class_9287> entries;
		private Map<Key, class_9285.class_9287> entriesByKey;

		ItemAttributeModifiersBuilder(class_9285 defaultModifiers) {
			this.entries = new LinkedList<>();
			this.entriesByKey = new HashMap<>(defaultModifiers.comp_2393().size());

			for (class_9285.class_9287 entry : defaultModifiers.comp_2393()) {
				entries.add(entry);
				entriesByKey.put(new Key(entry.comp_2395(), entry.comp_2396().comp_2447()), entry);
			}
		}

		/**
		 * {@return an unmodifiable view of the underlying entry list}
		 */
		List<class_9285.class_9287> getEntryView() {
			return Collections.unmodifiableList(this.entries);
		}

		/**
		 * Attempts to add a new modifier, refusing if one is already present with the same id.
		 *
		 * @return true if the modifier was added
		 */
		boolean addModifier(class_6880<class_1320> attribute, class_1322 modifier, class_9274 slot) {
			Key key = new Key(attribute, modifier.comp_2447());
			if (entriesByKey.containsKey(key)) {
				return false;
			}

			class_9285.class_9287 entry = new class_9285.class_9287(attribute, modifier, slot);
			entries.add(entry);
			entriesByKey.put(key, entry);
			return true;
		}

		/**
		 * Removes a modifier for the target attribute with the given id.
		 *
		 * @return true if a modifier was removed
		 */
		boolean removeModifier(class_6880<class_1320> attribute, class_2960 id) {
			class_9285.class_9287 entry = entriesByKey.remove(new Key(attribute, id));

			if (entry != null) {
				entries.remove(entry);
				return true;
			}

			return false;
		}

		/**
		 * Adds a modifier to the list, replacing any existing modifiers with the same id.
		 *
		 * @return the previous modifier, or null if there was no previous modifier with the same id
		 */
		@Nullable
		class_9285.class_9287 replaceModifier(class_6880<class_1320> attribute, class_1322 modifier, class_9274 slot) {
			Key key = new Key(attribute, modifier.comp_2447());
			class_9285.class_9287 entry = new class_9285.class_9287(attribute, modifier, slot);
			if (entriesByKey.containsKey(key)) {
				class_9285.class_9287 previousEntry = entriesByKey.get(key);
				int index = entries.indexOf(previousEntry);
				if (index != -1) {
					entries.set(index, entry);
				} else { // This should never happen, but it can't hurt to have anyways
					entries.add(entry);
				}
				entriesByKey.put(key, entry);
				return previousEntry;
			} else {
				entries.add(entry);
				entriesByKey.put(key, entry);
				return null;
			}
		}

		/**
		 * Removes modifiers based on a condition.
		 *
		 * @return true if any modifiers were removed
		 */
		boolean removeIf(Predicate<class_9285.class_9287> condition) {
			this.entries.removeIf(condition);
			return this.entriesByKey.values().removeIf(condition);
		}

		void clear() {
			this.entries.clear();
			this.entriesByKey.clear();
		}

		public class_9285 build(boolean showInTooltip) {
			return new class_9285(ImmutableList.copyOf(this.entries), showInTooltip);
		}

		/**
		 * Internal key class. Attribute modifiers are unique by id for each Attribute.
		 */
		private static record Key(class_6880<class_1320> attr, class_2960 id) {

		}
	}

	public interface Callback {
		void onItemAttributes(ItemAttributeModifierEvent event);
	}
}
