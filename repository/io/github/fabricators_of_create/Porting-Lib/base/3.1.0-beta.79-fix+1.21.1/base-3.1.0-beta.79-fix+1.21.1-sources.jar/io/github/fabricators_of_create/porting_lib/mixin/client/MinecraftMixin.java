package io.github.fabricators_of_create.porting_lib.mixin.client;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.blocks.extensions.CustomHitEffectsBlock;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.event.client.InteractEvents;
import io.github.fabricators_of_create.porting_lib.event.client.MinecraftTailCallback;
import io.github.fabricators_of_create.porting_lib.event.client.ParticleManagerRegistrationCallback;
import io.github.fabricators_of_create.porting_lib.event.client.RenderFrameEvent;
import io.github.fabricators_of_create.porting_lib.event.common.ModsLoadedCallback;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3283;
import net.minecraft.class_542;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_702;
import net.minecraft.class_746;
import net.minecraft.class_9779;

@Environment(EnvType.CLIENT)
@Mixin(class_310.class)
public abstract class MinecraftMixin {
	@Shadow
	public class_746 player;

	@Shadow
	public @Nullable class_638 level;

	@Shadow
	@Nullable
	public class_239 hitResult;

	@Shadow
	@Final
	private class_3283 resourcePackRepository;

	@Shadow
	@Final
	private class_9779.class_9781 timer;

	@Inject(
			method = "<init>",
			at = @At(
					value = "FIELD",
					target = "Lnet/minecraft/client/Minecraft;particleEngine:Lnet/minecraft/client/particle/ParticleEngine;",
					shift = Shift.AFTER,
					ordinal = 0
			)
	)
	public void port_lib$registerParticleManagers(class_542 gameConfiguration, CallbackInfo ci) {
		ParticleManagerRegistrationCallback.EVENT.invoker().onParticleManagerRegistration();
	}

	@Inject(method = "<init>", at = @At("TAIL"))
	public void port_lib$mcTail(class_542 gameConfiguration, CallbackInfo ci) {
		MinecraftTailCallback.EVENT.invoker().onMinecraftTail((class_310) (Object) this);
	}

	// Inject right after the fabric entrypoint
	@Inject(method = "<init>", at = @At(value = "INVOKE", target = "Ljava/lang/Thread;currentThread()Ljava/lang/Thread;"))
	public void port_lib$modsLoaded(class_542 gameConfig, CallbackInfo ci) {
		ModsLoadedCallback.EVENT.invoker().onAllModsLoaded(EnvType.CLIENT);
	}

	@Inject(
			method = "startAttack",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/phys/HitResult;getType()Lnet/minecraft/world/phys/HitResult$Type;"
			),
			cancellable = true
	)
	private void port_lib$onAttack(CallbackInfoReturnable<Boolean> cir, @Local class_1799 stack, @Local boolean bl) {
		class_1269 result = InteractEvents.ATTACK.invoker().onAttack((class_310) (Object) this, hitResult);
		if (result != class_1269.field_5811) {
			if (result == class_1269.field_5812) {
				player.method_6104(class_1268.field_5808);
			}
			cir.setReturnValue(bl); // bl is returned anyway, but return early to skip the switch
		}
	}

	@WrapOperation(
			method = "continueAttack",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/multiplayer/MultiPlayerGameMode;continueDestroyBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)Z"
			)
	)
	private boolean port_lib$onContinueAttack(class_636 gameMode, class_2338 posBlock, class_2350 directionFacing, Operation<Boolean> original) {
		class_1269 result = InteractEvents.ATTACK.invoker().onAttack((class_310) (Object) this, hitResult);
		if (result != class_1269.field_5811) {
			// true -> skip continueDestroyBlock, do swing and crack
			// false -> skip continueDestroyBlock, do NOT swing or crack
			return result == class_1269.field_5812;
		}
		return original.call(gameMode, posBlock, directionFacing); // continue to continueDestroyBlock
	}

	@Inject(method = "runTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GameRenderer;render(Lnet/minecraft/client/DeltaTracker;Z)V"))
	private void renderTickStart(CallbackInfo ci) {
		RenderFrameEvent.PRE.invoker().onRenderFrame(this.timer);
	}

	@Inject(method = "runTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GameRenderer;render(Lnet/minecraft/client/DeltaTracker;Z)V", shift = Shift.AFTER))
	private void renderTickEnd(CallbackInfo ci) {
		RenderFrameEvent.POST.invoker().onRenderFrame(this.timer);
	}

	@Inject(
			method = "startUseItem",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/player/LocalPlayer;getItemInHand(Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/item/ItemStack;"
			),
			cancellable = true
	)
	private void port_lib$onStartUseItem(CallbackInfo ci, @Local class_1268 hand) {
		class_1269 result = InteractEvents.USE.invoker().onUse((class_310) (Object) this, hitResult, hand);
		if (result != class_1269.field_5811) {
			if (result == class_1269.field_5812) {
				player.method_6104(hand);
			}
			ci.cancel();
		}
	}

	@Inject(method = "pickBlock", cancellable = true, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;getAbilities()Lnet/minecraft/world/entity/player/Abilities;"))
	private void port_lib$onPickBlock(CallbackInfo ci) {
		if (InteractEvents.PICK.invoker().onPick((class_310) (Object) this, hitResult)) {
			ci.cancel();
		}
	}

	@WrapWithCondition(
			method = "continueAttack",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/particle/ParticleEngine;crack(Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)V"
			)
	)
	private boolean customHitEffects(class_702 engine, class_2338 pos, class_2350 side) {
		class_2680 state = level.method_8320(pos);
		if (state.method_26204() instanceof CustomHitEffectsBlock custom)
			return !custom.addHitEffects(state, level, hitResult, engine);
		return true;
	}
}
