package io.github.fabricators_of_create.porting_lib.mixin.common;

import io.github.fabricators_of_create.porting_lib.extensions.common.TagAppenderExtension;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider.FabricTagBuilder;
import net.minecraft.class_2474;
import net.minecraft.class_2474.class_5124;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_2474.class_5124.class)
public abstract class TagAppenderMixin<T> implements TagAppenderExtension {
	@Shadow
	public abstract class_5124<T> addTag(class_6862<T> tag);

	// generics are a mess
	@SuppressWarnings({"unchecked", "ConstantConditions", "rawtypes"})
	@Override
	public <E> class_5124<E> addTags(class_6862<E>... values) {
		if ((Object) this instanceof FabricTagBuilder fabricTagBuilder) {
			for (class_6862<E> value : values) {
				fabricTagBuilder.forceAddTag(value);
			}
		} else {
			for (class_6862<E> value : values) {
				addTag((class_6862) value);
			}
		}
		return (class_5124<E>) (Object) this;
	}
}
