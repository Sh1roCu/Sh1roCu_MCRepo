package io.github.fabricators_of_create.porting_lib.client.armor;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;

@Environment(EnvType.CLIENT)
public interface ArmorRenderer {

	/**
	 * Renders an armor part.
	 *
	 * @param matrices			the matrix stack
	 * @param vertexConsumers	the vertex consumer provider
	 * @param stack				the item stack of the armor item
	 * @param entity			the entity wearing the armor item
	 * @param slot				the equipment slot in which the armor stack is worn
	 * @param light				packed lightmap coordinates
	 * @param contextModel		the model provided by {@link class_3887#method_17165()}
	 * @param armorModel		the original armor model
	 */
	void render(class_4587 matrices, class_4597 vertexConsumers, class_1799 stack, class_1309 entity, class_1304 slot, int light, class_572<class_1309> contextModel, class_572<class_1309> armorModel);
}
