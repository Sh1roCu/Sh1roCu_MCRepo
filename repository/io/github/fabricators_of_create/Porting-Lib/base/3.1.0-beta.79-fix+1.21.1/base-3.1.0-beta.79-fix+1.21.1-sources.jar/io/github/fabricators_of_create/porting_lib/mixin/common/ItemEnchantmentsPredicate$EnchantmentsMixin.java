package io.github.fabricators_of_create.porting_lib.mixin.common;

import io.github.fabricators_of_create.porting_lib.enchant.CustomEnchantingBehaviorItem;
import io.github.fabricators_of_create.porting_lib.util.PortingHooks;
import org.spongepowered.asm.mixin.Intrinsic;
import org.spongepowered.asm.mixin.Mixin;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2035;
import net.minecraft.class_7225.class_7226;
import net.minecraft.class_7924;
import net.minecraft.class_9356;

@Mixin(class_9356.class_9357.class)
public abstract class ItemEnchantmentsPredicate$EnchantmentsMixin extends class_9356 {
	protected EnchantmentsMixin(List<class_2035> enchantments) {
		super(enchantments);
	}

	@Intrinsic(displace = true)
	public boolean port_lib$matches(class_1799 stack) {
		if (stack.method_7909() instanceof CustomEnchantingBehaviorItem enchantingBehaviorItem) {
			var lookup = PortingHooks.resolveLookup(class_7924.field_41265);

			if (lookup != null) {
				return method_58172(stack, enchantingBehaviorItem.getAllEnchantments(stack, lookup));
			}
		}

		return super.method_58161(stack);
	}
}
