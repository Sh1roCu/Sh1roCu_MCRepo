package io.github.fabricators_of_create.porting_lib.util;

import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_4080;

public abstract class IdentifiableSimplePreparableReloadListener<T> extends class_4080<T> implements IdentifiableResourceReloadListener {
	private final class_2960 id;

	protected IdentifiableSimplePreparableReloadListener(class_2960 id) {
		this.id = id;
	}

	@Override
	public class_2960 getFabricId() {
		return id;
	}
}
