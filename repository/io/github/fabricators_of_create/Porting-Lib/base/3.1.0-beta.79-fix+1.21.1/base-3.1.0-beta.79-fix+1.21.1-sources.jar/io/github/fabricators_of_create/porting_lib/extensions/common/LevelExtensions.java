package io.github.fabricators_of_create.porting_lib.extensions.common;

import java.util.LinkedList;
import java.util.List;

import net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext;
import net.fabricmc.fabric.api.transfer.v1.transaction.base.SnapshotParticipant;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import javax.annotation.Nullable;

// allows block modification to be done in transactions easily.
// this only modifies set/getBlockState.
public interface LevelExtensions {
	default SnapshotParticipant<LevelSnapshotData> snapshotParticipant() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default void port_lib$updateSnapshots(TransactionContext ctx) {
		snapshotParticipant().updateSnapshots(ctx);
	}

	record LevelSnapshotData(List<ChangedPosData> changedStates) {
		public LevelSnapshotData(List<ChangedPosData> changedStates) {
			this.changedStates = changedStates == null ? null : new LinkedList<>(changedStates);
		}
	}

	record ChangedPosData(class_2338 pos, class_2680 state, int flags) {
	}

	default void port_lib$markAndNotifyBlock(class_2338 pos, @Nullable class_2818 levelchunk, class_2680 oldState, class_2680 newState, int flags, int p_46608_) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}
