package io.github.fabricators_of_create.porting_lib.util;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_2315;
import net.minecraft.class_2350;
import net.minecraft.class_2357;
import net.minecraft.class_3730;
import net.minecraft.class_5712;
import net.minecraft.class_7699;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

public class DeferredSpawnEggItem extends class_1826 {
	public static final List<DeferredSpawnEggItem> MOD_EGGS = new ArrayList<>();
	private static final Map<class_1299<? extends class_1308>, DeferredSpawnEggItem> TYPE_MAP = new IdentityHashMap<>();
	private final Supplier<? extends class_1299<? extends class_1308>> typeSupplier;

	public DeferredSpawnEggItem(Supplier<? extends class_1299<? extends class_1308>> type, int backgroundColor, int highlightColor, class_1793 props) {
		super(null, backgroundColor, highlightColor, props);
		this.typeSupplier = type;

		MOD_EGGS.add(this);
	}

	@Nullable
	protected class_2357 createDispenseBehavior() {
		return DEFAULT_DISPENSE_BEHAVIOR;
	}

	@ApiStatus.Internal
	@Nullable
	public static class_1826 deferredOnlyById(@Nullable class_1299<?> type) {
		return TYPE_MAP.get(type);
	}
	
	protected class_1299<?> getDefaultType() {
		return this.typeSupplier.get();
	}

	private static final class_2357 DEFAULT_DISPENSE_BEHAVIOR = (source, stack) -> {
		class_2350 face = source.comp_1969().method_11654(class_2315.field_10918);
		class_1299<?> type = ((class_1826) stack.method_7909()).method_8015(stack);

		try {
			type.method_5894(source.comp_1967(), stack, null, source.comp_1968().method_10093(face), class_3730.field_16470, face != class_2350.field_11036, false);
		} catch (Exception exception) {
			class_2357.field_34020.error("Error while dispensing spawn egg from dispenser at {}", source.comp_1968(), exception);
			return class_1799.field_8037;
		}

		stack.method_7934(1);
		source.comp_1967().method_43276(class_5712.field_28738, source.comp_1968(), class_5712.class_7397.method_43287(source.comp_1969()));
		return stack;
	};

	@Override
	public class_1299<?> method_8015(class_1799 p_330335_) {
		class_9279 customdata = p_330335_.method_57825(class_9334.field_49609, class_9279.field_49302);
		return !customdata.method_57458() ? customdata.method_57446(field_49273).result().orElse(getDefaultType()) : getDefaultType();
	}

	@Override
	public class_7699 method_45322() {
		return getDefaultType().method_45322();
	}

	public static void init() {
		MOD_EGGS.forEach(egg -> {
			class_2357 dispenseBehavior = egg.createDispenseBehavior();
			if (dispenseBehavior != null) {
				class_2315.method_10009(egg, dispenseBehavior);
			}

			TYPE_MAP.put(egg.typeSupplier.get(), egg);
		});
	}
}
