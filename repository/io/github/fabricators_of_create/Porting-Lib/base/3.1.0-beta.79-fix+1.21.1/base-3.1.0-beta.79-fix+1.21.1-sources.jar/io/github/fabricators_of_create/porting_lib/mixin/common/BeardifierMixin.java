package io.github.fabricators_of_create.porting_lib.mixin.common;

import io.github.fabricators_of_create.porting_lib.world.PieceBeardifierIterator;
import it.unimi.dsi.fastutil.objects.ObjectList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Slice;

import java.util.Iterator;
import net.minecraft.class_1923;
import net.minecraft.class_3443;
import net.minecraft.class_5817;

@Mixin(class_5817.class)
public class BeardifierMixin {
	@ModifyVariable(
			method = "method_42694",
			slice = @Slice(
					from = @At(
							value = "INVOKE",
							target = "Lnet/minecraft/world/level/levelgen/structure/Structure;terrainAdaptation()Lnet/minecraft/world/level/levelgen/structure/TerrainAdjustment;"
					),
					to = @At(
							value = "INVOKE",
							target = "Ljava/util/Iterator;hasNext()Z"
					)
			),
			at = @At("STORE")
	)
	private static Iterator<class_3443> port_lib$wrapStructureIterator(Iterator<class_3443> iterator, class_1923 pos, ObjectList<class_5817.class_7301> rigids) {
		return new PieceBeardifierIterator(iterator, rigids);
	}
}
