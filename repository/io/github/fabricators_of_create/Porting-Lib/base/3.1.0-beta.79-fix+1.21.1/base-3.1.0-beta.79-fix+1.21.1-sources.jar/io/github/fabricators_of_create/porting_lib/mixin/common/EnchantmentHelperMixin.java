package io.github.fabricators_of_create.porting_lib.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.enchant.CustomEnchantingBehaviorItem;
import io.github.fabricators_of_create.porting_lib.util.PortingHooks;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_7225.class_7226;
import net.minecraft.class_7924;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1890.class)
public abstract class EnchantmentHelperMixin {
	@ModifyExpressionValue(method = "runIterationOnItem(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/enchantment/EnchantmentHelper$EnchantmentVisitor;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getOrDefault(Lnet/minecraft/core/component/DataComponentType;Ljava/lang/Object;)Ljava/lang/Object;"))
	private static Object port_lib$lookupStackEnchantments(Object original, @Local(argsOnly = true) class_1799 stack) {
		if (stack.method_7909() instanceof CustomEnchantingBehaviorItem enchantingBehaviorItem) {
			var lookup = PortingHooks.resolveLookup(class_7924.field_41265);
			if (lookup != null)
				return enchantingBehaviorItem.getAllEnchantments(stack, lookup);
		}

		return original;
	}

	@ModifyExpressionValue(method = "runIterationOnItem(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/EquipmentSlot;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/enchantment/EnchantmentHelper$EnchantmentInSlotVisitor;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;get(Lnet/minecraft/core/component/DataComponentType;)Ljava/lang/Object;"))
	private static Object port_lib$lookupStackEnchantments(Object original, @Local(argsOnly = true) class_1799 stack, @Local(argsOnly = true) class_1309 entity) {
		if (stack.method_7909() instanceof CustomEnchantingBehaviorItem enchantingBehaviorItem) {
			return enchantingBehaviorItem.getAllEnchantments(stack, entity.method_56673().method_46762(class_7924.field_41265));
		}

		return original;
	}

	@ModifyExpressionValue(method = "hasTag", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getOrDefault(Lnet/minecraft/core/component/DataComponentType;Ljava/lang/Object;)Ljava/lang/Object;"))
	private static Object port_lib$lookupStackEnchantments2(Object original, @Local(argsOnly = true) class_1799 stack) {
		if (stack.method_7909() instanceof CustomEnchantingBehaviorItem enchantingBehaviorItem) {
			var lookup = PortingHooks.resolveLookup(class_7924.field_41265);
			if (lookup != null)
				return enchantingBehaviorItem.getAllEnchantments(stack, lookup);
		}

		return original;
	}
}
