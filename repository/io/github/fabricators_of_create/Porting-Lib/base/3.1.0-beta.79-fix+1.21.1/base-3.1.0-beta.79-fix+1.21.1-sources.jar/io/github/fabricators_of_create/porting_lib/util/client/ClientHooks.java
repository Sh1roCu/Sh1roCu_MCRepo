package io.github.fabricators_of_create.porting_lib.util.client;

import io.github.fabricators_of_create.porting_lib.event.client.TextureAtlasStitchedEvent;
import net.minecraft.class_1059;
import net.minecraft.class_1304;
import net.minecraft.class_1921;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import org.jetbrains.annotations.ApiStatus;

public class ClientHooks {
	public static void setPartVisibility(class_572<?> armorModel, class_1304 slot) {
		armorModel.method_2805(false);
		switch (slot) {
			case field_6169:
				armorModel.field_3398.field_3665 = true;
				armorModel.field_3394.field_3665 = true;
				break;
			case field_6174:
				armorModel.field_3391.field_3665 = true;
				armorModel.field_3401.field_3665 = true;
				armorModel.field_27433.field_3665 = true;
				break;
			case field_6172:
				armorModel.field_3391.field_3665 = true;
				armorModel.field_3392.field_3665 = true;
				armorModel.field_3397.field_3665 = true;
				break;
			case field_6166:
				armorModel.field_3392.field_3665 = true;
				armorModel.field_3397.field_3665 = true;
		}
	}

	@ApiStatus.Internal
	public static class_1921 RENDER_TYPE = null;

	/**
	 * Sets the current {@link class_1921} to use for rendering a single block in {@link net.minecraft.class_776#method_3353(class_2680, class_4587, class_4597, int, int)}.
	 * It is very important you set this to null after you have rendered your block(s).
	 *
	 * @param renderType The render type you want to render the block in. Ex: {@link class_1921#method_23583()}
	 */
	public static void setRenderType(class_1921 renderType) {
		RENDER_TYPE = renderType;
	}

	public static void onTextureAtlasStitched(class_1059 atlas) {
		new TextureAtlasStitchedEvent(atlas).sendEvent();
	}
}
