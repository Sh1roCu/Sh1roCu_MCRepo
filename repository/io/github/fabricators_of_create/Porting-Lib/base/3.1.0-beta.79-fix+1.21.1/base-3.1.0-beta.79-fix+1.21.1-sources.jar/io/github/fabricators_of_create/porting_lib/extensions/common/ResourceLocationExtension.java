package io.github.fabricators_of_create.porting_lib.extensions.common;

import net.minecraft.class_2960;

public interface ResourceLocationExtension {
	default int port_lib$compareNamespaced(class_2960 o) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}
