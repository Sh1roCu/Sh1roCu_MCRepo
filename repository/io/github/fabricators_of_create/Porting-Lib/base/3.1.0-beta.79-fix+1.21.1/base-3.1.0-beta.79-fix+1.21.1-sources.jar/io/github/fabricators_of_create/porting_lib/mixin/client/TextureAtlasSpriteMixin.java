package io.github.fabricators_of_create.porting_lib.mixin.client;

import io.github.fabricators_of_create.porting_lib.extensions.client.TextureAtlasSpriteExtension;
import io.github.fabricators_of_create.porting_lib.mixin.client.TextureAtlasSprite.AnimatedTextureAccessor;
import net.minecraft.class_1058;
import net.minecraft.class_7764;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1058.class)
public abstract class TextureAtlasSpriteMixin implements TextureAtlasSpriteExtension {

	@Shadow
	@Final
	private class_7764 contents;

	@Override
	public int port_lib$getPixelRGBA(int frameIndex, int x, int y) {
		if (this.contents.field_40541 != null) {
			x += ((AnimatedTextureAccessor) this.contents.field_40541).port_lib$getFrameX(frameIndex) * this.contents.method_45807();
			y += ((AnimatedTextureAccessor) this.contents.field_40541).port_lib$getFrameY(frameIndex) * this.contents.method_45815();
		}

		return this.contents.field_40539.method_4315(x, y);
	}
}
