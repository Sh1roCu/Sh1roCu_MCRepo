package io.github.fabricators_of_create.porting_lib.mixin.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3999;
import net.minecraft.class_638;
import net.minecraft.class_702;
import net.minecraft.class_703;

@Environment(EnvType.CLIENT)
@Mixin(class_702.class)
public abstract class ParticleEngineMixin {
	@Shadow
	protected class_638 level;

	@Shadow
	@Final
	@Mutable
	private static List<class_3999> RENDER_ORDER;

	@Unique
	private static void addRenderTypeSafe(class_3999 type) {
		if (!(RENDER_ORDER instanceof ArrayList)) {
			List<class_3999> old = RENDER_ORDER;
			RENDER_ORDER = new ArrayList<>(old);
		}
		RENDER_ORDER.add(type);
	}

	@Inject(method = "method_18125", at = @At("RETURN"))
	private static void addCustomRenderTypes(class_3999 particleRenderType, CallbackInfoReturnable<Queue<class_703>> cir) {
		if (!RENDER_ORDER.contains(particleRenderType)) {
			addRenderTypeSafe(particleRenderType);
		}
	}
}
