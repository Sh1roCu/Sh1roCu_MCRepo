package io.github.fabricators_of_create.porting_lib.mixin.client;

import com.google.common.collect.ImmutableMap;

import io.github.fabricators_of_create.porting_lib.util.ForgeI18n;
import net.minecraft.class_1074;
import net.minecraft.class_1078;
import net.minecraft.class_2477;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1074.class)
public abstract class I18nMixin {
	@Inject(method = "setLanguage", at = @At("TAIL"))
	private static void port_lib$setLanguage(class_2477 language, CallbackInfo ci) {
		if (language instanceof class_1078 clientLanguage)
			ForgeI18n.loadLanguageData(((ClientLanguageAccessor)clientLanguage).port_lib$getStorage());
		else
			ForgeI18n.loadLanguageData(ImmutableMap.of());
	}
}
