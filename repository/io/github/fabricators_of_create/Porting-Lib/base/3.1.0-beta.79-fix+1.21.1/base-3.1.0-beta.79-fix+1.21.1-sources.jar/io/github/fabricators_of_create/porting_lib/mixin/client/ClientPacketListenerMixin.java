package io.github.fabricators_of_create.porting_lib.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Share;

import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2487;
import net.minecraft.class_2535;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_8673;
import net.minecraft.class_8675;

@Environment(EnvType.CLIENT)
@Mixin(class_634.class)
public abstract class ClientPacketListenerMixin extends class_8673 {

	protected ClientPacketListenerMixin(class_310 client, class_2535 connection, class_8675 commonListenerCookie) {
		super(client, connection, commonListenerCookie);
	}

	@WrapOperation(method = "method_38542", at = @At(value = "INVOKE", target = "Lnet/minecraft/nbt/CompoundTag;isEmpty()Z"))
	private boolean checkIfUpdateAlreadyHandled(class_2487 instance, Operation<Boolean> original, @Share("data_packet") LocalBooleanRef handleRef) {
		if (!handleRef.get())
			return original.call(instance);
		return true;
	}

}
