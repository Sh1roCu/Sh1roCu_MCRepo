package io.github.fabricators_of_create.porting_lib.client.armor;

import java.util.HashMap;
import java.util.Objects;

import org.jetbrains.annotations.Nullable;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_7923;

@Environment(EnvType.CLIENT)
public class ArmorRendererRegistry {
	private static final HashMap<class_1792, ArmorRenderer> RENDERERS = new HashMap<>();

	public static void register(ArmorRenderer renderer, class_1935... items) {
		Objects.requireNonNull(renderer, "renderer is null");

		if (items.length == 0) {
			throw new IllegalArgumentException("Armor renderer registered for no item");
		}

		for (class_1935 item : items) {
			Objects.requireNonNull(item.method_8389(), "armor item is null");

			if (RENDERERS.putIfAbsent(item.method_8389(), renderer) != null) {
				throw new IllegalArgumentException("Custom armor renderer already exists for " + class_7923.field_41178.method_10206(item.method_8389()));
			}
		}
	}

	@Nullable
	public static ArmorRenderer get(class_1792 item) {
		return RENDERERS.get(item);
	}
}
