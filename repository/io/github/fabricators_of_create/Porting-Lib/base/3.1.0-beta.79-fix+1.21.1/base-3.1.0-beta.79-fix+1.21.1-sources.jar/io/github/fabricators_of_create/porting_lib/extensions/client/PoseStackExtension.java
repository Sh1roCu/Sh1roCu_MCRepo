package io.github.fabricators_of_create.porting_lib.extensions.client;

import net.minecraft.class_4587;
import net.minecraft.class_4590;
import org.joml.Vector3f;

public interface PoseStackExtension {
	/**
	 * Pushes and applies the {@code transformation} to this pose stack. <br>
	 * The effects of this method can be reversed by a corresponding {@link class_4587#method_22909()} call.
	 *
	 * @param transformation the transformation to push
	 */
	default void pushTransformation(class_4590 transformation) {
		final class_4587 self = (class_4587) this;
		self.method_22903();

		Vector3f trans = transformation.method_35865();
		self.method_46416(trans.x(), trans.y(), trans.z());

		self.method_22907(transformation.method_22937());

		Vector3f scale = transformation.method_35866();
		self.method_22905(scale.x(), scale.y(), scale.z());

		self.method_22907(transformation.method_35867());
	}
}
