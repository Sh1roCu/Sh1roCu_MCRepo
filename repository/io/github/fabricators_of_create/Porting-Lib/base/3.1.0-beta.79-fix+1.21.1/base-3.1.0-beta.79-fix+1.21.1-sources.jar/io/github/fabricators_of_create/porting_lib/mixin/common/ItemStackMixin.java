package io.github.fabricators_of_create.porting_lib.mixin.common;

import io.github.fabricators_of_create.porting_lib.core.util.MutableDataComponentHolder;
import io.github.fabricators_of_create.porting_lib.entity.extensions.IShearable;
import io.github.fabricators_of_create.porting_lib.entity.extensions.VanillaIShearable;
import io.github.fabricators_of_create.porting_lib.item.DamageableItem;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_5712;
import net.minecraft.class_9323;
import net.minecraft.class_9326;
import net.minecraft.class_9331;

@Mixin(class_1799.class)
@Implements(@Interface(iface = MutableDataComponentHolder.class, prefix = "port_lib$i$", remap = Interface.Remap.NONE))
public abstract class ItemStackMixin {
	@Shadow
	public abstract class_1792 getItem();

	@Shadow
	public abstract void applyComponents(class_9326 components);

	@Shadow
	public abstract void applyComponents(class_9323 components);

	@Shadow
	@Nullable
	public abstract <T> T set(class_9331<? super T> component, @Nullable T value);

	@Shadow
	@Nullable
	public abstract <T> T remove(class_9331<? extends T> component);

	@Inject(method = "setDamageValue", at = @At("HEAD"), cancellable = true)
	public void port_lib$itemSetDamage(int damage, CallbackInfo ci) {
		if(getItem() instanceof DamageableItem damagableItem) {
			damagableItem.setDamage((class_1799) (Object) this, damage);
			ci.cancel();
		}
	}

	@Inject(method = "getMaxDamage", at = @At("HEAD"), cancellable = true)
	public void port_lib$itemMaxDamage(CallbackInfoReturnable<Integer> cir) {
		if(getItem() instanceof DamageableItem damagableItem) {
			cir.setReturnValue(damagableItem.getMaxDamage((class_1799) (Object) this));
		}
	}

	@Inject(method = "getDamageValue", at = @At("HEAD"), cancellable = true)
	public void port_lib$itemDamage(CallbackInfoReturnable<Integer> cir) {
		if(getItem() instanceof DamageableItem damagableItem) {
			cir.setReturnValue(damagableItem.getDamage((class_1799) (Object) this));
		}
	}

	@Inject(method = "interactLivingEntity", at = @At("HEAD"), cancellable = true)
	private void checkCustomShearBehavior(class_1657 player, class_1309 entity, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
		if (entity instanceof IShearable target && !(entity instanceof VanillaIShearable)) {
			class_1799 stack = (class_1799) (Object) this;
			class_2338 pos = entity.method_24515();
			boolean isClient = entity.method_37908().method_8608();
			// Check isShearable on both sides (mirrors vanilla readyForShearing())
			if (target.isShearable(player, stack, entity.method_37908(), pos)) {
				// Call onSheared on both sides (mirrors vanilla shear())
				List<class_1799> drops = target.onSheared(player, stack, entity.method_37908(), pos);
				// Spawn drops on the server side using spawnShearedDrop to retain vanilla mob-specific behavior
				if (!isClient) {
					for(class_1799 drop : drops) {
						target.spawnShearedDrop(entity.method_37908(), pos, drop);
					}
				}
				// Call GameEvent.SHEAR on both sides
				entity.method_32875(class_5712.field_28730, player);
				// Damage the shear item stack by 1 on the server side
				if (!isClient) {
					stack.method_7970(1, player, class_1309.method_56079(hand));
				}
				// Return sided success if the entity was shearable
				cir.setReturnValue(class_1269.method_29236(isClient));
			}
		}
	}

	@Intrinsic(displace = true)
	@Nullable
	public <T> T port_lib$i$set(class_9331<? super T> componentType, @Nullable T value) {
		return this.set(componentType, value);
	}

	@Intrinsic(displace = true)
	public <T> T port_lib$i$remove(class_9331<? extends T> componentType) {
		return this.remove(componentType);
	}

	@Intrinsic(displace = true)
	public void port_lib$i$applyComponents(class_9326 patch) {
		this.applyComponents(patch);
	}

	@Intrinsic(displace = true)
	public void port_lib$i$applyComponents(class_9323 components) {
		this.applyComponents(components);
	}
}
