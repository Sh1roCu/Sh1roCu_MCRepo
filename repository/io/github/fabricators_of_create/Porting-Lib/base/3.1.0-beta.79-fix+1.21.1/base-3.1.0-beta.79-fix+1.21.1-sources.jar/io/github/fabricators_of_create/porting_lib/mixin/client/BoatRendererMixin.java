package io.github.fabricators_of_create.porting_lib.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import com.mojang.datafixers.util.Pair;

import io.github.fabricators_of_create.porting_lib.client.entity.CustomBoatModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.Map;
import net.minecraft.class_1690;
import net.minecraft.class_2960;
import net.minecraft.class_4595;
import net.minecraft.class_881;

@Mixin(class_881.class)
public class BoatRendererMixin {
	@ModifyReturnValue(method = "getTextureLocation(Lnet/minecraft/world/entity/vehicle/Boat;)Lnet/minecraft/resources/ResourceLocation;", at = @At("RETURN"))
	private class_2960 getCustomModelTexture(class_2960 original, class_1690 boat) {
		if (this instanceof CustomBoatModel customModel)
			return customModel.getModelWithLocation(boat).getFirst();
		return original;
	}

	@WrapOperation(method = "render(Lnet/minecraft/world/entity/vehicle/Boat;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At(value = "INVOKE", target = "Ljava/util/Map;get(Ljava/lang/Object;)Ljava/lang/Object;"))
	private Object getCustomModel(Map<class_1690.class_1692, Pair<class_2960, class_4595<class_1690>>> instance, Object o, Operation<Pair<class_2960, class_4595<class_1690>>> original, class_1690 boat) {
		if (this instanceof CustomBoatModel customModel)
			return customModel.getModelWithLocation(boat);
		return original.call(instance, o);
	}
}
