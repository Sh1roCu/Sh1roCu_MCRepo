package io.github.fabricators_of_create.porting_lib.util;

import javax.annotation.Nullable;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1834;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_6862;
import io.github.fabricators_of_create.porting_lib.tags.Tags;

public class TagUtil {
	@Nullable
	public static class_1767 getColorFromStack(class_1799 stack) {
		class_1792 item = stack.method_7909();
		if (item instanceof class_1769 dyeItem) {
			return dyeItem.method_7802();
		}

		for (class_1767 color : class_1767.values()) {
			if (stack.method_31573(color.getTag())) return color;
		}

		return null;
	}

	public static class_6862<class_2248> getTagFromVanillaTier(class_1834 tier) {
		return switch (tier) {
			case field_8922 -> Tags.Blocks.NEEDS_WOOD_TOOL;
			case field_8929 -> Tags.Blocks.NEEDS_GOLD_TOOL;
			case field_8927 -> class_3481.field_33719;
			case field_8923 -> class_3481.field_33718;
			case field_8930 -> class_3481.field_33717;
			case field_22033 -> Tags.Blocks.NEEDS_NETHERITE_TOOL;
		};
	}
}
