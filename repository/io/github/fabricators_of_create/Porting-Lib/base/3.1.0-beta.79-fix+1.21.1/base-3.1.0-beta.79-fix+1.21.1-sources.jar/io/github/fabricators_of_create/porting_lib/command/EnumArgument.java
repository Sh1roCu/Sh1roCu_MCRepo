package io.github.fabricators_of_create.porting_lib.command;

import com.google.gson.JsonObject;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.Dynamic2CommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_2172;
import net.minecraft.class_2314;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_7157;

public class EnumArgument<T extends Enum<T>> implements ArgumentType<T> {
	private static final Dynamic2CommandExceptionType INVALID_ENUM = new Dynamic2CommandExceptionType(
			(found, constants) -> class_2561.method_43469("commands.porting_lib.arguments.enum.invalid", constants, found));
	private final Class<T> enumClass;

	public static <R extends Enum<R>> EnumArgument<R> enumArgument(Class<R> enumClass) {
		return new EnumArgument<>(enumClass);
	}

	private EnumArgument(final Class<T> enumClass) {
		this.enumClass = enumClass;
	}

	@Override
	public T parse(final StringReader reader) throws CommandSyntaxException {
		String name = reader.readUnquotedString();
		try {
			return Enum.valueOf(enumClass, name);
		} catch (IllegalArgumentException e) {
			throw INVALID_ENUM.createWithContext(reader, name, Arrays.toString(Arrays.stream(enumClass.getEnumConstants()).map(Enum::name).toArray()));
		}
	}

	@Override
	public <S> CompletableFuture<Suggestions> listSuggestions(final CommandContext<S> context, final SuggestionsBuilder builder) {
		return class_2172.method_9264(Stream.of(enumClass.getEnumConstants()).map(Enum::name), builder);
	}

	@Override
	public Collection<String> getExamples() {
		return Stream.of(enumClass.getEnumConstants()).map(Enum::name).collect(Collectors.toList());
	}

	public static class Info<T extends Enum<T>> implements class_2314<EnumArgument<T>, Info<T>.Template> {
		@Override
		public void serializeToNetwork(Template template, class_2540 buffer) {
			buffer.method_10814(template.enumClass.getName());
		}

		@SuppressWarnings("unchecked")
		@Override
		public Template method_10005(class_2540 buffer) {
			try {
				String name = buffer.method_19772();
				return new Template((Class<T>) Class.forName(name));
			} catch (ClassNotFoundException e) {
				return null;
			}
		}

		@Override
		public void serializeToJson(Template template, JsonObject json) {
			json.addProperty("enum", template.enumClass.getName());
		}

		@Override
		public Template unpack(EnumArgument<T> argument) {
			return new Template(argument.enumClass);
		}

		public class Template implements class_2314.class_7217<EnumArgument<T>> {
			final Class<T> enumClass;

			Template(Class<T> enumClass) {
				this.enumClass = enumClass;
			}

			@Override
			public EnumArgument<T> method_41730(class_7157 pStructure) {
				return new EnumArgument<>(this.enumClass);
			}

			@Override
			public class_2314<EnumArgument<T>, ?> method_41728() {
				return Info.this;
			}
		}
	}
}
