package io.github.fabricators_of_create.porting_lib.command;

import java.io.File;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_7157;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;

import io.github.fabricators_of_create.porting_lib.config.ConfigTracker;
import io.github.fabricators_of_create.porting_lib.config.ModConfig;
import io.github.fabricators_of_create.porting_lib.config.ModConfigs;

public class ConfigCommand {
	public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
		dispatcher.register(
				class_2170.method_9247("porting_lib")
						.then(class_2170.method_9247("config").
							then(ShowFile.register())
		));
	}

	public static class ShowFile {
		static ArgumentBuilder<class_2168, ?> register() {
			return class_2170.method_9247("showfile").
					requires(cs->cs.method_9259(0)).
					then(class_2170.method_9244("mod", ModIdArgument.modIdArgument()).
							then(class_2170.method_9244("type", EnumArgument.enumArgument(ModConfig.Type.class)).
									executes(ShowFile::showFile)
							)
					);
		}

		private static int showFile(final CommandContext<class_2168> context) {
			final String modId = context.getArgument("mod", String.class);
			final ModConfig.Type type = ModConfig.Type.CLIENT;
			var configFileNames = ModConfigs.getConfigFileNames(modId, type);
			for (var configFileName : configFileNames) {
				File f = new File(configFileName);
				class_5250 fileComponent = class_2561.method_43470(f.getName()).method_27692(class_124.field_1073)
						.method_27694((style) -> style.method_10958(new class_2558(class_2558.class_2559.field_11746, f.getAbsolutePath())));

				context.getSource().method_9226(() -> class_2561.method_43469("commands.config.getwithtype",
						modId, type.toString(), fileComponent), true);
			}
			if (configFileNames.isEmpty()) {
				context.getSource().method_9226(() -> class_2561.method_43469("commands.config.noconfig", modId, type.toString()),
						true);
			}
			return 0;
		}
	}
}
