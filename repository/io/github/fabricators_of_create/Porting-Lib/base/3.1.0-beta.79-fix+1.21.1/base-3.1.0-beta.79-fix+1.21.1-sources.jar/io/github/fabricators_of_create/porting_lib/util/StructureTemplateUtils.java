package io.github.fabricators_of_create.porting_lib.util;

import javax.annotation.Nullable;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3491;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_3499.class_3502;
import java.util.ArrayList;
import java.util.List;

/**
 * Small utilities for StructureTemplates provided by forge.
 */
public class StructureTemplateUtils {
	/**
	 * Transforms the given vector using the provided placement settings (mirror, rotation, pivot)
	 */
	public static class_243 transformedVec3d(class_3492 settings, class_243 pos) {
		return class_3499.method_15176(
				pos, settings.method_15114(), settings.method_15113(), settings.method_15134()
		);
	}

	/**
	 * Processes entity infos in the same way blocks are.
	 * StructureProcessors may optionally implement a method to process entities.
	 */
	public static List<class_3502> processEntityInfos(@Nullable class_3499 template, class_1936 level,
															   class_2338 pos, class_3492 settings,
															   List<class_3502> entityInfos) {
		List<class_3502> processed = new ArrayList<>();
		for(class_3502 entityInfo : entityInfos) {
			class_243 entityPos = transformedVec3d(settings, entityInfo.field_15599).method_1019(class_243.method_24954(pos));
			class_2338 blockpos = class_3499.method_15171(settings, entityInfo.field_15600).method_10081(pos);
			class_3502 info = new class_3502(entityPos, blockpos, entityInfo.field_15598);
			for (class_3491 proc : settings.method_16182()) {
				info = proc.port_lib$processEntity(level, pos, entityInfo, info, settings, template);
				if (info == null)
					break;
			}
			if (info != null)
				processed.add(info);
		}
		return processed;
	}
}
