package io.github.fabricators_of_create.porting_lib.extensions.common;

import net.minecraft.class_2474;
import net.minecraft.class_6862;

public interface TagAppenderExtension {
	@SuppressWarnings("unchecked")
	default <E> class_2474.class_5124<E> addTags(class_6862<E>... values) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}
