package io.github.fabricators_of_create.porting_lib.mixin.common;

import com.llamalad7.mixinextras.sugar.Local;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import io.github.fabricators_of_create.porting_lib.event.common.AdvancementEvent;
import net.minecraft.class_167;
import net.minecraft.class_185;
import net.minecraft.class_2985;
import net.minecraft.class_3222;
import net.minecraft.class_8779;

@Mixin(class_2985.class)
public abstract class PlayerAdvancementsMixin {
	@Shadow
	private class_3222 player;

	@Inject(method = "award", at = @At(value = "INVOKE", target = "Ljava/util/Set;add(Ljava/lang/Object;)Z", shift = At.Shift.AFTER))
	public void onAdvancementProgress(class_8779 advancement, String criterionName, CallbackInfoReturnable<Boolean> cir, @Local class_167 advancementProgress) {
		AdvancementEvent.AdvancementProgressEvent event = new AdvancementEvent.AdvancementProgressEvent(this.player, advancement, advancementProgress, criterionName, AdvancementEvent.AdvancementProgressEvent.ProgressType.GRANT);
		event.sendEvent();
	}

	@Inject(method = "revoke", at = @At(value = "INVOKE", target = "Ljava/util/Set;add(Ljava/lang/Object;)Z", shift = At.Shift.AFTER))
	private void onAdvancementRevoke(class_8779 advancement, String criterionName, CallbackInfoReturnable<Boolean> cir, @Local class_167 advancementProgress) {
		AdvancementEvent.AdvancementProgressEvent event = new AdvancementEvent.AdvancementProgressEvent(this.player, advancement, advancementProgress, criterionName, AdvancementEvent.AdvancementProgressEvent.ProgressType.REVOKE);
		event.sendEvent();
	}

	@Inject(method = "method_53637", at = @At("TAIL"))
	public void onAwardAdvancement(class_8779 advancementHolder, class_185 display, CallbackInfo ci) {
		AdvancementEvent.AdvancementEarnEvent event = new AdvancementEvent.AdvancementEarnEvent(this.player, advancementHolder);
		event.sendEvent();
	}
}
