package io.github.fabricators_of_create.porting_lib.util;

import net.minecraft.class_2246;
import net.minecraft.class_2680;

public class StickinessUtil {
	public static boolean canStickTo(class_2680 state, class_2680 other) {
		if (state.method_26204() == class_2246.field_21211 && other.method_26204() == class_2246.field_10030) return false;
		if (state.method_26204() == class_2246.field_10030 && other.method_26204() == class_2246.field_21211) return false;
		return (state.method_26204() == class_2246.field_10030 || state.method_26204() == class_2246.field_21211) ||
				(other.method_26204() == class_2246.field_10030 || other.method_26204() == class_2246.field_21211);
	}
}
