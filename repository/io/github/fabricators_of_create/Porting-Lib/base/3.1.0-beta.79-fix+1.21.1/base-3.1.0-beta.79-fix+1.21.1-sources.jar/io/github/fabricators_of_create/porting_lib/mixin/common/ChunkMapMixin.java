package io.github.fabricators_of_create.porting_lib.mixin.common;

import io.github.fabricators_of_create.porting_lib.event.common.ChunkWatchEvent;
import net.minecraft.class_1923;
import net.minecraft.class_2818;
import net.minecraft.class_3222;
import net.minecraft.class_3898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3898.class)
public abstract class ChunkMapMixin {
	@Inject(method = "markChunkPendingToSend(Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/level/chunk/LevelChunk;)V", at = @At("TAIL"))
	private static void watchChunk(class_3222 player, class_2818 chunk, CallbackInfo ci) {
		new ChunkWatchEvent.Watch(player, chunk, player.method_51469()).sendEvent();
	}

	@Inject(method = "dropChunk", at = @At("HEAD"))
	private static void unwatchChunk(class_3222 player, class_1923 chunkPos, CallbackInfo ci) {
		new ChunkWatchEvent.UnWatch(player, chunkPos, player.method_51469()).sendEvent();
	}
}
