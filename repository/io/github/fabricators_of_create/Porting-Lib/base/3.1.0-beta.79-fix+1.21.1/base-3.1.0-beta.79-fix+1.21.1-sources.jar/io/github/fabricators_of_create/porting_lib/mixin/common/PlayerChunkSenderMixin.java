package io.github.fabricators_of_create.porting_lib.mixin.common;

import io.github.fabricators_of_create.porting_lib.event.common.ChunkWatchEvent;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3244;
import net.minecraft.class_8608;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_8608.class)
public class PlayerChunkSenderMixin {
	@Inject(method = "sendChunk", at = @At("TAIL"))
	private static void sentChunkEvent(class_3244 packetListener, class_3218 level, class_2818 chunk, CallbackInfo ci) {
		new ChunkWatchEvent.Sent(packetListener.field_14140, chunk, level).sendEvent();
	}
}
