package com.simibubi.create;

import com.simibubi.create.foundation.damageTypes.DamageTypeBuilder;
import net.minecraft.class_5321;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.class_8107;
import net.minecraft.class_8108;
import net.minecraft.class_8110;

public class AllDamageTypes {
	public static final class_5321<class_8110>
			CRUSH = key("crush"),
			CUCKOO_SURPRISE = key("cuckoo_surprise"),
			FAN_FIRE = key("fan_fire"),
			FAN_LAVA = key("fan_lava"),
			DRILL = key("mechanical_drill"),
			ROLLER = key("mechanical_roller"),
			SAW = key("mechanical_saw"),
			POTATO_CANNON = key("potato_cannon"),
			RUN_OVER = key("run_over");

	private static class_5321<class_8110> key(String name) {
		return class_5321.method_29179(class_7924.field_42534, Create.asResource(name));
	}

	public static void bootstrap(class_7891<class_8110> ctx) {
		new DamageTypeBuilder(CRUSH).scaling(class_8108.field_42287).register(ctx);
		new DamageTypeBuilder(CUCKOO_SURPRISE).scaling(class_8108.field_42287).exhaustion(0.1f).register(ctx);
		new DamageTypeBuilder(FAN_FIRE).effects(class_8107.field_42278).register(ctx);
		new DamageTypeBuilder(FAN_LAVA).effects(class_8107.field_42278).register(ctx);
		new DamageTypeBuilder(DRILL).register(ctx);
		new DamageTypeBuilder(ROLLER).register(ctx);
		new DamageTypeBuilder(SAW).register(ctx);
		new DamageTypeBuilder(POTATO_CANNON).register(ctx);
		new DamageTypeBuilder(RUN_OVER).register(ctx);
	}
}
