package com.simibubi.create.content.contraptions.actors.contraptionControls;

import com.mojang.serialization.MapCodec;
import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllShapes;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.content.contraptions.actors.trainControls.ControlsBlock;
import com.simibubi.create.foundation.block.IBE;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2383;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import org.jetbrains.annotations.NotNull;

public class ContraptionControlsBlock extends ControlsBlock implements IBE<ContraptionControlsBlockEntity> {

	public static final MapCodec<ContraptionControlsBlock> CODEC = method_54094(ContraptionControlsBlock::new);

	public ContraptionControlsBlock(class_2251 pProperties) {
		super(pProperties);
	}

	@Override
	protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
		return onBlockEntityUse(level, pos, cte -> {
			cte.pressButton();
			if (!level.method_8608()) {
				cte.disabled = !cte.disabled;
				cte.notifyUpdate();
				ContraptionControlsBlockEntity.sendStatus(player, cte.filtering.getFilter(), !cte.disabled);
				AllSoundEvents.CONTROLLER_CLICK.play(cte.method_10997(), null, cte.method_11016(), 1,
					cte.disabled ? 0.8f : 1.5f);
			}
			return class_1269.field_5812;
		});
	}

	@Override
	public void method_9612(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_2248 pBlock, class_2338 pFromPos,
		boolean pIsMoving) {
		withBlockEntityDo(pLevel, pPos, ContraptionControlsBlockEntity::updatePoweredState);
	}

	@Override
	public class_265 method_9530(class_2680 pState, class_1922 pLevel, class_2338 pPos, class_3726 pContext) {
		return AllShapes.CONTRAPTION_CONTROLS.get(pState.method_11654(field_11177));
	}
	
	@Override
	public class_265 method_9549(class_2680 pState, class_1922 pLevel, class_2338 pPos,
		class_3726 pContext) {
		return AllShapes.CONTRAPTION_CONTROLS_COLLISION.get(pState.method_11654(field_11177));
	}

	@Override
	public Class<ContraptionControlsBlockEntity> getBlockEntityClass() {
		return ContraptionControlsBlockEntity.class;
	}

	@Override
	public class_2591<? extends ContraptionControlsBlockEntity> getBlockEntityType() {
		return AllBlockEntityTypes.CONTRAPTION_CONTROLS.get();
	}

	@Override
	protected @NotNull MapCodec<? extends class_2383> method_53969() {
		return field_46280;
	}
}
