package com.simibubi.create.content.contraptions.actors.harvester;

import javax.annotation.Nullable;

import net.neoforged.neoforge.common.SpecialPlantable;

import org.apache.commons.lang3.mutable.MutableBoolean;

import com.simibubi.create.AllTags.AllBlockTags;
import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.contraptions.render.ActorVisual;
import com.simibubi.create.content.contraptions.render.ContraptionMatrices;
import com.simibubi.create.foundation.item.ItemHelper;
import com.simibubi.create.foundation.utility.BlockHelper;
import com.simibubi.create.foundation.virtualWorld.VirtualRenderWorld;
import com.simibubi.create.infrastructure.config.AllConfigs;

import dev.engine_room.flywheel.api.visualization.VisualizationContext;
import dev.engine_room.flywheel.api.visualization.VisualizationManager;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2282;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2523;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2758;
import net.minecraft.class_2769;
import net.minecraft.class_3481;
import net.minecraft.class_3830;
import net.minecraft.class_4597;
import net.minecraft.class_4863;
import io.github.fabricators_of_create.porting_lib.common.util.IPlantable;

public class HarvesterMovementBehaviour implements MovementBehaviour {

	@Override
	public boolean isActive(MovementContext context) {
		return MovementBehaviour.super.isActive(context)
			&& !VecHelper.isVecPointingTowards(context.relativeMotion, context.state.method_11654(HarvesterBlock.field_11177)
			.method_10153());
	}

	@Override
	public class_243 getActiveAreaOffset(MovementContext context) {
		return class_243.method_24954(context.state.method_11654(HarvesterBlock.field_11177)
				.method_10163())
			.method_1021(.45);
	}

	@Override
	public void visitNewPosition(MovementContext context, class_2338 pos) {
		class_1937 world = context.world;
		if (world.field_9236)
			return;

		class_2680 stateVisited = world.method_8320(pos);
		if (stateVisited.method_26215() || AllBlockTags.NON_HARVESTABLE.matches(stateVisited))
			return;

		boolean notCropButCuttable = false;

		if (!isValidCrop(world, pos, stateVisited)) {
			if (isValidOther(world, pos, stateVisited))
				notCropButCuttable = true;
			else
				return;
		}

		class_1799 item = class_1799.field_8037;
		float effectChance = 1;

		if (stateVisited.method_26164(class_3481.field_15503)) {
			item = new class_1799(class_1802.field_8868);
			effectChance = .45f;
		}

		MutableBoolean seedSubtracted = new MutableBoolean(notCropButCuttable);
		class_2680 state = stateVisited;
		BlockHelper.destroyBlockAs(world, pos, null, item, effectChance, stack -> {
			if (AllConfigs.server().kinetics.harvesterReplants.get() && !seedSubtracted.getValue()
				&& ItemHelper.sameItem(stack, new class_1799(state.method_26204()))) {
				stack.method_7934(1);
				seedSubtracted.setTrue();
			}
			if (!stack.method_7960()) // fabric: guard shrinking above
				dropItem(context, stack);
		});

		class_2680 cutCrop = cutCrop(world, pos, stateVisited);
		world.method_8501(pos, cutCrop.method_26184(world, pos) ? cutCrop : class_2246.field_10124.method_9564());
	}

	public boolean isValidCrop(class_1937 world, class_2338 pos, class_2680 state) {
		boolean harvestPartial = AllConfigs.server().kinetics.harvestPartiallyGrown.get();
		boolean replant = AllConfigs.server().kinetics.harvesterReplants.get();

		if (state.method_26204() instanceof class_2302 crop) {
			if (harvestPartial)
				return state != crop.method_9828(0) || !replant;
			return crop.method_9825(state);
		}

		if (state.method_26220(world, pos)
			.method_1110() || state.method_26204() instanceof class_2282) {
			for (class_2769<?> property : state.method_28501()) {
				if (!(property instanceof class_2758 ageProperty))
					continue;
				if (!property.method_11899()
					.equals(class_2741.field_12521.method_11899()))
					continue;
				int age = state.method_11654(ageProperty)
					.intValue();
				if (state.method_26204() instanceof class_3830 && age <= 1 && replant)
					continue;
				if (age == 0 && replant || !harvestPartial && (ageProperty.method_11898()
					.size() - 1 != age))
					continue;
				return true;
			}
		}

		return false;
	}

	public boolean isValidOther(class_1937 world, class_2338 pos, class_2680 state) {
		if (state.method_26204() instanceof class_2302)
			return false;
		if (state.method_26204() instanceof class_2523)
			return true;
		if (state.method_26164(class_3481.field_15503))
			return true;
		if (state.method_26204() instanceof class_2282)
			return state.method_11654(class_2282.field_10779) == class_2282.field_31061;

		if (state.method_26220(world, pos)
			.method_1110()) {
			if (state.method_26204() instanceof class_4863)
				return true;

			for (class_2769<?> property : state.method_28501()) {
				if (!(property instanceof class_2758))
					continue;
				if (!property.method_11899()
					.equals(class_2741.field_12521.method_11899()))
					continue;
				return false;
			}

			if (state.method_26204() instanceof SpecialPlantable)
				return true;
		}

		return false;
	}

	private class_2680 cutCrop(class_1937 world, class_2338 pos, class_2680 state) {
		if (!AllConfigs.server().kinetics.harvesterReplants.get()) {
			if (state.method_26227()
				.method_15769())
				return class_2246.field_10124.method_9564();
			return state.method_26227()
				.method_15759();
		}

		class_2248 block = state.method_26204();
		if (block instanceof class_2302 crop) {
			return crop.method_9828(0);
		}
		if (block == class_2246.field_16999) {
			return state.method_11657(class_2741.field_12497, Integer.valueOf(1));
		}
		if (AllBlockTags.SUGAR_CANE_VARIANTS.matches(block) || block instanceof class_4863) {
			if (state.method_26227()
				.method_15769())
				return class_2246.field_10124.method_9564();
			return state.method_26227()
				.method_15759();
		}
		if (state.method_26220(world, pos)
			.method_1110() || block instanceof class_2282) {
			for (class_2769<?> property : state.method_28501()) {
				if (!(property instanceof class_2758))
					continue;
				if (!property.method_11899()
					.equals(class_2741.field_12521.method_11899()))
					continue;
				return state.method_11657((class_2758) property, Integer.valueOf(0));
			}
		}

		if (state.method_26227()
			.method_15769())
			return class_2246.field_10124.method_9564();
		return state.method_26227()
			.method_15759();
	}

	@Override
	public boolean disableBlockEntityRendering() {
		return true;
	}

	@Override
	public void renderInContraption(MovementContext context, VirtualRenderWorld renderWorld,
									ContraptionMatrices matrices, class_4597 buffers) {
		if (!VisualizationManager.supportsVisualization(context.world))
			HarvesterRenderer.renderInContraption(context, renderWorld, matrices, buffers);
	}

	@Nullable
	@Override
	public ActorVisual createVisual(VisualizationContext visualizationContext, VirtualRenderWorld simulationWorld,
									MovementContext movementContext) {
		return new HarvesterActorVisual(visualizationContext, simulationWorld, movementContext);
	}

}
