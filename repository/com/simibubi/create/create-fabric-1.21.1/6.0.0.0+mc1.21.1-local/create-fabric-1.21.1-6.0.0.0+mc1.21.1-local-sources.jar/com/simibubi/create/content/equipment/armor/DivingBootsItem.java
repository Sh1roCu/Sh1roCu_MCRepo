package com.simibubi.create.content.equipment.armor;

import io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor.LivingEntityAccessor;

import net.createmod.catnip.nbt.NBTHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3486;
import net.minecraft.class_4050;
import net.minecraft.class_6880;
import io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor.LivingEntityAccessor;

public class DivingBootsItem extends BaseArmorItem {
	public static final class_1304 SLOT = class_1304.field_6166;
	public static final class_1738.class_8051 TYPE = class_1738.class_8051.field_41937;

	public DivingBootsItem(class_6880<class_1741> material, class_1793 properties, class_2960 textureLoc) {
		super(material, TYPE, properties, textureLoc);
	}

	public static boolean isWornBy(class_1297 entity) {
		return !getWornItem(entity).method_7960();
	}

	public static class_1799 getWornItem(class_1297 entity) {
		if (!(entity instanceof class_1309 livingEntity)) {
			return class_1799.field_8037;
		}
		class_1799 stack = livingEntity.method_6118(SLOT);
		if (!(stack.method_7909() instanceof DivingBootsItem)) {
			return class_1799.field_8037;
		}
		return stack;
	}

	public static void accelerateDescentUnderwater(class_1309 entity) {
		if (!affects(entity))
			return;

		class_243 motion = entity.method_18798();
		boolean isJumping = ((LivingEntityAccessor) entity).port_lib$isJumping();
		entity.method_24830(entity.method_24828() || entity.field_5992);

		if (isJumping && entity.method_24828()) {
			motion = motion.method_1031(0, .5f, 0);
			entity.method_24830(false);
		} else {
			motion = motion.method_1031(0, -0.05f, 0);
		}

		float multiplier = 1.3f;
		if (motion.method_18805(1, 0, 1)
			.method_1033() < 0.145f && (entity.field_6250 > 0 || entity.field_6212 != 0) && !entity.method_5715())
			motion = motion.method_18805(multiplier, 1, multiplier);
		entity.method_18799(motion);
	}

	protected static boolean affects(class_1309 entity) {
		if (!isWornBy(entity)) {
			entity.getCustomData()
				.method_10551("HeavyBoots");
			return false;
		}

		NBTHelper.putMarker(entity.getCustomData(), "HeavyBoots");
		if (!entity.method_5799())
			return false;
		if (entity.method_18376() == class_4050.field_18079)
			return false;
		if (entity instanceof class_1657 playerEntity) {
			if (playerEntity.method_31549().field_7479)
				return false;
		}
		return true;
	}

	public static class_243 getMovementMultiplier(class_1309 entity) {
		double yMotion = entity.method_18798().field_1351;
		double vMultiplier = yMotion < 0 ? Math.max(0, 2.5 - Math.abs(yMotion) * 2) : 1;

		if (!entity.method_24828()) {
			if (((LivingEntityAccessor) entity).port_lib$isJumping() && entity.getCustomData()
				.method_10545("LavaGrounded")) {
				boolean eyeInFluid = entity.method_5777(class_3486.field_15518);
				vMultiplier = yMotion == 0 ? 0 : (eyeInFluid ? 1 : 0.5) / yMotion;
			} else if (yMotion > 0)
				vMultiplier = 1.3;

			entity.getCustomData()
				.method_10551("LavaGrounded");
			return new class_243(1.75, vMultiplier, 1.75);
		}

		entity.getCustomData()
			.method_10556("LavaGrounded", true);
		double hMultiplier = entity.method_5624() ? 1.85 : 1.75;
		return new class_243(hMultiplier, vMultiplier, hMultiplier);
	}

}
