package com.simibubi.create.content.equipment.tool;

import com.simibubi.create.AllPackets;

import io.netty.buffer.ByteBuf;
import net.createmod.catnip.net.base.ClientboundPacketPayload;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record KnockbackPacket(float yRot, float strength) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, KnockbackPacket> STREAM_CODEC = class_9139.method_56435(
		class_9135.field_48552, KnockbackPacket::yRot,
	    class_9135.field_48552, KnockbackPacket::strength,
	    KnockbackPacket::new
	);

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.KNOCKBACK;
	}

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		if (player != null)
			player.method_6005(strength, class_3532.method_15374(yRot * ((float) Math.PI / 180F)), -class_3532.method_15362(yRot * ((float) Math.PI / 180F)));
	}
}
