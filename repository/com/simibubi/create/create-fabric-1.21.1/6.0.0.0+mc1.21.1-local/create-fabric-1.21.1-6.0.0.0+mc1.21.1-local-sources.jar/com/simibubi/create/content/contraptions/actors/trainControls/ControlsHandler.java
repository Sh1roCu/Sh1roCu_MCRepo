package com.simibubi.create.content.contraptions.actors.trainControls;

import java.lang.ref.WeakReference;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import com.simibubi.create.foundation.utility.ControlsUtil;
import com.simibubi.create.foundation.utility.CreateLang;

public class ControlsHandler {

	public static Collection<Integer> currentlyPressed = new HashSet<>();

	public static int PACKET_RATE = 5;
	private static int packetCooldown;

	private static WeakReference<AbstractContraptionEntity> entityRef = new WeakReference<>(null);
	private static class_2338 controlsPos;

	public static void levelUnloaded(class_1936 level) {
		packetCooldown = 0;
		entityRef = new WeakReference<>(null);
		controlsPos = null;
		currentlyPressed.clear();
	}

	public static void startControlling(AbstractContraptionEntity entity, class_2338 controllerLocalPos) {
		entityRef = new WeakReference<>(entity);
		controlsPos = controllerLocalPos;

		class_310.method_1551().field_1724.method_7353(
			CreateLang.translateDirect("contraption.controls.start_controlling", entity.getContraptionName()), true);
	}

	public static void stopControlling() {
		ControlsUtil.getControls()
			.forEach(kb -> kb.method_23481(ControlsUtil.isActuallyPressed(kb)));
		AbstractContraptionEntity abstractContraptionEntity = entityRef.get();

		if (!currentlyPressed.isEmpty() && abstractContraptionEntity != null)
			CatnipServices.NETWORK.sendToServer(new ControlsInputPacket(currentlyPressed, false,
				abstractContraptionEntity.method_5628(), controlsPos, false));

		packetCooldown = 0;
		entityRef = new WeakReference<>(null);
		controlsPos = null;
		currentlyPressed.clear();

		class_310.method_1551().field_1724.method_7353(CreateLang.translateDirect("contraption.controls.stop_controlling"),
			true);
	}

	public static void tick() {
		AbstractContraptionEntity entity = entityRef.get();
		if (entity == null)
			return;
		if (packetCooldown > 0)
			packetCooldown--;

		if (entity.method_31481() || class_3675.method_15987(class_310.method_1551()
			.method_22683()
			.method_4490(), GLFW.GLFW_KEY_ESCAPE)) {
			class_2338 pos = controlsPos;
			stopControlling();
			CatnipServices.NETWORK.sendToServer(new ControlsInputPacket(currentlyPressed, false, entity.method_5628(), pos, true));
			return;
		}

		List<class_304> controls = ControlsUtil.getControls();
		Collection<Integer> pressedKeys = new HashSet<>();
		for (int i = 0; i < controls.size(); i++) {
			if (ControlsUtil.isActuallyPressed(controls.get(i)))
				pressedKeys.add(i);
		}

		Collection<Integer> newKeys = new HashSet<>(pressedKeys);
		Collection<Integer> releasedKeys = currentlyPressed;
		newKeys.removeAll(releasedKeys);
		releasedKeys.removeAll(pressedKeys);

		// Released Keys
		if (!releasedKeys.isEmpty()) {
			CatnipServices.NETWORK.sendToServer(new ControlsInputPacket(releasedKeys, false, entity.method_5628(), controlsPos, false));
//			AllSoundEvents.CONTROLLER_CLICK.playAt(player.level, player.blockPosition(), 1f, .5f, true);
		}

		// Newly Pressed Keys
		if (!newKeys.isEmpty()) {
			CatnipServices.NETWORK.sendToServer(new ControlsInputPacket(newKeys, true, entity.method_5628(), controlsPos, false));
			packetCooldown = PACKET_RATE;
//			AllSoundEvents.CONTROLLER_CLICK.playAt(player.level, player.blockPosition(), 1f, .75f, true);
		}

		// Keepalive Pressed Keys
		if (packetCooldown == 0) {
//			if (!pressedKeys.isEmpty()) {
			CatnipServices.NETWORK.sendToServer(new ControlsInputPacket(pressedKeys, true, entity.method_5628(), controlsPos, false));
				packetCooldown = PACKET_RATE;
//			}
		}

		currentlyPressed = pressedKeys;
		controls.forEach(kb -> kb.method_23481(false));
	}

	@Nullable
	public static AbstractContraptionEntity getContraption() {
		return entityRef.get();
	}

	@Nullable
	public static class_2338 getControlsPos() {
		return controlsPos;
	}

}
