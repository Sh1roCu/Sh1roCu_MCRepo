package com.simibubi.create.content.contraptions.minecart.capability;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.annotation.Nullable;

import org.apache.commons.lang3.mutable.MutableBoolean;
import org.jetbrains.annotations.NotNull;

import com.simibubi.create.Create;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.OrientedContraptionEntity;
import com.simibubi.create.content.contraptions.minecart.CouplingHandler;

import net.createmod.catnip.data.Couple;
import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.lang.Lang;
import net.createmod.catnip.math.VecHelper;
import net.createmod.catnip.nbt.NBTHelper;
import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1297;
import net.minecraft.class_1688;
import net.minecraft.class_1695;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2442;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3532;
import net.minecraft.class_7225;
import io.github.fabricators_of_create.porting_lib.core.util.INBTSerializable;
import io.github.fabricators_of_create.porting_lib.util.MinecartAndRailUtil;

/**
 * Extended code for Minecarts, this allows for handling stalled carts and
 * coupled trains
 */
public class MinecartController implements INBTSerializable<class_2487> {
	public static final MinecartController EMPTY = new MinecartController.Empty();

	private boolean needsEntryRefresh;
	private WeakReference<class_1688> weakRef;

	/*
	 * Stall information, <Internal (waiting couplings), External (stalled
	 * contraptions)>
	 */
	private Couple<Optional<StallData>> stallData;

	/*
	 * Coupling information, <Main (helmed by this cart), Connected (handled by
	 * other cart)>
	 */
	private Couple<Optional<CouplingData>> couplings;

	public MinecartController(class_1688 minecart) {
		weakRef = new WeakReference<>(minecart);
		stallData = Couple.create(Optional::empty);
		couplings = Couple.create(Optional::empty);
		needsEntryRefresh = true;
	}

	public final boolean isEmpty() {
		return this == EMPTY;
	}

	public void tick() {
		class_1688 cart = cart();
		class_1937 world = getWorld();

		if (cart == null || world == null)
			return;

		if (needsEntryRefresh) {
			CapabilityMinecartController.queuedAdditions.get(world).add(cart);
			needsEntryRefresh = false;
		}

		stallData.forEach(opt -> opt.ifPresent(sd -> sd.tick(cart)));

		MutableBoolean internalStall = new MutableBoolean(false);
		couplings.forEachWithContext((opt, main) -> opt.ifPresent(cd -> {

			UUID idOfOther = cd.idOfCart(!main);
			MinecartController otherCart = CapabilityMinecartController.getIfPresent(world, idOfOther);
			internalStall.setValue(
				internalStall.booleanValue() || otherCart == null || !otherCart.isPresent() || otherCart.isStalled(false));

		}));
		if (!world.field_9236) {
			setStalled(internalStall.booleanValue(), true);
			disassemble(cart);
		}
	}

	private void disassemble(class_1688 cart) {
		if (cart instanceof class_1695) {
			return;
		}
		List<class_1297> passengers = cart.method_5685();
		if (passengers.isEmpty() || !(passengers.getFirst() instanceof AbstractContraptionEntity)) {
			return;
		}
		class_1937 world = cart.method_37908();
		int i = class_3532.method_15357(cart.method_23317());
		int j = class_3532.method_15357(cart.method_23318());
		int k = class_3532.method_15357(cart.method_23321());
		if (world.method_8320(new class_2338(i, j - 1, k))
			.method_26164(class_3481.field_15463)) {
			--j;
		}
		class_2338 blockpos = new class_2338(i, j, k);
		class_2680 blockstate = world.method_8320(blockpos);
		if (blockstate.method_26164(class_3481.field_15463)
				&& blockstate.method_26204() instanceof class_2442
				&& (MinecartAndRailUtil.isActivatorRail(
				blockstate.method_26204()))) {
			if (cart.method_5782()) {
				cart.method_5772();
			}

			if (cart.method_54295() == 0) {
				cart.method_54300(-cart.method_54296());
				cart.method_54299(10);
				cart.method_54297(50.0F);
				cart.field_6037 = true;
			}
		}
	}

	public boolean isFullyCoupled() {
		return isLeadingCoupling() && isConnectedToCoupling();
	}

	public boolean isLeadingCoupling() {
		return couplings.get(true)
			.isPresent();
	}

	public boolean isConnectedToCoupling() {
		return couplings.get(false)
			.isPresent();
	}

	public boolean isCoupledThroughContraption() {
		for (boolean current : Iterate.trueAndFalse)
			if (hasContraptionCoupling(current))
				return true;
		return false;
	}

	public boolean hasContraptionCoupling(boolean current) {
		Optional<CouplingData> optional = couplings.get(current);
		return optional.isPresent() && optional.get().contraption;
	}

	public float getCouplingLength(boolean leading) {
		Optional<CouplingData> optional = couplings.get(leading);
		return optional.map(couplingData -> couplingData.length).orElse(0F);
	}

	public void decouple() {
		couplings.forEachWithContext((opt, main) -> opt.ifPresent(cd -> {
			UUID idOfOther = cd.idOfCart(!main);
			MinecartController otherCart = CapabilityMinecartController.getIfPresent(getWorld(), idOfOther);
			if (otherCart == null)
				return;

			removeConnection(main);
			otherCart.removeConnection(!main);
		}));
	}

	public void removeConnection(boolean main) {
		if (hasContraptionCoupling(main) && getWorld() != null && !getWorld().field_9236) {
			List<class_1297> passengers = cart().method_5685();
			if (!passengers.isEmpty()) {
				class_1297 entity = passengers.getFirst();
				if (entity instanceof AbstractContraptionEntity)
					((AbstractContraptionEntity) entity).disassemble();
			}
		}

		couplings.set(main, Optional.empty());
		needsEntryRefresh |= main;
		sendData();
	}

	public void prepareForCoupling(boolean isLeading) {
		// reverse existing chain if necessary
		if (isLeading && isLeadingCoupling() || !isLeading && isConnectedToCoupling()) {

			List<MinecartController> cartsToFlip = new ArrayList<>();
			MinecartController current = this;
			boolean forward = current.isLeadingCoupling();
			int safetyCount = 1000;

			do {
				if (safetyCount-- <= 0) {
					Create.LOGGER.warn("Infinite loop in coupling iteration");
					return;
				}
				cartsToFlip.add(current);
				current = CouplingHandler.getNextInCouplingChain(getWorld(), current, forward);
			} while (current != null && current != MinecartController.EMPTY);

			for (MinecartController minecartController : cartsToFlip) {
				minecartController.couplings.forEachWithContext((opt, leading) -> opt.ifPresent(cd -> {
					cd.flip();
					if (!cd.contraption)
						return;
					List<class_1297> passengers = minecartController.cart()
						.method_5685();
					if (passengers.isEmpty())
						return;
					class_1297 entity = passengers.getFirst();
					if (!(entity instanceof OrientedContraptionEntity contraption))
						return;
					UUID couplingId = contraption.getCouplingId();
					if (couplingId == cd.mainCartID) {
						contraption.setCouplingId(cd.connectedCartID);
						return;
					}
					if (couplingId == cd.connectedCartID) {
						contraption.setCouplingId(cd.mainCartID);
						return;
					}
				}));
				minecartController.couplings = minecartController.couplings.swap();
				minecartController.needsEntryRefresh = true;
				if (minecartController == this)
					continue;
				minecartController.sendData();
			}
		}
	}

	public void coupleWith(boolean isLeading, UUID coupled, float length, boolean contraption) {
		UUID mainID = isLeading ? cart().method_5667() : coupled;
		UUID connectedID = isLeading ? coupled : cart().method_5667();
		couplings.set(isLeading, Optional.of(new CouplingData(mainID, connectedID, length, contraption)));
		needsEntryRefresh |= isLeading;
		sendData();
	}

	@Nullable
	public UUID getCoupledCart(boolean asMain) {
		Optional<CouplingData> optional = couplings.get(asMain);
		if (optional.isEmpty())
			return null;
		CouplingData couplingData = optional.get();
		return asMain ? couplingData.connectedCartID : couplingData.mainCartID;
	}

	public boolean isStalled() {
		return isStalled(true) || isStalled(false);
	}

	private boolean isStalled(boolean internal) {
		return stallData.get(internal)
			.isPresent();
	}

	public void setStalledExternally(boolean stall) {
		setStalled(stall, false);
	}

	private void setStalled(boolean stall, boolean internal) {
		if (isStalled(internal) == stall)
			return;

		@Nullable class_1688 cart = cart();
		if (stall && cart != null) {
			stallData.set(internal, Optional.of(new StallData(cart)));
			sendData();
			return;
		}

		if (!isStalled(!internal) && cart != null)
			stallData.get(internal)
					.ifPresent(data -> data.release(cart));
		stallData.set(internal, Optional.empty());

		sendData();
	}

	public void sendData() {
		sendData(null);
	}

	public void sendData(@Nullable class_1688 cart) {
		if (cart != null) {
			this.weakRef = new WeakReference<>(cart);
			needsEntryRefresh = true;
		}

		if (getWorld() == null || getWorld().field_9236)
			return;
		CatnipServices.NETWORK.sendToClientsTrackingEntity(this.cart(), new MinecartControllerUpdatePacket(this, getWorld().method_30349()));
	}

	@Override
	public class_2487 serializeNBT(@NotNull class_7225.class_7874 provider) {
		class_2487 compoundNBT = new class_2487();

		stallData.forEachWithContext((opt, internal) -> opt
			.ifPresent(sd -> compoundNBT.method_10566(internal ? "InternalStallData" : "StallData", sd.serialize())));
		couplings.forEachWithContext((opt, main) -> opt
			.ifPresent(cd -> compoundNBT.method_10566(main ? "MainCoupling" : "ConnectedCoupling", cd.serialize())));
		return compoundNBT;
	}

	@Override
	public void deserializeNBT(@NotNull class_7225.class_7874 provider, class_2487 nbt) {
		Optional<StallData> internalSD = Optional.empty();
		Optional<StallData> externalSD = Optional.empty();
		Optional<CouplingData> mainCD = Optional.empty();
		Optional<CouplingData> connectedCD = Optional.empty();

		if (nbt.method_10545("InternalStallData"))
			internalSD = Optional.of(StallData.read(nbt.method_10562("InternalStallData")));
		if (nbt.method_10545("StallData"))
			externalSD = Optional.of(StallData.read(nbt.method_10562("StallData")));
		if (nbt.method_10545("MainCoupling"))
			mainCD = Optional.of(CouplingData.read(nbt.method_10562("MainCoupling")));
		if (nbt.method_10545("ConnectedCoupling"))
			connectedCD = Optional.of(CouplingData.read(nbt.method_10562("ConnectedCoupling")));

		stallData = Couple.create(internalSD, externalSD);
		couplings = Couple.create(mainCD, connectedCD);
		needsEntryRefresh = true;
	}

	public boolean isPresent() {
		return weakRef.get() != null && cart().method_5805();
	}

	public class_1688 cart() {
		return weakRef.get();
	}

	private @Nullable class_1937 getWorld() {
		if (cart() == null)
			return null;
		return cart().method_37908();
	}

	private static class Empty extends MinecartController {
		private Empty() {
			super(null);
		}
	}

	private static class CouplingData {

		private UUID mainCartID;
		private UUID connectedCartID;
		private float length;
		private boolean contraption;

		public CouplingData(UUID mainCartID, UUID connectedCartID, float length, boolean contraption) {
			this.mainCartID = mainCartID;
			this.connectedCartID = connectedCartID;
			this.length = length;
			this.contraption = contraption;
		}

		void flip() {
			UUID swap = mainCartID;
			mainCartID = connectedCartID;
			connectedCartID = swap;
		}

		class_2487 serialize() {
			class_2487 nbt = new class_2487();
			nbt.method_10566("Main", class_2512.method_25929(mainCartID));
			nbt.method_10566("Connected", class_2512.method_25929(connectedCartID));
			nbt.method_10548("Length", length);
			nbt.method_10556("Contraption", contraption);
			return nbt;
		}

		static CouplingData read(class_2487 nbt) {
			UUID mainCartID = class_2512.method_25930(NBTHelper.getINBT(nbt, "Main"));
			UUID connectedCartID = class_2512.method_25930(NBTHelper.getINBT(nbt, "Connected"));
			float length = nbt.method_10583("Length");
			boolean contraption = nbt.method_10577("Contraption");
			return new CouplingData(mainCartID, connectedCartID, length, contraption);
		}

		public UUID idOfCart(boolean main) {
			return main ? mainCartID : connectedCartID;
		}

	}

	private static class StallData {
		class_243 position;
		class_243 motion;
		float yaw, pitch;

		private StallData() {
		}

		StallData(class_1688 entity) {
			position = entity.method_19538();
			motion = entity.method_18798();
			yaw = entity.method_36454();
			pitch = entity.method_36455();
			tick(entity);
		}

		void tick(class_1688 entity) {
//			entity.setPos(position.x, position.y, position.z);
			entity.method_18799(class_243.field_1353);
			entity.method_36456(yaw);
			entity.method_36457(pitch);
		}

		void release(class_1688 entity) {
			entity.method_18799(motion);
		}

		class_2487 serialize() {
			class_2487 nbt = new class_2487();
			nbt.method_10566("Pos", VecHelper.writeNBT(position));
			nbt.method_10566("Motion", VecHelper.writeNBT(motion));
			nbt.method_10548("Yaw", yaw);
			nbt.method_10548("Pitch", pitch);
			return nbt;
		}

		static StallData read(class_2487 nbt) {
			StallData stallData = new StallData();
			stallData.position = VecHelper.readNBT(nbt.method_10554("Pos", class_2520.field_33256));
			stallData.motion = VecHelper.readNBT(nbt.method_10554("Motion", class_2520.field_33256));
			stallData.yaw = nbt.method_10583("Yaw");
			stallData.pitch = nbt.method_10583("Pitch");
			return stallData;
		}
	}
}
