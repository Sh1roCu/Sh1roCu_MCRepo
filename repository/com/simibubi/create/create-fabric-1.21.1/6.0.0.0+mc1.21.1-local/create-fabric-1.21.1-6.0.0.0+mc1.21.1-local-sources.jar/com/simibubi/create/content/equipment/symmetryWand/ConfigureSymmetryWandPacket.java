package com.simibubi.create.content.equipment.symmetryWand;

import com.simibubi.create.AllPackets;
import com.simibubi.create.content.equipment.symmetryWand.mirror.SymmetryMirror;

import io.netty.buffer.ByteBuf;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecs;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import net.minecraft.class_9139;

public record ConfigureSymmetryWandPacket(class_1268 hand, SymmetryMirror mirror) implements ServerboundPacketPayload {
	public static final class_9139<ByteBuf, ConfigureSymmetryWandPacket> STREAM_CODEC = class_9139.method_56435(
			CatnipStreamCodecs.HAND, ConfigureSymmetryWandPacket::hand,
			SymmetryMirror.STREAM_CODEC, ConfigureSymmetryWandPacket::mirror,
			ConfigureSymmetryWandPacket::new
	);

	@Override
	public void handle(class_3222 player) {
		class_1799 stack = player.method_5998(hand);
		if (stack.method_7909() instanceof SymmetryWandItem) {
			SymmetryWandItem.configureSettings(stack, mirror);
		}
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CONFIGURE_SYMMETRY_WAND;
	}
}
