package com.simibubi.create;

import net.minecraft.class_2378;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9428;

public class AllMapDecorationTypes {
	public static final class_6880.class_6883<class_9428> STATION_MAP_DECORATION = class_2378.method_47985(
		class_7923.field_50078,
		Create.asResource("station"),
		new class_9428(Create.asResource("station"), true, -1, false, true)
	);

	public static void register() {
	}
}
