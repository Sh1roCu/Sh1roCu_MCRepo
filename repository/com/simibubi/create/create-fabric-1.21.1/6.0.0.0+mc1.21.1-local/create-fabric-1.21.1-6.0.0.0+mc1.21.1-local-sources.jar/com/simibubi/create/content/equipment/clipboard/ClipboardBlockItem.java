package com.simibubi.create.content.equipment.clipboard;

import javax.annotation.Nonnull;

import com.simibubi.create.AllDataComponents;

import com.simibubi.create.foundation.recipe.ItemCopyingRecipe.SupportsItemCopying;

import net.createmod.catnip.gui.ScreenOpener;
import net.createmod.catnip.platform.CatnipServices;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_9331;

public class ClipboardBlockItem extends class_1747 implements SupportsItemCopying {

	public ClipboardBlockItem(class_2248 pBlock, class_1793 pProperties) {
		super(pBlock, pProperties);
	}

	@Nonnull
	@Override
	public class_1269 method_7884(class_1838 context) {
		class_1657 player = context.method_8036();
		if (player == null)
			return class_1269.field_5811;
		if (player.method_5715())
			return super.method_7884(context);
		return method_7836(context.method_8045(), player, context.method_20287()).method_5467();
	}

	@Override
	protected boolean method_7710(class_2338 pPos, class_1937 pLevel, class_1657 pPlayer, class_1799 pStack,
		class_2680 pState) {
		if (pLevel.method_8608())
			return false;
		if (!(pLevel.method_8321(pPos) instanceof ClipboardBlockEntity cbe))
			return false;
		cbe.dataContainer = pStack.method_46651(1);
		cbe.notifyUpdate();
		return true;
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
		class_1799 heldItem = player.method_5998(hand);
		if (hand == class_1268.field_5810)
			return class_1271.method_22430(heldItem);

		player.method_7357()
			.method_7906(heldItem.method_7909(), 10);
		if (world.field_9236)
			CatnipServices.PLATFORM.executeOnClientOnly(() -> () -> openScreen(player, heldItem));
		heldItem.method_57379(AllDataComponents.CLIPBOARD_TYPE, ClipboardOverrides.ClipboardType.EDITING);

		return class_1271.method_22427(heldItem);
	}

	@Environment(EnvType.CLIENT)
	private void openScreen(class_1657 player, class_1799 stack) {
		if (class_310.method_1551().field_1724 == player)
			ScreenOpener.open(new ClipboardScreen(player.method_31548().field_7545, stack, null));
	}

	public void registerModelOverrides() {
		CatnipServices.PLATFORM.executeOnClientOnly(() -> () -> ClipboardOverrides.registerModelOverridesClient(this));
	}

	@Override
	public class_9331<?> getComponentType() {
		return AllDataComponents.CLIPBOARD_PAGES;
	}

}
