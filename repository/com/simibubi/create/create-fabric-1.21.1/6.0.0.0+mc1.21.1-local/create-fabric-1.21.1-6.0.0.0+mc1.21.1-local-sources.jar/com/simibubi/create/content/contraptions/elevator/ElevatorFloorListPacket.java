package com.simibubi.create.content.contraptions.elevator;

import java.util.List;

import com.simibubi.create.AllPackets;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import net.createmod.catnip.net.base.ClientboundPacketPayload;
import net.createmod.catnip.platform.CatnipServices;
import net.createmod.catnip.net.base.ServerboundPacketPayload;

import net.createmod.catnip.codecs.stream.CatnipStreamCodecBuilders;
import io.netty.buffer.ByteBuf;

import net.createmod.catnip.data.Couple;
import net.createmod.catnip.data.IntAttached;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ElevatorFloorListPacket(int entityId, List<IntAttached<Couple<String>>> floors) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, com.simibubi.create.content.contraptions.elevator.ElevatorFloorListPacket> STREAM_CODEC = class_9139.method_56435(
			class_9135.field_49675, com.simibubi.create.content.contraptions.elevator.ElevatorFloorListPacket::entityId,
			CatnipStreamCodecBuilders.list(IntAttached.streamCodec(Couple.streamCodec(class_9135.field_48554))), com.simibubi.create.content.contraptions.elevator.ElevatorFloorListPacket::floors,
			com.simibubi.create.content.contraptions.elevator.ElevatorFloorListPacket::new
	);

	public ElevatorFloorListPacket(AbstractContraptionEntity entity, List<IntAttached<Couple<String>>> floors) {
		this(entity.method_5628(), floors);
	}

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		class_1297 entityByID = player.field_17892.method_8469(entityId);
		if (!(entityByID instanceof AbstractContraptionEntity ace))
			return;
		if (!(ace.getContraption() instanceof ElevatorContraption ec))
			return;

		ec.namesList = this.floors;
		ec.syncControlDisplays();
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.UPDATE_ELEVATOR_FLOORS;
	}

	public record RequestFloorList(int entityId) implements ServerboundPacketPayload {
		public static final class_9139<ByteBuf, RequestFloorList> STREAM_CODEC = class_9135.field_49675.method_56432(
				RequestFloorList::new, RequestFloorList::entityId
		);

		public RequestFloorList(AbstractContraptionEntity entity) {
			this(entity.method_5628());
		}

		@Override
		public void handle(class_3222 sender) {
			class_1297 entityByID = sender.method_37908()
					.method_8469(entityId);
			if (!(entityByID instanceof AbstractContraptionEntity ace))
				return;
			if (!(ace.getContraption()instanceof ElevatorContraption ec))
				return;
			CatnipServices.NETWORK.sendToClient(sender,
					new ElevatorFloorListPacket(ace, ec.namesList));
		}

		@Override
		public PacketTypeProvider getTypeProvider() {
			return AllPackets.REQUEST_FLOOR_LIST;
		}
	}

}
