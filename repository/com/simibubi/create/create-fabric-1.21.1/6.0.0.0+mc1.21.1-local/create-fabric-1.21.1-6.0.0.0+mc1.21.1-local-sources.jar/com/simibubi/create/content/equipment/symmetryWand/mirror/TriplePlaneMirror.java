package com.simibubi.create.content.equipment.symmetryWand.mirror;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.ImmutableList;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.foundation.utility.CreateLang;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3542;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class TriplePlaneMirror extends SymmetryMirror {

	public TriplePlaneMirror(class_243 pos) {
		super(pos);
		orientationIndex = 0;
	}

	@Override
	public Map<class_2338, class_2680> process(class_2338 position, class_2680 block) {
		Map<class_2338, class_2680> result = new HashMap<>();

		result.put(flipX(position), flipX(block));
		result.put(flipZ(position), flipZ(block));
		result.put(flipX(flipZ(position)), flipX(flipZ(block)));

		result.put(flipD1(position), flipD1(block));
		result.put(flipD1(flipX(position)), flipD1(flipX(block)));
		result.put(flipD1(flipZ(position)), flipD1(flipZ(block)));
		result.put(flipD1(flipX(flipZ(position))), flipD1(flipX(flipZ(block))));

		return result;
	}

	@Override
	public String typeName() {
		return TRIPLE_PLANE;
	}

	@Override
	@Environment(EnvType.CLIENT)
	public PartialModel getModel() {
		return AllPartialModels.SYMMETRY_TRIPLEPLANE;
	}

	@Override
	protected void setOrientation() {
	}

	@Override
	public void setOrientation(int index) {
	}

	@Override
	public class_3542 getOrientation() {
		return CrossPlaneMirror.Align.Y;
	}

	@Override
	public List<class_2561> getAlignToolTips() {
		return ImmutableList.of(CreateLang.translateDirect("orientation.horizontal"));
	}

}
