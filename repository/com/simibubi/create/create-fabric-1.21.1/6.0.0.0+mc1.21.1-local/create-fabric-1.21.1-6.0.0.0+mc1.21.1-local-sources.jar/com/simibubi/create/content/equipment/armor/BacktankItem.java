package com.simibubi.create.content.equipment.armor;

import java.util.Locale;
import java.util.function.Supplier;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_6880;
import com.simibubi.create.AllDataComponents;
import com.simibubi.create.foundation.item.LayeredArmorItem;
import org.jetbrains.annotations.Nullable;

public class BacktankItem extends BaseArmorItem {
	public static final class_1304 SLOT = class_1304.field_6174;
	public static final class_1738.class_8051 TYPE = class_1738.class_8051.field_41935;
	public static final int BAR_COLOR = 0xEFEFEF;

	private final Supplier<BacktankBlockItem> blockItem;

	public BacktankItem(class_6880<class_1741> material, class_1793 properties, class_2960 textureLoc, Supplier<BacktankBlockItem> placeable) {
		super(material, TYPE, properties, textureLoc);
		this.blockItem = placeable;
	}

	@Nullable
	public static BacktankItem getWornBy(class_1297 entity) {
		if (!(entity instanceof class_1309 livingEntity)) {
			return null;
		}
		if (!(livingEntity.method_6118(SLOT).method_7909() instanceof BacktankItem item)) {
			return null;
		}
		return item;
	}

	@Override
	public class_1269 method_7884(class_1838 ctx) {
		return blockItem.get()
			.method_7884(ctx);
	}

	@Override
	public boolean method_7870(class_1799 p_77616_1_) {
		return true;
	}

	@Override
	public boolean method_31567(class_1799 stack) {
		return true;
	}

	@Override
	public int method_31569(class_1799 stack) {
		return Math.round(13.0F * class_3532.method_15363(getRemainingAir(stack) / ((float) BacktankUtil.maxAir(stack)), 0, 1));
	}

	@Override
	public int method_31571(class_1799 stack) {
		return BAR_COLOR;
	}

	public class_2248 getBlock() {
		return blockItem.get().method_7711();
	}

	public static int getRemainingAir(class_1799 stack) {
		return stack.method_57825(AllDataComponents.BACKTANK_AIR, 0);
	}

	public static class BacktankBlockItem extends class_1747 {
		private final Supplier<class_1792> actualItem;

		public BacktankBlockItem(class_2248 block, Supplier<class_1792> actualItem, class_1793 properties) {
			super(block, properties);
			this.actualItem = actualItem;
		}

		@Override
		public String method_7876() {
			return this.method_7869();
		}

		public class_1792 getActualItem() {
			return actualItem.get();
		}
	}

	public static class Layered extends BacktankItem implements LayeredArmorItem {
		public Layered(class_6880<class_1741> material, class_1793 properties, class_2960 textureLoc, Supplier<BacktankBlockItem> placeable) {
			super(material, properties, textureLoc, placeable);
		}

		@Override
		public String getArmorTextureLocation(class_1309 entity, class_1304 slot, class_1799 stack, int layer) {
			return String.format(Locale.ROOT, "%s:textures/models/armor/%s_layer_%d.png", textureLoc.method_12836(), textureLoc.method_12832(), layer);
		}
	}
}
