package com.simibubi.create.content.contraptions.minecart.capability;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllAttachmentTypes;
import com.simibubi.create.AllPackets;

import io.netty.buffer.ByteBuf;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecBuilders;
import net.createmod.catnip.net.base.ClientboundPacketPayload;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record MinecartControllerUpdatePacket(int entityId, @Nullable class_2487 nbt) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, MinecartControllerUpdatePacket> STREAM_CODEC = class_9139.method_56435(
			class_9135.field_49675, MinecartControllerUpdatePacket::entityId,
			CatnipStreamCodecBuilders.nullable(class_9135.field_48556), MinecartControllerUpdatePacket::nbt,
			MinecartControllerUpdatePacket::new
	);

	public MinecartControllerUpdatePacket(MinecartController controller, @NotNull class_7225.class_7874 registries) {
		this(controller.cart().method_5628(), controller.isEmpty() ? null : controller.serializeNBT(registries));
	}

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		class_1297 entityByID = player.field_17892.method_8469(entityId);
		if (entityByID == null)
			return;
		if (entityByID.hasAttached(AllAttachmentTypes.MINECART_CONTROLLER)) {
			if (nbt == null) {
				entityByID.removeAttached(AllAttachmentTypes.MINECART_CONTROLLER);
			} else {
				MinecartController controller = entityByID.getAttached(AllAttachmentTypes.MINECART_CONTROLLER);
				controller.deserializeNBT(player.method_56673(), nbt);
			}
		}
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.MINECART_CONTROLLER;
	}
}
