package com.simibubi.create.content.decoration.copycat;

import java.util.List;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.api.contraption.transformable.TransformableBlockEntity;
import com.simibubi.create.api.schematic.nbt.PartialSafeNBT;
import com.simibubi.create.api.schematic.requirement.SpecialBlockEntityItemRequirement;
import com.simibubi.create.content.contraptions.StructureTransform;
import com.simibubi.create.content.redstone.RoseQuartzLampBlock;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.content.schematics.requirement.ItemRequirement.ItemUseType;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

import net.createmod.catnip.data.Iterate;

import net.fabricmc.fabric.api.blockview.v2.RenderDataBlockEntity;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2533;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_7225;
import net.minecraft.class_9326;
import net.fabricmc.fabric.api.blockview.v2.RenderDataBlockEntity;

import com.simibubi.create.infrastructure.fabric.transfer.item.ItemStackHandler;


public class CopycatBlockEntity extends SmartBlockEntity
	implements SpecialBlockEntityItemRequirement, TransformableBlockEntity, PartialSafeNBT, RenderDataBlockEntity {

	private class_2680 material;
	private class_1799 consumedItem;

	public CopycatBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		material = AllBlocks.COPYCAT_BASE.getDefaultState();
		consumedItem = class_1799.field_8037;
	}

	public class_2680 getMaterial() {
		return material;
	}

	public boolean hasCustomMaterial() {
		return !AllBlocks.COPYCAT_BASE.has(getMaterial());
	}

	public void setMaterial(class_2680 blockState) {
		class_2680 wrapperState = method_11010();

		if (!material.method_27852(blockState.method_26204()))
			for (class_2350 side : Iterate.directions) {
				class_2338 neighbour = field_11867.method_10093(side);
				class_2680 neighbourState = field_11863.method_8320(neighbour);
				if (neighbourState != wrapperState)
					continue;
				if (!(field_11863.method_8321(neighbour)instanceof CopycatBlockEntity cbe))
					continue;
				class_2680 otherMaterial = cbe.getMaterial();
				if (!otherMaterial.method_27852(blockState.method_26204()))
					continue;
				blockState = otherMaterial;
				break;
			}

		material = blockState;
		if (!field_11863.method_8608()) {
			notifyUpdate();
			return;
		}
		redraw();
	}

	public boolean cycleMaterial() {
		if (material.method_28498(class_2533.field_11625) && material.method_28500(class_2533.field_11631)
			.orElse(false))
			setMaterial(material.method_28493(class_2533.field_11625));
		else if (material.method_28498(class_2741.field_12525))
			setMaterial(material.method_28493(class_2741.field_12525));
		else if (material.method_28498(class_2741.field_12481))
			setMaterial(material.method_11657(class_2741.field_12481,
				material.method_11654(class_2741.field_12481)
					.method_10170()));
		else if (material.method_28498(class_2741.field_12496))
			setMaterial(material.method_28493(class_2741.field_12496));
		else if (material.method_28498(class_2741.field_12529))
			setMaterial(material.method_28493(class_2741.field_12529));
		else if (material.method_28498(class_2741.field_12548))
			setMaterial(material.method_28493(class_2741.field_12548));
		else if (material.method_28498(RoseQuartzLampBlock.POWERING))
			setMaterial(material.method_28493(RoseQuartzLampBlock.POWERING));
		else
			return false;

		return true;
	}

	public class_1799 getConsumedItem() {
		return consumedItem;
	}

	public void setConsumedItem(class_1799 stack) {
		consumedItem = stack.method_46651(1);
		method_5431();
	}

	private void redraw() {
		// fabric: no need for requestModelDataUpdate
		if (method_11002()) {
			field_11863.method_8413(method_11016(), method_11010(), method_11010(), 16);
			field_11863.method_8398()
				.method_12130()
				.method_15513(field_11867);
		}
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {}

	@Override
	public ItemRequirement getRequiredItems(class_2680 state) {
		if (consumedItem.method_7960())
			return ItemRequirement.NONE;
		return new ItemRequirement(ItemUseType.CONSUME, consumedItem);
	}

	@Override
	public void transform(class_2586 be, StructureTransform transform) {
		material = transform.apply(material);
		notifyUpdate();
	}

	@Override
	protected void read(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		super.read(tag, registries, clientPacket);

		consumedItem = class_1799.method_57359(registries, tag.method_10562("Item"));

		class_2680 prevMaterial = material;
		if (!tag.method_10545("Material")) {
			consumedItem = class_1799.field_8037;
			return;
		}

		material = class_2512.method_10681(blockHolderGetter(), tag.method_10562("Material"));

		// Validate Material
		if (material != null && !clientPacket) {
			class_2680 blockState = method_11010();
			if (blockState == null)
				return;
			if (!(blockState.method_26204() instanceof CopycatBlock cb))
				return;
			class_2680 acceptedBlockState = cb.getAcceptedBlockState(field_11863, field_11867, consumedItem, null);
			if (acceptedBlockState != null && material.method_27852(acceptedBlockState.method_26204()))
				return;
			consumedItem = class_1799.field_8037;
			material = AllBlocks.COPYCAT_BASE.getDefaultState();
		}

		if (clientPacket && prevMaterial != material)
			redraw();
	}

	@Override
	public void writeSafe(class_2487 tag, class_7225.class_7874 registries) {
		super.writeSafe(tag, registries);

		class_1799 stackWithoutComponents = new class_1799(consumedItem.method_41409(), consumedItem.method_7947(), class_9326.field_49588);

		write(tag, registries, stackWithoutComponents, material);
	}

	@Override
	protected void write(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		super.write(tag, registries, clientPacket);
		write(tag, registries, consumedItem, material);
	}

	protected void write(class_2487 tag, class_7225.class_7874 registries, class_1799 stack, class_2680 material) {
		tag.method_10566("Item", stack.method_57375(registries));
		tag.method_10566("Material", class_2512.method_10686(material));
	}

	@Override
	public class_2680 getRenderData() {
		return material;
	}

}
