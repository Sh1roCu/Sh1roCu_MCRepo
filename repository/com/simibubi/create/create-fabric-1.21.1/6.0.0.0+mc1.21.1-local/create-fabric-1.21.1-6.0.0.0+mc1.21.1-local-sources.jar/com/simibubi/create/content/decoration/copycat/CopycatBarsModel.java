package com.simibubi.create.content.decoration.copycat;

import java.util.function.Supplier;

import net.createmod.catnip.render.SpriteShiftEntry;

import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.model.SpriteFinder;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1723;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.model.SpriteFinder;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;

public class CopycatBarsModel extends CopycatModel {

	public CopycatBarsModel(class_1087 originalModel) {
		super(originalModel);
	}

	@Override
	public boolean method_4708() {
		return false;
	}

	@Override
	protected void emitBlockQuadsInner(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context, class_2680 material, CullFaceRemovalData cullFaceRemovalData, OcclusionData occlusionData) {
		class_1087 model = getModelOf(material);
		class_1058 mainTargetSprite = model.method_4711();

		boolean vertical = state.method_11654(CopycatPanelBlock.FACING)
			.method_10166() == class_2351.field_11052;

		SpriteFinder spriteFinder = SpriteFinder.get(class_310.method_1551().method_1554().method_24153(class_1723.field_21668));

		// This is very cursed
		SpriteAndBool altTargetSpriteHolder = new SpriteAndBool(mainTargetSprite, true);
		context.pushTransform(quad -> {
			if (altTargetSpriteHolder.bool && quad.cullFace() == null && quad.lightFace() == class_2350.field_11036) {
				altTargetSpriteHolder.sprite = spriteFinder.find(quad, 0);
				altTargetSpriteHolder.bool = false;
			}
			return false;
		});
		((FabricBakedModel) model).emitBlockQuads(blockView, material, pos, randomSupplier, context);
		context.popTransform();
		class_1058 altTargetSprite = altTargetSpriteHolder.sprite;

		context.pushTransform(quad -> {
			class_1058 targetSprite;
			class_2350 cullFace = quad.cullFace();
			if (cullFace != null && (vertical || cullFace.method_10166() == class_2351.field_11052)) {
				targetSprite = altTargetSprite;
			} else {
				targetSprite = mainTargetSprite;
			}

			class_1058 original = spriteFinder.find(quad, 0);
			for (int vertex = 0; vertex < 4; vertex++) {
				float u = targetSprite.method_4580(SpriteShiftEntry.getUnInterpolatedU(original, quad.spriteU(vertex, 0)));
				float v = targetSprite.method_4570(SpriteShiftEntry.getUnInterpolatedV(original, quad.spriteV(vertex, 0)));
				quad.sprite(vertex, 0, u, v);
			}
			return true;
		});
		((FabricBakedModel) wrapped).emitBlockQuads(blockView, state, pos, randomSupplier, context);
		context.popTransform();
	}

	private static class SpriteAndBool {
		public class_1058 sprite;
		public boolean bool;

		public SpriteAndBool(class_1058 sprite, boolean bool) {
			this.sprite = sprite;
			this.bool = bool;
		}
	}

}
