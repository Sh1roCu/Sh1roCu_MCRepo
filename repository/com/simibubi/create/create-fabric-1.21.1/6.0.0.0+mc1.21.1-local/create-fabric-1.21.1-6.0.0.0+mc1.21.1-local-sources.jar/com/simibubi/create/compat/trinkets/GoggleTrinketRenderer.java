package com.simibubi.create.compat.trinkets;

import com.simibubi.create.AllItems;

import dev.emi.trinkets.api.SlotReference;
import dev.emi.trinkets.api.TrinketInventory;
import dev.emi.trinkets.api.TrinketsApi;
import dev.emi.trinkets.api.client.TrinketRenderer;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_583;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.class_811;

public class GoggleTrinketRenderer implements TrinketRenderer {
	@Override
	public void render(class_1799 stack, SlotReference slotReference, class_583<? extends class_1309> model,
					   class_4587 matrices, class_4597 multiBufferSource, int light, class_1309 entity,
					   float limbAngle, float limbDistance, float tickDelta, float animationProgress,
					   float headYaw, float headPitch) {
		if (AllItems.GOGGLES.isIn(stack) &&
				model instanceof class_591 playerModel &&
				entity instanceof class_742 player) {

			// Translate and rotate with our head
			matrices.method_22903();
			TrinketRenderer.followBodyRotations(entity, playerModel);
			TrinketRenderer.translateToFace(matrices, playerModel, player, headYaw, headPitch);

			// Translate and scale to our head
			matrices.method_22904(0, 0, 0.3);
			matrices.method_22907(class_7833.field_40718.rotationDegrees(180.0f));
			matrices.method_22905(0.625f, 0.625f, 0.625f);

			if (headOccupied(entity)) {
				matrices.method_22907(class_7833.field_40718.rotationDegrees(180.0f));
				matrices.method_22904(0, -0.25, 0);
			}

			// Render
			class_310 mc = class_310.method_1551();
			mc.method_1480()
					.method_23178(stack, class_811.field_4316, light, class_4608.field_21444, matrices,
							multiBufferSource, mc.field_1687, 0);
			matrices.method_22909();
		}
	}

	public static boolean headOccupied(class_1309 entity) {
		if (!entity.method_6118(class_1304.field_6169).method_7960())
			return true;
		return TrinketsApi.getTrinketComponent(entity)
				.filter(component -> {							 // guaranteed  // may be null
					TrinketInventory inv = component.getInventory().get("head").get("hat");
					return inv != null && !inv.method_5442();
				}).isPresent();
	}
}
