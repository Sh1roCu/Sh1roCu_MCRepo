package com.simibubi.create.api.equipment.goggles;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2586;

/**
 * Implement this interface on the {@link class_2586} that wants to add info to the hovering overlay
 */
public non-sealed interface IHaveHoveringInformation extends IHaveCustomOverlayIcon {
	/**
	 * This method will be called when looking at a {@link class_2586} that implements this interface
	 *
	 * @return {@code true} if the tooltip creation was successful and should be
	 * displayed, or {@code false} if the overlay should not be displayed
	 */
	default boolean addToTooltip(List<class_2561> tooltip, boolean isPlayerSneaking) {
		return false;
	}
}
