package com.simibubi.create.content.equipment.toolbox;

import com.simibubi.create.AllPackets;
import com.simibubi.create.foundation.utility.PersistentDataHelper;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2586;
import net.minecraft.class_3222;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecBuilders;
import io.netty.buffer.ByteBuf;
import net.neoforged.neoforge.items.ItemHandlerHelper;

public record ToolboxEquipPacket(class_2338 toolboxPos, int slot, int hotbarSlot) implements ServerboundPacketPayload {
	public static final class_9139<ByteBuf, ToolboxEquipPacket> STREAM_CODEC = class_9139.method_56436(
			CatnipStreamCodecBuilders.nullable(class_2338.field_48404), ToolboxEquipPacket::toolboxPos,
			class_9135.field_48550, ToolboxEquipPacket::slot,
			class_9135.field_48550, ToolboxEquipPacket::hotbarSlot,
	        ToolboxEquipPacket::new
	);

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.TOOLBOX_EQUIP;
	}

	@Override
	public void handle(class_3222 player) {
		class_1937 world = player.method_37908();

		if (toolboxPos == null) {
			ToolboxHandler.unequip(player, hotbarSlot, false);
			ToolboxHandler.syncData(player);
			return;
		}

		class_2586 blockEntity = world.method_8321(toolboxPos);

		double maxRange = ToolboxHandler.getMaxRange(player);
		if (player.method_5649(toolboxPos.method_10263() + 0.5, toolboxPos.method_10264(), toolboxPos.method_10260() + 0.5) > maxRange
				* maxRange)
			return;
		if (!(blockEntity instanceof ToolboxBlockEntity toolboxBlockEntity))
			return;

		ToolboxHandler.unequip(player, hotbarSlot, false);

		if (slot < 0 || slot >= 8) {
			ToolboxHandler.syncData(player);
			return;
		}

		class_1799 playerStack = player.method_31548().method_5438(hotbarSlot);
		if (!playerStack.method_7960() && !ToolboxInventory.canItemsShareCompartment(playerStack,
				toolboxBlockEntity.inventory.filters.get(slot))) {
			toolboxBlockEntity.inventory.inLimitedMode(inventory -> {
				class_1799 remainder = ItemHandlerHelper.insertItemStacked(inventory, playerStack, false);
				if (!remainder.method_7960())
					remainder = ItemHandlerHelper.insertItemStacked(new ItemReturnInvWrapper(player.method_31548()),
							remainder, false);
				if (remainder.method_7947() != playerStack.method_7947())
					player.method_31548().method_5447(hotbarSlot, remainder);
			});
		}

		class_2487 compound = PersistentDataHelper.get(player)
				.method_10562("CreateToolboxData");
		String key = String.valueOf(hotbarSlot);

		class_2487 data = new class_2487();
		data.method_10569("Slot", slot);
		data.method_10566("Pos", class_2512.method_10692(toolboxPos));
		compound.method_10566(key, data);

		PersistentDataHelper.get(player)
				.method_10566("CreateToolboxData", compound);

		toolboxBlockEntity.connectPlayer(slot, player, hotbarSlot);
		ToolboxHandler.syncData(player);
	}
}
