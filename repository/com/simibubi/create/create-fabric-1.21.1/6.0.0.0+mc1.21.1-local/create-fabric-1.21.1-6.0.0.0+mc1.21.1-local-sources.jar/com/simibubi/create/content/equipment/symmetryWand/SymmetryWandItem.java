package com.simibubi.create.content.equipment.symmetryWand;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import javax.annotation.Nonnull;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllDataComponents;
import com.simibubi.create.AllItems;
import com.simibubi.create.content.contraptions.mounted.CartAssemblerBlock;
import com.simibubi.create.content.equipment.symmetryWand.mirror.CrossPlaneMirror;
import com.simibubi.create.content.equipment.symmetryWand.mirror.EmptyMirror;
import com.simibubi.create.content.equipment.symmetryWand.mirror.PlaneMirror;
import com.simibubi.create.content.equipment.symmetryWand.mirror.SymmetryMirror;
import com.simibubi.create.foundation.utility.BlockHelper;
import com.simibubi.create.infrastructure.config.AllConfigs;

import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.gui.ScreenOpener;
import net.createmod.catnip.platform.CatnipServices;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3726;
import io.github.fabricators_of_create.porting_lib.common.util.EnvExecutor;

public class SymmetryWandItem extends class_1792 {

	public SymmetryWandItem(class_1793 properties) {
		super(properties);
	}

	@Nonnull
	@Override
	public class_1269 method_7884(class_1838 context) {
		class_1657 player = context.method_8036();
		class_2338 pos = context.method_8037();
		if (player == null)
			return class_1269.field_5811;
		player.method_7357()
			.method_7906(this, 5);
		class_1799 wand = player.method_5998(context.method_20287());
		checkComponents(wand);

		// Shift -> open GUI
		if (player.method_5715()) {
			if (player.method_37908().field_9236) {
				CatnipServices.PLATFORM.executeOnClientOnly(() -> () -> {
					openWandGUI(wand, context.method_20287());
				});
				player.method_7357()
					.method_7906(this, 5);
			}
			return class_1269.field_5812;
		}

		if (context.method_8045().field_9236 || context.method_20287() != class_1268.field_5808)
			return class_1269.field_5812;

		pos = pos.method_10093(context.method_8038());
		SymmetryMirror previousElement = wand.method_57824(AllDataComponents.SYMMETRY_WAND);

		// No Shift -> Make / Move Mirror
		wand.method_57379(AllDataComponents.SYMMETRY_WAND_ENABLE, true);
		class_243 pos3d = new class_243(pos.method_10263(), pos.method_10264(), pos.method_10260());
		SymmetryMirror newElement = new PlaneMirror(pos3d);

		if (previousElement instanceof EmptyMirror) {
			newElement.setOrientation(
				(player.method_5735() == class_2350.field_11043 || player.method_5735() == class_2350.field_11035)
					? PlaneMirror.Align.XY.ordinal()
					: PlaneMirror.Align.YZ.ordinal());
			newElement.enable = true;
			wand.method_57379(AllDataComponents.SYMMETRY_WAND_ENABLE, true);
		} else {
			previousElement.setPosition(pos3d);

			if (previousElement instanceof PlaneMirror) {
				previousElement.setOrientation(
					(player.method_5735() == class_2350.field_11043 || player.method_5735() == class_2350.field_11035)
						? PlaneMirror.Align.XY.ordinal()
						: PlaneMirror.Align.YZ.ordinal());
			}

			if (previousElement instanceof CrossPlaneMirror) {
				float rotation = player.method_5791();
				float abs = Math.abs(rotation % 90);
				boolean diagonal = abs > 22 && abs < 45 + 22;
				previousElement
					.setOrientation(diagonal ? CrossPlaneMirror.Align.D.ordinal() : CrossPlaneMirror.Align.Y.ordinal());
			}

			newElement = previousElement;
		}

		wand.method_57379(AllDataComponents.SYMMETRY_WAND, newElement);

		player.method_6122(context.method_20287(), wand);
		return class_1269.field_5812;
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 worldIn, class_1657 playerIn, class_1268 handIn) {
		class_1799 wand = playerIn.method_5998(handIn);
		checkComponents(wand);

		// Shift -> Open GUI
		if (playerIn.method_5715()) {
			if (worldIn.field_9236) {
				CatnipServices.PLATFORM.executeOnClientOnly(() -> () -> {
					openWandGUI(playerIn.method_5998(handIn), handIn);
				});
				playerIn.method_7357()
					.method_7906(this, 5);
			}
			return new class_1271<>(class_1269.field_5812, wand);
		}

		// No Shift -> Clear Mirror
		wand.method_57379(AllDataComponents.SYMMETRY_WAND_ENABLE, false);
		return new class_1271<>(class_1269.field_5812, wand);
	}

	@Environment(EnvType.CLIENT)
	private void openWandGUI(class_1799 wand, class_1268 hand) {
		ScreenOpener.open(new SymmetryWandScreen(wand, hand));
	}

	private static void checkComponents(class_1799 wand) {
		if (!wand.method_57826(AllDataComponents.SYMMETRY_WAND)) {
			wand.method_57379(AllDataComponents.SYMMETRY_WAND, new EmptyMirror(new class_243(0, 0, 0)));
			wand.method_57379(AllDataComponents.SYMMETRY_WAND_ENABLE, false);
		}
	}

	public static boolean isEnabled(class_1799 stack) {
		checkComponents(stack);
		return stack.method_57825(AllDataComponents.SYMMETRY_WAND_ENABLE, false) &&
				!stack.method_57825(AllDataComponents.SYMMETRY_WAND_SIMULATE, false);
	}

	public static SymmetryMirror getMirror(class_1799 stack) {
		checkComponents(stack);
		return stack.method_57824(AllDataComponents.SYMMETRY_WAND);
	}

	public static void configureSettings(class_1799 stack, SymmetryMirror mirror) {
		checkComponents(stack);
		stack.method_57379(AllDataComponents.SYMMETRY_WAND, mirror);
	}

	public static void apply(class_1937 world, class_1799 wand, class_1657 player, class_2338 pos, class_2680 block) {
		checkComponents(wand);
		if (!isEnabled(wand))
			return;
		if (!class_1747.field_8003.containsKey(block.method_26204()))
			return;

		Map<class_2338, class_2680> blockSet = new HashMap<>();
		blockSet.put(pos, block);
		SymmetryMirror symmetry = wand.method_57824(AllDataComponents.SYMMETRY_WAND);

		class_243 mirrorPos = symmetry.getPosition();
		if (mirrorPos.method_1022(class_243.method_24954(pos)) > AllConfigs.server().equipment.maxSymmetryWandRange.get())
			return;
		if (!player.method_7337() && isHoldingBlock(player, block)
			&& BlockHelper.simulateFindAndRemoveInInventory(block, player, 1) == 0) // fabric: simulate since the first block will already be removed
			return;

		symmetry.process(blockSet);
		class_2338 to = class_2338.method_49638(mirrorPos);
		List<class_2338> targets = new ArrayList<>();
		targets.add(pos);

		for (class_2338 position : blockSet.keySet()) {
			if (position.equals(pos))
				continue;

			if (world.method_8628(block, position, class_3726.method_16195(player))) {
				class_2680 blockState = blockSet.get(position);
				for (class_2350 face : Iterate.directions)
					blockState = blockState.method_26191(face, world.method_8320(position.method_10093(face)), world,
						position, position.method_10093(face));

				if (player.method_7337()) {
					world.method_8501(position, blockState);
					targets.add(position);
					continue;
				}

				class_2680 toReplace = world.method_8320(position);
				if (!toReplace.method_45474())
					continue;
				if (toReplace.method_26214(world, position) == -1)
					continue;

				if (AllBlocks.CART_ASSEMBLER.has(blockState)) {
					class_2680 railBlock = CartAssemblerBlock.getRailBlock(blockState);
					if (BlockHelper.findAndRemoveInInventory(railBlock, player, 1) == 0)
						continue;
					if (BlockHelper.findAndRemoveInInventory(blockState, player, 1) == 0)
						blockState = railBlock;
				} else {
					if (BlockHelper.findAndRemoveInInventory(blockState, player, 1) == 0)
						continue;
				}

//				BlockSnapshot blocksnapshot = BlockSnapshot.create(world.dimension(), world, position);
				class_2680 cachedState = world.method_8320(position);
				class_3610 ifluidstate = world.method_8316(position);
				world.method_8652(position, ifluidstate.method_15759(), class_2248.field_31031);
				world.method_8501(position, blockState);

					wand.method_57379(AllDataComponents.SYMMETRY_WAND_SIMULATE, true);
					boolean placeInterrupted = false;
					wand.method_57379(AllDataComponents.SYMMETRY_WAND_SIMULATE, false);

				if (placeInterrupted) {
					world.method_8501(position, cachedState);
					continue;
				}
				targets.add(position);
			}
		}

		CatnipServices.NETWORK.sendToClientsTrackingAndSelf(player, new SymmetryEffectPacket(to, targets));
	}

	private static boolean isHoldingBlock(class_1657 player, class_2680 block) {
		class_1799 itemBlock = BlockHelper.getRequiredItem(block);
		return player.method_24518(itemBlock.method_7909());
	}

	public static void remove(class_1937 world, class_1799 wand, class_1657 player, class_2338 pos, class_2680 ogBlock) {
		class_2680 air = class_2246.field_10124.method_9564();
		checkComponents(wand);
		if (!isEnabled(wand))
			return;

		Map<class_2338, class_2680> blockSet = new HashMap<>();
		blockSet.put(pos, air);
		SymmetryMirror symmetry = wand.method_57824(AllDataComponents.SYMMETRY_WAND);

		class_243 mirrorPos = symmetry.getPosition();
		if (mirrorPos.method_1022(class_243.method_24954(pos)) > AllConfigs.server().equipment.maxSymmetryWandRange.get())
			return;

		symmetry.process(blockSet);

		class_2338 to = class_2338.method_49638(mirrorPos);
		List<class_2338> targets = new ArrayList<>();

		targets.add(pos);
		for (class_2338 position : blockSet.keySet()) {
			if (!player.method_7337() && ogBlock.method_26204() != world.method_8320(position)
					.method_26204())
				continue;
			if (position.equals(pos))
				continue;

			class_2680 blockstate = world.method_8320(position);
			class_2586 be = blockstate.method_31709() ? world.method_8321(position) : null;
			if (!blockstate.method_26215()) {
				if (handlePreEvent(world, player, position, blockstate, be))
					continue;
				targets.add(position);
				world.method_20290(2001, position, class_2248.method_9507(blockstate));
				world.method_8652(position, air, 3);

				if (!player.method_7337()) {
					if (!player.method_6047()
						.method_7960())
						player.method_6047()
							.method_7952(world, blockstate, position, player);
					class_2586 blockEntity = blockstate.method_31709() ? world.method_8321(position) : null;
					class_2248.method_9511(blockstate, world, pos, blockEntity, player, player.method_6047()); // Add fortune, silk touch and other loot modifiers
				}
				handlePostEvent(world, player, position, blockstate, be);
			}
		}

		CatnipServices.NETWORK.sendToClientsTrackingAndSelf(player, new SymmetryEffectPacket(to, targets));
	}

	/**
	 * Handling firing events before the wand changes blocks.
	 * @return true if canceled
	 */
	public static boolean handlePreEvent(class_1937 world, class_1657 player, class_2338 pos, class_2680 state, class_2586 be) {
		if (PlayerBlockBreakEvents.BEFORE.invoker().beforeBlockBreak(world, player, pos, state, be)) {
			return false;
		}
		PlayerBlockBreakEvents.CANCELED.invoker().onBlockBreakCanceled(world, player, pos, state, be);
		return true;
	}

	public static void handlePostEvent(class_1937 world, class_1657 player, class_2338 pos, class_2680 state, class_2586 be) {
		PlayerBlockBreakEvents.AFTER.invoker().afterBlockBreak(world, player, pos, state, be);
	}

	public static boolean presentInHotbar(class_1657 player) {
		class_1661 inv = player.method_31548();
		for (int i = 0; i < class_1661.method_7368(); i++)
			if (AllItems.WAND_OF_SYMMETRY.isIn(inv.method_5438(i)))
				return true;
		return false;
	}

}
