package com.simibubi.create.content.equipment.armor;

import com.simibubi.create.AllItems;
import com.simibubi.create.Create;
import net.minecraft.class_1007;
import net.minecraft.class_1304;
import net.minecraft.class_1306;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_742;
import net.minecraft.class_765;

public class NetheriteBacktankFirstPersonRenderer {

	private static final class_2960 BACKTANK_ARMOR_LOCATION =
		Create.asResource("textures/models/armor/netherite_diving_arm.png");

	private static boolean rendererActive = false;

	public static void clientTick() {
		class_310 mc = class_310.method_1551();
		rendererActive =
			mc.field_1724 != null && AllItems.NETHERITE_BACKTANK.isIn(mc.field_1724.method_6118(class_1304.field_6174));
	}

	public static boolean onRenderPlayerHand(class_4587 poseStack, class_4597 buffer, int packedLight, class_742 player, class_1306 arm) {
		if (!rendererActive)
			return false;

		class_310 mc = class_310.method_1551();
		if (!(mc.method_1561()
			.method_3953(player) instanceof class_1007 pr))
			return false;

		class_591<class_742> model = pr.method_4038();
		model.field_3447 = 0.0F;
		model.field_3400 = false;
		model.field_3396 = 0.0F;
		model.method_17087(player, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
		class_630 armPart = arm == class_1306.field_6182 ? model.field_3484 : model.field_3486;
		armPart.field_3654 = 0.0F;
		armPart.method_22698(poseStack, buffer.getBuffer(class_1921.method_23572(BACKTANK_ARMOR_LOCATION)),
			class_765.field_32767, class_4608.field_21444);
		return true;
	}

}
