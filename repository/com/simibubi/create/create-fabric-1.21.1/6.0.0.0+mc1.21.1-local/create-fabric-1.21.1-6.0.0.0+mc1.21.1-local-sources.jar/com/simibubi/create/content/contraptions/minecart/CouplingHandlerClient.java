package com.simibubi.create.content.contraptions.minecart;

import org.joml.Vector3f;

import com.simibubi.create.AllItems;
import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1657;
import net.minecraft.class_1688;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.createmod.catnip.math.VecHelper;

public class CouplingHandlerClient {

	static class_1688 selectedCart;
	static class_5819 r = class_5819.method_43047();

	public static void tick() {
		if (selectedCart == null)
			return;
		spawnSelectionParticles(selectedCart.method_5829(), false);
		class_746 player = class_310.method_1551().field_1724;
		class_1799 heldItemMainhand = player.method_6047();
		class_1799 heldItemOffhand = player.method_6079();
		if (AllItems.MINECART_COUPLING.isIn(heldItemMainhand) || AllItems.MINECART_COUPLING.isIn(heldItemOffhand))
			return;
		selectedCart = null;
	}

	static void onCartClicked(class_1657 player, class_1688 entity) {
		if (class_310.method_1551().field_1724 != player)
			return;
		if (selectedCart == null || selectedCart == entity) {
			selectedCart = entity;
			spawnSelectionParticles(selectedCart.method_5829(), true);
			return;
		}
		spawnSelectionParticles(entity.method_5829(), true);
		CatnipServices.NETWORK.sendToServer(new CouplingCreationPacket(selectedCart, entity));
		selectedCart = null;
	}

	static void sneakClick() {
		selectedCart = null;
	}

	private static void spawnSelectionParticles(class_238 AABB, boolean highlight) {
		class_638 world = class_310.method_1551().field_1687;
		class_243 center = AABB.method_1005();
		int amount = highlight ? 100 : 2;
		class_2394 particleData =
			highlight ? class_2398.field_11207 : new class_2390(new Vector3f(1, 1, 1), 1);
		for (int i = 0; i < amount; i++) {
			class_243 v = VecHelper.offsetRandomly(class_243.field_1353, r, 1);
			double yOffset = v.field_1351;
			v = v.method_18805(1, 0, 1)
				.method_1029()
				.method_1031(0, yOffset / 8f, 0)
				.method_1019(center);
			world.method_8406(particleData, v.field_1352, v.field_1351, v.field_1350, 0, 0, 0);
		}
	}

}
