package com.simibubi.create.content.contraptions.bearing;

import org.joml.Quaternionf;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.contraptions.render.ActorVisual;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityVisual;
import com.simibubi.create.content.kinetics.base.RotatingInstance;
import com.simibubi.create.foundation.render.AllInstanceTypes;
import com.simibubi.create.foundation.virtualWorld.VirtualRenderWorld;

import dev.engine_room.flywheel.api.visualization.VisualizationContext;
import dev.engine_room.flywheel.lib.instance.InstanceTypes;
import dev.engine_room.flywheel.lib.instance.OrientedInstance;
import dev.engine_room.flywheel.lib.model.Models;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_7833;

public class StabilizedBearingVisual extends ActorVisual {

	final OrientedInstance topInstance;
	final RotatingInstance shaft;

	final class_2350 facing;
	final class_7833 rotationAxis;
	final Quaternionf blockOrientation;

	public StabilizedBearingVisual(VisualizationContext visualizationContext, VirtualRenderWorld simulationWorld, MovementContext movementContext) {
		super(visualizationContext, simulationWorld, movementContext);

		class_2680 blockState = movementContext.state;

		facing = blockState.method_11654(class_2741.field_12525);
		rotationAxis = class_7833.method_46356(class_2350.method_10156(class_2350.class_2352.field_11056, facing.method_10166()).method_23955());

		blockOrientation = BearingVisual.getBlockStateOrientation(facing);

        topInstance = instancerProvider.instancer(InstanceTypes.ORIENTED, Models.partial(AllPartialModels.BEARING_TOP))
				.createInstance();

		int blockLight = localBlockLight();
		topInstance.position(movementContext.localPos)
				.rotation(blockOrientation)
				.light(blockLight, 0)
				.setChanged();

		shaft = instancerProvider.instancer(AllInstanceTypes.ROTATING, Models.partial(AllPartialModels.SHAFT_HALF))
				.createInstance();

		// not rotating so no need to set speed.
		var axis = KineticBlockEntityVisual.rotationAxis(blockState);
		shaft.setRotationAxis(axis)
			.setRotationOffset(KineticBlockEntityVisual.rotationOffset(blockState, axis, movementContext.localPos))
			.setPosition(movementContext.localPos)
			.rotateToFace(class_2350.field_11035, blockState.method_11654(class_2741.field_12525).method_10153())
			.light(blockLight, 0)
			.setChanged();
	}

	@Override
	public void beginFrame() {
		float counterRotationAngle = StabilizedBearingMovementBehaviour.getCounterRotationAngle(context, facing, AnimationTickHolder.getPartialTicks());

		Quaternionf rotation = rotationAxis.rotationDegrees(counterRotationAngle);

		rotation.mul(blockOrientation);

		topInstance.rotation(rotation)
			.setChanged();
	}

	@Override
	protected void _delete() {
		topInstance.delete();
		shaft.delete();
	}
}
