package com.simibubi.create.content.contraptions.minecart;

import com.simibubi.create.AllPackets;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_1688;
import net.minecraft.class_3222;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.netty.buffer.ByteBuf;

public record CouplingCreationPacket(int id1, int id2) implements ServerboundPacketPayload {
	public static final class_9139<ByteBuf, CouplingCreationPacket> STREAM_CODEC = class_9139.method_56435(
			class_9135.field_48550, CouplingCreationPacket::id1,
			class_9135.field_48550, CouplingCreationPacket::id2,
			CouplingCreationPacket::new
	);

	public CouplingCreationPacket(class_1688 cart1, class_1688 cart2) {
		this(cart1.method_5628(), cart2.method_5628());
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.MINECART_COUPLING_CREATION;
	}

	@Override
	public void handle(class_3222 player) {
		CouplingHandler.tryToCoupleCarts(player, player.method_37908(), id1, id2);
	}
}
