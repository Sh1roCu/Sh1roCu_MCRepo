package com.simibubi.create.compat.archEx;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.simibubi.create.Create;
import com.simibubi.create.content.decoration.palettes.AllPaletteStoneTypes;
import com.simibubi.create.content.decoration.palettes.PaletteBlockPattern;

import net.createmod.catnip.lang.Lang;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_7923;

public record ArchExGroup(String name, class_2248 base, Textures textures, Recipes recipes, class_3620 color, BlockType[] types) {

	public static Builder builder() {
		return new Builder();
	}

	public JsonObject toJson() {
		JsonObject json = new JsonObject();
		json.addProperty("name", name);
		class_2960 blockId = class_7923.field_41175.method_10221(base);
		json.addProperty("base_block", blockId.toString());
		json.addProperty("textures", textures.typeOrId());
		json.addProperty("recipes", recipes.name);
		String colorName = MapColorSerialization.getArchExName(color);
		json.addProperty("map_color", colorName);
		JsonArray typesArray = new JsonArray();
		for (BlockType type : types) {
			typesArray.add(type.name);
		}
		json.add("types_to_generate", typesArray);
		return json;
	}

	public static class Builder {
		private String name;
		private class_2248 base;
		private Textures textures;
		private Recipes recipes;
		private class_3620 color;
		private final List<BlockType> types = new ArrayList<>();

		public Builder fromStoneTypeAndPattern(AllPaletteStoneTypes type, PaletteBlockPattern pattern) {
			String variant = Lang.asId(type.name());
			String baseBlockName = pattern.createName(variant);
			class_2248 baseBlock = class_7923.field_41175.method_10223(Create.asResource(baseBlockName));
			if (baseBlock == class_2246.field_10124)
				throw new IllegalStateException("Unknown block: " + baseBlockName);

			class_2960 texture = PaletteBlockPattern.toLocation(variant, pattern.getTexture(0));
			class_3620 color = baseBlock.method_26403();

			return this.named(baseBlockName)
					.basedOn(baseBlock)
					.textured(Textures.ofTexture(texture))
					.withRecipes(Recipes.STONECUTTING_AND_CRAFTING)
					.colored(color)
					.withTypes(BlockType.FOR_STONES);
		}

		public Builder named(String name) {
			this.name = name;
			return this;
		}

		public Builder basedOn(class_2248 block) {
			this.base = block;
			return this;
		}

		public Builder textured(Textures textures) {
			this.textures = textures;
			return this;
		}

		public Builder withRecipes(Recipes recipes) {
			this.recipes = recipes;
			return this;
		}

		public Builder colored(class_3620 color) {
			this.color = color;
			return this;
		}

		private Builder withTypes(BlockType... types) {
			Collections.addAll(this.types, types);
			return this;
		}

		public ArchExGroup build() {
			if (types.isEmpty())
				throw new IllegalArgumentException("types not set");
			return new ArchExGroup(
					Objects.requireNonNull(name, "name not set"),
					Objects.requireNonNull(base, "base not set"),
					Objects.requireNonNull(textures, "textures not set"),
					Objects.requireNonNull(recipes, "recipes not set"),
					Objects.requireNonNull(color, "color not set"),
					types.toArray(BlockType[]::new)
			);
		}
	}
}
