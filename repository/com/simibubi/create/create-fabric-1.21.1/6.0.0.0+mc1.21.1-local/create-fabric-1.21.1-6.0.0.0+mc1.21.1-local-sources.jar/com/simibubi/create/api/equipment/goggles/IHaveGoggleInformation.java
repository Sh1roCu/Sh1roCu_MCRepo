package com.simibubi.create.api.equipment.goggles;

import java.util.List;

import com.simibubi.create.foundation.utility.CreateLang;
import com.simibubi.create.infrastructure.config.AllConfigs;

import com.simibubi.create.infrastructure.fabric.util.FluidUnit;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import com.simibubi.create.infrastructure.fabric.transfer.fluid.FluidStack;

/**
 * Implement this interface on the {@link class_2586} that wants to add info to the goggle overlay
 */
public non-sealed interface IHaveGoggleInformation extends IHaveCustomOverlayIcon {
	/**
	 * This method will be called when looking at a {@link class_2586} that implements this interface
	 *
	 * @return {@code true} if the tooltip creation was successful and should be
	 * displayed, or {@code false} if the overlay should not be displayed
	 */
	default boolean addToGoggleTooltip(List<class_2561> tooltip, boolean isPlayerSneaking) {
		return false;
	}

	default boolean containedFluidTooltip(List<class_2561> tooltip, boolean isPlayerSneaking, Storage<FluidVariant> handler) {
		if (handler == null)
			return false;
		FluidUnit unit = AllConfigs.client().fluidUnitType.get();
		CreateLang.translate("gui.goggles.fluid_container")
				.forGoggles(tooltip);

		boolean isEmpty = true;
		int tanks = 0;
		long firstCapacity = -1;

		for (StorageView<FluidVariant> view : handler) {
			if (tanks == 0)
				firstCapacity = view.getCapacity();
			tanks++;
			FluidStack fluidStack = new FluidStack(view);
			if (fluidStack.isEmpty())
				continue;

			CreateLang.fluidName(fluidStack)
					.style(class_124.field_1080)
					.forGoggles(tooltip, 1);

			CreateLang.builder()
				.add(CreateLang.number(unit.convert(fluidStack.getAmount()))
					.add(unit.name)
					.style(class_124.field_1065))
				.text(class_124.field_1080, " / ")
				.add(CreateLang.number(unit.convert(view.getCapacity()))
					.add(unit.name)
					.style(class_124.field_1063))
				.forGoggles(tooltip, 1);

			isEmpty = false;
		}

		if (tanks > 1) {
			if (isEmpty)
				tooltip.remove(tooltip.size() - 1);
			return true;
		}

		if (!isEmpty)
			return true;

		CreateLang.translate("gui.goggles.fluid_container.capacity")
			.add(CreateLang.number(unit.convert(firstCapacity))
				.add(unit.name)
				.style(class_124.field_1065))
			.style(class_124.field_1080)
			.forGoggles(tooltip, 1);

		return true;
	}

}
