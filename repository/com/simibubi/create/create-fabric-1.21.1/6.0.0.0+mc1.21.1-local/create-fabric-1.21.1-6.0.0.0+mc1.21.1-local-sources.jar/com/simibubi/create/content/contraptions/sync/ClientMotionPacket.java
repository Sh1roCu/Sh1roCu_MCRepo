package com.simibubi.create.content.contraptions.sync;

import com.simibubi.create.AllPackets;
import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecs;
import io.netty.buffer.ByteBuf;

public record ClientMotionPacket(class_243 motion, boolean onGround, float limbSwing) implements ServerboundPacketPayload {
	public static final class_9139<ByteBuf, com.simibubi.create.content.contraptions.sync.ClientMotionPacket> STREAM_CODEC = class_9139.method_56436(
			CatnipStreamCodecs.VEC3, com.simibubi.create.content.contraptions.sync.ClientMotionPacket::motion,
			class_9135.field_48547, com.simibubi.create.content.contraptions.sync.ClientMotionPacket::onGround,
			class_9135.field_48552, com.simibubi.create.content.contraptions.sync.ClientMotionPacket::limbSwing,
	        com.simibubi.create.content.contraptions.sync.ClientMotionPacket::new
	);

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CLIENT_MOTION;
	}

	@Override
	public void handle(class_3222 sender) {
		if (sender == null)
			return;
		sender.method_18799(motion);
		sender.method_24830(onGround);
		if (onGround) {
			sender.method_5747(sender.field_6017, 1, sender.method_48923().method_48827());
			sender.field_6017 = 0;
			sender.field_13987.field_14138 = 0;
			sender.field_13987.field_14137 = 0;
		}
		CatnipServices.NETWORK.sendToClientsTrackingEntity(sender,
				new LimbSwingUpdatePacket(sender.method_5628(), sender.method_19538(), limbSwing));
	}
}
