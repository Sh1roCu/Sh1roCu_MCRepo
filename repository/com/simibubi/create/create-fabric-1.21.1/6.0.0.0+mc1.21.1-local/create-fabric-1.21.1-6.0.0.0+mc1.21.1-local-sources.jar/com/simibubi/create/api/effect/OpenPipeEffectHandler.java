package com.simibubi.create.api.effect;

import com.simibubi.create.api.registry.SimpleRegistry;
import com.simibubi.create.infrastructure.fabric.transfer.fluid.FluidStack;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_3611;

/**
 * Interface for custom behavior for fluids spilling out of open pipes. Examples:
 * <ul>
 *     <li>Potions: applying potion effects</li>
 *     <li>Milk: clearing effects</li>
 *     <li>Water: extinguishing fire</li>
 * </ul>
 */
@FunctionalInterface
public interface OpenPipeEffectHandler {
	SimpleRegistry<class_3611, OpenPipeEffectHandler> REGISTRY = SimpleRegistry.create();

	/**
	 * @param area the area to apply effects in
	 * @param fluid the fluid in the pipe. Do not modify, it will do nothing
	 */
	void apply(class_1937 level, class_238 area, FluidStack fluid);
}
