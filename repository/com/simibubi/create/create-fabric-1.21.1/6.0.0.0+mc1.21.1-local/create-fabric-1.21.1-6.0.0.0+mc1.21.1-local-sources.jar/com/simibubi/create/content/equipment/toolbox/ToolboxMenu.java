package com.simibubi.create.content.equipment.toolbox;

import static com.simibubi.create.content.equipment.toolbox.ToolboxInventory.STACKS_PER_COMPARTMENT;

import com.simibubi.create.AllMenuTypes;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.animatedContainer.AnimatedContainerBehaviour;
import com.simibubi.create.foundation.gui.menu.MenuBase;
import com.simibubi.create.infrastructure.fabric.transfer.item.SlotItemHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_3917;
import net.minecraft.class_638;
import net.minecraft.class_9129;

public class ToolboxMenu extends MenuBase<ToolboxBlockEntity> {

	public ToolboxMenu(class_3917<?> type, int id, class_1661 inv, class_9129 extraData) {
		super(type, id, inv, extraData);
	}

	public ToolboxMenu(class_3917<?> type, int id, class_1661 inv, ToolboxBlockEntity be) {
		super(type, id, inv, be);
		BlockEntityBehaviour.get(be, AnimatedContainerBehaviour.TYPE)
			.startOpen(player);
	}

	public static ToolboxMenu create(int id, class_1661 inv, ToolboxBlockEntity be) {
		return new ToolboxMenu(AllMenuTypes.TOOLBOX.get(), id, inv, be);
	}

	@Override
	protected ToolboxBlockEntity createOnClient(class_9129 extraData) {
		class_2338 readBlockPos = extraData.method_10811();
		class_2487 readNbt = extraData.method_10798();

		class_638 world = class_310.method_1551().field_1687;
		class_2586 blockEntity = world.method_8321(readBlockPos);
		if (blockEntity instanceof ToolboxBlockEntity toolbox) {
			toolbox.readClient(readNbt, extraData.method_56349());
			return toolbox;
		}

		return null;
	}

	@Override
	public class_1799 method_7601(class_1657 player, int index) {
		class_1735 clickedSlot = method_7611(index);
		if (!clickedSlot.method_7681())
			return class_1799.field_8037;

		class_1799 stack = clickedSlot.method_7677();
		int size = contentHolder.inventory.getSlotCount();
		boolean success = false;
		if (index < size) {
			success = !method_7616(stack, size, field_7761.size(), false);
			contentHolder.inventory.onContentsChanged(index);
		} else {
			success = !method_7616(stack, 0, size - 1, false);
		}

		return success ? class_1799.field_8037 : stack;
	}

	@Override
	protected void initAndReadInventory(ToolboxBlockEntity contentHolder) {

	}

	@Override
	public void method_7593(int index, int flags, class_1713 type, class_1657 player) {
		int size = contentHolder.inventory.getSlotCount();

		if (index >= 0 && index < size) {
			class_1799 itemInClickedSlot = method_7611(index).method_7677();
			class_1799 carried = method_34255();

			if (type == class_1713.field_7790 && !carried.method_7960() && !itemInClickedSlot.method_7960()
				&& ToolboxInventory.canItemsShareCompartment(itemInClickedSlot, carried)) {
				int subIndex = index % STACKS_PER_COMPARTMENT;
				if (subIndex != STACKS_PER_COMPARTMENT - 1) {
					method_7593(index - subIndex + STACKS_PER_COMPARTMENT - 1, flags, type, player);
					return;
				}
			}

			if (type == class_1713.field_7790 && carried.method_7960() && itemInClickedSlot.method_7960())
				if (!player.method_37908().field_9236) {
					contentHolder.inventory.filters.set(index / STACKS_PER_COMPARTMENT, class_1799.field_8037);
					contentHolder.sendData();
				}

		}
		super.method_7593(index, flags, type, player);
	}

	@Override
	public boolean method_7615(class_1735 slot) {
		return slot.field_7874 > contentHolder.inventory.getSlotCount() && super.method_7615(slot);
	}

	public class_1799 getFilter(int compartment) {
		return contentHolder.inventory.filters.get(compartment);
	}

	public int totalCountInCompartment(int compartment) {
		int count = 0;
		int baseSlot = compartment * STACKS_PER_COMPARTMENT;
		for (int i = 0; i < STACKS_PER_COMPARTMENT; i++)
			count += method_7611(baseSlot + i).method_7677()
				.method_7947();
		return count;
	}

	public boolean renderPass;

	@Override
	protected void addSlots() {
		ToolboxInventory inventory = contentHolder.inventory;

		int x = 79;
		int y = 37;

		int[] xOffsets = {x, x + 33, x + 66, x + 66 + 6, x + 66, x + 33, x, x - 6};
		int[] yOffsets = {y, y - 6, y, y + 33, y + 66, y + 66 + 6, y + 66, y + 33};

		for (int compartment = 0; compartment < 8; compartment++) {
			int baseIndex = compartment * STACKS_PER_COMPARTMENT;

			// Representative Slots
			method_7621(new ToolboxSlot(this, inventory, baseIndex, xOffsets[compartment], yOffsets[compartment], true));

			// Hidden Slots
			for (int i = 1; i < STACKS_PER_COMPARTMENT; i++)
				method_7621(new ToolboxSlot(this, inventory, baseIndex + i, -10000, -10000, false));
		}

		addPlayerSlots(8, 165);
	}

	@Override
	protected void saveData(ToolboxBlockEntity contentHolder) {

	}

	@Override
	public void method_7595(class_1657 playerIn) {
		super.method_7595(playerIn);
		if (!playerIn.method_37908().field_9236)
			BlockEntityBehaviour.get(contentHolder, AnimatedContainerBehaviour.TYPE)
				.stopOpen(playerIn);
	}

}
