package com.simibubi.create.content.contraptions.elevator;

import com.simibubi.create.AllPackets;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.netty.buffer.ByteBuf;

public record ElevatorTargetFloorPacket(int entityId, int targetY) implements ServerboundPacketPayload {
	public static final class_9139<ByteBuf, ElevatorTargetFloorPacket> STREAM_CODEC = class_9139.method_56435(
			class_9135.field_49675, ElevatorTargetFloorPacket::entityId,
			class_9135.field_49675, ElevatorTargetFloorPacket::targetY,
	        ElevatorTargetFloorPacket::new
	);

	public ElevatorTargetFloorPacket(AbstractContraptionEntity entity, int targetY) {
		this(entity.method_5628(), targetY);
	}

	@Override
	public void handle(class_3222 sender) {
		class_1297 entityByID = sender.method_51469()
				.method_8469(entityId);
		if (!(entityByID instanceof AbstractContraptionEntity ace))
			return;
		if (!(ace.getContraption() instanceof ElevatorContraption ec))
			return;
		if (ace.method_5858(sender) > 50 * 50)
			return;

		class_1937 level = sender.method_37908();
		ElevatorColumn elevatorColumn = ElevatorColumn.get(level, ec.getGlobalColumn());
		if (!elevatorColumn.contacts.contains(targetY))
			return;
		if (ec.isTargetUnreachable(targetY))
			return;

		class_2338 pos = elevatorColumn.contactAt(targetY);
		class_2680 blockState = level.method_8320(pos);
		if (!(blockState.method_26204() instanceof ElevatorContactBlock ecb))
			return;

		ecb.callToContactAndUpdate(elevatorColumn, blockState, level, pos, false);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.ELEVATOR_SET_FLOOR;
	}
}
