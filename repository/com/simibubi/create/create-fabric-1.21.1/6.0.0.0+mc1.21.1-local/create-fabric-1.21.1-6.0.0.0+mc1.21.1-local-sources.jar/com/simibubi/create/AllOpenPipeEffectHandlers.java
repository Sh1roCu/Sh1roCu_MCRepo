package com.simibubi.create;

import com.simibubi.create.api.effect.OpenPipeEffectHandler;
import com.simibubi.create.api.registry.SimpleRegistry;
import com.simibubi.create.impl.effect.LavaEffectHandler;
import com.simibubi.create.impl.effect.MilkEffectHandler;
import com.simibubi.create.impl.effect.PotionEffectHandler;
import com.simibubi.create.impl.effect.TeaEffectHandler;
import com.simibubi.create.impl.effect.WaterEffectHandler;
import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.minecraft.class_3486;

public class AllOpenPipeEffectHandlers {
	public static void registerDefaults() {
		OpenPipeEffectHandler.REGISTRY.registerProvider(SimpleRegistry.Provider.forFluidTag(class_3486.field_15517, new WaterEffectHandler()));
		OpenPipeEffectHandler.REGISTRY.registerProvider(SimpleRegistry.Provider.forFluidTag(class_3486.field_15518, new LavaEffectHandler()));
		OpenPipeEffectHandler.REGISTRY.registerProvider(SimpleRegistry.Provider.forFluidTag(Tags.Fluids.MILK, new MilkEffectHandler()));
		OpenPipeEffectHandler.REGISTRY.register(AllFluids.POTION.getSource(), new PotionEffectHandler());
		OpenPipeEffectHandler.REGISTRY.register(AllFluids.TEA.getSource(), new TeaEffectHandler());
	}
}
