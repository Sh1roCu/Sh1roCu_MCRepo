package com.simibubi.create.content.contraptions.wrench;

import com.simibubi.create.AllItems;
import com.simibubi.create.AllKeys;

import net.createmod.catnip.gui.ScreenOpener;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;

public class RadialWrenchHandler {

	public static int COOLDOWN = 0;

	public static void clientTick() {
		if (COOLDOWN > 0 && !AllKeys.ROTATE_MENU.isPressed())
			COOLDOWN--;
	}

	public static void onKeyInput(int key, boolean pressed) {
		if (!pressed)
			return;

		if (key != AllKeys.ROTATE_MENU.getBoundCode())
			return;

		if (COOLDOWN > 0)
			return;

		class_310 mc = class_310.method_1551();
		if (mc.field_1761 == null || mc.field_1761.method_2920() == class_1934.field_9219)
			return;

		class_746 player = mc.field_1724;
		if (player == null)
			return;

		class_1937 level = player.method_37908();

		class_1799 heldItem = player.method_6047();
		if (heldItem.method_7909() != AllItems.WRENCH.get())
			return;

		class_239 objectMouseOver = mc.field_1765;
		if (!(objectMouseOver instanceof class_3965 blockHitResult))
			return;

		class_2680 state = level.method_8320(blockHitResult.method_17777());

        RadialWrenchMenu.tryCreateFor(state, blockHitResult.method_17777(), level).ifPresent(ScreenOpener::open);
	}

}
