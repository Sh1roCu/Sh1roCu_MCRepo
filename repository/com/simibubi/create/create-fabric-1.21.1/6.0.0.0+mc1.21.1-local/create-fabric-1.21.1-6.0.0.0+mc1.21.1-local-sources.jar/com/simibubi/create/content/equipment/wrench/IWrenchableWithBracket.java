package com.simibubi.create.content.equipment.wrench;

import java.util.Optional;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_2680;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.fluids.FluidPropagator;

public interface IWrenchableWithBracket extends IWrenchable {

	public Optional<class_1799> removeBracket(class_1922 world, class_2338 pos, boolean inOnReplacedContext);

	@Override
	default class_1269 onWrenched(class_2680 state, class_1838 context) {
		if (tryRemoveBracket(context))
			return class_1269.field_5812;
		return IWrenchable.super.onWrenched(state, context);
	}

	default boolean tryRemoveBracket(class_1838 context) {
		class_1937 world = context.method_8045();
		class_2338 pos = context.method_8037();
		Optional<class_1799> bracket = removeBracket(world, pos, false);
		class_2680 blockState = world.method_8320(pos);
		if (bracket.isPresent()) {
			class_1657 player = context.method_8036();
			if (!world.field_9236 && !player.method_7337())
				player.method_31548().method_7398(bracket.get());
			if (!world.field_9236 && AllBlocks.FLUID_PIPE.has(blockState)) {
				class_2351 preferred = FluidPropagator.getStraightPipeAxis(blockState);
				class_2350 preferredDirection =
					preferred == null ? class_2350.field_11036 : class_2350.method_10156(class_2352.field_11056, preferred);
				class_2680 updated = AllBlocks.FLUID_PIPE.get()
					.updateBlockState(blockState, preferredDirection, null, world, pos);
				if (updated != blockState)
					world.method_8501(pos, updated);
			}
			return true;
		}
		return false;
	}

}
