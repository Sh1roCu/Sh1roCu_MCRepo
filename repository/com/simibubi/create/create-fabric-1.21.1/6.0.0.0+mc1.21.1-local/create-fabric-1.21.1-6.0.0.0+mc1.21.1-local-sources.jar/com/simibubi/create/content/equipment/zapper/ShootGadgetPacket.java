package com.simibubi.create.content.equipment.zapper;

import net.createmod.catnip.net.base.ClientboundPacketPayload;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

public abstract class ShootGadgetPacket implements ClientboundPacketPayload {
	protected final class_243 location;
	protected final class_1268 hand;
	protected final boolean self;

	public ShootGadgetPacket(class_243 location, class_1268 hand, boolean self) {
		this.location = location;
		this.hand = hand;
		this.self = self;
	}

	@Environment(EnvType.CLIENT)
	protected abstract void handleAdditional();

	@Environment(EnvType.CLIENT)
	protected abstract ShootableGadgetRenderHandler getHandler();

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		class_1297 renderViewEntity = class_310.method_1551()
				.method_1560();
		if (renderViewEntity == null)
			return;
		if (renderViewEntity.method_19538()
				.method_1022(location) > 100)
			return;

		ShootableGadgetRenderHandler handler = getHandler();
		handleAdditional();
		if (self)
			handler.shoot(hand, location);
		else
			handler.playSound(hand, location);
	}
}
