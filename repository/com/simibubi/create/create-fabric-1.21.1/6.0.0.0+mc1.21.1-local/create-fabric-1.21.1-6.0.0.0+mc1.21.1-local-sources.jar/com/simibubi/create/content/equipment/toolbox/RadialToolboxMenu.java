package com.simibubi.create.content.equipment.toolbox;

import static com.simibubi.create.content.equipment.toolbox.ToolboxInventory.STACKS_PER_COMPARTMENT;

import java.util.List;

import javax.annotation.Nullable;
import com.mojang.blaze3d.systems.RenderSystem;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllKeys;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import com.simibubi.create.foundation.gui.AllIcons;
import net.createmod.catnip.platform.CatnipServices;
import com.simibubi.create.foundation.utility.CreateLang;

import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.gui.AbstractSimiScreen;
import net.createmod.catnip.gui.element.GuiGameElement;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.theme.Color;
import net.minecraft.class_1041;
import net.minecraft.class_124;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4587;
import io.github.fabricators_of_create.porting_lib.util.KeyBindingHelper;

public class RadialToolboxMenu extends AbstractSimiScreen {

	private State state;
	private int ticksOpen;
	private int hoveredSlot;
	private boolean scrollMode;
	private int scrollSlot = 0;
	private List<ToolboxBlockEntity> toolboxes;
	private ToolboxBlockEntity selectedBox;

	private static final int DEPOSIT = -7;
	private static final int UNEQUIP = -5;

	public RadialToolboxMenu(List<ToolboxBlockEntity> toolboxes, State state, @Nullable ToolboxBlockEntity selectedBox) {
		this.toolboxes = toolboxes;
		this.state = state;
		hoveredSlot = -1;

		if (selectedBox != null)
			this.selectedBox = selectedBox;
	}

	public void prevSlot(int slot) {
		scrollSlot = slot;
	}

	@Override
	protected void renderWindow(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		float fade = class_3532.method_15363((ticksOpen + AnimationTickHolder.getPartialTicks()) / 10f, 1 / 512f, 1);

		hoveredSlot = -1;
		class_1041 window = class_310.method_1551().method_22683();
		float hoveredX = mouseX - window.method_4486() / 2;
		float hoveredY = mouseY - window.method_4502() / 2;

		float distance = hoveredX * hoveredX + hoveredY * hoveredY;
		if (distance > 25 && distance < 10000)
			hoveredSlot =
				(class_3532.method_15375((AngleHelper.deg(class_3532.method_15349(hoveredY, hoveredX)) + 360 + 180 - 22.5f)) % 360)
					/ 45;
		boolean renderCenterSlot = state == State.SELECT_ITEM_UNEQUIP;
		if (scrollMode && distance > 150)
			scrollMode = false;
		if (renderCenterSlot && distance <= 150)
			hoveredSlot = UNEQUIP;

		class_4587 ms = graphics.method_51448();
		ms.method_22903();
		ms.method_46416(field_22789 / 2, field_22790 / 2, 0);
		class_2561 tip = null;

		if (state == State.DETACH) {

			tip = CreateLang.translateDirect("toolbox.outOfRange");
			if (hoveredX > -20 && hoveredX < 20 && hoveredY > -80 && hoveredY < -20)
				hoveredSlot = UNEQUIP;

			ms.method_22903();
			AllGuiTextures.TOOLBELT_INACTIVE_SLOT.render(graphics, -12, -12);
			GuiGameElement.of(AllBlocks.TOOLBOXES.get(class_1767.field_7957)
				.asStack())
				.at(-9, -9)
				.render(graphics);

			ms.method_46416(0, -40 + (10 * (1 - fade) * (1 - fade)), 0);
			AllGuiTextures.TOOLBELT_SLOT.render(graphics, -12, -12);
			ms.method_22904(-0.5, 0.5, 0);
			AllIcons.I_DISABLE.render(graphics, -9, -9);
			ms.method_22904(0.5, -0.5, 0);
			if (!scrollMode && hoveredSlot == UNEQUIP) {
				AllGuiTextures.TOOLBELT_SLOT_HIGHLIGHT.render(graphics, -13, -13);
				tip = CreateLang.translateDirect("toolbox.detach")
					.method_27692(class_124.field_1065);
			}
			ms.method_22909();

		} else {

			if (hoveredX > 60 && hoveredX < 100 && hoveredY > -20 && hoveredY < 20)
				hoveredSlot = DEPOSIT;

			ms.method_22903();
			ms.method_46416(80 + (-5 * (1 - fade) * (1 - fade)), 0, 0);
			AllGuiTextures.TOOLBELT_SLOT.render(graphics, -12, -12);
			ms.method_22904(-0.5, 0.5, 0);
			AllIcons.I_TOOLBOX.render(graphics, -9, -9);
			ms.method_22904(0.5, -0.5, 0);
			if (!scrollMode && hoveredSlot == DEPOSIT) {
				AllGuiTextures.TOOLBELT_SLOT_HIGHLIGHT.render(graphics, -13, -13);
				tip = CreateLang.translateDirect(state == State.SELECT_BOX ? "toolbox.depositAll" : "toolbox.depositBox")
					.method_27692(class_124.field_1065);
			}
			ms.method_22909();

			for (int slot = 0; slot < 8; slot++) {
				ms.method_22903();
				TransformStack.of(ms)
					.rotateZDegrees(slot * 45 - 45)
					.translate(0, -40 + (10 * (1 - fade) * (1 - fade)), 0)
					.rotateZDegrees(-slot * 45 + 45);
				ms.method_46416(-12, -12, 0);

				if (state == State.SELECT_ITEM || state == State.SELECT_ITEM_UNEQUIP) {
					ToolboxInventory inv = selectedBox.inventory;
					class_1799 stackInSlot = inv.filters.get(slot);

					if (!stackInSlot.method_7960()) {
						boolean empty = inv.getStackInSlot(slot * STACKS_PER_COMPARTMENT)
							.method_7960();

						(empty ? AllGuiTextures.TOOLBELT_INACTIVE_SLOT : AllGuiTextures.TOOLBELT_SLOT)
							.render(graphics, 0, 0);
						GuiGameElement.of(stackInSlot)
							.at(3, 3)
							.render(graphics);

						if (slot == (scrollMode ? scrollSlot : hoveredSlot) && !empty) {
							AllGuiTextures.TOOLBELT_SLOT_HIGHLIGHT.render(graphics, -1, -1);
							tip = stackInSlot.method_7964();
						}
					} else
						AllGuiTextures.TOOLBELT_EMPTY_SLOT.render(graphics, 0, 0);

				} else if (state == State.SELECT_BOX) {

					if (slot < toolboxes.size()) {
						AllGuiTextures.TOOLBELT_SLOT.render(graphics, 0, 0);
						ToolboxBlockEntity toolboxBlockEntity = toolboxes.get(slot);
						GuiGameElement.of(AllBlocks.TOOLBOXES.get(toolboxBlockEntity.getColor())
							.asStack())
							.at(3, 3)
							.render(graphics);

						if (slot == (scrollMode ? scrollSlot : hoveredSlot)) {
							AllGuiTextures.TOOLBELT_SLOT_HIGHLIGHT.render(graphics, -1, -1);
							tip = toolboxBlockEntity.method_5476();
						}
					} else
						AllGuiTextures.TOOLBELT_EMPTY_SLOT.render(graphics, 0, 0);

				}

				ms.method_22909();
			}

			if (renderCenterSlot) {
				ms.method_22903();
				AllGuiTextures.TOOLBELT_SLOT.render(graphics, -12, -12);
				(scrollMode ? AllIcons.I_REFRESH : AllIcons.I_FLIP).render(graphics, -9, -9);
				if (!scrollMode && UNEQUIP == hoveredSlot) {
					AllGuiTextures.TOOLBELT_SLOT_HIGHLIGHT.render(graphics, -13, -13);
					tip = CreateLang.translateDirect("toolbox.unequip", field_22787.field_1724.method_6047()
						.method_7964())
						.method_27692(class_124.field_1065);
				}
				ms.method_22909();
			}
		}
		ms.method_22909();

		if (tip != null) {
			int i1 = (int) (fade * 255.0F);
			if (i1 > 255)
				i1 = 255;

			if (i1 > 8) {
				ms.method_22903();
				ms.method_46416((float) (field_22789 / 2), (float) (field_22790 - 68), 0.0F);
				RenderSystem.enableBlend();
				RenderSystem.defaultBlendFunc();
				int k1 = 16777215;
				int k = i1 << 24 & -16777216;
				int l = field_22793.method_27525(tip);
				graphics.method_51439(field_22793, tip, Math.round(-l / 2f), -4, k1 | k, false);
				RenderSystem.disableBlend();
				ms.method_22909();
			}
		}

	}

	@Override
	public void method_25420(class_332 pGuiGraphics, int pMouseX, int pMouseY, float pPartialTick) {
		Color color = BACKGROUND_COLOR
				.scaleAlpha(Math.min(1, (ticksOpen + AnimationTickHolder.getPartialTicks()) / 20f));

		pGuiGraphics.method_25296(0, 0, this.field_22789, this.field_22790, color.getRGB(), color.getRGB());
	}

	@Override
	public void method_25393() {
		ticksOpen++;
		super.method_25393();
	}

	@Override
	public void method_25432() {
		super.method_25432();

		int selected = (scrollMode ? scrollSlot : hoveredSlot);

		if (selected == DEPOSIT) {
			if (state == State.DETACH)
				return;
			else if (state == State.SELECT_BOX)
				toolboxes.forEach(be -> CatnipServices.NETWORK.sendToServer(new ToolboxDisposeAllPacket(be.method_11016())));
			else
				CatnipServices.NETWORK.sendToServer(new ToolboxDisposeAllPacket(selectedBox.method_11016()));
			return;
		}

		if (state == State.SELECT_BOX)
			return;

		if (state == State.DETACH) {
			if (selected == UNEQUIP)
				CatnipServices.NETWORK.sendToServer(
					new ToolboxEquipPacket(null, selected, field_22787.field_1724.method_31548().field_7545));
			return;
		}

		if (selected == UNEQUIP)
			CatnipServices.NETWORK.sendToServer(new ToolboxEquipPacket(selectedBox.method_11016(), selected,
				field_22787.field_1724.method_31548().field_7545));

		if (selected < 0)
			return;
		ToolboxInventory inv = selectedBox.inventory;
		class_1799 stackInSlot = inv.filters.get(selected);
		if (stackInSlot.method_7960())
			return;
		if (inv.getStackInSlot(selected * STACKS_PER_COMPARTMENT)
			.method_7960())
			return;

		CatnipServices.NETWORK.sendToServer(new ToolboxEquipPacket(selectedBox.method_11016(), selected,
			field_22787.field_1724.method_31548().field_7545));
	}

	@Override
	public boolean method_25401(double pMouseX, double pMouseY, double pScrollX, double pScrollY) {
		class_1041 window = class_310.method_1551().method_22683();
		double hoveredX = pMouseX - window.method_4486() / 2;
		double hoveredY = pMouseY - window.method_4502() / 2;
		double distance = hoveredX * hoveredX + hoveredY * hoveredY;
		if (distance <= 150) {
			scrollMode = true;
			scrollSlot = (((int) (scrollSlot - pScrollY)) + 8) % 8;
			for (int i = 0; i < 10; i++) {

				if (state == State.SELECT_ITEM || state == State.SELECT_ITEM_UNEQUIP) {
					ToolboxInventory inv = selectedBox.inventory;
					class_1799 stackInSlot = inv.filters.get(scrollSlot);
					if (!stackInSlot.method_7960() && !inv.getStackInSlot(scrollSlot * STACKS_PER_COMPARTMENT)
						.method_7960())
						break;
				}

				if (state == State.SELECT_BOX)
					if (scrollSlot < toolboxes.size())
						break;

				if (state == State.DETACH)
					break;

				scrollSlot -= class_3532.method_17822(pScrollY);
				scrollSlot = (scrollSlot + 8) % 8;
			}
			return true;
		}

		return super.method_25401(pMouseX, pMouseY, pScrollX, pScrollY);
	}

	@Override
	public boolean method_25402(double x, double y, int button) {
		int selected = scrollMode ? scrollSlot : hoveredSlot;

		if (button == 0) {
			if (selected == DEPOSIT) {
				method_25419();
				ToolboxHandlerClient.COOLDOWN = 2;
				return true;
			}

			if (state == State.SELECT_BOX && selected >= 0 && selected < toolboxes.size()) {
				state = State.SELECT_ITEM;
				selectedBox = toolboxes.get(selected);
				return true;
			}

			if (state == State.DETACH || state == State.SELECT_ITEM || state == State.SELECT_ITEM_UNEQUIP) {
				if (selected == UNEQUIP || selected >= 0) {
					method_25419();
					ToolboxHandlerClient.COOLDOWN = 2;
					return true;
				}
			}
		}

		if (button == 1) {
			if (state == State.SELECT_ITEM && toolboxes.size() > 1) {
				state = State.SELECT_BOX;
				return true;
			}

			if (state == State.SELECT_ITEM_UNEQUIP && selected == UNEQUIP) {
				if (toolboxes.size() > 1) {
					CatnipServices.NETWORK.sendToServer(new ToolboxEquipPacket(selectedBox.method_11016(), selected,
						field_22787.field_1724.method_31548().field_7545));
					state = State.SELECT_BOX;
					return true;
				}

				method_25419();
				ToolboxHandlerClient.COOLDOWN = 2;
				return true;
			}
		}

		return super.method_25402(x, y, button);
	}

	@Override
	public boolean method_25404(int code, int scanCode, int modifiers) {
		class_304[] hotbarBinds = field_22787.field_1690.field_1852;
		for (int i = 0; i < hotbarBinds.length && i < 8; i++) {
			if (hotbarBinds[i].method_1417(code, scanCode)) {

				if (state == State.SELECT_ITEM || state == State.SELECT_ITEM_UNEQUIP) {
					ToolboxInventory inv = selectedBox.inventory;
					class_1799 stackInSlot = inv.filters.get(i);
					if (stackInSlot.method_7960() || inv.getStackInSlot(i * STACKS_PER_COMPARTMENT)
						.method_7960())
						return false;
				}

				if (state == State.SELECT_BOX)
					if (i >= toolboxes.size())
						return false;

				scrollMode = true;
				scrollSlot = i;
				method_25402(0, 0, 0);
				return true;
			}
		}

		return super.method_25404(code, scanCode, modifiers);
	}

	@Override
	public boolean method_16803(int code, int scanCode, int modifiers) {
		class_3675.class_306 mouseKey = class_3675.method_15985(code, scanCode);
		if (KeyBindingHelper.isActiveAndMatches(AllKeys.TOOLBELT.getKeybind(), mouseKey)) {
			method_25419();
			return true;
		}
		return super.method_16803(code, scanCode, modifiers);
	}

	public static enum State {
		SELECT_BOX, SELECT_ITEM, SELECT_ITEM_UNEQUIP, DETACH
	}

}
