package com.simibubi.create.content.equipment.potatoCannon;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1311;
import net.minecraft.class_1528;
import net.minecraft.class_1657;
import net.minecraft.class_1668;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2392;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2668;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4048;
import net.minecraft.class_7924;
import net.minecraft.class_8103;
import net.minecraft.class_9129;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllEnchantments;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.api.equipment.potatoCannon.PotatoCannonProjectileType;
import com.simibubi.create.api.equipment.potatoCannon.PotatoProjectileRenderMode;
import com.simibubi.create.content.equipment.potatoCannon.AllPotatoProjectileRenderModes.StuckToEntity;
import com.simibubi.create.foundation.advancement.AllAdvancements;
import com.simibubi.create.foundation.damageTypes.CreateDamageSources;
import com.simibubi.create.foundation.particle.AirParticleData;

import net.createmod.catnip.math.VecHelper;
import io.github.fabricators_of_create.porting_lib.entity.IEntityWithComplexSpawn;

public class PotatoProjectileEntity extends class_1668 implements IEntityWithComplexSpawn {

	protected PotatoCannonProjectileType type;
	protected class_1799 stack = class_1799.field_8037;

	protected class_1297 stuckEntity;
	protected class_243 stuckOffset;
	protected PotatoProjectileRenderMode stuckRenderer;
	protected double stuckFallSpeed;

	protected float additionalDamageMult = 1;
	protected float additionalKnockback = 0;
	protected float recoveryChance = 0;

	public PotatoProjectileEntity(class_1299<? extends class_1668> type, class_1937 level) {
		super(type, level);
	}

	public void setItem(class_1799 stack) {
		this.stack = stack.method_46651(1);
		type = PotatoCannonProjectileType.getTypeValueForItem(method_37908().method_30349(), stack.method_7909())
			.orElseGet(() -> new PotatoCannonProjectileType.Builder()
				.damage(0)
				.addItems(stack.method_7909())
				.build());
	}

	public void setEnchantmentEffectsFromCannon(class_1799 cannon) {
		class_2378<class_1887> enchantmentRegistry = method_56673().method_30530(class_7924.field_41265);

		int recovery = class_1890.method_8225(
			enchantmentRegistry.method_40290(AllEnchantments.POTATO_RECOVERY), cannon);

		if (recovery > 0)
			recoveryChance = .125f + recovery * .125f;
	}

	public class_1799 getItem() {
		return stack;
	}

	@Nullable
	public PotatoCannonProjectileType getProjectileType() {
		return type;
	}

	@Override
	public void method_5749(class_2487 nbt) {
		setItem(class_1799.method_57359(this.method_56673(), nbt.method_10562("Item")));
		additionalDamageMult = nbt.method_10583("AdditionalDamage");
		additionalKnockback = nbt.method_10583("AdditionalKnockback");
		recoveryChance = nbt.method_10583("Recovery");
		super.method_5749(nbt);
	}

	@Override
	public void method_5652(class_2487 nbt) {
		nbt.method_10566("Item", stack.method_57375(this.method_56673()));
		nbt.method_10548("AdditionalDamage", additionalDamageMult);
		nbt.method_10548("AdditionalKnockback", additionalKnockback);
		nbt.method_10548("Recovery", recoveryChance);
		super.method_5652(nbt);
	}

	@Nullable
	public class_1297 getStuckEntity() {
		if (stuckEntity == null)
			return null;
		if (!stuckEntity.method_5805())
			return null;
		return stuckEntity;
	}

	public void setStuckEntity(class_1297 stuckEntity) {
		this.stuckEntity = stuckEntity;
		this.stuckOffset = method_19538().method_1020(stuckEntity.method_19538());
		this.stuckRenderer = new StuckToEntity(stuckOffset);
		this.stuckFallSpeed = 0.0;
		method_18799(class_243.field_1353);
	}

	public PotatoProjectileRenderMode getRenderMode() {
		if (getStuckEntity() != null)
			return stuckRenderer;

		return type.renderMode();
	}

	@Override
	public void method_5773() {
		class_1297 stuckEntity = getStuckEntity();
		if (stuckEntity != null) {
			if (method_23318() < stuckEntity.method_23318() - 0.1) {
				pop(method_19538());
				method_5768();
			} else {
				stuckFallSpeed += 0.007 * type.gravityMultiplier();
				stuckOffset = stuckOffset.method_1031(0, -stuckFallSpeed, 0);
				class_243 pos = stuckEntity.method_19538()
					.method_1019(stuckOffset);
				method_5814(pos.field_1352, pos.field_1351, pos.field_1350);
			}
		} else {
			method_18799(method_18798().method_1031(0, -0.05 * type.gravityMultiplier(), 0)
				.method_1021(type.drag()));
		}

		super.method_5773();
	}

	@Override
	protected float method_7466() {
		return 1;
	}

	@Override
	protected class_2394 method_7467() {
		return new AirParticleData(1, 10);
	}

	@Override
	protected boolean method_7468() {
		return false;
	}

	@Override
	protected void method_7454(class_3966 ray) {
		super.method_7454(ray);

		if (getStuckEntity() != null)
			return;

		class_243 hit = ray.method_17784();
		class_1297 target = ray.method_17782();
		float damage = type.damage() * additionalDamageMult;
		float knockback = type.knockback() + additionalKnockback;
		class_1297 owner = this.method_24921();

		if (!target.method_5805())
			return;
		if (owner instanceof class_1309)
			((class_1309) owner).method_6114(target);

		if (target instanceof PotatoProjectileEntity ppe) {
			if (field_6012 < 10 && target.field_6012 < 10)
				return;
			if (ppe.getProjectileType() != getProjectileType()) {
				if (owner instanceof class_1657 p)
					AllAdvancements.POTATO_CANNON_COLLIDE.awardTo(p);
				if (ppe.method_24921() instanceof class_1657 p)
					AllAdvancements.POTATO_CANNON_COLLIDE.awardTo(p);
			}
		}

		pop(hit);

		if (target instanceof class_1528 && ((class_1528) target).method_6872())
			return;
		if (type.preEntityHit(stack, ray))
			return;

		boolean targetIsEnderman = target.method_5864() == class_1299.field_6091;
		int k = target.method_20802();
		if (this.method_5809() && !targetIsEnderman)
			target.method_5639(5);

		boolean onServer = !method_37908().field_9236;
		class_1282 damageSource = causePotatoDamage();
		if (onServer && !target.method_5643(damageSource, damage)) {
			target.method_20803(k);
			method_5768();
			return;
		}

		if (targetIsEnderman)
			return;

		if (!type.onEntityHit(stack, ray) && onServer) {
			if (field_5974.method_43058() <= recoveryChance) {
				recoverItem();
			} else {
				method_5775(type.dropStack());
			}
		}

		if (!(target instanceof class_1309 livingentity)) {
			playHitSound(method_37908(), method_19538());
			method_5768();
			return;
		}

		if (type.reloadTicks() < 10)
			livingentity.field_6008 = type.reloadTicks() + 10;

		if (onServer && knockback > 0) {
			class_243 appliedMotion = this.method_18798()
				.method_18805(1.0D, 0.0D, 1.0D)
				.method_1029()
				.method_1021(knockback * 0.6);
			if (appliedMotion.method_1027() > 0.0D)
				livingentity.method_5762(appliedMotion.field_1352, 0.1D, appliedMotion.field_1350);
		}

		if (onServer && owner instanceof class_1309) {
			class_1890.method_60107((class_3218) method_37908(), livingentity, damageSource);
		}

		if (livingentity != owner && livingentity instanceof class_1657 && owner instanceof class_3222
			&& !this.method_5701()) {
			((class_3222) owner).field_13987
				.method_14364(new class_2668(class_2668.field_25651, 0.0F));
		}

		if (onServer && owner instanceof class_3222 serverplayerentity) {
			if (!target.method_5805() && target.method_5864()
				.method_5891() == class_1311.field_6302 || (target instanceof class_1657 && target != owner))
				AllAdvancements.POTATO_CANNON.awardTo(serverplayerentity);
		}

		if (type.sticky() && target.method_5805()) {
			setStuckEntity(target);
		} else {
			method_5768();
		}

	}

	private void recoverItem() {
		if (!stack.method_7960())
			method_5775(stack.method_46651(1));
	}

	public static void playHitSound(class_1937 world, class_243 location) {
		AllSoundEvents.POTATO_HIT.playOnServer(world, class_2338.method_49638(location));
	}

	public static void playLaunchSound(class_1937 world, class_243 location, float pitch) {
		AllSoundEvents.FWOOMP.playAt(world, location, 1, pitch, true);
	}

	@Override
	protected void method_24920(class_3965 ray) {
		class_243 hit = ray.method_17784();
		pop(hit);
		if (!type.onBlockHit(method_37908(), stack, ray) && !method_37908().field_9236) {
			if (field_5974.method_43058() <= recoveryChance) {
				recoverItem();
			} else {
				method_5775(getProjectileType().dropStack());
			}
		}

		super.method_24920(ray);
		method_5768();
	}

	@Override
	public boolean method_5643(@NotNull class_1282 source, float amt) {
		if (source.method_48789(class_8103.field_42246))
			return false;
		if (this.method_5679(source))
			return false;
		pop(method_19538());
		method_5768();
		return true;
	}

	private void pop(class_243 hit) {
		if (!stack.method_7960()) {
			for (int i = 0; i < 7; i++) {
				class_243 m = VecHelper.offsetRandomly(class_243.field_1353, this.field_5974, .25f);
				method_37908().method_8406(new class_2392(class_2398.field_11218, stack), hit.field_1352, hit.field_1351, hit.field_1350, m.field_1352, m.field_1351,
					m.field_1350);
			}
		}
		if (!method_37908().field_9236)
			playHitSound(method_37908(), method_19538());
	}

	private class_1282 causePotatoDamage() {
		return CreateDamageSources.potatoCannon(method_37908(), this, method_24921());
	}

	@SuppressWarnings("unchecked")
	public static FabricEntityTypeBuilder<?> build(FabricEntityTypeBuilder<?> builder) {
//		EntityType.Builder<PotatoProjectileEntity> entityBuilder = (EntityType.Builder<PotatoProjectileEntity>) builder;
		return builder.dimensions(class_4048.method_18385(0.25f, 0.25f));
	}

	@Override
	public void writeSpawnData(class_9129 buffer) {
		class_1799.field_49268.encode(buffer, stack);
		buffer.method_52941(additionalDamageMult);
		buffer.method_52941(additionalKnockback);
		buffer.method_52941(recoveryChance);
	}

	@Override
	public void readSpawnData(class_9129 additionalData) {
		setItem(class_1799.field_49268.decode(additionalData));
		additionalDamageMult = additionalData.readFloat();
		additionalKnockback = additionalData.readFloat();
		recoveryChance = additionalData.readFloat();
	}

}
