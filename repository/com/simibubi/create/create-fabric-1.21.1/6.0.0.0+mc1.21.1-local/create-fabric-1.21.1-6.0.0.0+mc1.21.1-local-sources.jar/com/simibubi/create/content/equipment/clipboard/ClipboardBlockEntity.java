package com.simibubi.create.content.equipment.clipboard;

import java.util.List;
import java.util.UUID;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.logistics.AddressEditBoxHelper;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

import net.createmod.catnip.platform.CatnipServices;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_7225;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import io.github.fabricators_of_create.porting_lib.common.util.EnvExecutor;


public class ClipboardBlockEntity extends SmartBlockEntity {

	public class_1799 dataContainer;
	private UUID lastEdit;

	public ClipboardBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		dataContainer = AllBlocks.CLIPBOARD.asStack();
	}

	@Override
	public void initialize() {
		super.initialize();
		updateWrittenState();
	}

	public void onEditedBy(class_1657 player) {
		lastEdit = player.method_5667();
		notifyUpdate();
		updateWrittenState();
	}

	@Override
	public void lazyTick() {
		super.lazyTick();
		if (field_11863.method_8608())
			CatnipServices.PLATFORM.executeOnClientOnly(() -> this::advertiseToAddressHelper);
	}

	public void updateWrittenState() {
		class_2680 blockState = method_11010();
		if (!AllBlocks.CLIPBOARD.has(blockState))
			return;
		if (field_11863.method_8608())
			return;
		boolean isWritten = blockState.method_11654(ClipboardBlock.WRITTEN);
		boolean shouldBeWritten = !dataContainer.method_57380().method_57848();
		if (isWritten == shouldBeWritten)
			return;
		field_11863.method_8501(field_11867, blockState.method_11657(ClipboardBlock.WRITTEN, shouldBeWritten));
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {}

	@Override
	protected void write(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		super.write(tag, registries, clientPacket);
		tag.method_10566("Item", dataContainer.method_57375(registries));
		if (clientPacket && lastEdit != null)
			tag.method_25927("LastEdit", lastEdit);
	}

	@Override
	protected void read(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		super.read(tag, registries, clientPacket);
		dataContainer = class_1799.method_57359(registries, tag.method_10562("Item"));
		if (!AllBlocks.CLIPBOARD.isIn(dataContainer))
			dataContainer = AllBlocks.CLIPBOARD.asStack();

		if (clientPacket)
			CatnipServices.PLATFORM.executeOnClientOnly(() -> () -> readClientSide(tag));
	}

	@Environment(EnvType.CLIENT)
	private void readClientSide(class_2487 tag) {
		class_310 mc = class_310.method_1551();
		if (!(mc.field_1755 instanceof ClipboardScreen cs))
			return;
		if (tag.method_10545("LastEdit") && tag.method_25926("LastEdit")
			.equals(mc.field_1724.method_5667()))
			return;
		if (!field_11867.equals(cs.targetedBlock))
			return;
		cs.reopenWith(dataContainer);
	}

	@Environment(EnvType.CLIENT)
	private void advertiseToAddressHelper() {
		AddressEditBoxHelper.advertiseClipboard(this);
	}

}
