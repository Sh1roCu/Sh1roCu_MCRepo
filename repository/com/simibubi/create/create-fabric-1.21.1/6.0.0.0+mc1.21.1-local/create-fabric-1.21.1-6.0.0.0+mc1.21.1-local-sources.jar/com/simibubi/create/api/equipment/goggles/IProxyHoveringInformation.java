package com.simibubi.create.api.equipment.goggles;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

/**
 * Implement this interface on the {@link class_2586} that wants proxy the information
 */
public interface IProxyHoveringInformation {
	class_2338 getInformationSource(class_1937 level, class_2338 pos, class_2680 state);
}
