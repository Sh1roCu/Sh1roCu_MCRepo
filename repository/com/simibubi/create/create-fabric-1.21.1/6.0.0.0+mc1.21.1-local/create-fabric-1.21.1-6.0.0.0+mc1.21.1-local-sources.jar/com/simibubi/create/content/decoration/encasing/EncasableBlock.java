package com.simibubi.create.content.decoration.encasing;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_9062;

/**
 * Implement this interface to indicate that this block is encasable.
 */
public interface EncasableBlock {
	/**
	 * This method should be called in the {@link class_2248#method_55765(class_1799, class_2680, class_1937, class_2338, class_1657, class_1268, class_3965)} method.
	 */
	default class_9062 tryEncase(class_2680 state, class_1937 level, class_2338 pos, class_1799 heldItem, class_1657 player, class_1268 hand,
											class_3965 ray) {
		List<class_2248> encasedVariants = EncasingRegistry.getVariants(state.method_26204());
		for (class_2248 block : encasedVariants) {
			if (block instanceof EncasedBlock encased) {
				if (encased.getCasing().method_8389() != heldItem.method_7909())
					continue;

				if (level.field_9236)
					return class_9062.field_47728;

				encased.handleEncasing(state, level, pos, heldItem, player, hand, ray);
				playEncaseSound(level, pos);
				return class_9062.field_47728;
			}
		}
		return class_9062.field_47731;
	}

	default void playEncaseSound(class_1937 level, class_2338 pos) {
		class_2680 newState = level.method_8320(pos);
		class_2498 soundType = newState.method_26231();
		level.method_8396(null, pos, soundType.method_10598(), class_3419.field_15245, (soundType.method_10597() + 1.0F) / 2.0F, soundType.method_10599() * 0.8F);
	}
}
