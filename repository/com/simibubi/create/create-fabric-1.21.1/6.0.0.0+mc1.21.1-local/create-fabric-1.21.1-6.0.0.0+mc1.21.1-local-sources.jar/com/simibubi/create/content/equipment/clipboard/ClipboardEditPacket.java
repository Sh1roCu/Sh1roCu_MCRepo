package com.simibubi.create.content.equipment.clipboard;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllDataComponents;
import com.simibubi.create.AllPackets;
import com.simibubi.create.foundation.utility.CreateComponentProcessors;

import net.createmod.catnip.codecs.stream.CatnipStreamCodecBuilders;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9326;

public record ClipboardEditPacket(int hotbarSlot, class_9326 dataComponentPatch, @Nullable class_2338 targetedBlock) implements ServerboundPacketPayload {
	public static final class_9139<class_9129, ClipboardEditPacket> STREAM_CODEC = class_9139.method_56436(
		class_9135.field_48550, ClipboardEditPacket::hotbarSlot,
		class_9326.field_49590, ClipboardEditPacket::dataComponentPatch,
		CatnipStreamCodecBuilders.nullable(class_2338.field_48404), ClipboardEditPacket::targetedBlock,
		ClipboardEditPacket::new
	);

	@Override
	public void handle(class_3222 sender) {
		class_9326 processedData = CreateComponentProcessors.clipboardProcessor(dataComponentPatch);

		if (targetedBlock != null) {
			class_1937 world = sender.method_37908();
			if (!world.method_8477(targetedBlock))
				return;
			if (!targetedBlock.method_19771(sender.method_24515(), 20))
				return;
			if (world.method_8321(targetedBlock) instanceof ClipboardBlockEntity cbe) {
				if (processedData.method_57848()) {
					clearComponents(cbe.dataContainer);
				} else {
					cbe.dataContainer.method_57381(AllDataComponents.CLIPBOARD_PREVIOUSLY_OPENED_PAGE);
					cbe.dataContainer.method_57366(processedData);
				}
				cbe.onEditedBy(sender);
			}
			return;
		}

		class_1799 itemStack = sender.method_31548()
				.method_5438(hotbarSlot);
		if (!AllBlocks.CLIPBOARD.isIn(itemStack))
			return;
		if (processedData.method_57848()) {
			clearComponents(itemStack);
		} else {
			itemStack.method_57381(AllDataComponents.CLIPBOARD_PREVIOUSLY_OPENED_PAGE);
			itemStack.method_57366(processedData);
		}
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CLIPBOARD_EDIT;
	}

	private static void clearComponents(class_1799 stack) {
		stack.method_57381(AllDataComponents.CLIPBOARD_TYPE);
		stack.method_57381(AllDataComponents.CLIPBOARD_PAGES);
		stack.method_57381(AllDataComponents.CLIPBOARD_READ_ONLY);
		stack.method_57381(AllDataComponents.CLIPBOARD_COPIED_VALUES);
		stack.method_57381(AllDataComponents.CLIPBOARD_PREVIOUSLY_OPENED_PAGE);
	}
}
