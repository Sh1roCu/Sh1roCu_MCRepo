package com.simibubi.create.content.decoration.encasing;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.function.BiPredicate;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import com.simibubi.create.foundation.block.connected.CTSpriteShiftEntry;

public class CasingConnectivity {

	private Map<class_2248, Entry> entries;

	public CasingConnectivity() {
		entries = new IdentityHashMap<>();
	}

	public Entry get(class_2680 blockState) {
		return entries.get(blockState.method_26204());
	}

	public void makeCasing(class_2248 block, CTSpriteShiftEntry casing) {
		new Entry(block, casing, (s, f) -> true).register();
	}

	public void make(class_2248 block, CTSpriteShiftEntry casing) {
		new Entry(block, casing, (s, f) -> true).register();
	}

	public void make(class_2248 block, CTSpriteShiftEntry casing, BiPredicate<class_2680, class_2350> predicate) {
		new Entry(block, casing, predicate).register();
	}

	public class Entry {

		private class_2248 block;
		private CTSpriteShiftEntry casing;
		private BiPredicate<class_2680, class_2350> predicate;

		private Entry(class_2248 block, CTSpriteShiftEntry casing, BiPredicate<class_2680, class_2350> predicate) {
			this.block = block;
			this.casing = casing;
			this.predicate = predicate;
		}

		public CTSpriteShiftEntry getCasing() {
			return casing;
		}

		public boolean isSideValid(class_2680 state, class_2350 face) {
			return predicate.test(state, face);
		}

		public void register() {
			entries.put(block, this);
		}

	}
}
