package com.simibubi.create.content.contraptions.actors.trainControls;

import com.simibubi.create.AllPackets;

import io.netty.buffer.ByteBuf;
import net.createmod.catnip.net.base.ClientboundPacketPayload;

import io.netty.buffer.ByteBuf;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_746;
import net.minecraft.class_9139;

public enum ControlsStopControllingPacket implements ClientboundPacketPayload {
	INSTANCE;

	public static final class_9139<ByteBuf, ControlsStopControllingPacket> STREAM_CODEC = class_9139.method_56431(INSTANCE);

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		ControlsHandler.stopControlling();
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CONTROLS_ABORT;
	}
}
