package com.simibubi.create.content.contraptions;

import com.simibubi.create.AllEntityTypes;
import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import com.simibubi.create.content.contraptions.bearing.BearingContraption;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;

import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.math.VecHelper;
import net.createmod.catnip.nbt.NBTHelper;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2586;
import net.minecraft.class_3499.class_3501;
import net.minecraft.class_4587;
import net.minecraft.class_7225;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

/**
 * Ex: Pistons, bearings <br>
 * Controlled Contraption Entities can rotate around one axis and translate.
 * <br>
 * They are bound to an {@link IControlContraption}
 */
public class ControlledContraptionEntity extends AbstractContraptionEntity {

	protected class_2338 controllerPos;
	protected class_2351 rotationAxis;
	protected float prevAngle;
	protected float angle;
	protected float angleDelta;

	public ControlledContraptionEntity(class_1299<?> type, class_1937 world) {
		super(type, world);
	}

	public static ControlledContraptionEntity create(class_1937 world, IControlContraption controller,
													 Contraption contraption) {
		ControlledContraptionEntity entity =
			new ControlledContraptionEntity(AllEntityTypes.CONTROLLED_CONTRAPTION.get(), world);
		entity.controllerPos = controller.getBlockPosition();
		entity.setContraption(contraption);
		return entity;
	}

	@Override
	public void method_5814(double x, double y, double z) {
		super.method_5814(x, y, z);
		if (!method_37908().method_8608())
			return;
		for (class_1297 entity : method_5685())
			method_24201(entity);
	}

	@Override
	public class_243 getContactPointMotion(class_243 globalContactPoint) {
		if (contraption instanceof TranslatingContraption)
			return method_18798();
		return super.getContactPointMotion(globalContactPoint);
	}

	@Override
	protected void setContraption(Contraption contraption) {
		super.setContraption(contraption);
		if (contraption instanceof BearingContraption)
			rotationAxis = ((BearingContraption) contraption).getFacing()
				.method_10166();
	}

	@Override
	protected void readAdditional(class_2487 compound, boolean spawnPacket) {
		super.readAdditional(compound, spawnPacket);
		if (compound.method_10545("ControllerRelative"))
			controllerPos = NBTHelper.readBlockPos(compound, "ControllerRelative").method_10081(method_24515());
		if (compound.method_10545("Axis"))
			rotationAxis = NBTHelper.readEnum(compound, "Axis", class_2351.class);
		angle = compound.method_10583("Angle");
	}

	@Override
	protected void writeAdditional(class_2487 compound, class_7225.class_7874 registries, boolean spawnPacket) {
		super.writeAdditional(compound, registries, spawnPacket);
		compound.method_10566("ControllerRelative", class_2512.method_10692(controllerPos.method_10059(method_24515())));
		if (rotationAxis != null)
			NBTHelper.writeEnum(compound, "Axis", rotationAxis);
		compound.method_10548("Angle", angle);
	}

	@Override
	public ContraptionRotationState getRotationState() {
		ContraptionRotationState crs = new ContraptionRotationState();
		if (rotationAxis == class_2351.field_11048)
			crs.xRotation = angle;
		if (rotationAxis == class_2351.field_11052)
			crs.yRotation = angle;
		if (rotationAxis == class_2351.field_11051)
			crs.zRotation = angle;
		return crs;
	}

	@Override
	public class_243 applyRotation(class_243 localPos, float partialTicks) {
		localPos = VecHelper.rotate(localPos, getAngle(partialTicks), rotationAxis);
		return localPos;
	}

	@Override
	public class_243 reverseRotation(class_243 localPos, float partialTicks) {
		localPos = VecHelper.rotate(localPos, -getAngle(partialTicks), rotationAxis);
		return localPos;
	}

	public void setAngle(float angle) {
		this.angle = angle;

		if (!method_37908().method_8608())
			return;
		for (class_1297 entity : method_5685())
			method_24201(entity);
	}

	public float getAngle(float partialTicks) {
		return partialTicks == 1.0F ? angle : AngleHelper.angleLerp(partialTicks, prevAngle, angle);
	}

	public void setRotationAxis(class_2351 rotationAxis) {
		this.rotationAxis = rotationAxis;
	}

	public class_2351 getRotationAxis() {
		return rotationAxis;
	}

	@Override
	public void method_5859(double p_70634_1_, double p_70634_3_, double p_70634_5_) {
	}

	// Always noop this. Controlled Contraptions are given their position on the client from the BE
	@Override
	@Environment(EnvType.CLIENT)
	public void method_5759(double pX, double pY, double pZ, float pYRot, float pXRot, int pSteps) {
	}

	protected void tickContraption() {
		angleDelta = angle - prevAngle;
		prevAngle = angle;
		tickActors();

		if (controllerPos == null)
			return;
		if (!method_37908().method_8477(controllerPos))
			return;
		IControlContraption controller = getController();
		if (controller == null) {
			method_31472();
			return;
		}
		if (!controller.isAttachedTo(this)) {
			controller.attach(this);
			if (method_37908().field_9236)
				method_5814(method_23317(), method_23318(), method_23321());
		}
	}

	@Override
	protected boolean shouldActorTrigger(MovementContext context, class_3501 blockInfo, MovementBehaviour actor,
										 class_243 actorPosition, class_2338 gridPosition) {
		if (super.shouldActorTrigger(context, blockInfo, actor, actorPosition, gridPosition))
			return true;

		// Special activation timer for actors in the center of a bearing contraption
		if (!(contraption instanceof BearingContraption bc))
			return false;
		class_2350 facing = bc.getFacing();
		class_243 activeAreaOffset = actor.getActiveAreaOffset(context);
		if (!activeAreaOffset.method_18806(VecHelper.axisAlingedPlaneOf(class_243.method_24954(facing.method_10163())))
			.equals(class_243.field_1353))
			return false;
		if (!VecHelper.onSameAxis(blockInfo.comp_1341(), class_2338.field_10980, facing.method_10166()))
			return false;
		context.motion = class_243.method_24954(facing.method_10163())
			.method_1021(angleDelta / 360.0);
		context.relativeMotion = context.motion;
		int timer = context.data.method_10550("StationaryTimer");
		if (timer > 0) {
			context.data.method_10569("StationaryTimer", timer - 1);
			return false;
		}

		context.data.method_10569("StationaryTimer", 20);
		return true;
	}

	protected IControlContraption getController() {
		if (controllerPos == null)
			return null;
		if (!method_37908().method_8477(controllerPos))
			return null;
		class_2586 be = method_37908().method_8321(controllerPos);
		if (!(be instanceof IControlContraption))
			return null;
		return (IControlContraption) be;
	}

	@Override
	protected StructureTransform makeStructureTransform() {
		class_2338 offset = class_2338.method_49638(getAnchorVec().method_1031(.5, .5, .5));
		float xRot = rotationAxis == class_2351.field_11048 ? angle : 0;
		float yRot = rotationAxis == class_2351.field_11052 ? angle : 0;
		float zRot = rotationAxis == class_2351.field_11051 ? angle : 0;
		return new StructureTransform(offset, xRot, yRot, zRot);
	}

	@Override
	protected void onContraptionStalled() {
		IControlContraption controller = getController();
		if (controller != null)
			controller.onStall();
		super.onContraptionStalled();
	}

	@Override
	protected float getStalledAngle() {
		return angle;
	}

	@Override
	protected void handleStallInformation(double x, double y, double z, float angle) {
		method_23327(x, y, z);
		this.angle = this.prevAngle = angle;
	}

	@Override
	@Environment(EnvType.CLIENT)
	public void applyLocalTransforms(class_4587 matrixStack, float partialTicks) {
		float angle = getAngle(partialTicks);
		class_2351 axis = getRotationAxis();

		if (axis != null) {
			TransformStack.of(matrixStack)
				.nudge(method_5628())
				.center()
				.rotateDegrees(angle, axis)
				.uncenter();
		}
	}
}
