package com.simibubi.create.content.decoration;

import javax.annotation.Nullable;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3734;

public class MetalScaffoldingBlockItem extends class_3734 {

	public MetalScaffoldingBlockItem(class_2248 pBlock, class_1793 pProperties) {
		super(pBlock, pProperties);
	}

	@Nullable
	public class_1750 method_16356(class_1750 pContext) { // TODO replace with placement helper
		class_2338 blockpos = pContext.method_8037();
		class_1937 level = pContext.method_8045();
		class_2680 blockstate = level.method_8320(blockpos);
		class_2248 block = this.method_7711();
		if (!blockstate.method_27852(block))
			return pContext;

		class_2350 direction;
		if (pContext.method_8046()) {
			direction = pContext.method_17699() ? pContext.method_8038()
				.method_10153() : pContext.method_8038();
		} else {
			direction = pContext.method_8038() == class_2350.field_11036 ? pContext.method_8042() : class_2350.field_11036;
		}

		int i = 0;
		class_2338.class_2339 blockpos$mutableblockpos = blockpos.method_25503()
			.method_10098(direction);

		while (i < 7) {
			if (!level.field_9236 && !level.method_24794(blockpos$mutableblockpos)) {
				class_1657 player = pContext.method_8036();
				int j = level.method_31600();
				if (player instanceof class_3222 sp && blockpos$mutableblockpos.method_10264() >= j)
					sp.method_43502(class_2561.method_43469("build.tooHigh", j - 1)
									.method_27692(class_124.field_1061), true);
				break;
			}

			blockstate = level.method_8320(blockpos$mutableblockpos);
			if (!blockstate.method_27852(this.method_7711())) {
				if (blockstate.method_26166(pContext)) {
					return class_1750.method_16355(pContext, blockpos$mutableblockpos, direction);
				}
				break;
			}

			blockpos$mutableblockpos.method_10098(direction);
			if (direction.method_10166()
				.method_10179()) {
				++i;
			}
		}

		return null;
	}

}
