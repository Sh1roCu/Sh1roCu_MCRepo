package com.simibubi.create.content.decoration.copycat;

import com.simibubi.create.foundation.data.SpecialBlockStateGen;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;
import net.minecraft.class_2248;
import net.minecraft.class_2318;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2680;
import io.github.fabricators_of_create.porting_lib.models.generators.BlockModelProvider;

public class SpecialCopycatPanelBlockState extends SpecialBlockStateGen {

	private String name;

	public SpecialCopycatPanelBlockState(String name) {
		this.name = name;
	}

	@Override
	protected int getXRotation(class_2680 state) {
		return facing(state) == class_2350.field_11036 ? 0 : facing(state) == class_2350.field_11033 ? 180 : 0;
	}

	@Override
	protected int getYRotation(class_2680 state) {
		return horizontalAngle(facing(state));
	}

	private class_2350 facing(class_2680 state) {
		return state.method_11654(class_2318.field_10927);
	}

	@Override
	public <T extends class_2248> ModelFile getModel(DataGenContext<class_2248, T> ctx, RegistrateBlockstateProvider prov,
												class_2680 state) {
		BlockModelProvider models = prov.models();
		return facing(state).method_10166() == class_2351.field_11052
			? models.getExistingFile(prov.modLoc("block/copycat_panel/" + name + "_vertical"))
			: models.getExistingFile(prov.modLoc("block/copycat_panel/" + name));
	}

}
