package com.simibubi.create.content.decoration.girder;

import com.simibubi.create.foundation.data.AssetLookup;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;

import net.createmod.catnip.data.Iterate;
import net.minecraft.class_2248;
import net.minecraft.class_2350.class_2351;
import io.github.fabricators_of_create.porting_lib.models.generators.MultiPartBlockStateBuilder;

public class GirderBlockStateGenerator {

	public static void blockStateWithShaft(DataGenContext<class_2248, GirderEncasedShaftBlock> c,
		RegistrateBlockstateProvider p) {
		MultiPartBlockStateBuilder builder = p.getMultipartBuilder(c.get());

		builder.part()
			.modelFile(AssetLookup.partialBaseModel(c, p))
			.rotationY(0)
			.addModel()
			.condition(GirderEncasedShaftBlock.HORIZONTAL_AXIS, class_2351.field_11051)
			.end();

		builder.part()
			.modelFile(AssetLookup.partialBaseModel(c, p))
			.rotationY(90)
			.addModel()
			.condition(GirderEncasedShaftBlock.HORIZONTAL_AXIS, class_2351.field_11048)
			.end();

		builder.part()
			.modelFile(AssetLookup.partialBaseModel(c, p, "top"))
			.addModel()
			.condition(GirderEncasedShaftBlock.TOP, true)
			.end();

		builder.part()
			.modelFile(AssetLookup.partialBaseModel(c, p, "bottom"))
			.addModel()
			.condition(GirderEncasedShaftBlock.BOTTOM, true)
			.end();

	}

	public static void blockState(DataGenContext<class_2248, GirderBlock> c, RegistrateBlockstateProvider p) {
		MultiPartBlockStateBuilder builder = p.getMultipartBuilder(c.get());

		builder.part()
			.modelFile(AssetLookup.partialBaseModel(c, p, "pole"))
			.addModel()
			.condition(GirderBlock.X, false)
			.condition(GirderBlock.Z, false)
			.end();

		builder.part()
			.modelFile(AssetLookup.partialBaseModel(c, p, "x"))
			.addModel()
			.condition(GirderBlock.X, true)
			.end();

		builder.part()
			.modelFile(AssetLookup.partialBaseModel(c, p, "z"))
			.addModel()
			.condition(GirderBlock.Z, true)
			.end();

		for (boolean x : Iterate.trueAndFalse)
			builder.part()
				.modelFile(AssetLookup.partialBaseModel(c, p, "top"))
				.addModel()
				.condition(GirderBlock.TOP, true)
				.condition(GirderBlock.X, x)
				.condition(GirderBlock.Z, !x)
				.end()
				.part()
				.modelFile(AssetLookup.partialBaseModel(c, p, "bottom"))
				.addModel()
				.condition(GirderBlock.BOTTOM, true)
				.condition(GirderBlock.X, x)
				.condition(GirderBlock.Z, !x)
				.end();

		builder.part()
			.modelFile(AssetLookup.partialBaseModel(c, p, "cross"))
			.addModel()
			.condition(GirderBlock.X, true)
			.condition(GirderBlock.Z, true)
			.end();

	}

}
