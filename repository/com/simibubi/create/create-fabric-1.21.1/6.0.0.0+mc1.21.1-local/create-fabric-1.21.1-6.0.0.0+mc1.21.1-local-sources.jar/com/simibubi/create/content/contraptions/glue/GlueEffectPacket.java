package com.simibubi.create.content.contraptions.glue;

import com.simibubi.create.AllPackets;
import net.createmod.catnip.net.base.ClientboundPacketPayload;

import io.netty.buffer.ByteBuf;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record GlueEffectPacket(class_2338 pos, class_2350 direction, boolean fullBlock) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, com.simibubi.create.content.contraptions.glue.GlueEffectPacket> STREAM_CODEC = class_9139.method_56436(
			class_2338.field_48404, com.simibubi.create.content.contraptions.glue.GlueEffectPacket::pos,
			class_2350.field_48450, com.simibubi.create.content.contraptions.glue.GlueEffectPacket::direction,
			class_9135.field_48547, com.simibubi.create.content.contraptions.glue.GlueEffectPacket::fullBlock,
			com.simibubi.create.content.contraptions.glue.GlueEffectPacket::new
	);

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		if (!player.method_24515().method_19771(pos, 100))
			return;
		SuperGlueItem.spawnParticles(player.field_17892, pos, direction, fullBlock);
	}
@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.GLUE_EFFECT;
	}
}
