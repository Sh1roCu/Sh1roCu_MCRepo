package com.simibubi.create.content.contraptions.elevator;

import java.util.List;

import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;

import com.google.common.collect.ImmutableList;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllContraptionTypes;
import com.simibubi.create.api.contraption.ContraptionType;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.AssemblyException;
import com.simibubi.create.content.contraptions.actors.contraptionControls.ContraptionControlsMovement.ElevatorFloorSelection;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.contraptions.elevator.ElevatorColumn.ColumnCoords;
import com.simibubi.create.content.contraptions.pulley.PulleyContraption;
import com.simibubi.create.content.redstone.contact.RedstoneContactBlock;
import com.simibubi.create.foundation.utility.CreateLang;

import net.createmod.catnip.data.Couple;
import net.createmod.catnip.data.IntAttached;
import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3499.class_3501;
import net.minecraft.class_7225;

public class ElevatorContraption extends PulleyContraption {

	protected ColumnCoords column;
	protected int contactYOffset;
	public boolean arrived;

	private int namesListVersion = -1;
	public List<IntAttached<Couple<String>>> namesList = ImmutableList.of();
	public int clientYTarget;

	public int maxContactY;
	public int minContactY;

	// during assembly only
	private int contacts;

	public ElevatorContraption() {
		super();
	}

	public ElevatorContraption(int initialOffset) {
		super(initialOffset);
	}

	@Override
	public void tickStorage(AbstractContraptionEntity entity) {
		super.tickStorage(entity);

		if (entity.field_6012 % 10 != 0)
			return;

		ColumnCoords coords = getGlobalColumn();
		ElevatorColumn column = ElevatorColumn.get(entity.method_37908(), coords);

		if (column == null)
			return;
		if (column.namesListVersion == namesListVersion)
			return;

		namesList = column.compileNamesList();
		namesListVersion = column.namesListVersion;
		CatnipServices.NETWORK.sendToClientsTrackingEntity(entity,
			new ElevatorFloorListPacket(entity, namesList));
	}

	@Override
	protected void disableActorOnStart(MovementContext context) {}

	public ColumnCoords getGlobalColumn() {
		return column.relative(anchor);
	}

	public Integer getCurrentTargetY(class_1937 level) {
		ColumnCoords coords = getGlobalColumn();
		ElevatorColumn column = ElevatorColumn.get(level, coords);
		if (column == null)
			return null;
		if (!column.isTargetAvailable())
			return null;
		int targetedYLevel = column.getTargetedYLevel();
		if (isTargetUnreachable(targetedYLevel))
			return null;
		return targetedYLevel;
	}

	public boolean isTargetUnreachable(int contactY) {
		return contactY < minContactY || contactY > maxContactY;
	}

	@Override
	public boolean assemble(class_1937 world, class_2338 pos) throws AssemblyException {
		if (!searchMovedStructure(world, pos, null))
			return false;
		if (blocks.size() <= 0)
			return false;
		if (contacts == 0)
			throw new AssemblyException(CreateLang.translateDirect("gui.assembly.exception.no_contacts"));
		if (contacts > 1)
			throw new AssemblyException(CreateLang.translateDirect("gui.assembly.exception.too_many_contacts"));
		ElevatorColumn column = ElevatorColumn.get(world, getGlobalColumn());
		if (column != null && column.isActive())
			throw new AssemblyException(CreateLang.translateDirect("gui.assembly.exception.column_conflict"));
		startMoving(world);
		return true;
	}

	@Override
	protected Pair<class_3501, class_2586> capture(class_1937 world, class_2338 pos) {
		class_2680 blockState = world.method_8320(pos);

		if (!AllBlocks.REDSTONE_CONTACT.has(blockState))
			return super.capture(world, pos);

		class_2350 facing = blockState.method_11654(RedstoneContactBlock.field_10927);
		if (facing.method_10166() == class_2351.field_11052)
			return super.capture(world, pos);

		contacts++;
		class_2338 local = toLocalPos(pos.method_10093(facing));
		column = new ColumnCoords(local.method_10263(), local.method_10260(), facing.method_10153());
		contactYOffset = local.method_10264();

		return super.capture(world, pos);
	}

	public int getContactYOffset() {
		return contactYOffset;
	}

	public void broadcastFloorData(class_1937 level, class_2338 contactPos) {
		ElevatorColumn column = ElevatorColumn.get(level, getGlobalColumn());
		if (!(world.method_8321(contactPos) instanceof ElevatorContactBlockEntity ecbe))
			return;
		if (column != null)
			column.floorReached(level, ecbe.shortName);
	}

	@Override
	public class_2487 writeNBT(class_7225.class_7874 registries,  boolean spawnPacket) {
		class_2487 tag = super.writeNBT(registries, spawnPacket);
		tag.method_10556("Arrived", arrived);
		tag.method_10566("Column", column.write());
		tag.method_10569("ContactY", contactYOffset);
		tag.method_10569("MaxContactY", maxContactY);
		tag.method_10569("MinContactY", minContactY);
		return tag;
	}

	@Override
	public void readNBT(class_1937 world, class_2487 nbt, boolean spawnData) {
		arrived = nbt.method_10577("Arrived");
		column = ColumnCoords.read(nbt.method_10562("Column"));
		contactYOffset = nbt.method_10550("ContactY");
		maxContactY = nbt.method_10550("MaxContactY");
		minContactY = nbt.method_10550("MinContactY");
		super.readNBT(world, nbt, spawnData);
	}

	@Override
	public ContraptionType getType() {
		return AllContraptionTypes.ELEVATOR.comp_349();
	}

	public void setClientYTarget(int clientYTarget) {
		if (this.clientYTarget == clientYTarget)
			return;

		this.clientYTarget = clientYTarget;
		syncControlDisplays();
	}

	public void syncControlDisplays() {
		if (namesList.isEmpty())
			return;
		for (int i = 0; i < namesList.size(); i++)
			if (namesList.get(i)
				.getFirst() == clientYTarget)
				setAllControlsToFloor(i);
	}

	public void setAllControlsToFloor(int floorIndex) {
		for (MutablePair<class_3501, MovementContext> pair : actors)
			if (pair.right != null && pair.right.temporaryData instanceof ElevatorFloorSelection efs)
				efs.currentIndex = floorIndex;
	}

}
