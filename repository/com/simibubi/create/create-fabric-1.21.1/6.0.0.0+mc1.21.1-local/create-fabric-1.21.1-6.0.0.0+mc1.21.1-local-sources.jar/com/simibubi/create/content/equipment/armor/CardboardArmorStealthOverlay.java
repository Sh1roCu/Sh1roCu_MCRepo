package com.simibubi.create.content.equipment.armor;

import com.simibubi.create.Create;
import com.simibubi.create.foundation.mixin.accessor.GuiAccessor;
import com.simibubi.create.infrastructure.fabric.HelmetOverlay;

import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.catnip.animation.LerpedFloat.Chaser;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class CardboardArmorStealthOverlay extends HelmetOverlay {

	public CardboardArmorStealthOverlay() {
		super(PACKAGE_BLUR_LOCATION);
	}

	private static final class_2960 PACKAGE_BLUR_LOCATION = Create.asResource("textures/misc/package_blur.png");

	private static LerpedFloat opacity = LerpedFloat.linear()
		.startWithValue(0)
		.chase(0, 0.25f, Chaser.EXP);

	public static void clientTick() {
		class_746 player = class_310.method_1551().field_1724;
		if (player == null)
			return;

		opacity.tickChaser();
		opacity.updateChaseTarget(CardboardArmorHandler.testForStealth(player) ? 1 : 0);
	}

	@Override
	public float calculateOpacity(class_1799 stack, class_1657 player, float partialTicks) {
		return opacity.getValue(partialTicks);
	}
}
