package com.simibubi.create.content.equipment.toolbox;

import java.util.Collections;
import java.util.List;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.systems.RenderSystem;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import com.simibubi.create.foundation.gui.AllIcons;
import com.simibubi.create.foundation.gui.menu.AbstractSimiContainerScreen;
import com.simibubi.create.foundation.gui.widget.IconButton;
import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_768;
import com.simibubi.create.foundation.utility.CreateLang;

import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.gui.element.GuiGameElement;
import net.createmod.catnip.data.Iterate;

public class ToolboxScreen extends AbstractSimiContainerScreen<ToolboxMenu> {

	protected static final AllGuiTextures BG = AllGuiTextures.TOOLBOX;
	protected static final AllGuiTextures PLAYER = AllGuiTextures.PLAYER_INVENTORY;

	protected class_1735 hoveredToolboxSlot;
	private IconButton confirmButton;
	private IconButton disposeButton;
	private class_1767 color;

	private List<class_768> extraAreas = Collections.emptyList();

	public ToolboxScreen(ToolboxMenu menu, class_1661 inv, class_2561 title) {
		super(menu, inv, title);
//		init(); // fabric: this causes a crash with Trinkets since minecraft is null.
				// removal seems to have no effect. why is it here?
	}

	@Override
	protected void method_25426() {
		setWindowSize(30 + BG.getWidth(), BG.getHeight() + PLAYER.getHeight() - 24);
		setWindowOffset(-11, 0);
		super.method_25426();
		method_37067();

		color = field_2797.contentHolder.getColor();

		confirmButton = new IconButton(field_2776 + 30 + BG.getWidth() - 33, field_2800 + BG.getHeight() - 24, AllIcons.I_CONFIRM);
		confirmButton.withCallback(() -> {
			field_22787.field_1724.method_7346();
		});
		method_37063(confirmButton);

		disposeButton = new IconButton(field_2776 + 30 + 81, field_2800 + 69, AllIcons.I_TOOLBOX);
		disposeButton.withCallback(() -> {
			CatnipServices.NETWORK.sendToServer(new ToolboxDisposeAllPacket(field_2797.contentHolder.method_11016()));
		});
		disposeButton.setToolTip(CreateLang.translateDirect("toolbox.depositBox"));
		method_37063(disposeButton);

		extraAreas = ImmutableList.of(
			new class_768(field_2776 + 30 + BG.getWidth(), field_2800 + BG.getHeight() - 15 - 34 - 6, 72, 68)
		);
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		field_2797.renderPass = true;
		super.method_25394(graphics, mouseX, mouseY, partialTicks);
		field_2797.renderPass = false;
	}

	@Override
	protected void method_2389(class_332 graphics, float partialTicks, int mouseX, int mouseY) {
		int x = field_2776 + field_2792 - BG.getWidth();
		int y = field_2800;

		BG.render(graphics, x, y);
		graphics.method_51439(field_22793, field_22785, x + 15, y + 4, 0x592424, false);

		int invX = field_2776;
		int invY = field_2800 + field_2779 - PLAYER.getHeight();
		renderPlayerInventory(graphics, invX, invY);

		renderToolbox(graphics, x + BG.getWidth() + 50, y + BG.getHeight() + 12, partialTicks);

		class_4587 ms = graphics.method_51448();

		hoveredToolboxSlot = null;
		for (int compartment = 0; compartment < 8; compartment++) {
			int baseIndex = compartment * ToolboxInventory.STACKS_PER_COMPARTMENT;
			class_1735 slot = field_2797.field_7761.get(baseIndex);
			class_1799 itemstack = slot.method_7677();
			int i = slot.field_7873 + field_2776;
			int j = slot.field_7872 + field_2800;

			if (itemstack.method_7960())
				itemstack = field_2797.getFilter(compartment);

			if (!itemstack.method_7960()) {
				int count = field_2797.totalCountInCompartment(compartment);
				String s = String.valueOf(count);
				ms.method_22903();
				ms.method_46416(0, 0, 100);
				RenderSystem.enableDepthTest();
				graphics.method_51423(field_22787.field_1724, itemstack, i, j, 0);
				graphics.method_51432(field_22793, itemstack, i, j, s);
				ms.method_22909();
			}

			if (method_2378(slot.field_7873, slot.field_7872, 16, 16, mouseX, mouseY)) {
				hoveredToolboxSlot = slot;
				RenderSystem.disableDepthTest();
				RenderSystem.colorMask(true, true, true, false);
				int slotColor = 0x80FFFFFF;// default in forge, never overridden. // this.getSlotColor(baseIndex);
				graphics.method_25296(i, j, i + 16, j + 16, slotColor, slotColor);
				RenderSystem.colorMask(true, true, true, true);
				RenderSystem.enableDepthTest();
			}
		}
	}

	private void renderToolbox(class_332 graphics, int x, int y, float partialTicks) {
        class_4587 ms = graphics.method_51448();
		TransformStack.of(ms)
			.pushPose()
			.translate(x, y, 100)
			.scale(50)
			.rotateXDegrees(-22)
			.rotateYDegrees(-202);

		GuiGameElement.of(AllBlocks.TOOLBOXES.get(color)
			.getDefaultState())
			.render(graphics);

        TransformStack.of(ms)
			.pushPose()
			.translate(0, -6 / 16f, 12 / 16f)
			.rotateXDegrees(-105 * field_2797.contentHolder.lid.getValue(partialTicks))
			.translate(0, 6 / 16f, -12 / 16f);
		GuiGameElement.of(AllPartialModels.TOOLBOX_LIDS.get(color))
			.render(graphics);
		ms.method_22909();

		for (int offset : Iterate.zeroAndOne) {
			ms.method_22903();
			ms.method_46416(0, -offset * 1 / 8f,
				field_2797.contentHolder.drawers.getValue(partialTicks) * -.175f * (2 - offset));
			GuiGameElement.of(AllPartialModels.TOOLBOX_DRAWER)
				.render(graphics);
			ms.method_22909();
		}
		ms.method_22909();
	}

	@Override
	protected void renderForeground(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		if (hoveredToolboxSlot != null)
			field_2787 = hoveredToolboxSlot;
		super.renderForeground(graphics, mouseX, mouseY, partialTicks);
	}

	@Override
	public List<class_768> getExtraAreas() {
		return extraAreas;
	}

}
