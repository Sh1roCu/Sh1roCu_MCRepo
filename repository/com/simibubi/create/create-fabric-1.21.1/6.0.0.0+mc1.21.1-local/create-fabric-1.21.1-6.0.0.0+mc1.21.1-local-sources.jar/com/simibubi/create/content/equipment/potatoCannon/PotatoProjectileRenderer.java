package com.simibubi.create.content.equipment.potatoCannon;

import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_811;
import net.minecraft.class_897;

public class PotatoProjectileRenderer extends class_897<PotatoProjectileEntity> {

	public PotatoProjectileRenderer(class_5617.class_5618 context) {
		super(context);
	}

	@Override
	public void render(PotatoProjectileEntity entity, float yaw, float pt, class_4587 ms, class_4597 buffer,
		int light) {
		class_1799 item = entity.getItem();
		if (item.method_7960())
			return;
		ms.method_22903();
		ms.method_22904(0, entity.method_5829()
			.method_17940() / 2 - 1 / 8f, 0);
		entity.getRenderMode()
			.transform(ms, entity, pt);

		class_310.method_1551()
			.method_1480()
			.method_23178(item, class_811.field_4318, light, class_4608.field_21444, ms, buffer, entity.method_37908(),
				0);
		ms.method_22909();
	}

	@Override
	public class_2960 getTextureLocation(PotatoProjectileEntity entity) {
		return null;
	}

}
