package com.simibubi.create.content.equipment.wrench;

import com.simibubi.create.AllItems;
import com.simibubi.create.AllTags.AllItemTags;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public class WrenchEventHandler {
	public static class_1269 useOwnWrenchLogicForCreateBlocks(class_1657 player, class_1937 world, class_1268 hand, class_3965 hitVec) {
		class_1799 itemStack = player.method_5998(hand);

		// fabric: note - mayBuild handles spectator check
		if (!player.method_7294())
			return class_1269.field_5811;
		if (itemStack.method_7960())
			return class_1269.field_5811;
		if (AllItems.WRENCH.isIn(itemStack))
			return class_1269.field_5811;
		if (!AllItemTags.WRENCH.matches(itemStack.method_7909()))
			return class_1269.field_5811;

		class_2680 state = world
			.method_8320(hitVec.method_17777());
		class_2248 block = state.method_26204();

		if (!(block instanceof IWrenchable actor))
			return class_1269.field_5811;

		class_1838 context = new class_1838(player, hand, hitVec);

		return player.method_5715() ? actor.onSneakWrenched(state, context) : actor.onWrenched(state, context);
	}

}
