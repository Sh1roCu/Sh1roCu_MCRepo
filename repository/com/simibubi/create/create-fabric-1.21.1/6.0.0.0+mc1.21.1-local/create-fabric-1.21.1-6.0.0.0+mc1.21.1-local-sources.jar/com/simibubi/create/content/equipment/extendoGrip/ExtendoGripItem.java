package com.simibubi.create.content.equipment.extendoGrip;

import com.google.common.base.Suppliers;
import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.simibubi.create.AllItems;
import com.simibubi.create.Create;
import com.simibubi.create.content.equipment.armor.BacktankUtil;
import com.simibubi.create.infrastructure.config.AllConfigs;
import java.util.function.Supplier;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_5134;
import net.minecraft.class_6880;

public class ExtendoGripItem extends class_1792 {
	public static final int MAX_DAMAGE = 200;

	public static final class_1322 singleRangeAttributeModifier =
		new class_1322(Create.asResource("single_range_attribute_modifier"), 3,
			class_1322.class_1323.field_6328);
	public static final class_1322 doubleRangeAttributeModifier =
		new class_1322(Create.asResource("double_range_attribute_modifier"), 5,
			class_1322.class_1323.field_6328);

	@SuppressWarnings("unused")
	private static final Supplier<Multimap<class_6880<class_1320>, class_1322>> rangeModifier = Suppliers.memoize(() ->
		ImmutableMultimap.of(class_5134.field_47758, singleRangeAttributeModifier));
	@SuppressWarnings("unused")
	private static final Supplier<Multimap<class_6880<class_1320>, class_1322>> doubleRangeModifier = Suppliers.memoize(() ->
		ImmutableMultimap.of(class_5134.field_47758, doubleRangeAttributeModifier));

	public static final String EXTENDO_MARKER = "createExtendo";
	public static final String DUAL_EXTENDO_MARKER = "createDualExtendo";

	public ExtendoGripItem(class_1793 properties) {
		super(properties.method_7895(MAX_DAMAGE));
	}

	public static boolean isHoldingExtendoGrip(class_1657 player) {
		boolean inOff = AllItems.EXTENDO_GRIP.isIn(player.method_6079());
		boolean inMain = AllItems.EXTENDO_GRIP.isIn(player.method_6047());
		return inOff || inMain;
	}

	@Override
	public boolean method_31567(class_1799 stack) {
		return BacktankUtil.isBarVisible(stack, maxUses());
	}

	@Override
	public int method_31569(class_1799 stack) {
		return BacktankUtil.getBarWidth(stack, maxUses());
	}

	@Override
	public int method_31571(class_1799 stack) {
		return BacktankUtil.getBarColor(stack, maxUses());
	}

	private static int maxUses() {
		return AllConfigs.server().equipment.maxExtendoGripActions.get();
	}
}
