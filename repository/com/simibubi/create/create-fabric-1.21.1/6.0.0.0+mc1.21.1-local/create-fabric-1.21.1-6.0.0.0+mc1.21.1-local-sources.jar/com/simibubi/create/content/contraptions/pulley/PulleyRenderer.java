package com.simibubi.create.content.contraptions.pulley;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.AllSpriteShifts;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SpriteShiftEntry;
import net.createmod.catnip.render.SuperByteBuffer;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_3532;
import net.minecraft.class_5614;

public class PulleyRenderer extends AbstractPulleyRenderer<PulleyBlockEntity> {

	public PulleyRenderer(class_5614.class_5615 context) {
		super(context, AllPartialModels.ROPE_HALF, AllPartialModels.ROPE_HALF_MAGNET);
	}

	@Override
	protected class_2351 getShaftAxis(PulleyBlockEntity be) {
		return be.method_11010()
			.method_11654(PulleyBlock.HORIZONTAL_AXIS);
	}

	@Override
	protected PartialModel getCoil() {
		return AllPartialModels.ROPE_COIL;
	}

	@Override
	protected SuperByteBuffer renderRope(PulleyBlockEntity be) {
		return CachedBuffers.block(AllBlocks.ROPE.getDefaultState());
	}

	@Override
	protected SuperByteBuffer renderMagnet(PulleyBlockEntity be) {
		return CachedBuffers.block(AllBlocks.PULLEY_MAGNET.getDefaultState());
	}

	@Override
	protected float getOffset(PulleyBlockEntity be, float partialTicks) {
		return getBlockEntityOffset(partialTicks, be);
	}

	@Override
	protected boolean isRunning(PulleyBlockEntity be) {
		return isPulleyRunning(be);
	}

	public static boolean isPulleyRunning(PulleyBlockEntity be) {
		return be.running || be.mirrorParent != null || be.isVirtual();
	}

	@Override
	protected SpriteShiftEntry getCoilShift() {
		return AllSpriteShifts.ROPE_PULLEY_COIL;
	}
	
	public static float getBlockEntityOffset(float partialTicks, PulleyBlockEntity blockEntity) {
		float offset = blockEntity.getInterpolatedOffset(partialTicks);

		AbstractContraptionEntity attachedContraption = blockEntity.getAttachedContraption();
		if (attachedContraption != null) {
			PulleyContraption c = (PulleyContraption) attachedContraption.getContraption();
			double entityPos = class_3532.method_16436(partialTicks, attachedContraption.field_5971, attachedContraption.method_23318());
			offset = (float) -(entityPos - c.anchor.method_10264() - c.getInitialOffset());
		}

		return offset;
	}
	
	@Override
	public int method_33893() {
		return 128;
	}
	
}
