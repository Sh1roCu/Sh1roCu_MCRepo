package com.simibubi.create.content.equipment.bell;

import com.simibubi.create.foundation.blockEntity.renderer.SafeBlockEntityRenderer;

import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SuperByteBuffer;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_3709;
import net.minecraft.class_3867;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.createmod.catnip.math.AngleHelper;

public class BellRenderer<BE extends AbstractBellBlockEntity> extends SafeBlockEntityRenderer<BE> {

	public BellRenderer(class_5614.class_5615 context) {
	}

	@Override
	protected void renderSafe(BE be, float partialTicks, class_4587 ms, class_4597 buffer, int light, int overlay) {
		class_2680 state = be.method_11010();
		class_2350 facing = state.method_11654(class_3709.field_16324);
		class_3867 attachment = state.method_11654(class_3709.field_16326);

		SuperByteBuffer bell = CachedBuffers.partial(be.getBellModel(), state);

		if (be.isRinging)
			bell.rotateCentered(getSwingAngle(be.ringingTicks + partialTicks), be.ringDirection.method_10160());

		float rY = AngleHelper.horizontalAngle(facing);
		if (attachment == class_3867.field_17100 || attachment == class_3867.field_17101)
			rY += 90;
		bell.rotateCentered(AngleHelper.rad(rY), class_2350.field_11036);

		bell.light(light)
			.renderInto(ms, buffer.getBuffer(class_1921.method_23581()));
	}

	public static float getSwingAngle(float time) {
		float t = time / 1.5f;
		return 1.2f * class_3532.method_15374(t / (float) Math.PI) / (2.5f + t / 3.0f);
	}

}
