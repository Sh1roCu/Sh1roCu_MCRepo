package com.simibubi.create.content.contraptions;

import java.util.HashMap;
import java.util.Map;

import com.simibubi.create.AllPackets;
import com.simibubi.create.api.contraption.storage.fluid.MountedFluidStorage;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorage;

import net.createmod.catnip.net.base.ClientboundPacketPayload;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record MountedStorageSyncPacket(int contraptionId, Map<class_2338, MountedItemStorage> items, Map<class_2338, MountedFluidStorage> fluids) implements ClientboundPacketPayload {
	public static final class_9139<class_9129, MountedStorageSyncPacket> STREAM_CODEC = class_9139.method_56436(
		class_9135.field_49675, MountedStorageSyncPacket::contraptionId,
	    class_9135.method_56377(HashMap::new, class_2338.field_48404, MountedItemStorage.STREAM_CODEC), MountedStorageSyncPacket::items,
	    class_9135.method_56377(HashMap::new, class_2338.field_48404, MountedFluidStorage.STREAM_CODEC), MountedStorageSyncPacket::fluids,
	    MountedStorageSyncPacket::new
	);

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.MOUNTED_STORAGE_SYNC;
	}

	@Override
	public void handle(class_746 player) {
		class_1297 entity = class_310.method_1551().field_1687.method_8469(this.contraptionId);
		if (!(entity instanceof AbstractContraptionEntity contraption))
			return;

		contraption.getContraption().getStorage().handleSync(this, contraption);
	}
}
