package com.simibubi.create.content.contraptions.piston;

import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllShapes;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.content.kinetics.base.DirectionalAxisKineticBlock;
import com.simibubi.create.foundation.block.IBE;
import com.simibubi.create.infrastructure.config.AllConfigs;

import net.createmod.catnip.lang.Lang;

import net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3542;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import net.minecraft.class_9062;

public class MechanicalPistonBlock extends DirectionalAxisKineticBlock implements IBE<MechanicalPistonBlockEntity> {

	public static final class_2754<PistonState> STATE = class_2754.method_11850("state", PistonState.class);
	protected boolean isSticky;

	public static MechanicalPistonBlock normal(class_2251 properties) {
		return new MechanicalPistonBlock(properties, false);
	}

	public static MechanicalPistonBlock sticky(class_2251 properties) {
		return new MechanicalPistonBlock(properties, true);
	}

	protected MechanicalPistonBlock(class_2251 properties, boolean sticky) {
		super(properties);
		method_9590(method_9564().method_11657(FACING, class_2350.field_11043)
			.method_11657(STATE, PistonState.RETRACTED));
		isSticky = sticky;
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> builder) {
		builder.method_11667(STATE);
		super.method_9515(builder);
	}

	@Override
	protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
		if (!player.method_7294())
			return class_9062.field_47731;
		if (player.method_5715())
			return class_9062.field_47731;
		if (!stack.method_31573(ConventionalItemTags.SLIME_BALLS)) {
			if (stack.method_7960()) {
				withBlockEntityDo(level, pos, be -> be.assembleNextTick = true);
				return class_9062.field_47728;
			}
			return class_9062.field_47731;
		}
		if (state.method_11654(STATE) != PistonState.RETRACTED)
			return class_9062.field_47731;
		class_2350 direction = state.method_11654(FACING);
		if (hitResult.method_17780() != direction)
			return class_9062.field_47731;
		if (((MechanicalPistonBlock) state.method_26204()).isSticky)
			return class_9062.field_47731;
		if (level.field_9236) {
			class_243 vec = hitResult.method_17784();
			level.method_8406(class_2398.field_11246, vec.field_1352, vec.field_1351, vec.field_1350, 0, 0, 0);
			return class_9062.field_47728;
		}
		AllSoundEvents.SLIME_ADDED.playOnServer(level, pos, .5f, 1);
		if (!player.method_7337())
			stack.method_7934(1);
		level.method_8501(pos, AllBlocks.STICKY_MECHANICAL_PISTON.getDefaultState()
			.method_11657(FACING, direction)
			.method_11657(AXIS_ALONG_FIRST_COORDINATE, state.method_11654(AXIS_ALONG_FIRST_COORDINATE)));
		return class_9062.field_47728;
	}

	@Override
	public void method_9612(class_2680 state, class_1937 level, class_2338 pos, class_2248 block, class_2338 fromPos,
		boolean isMoving) {
		class_2350 direction = state.method_11654(FACING);
		if (!fromPos.equals(pos.method_10093(direction.method_10153())))
			return;
		if (!level.field_9236 && !level.method_8397()
			.method_8677(pos, this))
			level.method_39279(pos, this, 1);
	}

	@Override
	public void method_9588(class_2680 state, class_3218 worldIn, class_2338 pos, class_5819 r) {
		class_2350 direction = state.method_11654(FACING);
		class_2680 pole = worldIn.method_8320(pos.method_10093(direction.method_10153()));
		if (!AllBlocks.PISTON_EXTENSION_POLE.has(pole))
			return;
		if (pole.method_11654(PistonExtensionPoleBlock.field_10927)
			.method_10166() != direction.method_10166())
			return;
		withBlockEntityDo(worldIn, pos, be -> {
			if (be.lastException == null)
				return;
			be.lastException = null;
			be.sendData();
		});
	}

	@Override
	public class_1269 onWrenched(class_2680 state, class_1838 context) {
		if (state.method_11654(STATE) != PistonState.RETRACTED)
			return class_1269.field_5811;
		return super.onWrenched(state, context);
	}

	public enum PistonState implements class_3542 {
		RETRACTED, MOVING, EXTENDED;

		@Override
		public String method_15434() {
			return Lang.asId(name());
		}
	}

	@Override
	public class_2680 method_9576(class_1937 worldIn, class_2338 pos, class_2680 state, class_1657 player) {
		class_2350 direction = state.method_11654(FACING);
		class_2338 pistonHead = null;
		class_2338 pistonBase = pos;
		boolean dropBlocks = player == null || !player.method_7337();

		Integer maxPoles = maxAllowedPistonPoles();
		for (int offset = 1; offset < maxPoles; offset++) {
			class_2338 currentPos = pos.method_10079(direction, offset);
			class_2680 block = worldIn.method_8320(currentPos);

			if (isExtensionPole(block) && direction.method_10166() == block.method_11654(class_2741.field_12525)
				.method_10166())
				continue;

			if (isPistonHead(block) && block.method_11654(class_2741.field_12525) == direction) {
				pistonHead = currentPos;
			}

			break;
		}

		if (pistonHead != null && pistonBase != null) {
			class_2338.method_20437(pistonBase, pistonHead)
				.filter(p -> !p.equals(pos))
				.forEach(p -> worldIn.method_22352(p, dropBlocks));
		}

		for (int offset = 1; offset < maxPoles; offset++) {
			class_2338 currentPos = pos.method_10079(direction.method_10153(), offset);
			class_2680 block = worldIn.method_8320(currentPos);

			if (isExtensionPole(block) && direction.method_10166() == block.method_11654(class_2741.field_12525)
				.method_10166()) {
				worldIn.method_22352(currentPos, dropBlocks);
				continue;
			}

			break;
		}

		return super.method_9576(worldIn, pos, state, player);
	}

	public static int maxAllowedPistonPoles() {
		return AllConfigs.server().kinetics.maxPistonPoles.get();
	}

	@Override
	public class_265 method_9530(class_2680 state, class_1922 worldIn, class_2338 pos, class_3726 context) {

		if (state.method_11654(STATE) == PistonState.EXTENDED)
			return AllShapes.MECHANICAL_PISTON_EXTENDED.get(state.method_11654(FACING));

		if (state.method_11654(STATE) == PistonState.MOVING)
			return AllShapes.MECHANICAL_PISTON.get(state.method_11654(FACING));

		return class_259.method_1077();
	}

	@Override
	public Class<MechanicalPistonBlockEntity> getBlockEntityClass() {
		return MechanicalPistonBlockEntity.class;
	}

	@Override
	public class_2591<? extends MechanicalPistonBlockEntity> getBlockEntityType() {
		return AllBlockEntityTypes.MECHANICAL_PISTON.get();
	}

	public static boolean isPiston(class_2680 state) {
		return AllBlocks.MECHANICAL_PISTON.has(state) || isStickyPiston(state);
	}

	public static boolean isStickyPiston(class_2680 state) {
		return AllBlocks.STICKY_MECHANICAL_PISTON.has(state);
	}

	public static boolean isExtensionPole(class_2680 state) {
		return AllBlocks.PISTON_EXTENSION_POLE.has(state);
	}

	public static boolean isPistonHead(class_2680 state) {
		return AllBlocks.MECHANICAL_PISTON_HEAD.has(state);
	}
}
