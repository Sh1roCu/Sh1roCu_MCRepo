package com.simibubi.create.content.contraptions.mounted;

import java.util.function.Supplier;

import com.simibubi.create.AllBlocks;
import com.tterrag.registrate.util.entry.BlockEntry;

import net.createmod.catnip.lang.Lang;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3542;

public enum CartAssembleRailType implements class_3542 {

	REGULAR(class_2246.field_10167),
	POWERED_RAIL(class_2246.field_10425),
	DETECTOR_RAIL(class_2246.field_10025),
	ACTIVATOR_RAIL(class_2246.field_10546),
	CONTROLLER_RAIL(AllBlocks.CONTROLLER_RAIL)

	;

	private final Supplier<class_2248> railBlockSupplier;
	private final Supplier<class_1792> railItemSupplier;

	CartAssembleRailType(class_2248 block) {
		this.railBlockSupplier = () -> block;
		this.railItemSupplier = block::method_8389;
	}

	CartAssembleRailType(BlockEntry<?> block) {
		this.railBlockSupplier = block::get;
		this.railItemSupplier = () -> block.get().method_8389();
	}

	public class_2248 getBlock() {
		return railBlockSupplier.get();
	}

	public class_1792 getItem() {
		return railItemSupplier.get();
	}

	public boolean matches(class_2680 rail) {
		return rail.method_26204() == railBlockSupplier.get();
	}

	@Override
	public String method_15434() {
		return Lang.asId(name());
	}

}
