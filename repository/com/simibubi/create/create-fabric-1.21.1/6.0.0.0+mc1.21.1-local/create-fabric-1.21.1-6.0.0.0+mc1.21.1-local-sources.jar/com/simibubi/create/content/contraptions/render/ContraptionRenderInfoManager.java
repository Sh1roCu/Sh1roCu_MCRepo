package com.simibubi.create.content.contraptions.render;

import com.simibubi.create.content.contraptions.Contraption;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.createmod.catnip.data.WorldAttached;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_638;

public class ContraptionRenderInfoManager {
	static final WorldAttached<ContraptionRenderInfoManager> MANAGERS = new WorldAttached<>(ContraptionRenderInfoManager::new);

	private final class_1937 level;
	private final Int2ObjectMap<ContraptionRenderInfo> renderInfos = new Int2ObjectOpenHashMap<>();
	private int removalTimer;

	private ContraptionRenderInfoManager(class_1936 level) {
		this.level = (class_1937) level;
	}

	public static void tickFor(class_1937 level) {
		if (class_310.method_1551()
			.method_1493())
			return;

		MANAGERS.get(level)
			.tick();
	}

	public static void resetAll() {
		MANAGERS.empty(ContraptionRenderInfoManager::delete);
	}

	public static void onReloadLevelRenderer(class_638 level) {
		resetAll();
	}

	ContraptionRenderInfo getRenderInfo(Contraption contraption) {
		int entityId = contraption.entity.method_5628();
		ContraptionRenderInfo renderInfo = renderInfos.get(entityId);

		if (renderInfo == null) {
			renderInfo = new ContraptionRenderInfo(level, contraption);
			renderInfos.put(entityId, renderInfo);
		}

		return renderInfo;
	}

	boolean invalidate(Contraption contraption) {
		int entityId = contraption.entity.method_5628();
		ContraptionRenderInfo renderInfo = renderInfos.remove(entityId);

		if (renderInfo != null) {
			renderInfo.invalidate();
			return true;
		}

		return false;
	}

	private void tick() {
		if (removalTimer >= 20) {
			renderInfos.values().removeIf(ContraptionRenderInfo::isDead);
			removalTimer = 0;
		}
		removalTimer++;
	}

	private void delete() {
		for (ContraptionRenderInfo renderer : renderInfos.values()) {
			renderer.invalidate();
		}
		renderInfos.clear();
	}
}
