package com.simibubi.create.content.contraptions.glue;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1313;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2318;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3619;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_9129;
import org.jetbrains.annotations.NotNull;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllEntityTypes;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.api.contraption.BlockMovementChecks;
import com.simibubi.create.api.schematic.requirement.SpecialEntityItemRequirement;
import com.simibubi.create.content.contraptions.bearing.BearingBlock;
import com.simibubi.create.content.contraptions.chassis.AbstractChassisBlock;
import com.simibubi.create.content.kinetics.base.DirectionalKineticBlock;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.content.schematics.requirement.ItemRequirement.ItemUseType;

import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.math.VecHelper;
import io.github.fabricators_of_create.porting_lib.entity.IEntityWithComplexSpawn;

public class SuperGlueEntity extends class_1297 implements IEntityWithComplexSpawn, SpecialEntityItemRequirement {

	public static class_238 span(class_2338 startPos, class_2338 endPos) {
		return new class_238(class_243.method_24954(startPos), class_243.method_24954(endPos)).method_1012(1, 1, 1);
	}

	public static boolean isGlued(class_1936 level, class_2338 blockPos, class_2350 direction,
								  Set<SuperGlueEntity> cached) {
		class_2338 targetPos = blockPos.method_10093(direction);
		if (cached != null)
			for (SuperGlueEntity glueEntity : cached)
				if (glueEntity.contains(blockPos) && glueEntity.contains(targetPos))
					return true;
		for (SuperGlueEntity glueEntity : level.method_18467(SuperGlueEntity.class,
				span(blockPos, targetPos).method_1014(16))) {
			if (!glueEntity.contains(blockPos) || !glueEntity.contains(targetPos))
				continue;
			if (cached != null)
				cached.add(glueEntity);
			return true;
		}
		return false;
	}

	public static List<SuperGlueEntity> collectCropped(class_1937 level, class_238 bb) {
		List<SuperGlueEntity> glue = new ArrayList<>();
		for (SuperGlueEntity glueEntity : level.method_18467(SuperGlueEntity.class, bb)) {
			class_238 glueBox = glueEntity.method_5829();
			class_238 intersect = bb.method_999(glueBox);
			if (intersect.method_17939() * intersect.method_17940() * intersect.method_17941() == 0)
				continue;
			if (class_3532.method_20390(intersect.method_995(), 1))
				continue;
			glue.add(new SuperGlueEntity(level, intersect));
		}
		return glue;
	}

	public SuperGlueEntity(class_1299<?> type, class_1937 world) {
		super(type, world);
	}

	public SuperGlueEntity(class_1937 world, class_238 boundingBox) {
		this(AllEntityTypes.SUPER_GLUE.get(), world);
		method_5857(boundingBox);
		resetPositionToBB();
	}

	public void resetPositionToBB() {
		class_238 bb = method_5829();
		method_23327(bb.method_1005().field_1352, bb.field_1322, bb.method_1005().field_1350);
	}

	@Override
	protected void method_5693(class_2945.class_9222 builder) {}

	public static boolean isValidFace(class_1937 world, class_2338 pos, class_2350 direction) {
		class_2680 state = world.method_8320(pos);
		if (BlockMovementChecks.isBlockAttachedTowards(state, world, pos, direction))
			return true;
		if (!BlockMovementChecks.isMovementNecessary(state, world, pos))
			return false;
		if (BlockMovementChecks.isNotSupportive(state, direction))
			return false;
		return true;
	}

	public static boolean isSideSticky(class_1937 world, class_2338 pos, class_2350 direction) {
		class_2680 state = world.method_8320(pos);
		if (AllBlocks.STICKY_MECHANICAL_PISTON.has(state))
			return state.method_11654(DirectionalKineticBlock.FACING) == direction;

		if (AllBlocks.STICKER.has(state))
			return state.method_11654(class_2318.field_10927) == direction;

		if (state.method_26204() == class_2246.field_10030)
			return true;
		if (state.method_26204() == class_2246.field_21211)
			return true;

		if (AllBlocks.CART_ASSEMBLER.has(state))
			return class_2350.field_11036 == direction;

		if (AllBlocks.GANTRY_CARRIAGE.has(state))
			return state.method_11654(DirectionalKineticBlock.FACING) == direction;

		if (state.method_26204() instanceof BearingBlock) {
			return state.method_11654(DirectionalKineticBlock.FACING) == direction;
		}

		if (state.method_26204() instanceof AbstractChassisBlock) {
			class_2746 glueableSide = ((AbstractChassisBlock) state.method_26204()).getGlueableSide(state, direction);
			if (glueableSide == null)
				return false;
			return state.method_11654(glueableSide);
		}

		return false;
	}

	@Override
	public boolean method_5643(class_1282 source, float amount) {
		return false;
	}

	@Override
	public void method_5773() {
		field_6004 = method_36455();
		field_5982 = method_36454();
		field_6039 = field_5973;
		field_6014 = method_23317();
		field_6036 = method_23318();
		field_5969 = method_23321();

		if (method_5829().method_17939() == 0)
			method_31472();
	}

	@Override
	public void method_5814(double x, double y, double z) {
		class_238 bb = method_5829();
		method_23327(x, y, z);
		class_243 center = bb.method_1005();
		method_5857(bb.method_989(-center.field_1352, -bb.field_1322, -center.field_1350)
				.method_989(x, y, z));
	}

	@Override
	public void method_5784(class_1313 typeIn, class_243 pos) {
		if (!method_37908().field_9236 && method_5805() && pos.method_1027() > 0.0D)
			method_31472();
	}

	@Override
	public void method_5762(double x, double y, double z) {
		if (!method_37908().field_9236 && method_5805() && x * x + y * y + z * z > 0.0D)
			method_31472();
	}

	@Override
	public @NotNull class_4048 method_18377(@NotNull class_4050 pose) {
		return super.method_18377(pose).method_55685(0.0F);
	}

	public void playPlaceSound() {
		AllSoundEvents.SLIME_ADDED.playFrom(this, 0.5F, 0.75F);
	}

	@Override
	public void method_5697(class_1297 entityIn) {
		super.method_5697(entityIn);
	}

	@Override
	public class_1269 method_5688(class_1657 player, class_1268 hand) {
		return class_1269.field_5811;
	}

	@Override
	public void method_5652(class_2487 compound) {
		class_243 position = method_19538();
		writeBoundingBox(compound, method_5829().method_997(position.method_1021(-1)));
	}

	@Override
	public void method_5749(class_2487 compound) {
		class_243 position = method_19538();
		method_5857(readBoundingBox(compound).method_997(position));
	}

	public static void writeBoundingBox(class_2487 compound, class_238 bb) {
		compound.method_10566("From", VecHelper.writeNBT(new class_243(bb.field_1323, bb.field_1322, bb.field_1321)));
		compound.method_10566("To", VecHelper.writeNBT(new class_243(bb.field_1320, bb.field_1325, bb.field_1324)));
	}

	public static class_238 readBoundingBox(class_2487 compound) {
		class_243 from = VecHelper.readNBT(compound.method_10554("From", class_2520.field_33256));
		class_243 to = VecHelper.readNBT(compound.method_10554("To", class_2520.field_33256));
		return new class_238(from, to);
	}

	@Override
	protected boolean method_5638() {
		return false;
	}

	@Override
	public float method_5832(class_2470 transformRotation) {
		class_238 bb = method_5829().method_997(method_19538().method_1021(-1));
		if (transformRotation == class_2470.field_11463 || transformRotation == class_2470.field_11465)
			method_5857(new class_238(bb.field_1321, bb.field_1322, bb.field_1323, bb.field_1324, bb.field_1325, bb.field_1320).method_997(method_19538()));
		return super.method_5832(transformRotation);
	}

	@Override
	public float method_5763(class_2415 transformMirror) {
		return super.method_5763(transformMirror);
	}

	@Override
	public void method_5800(class_3218 world, class_1538 lightningBolt) {
	}

	@Override
	public void method_18382() {
	}

	public static FabricEntityTypeBuilder<?> build(FabricEntityTypeBuilder<?> builder) {
//		@SuppressWarnings("unchecked")
//		EntityType.Builder<SuperGlueEntity> entityBuilder = (EntityType.Builder<SuperGlueEntity>) builder;
		return builder;
	}

	@Override
	public void writeSpawnData(class_9129 buffer) {
		class_2487 compound = new class_2487();
		method_5652(compound);
		buffer.method_10794(compound);
	}

	@Override
	public void readSpawnData(class_9129 additionalData) {
		method_5749(additionalData.method_10798());
	}

	@Override
	public ItemRequirement getRequiredItems() {
		return new ItemRequirement(ItemUseType.DAMAGE, AllItems.SUPER_GLUE.get());
	}

	@Override
	public boolean method_5696() {
		return true;
	}

	public boolean contains(class_2338 pos) {
		return method_5829().method_1006(class_243.method_24953(pos));
	}

	@Override
	public class_3619 method_5657() {
		return class_3619.field_15975;
	}

	public void spawnParticles() {
		class_238 bb = method_5829();
		class_243 origin = new class_243(bb.field_1323, bb.field_1322, bb.field_1321);
		class_243 extents = new class_243(bb.method_17939(), bb.method_17940(), bb.method_17941());

		if (!(method_37908() instanceof class_3218 slevel))
			return;

		for (class_2351 axis : Iterate.axes) {
			class_2352 positive = class_2352.field_11056;
			double max = axis.method_10172(extents.field_1352, extents.field_1351, extents.field_1350);
			class_243 normal = class_243.method_24954(class_2350.method_10169(axis, positive)
					.method_10163());
			for (class_2351 axis2 : Iterate.axes) {
				if (axis2 == axis)
					continue;
				double max2 = axis2.method_10172(extents.field_1352, extents.field_1351, extents.field_1350);
				class_243 normal2 = class_243.method_24954(class_2350.method_10169(axis2, positive)
						.method_10163());
				for (class_2351 axis3 : Iterate.axes) {
					if (axis3 == axis2 || axis3 == axis)
						continue;
					double max3 = axis3.method_10172(extents.field_1352, extents.field_1351, extents.field_1350);
					class_243 normal3 = class_243.method_24954(class_2350.method_10169(axis3, positive)
							.method_10163());

					for (int i = 0; i <= max * 2; i++) {
						for (int o1 : Iterate.zeroAndOne) {
							for (int o2 : Iterate.zeroAndOne) {
								class_243 v = origin.method_1019(normal.method_1021(i / 2f))
										.method_1019(normal2.method_1021(max2 * o1))
										.method_1019(normal3.method_1021(max3 * o2));

								slevel.method_14199(class_2398.field_11246, v.field_1352, v.field_1351, v.field_1350, 1, 0, 0, 0, 0);

							}
						}
					}
					break;
				}
				break;
			}
		}
	}
}
