package com.simibubi.create.content.equipment.goggles;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllItems;
import com.simibubi.create.api.equipment.goggles.IHaveCustomOverlayIcon;
import com.simibubi.create.api.equipment.goggles.IHaveGoggleInformation;
import com.simibubi.create.api.equipment.goggles.IHaveHoveringInformation;
import com.simibubi.create.api.equipment.goggles.IProxyHoveringInformation;
import com.simibubi.create.compat.Mods;
import com.simibubi.create.content.contraptions.IDisplayAssemblyExceptions;
import com.simibubi.create.content.contraptions.piston.MechanicalPistonBlock;
import com.simibubi.create.content.contraptions.piston.PistonExtensionPoleBlock;
import com.simibubi.create.content.trains.entity.TrainRelocator;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBox;
import com.simibubi.create.foundation.gui.RemovedGuiUtils;
import com.simibubi.create.foundation.mixin.accessor.MouseHandlerAccessor;
import com.simibubi.create.foundation.utility.CreateLang;
import com.simibubi.create.infrastructure.config.AllConfigs;
import com.simibubi.create.infrastructure.config.CClient;

import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.gui.element.BoxElement;
import net.createmod.catnip.gui.element.GuiGameElement;
import net.createmod.catnip.outliner.Outline;
import net.createmod.catnip.outliner.Outliner;
import net.createmod.catnip.outliner.Outliner.OutlineEntry;
import net.createmod.catnip.theme.Color;
import net.minecraft.class_1041;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_5244;
import net.minecraft.class_5348;
import net.minecraft.class_638;
import net.minecraft.class_9080;
import net.minecraft.class_9779;

public class GoggleOverlayRenderer {

	public static final class_9080.class_9081 OVERLAY = GoggleOverlayRenderer::renderOverlay;

	private static final Map<Object, OutlineEntry> outlines = Outliner.getInstance().getOutlines();

	public static int hoverTicks = 0;
	public static class_2338 lastHovered = null;

	public static void renderOverlay(class_332 guiGraphics, class_9779 deltaTracker) {
		class_310 mc = class_310.method_1551();
		if (mc.field_1690.field_1842 || mc.field_1761.method_2920() == class_1934.field_9219)
			return;

		class_239 objectMouseOver = mc.field_1765;
		if (!(objectMouseOver instanceof class_3965 result)) {
			lastHovered = null;
			hoverTicks = 0;
			return;
		}

		for (OutlineEntry entry : outlines.values()) {
			if (!entry.isAlive())
				continue;
			Outline outline = entry.getOutline();
			if (outline instanceof ValueBox && !((ValueBox) outline).isPassive)
				return;
		}

		class_638 world = mc.field_1687;
		class_2338 pos = result.method_17777();

		int prevHoverTicks = hoverTicks;
		hoverTicks++;
		lastHovered = pos;

		pos = proxiedOverlayPosition(world, pos);

		class_2586 be = world.method_8321(pos);
		boolean wearingGoggles = GogglesItem.isWearingGoggles(mc.field_1724);

		boolean isShifting = mc.field_1724.method_5715();

		boolean hasGoggleInformation = be instanceof IHaveGoggleInformation;
		boolean hasHoveringInformation = be instanceof IHaveHoveringInformation;

		boolean goggleAddedInformation = false;
		boolean hoverAddedInformation = false;

		class_1799 item = AllItems.GOGGLES.asStack();
		List<class_2561> tooltip = new ArrayList<>();

		if (be instanceof IHaveCustomOverlayIcon customOverlayIcon)
			item = customOverlayIcon.getIcon(isShifting);

		if (hasGoggleInformation && wearingGoggles) {
			IHaveGoggleInformation gte = (IHaveGoggleInformation) be;
			goggleAddedInformation = gte.addToGoggleTooltip(tooltip, isShifting);
		}

		if (hasHoveringInformation) {
			if (!tooltip.isEmpty())
				tooltip.add(class_5244.field_39003);
			IHaveHoveringInformation hte = (IHaveHoveringInformation) be;
			hoverAddedInformation = hte.addToTooltip(tooltip, isShifting);

			if (goggleAddedInformation && !hoverAddedInformation)
				tooltip.remove(tooltip.size() - 1);
		}

		if (be instanceof IDisplayAssemblyExceptions) {
			boolean exceptionAdded = ((IDisplayAssemblyExceptions) be).addExceptionToTooltip(tooltip);
			if (exceptionAdded) {
				hasHoveringInformation = true;
				hoverAddedInformation = true;
			}
		}

		if (!hasHoveringInformation)
			if (hasHoveringInformation =
				hoverAddedInformation = TrainRelocator.addToTooltip(tooltip, isShifting))
				hoverTicks = prevHoverTicks + 1;

		// break early if goggle or hover returned false when present
		if ((hasGoggleInformation && !goggleAddedInformation) && (hasHoveringInformation && !hoverAddedInformation)) {
			hoverTicks = 0;
			return;
		}

		// check for piston poles if goggles are worn
		class_2680 state = world.method_8320(pos);
		if (wearingGoggles && AllBlocks.PISTON_EXTENSION_POLE.has(state)) {
			class_2350[] directions = Iterate.directionsInAxis(state.method_11654(PistonExtensionPoleBlock.field_10927)
				.method_10166());
			int poles = 1;
			boolean pistonFound = false;
			for (class_2350 dir : directions) {
				int attachedPoles = PistonExtensionPoleBlock.PlacementHelper.get()
					.attachedPoles(world, pos, dir);
				poles += attachedPoles;
				pistonFound |= world.method_8320(pos.method_10079(dir, attachedPoles + 1))
					.method_26204() instanceof MechanicalPistonBlock;
			}

			if (!pistonFound) {
				hoverTicks = 0;
				return;
			}
			if (!tooltip.isEmpty())
				tooltip.add(class_5244.field_39003);

			CreateLang.translate("gui.goggles.pole_length")
				.text(" " + poles)
				.forGoggles(tooltip);
		}

		if (tooltip.isEmpty()) {
			hoverTicks = 0;
			return;
		}

		class_4587 poseStack = guiGraphics.method_51448();
		poseStack.method_22903();

		int tooltipTextWidth = 0;
		for (class_5348 textLine : tooltip) {
			int textLineWidth = mc.field_1772.method_27525(textLine);
			if (textLineWidth > tooltipTextWidth)
				tooltipTextWidth = textLineWidth;
		}

		int tooltipHeight = 8;
		if (tooltip.size() > 1) {
			tooltipHeight += 2; // gap between title lines and next lines
			tooltipHeight += (tooltip.size() - 1) * 10;
		}

		int width = guiGraphics.method_51421();
		int height = guiGraphics.method_51443();

		CClient cfg = AllConfigs.client();
		int posX = width / 2 + cfg.overlayOffsetX.get();
		int posY = height / 2 + cfg.overlayOffsetY.get();

		posX = Math.min(posX, width - tooltipTextWidth - 20);
		posY = Math.min(posY, height - tooltipHeight - 20);

		float fade = class_3532.method_15363((hoverTicks + deltaTracker.method_60637(false)) / 24f, 0, 1);
		Boolean useCustom = cfg.overlayCustomColor.get();
		Color colorBackground = useCustom ? new Color(cfg.overlayBackgroundColor.get())
			: BoxElement.COLOR_VANILLA_BACKGROUND.scaleAlpha(.75f);
		Color colorBorderTop = useCustom ? new Color(cfg.overlayBorderColorTop.get())
			: BoxElement.COLOR_VANILLA_BORDER.getFirst().copy();
		Color colorBorderBot = useCustom ? new Color(cfg.overlayBorderColorBot.get())
			: BoxElement.COLOR_VANILLA_BORDER.getSecond().copy();

		if (fade < 1) {
			poseStack.method_22904(Math.pow(1 - fade, 3) * Math.signum(cfg.overlayOffsetX.get() + .5f) * 8, 0, 0);
			colorBackground.scaleAlpha(fade);
			colorBorderTop.scaleAlpha(fade);
			colorBorderBot.scaleAlpha(fade);
		}

		GuiGameElement.of(item)
			.at(posX + 10, posY - 16, 450)
			.render(guiGraphics);

		if (!Mods.MODERNUI.isLoaded()) {
			// default tooltip rendering when modernUI is not loaded
			RemovedGuiUtils.drawHoveringText(guiGraphics, tooltip, posX, posY, width, height, -1, colorBackground.getRGB(),
				colorBorderTop.getRGB(), colorBorderBot.getRGB(), mc.field_1772);

			poseStack.method_22909();

			return;
		}

		/*
		 * special handling for modernUI
		 *
		 * their tooltip handler causes the overlay to jiggle each frame,
		 * if the mouse is moving, guiScale is anything but 1 and exactPositioning is enabled
		 *
		 * this is a workaround to fix this behavior
		 */
		class_312 mouseHandler = class_310.method_1551().field_1729;
		class_1041 window = class_310.method_1551().method_22683();
		double guiScale = window.method_4495();
		double cursorX = mouseHandler.method_1603();
		double cursorY = mouseHandler.method_1604();
		((MouseHandlerAccessor) mouseHandler).create$setXPos(Math.round(cursorX / guiScale) * guiScale);
		((MouseHandlerAccessor) mouseHandler).create$setYPos(Math.round(cursorY / guiScale) * guiScale);

		RemovedGuiUtils.drawHoveringText(guiGraphics, tooltip, posX, posY, width, height, -1, colorBackground.getRGB(),
			colorBorderTop.getRGB(), colorBorderBot.getRGB(), mc.field_1772);

		((MouseHandlerAccessor) mouseHandler).create$setXPos(cursorX);
		((MouseHandlerAccessor) mouseHandler).create$setYPos(cursorY);
		poseStack.method_22909();

	}

	public static class_2338 proxiedOverlayPosition(class_1937 level, class_2338 pos) {
		class_2680 targetedState = level.method_8320(pos);
		if (targetedState.method_26204() instanceof IProxyHoveringInformation proxy)
			return proxy.getInformationSource(level, pos, targetedState);
		return pos;
	}

}
