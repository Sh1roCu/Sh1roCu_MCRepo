package com.simibubi.create.content.decoration.palettes;

import net.minecraft.class_2389;

public class GlassPaneBlock extends class_2389 {

	public GlassPaneBlock(class_2251 builder) {
		super(builder);
	}

}
