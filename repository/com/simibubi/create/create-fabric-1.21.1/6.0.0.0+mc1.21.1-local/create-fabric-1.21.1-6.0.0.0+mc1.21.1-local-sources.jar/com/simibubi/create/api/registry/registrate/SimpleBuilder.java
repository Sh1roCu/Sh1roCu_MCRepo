package com.simibubi.create.api.registry.registrate;

import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.api.registry.SimpleRegistry;
import com.simibubi.create.api.registry.SimpleRegistry.Provider;
import com.simibubi.create.impl.registry.TagProviderImpl;
import com.tterrag.registrate.AbstractRegistrate;
import com.tterrag.registrate.builders.AbstractBuilder;
import com.tterrag.registrate.builders.BuilderCallback;

public class SimpleBuilder<R, T extends R, P> extends AbstractBuilder<R, T, P, SimpleBuilder<R, T, P>> {
	private final Supplier<T> value;

	private SimpleRegistryAccess<class_2248, R> byBlock;
	private SimpleRegistryAccess<class_2591<?>, R> byBlockEntity;
	private SimpleRegistryAccess<class_1299<?>, R> byEntity;
	private SimpleRegistryAccess<class_3611, R> byFluid;

	public SimpleBuilder(AbstractRegistrate<?> owner, P parent, String name, BuilderCallback callback, class_5321<class_2378<R>> registryKey, Supplier<T> value) {
		super(owner, parent, name, callback, registryKey);
		this.value = value;
	}

	@Override
	protected T createEntry() {
		return this.value.get();
	}

	// for setup

	@SuppressWarnings("deprecation")
	public SimpleBuilder<R, T, P> byBlock(SimpleRegistry<class_2248, R> registry) {
		this.byBlock = SimpleRegistryAccess.of(registry, class_2248::method_40142);
		return this;
	}

	@SuppressWarnings("deprecation")
	public SimpleBuilder<R, T, P> byBlock(SimpleRegistry.Multi<class_2248, R> registry) {
		this.byBlock = SimpleRegistryAccess.of(registry, class_2248::method_40142);
		return this;
	}

	public SimpleBuilder<R, T, P> byBlockEntity(SimpleRegistry<class_2591<?>, R> registry) {
		this.byBlockEntity = SimpleRegistryAccess.of(registry, TagProviderImpl::getBeHolder);
		return this;
	}

	public SimpleBuilder<R, T, P> byBlockEntity(SimpleRegistry.Multi<class_2591<?>, R> registry) {
		this.byBlockEntity = SimpleRegistryAccess.of(registry, TagProviderImpl::getBeHolder);
		return this;
	}

	@SuppressWarnings("deprecation")
	public SimpleBuilder<R, T, P> byEntity(SimpleRegistry<class_1299<?>, R> registry) {
		this.byEntity = SimpleRegistryAccess.of(registry, class_1299::method_40124);
		return this;
	}

	@SuppressWarnings("deprecation")
	public SimpleBuilder<R, T, P> byEntity(SimpleRegistry.Multi<class_1299<?>, R> registry) {
		this.byEntity = SimpleRegistryAccess.of(registry, class_1299::method_40124);
		return this;
	}

	@SuppressWarnings("deprecation")
	public SimpleBuilder<R, T, P> byFluid(SimpleRegistry<class_3611, R> registry) {
		this.byFluid = SimpleRegistryAccess.of(registry, class_3611::method_40178);
		return this;
	}

	@SuppressWarnings("deprecation")
	public SimpleBuilder<R, T, P> byFluid(SimpleRegistry.Multi<class_3611, R> registry) {
		this.byFluid = SimpleRegistryAccess.of(registry, class_3611::method_40178);
		return this;
	}

	// association methods

	public SimpleBuilder<R, T, P> associate(class_2248 block) {
		assertPresent(this.byBlock, "Block");
		this.onRegister(value -> this.byBlock.adder.accept(block, value));
		return this;
	}

	public SimpleBuilder<R, T, P> associateBlockTag(class_6862<class_2248> tag) {
		assertPresent(this.byBlock, "Block");
		this.onRegister(value -> this.byBlock.tagAdder.accept(tag, value));
		return this;
	}

	public SimpleBuilder<R, T, P> associate(class_2591<?> type) {
		assertPresent(this.byBlockEntity, "BlockEntityType");
		this.onRegister(value -> this.byBlockEntity.adder.accept(type, value));
		return this;
	}

	public SimpleBuilder<R, T, P> associateBeTag(class_6862<class_2591<?>> tag) {
		assertPresent(this.byBlockEntity, "BlockEntityType");
		this.onRegister(value -> this.byBlockEntity.tagAdder.accept(tag, value));
		return this;
	}

	public SimpleBuilder<R, T, P> associate(class_1299<?> type) {
		assertPresent(this.byEntity, "EntityType");
		this.onRegister(value -> this.byEntity.adder.accept(type, value));
		return this;
	}

	public SimpleBuilder<R, T, P> associateEntityTag(class_6862<class_1299<?>> tag) {
		assertPresent(this.byEntity, "EntityType");
		this.onRegister(value -> this.byEntity.tagAdder.accept(tag, value));
		return this;
	}

	public SimpleBuilder<R, T, P> associate(class_3611 fluid) {
		assertPresent(this.byFluid, "Fluid");
		this.onRegister(value -> this.byFluid.adder.accept(fluid, value));
		return this;
	}

	public SimpleBuilder<R, T, P> associateFluidTag(class_6862<class_3611> tag) {
		assertPresent(this.byFluid, "Fluid");
		this.onRegister(value -> this.byFluid.tagAdder.accept(tag, value));
		return this;
	}

	private static void assertPresent(@Nullable Object object, String type) {
		if (object == null) {
			throw new IllegalStateException("This type does not support " + type + " associations");
		}
	}

	protected record SimpleRegistryAccess<K, V>(BiConsumer<K, V> adder, BiConsumer<class_6862<K>, V> tagAdder) {
		public static <K, V> SimpleRegistryAccess<K, V> of(SimpleRegistry<K, V> registry, Function<K, class_6880<K>> holderGetter) {
			return new SimpleRegistryAccess<>(
				registry::register,
				(tag, value) -> registry.registerProvider(Provider.forTag(tag, holderGetter, value))
			);
		}

		public static <K, V> SimpleRegistryAccess<K, V> of(SimpleRegistry.Multi<K, V> registry, Function<K, class_6880<K>> holderGetter) {
			return new SimpleRegistryAccess<>(
				registry::add,
				(tag, value) -> registry.addProvider(Provider.forTag(tag, holderGetter, value))
			);
		}
	}
}
