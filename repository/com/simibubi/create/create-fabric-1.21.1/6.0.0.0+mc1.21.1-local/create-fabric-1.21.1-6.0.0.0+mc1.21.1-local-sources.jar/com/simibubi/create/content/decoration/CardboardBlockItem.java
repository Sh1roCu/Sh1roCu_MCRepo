package com.simibubi.create.content.decoration;

import net.minecraft.class_1747;
import net.minecraft.class_2248;

public class CardboardBlockItem extends class_1747 {

	public CardboardBlockItem(class_2248 pBlock, class_1793 pProperties) {
		super(pBlock, pProperties);
	}

}
