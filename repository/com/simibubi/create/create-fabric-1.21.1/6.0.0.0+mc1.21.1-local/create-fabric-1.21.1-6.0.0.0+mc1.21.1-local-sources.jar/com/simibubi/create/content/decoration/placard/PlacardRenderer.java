package com.simibubi.create.content.decoration.placard;

import com.simibubi.create.foundation.blockEntity.renderer.SafeBlockEntityRenderer;

import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.math.AngleHelper;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2738;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_811;
import net.minecraft.class_918;

public class PlacardRenderer extends SafeBlockEntityRenderer<PlacardBlockEntity> {

	public PlacardRenderer(class_5614.class_5615 context) {}

	@Override
	protected void renderSafe(PlacardBlockEntity be, float partialTicks, class_4587 ms, class_4597 buffer,
		int light, int overlay) {
		class_1799 heldItem = be.getHeldItem();
		if (heldItem.method_7960())
			return;

		class_2680 blockState = be.method_11010();
		class_2350 facing = blockState.method_11654(PlacardBlock.field_11177);
		class_2738 face = blockState.method_11654(PlacardBlock.field_11007);

		class_918 itemRenderer = class_310.method_1551()
			.method_1480();
		class_1087 bakedModel = itemRenderer.method_4019(heldItem, null, null, 0);
		boolean blockItem = bakedModel.method_4712();

		ms.method_22903();
		TransformStack.of(ms)
			.center()
			.rotate((face == class_2738.field_12473 ? class_3532.field_29844 : 0) + AngleHelper.rad(180 + AngleHelper.horizontalAngle(facing)),
				class_2350.field_11036)
			.rotate(face == class_2738.field_12473 ? -class_3532.field_29844 / 2 : face == class_2738.field_12475 ? class_3532.field_29844 / 2 : 0,
				class_2350.field_11034)
			.translate(0, 0, 4.5 / 16f)
			.scale(blockItem ? .5f : .375f);

		itemRenderer.method_23179(heldItem, class_811.field_4319, false, ms, buffer, light, overlay, bakedModel);
		ms.method_22909();
	}

}
