package com.simibubi.create.content.contraptions.behaviour;

import com.simibubi.create.content.contraptions.Contraption;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

public class TrapdoorMovingInteraction extends SimpleBlockMovingInteraction {

	@Override
	protected class_2680 handle(class_1657 player, Contraption contraption, class_2338 pos, class_2680 currentState) {
		class_3414 sound = currentState.method_11654(class_2533.field_11631) ? class_3417.field_15080
			: class_3417.field_14932;
		float pitch = player.method_37908().field_9229.method_43057() * 0.1F + 0.9F;
		playSound(player, sound, pitch);
		return currentState.method_28493(class_2533.field_11631);
	}

	@Override
	protected boolean updateColliders() {
		return true;
	}

}
