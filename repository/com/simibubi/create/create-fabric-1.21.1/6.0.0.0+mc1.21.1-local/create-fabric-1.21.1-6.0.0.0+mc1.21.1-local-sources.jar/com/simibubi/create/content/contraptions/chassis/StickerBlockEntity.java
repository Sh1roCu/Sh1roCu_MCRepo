package com.simibubi.create.content.contraptions.chassis;

import java.util.List;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.content.contraptions.glue.SuperGlueEntity;
import com.simibubi.create.content.contraptions.glue.SuperGlueItem;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.tterrag.registrate.fabric.EnvExecutor;

import dev.engine_room.flywheel.lib.visualization.VisualizationHelper;
import net.createmod.catnip.platform.CatnipServices;
import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.catnip.animation.LerpedFloat.Chaser;

import net.fabricmc.api.EnvType;

import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_7225;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class StickerBlockEntity extends SmartBlockEntity {

	LerpedFloat piston;
	boolean update;

	public StickerBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		piston = LerpedFloat.linear();
		update = false;
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {}

	@Override
	public void initialize() {
		super.initialize();
		if (!field_11863.field_9236)
			return;
		piston.startWithValue(isBlockStateExtended() ? 1 : 0);
	}

	public boolean isBlockStateExtended() {
		class_2680 blockState = method_11010();
		boolean extended = AllBlocks.STICKER.has(blockState) && blockState.method_11654(StickerBlock.EXTENDED);
		return extended;
	}

	@Override
	public void tick() {
		super.tick();
		if (!field_11863.field_9236)
			return;
		piston.tickChaser();

		if (isAttachedToBlock() && piston.getValue(0) != piston.getValue() && piston.getValue() == 1) {
			SuperGlueItem.spawnParticles(field_11863, field_11867, method_11010().method_11654(StickerBlock.field_10927), true);
			CatnipServices.PLATFORM.executeOnClientOnly(() -> () -> playSound(true));
		}

		if (!update)
			return;
		update = false;
		int target = isBlockStateExtended() ? 1 : 0;
		if (isAttachedToBlock() && target == 0 && piston.getChaseTarget() == 1)
			CatnipServices.PLATFORM.executeOnClientOnly(() -> () -> playSound(false));
		piston.chase(target, .4f, Chaser.LINEAR);

		CatnipServices.PLATFORM.executeOnClientOnly(() -> () -> VisualizationHelper.queueUpdate(this));
	}

	public boolean isAttachedToBlock() {
		class_2680 blockState = method_11010();
		if (!AllBlocks.STICKER.has(blockState))
			return false;
		class_2350 direction = blockState.method_11654(StickerBlock.field_10927);
		return SuperGlueEntity.isValidFace(field_11863, field_11867.method_10093(direction), direction.method_10153());
	}

	@Override
	protected void write(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		super.write(tag, registries, clientPacket);
	}

	@Override
	protected void read(class_2487 compound, class_7225.class_7874 registries, boolean clientPacket) {
		super.read(compound, registries, clientPacket);
		if (clientPacket)
			update = true;
	}

	@Environment(EnvType.CLIENT)
	public void playSound(boolean attach) {
		AllSoundEvents.SLIME_ADDED.play(field_11863, class_310.method_1551().field_1724, field_11867, 0.35f, attach ? 0.75f : 0.2f);
	}


}
