package com.simibubi.create;

import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_2073;
import net.minecraft.class_223;
import net.minecraft.class_5321;
import net.minecraft.class_6885;
import net.minecraft.class_7871;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.class_9274;
import net.minecraft.class_9701;
import net.minecraft.class_9704;
import net.minecraft.class_9733;

public class AllEnchantments {
	public static final class_5321<class_1887>
			POTATO_RECOVERY = key("potato_recovery"),
			CAPACITY = key("capacity");

	private static class_5321<class_1887> key(String name) {
		return class_5321.method_29179(class_7924.field_41265, Create.asResource(name));
	}

	public static void bootstrap(class_7891<class_1887> context) {
		class_7871<class_1792> itemHolderGetter = context.method_46799(class_7924.field_41197);

		register(
				context,
				POTATO_RECOVERY,
				class_1887.method_60030(
						class_1887.method_58442(
								class_6885.method_40246(AllItems.POTATO_CANNON),
								10,
								3,
								class_1887.method_58441(15, 15),
								class_1887.method_58441(45, 15),
								1,
								class_9274.field_49217
						)
				).method_60067(
						class_9701.field_51672,
						new class_9733(class_9704.method_60187(0.0F, 33.3333333333F)),
						class_223.method_945(
								class_2073.class_2074.method_8973().method_8977() // TODO - Fix potato recovery
						)
				)
		);

		register(
				context,
				CAPACITY,
				class_1887.method_60030(
						class_1887.method_58442(
								itemHolderGetter.method_46735(AllTags.AllItemTags.PRESSURIZED_AIR_SOURCES.tag),
								10,
								3,
								class_1887.method_58441(15, 15),
								class_1887.method_58441(45, 15),
								1,
								class_9274.field_49217
						)
				)
		);
	}

	private static void register(class_7891<class_1887> context, class_5321<class_1887> key, class_1887.class_9700 builder) {
		context.method_46838(key, builder.method_60060(key.method_29177()));
	}

}
