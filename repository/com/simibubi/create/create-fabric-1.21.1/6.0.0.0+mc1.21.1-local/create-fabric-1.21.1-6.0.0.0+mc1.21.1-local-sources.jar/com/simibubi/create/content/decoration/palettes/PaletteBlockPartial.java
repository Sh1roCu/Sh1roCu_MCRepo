package com.simibubi.create.content.decoration.palettes;

import static com.simibubi.create.foundation.data.TagGen.pickaxeOnly;

import java.util.Arrays;
import java.util.function.Supplier;

import com.simibubi.create.Create;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.builders.ItemBuilder;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import com.tterrag.registrate.providers.RegistrateRecipeProvider;
import com.tterrag.registrate.util.DataIngredient;
import com.tterrag.registrate.util.entry.BlockEntry;
import com.tterrag.registrate.util.nullness.NonnullType;

import net.createmod.catnip.lang.Lang;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2482;
import net.minecraft.class_2510;
import net.minecraft.class_2544;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_6862;
import net.minecraft.class_7800;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;

public abstract class PaletteBlockPartial<B extends class_2248> {

	public static final PaletteBlockPartial<class_2510> STAIR = new Stairs();
	public static final PaletteBlockPartial<class_2482> SLAB = new Slab(false);
	public static final PaletteBlockPartial<class_2482> UNIQUE_SLAB = new Slab(true);
	public static final PaletteBlockPartial<class_2544> WALL = new Wall();

	public static final PaletteBlockPartial<?>[] ALL_PARTIALS = {STAIR, SLAB, WALL};
	public static final PaletteBlockPartial<?>[] FOR_POLISHED = {STAIR, UNIQUE_SLAB, WALL};

	private String name;

	private PaletteBlockPartial(String name) {
		this.name = name;
	}

	public @NonnullType BlockBuilder<B, CreateRegistrate> create(String variantName, PaletteBlockPattern pattern,
																 BlockEntry<? extends class_2248> block, AllPaletteStoneTypes variant) {
		String patternName = Lang.nonPluralId(pattern.createName(variantName));
		String blockName = patternName + "_" + this.name;

		BlockBuilder<B, CreateRegistrate> blockBuilder = Create.registrate()
			.block(blockName, p -> createBlock(block))
			.blockstate((c, p) -> generateBlockState(c, p, variantName, pattern, block))
			.recipe((c, p) -> createRecipes(variant, block, c, p))
			.transform(b -> transformBlock(b, variantName, pattern));

		ItemBuilder<class_1747, BlockBuilder<B, CreateRegistrate>> itemBuilder = blockBuilder.item()
			.transform(b -> transformItem(b, variantName, pattern));

		if (canRecycle())
			itemBuilder.tag(variant.materialTag);

		return itemBuilder.build();
	}

	protected class_2960 getTexture(String variantName, PaletteBlockPattern pattern, int index) {
		return PaletteBlockPattern.toLocation(variantName, pattern.getTexture(index));
	}

	protected BlockBuilder<B, CreateRegistrate> transformBlock(BlockBuilder<B, CreateRegistrate> builder,
															   String variantName, PaletteBlockPattern pattern) {
		getBlockTags().forEach(builder::tag);
		return builder.transform(pickaxeOnly());
	}

	protected ItemBuilder<class_1747, BlockBuilder<B, CreateRegistrate>> transformItem(
		ItemBuilder<class_1747, BlockBuilder<B, CreateRegistrate>> builder, String variantName,
		PaletteBlockPattern pattern) {
		getItemTags().forEach(builder::tag);
		return builder;
	}

	protected boolean canRecycle() {
		return true;
	}

	protected abstract Iterable<class_6862<class_2248>> getBlockTags();

	protected abstract Iterable<class_6862<class_1792>> getItemTags();

	protected abstract B createBlock(Supplier<? extends class_2248> block);

	protected abstract void createRecipes(AllPaletteStoneTypes type, BlockEntry<? extends class_2248> patternBlock,
										  DataGenContext<class_2248, ? extends class_2248> c, RegistrateRecipeProvider p);

	protected abstract void generateBlockState(DataGenContext<class_2248, B> ctx, RegistrateBlockstateProvider prov,
											   String variantName, PaletteBlockPattern pattern, Supplier<? extends class_2248> block);

	private static class Stairs extends PaletteBlockPartial<class_2510> {

		public Stairs() {
			super("stairs");
		}

		@Override
		protected class_2510 createBlock(Supplier<? extends class_2248> block) {
			return new class_2510(block.get().method_9564(), class_2251.method_9630(block.get()));
		}

		@Override
		protected void generateBlockState(DataGenContext<class_2248, class_2510> ctx, RegistrateBlockstateProvider prov,
										  String variantName, PaletteBlockPattern pattern, Supplier<? extends class_2248> block) {
			prov.stairsBlock(ctx.get(), getTexture(variantName, pattern, 0));
		}

		@Override
		protected Iterable<class_6862<class_2248>> getBlockTags() {
			return Arrays.asList(class_3481.field_15459);
		}

		@Override
		protected Iterable<class_6862<class_1792>> getItemTags() {
			return Arrays.asList(class_3489.field_15526);
		}

		@Override
		protected void createRecipes(AllPaletteStoneTypes type, BlockEntry<? extends class_2248> patternBlock,
									 DataGenContext<class_2248, ? extends class_2248> c, RegistrateRecipeProvider p) {
			class_7800 category = class_7800.field_40634;
			p.stairs(DataIngredient.items(patternBlock.get()), category, c::get, c.getName(), false);
			p.stonecutting(DataIngredient.tag(type.materialTag), category, c::get, 1);
		}

	}

	private static class Slab extends PaletteBlockPartial<class_2482> {

		private boolean customSide;

		public Slab(boolean customSide) {
			super("slab");
			this.customSide = customSide;
		}

		@Override
		protected class_2482 createBlock(Supplier<? extends class_2248> block) {
			return new class_2482(class_2251.method_9630(block.get()));
		}

		@Override
		protected boolean canRecycle() {
			return false;
		}

		@Override
		protected void generateBlockState(DataGenContext<class_2248, class_2482> ctx, RegistrateBlockstateProvider prov,
										  String variantName, PaletteBlockPattern pattern, Supplier<? extends class_2248> block) {
			String name = ctx.getName();
			class_2960 mainTexture = getTexture(variantName, pattern, 0);
			class_2960 sideTexture = customSide ? getTexture(variantName, pattern, 1) : mainTexture;

			ModelFile bottom = prov.models()
				.slab(name, sideTexture, mainTexture, mainTexture);
			ModelFile top = prov.models()
				.slabTop(name + "_top", sideTexture, mainTexture, mainTexture);
			ModelFile doubleSlab;

			if (customSide) {
				doubleSlab = prov.models()
					.cubeColumn(name + "_double", sideTexture, mainTexture);
			} else {
				doubleSlab = prov.models()
					.getExistingFile(prov.modLoc(pattern.createName(variantName)));
			}

			prov.slabBlock(ctx.get(), bottom, top, doubleSlab);
		}

		@Override
		protected Iterable<class_6862<class_2248>> getBlockTags() {
			return Arrays.asList(class_3481.field_15469);
		}

		@Override
		protected Iterable<class_6862<class_1792>> getItemTags() {
			return Arrays.asList(class_3489.field_15535);
		}

		@Override
		protected void createRecipes(AllPaletteStoneTypes type, BlockEntry<? extends class_2248> patternBlock,
									 DataGenContext<class_2248, ? extends class_2248> c, RegistrateRecipeProvider p) {
			class_7800 category = class_7800.field_40634;
			p.slab(DataIngredient.items(patternBlock.get()), category, c::get, c.getName(), false);
			p.stonecutting(DataIngredient.tag(type.materialTag), category, c::get, 2);
			DataIngredient ingredient = DataIngredient.items(c.get());
			class_2450.method_10447(category, patternBlock.get())
				.method_10451(ingredient.toVanilla())
				.method_10451(ingredient.toVanilla())
				.method_10442("has_" + c.getName(), ingredient.getCriterion(p))
				.method_36443(p, Create.ID + ":" + c.getName() + "_recycling");
		}

		@Override
		protected BlockBuilder<class_2482, CreateRegistrate> transformBlock(
				BlockBuilder<class_2482, CreateRegistrate> builder,
				String variantName, PaletteBlockPattern pattern) {
			builder.loot((lt, block) -> lt.method_45988(block, lt.method_45980(block)));
			return super.transformBlock(builder, variantName, pattern);
		}

	}

	private static class Wall extends PaletteBlockPartial<class_2544> {

		public Wall() {
			super("wall");
		}

		@Override
		protected class_2544 createBlock(Supplier<? extends class_2248> block) {
			return new class_2544(class_2251.method_9630(block.get()).method_51369());
		}

		@Override
		protected ItemBuilder<class_1747, BlockBuilder<class_2544, CreateRegistrate>> transformItem(
			ItemBuilder<class_1747, BlockBuilder<class_2544, CreateRegistrate>> builder, String variantName,
			PaletteBlockPattern pattern) {
			builder.model((c, p) -> p.wallInventory(c.getName(), getTexture(variantName, pattern, 0)));
			return super.transformItem(builder, variantName, pattern);
		}

		@Override
		protected void generateBlockState(DataGenContext<class_2248, class_2544> ctx, RegistrateBlockstateProvider prov,
										  String variantName, PaletteBlockPattern pattern, Supplier<? extends class_2248> block) {
			prov.wallBlock(ctx.get(), pattern.createName(variantName), getTexture(variantName, pattern, 0));
		}

		@Override
		protected Iterable<class_6862<class_2248>> getBlockTags() {
			return Arrays.asList(class_3481.field_15504);
		}

		@Override
		protected Iterable<class_6862<class_1792>> getItemTags() {
			return Arrays.asList(class_3489.field_15560);
		}

		@Override
		protected void createRecipes(AllPaletteStoneTypes type, BlockEntry<? extends class_2248> patternBlock,
									 DataGenContext<class_2248, ? extends class_2248> c, RegistrateRecipeProvider p) {
			class_7800 category = class_7800.field_40634;
			p.stonecutting(DataIngredient.tag(type.materialTag), category, c::get, 1);
			DataIngredient ingredient = DataIngredient.items(patternBlock.get());
			class_2447.method_10436(category, c.get(), 6)
				.method_10439("XXX")
				.method_10439("XXX")
				.method_10428('X', ingredient.toVanilla())
				.method_10429("has_" + p.safeName(ingredient), ingredient.getCriterion(p))
				.method_17972(p, p.safeId(c.get()));
		}

	}

}
