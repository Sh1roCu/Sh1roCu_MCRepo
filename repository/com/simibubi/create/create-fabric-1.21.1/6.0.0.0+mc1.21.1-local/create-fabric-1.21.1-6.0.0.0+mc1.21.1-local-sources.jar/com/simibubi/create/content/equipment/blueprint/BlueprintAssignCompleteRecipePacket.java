package com.simibubi.create.content.equipment.blueprint;

import com.simibubi.create.AllPackets;

import io.netty.buffer.ByteBuf;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_9139;

public record BlueprintAssignCompleteRecipePacket(class_2960 recipeId) implements ServerboundPacketPayload {
	public static final class_9139<ByteBuf, com.simibubi.create.content.equipment.blueprint.BlueprintAssignCompleteRecipePacket> STREAM_CODEC = class_2960.field_48267.method_56432(
			com.simibubi.create.content.equipment.blueprint.BlueprintAssignCompleteRecipePacket::new, com.simibubi.create.content.equipment.blueprint.BlueprintAssignCompleteRecipePacket::recipeId
	);

	@Override
	public void handle(class_3222 player) {
		if (player.field_7512 instanceof BlueprintMenu c) {
			player.method_37908()
					.method_8433()
					.method_8130(recipeId)
					.ifPresent(r -> BlueprintItem.assignCompleteRecipe(c.player.method_37908(), c.ghostInventory, r.comp_1933()));
		}
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.BLUEPRINT_COMPLETE_RECIPE;
	}
}
