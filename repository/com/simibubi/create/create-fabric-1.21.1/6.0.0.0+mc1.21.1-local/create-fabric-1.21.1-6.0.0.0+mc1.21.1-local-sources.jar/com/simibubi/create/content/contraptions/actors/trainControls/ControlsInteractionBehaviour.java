package com.simibubi.create.content.contraptions.actors.trainControls;

import java.util.UUID;

import com.google.common.base.Objects;
import com.simibubi.create.AllItems;
import com.simibubi.create.api.behaviour.interaction.MovingInteractionBehaviour;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.foundation.utility.AdventureUtil;
import com.tterrag.registrate.fabric.EnvExecutor;
import net.fabricmc.api.EnvType;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2338;

public class ControlsInteractionBehaviour extends MovingInteractionBehaviour {

	@Override
	public boolean handlePlayerInteraction(class_1657 player, class_1268 activeHand, class_2338 localPos,
		AbstractContraptionEntity contraptionEntity) {
		if (AdventureUtil.isAdventure(player))
			return false;
		if (AllItems.WRENCH.isIn(player.method_5998(activeHand)))
			return false;

		UUID currentlyControlling = contraptionEntity.getControllingPlayer()
			.orElse(null);

		if (currentlyControlling != null) {
			contraptionEntity.stopControlling(localPos);
			if (Objects.equal(currentlyControlling, player.method_5667()))
				return true;
		}

		if (!contraptionEntity.startControlling(localPos, player))
			return false;

		contraptionEntity.setControllingPlayer(player.method_5667());
		if (player.method_37908().field_9236)
			ControlsHandler.startControlling(contraptionEntity, localPos);
		return true;
	}

}
