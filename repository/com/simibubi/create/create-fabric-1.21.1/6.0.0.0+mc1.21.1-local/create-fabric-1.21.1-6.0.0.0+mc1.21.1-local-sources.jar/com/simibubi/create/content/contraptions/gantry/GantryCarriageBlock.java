package com.simibubi.create.content.contraptions.gantry;

import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.kinetics.base.DirectionalAxisKineticBlock;
import com.simibubi.create.content.kinetics.base.IRotate;
import com.simibubi.create.content.kinetics.gantry.GantryShaftBlock;
import com.simibubi.create.foundation.block.IBE;

import net.createmod.catnip.data.Iterate;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_9062;

public class GantryCarriageBlock extends DirectionalAxisKineticBlock implements IBE<GantryCarriageBlockEntity> {

	public GantryCarriageBlock(class_2251 properties) {
		super(properties);
	}

	@Override
	public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
		class_2350 direction = state.method_11654(FACING);
		class_2680 shaft = world.method_8320(pos.method_10093(direction.method_10153()));
		return AllBlocks.GANTRY_SHAFT.has(shaft) && shaft.method_11654(GantryShaftBlock.FACING)
			.method_10166() != direction.method_10166();
	}

	@Override
	public void method_9517(class_2680 stateIn, class_1936 worldIn, class_2338 pos, int flags, int count) {
		super.method_9517(stateIn, worldIn, pos, flags, count);
		withBlockEntityDo(worldIn, pos, GantryCarriageBlockEntity::checkValidGantryShaft);
	}

	@Override
	public void method_9615(class_2680 state, class_1937 worldIn, class_2338 pos, class_2680 oldState, boolean isMoving) {
		super.method_9615(state, worldIn, pos, oldState, isMoving);
	}

	@Override
	protected class_2350 getFacingForPlacement(class_1750 context) {
		return context.method_8038();
	}

	@Override
	protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
		if (!player.method_7294() || player.method_5715())
			return class_9062.field_47731;
		if (stack.method_7960()) {
			withBlockEntityDo(level, pos, be -> be.checkValidGantryShaft());
			return class_9062.field_47728;
		}
		return class_9062.field_47731;
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		class_2680 stateForPlacement = super.method_9605(context);
		class_2350 opposite = stateForPlacement.method_11654(FACING)
			.method_10153();
		return cycleAxisIfNecessary(stateForPlacement, opposite, context.method_8045()
			.method_8320(context.method_8037()
				.method_10093(opposite)));
	}

	@Override
	public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 p_220069_4_, class_2338 updatePos,
								boolean p_220069_6_) {
		if (updatePos.equals(pos.method_10093(state.method_11654(FACING)
			.method_10153())) && !method_9558(state, world, pos))
			world.method_22352(pos, true);
	}

	@Override
	public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 otherState, class_1936 world,
								  class_2338 pos, class_2338 p_196271_6_) {
		if (state.method_11654(FACING) != direction.method_10153())
			return state;
		return cycleAxisIfNecessary(state, direction, otherState);
	}

	protected class_2680 cycleAxisIfNecessary(class_2680 state, class_2350 direction, class_2680 otherState) {
		if (!AllBlocks.GANTRY_SHAFT.has(otherState))
			return state;
		if (otherState.method_11654(GantryShaftBlock.FACING)
			.method_10166() == direction.method_10166())
			return state;
		if (isValidGantryShaftAxis(state, otherState))
			return state;
		return state.method_28493(AXIS_ALONG_FIRST_COORDINATE);
	}

	public static boolean isValidGantryShaftAxis(class_2680 pinionState, class_2680 gantryState) {
		return getValidGantryShaftAxis(pinionState) == gantryState.method_11654(GantryShaftBlock.FACING)
			.method_10166();
	}

	public static class_2351 getValidGantryShaftAxis(class_2680 state) {
		if (!(state.method_26204() instanceof GantryCarriageBlock block))
			return class_2351.field_11052;
		class_2351 rotationAxis = block.getRotationAxis(state);
		class_2351 facingAxis = state.method_11654(FACING)
			.method_10166();
		for (class_2351 axis : Iterate.axes)
			if (axis != rotationAxis && axis != facingAxis)
				return axis;
		return class_2351.field_11052;
	}

	public static class_2351 getValidGantryPinionAxis(class_2680 state, class_2351 shaftAxis) {
		class_2351 facingAxis = state.method_11654(FACING)
			.method_10166();
		for (class_2351 axis : Iterate.axes)
			if (axis != shaftAxis && axis != facingAxis)
				return axis;
		return class_2351.field_11052;
	}

	@Override
	public Class<GantryCarriageBlockEntity> getBlockEntityClass() {
		return GantryCarriageBlockEntity.class;
	}

	@Override
	public class_2591<? extends GantryCarriageBlockEntity> getBlockEntityType() {
		return AllBlockEntityTypes.GANTRY_PINION.get();
	}

}
