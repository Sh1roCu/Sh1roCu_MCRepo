package com.simibubi.create.api.schematic.requirement;

import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import net.minecraft.class_2680;

public interface SpecialBlockEntityItemRequirement {
	ItemRequirement getRequiredItems(class_2680 state);
}
