package com.simibubi.create.content.equipment.bell;

import com.simibubi.create.AllPackets;
import com.simibubi.create.CreateClient;
import net.createmod.catnip.net.base.ClientboundPacketPayload;

import io.netty.buffer.ByteBuf;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SoulPulseEffectPacket(class_2338 pos, int distance, boolean canOverlap) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, SoulPulseEffectPacket> STREAM_CODEC = class_9139.method_56436(
	        class_2338.field_48404, SoulPulseEffectPacket::pos,
			class_9135.field_49675, SoulPulseEffectPacket::distance,
			class_9135.field_48547, SoulPulseEffectPacket::canOverlap,
	        SoulPulseEffectPacket::new
	);

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		CreateClient.SOUL_PULSE_EFFECT_HANDLER.addPulse(new SoulPulseEffect(pos, distance, canOverlap));
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.SOUL_PULSE;
	}
}
