package com.simibubi.create.api.behaviour.interaction;

import org.apache.commons.lang3.tuple.MutablePair;

import com.simibubi.create.api.registry.SimpleRegistry;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.tterrag.registrate.util.nullness.NonNullConsumer;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_3499.class_3501;

/**
 * MovingInteractionBehaviors define behavior of blocks on contraptions
 * when interacted with by players or collided with by entities.
 */
public abstract class MovingInteractionBehaviour {
	public static final SimpleRegistry<class_2248, MovingInteractionBehaviour> REGISTRY = SimpleRegistry.create();

	/**
	 * Creates a consumer that will register a behavior to a block. Useful for Registrate.
	 */
	public static <B extends class_2248> NonNullConsumer<? super B> interactionBehaviour(MovingInteractionBehaviour behaviour) {
		return b -> REGISTRY.register(b, behaviour);
	}

	protected void setContraptionActorData(AbstractContraptionEntity contraptionEntity, int index,
										   class_3501 info, MovementContext ctx) {
		contraptionEntity.getContraption().getActors().remove(index);
		contraptionEntity.getContraption().getActors().add(index, MutablePair.of(info, ctx));
		if (contraptionEntity.method_37908().field_9236)
			contraptionEntity.getContraption().deferInvalidate = true;
	}

	protected void setContraptionBlockData(AbstractContraptionEntity contraptionEntity, class_2338 pos,
		class_3501 info) {
		if (contraptionEntity.method_37908().method_8608())
			return;
		contraptionEntity.setBlock(pos, info);
	}

	public boolean handlePlayerInteraction(class_1657 player, class_1268 activeHand, class_2338 localPos,
		AbstractContraptionEntity contraptionEntity) {
		return true;
	}

	public void handleEntityCollision(class_1297 entity, class_2338 localPos, AbstractContraptionEntity contraptionEntity) {}

}
