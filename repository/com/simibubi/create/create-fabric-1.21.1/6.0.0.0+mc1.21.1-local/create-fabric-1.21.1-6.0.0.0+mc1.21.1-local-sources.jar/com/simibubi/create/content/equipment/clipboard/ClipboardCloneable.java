package com.simibubi.create.content.equipment.clipboard;

import net.minecraft.class_1657;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import org.jetbrains.annotations.NotNull;

public interface ClipboardCloneable {
	String getClipboardKey();

	boolean writeToClipboard(@NotNull class_7225.class_7874 registries, class_2487 tag, class_2350 side);

	boolean readFromClipboard(@NotNull class_7225.class_7874 registries, class_2487 tag, class_1657 player, class_2350 side, boolean simulate);
}
