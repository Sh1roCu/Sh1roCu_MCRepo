package com.simibubi.create.compat.computercraft;

import com.simibubi.create.AllPackets;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.SyncedBlockEntity;
import com.simibubi.create.foundation.networking.BlockEntityDataPacket;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2338;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class AttachedComputerPacket extends BlockEntityDataPacket<SyncedBlockEntity> {
	public static final class_9139<ByteBuf, AttachedComputerPacket> STREAM_CODEC = class_9139.method_56435(
			class_2338.field_48404, packet -> packet.pos,
			class_9135.field_48547, packet -> packet.hasAttachedComputer,
			AttachedComputerPacket::new
	);

	private final boolean hasAttachedComputer;

	public AttachedComputerPacket(class_2338 blockEntityPos, boolean hasAttachedComputer) {
		super(blockEntityPos);
		this.hasAttachedComputer = hasAttachedComputer;
	}

	@Override
	protected void handlePacket(SyncedBlockEntity blockEntity) {
		if (blockEntity instanceof SmartBlockEntity sbe) {
			sbe.getBehaviour(AbstractComputerBehaviour.TYPE)
				.setHasAttachedComputer(hasAttachedComputer);
		}
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.ATTACHED_COMPUTER;
	}
}
