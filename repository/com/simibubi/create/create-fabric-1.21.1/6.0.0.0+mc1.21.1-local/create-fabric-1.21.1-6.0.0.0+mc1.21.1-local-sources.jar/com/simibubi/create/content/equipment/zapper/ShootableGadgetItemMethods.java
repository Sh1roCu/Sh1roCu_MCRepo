package com.simibubi.create.content.equipment.zapper;

import java.util.function.Function;
import java.util.function.Predicate;

import com.simibubi.create.AllDataComponents;
import com.simibubi.create.AllPackets;

import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3222;

public class ShootableGadgetItemMethods {

	public static void applyCooldown(class_1657 player, class_1799 item, class_1268 hand, Predicate<class_1799> predicate,
		int cooldown) {
		if (cooldown <= 0)
			return;

		boolean gunInOtherHand =
			predicate.test(player.method_5998(hand == class_1268.field_5808 ? class_1268.field_5810 : class_1268.field_5808));
		player.method_7357()
			.method_7906(item.method_7909(), gunInOtherHand ? cooldown * 2 / 3 : cooldown);
	}

	public static void sendPackets(class_1657 player, Function<Boolean, ? extends ShootGadgetPacket> factory) {
		if (!(player instanceof class_3222))
			return;
		CatnipServices.NETWORK.sendToClientsTrackingEntity(player, factory.apply(false));
		CatnipServices.NETWORK.sendToClient((class_3222) player, factory.apply(true));
	}

	public static boolean shouldSwap(class_1657 player, class_1799 item, class_1268 hand, Predicate<class_1799> predicate) {
		boolean isSwap = item.method_57826(AllDataComponents.SHAPER_SWAP);
		boolean mainHand = hand == class_1268.field_5808;
		boolean gunInOtherHand = predicate.test(player.method_5998(mainHand ? class_1268.field_5810 : class_1268.field_5808));

		// Pass To Offhand
		if (mainHand && isSwap && gunInOtherHand)
			return true;
		if (mainHand && !isSwap && gunInOtherHand)
			item.method_57379(AllDataComponents.SHAPER_SWAP, true);
		if (!mainHand && isSwap)
			item.method_57381(AllDataComponents.SHAPER_SWAP);
		if (!mainHand && gunInOtherHand)
			player.method_5998(class_1268.field_5808).method_57381(AllDataComponents.SHAPER_SWAP);

		// (#574) fabric: on forge, this condition is patched into startUsingItem
		// skipping it causes an item to be used forever, only allowing 1 use before releasing and re-pressing the use button.
			if (item.method_7935(player) > 0) {
				player.method_6019(hand);
			}

		return false;
	}

	public static class_243 getGunBarrelVec(class_1657 player, boolean mainHand, class_243 rightHandForward) {
		class_243 start = player.method_19538()
			.method_1031(0, player.method_5751(), 0);
		float yaw = (float) ((player.method_36454()) / -180 * Math.PI);
		float pitch = (float) ((player.method_36455()) / -180 * Math.PI);
		int flip = mainHand == (player.method_6068() == class_1306.field_6183) ? -1 : 1;
		class_243 barrelPosNoTransform = new class_243(flip * rightHandForward.field_1352, rightHandForward.field_1351, rightHandForward.field_1350);
		class_243 barrelPos = start.method_1019(barrelPosNoTransform.method_1037(pitch)
			.method_1024(yaw));
		return barrelPos;
	}

}
