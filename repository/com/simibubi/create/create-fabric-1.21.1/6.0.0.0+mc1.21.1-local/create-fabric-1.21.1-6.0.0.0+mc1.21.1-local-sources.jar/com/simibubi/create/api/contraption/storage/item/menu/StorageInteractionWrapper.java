package com.simibubi.create.api.contraption.storage.item.menu;

import java.util.function.Consumer;
import java.util.function.Predicate;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import com.simibubi.create.infrastructure.fabric.transfer.item.SlottedStackStorage;

public class StorageInteractionWrapper implements class_1263 {
	private final SlottedStackStorage storage;
	private final Predicate<class_1657> stillValid;
	private final Consumer<class_1657> onClose;

	public StorageInteractionWrapper(SlottedStackStorage storage, Predicate<class_1657> stillValid, Consumer<class_1657> onClose) {
		this.storage = storage;
		this.stillValid = stillValid;
		this.onClose = onClose;
	}

	@Override
	public boolean method_5443(class_1657 player) {
		return this.stillValid.test(player);
	}

	@Override
	public void method_5432(class_1657 player) {
		this.onClose.accept(player);
	}

	@Override
	public int method_5439() {
		return this.storage.getSlotCount();
	}

	@Override
	public boolean method_5442() {
		return this.storage.nonEmptyIterator().hasNext();
	}

	@Override
	public class_1799 method_5438(int slot) {
		return this.storage.getStackInSlot(slot);
	}

	@Override
	public class_1799 method_5434(int index, int count) {
		if (index >= 0 && index < this.storage.getSlotCount()) {
			class_1799 current = this.storage.getStackInSlot(index);
			if (current.method_7960())
				return class_1799.field_8037;
			current = current.method_7972();
			class_1799 extracted = current.method_7971(count);
			this.storage.setStackInSlot(index, current);
			return extracted;
		}
		return class_1799.field_8037;
	}

	@Override
	public class_1799 method_5441(int index) {
		return method_5434(index, Integer.MAX_VALUE);
	}

	@Override
	public void method_5447(int slot, class_1799 stack) {
		this.storage.setStackInSlot(slot, stack);
	}

	@Override
	public void method_5431() {
	}

	@Override
	public boolean method_5437(int index, class_1799 stack) {
		return this.storage.isItemValid(index, ItemVariant.of(stack), stack.method_7947());
	}

	@Override
	public void method_5448() {
		for (int i = 0; i < this.storage.getSlotCount(); i++) {
			this.storage.setStackInSlot(i, class_1799.field_8037);
		}
	}
}
