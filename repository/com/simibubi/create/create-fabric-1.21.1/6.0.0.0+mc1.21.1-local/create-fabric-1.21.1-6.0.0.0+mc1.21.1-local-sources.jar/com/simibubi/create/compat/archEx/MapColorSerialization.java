package com.simibubi.create.compat.archEx;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_3620;

// https://github.com/DebuggyTeam/architecture-extensions/blob/1.20/src/main/java/io/github/debuggyteam/architecture_extensions/util/MapColors.java
public class MapColorSerialization {
	private static final Map<class_3620, String> names = new HashMap<>();

	static {
		// there's too many, so this is the bare minimum
		names.put(class_3620.field_15984, "blue");
		names.put(class_3620.field_16020, "red");
		names.put(class_3620.field_15986, "sand");
		names.put(class_3620.field_16013, "yellow_terracotta");
		names.put(class_3620.field_15977, "brown");
		names.put(class_3620.field_16027, "gray_terracotta");
		names.put(class_3620.field_25705, "warped_nylium");
		names.put(class_3620.field_16000, "dirt");
		names.put(class_3620.field_16025, "quartz");
		names.put(class_3620.field_16023, "stone");
		names.put(class_3620.field_16003, "white_terracotta");
		names.put(class_3620.field_15992, "brown_terracotta");
		names.put(class_3620.field_33532, "deepslate");
	}

	public static String getArchExName(class_3620 color) {
		String name = names.get(color);
		if (name == null)
			throw new IllegalArgumentException("Unsupported MapColor: " + color);
		return name;
	}
}
