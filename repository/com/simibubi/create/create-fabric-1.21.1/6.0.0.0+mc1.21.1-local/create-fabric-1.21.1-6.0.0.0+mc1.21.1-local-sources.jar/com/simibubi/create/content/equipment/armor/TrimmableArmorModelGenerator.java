package com.simibubi.create.content.equipment.armor;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.util.Map;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_4915;
import net.minecraft.class_4941;
import net.minecraft.class_4944;
import com.simibubi.create.Create;
import com.simibubi.create.foundation.mixin.accessor.ItemModelGeneratorsAccessor;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateItemModelProvider;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelBuilder;
import io.github.fabricators_of_create.porting_lib.models.generators.ItemModelBuilder;

public class TrimmableArmorModelGenerator {
	public static final VarHandle TEXTURES_HANDLE;

	static {
		try {
			MethodHandles.Lookup lookup = MethodHandles.privateLookupIn(ModelBuilder.class, MethodHandles.lookup());
			TEXTURES_HANDLE = lookup.findVarHandle(ModelBuilder.class, "textures", Map.class);
		} catch (IllegalAccessException | NoSuchFieldException e) {
			throw new RuntimeException(e);
		}
	}

	public static <T extends class_1738> void generate(DataGenContext<class_1792, T> c, RegistrateItemModelProvider p) {
		T item = c.get();
		ItemModelBuilder builder = p.generated(c);
		for (class_4915.class_8072 data : ItemModelGeneratorsAccessor.create$getGENERATED_TRIM_MODELS()) {
			class_2960 modelLoc = class_4941.method_25840(item);
			class_2960 textureLoc = class_4944.method_25876(item);
			String trimId = data.method_48744(item.method_7686());
			class_2960 trimModelLoc = modelLoc.method_48331("_" + trimId + "_trim");
			class_2960 trimLoc =
				class_2960.method_60656("trims/items/" + item.method_48398().method_48400() + "_trim_" + trimId);
			String parent = "item/generated";
			if (item.method_7686() == AllArmorMaterials.CARDBOARD) {
				trimLoc = Create.asResource("trims/items/card_" + item.method_48398().method_48400() + "_trim_" + trimId);
			}
			ItemModelBuilder itemModel = p.withExistingParent(trimModelLoc.method_12832(), parent)
				.texture("layer0", textureLoc);
			Map<String, String> textures = (Map<String, String>) TEXTURES_HANDLE.get(itemModel);
			textures.put("layer1", trimLoc.toString());
			builder.override()
				.predicate(class_4915.field_42086, data.comp_1220())
				.model(itemModel)
				.end();
		}
	}
}
