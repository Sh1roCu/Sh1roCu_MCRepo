package com.simibubi.create.content.contraptions.actors.harvester;

import com.mojang.serialization.MapCodec;
import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.content.contraptions.actors.AttachedActorBlock;
import com.simibubi.create.foundation.block.IBE;
import net.minecraft.class_2383;
import net.minecraft.class_2591;
import org.jetbrains.annotations.NotNull;

public class HarvesterBlock extends AttachedActorBlock implements IBE<HarvesterBlockEntity> {

	public static final MapCodec<HarvesterBlock> CODEC = method_54094(HarvesterBlock::new);

	public HarvesterBlock(class_2251 p_i48377_1_) {
		super(p_i48377_1_);
	}

	@Override
	public Class<HarvesterBlockEntity> getBlockEntityClass() {
		return HarvesterBlockEntity.class;
	}

	@Override
	public class_2591<? extends HarvesterBlockEntity> getBlockEntityType() {
		return AllBlockEntityTypes.HARVESTER.get();
	}

	@Override
	protected @NotNull MapCodec<? extends class_2383> method_53969() {
		return field_46280;
	}
}
