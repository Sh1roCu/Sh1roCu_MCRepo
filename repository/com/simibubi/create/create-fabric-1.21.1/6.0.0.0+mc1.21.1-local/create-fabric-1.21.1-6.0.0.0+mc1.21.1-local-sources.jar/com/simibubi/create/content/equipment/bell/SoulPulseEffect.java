package com.simibubi.create.content.equipment.bell;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.google.common.collect.Streams;
import com.simibubi.create.content.equipment.bell.SoulParticle.ExpandingPerimeterData;

import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_9169;

public class SoulPulseEffect {

	public static final int MAX_DISTANCE = 11;
	private static final List<List<class_2338>> LAYERS = genLayers();

	private static final int WAITING_TICKS = 100;
	public static final int TICKS_PER_LAYER = 6;
	private int ticks;
	public final class_2338 pos;
	public final int distance;
	public final List<class_2338> added;

	public SoulPulseEffect(class_2338 pos, int distance, boolean canOverlap) {
		this.ticks = TICKS_PER_LAYER * distance;
		this.pos = pos;
		this.distance = distance;
		this.added = canOverlap ? null : new ArrayList<>();
	}

	public boolean finished() {
		return ticks <= -WAITING_TICKS;
	}

	public boolean canOverlap() {
		return added == null;
	}

	public List<class_2338> tick(class_1937 world) {
		if (finished())
			return null;

		ticks--;
		if (ticks < 0 || ticks % TICKS_PER_LAYER != 0)
			return null;

		List<class_2338> spawns = getPotentialSoulSpawns(world);
		while (spawns.isEmpty() && ticks > 0) {
			ticks -= TICKS_PER_LAYER;
			spawns.addAll(getPotentialSoulSpawns(world));
		}
		return spawns;
	}

	public int currentLayerIdx() {
		return distance - ticks / TICKS_PER_LAYER - 1;
	}

	public List<class_2338> getPotentialSoulSpawns(class_1937 world) {
		if (world == null)
			return new ArrayList<>();

		return getLayer(currentLayerIdx()).map(p -> p.method_10081(pos))
			.filter(p -> canSpawnSoulAt(world, p, true))
			.collect(Collectors.toList());
	}

	public static boolean isDark(class_1937 world, class_2338 at) {
		return world.method_8314(class_1944.field_9282, at) < 1;
	}

	public static boolean canSpawnSoulAt(class_1937 world, class_2338 at, boolean ignoreLight) {
		class_1299<?> dummy = class_1299.field_6051;
		double dummyWidth = 0.2, dummyHeight = 0.75;
		double w2 = dummyWidth / 2;

		return world != null && class_9169.field_48745.isSpawnPositionOk(world, at, dummy)
			&& (ignoreLight || isDark(world, at))
			&& Streams
				.stream(world.method_20812(null,
					new class_238(at.method_10263() + 0.5 - w2, at.method_10264(), at.method_10260() + 0.5 - w2, at.method_10263() + 0.5 + w2,
						at.method_10264() + dummyHeight, at.method_10260() + 0.5 + w2)))
				.allMatch(class_265::method_1110);
	}

	public void spawnParticles(class_1937 world, class_2338 at) {
		if (world == null || !world.field_9236)
			return;

		class_243 p = class_243.method_24954(at);
		if (canOverlap())
			world.method_8494(((int) Math.round(VecHelper.getCenterOf(pos)
				.method_1022(VecHelper.getCenterOf(at)))) >= distance ? new SoulParticle.PerimeterData()
					: new ExpandingPerimeterData(),
				p.field_1352 + 0.5, p.field_1351 + 0.5, p.field_1350 + 0.5, 0, 0, 0);
		if (SoulPulseEffect.isDark(world, at)) {
			world.method_8494(new SoulParticle.Data(), p.field_1352 + 0.5, p.field_1351 + 0.5, p.field_1350 + 0.5, 0, 0, 0);
			world.method_8406(new SoulBaseParticle.Data(), p.field_1352 + 0.5, p.field_1351 + 0.01, p.field_1350 + 0.5, 0, 0, 0);
		}
	}

	private static List<List<class_2338>> genLayers() {
		List<List<class_2338>> layers = new ArrayList<>();
		for (int i = 0; i < MAX_DISTANCE; i++)
			layers.add(new ArrayList<>());

		for (int x = 0; x < MAX_DISTANCE; x++) {
			for (int y = 0; y < MAX_DISTANCE; y++) {
				for (int z = 0; z < MAX_DISTANCE; z++) {
					class_2338 candidate = new class_2338(x, y, z);

					int dist = (int) Math.round(Math.sqrt(candidate.method_10262(class_2338.field_10980)));
					if (dist > MAX_DISTANCE)
						continue;
					if (dist <= 0)
						dist = 1;

					List<class_2338> layer = layers.get(dist - 1);
					int start = layer.size(), end = start + 1;
					layer.add(candidate);

					if (candidate.method_10263() != 0) {
						layer.add(new class_2338(-candidate.method_10263(), candidate.method_10264(), candidate.method_10260()));
						end += 1;
					}
					if (candidate.method_10264() != 0) {
						for (int i = start; i < end; i++) {
							class_2338 prev = layer.get(i);
							layer.add(new class_2338(prev.method_10263(), -prev.method_10264(), prev.method_10260()));
						}
						end += end - start;
					}
					if (candidate.method_10260() != 0) {
						for (int i = start; i < end; i++) {
							class_2338 prev = layer.get(i);
							layer.add(new class_2338(prev.method_10263(), prev.method_10264(), -prev.method_10260()));
						}
					}
				}
			}
		}

		return layers;
	}

	public static Stream<class_2338> getLayer(int idx) {
		if (idx < 0 || idx >= MAX_DISTANCE)
			return Stream.empty();
		return LAYERS.get(idx)
			.stream();
	}

}
