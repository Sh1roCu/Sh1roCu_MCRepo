package com.simibubi.create.content.equipment.blueprint;

import org.joml.Matrix3f;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.equipment.blueprint.BlueprintEntity.BlueprintSection;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SuperByteBuffer;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_5617;
import net.minecraft.class_811;
import net.minecraft.class_897;
import net.createmod.catnip.data.Couple;

public class BlueprintRenderer extends class_897<BlueprintEntity> {

	public BlueprintRenderer(class_5617.class_5618 context) {
		super(context);
	}

	@Override
	public void render(BlueprintEntity entity, float yaw, float pt, class_4587 ms, class_4597 buffer,
		int light) {
		PartialModel partialModel = entity.size == 3 ? AllPartialModels.CRAFTING_BLUEPRINT_3x3
			: entity.size == 2 ? AllPartialModels.CRAFTING_BLUEPRINT_2x2 : AllPartialModels.CRAFTING_BLUEPRINT_1x1;
		SuperByteBuffer sbb = CachedBuffers.partial(partialModel, class_2246.field_10124.method_9564());
		sbb.rotateYDegrees(-yaw)
			.rotateXDegrees(90.0F + entity.method_36455())
			.translate(-.5, -1 / 32f, -.5);
		if (entity.size == 2)
			sbb.translate(.5, 0, -.5);

		sbb.disableDiffuse()
			.light(light)
			.renderInto(ms, buffer.getBuffer(class_4722.method_24073()));
		super.method_3936(entity, yaw, pt, ms, buffer, light);

		ms.method_22903();

		float fakeNormalXRotation = -15;
		int bl = light >> 4 & 0xf;
		int sl = light >> 20 & 0xf;
		boolean vertical = entity.method_36455() != 0;
		if (entity.method_36455() == -90)
			fakeNormalXRotation = -45;
		else if (entity.method_36455() == 90 || yaw % 180 != 0) {
			bl /= 1.35;
			sl /= 1.35;
		}
		int itemLight = class_3532.method_15357(sl + .5) << 20 | (class_3532.method_15357(bl + .5) & 0xf) << 4;

		TransformStack.of(ms)
			.rotateYDegrees(vertical ? 0 : -yaw)
			.rotateXDegrees(fakeNormalXRotation);
		Matrix3f copy = new Matrix3f(ms.method_23760()
			.method_23762());

		ms.method_22909();
		ms.method_22903();

		TransformStack.of(ms)
			.rotateYDegrees(-yaw)
			.rotateXDegrees(entity.method_36455())
			.translate(0, 0, 1 / 32f + .001);

		if (entity.size == 3)
			ms.method_46416(-1, -1, 0);

		class_4587 squashedMS = new class_4587();
		squashedMS.method_23760()
			.method_23761()
			.mul(ms.method_23760()
				.method_23761());

		for (int x = 0; x < entity.size; x++) {
			squashedMS.method_22903();
			for (int y = 0; y < entity.size; y++) {
				BlueprintSection section = entity.getSection(x * entity.size + y);
				Couple<class_1799> displayItems = section.getDisplayItems();
				squashedMS.method_22903();
				squashedMS.method_22905(.5f, .5f, 1 / 1024f);
				displayItems.forEachWithContext((stack, primary) -> {
					if (stack.method_7960())
						return;

					squashedMS.method_22903();
					if (!primary) {
						squashedMS.method_46416(0.325f, -0.325f, 1);
						squashedMS.method_22905(.625f, .625f, 1);
					}

					squashedMS.method_23760()
						.method_23762()
						.set(copy);

					class_310.method_1551()
						.method_1480()
						.method_23178(stack, class_811.field_4317, itemLight, class_4608.field_21444, squashedMS,
							buffer, entity.method_37908(), 0);
					squashedMS.method_22909();
				});
				squashedMS.method_22909();
				squashedMS.method_46416(1, 0, 0);
			}
			squashedMS.method_22909();
			squashedMS.method_46416(0, 1, 0);
		}

		ms.method_22909();
	}

	@Override
	public class_2960 getTextureLocation(BlueprintEntity entity) {
		return null;
	}

}
