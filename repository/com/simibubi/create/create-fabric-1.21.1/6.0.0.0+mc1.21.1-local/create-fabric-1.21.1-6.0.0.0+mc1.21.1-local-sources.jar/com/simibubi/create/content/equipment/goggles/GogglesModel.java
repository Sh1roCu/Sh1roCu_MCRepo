package com.simibubi.create.content.equipment.goggles;

import com.simibubi.create.AllPartialModels;

import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.minecraft.class_1087;
import net.minecraft.class_4587;
import net.minecraft.class_811;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;

import io.github.fabricators_of_create.porting_lib.models.TransformTypeDependentItemBakedModel;

public class GogglesModel extends ForwardingBakedModel implements TransformTypeDependentItemBakedModel {
	protected class_1087 itemModel;

	public GogglesModel(class_1087 template) {
		this.itemModel = wrapped = template;
	}

	@Override
	public class_1087 applyTransform(class_811 cameraItemDisplayContext, class_4587 mat, boolean leftHanded, DefaultTransform defaultTransform) {
		if (cameraItemDisplayContext == class_811.field_4316) {
			class_1087 headGoggles = AllPartialModels.GOGGLES.get();
			defaultTransform.apply(headGoggles);
			return headGoggles;
		}
		defaultTransform.apply(this);
		return this;
	}
}
