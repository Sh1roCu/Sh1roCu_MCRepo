package com.simibubi.create.content.equipment.zapper;

import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

public abstract class ConfigureZapperPacket implements ServerboundPacketPayload {
	protected final class_1268 hand;
	protected final PlacementPatterns pattern;

	public ConfigureZapperPacket(class_1268 hand, PlacementPatterns pattern) {
		this.hand = hand;
		this.pattern = pattern;
	}

	@Override
	public void handle(class_3222 player) {
		class_1799 stack = player.method_5998(hand);
		if (stack.method_7909() instanceof ZapperItem) {
			configureZapper(stack);
		}
	}

	public abstract void configureZapper(class_1799 stack);

}
