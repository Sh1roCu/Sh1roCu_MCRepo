package com.simibubi.create.api.unpacking;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.jetbrains.annotations.ApiStatus.Experimental;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.api.registry.SimpleRegistry;
import com.simibubi.create.content.logistics.stockTicker.PackageOrder;
import com.simibubi.create.impl.unpacking.DefaultUnpackingHandler;

/**
 * Interface for custom handling of box unpacking into storage.
 * <p>
 * This interface is <strong>experimental</strong> as it is for a new feature. It may be revised or relocated,
 * but will likely not change very much.
 */
@Experimental
public interface UnpackingHandler {
	SimpleRegistry<class_2248, UnpackingHandler> REGISTRY = SimpleRegistry.create();

	/**
	 * The default unpacking handler, simply inserting all items into storage.
	 */
	UnpackingHandler DEFAULT = DefaultUnpackingHandler.INSTANCE;

	/**
	 * Unpack the given items into storage.
	 * @param items the list of non-empty item stacks to unpack. May be freely modified
	 * @param order the order context, if present
	 * @param simulate true if the unpacking should only be simulated
	 * @return true if all items have been unpacked successfully
	 */
	boolean unpack(class_1937 level, class_2338 pos, class_2680 state, class_2350 side, List<class_1799> items, @Nullable PackageOrder order, boolean simulate);
}
