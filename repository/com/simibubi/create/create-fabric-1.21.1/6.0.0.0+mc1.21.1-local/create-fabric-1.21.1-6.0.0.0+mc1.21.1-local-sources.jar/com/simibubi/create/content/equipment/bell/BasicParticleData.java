package com.simibubi.create.content.equipment.bell;

import javax.annotation.ParametersAreNonnullByDefault;

import com.mojang.serialization.MapCodec;
import com.simibubi.create.foundation.particle.ICustomParticleDataWithSprite;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_4002;
import net.minecraft.class_6328;
import net.minecraft.class_638;
import net.minecraft.class_702;
import net.minecraft.class_703;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

@ParametersAreNonnullByDefault
@class_6328
public abstract class BasicParticleData<T extends class_703> implements class_2394, ICustomParticleDataWithSprite<BasicParticleData<T>> {

	public BasicParticleData() {
	}

	@Override
	public class_9139<? super class_9129, BasicParticleData<T>> getStreamCodec() {
		return class_9139.method_56431(this);
	}

	@Override
	public MapCodec<BasicParticleData<T>> getCodec(class_2396<BasicParticleData<T>> type) {
		return MapCodec.unit(this);
	}

	public interface IBasicParticleFactory<U extends class_703> {
		U makeParticle(class_638 worldIn, double x, double y, double z, double vx, double vy, double vz, class_4002 sprite);
	}

	@Environment(EnvType.CLIENT)
	public abstract IBasicParticleFactory<T> getBasicFactory();

	@Override
	@Environment(EnvType.CLIENT)
	public class_702.class_4091<BasicParticleData<T>> getMetaFactory() {
		return animatedSprite -> (data, worldIn, x, y, z, vx, vy, vz) ->
			getBasicFactory().makeParticle(worldIn, x, y, z, vx, vy, vz, animatedSprite);
	}
}
