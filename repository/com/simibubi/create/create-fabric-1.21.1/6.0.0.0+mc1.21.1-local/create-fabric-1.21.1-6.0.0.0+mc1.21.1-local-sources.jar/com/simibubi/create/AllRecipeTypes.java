package com.simibubi.create;

import java.util.Optional;
import java.util.function.Predicate;
import java.util.function.Supplier;
import org.jetbrains.annotations.ApiStatus.Internal;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.simibubi.create.content.equipment.sandPaper.SandPaperPolishingRecipe;
import com.simibubi.create.content.equipment.toolbox.ToolboxDyeingRecipe;
import com.simibubi.create.content.fluids.transfer.EmptyingRecipe;
import com.simibubi.create.content.fluids.transfer.FillingRecipe;
import com.simibubi.create.content.kinetics.crafter.MechanicalCraftingRecipe;
import com.simibubi.create.content.kinetics.crusher.CrushingRecipe;
import com.simibubi.create.content.kinetics.deployer.DeployerApplicationRecipe;
import com.simibubi.create.content.kinetics.deployer.ItemApplicationRecipe;
import com.simibubi.create.content.kinetics.deployer.ManualApplicationRecipe;
import com.simibubi.create.content.kinetics.fan.processing.HauntingRecipe;
import com.simibubi.create.content.kinetics.fan.processing.SplashingRecipe;
import com.simibubi.create.content.kinetics.millstone.MillingRecipe;
import com.simibubi.create.content.kinetics.mixer.CompactingRecipe;
import com.simibubi.create.content.kinetics.mixer.MixingRecipe;
import com.simibubi.create.content.kinetics.press.PressingRecipe;
import com.simibubi.create.content.kinetics.saw.CuttingRecipe;
import com.simibubi.create.content.processing.basin.BasinRecipe;
import com.simibubi.create.content.processing.recipe.ProcessingRecipe;
import com.simibubi.create.content.processing.recipe.ProcessingRecipeBuilder.ProcessingRecipeFactory;
import com.simibubi.create.content.processing.recipe.ProcessingRecipeSerializer;
import com.simibubi.create.content.processing.sequenced.SequencedAssemblyRecipeSerializer;
import com.simibubi.create.foundation.recipe.IRecipeTypeInfo;
import com.simibubi.create.foundation.recipe.ItemCopyingRecipe;

import net.createmod.catnip.lang.Lang;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1866;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3542;
import net.minecraft.class_3956;
import net.minecraft.class_7923;
import net.minecraft.class_8786;
import net.minecraft.class_9695;

public enum AllRecipeTypes implements IRecipeTypeInfo, class_3542 {

	CONVERSION(PressingRecipe::new),
	CRUSHING(CrushingRecipe::new),
	CUTTING(CuttingRecipe::new),
	MILLING(MillingRecipe::new),
	BASIN(BasinRecipe::new),
	MIXING(MixingRecipe::new),
	COMPACTING(CompactingRecipe::new),
	PRESSING(PressingRecipe::new),
	SANDPAPER_POLISHING(SandPaperPolishingRecipe::new),
	SPLASHING(SplashingRecipe::new),
	HAUNTING(HauntingRecipe::new),
	DEPLOYING(DeployerApplicationRecipe::new),
	FILLING(FillingRecipe::new),
	EMPTYING(EmptyingRecipe::new),
	ITEM_APPLICATION(ManualApplicationRecipe::new),

	MECHANICAL_CRAFTING(MechanicalCraftingRecipe.Serializer::new),
	SEQUENCED_ASSEMBLY(SequencedAssemblyRecipeSerializer::new),

	TOOLBOX_DYEING(() -> new class_1866<>(ToolboxDyeingRecipe::new), () -> class_3956.field_17545, false),
	ITEM_COPYING(() -> new class_1866<>(ItemCopyingRecipe::new), () -> class_3956.field_17545, false);

	public static final Predicate<class_8786<?>> CAN_BE_AUTOMATED = r -> !r.comp_1932()
			.method_12832()
			.endsWith("_manual_only");

	private final class_2960 id;
	private final class_1865<?> serializerObject;
	@Nullable
	private final class_3956<?> typeObject;

	private boolean isProcessingRecipe;

	public static final Codec<AllRecipeTypes> CODEC = class_3542.method_28140(AllRecipeTypes::values);

	AllRecipeTypes(Supplier<class_1865<?>> serializerSupplier, Supplier<class_3956<?>> typeSupplier, boolean registerType) {
		String name = Lang.asId(name());
		id = Create.asResource(name);
		serializerObject = class_2378.method_10230(class_7923.field_41189, id, serializerSupplier.get());
		if (registerType) {
			typeObject = typeSupplier.get();
			class_2378.method_10230(class_7923.field_41188, id, typeObject);
		} else {
			typeObject = typeSupplier.get();
		}
		isProcessingRecipe = false;
	}

	AllRecipeTypes(Supplier<class_1865<?>> serializerSupplier) {
		String name = Lang.asId(name());
		id = Create.asResource(name);
		serializerObject = class_2378.method_10230(class_7923.field_41189, id, serializerSupplier.get());
		typeObject = class_2378.method_10230(class_7923.field_41188, id, createType(id));
		isProcessingRecipe = false;
	}

	AllRecipeTypes(ProcessingRecipeFactory<?> processingFactory) {
		String name = Lang.asId(name());
		id = Create.asResource(name);
		serializerObject = class_2378.method_10230(class_7923.field_41189, id, new ProcessingRecipeSerializer<>(processingFactory, this));
		typeObject = class_2378.method_10230(class_7923.field_41188, id, createType(id));
		isProcessingRecipe = true;
	}

	@Internal
	public static void register() {
		ShapedRecipeUtil.setCraftingSize(9, 9);
		// fabric: just load the class
	}

	@Override
	public class_2960 getId() {
		return id;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends class_1865<?>> T getSerializer() {
		return (T) serializerObject;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <I extends class_9695, R extends class_1860<I>> class_3956<R> getType() {
		return (class_3956<R>) this.typeObject;
	}

	public <I extends class_9695, R extends class_1860<I>> Optional<class_8786<R>> find(I inv, class_1937 world) {
		return world.method_8433()
			.method_8132(getType(), inv, world);
	}

	public static boolean shouldIgnoreInAutomation(class_8786<?> recipe) {
		class_1865<?> serializer = recipe.comp_1933().method_8119();
		if (serializer != null && AllTags.AllRecipeSerializerTags.AUTOMATION_IGNORE.matches(serializer))
			return true;
		return !CAN_BE_AUTOMATED.test(recipe);
	}

	@Override
	public @NotNull String method_15434() {
		return id.toString();
	}

	private static <T extends class_1860<?>> class_3956<T> createType(class_2960 id) {
		String string = id.toString();
		return new class_3956<T>() {
			@Override
			public String toString() {
				return string;
			}
		};
	}

	public <T extends ProcessingRecipe<?>> MapCodec<T> processingCodec() {
		if (!isProcessingRecipe)
			throw new AssertionError("AllRecipeTypes#processingCodec called on " + name() + ", which is not a processing recipe");
		if (this == DEPLOYING || this == ITEM_APPLICATION)
			return ItemApplicationRecipe.codec(this);
		return ProcessingRecipeSerializer.codec(this);
	}
}
