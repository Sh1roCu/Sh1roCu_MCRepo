package com.simibubi.create.content.equipment.sandPaper;

import java.util.List;

import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_8786;
import net.minecraft.class_9696;
import com.simibubi.create.AllRecipeTypes;
import com.simibubi.create.content.processing.recipe.ProcessingRecipe;
import com.simibubi.create.content.processing.recipe.ProcessingRecipeBuilder.ProcessingRecipeParams;

@ParametersAreNonnullByDefault
public class SandPaperPolishingRecipe extends ProcessingRecipe<class_9696> {

	public SandPaperPolishingRecipe(ProcessingRecipeParams params) {
		super(AllRecipeTypes.SANDPAPER_POLISHING, params);
	}

	@Override
	public boolean matches(class_9696 inv, class_1937 worldIn) {
		return ingredients.get(0)
			.method_8093(inv.method_59984(0));
	}

	@Override
	protected int getMaxInputCount() {
		return 1;
	}

	@Override
	protected int getMaxOutputCount() {
		return 1;
	}

	public static boolean canPolish(class_1937 world, class_1799 stack) {
		return !getMatchingRecipes(world, stack).isEmpty();
	}

	public static class_1799 applyPolish(class_1937 world, class_243 position, class_1799 stack, class_1799 sandPaperStack) {
		List<class_8786<class_1860<class_9696>>> matchingRecipes = getMatchingRecipes(world, stack);
		if (!matchingRecipes.isEmpty())
			return matchingRecipes.get(0).comp_1933()
				.method_8116(new class_9696(stack), world.method_30349())
				.method_7972();
		return stack;
	}

	public static List<class_8786<class_1860<class_9696>>> getMatchingRecipes(class_1937 world, class_1799 stack) {
		return world.method_8433()
			.method_17877(AllRecipeTypes.SANDPAPER_POLISHING.getType(), new class_9696(stack), world);
	}
}
