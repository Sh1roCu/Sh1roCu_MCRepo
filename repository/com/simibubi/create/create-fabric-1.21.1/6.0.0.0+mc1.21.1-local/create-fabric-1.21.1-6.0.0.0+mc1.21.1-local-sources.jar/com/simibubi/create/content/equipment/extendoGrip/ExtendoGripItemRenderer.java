package com.simibubi.create.content.equipment.extendoGrip;

import com.simibubi.create.AllPartialModels;
import com.simibubi.create.Create;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModel;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModelRenderer;
import com.simibubi.create.foundation.item.render.PartialItemModelRenderer;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;

public class ExtendoGripItemRenderer extends CustomRenderedItemModelRenderer {

	protected static final PartialModel COG = PartialModel.of(Create.asResource("item/extendo_grip/cog"));
	protected static final PartialModel THIN_SHORT = PartialModel.of(Create.asResource("item/extendo_grip/thin_short"));
	protected static final PartialModel WIDE_SHORT = PartialModel.of(Create.asResource("item/extendo_grip/wide_short"));
	protected static final PartialModel THIN_LONG = PartialModel.of(Create.asResource("item/extendo_grip/thin_long"));
	protected static final PartialModel WIDE_LONG = PartialModel.of(Create.asResource("item/extendo_grip/wide_long"));

	private static final class_243 ROTATION_OFFSET = new class_243(0, 1 / 2f, 1 / 2f);
	private static final class_243 COG_ROTATION_OFFSET = new class_243(0, 1 / 16f, 0);

	@Override
	protected void render(class_1799 stack, CustomRenderedItemModel model, PartialItemModelRenderer renderer, class_811 transformType,
		class_4587 ms, class_4597 buffer, int light, int overlay) {
		var stacker = TransformStack.of(ms);
		float animation = 0.25f;
		boolean leftHand = transformType == class_811.field_4321;
		boolean rightHand = transformType == class_811.field_4322;
		if (leftHand || rightHand)
			animation = class_3532.method_16439(AnimationTickHolder.getPartialTicks(),
										ExtendoGripRenderHandler.lastMainHandAnimation,
										ExtendoGripRenderHandler.mainHandAnimation);

		animation = animation * animation * animation;
		float extensionAngle = class_3532.method_16439(animation, 24f, 156f);
		float halfAngle = extensionAngle / 2;
		float oppositeAngle = 180 - extensionAngle;

		// grip
		renderer.renderSolid(model.getOriginalModel(), light);

		// bits
		ms.method_22903();
		ms.method_46416(0, 1 / 16f, -7 / 16f);
		ms.method_22905(1, 1, 1 + animation);
		ms.method_22903();
		stacker.rotateXDegrees(-halfAngle)
			.translate(ROTATION_OFFSET);
		renderer.renderSolid(THIN_SHORT.get(), light);
		stacker.translateBack(ROTATION_OFFSET);

		ms.method_46416(0, 5.5f / 16f, 0);
		stacker.rotateXDegrees(-oppositeAngle)
			.translate(ROTATION_OFFSET);
		renderer.renderSolid(WIDE_LONG.get(), light);
		stacker.translateBack(ROTATION_OFFSET);

		ms.method_46416(0, 11 / 16f, 0);
		stacker.rotateXDegrees(oppositeAngle)
			.translate(ROTATION_OFFSET);
		ms.method_46416(0, 0.5f / 16f, 0);
		renderer.renderSolid(THIN_SHORT.get(), light);
		stacker.translateBack(ROTATION_OFFSET);

		ms.method_22909();
		ms.method_22903();

		stacker.rotateXDegrees(-180 + halfAngle)
			.translate(ROTATION_OFFSET);
		renderer.renderSolid(WIDE_SHORT.get(), light);
		stacker.translateBack(ROTATION_OFFSET);

		ms.method_46416(0, 5.5f / 16f, 0);
		stacker.rotateXDegrees(oppositeAngle)
			.translate(ROTATION_OFFSET);
		renderer.renderSolid(THIN_LONG.get(), light);
		stacker.translateBack(ROTATION_OFFSET);

		ms.method_46416(0, 11 / 16f, 0);
		stacker.rotateXDegrees(-oppositeAngle)
			.translate(ROTATION_OFFSET);
		ms.method_46416(0, 0.5f / 16f, 0);
		renderer.renderSolid(WIDE_SHORT.get(), light);
		stacker.translateBack(ROTATION_OFFSET);

		// hand
		ms.method_46416(0, 5.5f / 16f, 0);
		stacker.rotateXDegrees(180 - halfAngle)
			.rotateYDegrees(180);
		ms.method_46416(0, 0, -4 / 16f);
		ms.method_22905(1, 1, 1 / (1 + animation));
		renderer.renderSolid((leftHand || rightHand) ? ExtendoGripRenderHandler.pose.get()
			: AllPartialModels.DEPLOYER_HAND_POINTING.get(), light);
		ms.method_22909();

		ms.method_22909();

		// cog
		ms.method_22903();
		float angle = AnimationTickHolder.getRenderTime() * -2;
		if (leftHand || rightHand)
			angle += 360 * animation;
		angle %= 360;
		stacker.translate(COG_ROTATION_OFFSET)
			.rotateZDegrees(angle)
			.translateBack(COG_ROTATION_OFFSET);
		renderer.renderSolid(COG.get(), light);
		ms.method_22909();
	}

}
