package com.simibubi.create.content.contraptions.minecart;

import java.util.Map;

import com.google.common.collect.Maps;
import com.mojang.datafixers.util.Pair;
import com.simibubi.create.AllAttachmentTypes;
import com.simibubi.create.content.contraptions.minecart.capability.MinecartController;

import io.github.fabricators_of_create.porting_lib.util.MinecartAndRailUtil;

import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_156;
import net.minecraft.class_1688;
import net.minecraft.class_1696;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import net.minecraft.class_3532;
import io.github.fabricators_of_create.porting_lib.util.MinecartAndRailUtil;

/**
 * Useful methods for dealing with Minecarts
 *
 */
public class MinecartSim2020 {
	private static final Map<class_2768, Pair<class_2382, class_2382>> MATRIX =
		class_156.method_654(Maps.newEnumMap(class_2768.class), (map) -> {
			class_2382 west = class_2350.field_11039.method_10163();
			class_2382 east = class_2350.field_11034.method_10163();
			class_2382 north = class_2350.field_11043.method_10163();
			class_2382 south = class_2350.field_11035.method_10163();
			map.put(class_2768.field_12665, Pair.of(north, south));
			map.put(class_2768.field_12674, Pair.of(west, east));
			map.put(class_2768.field_12667, Pair.of(west.method_23228(), east));
			map.put(class_2768.field_12666, Pair.of(west, east.method_23228()));
			map.put(class_2768.field_12670, Pair.of(north, south.method_23228()));
			map.put(class_2768.field_12668, Pair.of(north.method_23228(), south));
			map.put(class_2768.field_12664, Pair.of(south, east));
			map.put(class_2768.field_12671, Pair.of(south, west));
			map.put(class_2768.field_12672, Pair.of(north, west));
			map.put(class_2768.field_12663, Pair.of(north, east));
		});

	public static class_243 predictNextPositionOf(class_1688 cart) {
		class_243 position = cart.method_19538();
		class_243 motion = VecHelper.clamp(cart.method_18798(), 1f);
		return position.method_1019(motion);
	}

	public static boolean canAddMotion(class_1688 c) {
		if (c instanceof class_1696)
			return class_3532.method_20390(((class_1696) c).field_7737, 0)
				&& class_3532.method_20390(((class_1696) c).field_7736, 0);
		if (c.create$getController()
			.isStalled())
			return false;
		return true;
	}

	public static void moveCartAlongTrack(class_1688 cart, class_243 forcedMovement, class_2338 cartPos,
		class_2680 trackState) {

		if (forcedMovement.equals(class_243.field_1353))
			return;

		class_243 previousMotion = cart.method_18798();
		cart.field_6017 = 0.0F;

		double x = cart.method_23317();
		double y = cart.method_23318();
		double z = cart.method_23321();

		double actualX = x;
		double actualY = y;
		double actualZ = z;

		class_243 actualVec = cart.method_7508(actualX, actualY, actualZ);
		actualY = cartPos.method_10264() + 1;

		class_2241 abstractrailblock = (class_2241) trackState.method_26204();
		class_2768 railshape = MinecartAndRailUtil.getDirectionOfRail(trackState, cart.method_37908(), cartPos, abstractrailblock);
		switch (railshape) {
		case field_12667:
			forcedMovement = forcedMovement.method_1031(-1 * MinecartAndRailUtil.getSlopeAdjustment(), 0.0D, 0.0D);
			actualY++;
			break;
		case field_12666:
			forcedMovement = forcedMovement.method_1031(MinecartAndRailUtil.getSlopeAdjustment(), 0.0D, 0.0D);
			actualY++;
			break;
		case field_12670:
			forcedMovement = forcedMovement.method_1031(0.0D, 0.0D, MinecartAndRailUtil.getSlopeAdjustment());
			actualY++;
			break;
		case field_12668:
			forcedMovement = forcedMovement.method_1031(0.0D, 0.0D, -1 * MinecartAndRailUtil.getSlopeAdjustment());
			actualY++;
		default:
			break;
		}

		Pair<class_2382, class_2382> pair = MATRIX.get(railshape);
		class_2382 Vector3i = pair.getFirst();
		class_2382 Vector3i1 = pair.getSecond();
		double d4 = (double) (Vector3i1.method_10263() - Vector3i.method_10263());
		double d5 = (double) (Vector3i1.method_10260() - Vector3i.method_10260());
//		double d6 = Math.sqrt(d4 * d4 + d5 * d5);
		double d7 = forcedMovement.field_1352 * d4 + forcedMovement.field_1350 * d5;
		if (d7 < 0.0D) {
			d4 = -d4;
			d5 = -d5;
		}

		double d23 = (double) cartPos.method_10263() + 0.5D + (double) Vector3i.method_10263() * 0.5D;
		double d10 = (double) cartPos.method_10260() + 0.5D + (double) Vector3i.method_10260() * 0.5D;
		double d12 = (double) cartPos.method_10263() + 0.5D + (double) Vector3i1.method_10263() * 0.5D;
		double d13 = (double) cartPos.method_10260() + 0.5D + (double) Vector3i1.method_10260() * 0.5D;
		d4 = d12 - d23;
		d5 = d13 - d10;
		double d14;
		if (d4 == 0.0D) {
			d14 = actualZ - (double) cartPos.method_10260();
		} else if (d5 == 0.0D) {
			d14 = actualX - (double) cartPos.method_10263();
		} else {
			double d15 = actualX - d23;
			double d16 = actualZ - d10;
			d14 = (d15 * d4 + d16 * d5) * 2.0D;
		}

		actualX = d23 + d4 * d14;
		actualZ = d10 + d5 * d14;

		cart.method_5814(actualX, actualY, actualZ);
		cart.method_18799(forcedMovement);
		cart.moveMinecartOnRail(cartPos);

		x = cart.method_23317();
		y = cart.method_23318();
		z = cart.method_23321();

		if (Vector3i.method_10264() != 0 && class_3532.method_15357(x) - cartPos.method_10263() == Vector3i.method_10263()
			&& class_3532.method_15357(z) - cartPos.method_10260() == Vector3i.method_10260()) {
			cart.method_5814(x, y + (double) Vector3i.method_10264(), z);
		} else if (Vector3i1.method_10264() != 0 && class_3532.method_15357(x) - cartPos.method_10263() == Vector3i1.method_10263()
			&& class_3532.method_15357(z) - cartPos.method_10260() == Vector3i1.method_10260()) {
			cart.method_5814(x, y + (double) Vector3i1.method_10264(), z);
		}

		x = cart.method_23317();
		y = cart.method_23318();
		z = cart.method_23321();

		class_243 Vector3d3 = cart.method_7508(x, y, z);
		if (Vector3d3 != null && actualVec != null) {
			double d17 = (actualVec.field_1351 - Vector3d3.field_1351) * 0.05D;
			class_243 Vector3d4 = cart.method_18798();
			double d18 = Math.sqrt(Vector3d4.method_37268());
			if (d18 > 0.0D) {
				cart.method_18799(Vector3d4.method_18805((d18 + d17) / d18, 1.0D, (d18 + d17) / d18));
			}

			cart.method_5814(x, Vector3d3.field_1351, z);
		}

		x = cart.method_23317();
		y = cart.method_23318();
		z = cart.method_23321();

		int j = class_3532.method_15357(x);
		int i = class_3532.method_15357(z);
		if (j != cartPos.method_10263() || i != cartPos.method_10260()) {
			class_243 Vector3d5 = cart.method_18798();
			double d26 = Math.sqrt(Vector3d5.method_37268());
			cart.method_18800(d26 * (double) (j - cartPos.method_10263()), Vector3d5.field_1351, d26 * (double) (i - cartPos.method_10260()));
		}

		cart.method_18799(previousMotion);
	}

	public static class_243 getRailVec(class_2768 shape) {
		switch (shape) {
		case field_12670:
		case field_12668:
		case field_12665:
			return new class_243(0, 0, 1);
		case field_12667:
		case field_12666:
		case field_12674:
			return new class_243(1, 0, 0);
		case field_12663:
		case field_12671:
			return new class_243(1, 0, 1).method_1029();
		case field_12672:
		case field_12664:
			return new class_243(1, 0, -1).method_1029();
		default:
			return new class_243(0, 1, 0);
		}
	}

}
