package com.simibubi.create.content.contraptions.elevator;

import java.util.Optional;

import javax.annotation.Nullable;

import io.github.fabricators_of_create.porting_lib.block.ConnectableRedstoneBlock;
import com.simibubi.create.infrastructure.fabric.block.WeakPowerCheckingBlock;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2318;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_239;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3218;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_746;
import net.minecraft.class_8235;
import net.minecraft.class_9062;
import org.jetbrains.annotations.NotNull;

import com.mojang.serialization.MapCodec;
import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllItems;
import com.simibubi.create.api.schematic.requirement.SpecialBlockItemRequirement;
import com.simibubi.create.content.contraptions.elevator.ElevatorColumn.ColumnCoords;
import com.simibubi.create.content.redstone.contact.RedstoneContactBlock;
import com.simibubi.create.content.redstone.diodes.BrassDiodeBlock;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.foundation.block.IBE;
import com.simibubi.create.foundation.block.WrenchableDirectionalBlock;
import com.simibubi.create.foundation.utility.BlockHelper;

import net.createmod.catnip.gui.ScreenOpener;
import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import io.github.fabricators_of_create.porting_lib.block.ConnectableRedstoneBlock;
import com.simibubi.create.infrastructure.fabric.block.WeakPowerCheckingBlock;
import io.github.fabricators_of_create.porting_lib.common.util.EnvExecutor;

public class ElevatorContactBlock extends WrenchableDirectionalBlock
	implements IBE<ElevatorContactBlockEntity>, SpecialBlockItemRequirement, WeakPowerCheckingBlock, ConnectableRedstoneBlock {

	public static final class_2746 POWERED = class_2741.field_12484;
	public static final class_2746 CALLING = class_2746.method_11825("calling");
	public static final class_2746 POWERING = BrassDiodeBlock.POWERING;

	public static final MapCodec<ElevatorContactBlock> field_46280 = method_54094(ElevatorContactBlock::new);

	public ElevatorContactBlock(class_2251 pProperties) {
		super(pProperties);
		method_9590(method_9564().method_11657(CALLING, false)
			.method_11657(POWERING, false)
			.method_11657(POWERED, false)
			.method_11657(field_10927, class_2350.field_11035));
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> builder) {
		super.method_9515(builder.method_11667(CALLING, POWERING, POWERED));
	}

	@Override
	public class_1269 onWrenched(class_2680 state, class_1838 context) {
		class_1269 onWrenched = super.onWrenched(state, context);
		if (onWrenched != class_1269.field_5812)
			return onWrenched;

		class_1937 level = context.method_8045();
		if (level.method_8608())
			return onWrenched;

		class_2338 pos = context.method_8037();
		state = level.method_8320(pos);
		class_2350 facing = state.method_11654(RedstoneContactBlock.field_10927);
		if (facing.method_10166() != class_2351.field_11052
			&& ElevatorColumn.get(level, new ColumnCoords(pos.method_10263(), pos.method_10260(), facing)) != null)
			return onWrenched;

		level.method_8501(pos, BlockHelper.copyProperties(state, AllBlocks.REDSTONE_CONTACT.getDefaultState()));

		return onWrenched;
	}

	@Nullable
	public static ColumnCoords getColumnCoords(class_1936 level, class_2338 pos) {
		class_2680 blockState = level.method_8320(pos);
		if (!AllBlocks.ELEVATOR_CONTACT.has(blockState) && !AllBlocks.REDSTONE_CONTACT.has(blockState))
			return null;
		class_2350 facing = blockState.method_11654(field_10927);
		class_2338 target = pos;
		return new ColumnCoords(target.method_10263(), target.method_10260(), facing);
	}

	@Override
	public void method_9612(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_2248 pBlock, class_2338 pFromPos,
		boolean pIsMoving) {
		if (pLevel.field_9236)
			return;

		boolean isPowered = pState.method_11654(POWERED);
		if (isPowered == pLevel.method_49803(pPos))
			return;

		pLevel.method_8652(pPos, pState.method_28493(POWERED), 2);

		if (isPowered)
			return;
		if (pState.method_11654(CALLING))
			return;

		ElevatorColumn elevatorColumn = ElevatorColumn.getOrCreate(pLevel, getColumnCoords(pLevel, pPos));
		callToContactAndUpdate(elevatorColumn, pState, pLevel, pPos, true);
	}

	public void callToContactAndUpdate(ElevatorColumn elevatorColumn, class_2680 pState, class_1937 pLevel, class_2338 pPos,
		boolean powered) {
		pLevel.method_8652(pPos, pState.method_28493(CALLING), 2);

		for (class_2338 otherPos : elevatorColumn.getContacts()) {
			if (otherPos.equals(pPos))
				continue;
			class_2680 otherState = pLevel.method_8320(otherPos);
			if (!AllBlocks.ELEVATOR_CONTACT.has(otherState))
				continue;
			pLevel.method_8652(otherPos, otherState.method_11657(CALLING, false), 2 | 16);
			scheduleActivation(pLevel, otherPos);
		}

		if (powered)
			pState = pState.method_11657(POWERED, true);
		pLevel.method_8652(pPos, pState.method_11657(CALLING, true), 2);
		pLevel.method_8452(pPos, this);

		elevatorColumn.target(pPos.method_10264());
		elevatorColumn.markDirty();
	}

	public void scheduleActivation(class_1936 pLevel, class_2338 pPos) {
		if (!pLevel.method_8397()
			.method_8674(pPos, this))
			pLevel.method_39279(pPos, this, 1);
	}

	@Override
	public void method_9588(class_2680 pState, class_3218 pLevel, class_2338 pPos, class_5819 pRand) {
		boolean wasPowering = pState.method_11654(POWERING);

		Optional<ElevatorContactBlockEntity> optionalBE = getBlockEntityOptional(pLevel, pPos);
		boolean shouldBePowering = optionalBE.map(be -> {
			boolean activateBlock = be.activateBlock;
			be.activateBlock = false;
			be.method_5431();
			return activateBlock;
		})
			.orElse(false);

		shouldBePowering |= RedstoneContactBlock.hasValidContact(pLevel, pPos, pState.method_11654(field_10927));

		if (wasPowering || shouldBePowering)
			pLevel.method_8652(pPos, pState.method_11657(POWERING, shouldBePowering), 2 | 16);

		pLevel.method_8452(pPos, this);
	}

	@Override
	public class_2680 method_9559(class_2680 stateIn, class_2350 facing, class_2680 facingState, class_1936 worldIn,
		class_2338 currentPos, class_2338 facingPos) {
		if (facing != stateIn.method_11654(field_10927))
			return stateIn;
		boolean hasValidContact = RedstoneContactBlock.hasValidContact(worldIn, currentPos, facing);
		if (stateIn.method_11654(POWERING) != hasValidContact)
			scheduleActivation(worldIn, currentPos);
		return stateIn;
	}

	@Override
    public boolean shouldCheckWeakPower(class_2680 state, class_8235 level, class_2338 pos, class_2350 side) {
        return false;
    }

	@Override
	public boolean method_9506(class_2680 state) {
		return state.method_11654(POWERING);
	}

	public class_1799 getCloneItemStack(class_2680 state, class_239 target, class_4538 level, class_2338 pos, class_1657 player) {
		return AllBlocks.REDSTONE_CONTACT.asStack();
	}

	@Override
	public boolean canConnectRedstone(class_2680 state, class_1922 world, class_2338 pos, @Nullable class_2350 side) {
		if (side == null)
			return true;
		return state.method_11654(field_10927) != side.method_10153();
	}

	@Override
	public int method_9524(class_2680 state, class_1922 blockAccess, class_2338 pos, class_2350 side) {
		if (side == null)
			return 0;
		class_2680 toState = blockAccess.method_8320(pos.method_10093(side.method_10153()));
		if (toState.method_27852(this))
			return 0;
		return state.method_11654(POWERING) ? 15 : 0;
	}

	@Override
	public Class<ElevatorContactBlockEntity> getBlockEntityClass() {
		return ElevatorContactBlockEntity.class;
	}

	@Override
	public class_2591<? extends ElevatorContactBlockEntity> getBlockEntityType() {
		return AllBlockEntityTypes.ELEVATOR_CONTACT.get();
	}

	@Override
	public ItemRequirement getRequiredItems(class_2680 state, class_2586 be) {
		return ItemRequirement.of(AllBlocks.REDSTONE_CONTACT.getDefaultState(), be);
	}

	@Override
	protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
		if (player != null && AllItems.WRENCH.isIn(stack))
			return class_9062.field_47731;
		CatnipServices.PLATFORM.executeOnClientOnly(() -> () -> withBlockEntityDo(level, pos, be -> this.displayScreen(be, player)));
		return class_9062.field_47728;
	}

	@Environment(EnvType.CLIENT)
	protected void displayScreen(ElevatorContactBlockEntity be, class_1657 player) {
		if (player instanceof class_746)
			ScreenOpener
				.open(new ElevatorContactScreen(be.method_11016(), be.shortName, be.longName, be.doorControls.mode));
	}

	public static int getLight(class_2680 state) {
		return state.method_11654(POWERING) ? 10 : 0;
	}

	@Override
	protected @NotNull MapCodec<? extends class_2318> method_53969() {
		return field_46280;
	}
}
