package com.simibubi.create;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import org.jetbrains.annotations.ApiStatus;

import com.simibubi.create.content.trains.bogey.BogeySizes;
import com.simibubi.create.content.trains.bogey.BogeyStyle;
import com.simibubi.create.content.trains.bogey.BogeyStyle.SizeRenderer;
import com.simibubi.create.content.trains.bogey.StandardBogeyRenderer;
import com.simibubi.create.content.trains.bogey.StandardBogeyVisual;

public class AllBogeyStyles {
	public static final Map<class_2960, BogeyStyle> BOGEY_STYLES = new HashMap<>();
	public static final Map<class_2960, Map<class_2960, BogeyStyle>> CYCLE_GROUPS = new HashMap<>();
	private static final Map<class_2960, BogeyStyle> EMPTY_GROUP = Collections.emptyMap();

	public static final class_2960 STANDARD_CYCLE_GROUP = Create.asResource("standard");

	public static final BogeyStyle STANDARD
            = builder("standard", STANDARD_CYCLE_GROUP).displayName(class_2561.method_43471("create.bogey.style.standard"))
                .size(BogeySizes.SMALL, AllBlocks.SMALL_BOGEY, () -> () -> new SizeRenderer(new StandardBogeyRenderer.Small(), StandardBogeyVisual.Small::new))
                .size(BogeySizes.LARGE, AllBlocks.LARGE_BOGEY, () -> () -> new SizeRenderer(new StandardBogeyRenderer.Large(), StandardBogeyVisual.Large::new))
                .build();

    public static Map<class_2960, BogeyStyle> getCycleGroup(class_2960 cycleGroup) {
		return CYCLE_GROUPS.getOrDefault(cycleGroup, EMPTY_GROUP);
	}

	private static BogeyStyle.Builder builder(String name, class_2960 cycleGroup) {
		return new BogeyStyle.Builder(Create.asResource(name), cycleGroup);
	}

	@ApiStatus.Internal
	public static void init() {
	}
}
