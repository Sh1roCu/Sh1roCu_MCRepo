package com.simibubi.create.content.contraptions;

import java.lang.ref.WeakReference;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.Nullable;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3499.class_3501;
import net.minecraft.class_3965;
import net.minecraft.class_745;
import net.minecraft.class_746;
import org.apache.commons.lang3.mutable.MutableObject;

import com.simibubi.create.AllItems;
import com.simibubi.create.content.contraptions.sync.ContraptionInteractionPacket;
import com.simibubi.create.content.trains.entity.CarriageContraptionEntity;
import com.simibubi.create.content.trains.entity.TrainRelocator;
import com.simibubi.create.foundation.utility.PersistentDataHelper;
import com.simibubi.create.foundation.utility.RaycastHelper;
import com.simibubi.create.foundation.utility.RaycastHelper.PredicateTraceResult;

import net.createmod.catnip.platform.CatnipServices;
import net.createmod.catnip.data.Couple;
import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.math.VecHelper;

public class ContraptionHandlerClient {

	@Environment(EnvType.CLIENT)
	public static void preventRemotePlayersWalkingAnimations(class_1657 player) {
		if (!(player instanceof class_745 remotePlayer))
			return;

		class_2487 data = PersistentDataHelper.get(remotePlayer);
		if (!data.method_10545("LastOverrideLimbSwingUpdate"))
			return;

		int lastOverride = data.method_10550("LastOverrideLimbSwingUpdate");
		data.method_10569("LastOverrideLimbSwingUpdate", lastOverride + 1);
		if (lastOverride > 5) {
			data.method_10551("LastOverrideLimbSwingUpdate");
			data.method_10551("OverrideLimbSwing");
			return;
		}

		float limbSwing = data.method_10583("OverrideLimbSwing");
		remotePlayer.field_6014 = remotePlayer.method_23317() - (limbSwing / 4);
		remotePlayer.field_5969 = remotePlayer.method_23321();
	}

	@Environment(EnvType.CLIENT)
	public static class_1269 rightClickingOnContraptionsGetsHandledLocally(class_310 mc, class_239 result, class_1268 hand) {
		if (class_310.method_1551().field_1755 != null) // this is the only input event that doesn't check this?
			return class_1269.field_5811;

		class_746 player = mc.field_1724;

		if (player == null)
			return class_1269.field_5811;
		if (player.method_7325())
			return class_1269.field_5811;
		if (mc.field_1687 == null)
			return class_1269.field_5811;
		if (mc.field_1761 == null)
			return class_1269.field_5811;
//		if (!event.isUseItem())
//			return InteractionResult.PASS;

		Couple<class_243> rayInputs = getRayInputs(player);
		class_243 origin = rayInputs.getFirst();
		class_243 target = rayInputs.getSecond();
			class_238 aabb = new class_238(origin, target).method_1014(16);

			Collection<WeakReference<AbstractContraptionEntity>> contraptions =
				ContraptionHandler.loadedContraptions.get(mc.field_1687)
					.values();
			Set<AbstractContraptionEntity> candidates = new HashSet<>();
			for (WeakReference<AbstractContraptionEntity> ref : contraptions) {
				AbstractContraptionEntity contraptionEntity = ref.get();
				if (contraptionEntity != null)
					candidates.add(contraptionEntity);
			}
			// Fallback for cases where the contraption cache missed spawn events.
			candidates.addAll(mc.field_1687.method_18467(AbstractContraptionEntity.class, aabb));

			double bestDistance = Double.MAX_VALUE;
			class_3965 bestResult = null;
			AbstractContraptionEntity bestEntity = null;

			for (AbstractContraptionEntity contraptionEntity : candidates) {
				if (!contraptionEntity.method_5829()
					.method_994(aabb))
					continue;

			class_3965 rayTraceResult = rayTraceContraption(origin, target, contraptionEntity);
			if (rayTraceResult == null)
				continue;

			double distance = contraptionEntity.toGlobalVector(rayTraceResult.method_17784(), 1).method_1022(origin);
			if (distance > bestDistance)
				continue;

			bestResult = rayTraceResult;
			bestDistance = distance;
			bestEntity = contraptionEntity;
		}

		if (bestResult == null)
			return class_1269.field_5811;

		class_2350 face = bestResult.method_17780();
		class_2338 pos = bestResult.method_17777();

		if (bestEntity.handlePlayerInteraction(player, pos, face, hand)) {
			CatnipServices.NETWORK.sendToServer(new ContraptionInteractionPacket(bestEntity, hand, pos, face));
		} else if (!handleSpecialInteractions(bestEntity, player, pos, face, hand)) {
			// Client can be out of sync while the train entity is binding; let server authority decide interaction validity.
			CatnipServices.NETWORK.sendToServer(new ContraptionInteractionPacket(bestEntity, hand, pos, face));
		}

		return class_1269.field_5814;
	}

	private static boolean handleSpecialInteractions(AbstractContraptionEntity contraptionEntity, class_1657 player,
													 class_2338 localPos, class_2350 side, class_1268 interactionHand) {
		if (AllItems.WRENCH.isIn(player.method_5998(interactionHand))
			&& contraptionEntity instanceof CarriageContraptionEntity car)
			return TrainRelocator.carriageWrenched(car.toGlobalVector(VecHelper.getCenterOf(localPos), 1), car);
		return false;
	}

	@Environment(EnvType.CLIENT)
	public static Couple<class_243> getRayInputs(class_746 player) {
		class_310 mc = class_310.method_1551();
		class_243 origin = RaycastHelper.getTraceOrigin(player);
		double reach = player.method_55754();
		if (mc.field_1765 != null && mc.field_1765.method_17784() != null)
			reach = Math.min(mc.field_1765.method_17784()
				.method_1022(origin), reach);
		class_243 target = RaycastHelper.getTraceTarget(player, reach, origin);
		return Couple.create(origin, target);
	}

	@Nullable
	public static class_3965 rayTraceContraption(class_243 origin, class_243 target,
													 AbstractContraptionEntity contraptionEntity) {
		class_243 localOrigin = contraptionEntity.toLocalVector(origin, 1);
		class_243 localTarget = contraptionEntity.toLocalVector(target, 1);
		Contraption contraption = contraptionEntity.getContraption();

		MutableObject<class_3965> mutableResult = new MutableObject<>();
		PredicateTraceResult predicateResult = RaycastHelper.rayTraceUntil(localOrigin, localTarget, p -> {
			for (class_2350 d : Iterate.directions) {
				if (d == class_2350.field_11036)
					continue;
				class_2338 pos = d == class_2350.field_11033 ? p : p.method_10093(d);
				class_3501 blockInfo = contraption.getBlocks()
					.get(pos);
				if (blockInfo == null)
					continue;
				class_2680 state = blockInfo.comp_1342();
				class_265 raytraceShape = state.method_26218(contraption.getContraptionWorld(), class_2338.field_10980.method_10074());
				if (raytraceShape.method_1110())
					continue;
				if (contraption.isHiddenInPortal(pos))
					continue;
				class_3965 rayTrace = raytraceShape.method_1092(localOrigin, localTarget, pos);
				if (rayTrace != null) {
					mutableResult.setValue(rayTrace);
					return true;
				}
			}
			return false;
		});

		if (predicateResult == null || predicateResult.missed())
			return null;

		class_3965 rayTraceResult = mutableResult.getValue();
		return rayTraceResult;
	}

}
