package com.simibubi.create.content.contraptions.chassis;

import com.simibubi.create.AllPartialModels;
import com.simibubi.create.foundation.blockEntity.renderer.SafeBlockEntityRenderer;

import dev.engine_room.flywheel.api.visualization.VisualizationManager;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SuperByteBuffer;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;

public class StickerRenderer extends SafeBlockEntityRenderer<StickerBlockEntity> {

	public StickerRenderer(class_5614.class_5615 context) {
	}

	@Override
	protected void renderSafe(StickerBlockEntity be, float partialTicks, class_4587 ms, class_4597 buffer,
		int light, int overlay) {

		if (VisualizationManager.supportsVisualization(be.method_10997())) return;

		class_2680 state = be.method_11010();
		SuperByteBuffer head = CachedBuffers.partial(AllPartialModels.STICKER_HEAD, state);
		float offset = be.piston.getValue(AnimationTickHolder.getPartialTicks(be.method_10997()));

		if (be.method_10997() != class_310.method_1551().field_1687 && !be.isVirtual())
			offset = state.method_11654(StickerBlock.EXTENDED) ? 1 : 0;

		class_2350 facing = state.method_11654(StickerBlock.field_10927);
		head.nudge(be.hashCode())
			.center()
			.rotateYDegrees(AngleHelper.horizontalAngle(facing))
			.rotateXDegrees(AngleHelper.verticalAngle(facing) + 90)
			.uncenter()
			.translate(0, (offset * offset) * 4 / 16f, 0);

		head.light(light)
			.renderInto(ms, buffer.getBuffer(class_1921.method_23577()));
	}

}
