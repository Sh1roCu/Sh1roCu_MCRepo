package com.simibubi.create.content.equipment.symmetryWand;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5819;
import net.minecraft.class_746;
import org.joml.Vector3f;
import com.simibubi.create.AllItems;
import com.simibubi.create.content.equipment.symmetryWand.mirror.EmptyMirror;
import com.simibubi.create.content.equipment.symmetryWand.mirror.SymmetryMirror;
import com.simibubi.create.foundation.render.fabric.DefaultLayerFilteringBakedModel;
import com.simibubi.create.foundation.utility.AdventureUtil;

import net.createmod.catnip.animation.AnimationTickHolder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;

public class SymmetryHandler {

	private static int tickCounter = 0;
	private static boolean handlingSymmetry = false; // fabric: prevent infinite recursion in break event listening

	public static void onBlockPlaced(class_1750 context, class_2338 pos, class_2680 state) {
		if (context.method_8045()
			.method_8608())
			return;

		class_1792 held = context.method_8041().method_7909();
		if (!(held instanceof class_1747))
			return;

		class_1657 player = context.method_8036();
		if (player == null || AdventureUtil.isAdventure(player))
			return;
		class_1661 inv = player.method_31548();
		for (int i = 0; i < class_1661.method_7368(); i++)
			if (AllItems.WAND_OF_SYMMETRY.isIn(inv.method_5438(i)))
				SymmetryWandItem.apply(player.method_37908(), inv.method_5438(i), player, pos, state);
	}

	public static boolean onBlockDestroyed(class_1937 world, class_1657 player, class_2338 pos, class_2680 state, /* Nullable */ class_2586 blockEntity) {
		if (handlingSymmetry || AdventureUtil.isAdventure(player))
			return true;

		if (world
			.method_8608())
			return true;

		if (player.method_7325())
			return true;

		class_1661 inv = player.method_31548();
		handlingSymmetry = true;
		for (int i = 0; i < class_1661.method_7368(); i++)
			if (AllItems.WAND_OF_SYMMETRY.isIn(inv.method_5438(i)))
				SymmetryWandItem.remove(player.method_37908(), inv.method_5438(i), player, pos, state);
		handlingSymmetry = false;
		return true;
	}

	@Environment(EnvType.CLIENT)
	public static void render(WorldRenderContext context) {
		class_310 mc = class_310.method_1551();
		class_746 player = mc.field_1724;
		class_5819 random = class_5819.method_43047();

		for (int i = 0; i < class_1661.method_7368(); i++) {
			class_1799 stackInSlot = player.method_31548()
				.method_5438(i);
			if (!AllItems.WAND_OF_SYMMETRY.isIn(stackInSlot))
				continue;
			if (!SymmetryWandItem.isEnabled(stackInSlot))
				continue;
			SymmetryMirror mirror = SymmetryWandItem.getMirror(stackInSlot);
			if (mirror instanceof EmptyMirror)
				continue;

			class_2338 pos = class_2338.method_49638(mirror.getPosition());

			float yShift = 0;
			double speed = 1 / 16d;
			yShift = class_3532.method_15374((float) (AnimationTickHolder.getRenderTime() * speed)) / 5f;

			class_4597.class_4598 buffer = mc.method_22940()
				.method_23000();
			class_4184 info = mc.field_1773.method_19418();
			class_243 view = info.method_19326();

			class_4587 ms = context.matrixStack();
			ms.method_22903();
			ms.method_22904(pos.method_10263() - view.method_10216(), pos.method_10264() - view.method_10214(), pos.method_10260() - view.method_10215());
			ms.method_46416(0, yShift + .2f, 0);
			mirror.applyModelTransform(ms);
			class_1087 model = mirror.getModel()
				.get();
			class_4588 builder = buffer.getBuffer(class_1921.method_23577());

			model = DefaultLayerFilteringBakedModel.wrap(model);
			mc.method_1541()
				.method_3350()
				.method_3374(player.method_37908(), model, class_2246.field_10124.method_9564(), pos, ms, builder, true,
					random, class_3532.method_15389(pos), class_4608.field_21444);

			ms.method_22909();
			buffer.method_22993();
		}
	}

	@Environment(EnvType.CLIENT)
	public static void onClientTick(class_310 client) {
//		if (event.phase == Phase.START)
//			return;
		class_310 mc = class_310.method_1551();
		class_746 player = mc.field_1724;

		if (mc.field_1687 == null)
			return;
		if (mc.method_1493())
			return;

		tickCounter++;

		if (tickCounter % 10 == 0) {
			for (int i = 0; i < class_1661.method_7368(); i++) {
				class_1799 stackInSlot = player.method_31548()
					.method_5438(i);

				if (stackInSlot != null && AllItems.WAND_OF_SYMMETRY.isIn(stackInSlot)
					&& SymmetryWandItem.isEnabled(stackInSlot)) {

					SymmetryMirror mirror = SymmetryWandItem.getMirror(stackInSlot);
					if (mirror instanceof EmptyMirror)
						continue;

					class_5819 r = class_5819.method_43047();
					double offsetX = (r.method_43058() - 0.5) * 0.3;
					double offsetZ = (r.method_43058() - 0.5) * 0.3;

					class_243 pos = mirror.getPosition()
						.method_1031(0.5 + offsetX, 1 / 4d, 0.5 + offsetZ);
					class_243 speed = new class_243(0, r.method_43058() * 1 / 8f, 0);
					mc.field_1687.method_8406(class_2398.field_11207, pos.field_1352, pos.field_1351, pos.field_1350, speed.field_1352, speed.field_1351, speed.field_1350);
				}
			}
		}

	}

	public static void drawEffect(class_2338 from, class_2338 to) {
		double density = 0.8f;
		class_243 start = class_243.method_24954(from)
			.method_1031(0.5, 0.5, 0.5);
		class_243 end = class_243.method_24954(to)
			.method_1031(0.5, 0.5, 0.5);
		class_243 diff = end.method_1020(start);

		class_243 step = diff.method_1029()
			.method_1021(density);
		int steps = (int) (diff.method_1033() / step.method_1033());

		class_5819 r = class_5819.method_43047();
		for (int i = 3; i < steps - 1; i++) {
			class_243 pos = start.method_1019(step.method_1021(i));
			class_243 speed = new class_243(0, r.method_43058() * -40f, 0);

			class_310.method_1551().field_1687.method_8406(new class_2390(new Vector3f(1, 1, 1), 1), pos.field_1352, pos.field_1351,
				pos.field_1350, speed.field_1352, speed.field_1351, speed.field_1350);
		}

		class_243 speed = new class_243(0, r.method_43058() * 1 / 32f, 0);
		class_243 pos = start.method_1019(step.method_1021(2));
		class_310.method_1551().field_1687.method_8406(class_2398.field_11207, pos.field_1352, pos.field_1351, pos.field_1350, speed.field_1352, speed.field_1351,
			speed.field_1350);

		speed = new class_243(0, r.method_43058() * 1 / 32f, 0);
		pos = start.method_1019(step.method_1021(steps));
		class_310.method_1551().field_1687.method_8406(class_2398.field_11207, pos.field_1352, pos.field_1351, pos.field_1350, speed.field_1352, speed.field_1351,
			speed.field_1350);
	}

}
