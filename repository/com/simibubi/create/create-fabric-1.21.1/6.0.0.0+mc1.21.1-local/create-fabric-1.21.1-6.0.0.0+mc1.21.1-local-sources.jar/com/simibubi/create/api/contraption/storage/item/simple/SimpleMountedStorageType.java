package com.simibubi.create.api.contraption.storage.item.simple;

import org.jetbrains.annotations.Nullable;

import com.mojang.serialization.MapCodec;

import org.jetbrains.annotations.Nullable;

import com.mojang.serialization.Codec;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorageType;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.SlottedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public abstract class SimpleMountedStorageType<T extends SimpleMountedStorage> extends MountedItemStorageType<SimpleMountedStorage> {
	protected SimpleMountedStorageType(MapCodec<T> codec) {
		super(codec);
	}

	@Override
	@Nullable
	public SimpleMountedStorage mount(class_1937 level, class_2680 state, class_2338 pos, @Nullable class_2586 be) {
		SlottedStorage<ItemVariant> storage = this.getStorage(level, state, pos, be);
		return this.createStorage(storage);
	}

	protected SlottedStorage<ItemVariant> getStorage(class_1937 level, class_2680 state, class_2338 pos, @Nullable class_2586 be) {
		Storage<ItemVariant> storage = ItemStorage.SIDED.find(level, pos, state, be, null);
		// make sure the storage is slotted so new contents can be moved over on disassembly
		return storage instanceof SlottedStorage<ItemVariant> slotted ? slotted : null;
	}

	@Nullable
	protected SimpleMountedStorage createStorage(SlottedStorage<ItemVariant> storage) {
		return new SimpleMountedStorage(storage);
	}

	public static final class Impl extends SimpleMountedStorageType<SimpleMountedStorage> {
		public Impl() {
			super(SimpleMountedStorage.CODEC);
		}
	}
}
