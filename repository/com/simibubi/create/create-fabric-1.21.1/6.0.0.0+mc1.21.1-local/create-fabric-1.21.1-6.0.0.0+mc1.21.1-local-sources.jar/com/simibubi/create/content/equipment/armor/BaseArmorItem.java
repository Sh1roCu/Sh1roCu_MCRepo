package com.simibubi.create.content.equipment.armor;

import java.util.Locale;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;
import io.github.fabricators_of_create.porting_lib.item.ArmorTextureItem;

public class BaseArmorItem extends class_1738 implements ArmorTextureItem {
	protected final class_2960 textureLoc;

	public BaseArmorItem(class_6880<class_1741> armorMaterial, class_1738.class_8051 type, class_1793 properties, class_2960 textureLoc) {
		super(armorMaterial, type, properties.method_7889(1));
		this.textureLoc = textureLoc;
	}

	@Override
	public @Nullable class_2960 getArmorTexture(class_1799 stack, class_1297 entity, class_1304 slot, class_1741.class_9196 layer, boolean innerModel) {
		return class_2960.method_60654(String.format(Locale.ROOT, "%s:textures/models/armor/%s_layer_%d.png", textureLoc.method_12836(), textureLoc.method_12832(), slot == class_1304.field_6172 ? 2 : 1));
	}
}
