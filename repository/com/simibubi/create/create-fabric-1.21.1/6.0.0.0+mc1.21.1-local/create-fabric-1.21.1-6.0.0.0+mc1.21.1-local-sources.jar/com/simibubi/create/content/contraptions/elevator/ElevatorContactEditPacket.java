package com.simibubi.create.content.contraptions.elevator;

import com.simibubi.create.AllPackets;
import com.simibubi.create.content.decoration.slidingDoor.DoorControl;
import com.simibubi.create.foundation.networking.BlockEntityConfigurationPacket;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class ElevatorContactEditPacket extends BlockEntityConfigurationPacket<ElevatorContactBlockEntity> {
	public static final class_9139<class_2540, ElevatorContactEditPacket> STREAM_CODEC = class_9139.method_56905(
			class_2338.field_48404, packet -> packet.pos,
			class_9135.method_56364(4), packet -> packet.shortName,
			class_9135.method_56364(90), packet -> packet.longName,
			DoorControl.STREAM_CODEC, packet -> packet.doorControl,
			ElevatorContactEditPacket::new
	);

	private final String shortName;
	private final String longName;
	private final DoorControl doorControl;

	public ElevatorContactEditPacket(class_2338 pos, String shortName, String longName, DoorControl doorControl) {
		super(pos);
		this.shortName = shortName;
		this.longName = longName;
		this.doorControl = doorControl;
	}

	@Override
	protected void applySettings(class_3222 player, ElevatorContactBlockEntity be) {
		be.updateName(shortName, longName);
		be.doorControls.set(doorControl);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CONFIGURE_ELEVATOR_CONTACT;
	}
}
