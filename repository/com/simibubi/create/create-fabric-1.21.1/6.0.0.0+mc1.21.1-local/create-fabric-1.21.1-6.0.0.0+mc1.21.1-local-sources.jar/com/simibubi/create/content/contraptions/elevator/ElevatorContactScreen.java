package com.simibubi.create.content.contraptions.elevator;

import org.lwjgl.glfw.GLFW;

import com.google.common.collect.ImmutableList;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.decoration.slidingDoor.DoorControl;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import com.simibubi.create.foundation.gui.AllIcons;
import com.simibubi.create.foundation.gui.widget.IconButton;
import com.simibubi.create.foundation.gui.widget.Label;
import com.simibubi.create.foundation.gui.widget.ScrollInput;
import com.simibubi.create.foundation.gui.widget.TooltipArea;
import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_124;
import net.minecraft.class_2338;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import com.simibubi.create.foundation.utility.CreateLang;

import net.createmod.catnip.data.Pair;
import net.createmod.catnip.gui.AbstractSimiScreen;
import net.createmod.catnip.gui.element.GuiGameElement;

public class ElevatorContactScreen extends AbstractSimiScreen {

	private AllGuiTextures background;

	private class_342 shortNameInput;
	private class_342 longNameInput;
	private IconButton confirm;

	private String shortName;
	private String longName;
	private DoorControl doorControl;

	private class_2338 pos;

	public ElevatorContactScreen(class_2338 pos, String prevShortName, String prevLongName, DoorControl prevDoorControl) {
		super(CreateLang.translateDirect("elevator_contact.title"));
		this.pos = pos;
		this.doorControl = prevDoorControl;
		background = AllGuiTextures.ELEVATOR_CONTACT;
		this.shortName = prevShortName;
		this.longName = prevLongName;
	}

	@Override
	public void method_25426() {
		setWindowSize(background.getWidth() + 30, background.getHeight());
		super.method_25426();

		int x = guiLeft;
		int y = guiTop;

		confirm = new IconButton(x + 200, y + 58, AllIcons.I_CONFIRM);
		confirm.withCallback(this::confirm);
		method_37063(confirm);

		shortNameInput = editBox(33, 30, 4);
		shortNameInput.method_1852(shortName);
		centerInput(x);
		shortNameInput.method_1863(s -> {
			shortName = s;
			centerInput(x);
		});
		shortNameInput.method_25365(true);
		method_25395(shortNameInput);
		shortNameInput.method_1884(0);

		longNameInput = editBox(63, 140, 30);
		longNameInput.method_1852(longName);
		longNameInput.method_1863(s -> longName = s);

		class_5250 rmbToEdit = CreateLang.translate("gui.schedule.lmb_edit")
			.style(class_124.field_1063)
			.style(class_124.field_1056)
			.component();

		method_37060(new TooltipArea(x + 21, y + 23, 30, 18)
			.withTooltip(ImmutableList.of(CreateLang.translate("elevator_contact.floor_identifier")
				.color(0x5391E1)
				.component(), rmbToEdit)));

		method_37060(new TooltipArea(x + 57, y + 23, 147, 18).withTooltip(ImmutableList.of(
			CreateLang.translate("elevator_contact.floor_description")
				.color(0x5391E1)
				.component(),
			CreateLang.translate("crafting_blueprint.optional")
				.style(class_124.field_1080)
				.component(),
			rmbToEdit)));

		Pair<ScrollInput, Label> doorControlWidgets =
			DoorControl.createWidget(x + 58, y + 57, mode -> doorControl = mode, doorControl);
		method_37063(doorControlWidgets.getFirst());
		method_37063(doorControlWidgets.getSecond());
	}

	private int centerInput(int x) {
		int centeredX = x + (shortName.isEmpty() ? 34 : 36 - field_22793.method_1727(shortName) / 2);
		shortNameInput.method_46421(centeredX);
		return centeredX;
	}

	private class_342 editBox(int x, int width, int chars) {
		class_342 editBox = new class_342(field_22793, guiLeft + x, guiTop + 30, width, 10, class_5244.field_39003);
		editBox.method_1868(-1);
		editBox.method_1860(-1);
		editBox.method_1858(false);
		editBox.method_1880(chars);
		editBox.method_25365(false);
		editBox.method_25402(0, 0, 0);
		method_37063(editBox);
		return editBox;
	}

	@Override
	protected void renderWindow(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		int x = guiLeft;
		int y = guiTop;

		background.render(graphics, x, y);

		class_5481 formattedcharsequence = field_22785.method_30937();
		graphics.method_51430(field_22793, formattedcharsequence,
			x + (background.getWidth() - 8) / 2 - field_22793.method_30880(formattedcharsequence) / 2, y + 6, 0x2F3738, false);

		GuiGameElement.of(AllBlocks.ELEVATOR_CONTACT.asStack()).<GuiGameElement
				.GuiRenderBuilder>at(x + background.getWidth() + 6, y + background.getHeight() - 56, -200)
			.scale(5)
			.render(graphics);

		graphics.method_51427(AllBlocks.TRAIN_DOOR.asStack(), x + 37, y + 58);
	}

	@Override
	public boolean method_25402(double pMouseX, double pMouseY, int pButton) {
		boolean consumed = super.method_25402(pMouseX, pMouseY, pButton);

		if (!shortNameInput.method_25370()) {
			int length = shortNameInput.method_1882()
				.length();
			shortNameInput.method_1884(length);
			shortNameInput.method_1875(length);
		}

		if (shortNameInput.method_25367())
			longNameInput.method_25402(0, 0, 0);

		if (!consumed && pMouseX > guiLeft + 22 && pMouseY > guiTop + 24 && pMouseX < guiLeft + 50
			&& pMouseY < guiTop + 40) {
			method_25395(shortNameInput);
			shortNameInput.method_25365(true);
			return true;
		}

		return consumed;
	}

	@Override
	public boolean method_25404(int keyCode, int p_keyPressed_2_, int p_keyPressed_3_) {
		if (super.method_25404(keyCode, p_keyPressed_2_, p_keyPressed_3_))
			return true;
		if (keyCode == GLFW.GLFW_KEY_ENTER) {
			confirm();
			return true;
		}
		if (keyCode == 256 && this.method_25422()) {
			this.method_25419();
			return true;
		}
		return false;
	}

	private void confirm() {
		CatnipServices.NETWORK.sendToServer(new ElevatorContactEditPacket(pos, shortName, longName, doorControl));
		method_25419();
	}

}
