package com.simibubi.create.content.equipment.goggles;

import java.util.ArrayList;
import java.util.List;

import com.simibubi.create.AllItems;
import com.simibubi.create.foundation.utility.CreateLang;
import com.simibubi.create.infrastructure.config.AllConfigs;

import net.createmod.catnip.gui.AbstractSimiScreen;
import net.createmod.catnip.gui.element.GuiGameElement;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_5244;
import net.minecraft.class_5348;

public class GoggleConfigScreen extends AbstractSimiScreen {

	private int offsetX;
	private int offsetY;
	private final List<class_2561> tooltip;

	public GoggleConfigScreen() {
		class_2561 componentSpacing = class_2561.method_43470("    ");
		tooltip = new ArrayList<>();
		tooltip.add(componentSpacing.method_27662()
			.method_10852(CreateLang.translateDirect("gui.config.overlay1")));
		tooltip.add(componentSpacing.method_27662()
			.method_10852(CreateLang.translateDirect("gui.config.overlay2")
				.method_27692(class_124.field_1080)));
		tooltip.add(class_5244.field_39003);
		tooltip.add(componentSpacing.method_27662()
			.method_10852(CreateLang.translateDirect("gui.config.overlay3")));
		tooltip.add(componentSpacing.method_27662()
			.method_10852(CreateLang.translateDirect("gui.config.overlay4")));
		tooltip.add(class_5244.field_39003);
		tooltip.add(componentSpacing.method_27662()
			.method_10852(CreateLang.translateDirect("gui.config.overlay5")
				.method_27692(class_124.field_1080)));
		tooltip.add(componentSpacing.method_27662()
			.method_10852(CreateLang.translateDirect("gui.config.overlay6")
				.method_27692(class_124.field_1080)));
		tooltip.add(class_5244.field_39003);
		tooltip.add(componentSpacing.method_27662()
			.method_10852(CreateLang.translateDirect("gui.config.overlay7")));
		tooltip.add(componentSpacing.method_27662()
			.method_10852(CreateLang.translateDirect("gui.config.overlay8")));
	}

	@Override
	protected void method_25426() {
		this.field_22789 = field_22787.method_22683()
			.method_4486();
		this.field_22790 = field_22787.method_22683()
			.method_4502();

		offsetX = AllConfigs.client().overlayOffsetX.get();
		offsetY = AllConfigs.client().overlayOffsetY.get();
	}

	@Override
	public void method_25432() {
		AllConfigs.client().overlayOffsetX.set(offsetX);
		AllConfigs.client().overlayOffsetY.set(offsetY);
	}

	@Override
	public boolean method_25402(double x, double y, int button) {
		updateOffset(x, y);

		return true;
	}

	@Override
	public boolean method_25403(double p_mouseDragged_1_, double p_mouseDragged_3_, int p_mouseDragged_5_,
								double p_mouseDragged_6_, double p_mouseDragged_8_) {
		updateOffset(p_mouseDragged_1_, p_mouseDragged_3_);

		return true;
	}

	private void updateOffset(double windowX, double windowY) {
		offsetX = (int) (windowX - (this.field_22789 / 2));
		offsetY = (int) (windowY - (this.field_22790 / 2));

		int titleLinesCount = 1;
		int tooltipTextWidth = 0;
		for (class_5348 textLine : tooltip) {
			int textLineWidth = field_22787.field_1772.method_27525(textLine);
			if (textLineWidth > tooltipTextWidth)
				tooltipTextWidth = textLineWidth;
		}
		int tooltipHeight = 8;
		if (tooltip.size() > 1) {
			tooltipHeight += (tooltip.size() - 1) * 10;
			if (tooltip.size() > titleLinesCount)
				tooltipHeight += 2; // gap between title lines and next lines
		}

		offsetX = class_3532.method_15340(offsetX, -(field_22789 / 2) - 5, (field_22789 / 2) - tooltipTextWidth - 20);
		offsetY = class_3532.method_15340(offsetY, -(field_22790 / 2) + 17, (field_22790 / 2) - tooltipHeight + 5);
	}

	@Override
	protected void renderWindow(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		int posX = this.field_22789 / 2 + offsetX;
		int posY = this.field_22790 / 2 + offsetY;
		graphics.method_51434(field_22793, tooltip, posX, posY);

		// UIRenderHelper.breadcrumbArrow(ms, 50, 50, 100, 50, 20, 10, 0x80aa9999, 0x10aa9999);
		// UIRenderHelper.breadcrumbArrow(ms, 100, 80, 0, -50, 20, -10, 0x80aa9999, 0x10aa9999);

		class_1799 item = AllItems.GOGGLES.asStack();
		GuiGameElement.of(item)
			.at(posX + 10, posY - 16, 450)
			.render(graphics);
		// GuiGameElement.of(item).at(0, 0, 450).render(ms);
	}
}
