package com.simibubi.create.content.contraptions;

import java.util.Collection;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang3.mutable.MutableInt;
import org.apache.commons.lang3.tuple.MutablePair;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import com.simibubi.create.content.contraptions.actors.psi.PortableStorageInterfaceMovement;
import com.simibubi.create.content.contraptions.actors.seat.SeatBlock;
import com.simibubi.create.content.contraptions.actors.seat.SeatEntity;
import com.simibubi.create.content.contraptions.actors.trainControls.ControlsStopControllingPacket;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.contraptions.data.ContraptionSyncLimiting;
import com.simibubi.create.content.contraptions.elevator.ElevatorContraption;
import com.simibubi.create.content.contraptions.glue.SuperGlueEntity;
import com.simibubi.create.content.contraptions.mounted.MountedContraption;
import com.simibubi.create.content.contraptions.render.ContraptionRenderInfo;
import com.simibubi.create.content.contraptions.sync.ContraptionSeatMappingPacket;
import com.simibubi.create.content.decoration.slidingDoor.SlidingDoorBlock;
import com.simibubi.create.content.trains.entity.CarriageContraption;
import com.simibubi.create.content.trains.entity.CarriageContraptionEntity;
import com.simibubi.create.content.trains.entity.Train;
import com.simibubi.create.foundation.advancement.AllAdvancements;
import com.simibubi.create.foundation.collision.Matrix3d;
import com.simibubi.create.foundation.mixin.accessor.ServerLevelAccessor;
import com.simibubi.create.foundation.utility.AdventureUtil;

import dev.engine_room.flywheel.api.backend.BackendManager;
import io.netty.handler.codec.DecoderException;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.math.VecHelper;
import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1321;
import net.minecraft.class_1530;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1688;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2505;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_3499.class_3501;
import net.minecraft.class_3532;
import net.minecraft.class_3619;
import net.minecraft.class_4048;
import net.minecraft.class_4587;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import io.github.fabricators_of_create.porting_lib.entity.IEntityWithComplexSpawn;
import io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor.EntityAccessor;

public abstract class AbstractContraptionEntity extends class_1297 implements IEntityWithComplexSpawn {

	private static final class_2940<Boolean> STALLED =
		class_2945.method_12791(AbstractContraptionEntity.class, class_2943.field_13323);
	private static final class_2940<Optional<UUID>> CONTROLLED_BY =
		class_2945.method_12791(AbstractContraptionEntity.class, class_2943.field_13313);

	public final Map<class_1297, MutableInt> collidingEntities;

	protected Contraption contraption;
	protected boolean initialized;
	protected boolean prevPosInvalid;
	private boolean skipActorStop;
	private int clientSpawnDataGraceTicks = 20;
	private boolean collisionRegistered;

	/*
	 * staleTicks are a band-aid to prevent a frame or two of missing blocks between
	 * contraption discard and off-thread block placement on disassembly
	 *
	 * FIXME this timeout should be longer but then also cancelled early based on a
	 * chunk rebuild listener
	 */
	public int staleTicks = 3;

	public AbstractContraptionEntity(class_1299<?> entityTypeIn, class_1937 worldIn) {
		super(entityTypeIn, worldIn);
		prevPosInvalid = true;
		collidingEntities = new IdentityHashMap<>();
	}

	protected void setContraption(Contraption contraption) {
		this.contraption = contraption;
		if (contraption == null)
			return;
		if (method_37908().field_9236)
			return;
		contraption.onEntityCreated(this);
	}

	@Override
	public void method_5784(class_1313 pType, class_243 pPos) {
		if (pType == class_1313.field_6309)
			return;
		if (pType == class_1313.field_6306)
			return;
		if (pType == class_1313.field_6310)
			return;
		super.method_5784(pType, pPos);
	}

	public boolean supportsTerrainCollision() {
		return contraption instanceof TranslatingContraption && !(contraption instanceof ElevatorContraption);
	}

	protected void contraptionInitialize() {
		contraption.onEntityInitialize(method_37908(), this);
		initialized = true;
	}

	public boolean collisionEnabled() {
		return true;
	}

	public void registerColliding(class_1297 collidingEntity) {
		collidingEntities.put(collidingEntity, new MutableInt());
	}

	public void addSittingPassenger(class_1297 passenger, int seatIndex) {
		for (class_1297 entity : method_5685()) {
			class_2338 seatOf = contraption.getSeatOf(entity.method_5667());
			if (seatOf != null && seatOf.equals(contraption.getSeats()
				.get(seatIndex))) {
				if (entity instanceof class_1657)
					return;
				if (!(passenger instanceof class_1657))
					return;
				entity.method_5848();
			}
		}
		passenger.method_5873(this, true);
		if (passenger instanceof class_1321 ta)
			ta.method_6179(true);
		if (method_37908().field_9236)
			return;
		contraption.getSeatMapping()
			.put(passenger.method_5667(), seatIndex);

		CatnipServices.NETWORK.sendToClientsTrackingEntity(this, new ContraptionSeatMappingPacket(method_5628(), contraption.getSeatMapping()));
	}

	@Override
	protected void method_5793(class_1297 passenger) {
		// fabric: when a passenger is present, passengers are synced too early. Everything seems to behave fine anyway if this is ignored.
		// This is not an issue on forge because extra data is directly part of the spawn packet.
		// there's some ordering weirdness that I spent a couple hours debugging and gave up on.
		if (this.contraption == null)
			return;
		class_243 transformedVector = getPassengerPosition(passenger, 1);
		super.method_5793(passenger);
		if (passenger instanceof class_1321 ta)
			ta.method_6179(false);
		if (method_37908().field_9236)
			return;
		if (transformedVector != null)
			passenger.getCustomData()
				.method_10566("ContraptionDismountLocation", VecHelper.writeNBT(transformedVector));
		contraption.getSeatMapping()
			.remove(passenger.method_5667());

		CatnipServices.NETWORK.sendToClientsTrackingEntity(this,
				new ContraptionSeatMappingPacket(method_5628(), contraption.getSeatMapping(), passenger.method_5628()));
	}

	@Override
	public class_243 method_24829(class_1309 entityLiving) {
		class_243 position = super.method_24829(entityLiving);
		class_2487 data = entityLiving.getCustomData();
		if (!data.method_10545("ContraptionDismountLocation"))
			return position;

		position = VecHelper.readNBT(data.method_10554("ContraptionDismountLocation", class_2520.field_33256));
		data.method_10551("ContraptionDismountLocation");
		entityLiving.method_24830(false);

		if (!data.method_10545("ContraptionMountLocation"))
			return position;

		class_243 prevPosition = VecHelper.readNBT(data.method_10554("ContraptionMountLocation", class_2520.field_33256));
		data.method_10551("ContraptionMountLocation");
		if (entityLiving instanceof class_1657 player && !prevPosition.method_24802(position, 5000))
			AllAdvancements.LONG_TRAVEL.awardTo(player);
		return position;
	}

	@Override
	public void method_5865(class_1297 passenger, class_4738 callback) {
		if (!method_5626(passenger))
			return;
		class_243 transformedVector = getPassengerPosition(passenger, 1);
		if (transformedVector == null)
			return;

		float offset = -1 / 8f;
		if (passenger instanceof AbstractContraptionEntity)
			offset = 0.0f;
		callback.accept(passenger, transformedVector.field_1352,
			transformedVector.field_1351 + SeatEntity.getCustomEntitySeatOffset(passenger) + offset, transformedVector.field_1350);
	}

	public class_243 getPassengerPosition(class_1297 passenger, float partialTicks) {
		if (contraption == null)
			return null;

		UUID id = passenger.method_5667();
		if (passenger instanceof OrientedContraptionEntity) {
			class_2338 localPos = contraption.getBearingPosOf(id);
			if (localPos != null)
				return toGlobalVector(VecHelper.getCenterOf(localPos), partialTicks)
					.method_1019(VecHelper.getCenterOf(class_2338.field_10980))
					.method_1023(.5f, 1, .5f);
		}

		class_238 bb = passenger.method_5829();
		double ySize = bb.method_17940();
		class_2338 seat = contraption.getSeatOf(id);
		if (seat == null)
			return null;

		class_243 transformedVector = toGlobalVector(class_243.method_24954(seat)
			.method_1031(.5,
				-passenger.method_55668(this).field_1351 + ySize + .125
					- SeatEntity.getCustomEntitySeatOffset(passenger),
				.5),
			partialTicks).method_1019(VecHelper.getCenterOf(class_2338.field_10980))
				.method_1023(0.5, ySize, 0.5);
		return transformedVector;
	}

	@Override
	protected boolean method_5818(@NotNull class_1297 pPassenger) {
		if (pPassenger instanceof OrientedContraptionEntity)
			return true;
		return contraption.getSeatMapping()
			.size() < contraption.getSeats()
			.size();
	}

	public class_2561 getContraptionName() {
		return method_5477();
	}

	public Optional<UUID> getControllingPlayer() {
		return field_6011.method_12789(CONTROLLED_BY);
	}

	public void setControllingPlayer(@Nullable UUID playerId) {
		field_6011.method_12778(CONTROLLED_BY, Optional.ofNullable(playerId));
	}

	public boolean startControlling(class_2338 controlsLocalPos, class_1657 player) {
		return false;
	}

	public boolean control(class_2338 controlsLocalPos, Collection<Integer> heldControls, class_1657 player) {
		return true;
	}

	public void stopControlling(class_2338 controlsLocalPos) {
		getControllingPlayer().map(method_37908()::method_18470)
			.map(p -> (p instanceof class_3222) ? ((class_3222) p) : null)
			.ifPresent(p -> CatnipServices.NETWORK.sendToClient(p, ControlsStopControllingPacket.INSTANCE));
		setControllingPlayer(null);
	}

	public boolean handlePlayerInteraction(class_1657 player, class_2338 localPos, class_2350 side,
										   class_1268 interactionHand) {
		int indexOfSeat = contraption.getSeats()
			.indexOf(localPos);
		if (indexOfSeat == -1 || AllItems.WRENCH.isIn(player.method_5998(interactionHand))) {
			if (contraption.interactors.containsKey(localPos))
				return contraption.interactors.get(localPos)
					.handlePlayerInteraction(player, interactionHand, localPos, this);
			return contraption.storage.handlePlayerStorageInteraction(contraption, player, localPos);
		}
		if (player.method_5765())
			return false;

		// Eject potential existing passenger
		class_1297 toDismount = null;
		for (Entry<UUID, Integer> entry : contraption.getSeatMapping()
			.entrySet()) {
			if (entry.getValue() != indexOfSeat)
				continue;
			for (class_1297 entity : method_5685()) {
				if (!entry.getKey()
					.equals(entity.method_5667()))
					continue;
				if (entity instanceof class_1657)
					return false;
				toDismount = entity;
			}
		}

		if (toDismount != null && AdventureUtil.isAdventure(player))
			return false;

		if (toDismount != null && !method_37908().field_9236) {
			class_243 transformedVector = getPassengerPosition(toDismount, 1);
			toDismount.method_5848();
			if (transformedVector != null)
				toDismount.method_5859(transformedVector.field_1352, transformedVector.field_1351, transformedVector.field_1350);
		}

		if (method_37908().field_9236)
			return true;
		addSittingPassenger(SeatBlock.getLeashed(method_37908(), player)
			.or(player), indexOfSeat);
		return true;
	}

	public class_243 toGlobalVector(class_243 localVec, float partialTicks) {
		return toGlobalVector(localVec, partialTicks, false);
	}

	public class_243 toGlobalVector(class_243 localVec, float partialTicks, boolean prevAnchor) {
		class_243 anchor = prevAnchor ? getPrevAnchorVec() : getAnchorVec();
		class_243 rotationOffset = VecHelper.getCenterOf(class_2338.field_10980);
		localVec = localVec.method_1020(rotationOffset);
		localVec = applyRotation(localVec, partialTicks);
		localVec = localVec.method_1019(rotationOffset)
			.method_1019(anchor);
		return localVec;
	}

	public class_243 toLocalVector(class_243 localVec, float partialTicks) {
		return toLocalVector(localVec, partialTicks, false);
	}

	public class_243 toLocalVector(class_243 globalVec, float partialTicks, boolean prevAnchor) {
		class_243 anchor = prevAnchor ? getPrevAnchorVec() : getAnchorVec();
		class_243 rotationOffset = VecHelper.getCenterOf(class_2338.field_10980);
		globalVec = globalVec.method_1020(anchor)
			.method_1020(rotationOffset);
		globalVec = reverseRotation(globalVec, partialTicks);
		globalVec = globalVec.method_1019(rotationOffset);
		return globalVec;
	}

	@Override
	public void method_5773() {
		if (contraption == null) {
			// Fabric can deliver complex spawn data shortly after the entity itself.
			// Wait a few client ticks before discarding to avoid despawning moving contraptions early.
			if (method_37908().field_9236 && clientSpawnDataGraceTicks-- > 0) {
				super.method_5773();
				return;
			}
			method_31472();
			return;
		}

		if (!collisionRegistered) {
			ContraptionHandler.addSpawnedContraptionsToCollisionList(this, method_37908());
			collisionRegistered = true;
		}

		collidingEntities.entrySet()
			.removeIf(e -> e.getValue()
				.incrementAndGet() > 3);

		field_6014 = method_23317();
		field_6036 = method_23318();
		field_5969 = method_23321();
		prevPosInvalid = false;

		if (!initialized)
			contraptionInitialize();

		contraption.tickStorage(this);
		tickContraption();
		super.method_5773();

		if (method_37908().method_8608()) {
			AbstractContraptionEntityClient.invalidate(contraption);
		}

		if (!(method_37908() instanceof ServerLevelAccessor sl))
			return;

		for (class_1297 entity : method_5685()) {
			if (entity instanceof class_1657)
				continue;
			if (entity.method_31747())
				continue;
			if (sl.create$getEntityTickList()
				.method_31793(entity))
				continue;
			method_24201(entity);
		}
	}

	public void alignPassenger(class_1297 passenger) {
		class_243 motion = getContactPointMotion(passenger.method_33571());
		if (class_3532.method_20390(motion.method_1033(), 0))
			return;
		if (passenger instanceof class_1531)
			return;
		if (!(passenger instanceof class_1309 living))
			return;
		float prevAngle = living.method_36454();
		float angle = AngleHelper.deg(-class_3532.method_15349(motion.field_1352, motion.field_1350));
		angle = AngleHelper.angleLerp(0.4f, prevAngle, angle);
		if (method_37908().field_9236) {
			living.method_5759(0, 0, 0, 0, 0, 0);
			living.method_5683(0, 0);
			living.method_36456(angle);
			living.method_36457(0);
			living.field_6283 = angle;
			living.field_6241 = angle;
		} else
			living.method_36456(angle);
	}

	public void setBlock(class_2338 localPos, class_3501 newInfo) {
		contraption.blocks.put(localPos, newInfo);
		CatnipServices.NETWORK.sendToClientsTrackingEntity(this, new ContraptionBlockChangedPacket(method_5628(), localPos, newInfo.comp_1342()));
	}

	protected abstract void tickContraption();

	public abstract class_243 applyRotation(class_243 localPos, float partialTicks);

	public abstract class_243 reverseRotation(class_243 localPos, float partialTicks);

	public void tickActors() {
		boolean stalledPreviously = contraption.stalled;

		if (!method_37908().field_9236)
			contraption.stalled = false;

		skipActorStop = true;
		for (MutablePair<class_3501, MovementContext> pair : contraption.getActors()) {
			MovementContext context = pair.right;
			class_3501 blockInfo = pair.left;
			MovementBehaviour actor = MovementBehaviour.REGISTRY.get(blockInfo.comp_1342());

			if (actor == null)
				continue;

			class_243 oldMotion = context.motion;
			class_243 actorPosition = toGlobalVector(VecHelper.getCenterOf(blockInfo.comp_1341())
				.method_1019(actor.getActiveAreaOffset(context)), 1);
			class_2338 gridPosition = class_2338.method_49638(actorPosition);
			boolean newPosVisited =
				!context.stall && shouldActorTrigger(context, blockInfo, actor, actorPosition, gridPosition);

			context.rotation = v -> applyRotation(v, 1);
			context.position = actorPosition;
			if (!isActorActive(context, actor) && !actor.mustTickWhileDisabled())
				continue;
			if (newPosVisited && !context.stall) {
				actor.visitNewPosition(context, gridPosition);
				if (!method_5805())
					break;
				context.firstMovement = false;
			}
			if (!oldMotion.equals(context.motion)) {
				actor.onSpeedChanged(context, oldMotion, context.motion);
				if (!method_5805())
					break;
			}
			actor.tick(context);
			if (!method_5805())
				break;
			contraption.stalled |= context.stall;
		}
		if (!method_5805()) {
			contraption.stop(method_37908());
			return;
		}
		skipActorStop = false;

		for (class_1297 entity : method_5685()) {
			if (!(entity instanceof OrientedContraptionEntity orientedCE))
				continue;
			if (!contraption.stabilizedSubContraptions.containsKey(entity.method_5667()))
				continue;
			if (orientedCE.contraption != null && orientedCE.contraption.stalled) {
				contraption.stalled = true;
				break;
			}
		}

		if (!method_37908().field_9236) {
			if (!stalledPreviously && contraption.stalled)
				onContraptionStalled();
			field_6011.method_12778(STALLED, contraption.stalled);
			return;
		}

		contraption.stalled = isStalled();
	}

	public void refreshPSIs() {
		for (MutablePair<class_3501, MovementContext> pair : contraption.getActors()) {
			MovementContext context = pair.right;
			class_3501 blockInfo = pair.left;
			MovementBehaviour actor = MovementBehaviour.REGISTRY.get(blockInfo.comp_1342());
			if (actor instanceof PortableStorageInterfaceMovement && isActorActive(context, actor))
				if (context.position != null)
					actor.visitNewPosition(context, class_2338.method_49638(context.position));
		}
	}

	protected boolean isActorActive(MovementContext context, MovementBehaviour actor) {
		return actor.isActive(context);
	}

	protected void onContraptionStalled() {
		CatnipServices.NETWORK.sendToClientsTrackingEntity(this, new ContraptionStallPacket(method_5628(), method_23317(), method_23318(), method_23321(), getStalledAngle()));
	}

	protected boolean shouldActorTrigger(MovementContext context, class_3501 blockInfo, MovementBehaviour actor,
										 class_243 actorPosition, class_2338 gridPosition) {
		class_243 previousPosition = context.position;
		if (previousPosition == null)
			return false;

		context.motion = actorPosition.method_1020(previousPosition);

		if (!method_37908().method_8608() && context.contraption.entity instanceof CarriageContraptionEntity cce
			&& cce.getCarriage() != null) {
			Train train = cce.getCarriage().train;
			double actualSpeed = train.speedBeforeStall != null ? train.speedBeforeStall : train.speed;
			context.motion = context.motion.method_1029()
				.method_1021(Math.abs(actualSpeed));
		}

		class_243 relativeMotion = context.motion;
		relativeMotion = reverseRotation(relativeMotion, 1);
		context.relativeMotion = relativeMotion;

		boolean ignoreMotionForFirstMovement =
			context.contraption instanceof CarriageContraption || actor instanceof PortableStorageInterfaceMovement;

		return !class_2338.method_49638(previousPosition)
			.equals(gridPosition)
			|| (context.relativeMotion.method_1033() > 0 || ignoreMotionForFirstMovement) && context.firstMovement;
	}

	public void move(double x, double y, double z) {
		method_5814(method_23317() + x, method_23318() + y, method_23321() + z);
	}

	public class_243 getAnchorVec() {
		return method_19538();
	}

	public class_243 getPrevAnchorVec() {
		return getPrevPositionVec();
	}

	public float getYawOffset() {
		return 0;
	}

	@Override
	public void method_5814(double x, double y, double z) {
		super.method_5814(x, y, z);
		if (contraption == null)
			return;
		class_238 cbox = contraption.bounds;
		if (cbox == null)
			return;
		class_243 actualVec = getAnchorVec();
		method_5857(cbox.method_997(actualVec));
	}

	public static float yawFromVector(class_243 vec) {
		return (float) ((3 * Math.PI / 2 + Math.atan2(vec.field_1350, vec.field_1352)) / Math.PI * 180);
	}

	public static float pitchFromVector(class_243 vec) {
		return (float) ((Math.acos(vec.field_1351)) / Math.PI * 180);
	}

	public static FabricEntityTypeBuilder<?> build(FabricEntityTypeBuilder<?> builder) {
//		@SuppressWarnings("unchecked")
//		EntityType.Builder<AbstractContraptionEntity> entityBuilder =
//			(EntityType.Builder<AbstractContraptionEntity>) builder;
		return builder.dimensions(class_4048.method_18385(1, 1));
	}

	@Override
	protected void method_5693(class_2945.class_9222 builder) {
		builder.method_56912(STALLED, false);
		builder.method_56912(CONTROLLED_BY, Optional.empty());
	}

	@Override
	public void writeSpawnData(class_9129 registryFriendlyByteBuf) {
		class_2487 compound = new class_2487();
		writeAdditional(compound, registryFriendlyByteBuf.method_56349(), true);

		if (!CatnipServices.PLATFORM.getLoader().isNeoForge() && ContraptionSyncLimiting.isTooLargeForSync(compound))
			compound = null; // don't sync contraption data

		registryFriendlyByteBuf.method_10794(compound);
	}

	@Override
	protected final void method_5652(class_2487 compound) {
		writeAdditional(compound, method_56673(), false);
	}

	protected void writeAdditional(class_2487 compound, class_7225.class_7874 registries, boolean spawnPacket) {
		if (contraption != null)
			compound.method_10566("Contraption", contraption.writeNBT(registries, spawnPacket));
		compound.method_10556("Stalled", isStalled());
		compound.method_10556("Initialized", initialized);
	}

	@Override
	public void readSpawnData(class_9129 registryFriendlyByteBuf) {
		class_2487 nbt = readAnySizeNbt(registryFriendlyByteBuf);
		if (nbt != null) {
			readAdditional(nbt, true);
		}
	}

	@Override
	protected final void method_5749(class_2487 compound) {
		readAdditional(compound, false);
	}

	@Nullable
	private static class_2487 readAnySizeNbt(class_9129 buf) {
		class_2520 tag = buf.method_30616(class_2505.method_53898());
		if (tag != null && !(tag instanceof class_2487)) {
			throw new DecoderException("Not a compound tag: " + tag);
		} else {
			return (class_2487) tag;
		}
	}

	protected void readAdditional(class_2487 compound, boolean spawnData) {
		if (compound.method_33133())
			return;

		initialized = compound.method_10577("Initialized");
		contraption = Contraption.fromNBT(method_37908(), compound.method_10562("Contraption"), spawnData);
		contraption.entity = this;
		field_6011.method_12778(STALLED, compound.method_10577("Stalled"));
	}

	public void disassemble() {
		if (!method_5805())
			return;
		if (contraption == null)
			return;

		StructureTransform transform = makeStructureTransform();

		contraption.stop(method_37908());
		CatnipServices.NETWORK.sendToClientsTrackingEntity(this, new ContraptionDisassemblyPacket(this.method_5628(), transform));

		contraption.addBlocksToWorld(method_37908(), transform);
		contraption.addPassengersToWorld(method_37908(), transform, method_5685());

		for (class_1297 entity : method_5685()) {
			if (!(entity instanceof OrientedContraptionEntity))
				continue;
			UUID id = entity.method_5667();
			if (!contraption.stabilizedSubContraptions.containsKey(id))
				continue;
			class_2338 transformed = transform.apply(contraption.stabilizedSubContraptions.get(id)
				.getConnectedPos());
			entity.method_5814(transformed.method_10263(), transformed.method_10264(), transformed.method_10260());
			((AbstractContraptionEntity) entity).disassemble();
		}

		skipActorStop = true;
		method_31472();

		method_5772();
		moveCollidedEntitiesOnDisassembly(transform);
		AllSoundEvents.CONTRAPTION_DISASSEMBLE.playOnServer(method_37908(), method_24515());
	}

	private void moveCollidedEntitiesOnDisassembly(StructureTransform transform) {
		for (class_1297 entity : collidingEntities.keySet()) {
			class_243 localVec = toLocalVector(entity.method_19538(), 0);
			class_243 transformed = transform.apply(localVec);
			if (method_37908().field_9236)
				entity.method_5814(transformed.field_1352, transformed.field_1351 + 1 / 16f, transformed.field_1350);
			else
				entity.method_5859(transformed.field_1352, transformed.field_1351 + 1 / 16f, transformed.field_1350);
		}
	}

	@Override
	public void method_5650(class_5529 p_146834_) {
		if (!method_37908().field_9236 && !method_31481() && contraption != null && !skipActorStop)
			contraption.stop(method_37908());
		if (contraption != null)
			contraption.onEntityRemoved(this);
		super.method_5650(p_146834_);
	}

	protected abstract StructureTransform makeStructureTransform();

	@Override
	public void method_5768() {
		method_5772();
		super.method_5768();
	}

	@Override
	protected void method_5825() {
		method_5772();
		super.method_5825();
	}

	@Override
	protected void method_5746() {
	}

	public Contraption getContraption() {
		return contraption;
	}

	public boolean isStalled() {
		return field_6011.method_12789(STALLED);
	}

	@Environment(EnvType.CLIENT)
	static void handleStallPacket(ContraptionStallPacket packet) {
		if (class_310.method_1551().field_1687.method_8469(packet.entityId()) instanceof AbstractContraptionEntity ce)
			ce.handleStallInformation(packet.x(), packet.y(), packet.z(), packet.angle());
	}

	@Environment(EnvType.CLIENT)
	static void handleBlockChangedPacket(ContraptionBlockChangedPacket packet) {
		if (class_310.method_1551().field_1687.method_8469(packet.entityId()) instanceof AbstractContraptionEntity ce)
			ce.handleBlockChange(packet.localPos(), packet.newState());
	}

	@Environment(EnvType.CLIENT)
	static void handleDisassemblyPacket(ContraptionDisassemblyPacket packet) {
		if (class_310.method_1551().field_1687.method_8469(packet.entityId()) instanceof AbstractContraptionEntity ce)
			ce.moveCollidedEntitiesOnDisassembly(packet.transform());
	}

	protected abstract float getStalledAngle();

	protected abstract void handleStallInformation(double x, double y, double z, float angle);

	@Environment(EnvType.CLIENT)
	protected void handleBlockChange(class_2338 localPos, class_2680 newState) {
		if (contraption == null || !contraption.blocks.containsKey(localPos))
			return;
		class_3501 info = contraption.blocks.get(localPos);
		contraption.blocks.put(localPos, new class_3501(info.comp_1341(), newState, info.comp_1343()));
		if (info.comp_1342() != newState && !(newState.method_26204() instanceof SlidingDoorBlock))
			contraption.deferInvalidate = true;
		contraption.invalidateColliders();
	}

	@Override
	public class_2487 method_5647(class_2487 nbt) {
		class_243 vec = method_19538();
		List<class_1297> passengers = method_5685();

		for (class_1297 entity : passengers) {
			// setPos has world accessing side-effects when removed == null
			((EntityAccessor) entity).port_lib$setRemovalReason(class_5529.field_27000);

			// Gather passengers into same chunk when saving
			class_243 prevVec = entity.method_19538();
			entity.method_23327(vec.field_1352, prevVec.field_1351, vec.field_1350);

			// Super requires all passengers to not be removed in order to write them to the
			// tag
			((EntityAccessor) entity).port_lib$setRemovalReason(null);
		}

		class_2487 tag = super.method_5647(nbt);
		return tag;
	}

	@Override
	// Make sure nothing can move contraptions out of the way
	public void method_18799(class_243 motionIn) {
	}

	@Override
	public class_3619 method_5657() {
		return class_3619.field_15975;
	}

	public void setContraptionMotion(class_243 vec) {
		super.method_18799(vec);
	}

	@Override
	public boolean method_5863() {
		return false;
	}

	@Override
	public boolean method_5643(class_1282 source, float amount) {
		return false;
	}

	public class_243 getPrevPositionVec() {
		return prevPosInvalid ? method_19538() : new class_243(field_6014, field_6036, field_5969);
	}

	public abstract ContraptionRotationState getRotationState();

	public class_243 getContactPointMotion(class_243 globalContactPoint) {
		if (prevPosInvalid)
			return class_243.field_1353;

		class_243 contactPoint = toGlobalVector(toLocalVector(globalContactPoint, 0, true), 1, true);
		class_243 contraptionLocalMovement = contactPoint.method_1020(globalContactPoint);
		class_243 contraptionAnchorMovement = method_19538().method_1020(getPrevPositionVec());
		return contraptionLocalMovement.method_1019(contraptionAnchorMovement);
	}

	public boolean method_30949(class_1297 e) {
		if (e instanceof class_1657 && e.method_7325())
			return false;
		if (e.field_5960)
			return false;
		if (e instanceof class_1530)
			return false;
		if (e instanceof class_1688)
			return !(contraption instanceof MountedContraption);
		if (e instanceof SuperGlueEntity)
			return false;
		if (e instanceof SeatEntity)
			return false;
		if (e instanceof class_1676)
			return false;
		if (e.method_5854() != null)
			return false;

		class_1297 riding = this.method_5854();
		while (riding != null) {
			if (riding == e)
				return false;
			riding = riding.method_5854();
		}

		return e.method_5657() == class_3619.field_15974;
	}

	@Override
	public boolean method_5817() {
		return false;
	}

	@Environment(EnvType.CLIENT)
	public abstract void applyLocalTransforms(class_4587 matrixStack, float partialTicks);

	public static class ContraptionRotationState {
		public static final ContraptionRotationState NONE = new ContraptionRotationState();

		public float xRotation = 0;
		public float yRotation = 0;
		public float zRotation = 0;
		public float secondYRotation = 0;

		Matrix3d matrix;

		public Matrix3d asMatrix() {
			if (matrix != null)
				return matrix;

			matrix = new Matrix3d().asIdentity();
			if (xRotation != 0)
				matrix.multiply(new Matrix3d().asXRotation(AngleHelper.rad(-xRotation)));
			if (yRotation != 0)
				matrix.multiply(new Matrix3d().asYRotation(AngleHelper.rad(-yRotation)));
			if (zRotation != 0)
				matrix.multiply(new Matrix3d().asZRotation(AngleHelper.rad(-zRotation)));
			return matrix;
		}

		public boolean hasVerticalRotation() {
			return xRotation != 0 || zRotation != 0;
		}

		public float getYawOffset() {
			return secondYRotation;
		}

	}

	@Override
	protected boolean method_5876() {
		/*
		 * Override this with an empty method to reduce enormous calculation time when
		 * contraptions are in water WARNING: THIS HAS A BUNCH OF SIDE EFFECTS! - Fluids
		 * will not try to change contraption movement direction - this.inWater and
		 * this.isInWater() will return unreliable data - entities riding a contraption
		 * will not cause water splashes (seats are their own entity so this should be
		 * fine) - fall distance is not reset when the contraption is in water -
		 * this.eyesInWater and this.canSwim() will always be false - swimming state
		 * will never be updated
		 */
		return false;
	}

	@Override
	public void method_56073(int ticks) {
		// Contraptions no longer catch fire
	}

	@Override
	public boolean method_5753() {
		return true;
	}

	// Contraptions shouldn't activate pressure plates and tripwires
	@Override
	public boolean method_5696() {
		return true;
	}

	public boolean isReadyForRender() {
		return initialized;
	}

	public boolean isAliveOrStale() {
		return method_5805() || method_37908().method_8608() ? staleTicks > 0 : false;
	}

	public boolean isPrevPosInvalid() {
		return prevPosInvalid;
	}

	private static class AbstractContraptionEntityClient {
		private static void invalidate(Contraption contraption) {
			// The visual will handle this with flywheel on.
			if (!contraption.deferInvalidate || BackendManager.isBackendOn())
				return;
			contraption.deferInvalidate = false;
			ContraptionRenderInfo.invalidate(contraption);
		}
	}
}
