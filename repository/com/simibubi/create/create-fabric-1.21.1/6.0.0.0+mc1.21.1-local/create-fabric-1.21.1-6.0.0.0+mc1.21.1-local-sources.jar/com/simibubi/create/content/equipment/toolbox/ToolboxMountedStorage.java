package com.simibubi.create.content.equipment.toolbox;

import org.jetbrains.annotations.Nullable;

import com.mojang.serialization.MapCodec;
import com.simibubi.create.AllMountedStorageTypes;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorageType;
import com.simibubi.create.api.contraption.storage.item.WrapperMountedItemStorage;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.foundation.item.ItemHelper;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3499.class_3501;
import net.minecraft.class_7225;

public class ToolboxMountedStorage extends WrapperMountedItemStorage<ToolboxInventory> {
	public static final MapCodec<ToolboxMountedStorage> CODEC = ToolboxInventory.CODEC.xmap(
		ToolboxMountedStorage::new, storage -> storage.wrapped
	).fieldOf("value");

	protected ToolboxMountedStorage(MountedItemStorageType<?> type, ToolboxInventory wrapped) {
		super(type, wrapped);
	}

	protected ToolboxMountedStorage(ToolboxInventory wrapped) {
		this(AllMountedStorageTypes.TOOLBOX.get(), wrapped);
	}

	@Override
	public void unmount(class_1937 level, class_2680 state, class_2338 pos, @Nullable class_2586 be) {
		if (be instanceof ToolboxBlockEntity toolbox) {
			ItemHelper.copyContents(this, toolbox.inventory);
		}
	}

	@Override
	public boolean handleInteraction(class_3222 player, Contraption contraption, class_3501 info) {
		// The default impl will fail anyway, might as well cancel trying
		return false;
	}

	public static ToolboxMountedStorage fromToolbox(ToolboxBlockEntity toolbox) {
		// the inventory will send updates to the block entity, make an isolated copy to avoid that
		ToolboxInventory copy = new ToolboxInventory(null);
		ItemHelper.copyContents(toolbox.inventory, copy);
		copy.filters = toolbox.inventory.filters.stream().map(class_1799::method_7972).toList();
		return new ToolboxMountedStorage(copy);
	}

	public static ToolboxMountedStorage fromLegacy(class_7225.class_7874 registries, class_2487 nbt) {
		ToolboxInventory inv = new ToolboxInventory(null);
		inv.deserializeNBT(registries, nbt);
		return new ToolboxMountedStorage(inv);
	}
}
