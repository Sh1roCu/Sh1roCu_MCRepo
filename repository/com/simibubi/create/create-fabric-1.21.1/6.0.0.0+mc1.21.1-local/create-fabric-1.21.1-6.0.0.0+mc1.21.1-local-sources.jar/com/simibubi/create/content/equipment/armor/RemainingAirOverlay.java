package com.simibubi.create.content.equipment.armor;

import java.util.List;
import com.simibubi.create.AllItems;

import net.createmod.catnip.gui.element.GuiGameElement;
import net.createmod.catnip.theme.Color;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3486;
import net.minecraft.class_3544;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.class_9080;
import net.minecraft.class_9334;
import net.minecraft.class_9779;

public class RemainingAirOverlay implements class_9080.class_9081 {
	public static final RemainingAirOverlay INSTANCE = new RemainingAirOverlay();

	@Override
	public void render(class_332 guiGraphics, class_9779 deltaTracker) {
		class_310 mc = class_310.method_1551();
		if (mc.field_1690.field_1842 || mc.field_1761.method_2920() == class_1934.field_9219)
			return;

		class_746 player = mc.field_1724;
		if (player == null)
			return;
		if (player.method_7337())
			return;
		if (!player.getCustomData()
			.method_10545("VisualBacktankAir"))
			return;
		if (!player.method_5777(class_3486.field_15517) && !player.method_5771())
			return;

		int timeLeft = player.getCustomData()
			.method_10550("VisualBacktankAir");

		class_4587 poseStack = guiGraphics.method_51448();
		poseStack.method_22903();

		class_1799 backtank = getDisplayedBacktank(player);
		poseStack.method_46416(guiGraphics.method_51421() / 2 + 90, guiGraphics.method_51443() - 53 + (backtank
				.method_57826(class_9334.field_50076) ? 9 : 0), 0);

		class_2561 text = class_2561.method_43470(class_3544.method_15439(Math.max(0, timeLeft - 1) * 20, mc.field_1687.method_54719().method_54748()));
		GuiGameElement.of(backtank)
			.at(0, 0)
			.render(guiGraphics);
		int color = 0xFF_FFFFFF;
		if (timeLeft < 60 && timeLeft % 2 == 0) {
			color = Color.mixColors(0xFF_FF0000, color, Math.max(timeLeft / 60f, .25f));
		}
		guiGraphics.method_27535(mc.field_1772, text, 16, 5, color);

		poseStack.method_22909();
	}

	public static class_1799 getDisplayedBacktank(class_746 player) {
		List<class_1799> backtanks = BacktankUtil.getAllWithAir(player);
		if (!backtanks.isEmpty()) {
			return backtanks.getFirst();
		}
		return AllItems.COPPER_BACKTANK.asStack();
	}
}
