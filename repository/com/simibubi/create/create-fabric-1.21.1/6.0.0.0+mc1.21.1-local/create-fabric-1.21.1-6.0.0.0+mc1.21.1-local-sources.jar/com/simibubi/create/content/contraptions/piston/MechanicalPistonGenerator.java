package com.simibubi.create.content.contraptions.piston;

import com.simibubi.create.content.contraptions.piston.MechanicalPistonBlock.PistonState;
import com.simibubi.create.foundation.data.SpecialBlockStateGen;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2665;
import net.minecraft.class_2680;
import net.minecraft.class_2764;

public class MechanicalPistonGenerator extends SpecialBlockStateGen {

	private final class_2764 type;

	public MechanicalPistonGenerator(class_2764 type) {
		this.type = type;
	}

	@Override
	protected int getXRotation(class_2680 state) {
		class_2350 facing = state.method_11654(MechanicalPistonBlock.FACING);
		return facing.method_10166()
			.method_10178() ? facing == class_2350.field_11033 ? 180 : 0 : 90;
	}

	@Override
	protected int getYRotation(class_2680 state) {
		class_2350 facing = state.method_11654(MechanicalPistonBlock.FACING);
		return facing.method_10166()
			.method_10178() ? 0 : horizontalAngle(facing) + 180;
	}

	@Override
	public <T extends class_2248> ModelFile getModel(DataGenContext<class_2248, T> ctx, RegistrateBlockstateProvider prov,
												class_2680 state) {
		class_2350 facing = state.method_11654(class_2665.field_10927);
		boolean axisAlongFirst = state.method_11654(MechanicalPistonBlock.AXIS_ALONG_FIRST_COORDINATE);
		PistonState pistonState = state.method_11654(MechanicalPistonBlock.STATE);

		String path = "block/mechanical_piston";
		String folder = pistonState == PistonState.RETRACTED ? type.method_15434() : pistonState.method_15434();
		String partial = facing.method_10166() == class_2351.field_11048 ^ axisAlongFirst ? "block_rotated" : "block";

		return prov.models()
			.getExistingFile(prov.modLoc(path + "/" + folder + "/" + partial));
	}

}
