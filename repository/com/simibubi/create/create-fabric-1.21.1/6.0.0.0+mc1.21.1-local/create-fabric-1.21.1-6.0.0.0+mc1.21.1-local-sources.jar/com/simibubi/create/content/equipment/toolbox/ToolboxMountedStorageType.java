package com.simibubi.create.content.equipment.toolbox;

import com.simibubi.create.api.contraption.storage.item.MountedItemStorageType;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

public class ToolboxMountedStorageType extends MountedItemStorageType<ToolboxMountedStorage> {
	public ToolboxMountedStorageType() {
		super(ToolboxMountedStorage.CODEC);
	}

	@Override
	@Nullable
	public ToolboxMountedStorage mount(class_1937 level, class_2680 state, class_2338 pos, @Nullable class_2586 be) {
		return be instanceof ToolboxBlockEntity toolbox ? ToolboxMountedStorage.fromToolbox(toolbox) : null;
	}
}
