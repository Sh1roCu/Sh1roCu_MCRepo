package com.simibubi.create.content.contraptions.wrench;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.annotation.Nullable;

import io.github.fabricators_of_create.porting_lib.util.KeyBindingHelper;

import org.joml.Matrix4f;
import com.mojang.blaze3d.systems.RenderSystem;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllKeys;
import com.simibubi.create.Create;
import com.simibubi.create.content.kinetics.base.DirectionalKineticBlock;
import com.simibubi.create.content.kinetics.base.HorizontalAxisKineticBlock;
import com.simibubi.create.content.kinetics.base.HorizontalKineticBlock;
import com.simibubi.create.content.kinetics.base.RotatedPillarKineticBlock;
import com.simibubi.create.content.kinetics.transmission.sequencer.SequencedGearshiftBlock;
import com.simibubi.create.content.redstone.DirectedDirectionalBlock;
import com.simibubi.create.foundation.gui.AllIcons;

import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.createmod.catnip.gui.AbstractSimiScreen;
import net.createmod.catnip.gui.UIRenderHelper;
import net.createmod.catnip.gui.element.GuiGameElement;
import net.createmod.catnip.gui.element.RenderElement;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.platform.CatnipServices;
import net.createmod.catnip.registry.RegisteredObjectsHelper;
import net.createmod.catnip.theme.Color;
import net.createmod.ponder.enums.PonderGuiTextures;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2377;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.class_757;

public class RadialWrenchMenu extends AbstractSimiScreen {

	public static final Map<class_2769<?>, String> VALID_PROPERTIES = new HashMap<>();

	static {
		registerRotationProperty(RotatedPillarKineticBlock.AXIS, "Axis");
		registerRotationProperty(DirectionalKineticBlock.FACING, "Facing");
		registerRotationProperty(HorizontalAxisKineticBlock.HORIZONTAL_AXIS, "Axis");
		registerRotationProperty(HorizontalKineticBlock.HORIZONTAL_FACING, "Facing");
		registerRotationProperty(class_2377.field_11129, "Facing");
		registerRotationProperty(DirectedDirectionalBlock.TARGET, "Target");

		registerRotationProperty(SequencedGearshiftBlock.VERTICAL, "Vertical");
	}

	public static final Set<class_2960> BLOCK_BLACKLIST = new HashSet<>();

	static {
		registerBlacklistedBlock(AllBlocks.LARGE_WATER_WHEEL.getId());
		registerBlacklistedBlock(AllBlocks.WATER_WHEEL_STRUCTURAL.getId());
	}

	public static void registerRotationProperty(class_2769<?> property, String label) {
		if (VALID_PROPERTIES.containsKey(property))
			return;

		VALID_PROPERTIES.put(property, label);
	}

	public static void registerBlacklistedBlock(class_2960 location) {
		if (BLOCK_BLACKLIST.contains(location))
			return;

		BLOCK_BLACKLIST.add(location);
	}

	private final class_2680 state;
	private final class_2338 pos;
	private final class_2586 blockEntity;
	@Nullable private final class_1937 level;
	private final List<Map.Entry<class_2769<?>, String>> propertiesForState;
	private final int innerRadius = 50;
	private final int outerRadius = 110;

	private int selectedPropertyIndex = 0;
	private List<class_2680> allStates = List.of();
	private String propertyLabel = "";
	private int ticksOpen;
	private int selectedStateIndex = 0;

	private final RenderElement iconScroll = RenderElement.of(PonderGuiTextures.ICON_SCROLL);
	private final RenderElement iconUp = RenderElement.of(AllIcons.I_PRIORITY_HIGH);
	private final RenderElement iconDown = RenderElement.of(AllIcons.I_PRIORITY_LOW);

	public static Optional<RadialWrenchMenu> tryCreateFor(class_2680 state, class_2338 pos, @Nullable class_1937 level) {
		if (BLOCK_BLACKLIST.contains(RegisteredObjectsHelper.getKeyOrThrow(state.method_26204())))
			return Optional.empty();

		var propertiesForState = VALID_PROPERTIES.entrySet().stream().filter(entry -> state.method_28498(entry.getKey())).toList();

		if (propertiesForState.isEmpty())
			return Optional.empty();

        return Optional.of(new RadialWrenchMenu(state, pos, level, propertiesForState));
	}

	private RadialWrenchMenu(class_2680 state, class_2338 pos, @Nullable class_1937 level, List<Map.Entry<class_2769<?>, String>> properties) {
		this.state = state;
		this.pos = pos;
		this.level = level;
		this.blockEntity = level.method_8321(pos);
		this.propertiesForState = properties;

		initForSelectedProperty();
	}

	private void initForSelectedProperty() {
		Map.Entry<class_2769<?>, String> entry = propertiesForState.get(selectedPropertyIndex);

		allStates = new ArrayList<>();
		//allStates.add(state);
		cycleAllPropertyValues(state, entry.getKey(), allStates);

		propertyLabel = entry.getValue();
	}

	private void cycleAllPropertyValues(class_2680 state, class_2769<?> property, List<class_2680> states) {
		Optional<? extends Comparable<?>> first = property.method_11898().stream().findFirst();
		if (first.isEmpty())
			return;

		int offset = 0;
		int safety = 100;
		while (safety-- > 0) {
			if (state.method_11654(property).equals(first.get())) {
				offset = 99 - safety;
				break;
			}

			state = state.method_28493(property);
		}

		safety = 100;
		while (safety-- > 0) {
			if (states.contains(state))
				break;

			states.add(state);

			state = state.method_28493(property);
		}

		offset = class_3532.method_15340(offset, 0, states.size() - 1);
		selectedStateIndex = (offset == 0) ? 0 : (states.size() - offset);
	}

	@Override
	public void method_25393() {
		ticksOpen++;
		if (!level.method_8320(pos).method_27852(state.method_26204()))
			class_310.method_1551().method_1507(null);
		super.method_25393();
	}

	@Override
	protected void renderWindow(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		int x = this.field_22789 / 2;
		int y = this.field_22790 / 2;

		class_4587 ms = graphics.method_51448();

		ms.method_22903();
		ms.method_46416(x, y, 0);

		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();

		int mouseOffsetX = mouseX - this.field_22789 / 2;
		int mouseOffsetY = mouseY - this.field_22790 / 2;

		if (class_3532.method_39241(mouseOffsetX, mouseOffsetY) > innerRadius - 5) {
			double theta = class_3532.method_15349(mouseOffsetX, mouseOffsetY);

			float sectorSize = 360f / allStates.size();

			selectedStateIndex = (int) Math.floor(
					((-AngleHelper.deg(class_3532.method_15349(mouseOffsetX, mouseOffsetY)) + 180 + sectorSize / 2) % 360)
					/ sectorSize
			);

			renderDirectionIndicator(graphics, theta);
		}

		renderRadialSectors(graphics);

		UIRenderHelper.streak(graphics, 0, 0, 0, 32, 65, Color.BLACK.setAlpha(0.8f));
		UIRenderHelper.streak(graphics, 180, 0, 0, 32, 65, Color.BLACK.setAlpha(0.8f));

		if (selectedPropertyIndex > 0) {
			iconScroll.at(-14, -46).render(graphics);
			iconUp.at(-1, -46).render(graphics);
			graphics.method_25300(field_22793, propertiesForState.get(selectedPropertyIndex - 1).getValue(), 0, -30, UIRenderHelper.COLOR_TEXT.getFirst().getRGB());
		}

		if (selectedPropertyIndex < propertiesForState.size() - 1) {
			iconScroll.at(-14, 30).render(graphics);
			iconDown.at(-1, 30).render(graphics);
			graphics.method_25300(field_22793, propertiesForState.get(selectedPropertyIndex + 1).getValue(), 0, 22, UIRenderHelper.COLOR_TEXT.getFirst().getRGB());
		}

		graphics.method_25300(field_22793, "Currently", 0, -13, UIRenderHelper.COLOR_TEXT.getFirst().getRGB());
		graphics.method_25300(field_22793, "Changing:", 0, -3, UIRenderHelper.COLOR_TEXT.getFirst().getRGB());
		graphics.method_25300(field_22793, propertyLabel, 0, 7, UIRenderHelper.COLOR_TEXT.getFirst().getRGB());

		ms.method_22909();

	}

	private void renderRadialSectors(class_332 graphics) {
		int sectors = allStates.size();
		if (sectors < 2)
			return;

		class_4587 poseStack = graphics.method_51448();
		class_746 player = class_310.method_1551().field_1724;
		if (player == null)
			return;

		float sectorAngle = 360f / sectors;
		int sectorWidth = outerRadius - innerRadius;

		poseStack.method_22903();

		for (int i = 0; i < sectors; i++) {
			Color innerColor = Color.WHITE.setAlpha(0.05f);
			Color outerColor = Color.WHITE.setAlpha(0.3f);
			class_2680 blockState = allStates.get(i);
			class_2769<?> property = propertiesForState.get(selectedPropertyIndex).getKey();

			poseStack.method_22903();

			if (i == selectedStateIndex) {
				innerColor.mixWith(new Color(0.8f, 0.8f, 0.2f, 0.2f), 0.5f);
				outerColor.mixWith(new Color(0.8f, 0.8f, 0.2f, 0.6f), 0.5f);

				UIRenderHelper.drawRadialSector(graphics, outerRadius + 2, outerRadius + 3, -(sectorAngle / 2 + 90), sectorAngle, outerColor, outerColor);
			}

			UIRenderHelper.drawRadialSector(graphics, innerRadius, outerRadius, -(sectorAngle / 2 + 90), sectorAngle, innerColor, outerColor);
			Color c = innerColor.copy().setAlpha(0.5f);
			UIRenderHelper.drawRadialSector(graphics, innerRadius - 3, innerRadius - 2, -(sectorAngle / 2 + 90), sectorAngle, c, c);

			TransformStack.of(poseStack)
					.translateY(-(sectorWidth / 2f + innerRadius))
					.rotateZDegrees(-i * sectorAngle);

			poseStack.method_46416(0, 0, 100);

			try {
				GuiGameElement.of(blockState, blockEntity)
						.rotateBlock(player.method_36455(), player.method_36454() + 180, 0f)
						.scale(24)
						.at(-12, 12)
						.render(graphics);
			} catch (Exception e) {
				Create.LOGGER.warn("Failed to render blockstate in RadialWrenchMenu", e);
				allStates.remove(i);
				selectedStateIndex = 0;
				return;
			}

			poseStack.method_46416(0, 0, 50);

			if (i == selectedStateIndex) {
				graphics.method_25300(field_22793, blockState.method_11654(property).toString(), 0, 15, UIRenderHelper.COLOR_TEXT.getFirst().getRGB());
			}

			poseStack.method_22909();

			poseStack.method_22903();

			TransformStack.of(poseStack)
					.rotateZDegrees(sectorAngle / 2);

			poseStack.method_46416(0, -innerRadius - 20, 10);

			UIRenderHelper.angledGradient(graphics, -90, 0, 0, 0.5f, sectorWidth - 10, Color.WHITE.setAlpha(0.5f), Color.WHITE.setAlpha(0.15f));
			UIRenderHelper.angledGradient(graphics,  90, 0, 0, 0.5f, 25              , Color.WHITE.setAlpha(0.5f), Color.WHITE.setAlpha(0.15f));
			poseStack.method_22909();

			TransformStack.of(poseStack)
					.rotateZDegrees(sectorAngle);
		}

		poseStack.method_22909();

	}

	private void renderDirectionIndicator(class_332 graphics, double theta) {
		class_4587 poseStack = graphics.method_51448();

		float r = 0.8f;
		float g = 0.8f;
		float b = 0.8f;

		poseStack.method_22903();
		TransformStack.of(poseStack)
			.rotateZ((float) -theta)
			.translateY(innerRadius + 3)
			.translateZ(15);

		RenderSystem.setShader(class_757::method_34540);

		class_289 tesselator = class_289.method_1348();
		class_287 bufferbuilder = tesselator.method_60827(class_5596.field_27381, class_290.field_1576);

		Matrix4f mat = poseStack.method_23760().method_23761();

		bufferbuilder.method_22918(mat, 0, 0, 0).method_22915(r, g, b, 0.75f);

		bufferbuilder.method_22918(mat, 5, -5, 0).method_22915(r, g, b, 0.4f);
		bufferbuilder.method_22918(mat, 3, -4.5f, 0).method_22915(r, g, b, 0.4f);
		bufferbuilder.method_22918(mat, 0, -4.2f, 0).method_22915(r, g, b, 0.4f);
		bufferbuilder.method_22918(mat, -3, -4.5f, 0).method_22915(r, g, b, 0.4f);
		bufferbuilder.method_22918(mat, -5, -5, 0).method_22915(r, g, b, 0.4f);

		class_286.method_43433(bufferbuilder.method_60800());

		poseStack.method_22909();
	}

	private void submitChange() {
		class_2680 selectedState = allStates.get(selectedStateIndex);
        if (selectedState != state) {
			CatnipServices.NETWORK.sendToServer(new RadialWrenchMenuSubmitPacket(pos, selectedState));
        }

		method_25419();
    }

	@Override
	public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		Color color = BACKGROUND_COLOR
			.scaleAlpha(Math.min(1, (ticksOpen + AnimationTickHolder.getPartialTicks()) / 20f));

		guiGraphics.method_25296(0, 0, this.field_22789, this.field_22790, color.getRGB(), color.getRGB());
	}

	@Override
	public boolean method_16803(int code, int scanCode, int modifiers) {
		class_3675.class_306 mouseKey = class_3675.method_15985(code, scanCode);
		if (KeyBindingHelper.isActiveAndMatches(AllKeys.ROTATE_MENU.getKeybind(), mouseKey)) {
			submitChange();
			return true;
		}
		return super.method_16803(code, scanCode, modifiers);
	}

	@Override
	public boolean method_25402(double pMouseX, double pMouseY, int pButton) {
		if (pButton == class_3675.field_32000) {
			submitChange();
			return true;
		} else if (pButton == class_3675.field_32002) {
			method_25419();
			return true;
		}

		return super.method_25402(pMouseX, pMouseY, pButton);
	}

	@Override
	public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
		if (propertiesForState.size() < 2)
			return super.method_25401(mouseX, mouseY, scrollX, scrollY);

		int indexDelta = (int) Math.round(Math.signum(-scrollY));

		int newIndex = selectedPropertyIndex + indexDelta;
		if (newIndex < 0)
			return false;

		if (newIndex >= propertiesForState.size())
			return false;

		selectedPropertyIndex = newIndex;
		initForSelectedProperty();

		return true;
	}

	@Override
	public void method_25432() {
		RadialWrenchHandler.COOLDOWN = 2;

		super.method_25432();
	}
}
