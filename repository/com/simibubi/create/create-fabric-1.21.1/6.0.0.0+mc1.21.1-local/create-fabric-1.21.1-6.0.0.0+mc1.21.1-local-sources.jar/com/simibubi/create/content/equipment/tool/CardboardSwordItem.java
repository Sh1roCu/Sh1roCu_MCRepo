package com.simibubi.create.content.equipment.tool;

import com.simibubi.create.AllItems;
import com.simibubi.create.AllSoundEvents;
import io.github.fabricators_of_create.porting_lib.entity.events.LivingAttackEvent;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public class CardboardSwordItem extends class_1829 {

	public CardboardSwordItem(class_1793 properties) {
		super(AllToolMaterials.CARDBOARD, properties);
	}

	public static class_1269 cardboardSwordsMakeNoiseOnClick(class_1657 player, class_1937 level, class_1268 hand,
		class_2338 pos, class_2350 direction) {
		class_1799 stack = player.method_5998(hand);
		if (!AllItems.CARDBOARD_SWORD.isIn(stack)) {
			return class_1269.field_5811;
		}
		AllSoundEvents.CARDBOARD_SWORD.play(level, player, pos, 0.5f, 1.85f);
		return class_1269.field_5812;
	}

	public static void cardboardSwordsCannotHurtYou(LivingAttackEvent event) {
		class_1309 target = event.getEntity();
		if (target == null) {
			return;
		}
		event.setCanceled(true);
	}
}
