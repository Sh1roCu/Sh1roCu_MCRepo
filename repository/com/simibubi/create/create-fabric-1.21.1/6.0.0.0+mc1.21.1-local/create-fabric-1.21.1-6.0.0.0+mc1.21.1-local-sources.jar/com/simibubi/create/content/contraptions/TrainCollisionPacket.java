package com.simibubi.create.content.contraptions;

import com.simibubi.create.AllPackets;
import com.simibubi.create.content.trains.entity.CarriageContraptionEntity;
import com.simibubi.create.foundation.damageTypes.CreateDamageSources;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.netty.buffer.ByteBuf;

public record TrainCollisionPacket(int damage, int contraptionEntityId) implements ServerboundPacketPayload {
	public static final class_9139<ByteBuf, TrainCollisionPacket> STREAM_CODEC = class_9139.method_56435(
			class_9135.field_49675, TrainCollisionPacket::damage,
			class_9135.field_49675, TrainCollisionPacket::contraptionEntityId,
	        TrainCollisionPacket::new
	);

	@Override
	public void handle(class_3222 player) {
		class_1937 level = player.method_37908();

		class_1297 entity = level.method_8469(contraptionEntityId);
		if (!(entity instanceof CarriageContraptionEntity cce))
			return;

		player.method_5643(CreateDamageSources.runOver(level, cce), damage);
		player.method_37908().method_8396(player, entity.method_24515(), class_3417.field_15016, class_3419.field_15254,
				1, .75f);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.TRAIN_COLLISION;
	}
}
