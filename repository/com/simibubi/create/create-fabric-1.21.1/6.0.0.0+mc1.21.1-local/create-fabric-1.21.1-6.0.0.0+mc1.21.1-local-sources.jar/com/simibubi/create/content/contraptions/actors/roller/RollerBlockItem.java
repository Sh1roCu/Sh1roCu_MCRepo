package com.simibubi.create.content.contraptions.actors.roller;

import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

public class RollerBlockItem extends class_1747 {

	public RollerBlockItem(class_2248 pBlock, class_1793 pProperties) {
		super(pBlock, pProperties);
	}

	@Override
	public class_1269 method_7712(class_1750 ctx) {
		class_2338 clickedPos = ctx.method_8037();
		class_1937 level = ctx.method_8045();
		class_2680 blockStateBelow = level.method_8320(clickedPos.method_10074());
		if (!class_2248.method_9501(blockStateBelow.method_26220(level, clickedPos.method_10074()), class_2350.field_11036))
			return super.method_7712(ctx);
		class_2350 clickedFace = ctx.method_8038();
		return super.method_7712(class_1750.method_16355(ctx, clickedPos.method_10093(class_2350.field_11036), clickedFace));
	}

}
