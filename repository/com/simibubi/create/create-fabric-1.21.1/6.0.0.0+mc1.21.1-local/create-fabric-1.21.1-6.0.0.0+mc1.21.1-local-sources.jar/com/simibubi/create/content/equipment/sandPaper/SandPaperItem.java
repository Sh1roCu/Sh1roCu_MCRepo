package com.simibubi.create.content.equipment.sandPaper;

import java.util.Optional;

import javax.annotation.ParametersAreNonnullByDefault;

import com.simibubi.create.AllDataComponents;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.foundation.item.CustomUseEffectsItem;
import com.simibubi.create.foundation.mixin.accessor.LivingEntityAccessor;

import net.createmod.catnip.data.TriState;
import net.createmod.catnip.math.VecHelper;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import net.minecraft.class_5953;
import net.minecraft.class_5955;
import net.minecraft.class_6328;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor.AxeItemAccessor;


@class_6328
@ParametersAreNonnullByDefault
public class SandPaperItem extends class_1792 implements CustomUseEffectsItem {

	public SandPaperItem(class_1793 properties) {
		super(properties.method_7895(8));
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 worldIn, class_1657 playerIn, class_1268 handIn) {
		class_1799 itemstack = playerIn.method_5998(handIn);
		class_1271<class_1799> FAIL = new class_1271<>(class_1269.field_5814, itemstack);

		if (itemstack.method_57826(AllDataComponents.SAND_PAPER_POLISHING)) {
			playerIn.method_6019(handIn);
			return new class_1271<>(class_1269.field_5811, itemstack);
		}

		class_1268 otherHand =
			handIn == class_1268.field_5808 ? class_1268.field_5810 : class_1268.field_5808;
		class_1799 itemInOtherHand = playerIn.method_5998(otherHand);
		if (SandPaperPolishingRecipe.canPolish(worldIn, itemInOtherHand)) {
			class_1799 item = itemInOtherHand.method_7972();
			class_1799 toPolish = item.method_7971(1);
			playerIn.method_6019(handIn);
			itemstack.method_57379(AllDataComponents.SAND_PAPER_POLISHING, toPolish);
			playerIn.method_6122(otherHand, item);
			return new class_1271<>(class_1269.field_5812, itemstack);
		}

		class_3965 raytraceresult = method_7872(worldIn, playerIn, class_3959.class_242.field_1348);
		class_243 hitVec = raytraceresult.method_17784();

		class_238 bb = new class_238(hitVec, hitVec).method_1014(1f);
		class_1542 pickUp = null;
		for (class_1542 itemEntity : worldIn.method_18467(class_1542.class, bb)) {
			if (!itemEntity.method_5805())
				continue;
			if (itemEntity.method_19538()
				.method_1022(playerIn.method_19538()) > 3)
				continue;
			class_1799 stack = itemEntity.method_6983();
			if (!SandPaperPolishingRecipe.canPolish(worldIn, stack))
				continue;
			pickUp = itemEntity;
			break;
		}

		if (pickUp == null)
			return FAIL;

		class_1799 item = pickUp.method_6983()
			.method_7972();
		class_1799 toPolish = item.method_7971(1);

		playerIn.method_6019(handIn);

		if (!worldIn.field_9236) {
			itemstack.method_57379(AllDataComponents.SAND_PAPER_POLISHING, toPolish);
			if (item.method_7960())
				pickUp.method_31472();
			else
				pickUp.method_6979(item);
		}

		return new class_1271<>(class_1269.field_5812, itemstack);
	}

	@Override
	public class_1799 method_7861(class_1799 stack, class_1937 worldIn, class_1309 entityLiving) {
		if (!(entityLiving instanceof class_1657 player))
			return stack;
		if (stack.method_57826(AllDataComponents.SAND_PAPER_POLISHING)) {
			class_1799 toPolish = stack.method_57824(AllDataComponents.SAND_PAPER_POLISHING);
			//noinspection DataFlowIssue - toPolish won't be null as we do call .has before calling .get
			class_1799 polished =
				SandPaperPolishingRecipe.applyPolish(worldIn, entityLiving.method_19538(), toPolish, stack);

			if (worldIn.field_9236) {
				spawnParticles(entityLiving.method_5836(1)
						.method_1019(entityLiving.method_5720()
							.method_1021(.5f)),
					toPolish, worldIn);
				return stack;
			}

			if (!polished.method_7960()) {
				if (player instanceof FakePlayer) {
					player.method_7329(polished, false, false);
				} else {
					player.method_31548()
						.method_7398(polished);
				}
			}
			stack.method_57381(AllDataComponents.SAND_PAPER_POLISHING);
			stack.method_7970(1, entityLiving, class_1309.method_56079(entityLiving.method_6058()));
		}

		return stack;
	}

	public static void spawnParticles(class_243 location, class_1799 polishedStack, class_1937 world) {
		for (int i = 0; i < 20; i++) {
			class_243 motion = VecHelper.offsetRandomly(class_243.field_1353, world.field_9229, 1 / 8f);
			world.method_8406(new class_2392(class_2398.field_11218, polishedStack), location.field_1352, location.field_1351,
				location.field_1350, motion.field_1352, motion.field_1351, motion.field_1350);
		}
	}

	@Override
	public void method_7840(class_1799 stack, class_1937 worldIn, class_1309 entityLiving, int timeLeft) {
		if (!(entityLiving instanceof class_1657 player))
			return;
		if (stack.method_57826(AllDataComponents.SAND_PAPER_POLISHING)) {
			class_1799 toPolish = stack.method_57824(AllDataComponents.SAND_PAPER_POLISHING);
			//noinspection DataFlowIssue - toPolish won't be null as we do call .has before calling .get
			player.method_31548()
				.method_7398(toPolish);
			stack.method_57381(AllDataComponents.SAND_PAPER_POLISHING);
		}
	}

	@Override
	public class_1269 method_7884(class_1838 context) {
		class_1657 player = context.method_8036();
		class_1799 stack = context.method_8041();
		class_1937 level = context.method_8045();
		class_2338 pos = context.method_8037();
		class_2680 state = level.method_8320(pos);
		AxeItemAccessor access = (AxeItemAccessor) class_1802.field_8556;
		Optional<class_2680> newState = access.porting_lib$getStripped(state);
		if (newState.isPresent()) {
			AllSoundEvents.SANDING_LONG.play(level, player, pos, 1, 1 + (level.field_9229.method_43057() * 0.5f - 1f) / 5f);
			level.method_8444(player, 3005, pos, 0); // Spawn particles
		} else {
			newState = class_5955.method_34735(state);
			if (newState.isEmpty()) { // fabric: account for waxing
				newState = Optional.ofNullable((class_5953.field_29561.get()).get(state.method_26204()))
						.map(block -> block.method_34725(state));
			}
			if (newState.isPresent()) {
				AllSoundEvents.SANDING_LONG.play(level, player, pos, 1,
					1 + (level.field_9229.method_43057() * 0.5f - 1f) / 5f);
				level.method_8444(player, 3004, pos, 0); // Spawn particles
			}
		}

		if (newState.isPresent()) {
			level.method_8501(pos, newState.get());
			if (player != null)
				stack.method_7970(1, player, class_1309.method_56079(player.method_6058()));
			return class_1269.method_29236(level.field_9236);
		}

		return class_1269.field_5811;
	}

//	@Override
//	public boolean canPerformAction(ItemStack stack, ToolAction toolAction) {
//		return toolAction == ToolActions.AXE_SCRAPE || toolAction == ToolActions.AXE_WAX_OFF;
//	}

	@Override
	public TriState shouldTriggerUseEffects(class_1799 stack, class_1309 entity) {
		// Trigger every tick so that we have more fine grain control over the animation
		return TriState.TRUE;
	}

	@Override
	public boolean triggerUseEffects(class_1799 stack, class_1309 entity, int count, class_5819 random) {
		if (stack.method_57826(AllDataComponents.SAND_PAPER_POLISHING)) {
			class_1799 polishing = stack.method_57824(AllDataComponents.SAND_PAPER_POLISHING);
			((LivingEntityAccessor) entity).create$callSpawnItemParticles(polishing, 1);
		}

		// After 6 ticks play the sound every 7th
		if ((entity.method_6048() - 6) % 7 == 0)
			entity.method_5783(entity.method_18869(stack), 0.9F + 0.2F * random.method_43057(),
				random.method_43057() * 0.2F + 0.9F);

		return true;
	}

	@Override
	public class_3414 method_21830() {
		return AllSoundEvents.SANDING_SHORT.getMainEvent();
	}

	@Override
	public class_1839 method_7853(class_1799 stack) {
		return class_1839.field_8950;
	}

	@Override
	public int method_7881(class_1799 stack, class_1309 entity) {
		return 32;
	}

	@Override
	public int method_7837() {
		return 1;
	}

//	@Override
//	@Environment(EnvType.CLIENT)
//	public void initializeClient(Consumer<IClientItemExtensions> consumer) {
//		consumer.accept(SimpleCustomRenderer.create(this, new SandPaperItemRenderer()));
//	}

}
