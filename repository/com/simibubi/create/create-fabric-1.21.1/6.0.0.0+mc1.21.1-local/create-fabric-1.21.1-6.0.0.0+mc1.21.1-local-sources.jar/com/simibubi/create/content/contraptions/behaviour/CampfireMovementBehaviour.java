package com.simibubi.create.content.contraptions.behaviour;

import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import net.minecraft.class_2398;
import net.minecraft.class_3922;
import net.minecraft.class_5819;

public class CampfireMovementBehaviour implements MovementBehaviour {
	@Override
	public void tick(MovementContext context) {
		if (context.world == null || !context.world.field_9236 || context.position == null
			|| !context.state.method_11654(class_3922.field_17352) || context.disabled)
			return;

		// Mostly copied from CampfireBlock and CampfireBlockEntity
		class_5819 random = context.world.field_9229;
		if (random.method_43057() < 0.11F) {
			for (int i = 0; i < random.method_43048(2) + 2; ++i) {
				context.world.method_17452(
					context.state.method_11654(class_3922.field_17353) ? class_2398.field_17431
						: class_2398.field_17430,
					true, context.position.method_10216() + random.method_43058() / (random.method_43056() ? 3D : -3D),
					context.position.method_10214() + random.method_43058() + random.method_43058(),
					context.position.method_10215() + random.method_43058() / (random.method_43056() ? 3D : -3D), 0.0D, 0.07D,
					0.0D);
			}
		}
	}
}
