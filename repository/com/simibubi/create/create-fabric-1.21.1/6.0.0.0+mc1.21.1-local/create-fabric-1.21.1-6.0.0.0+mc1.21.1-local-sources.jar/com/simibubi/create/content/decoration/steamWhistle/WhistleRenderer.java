package com.simibubi.create.content.decoration.steamWhistle;

import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.decoration.steamWhistle.WhistleBlock.WhistleSize;
import com.simibubi.create.foundation.blockEntity.renderer.SafeBlockEntityRenderer;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.render.CachedBuffers;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;

public class WhistleRenderer extends SafeBlockEntityRenderer<WhistleBlockEntity> {

	public WhistleRenderer(class_5614.class_5615 context) {}

	@Override
	protected void renderSafe(WhistleBlockEntity be, float partialTicks, class_4587 ms, class_4597 buffer,
		int light, int overlay) {
		class_2680 blockState = be.method_11010();
		if (!(blockState.method_26204() instanceof WhistleBlock))
			return;

		class_2350 direction = blockState.method_11654(WhistleBlock.FACING);
		WhistleSize size = blockState.method_11654(WhistleBlock.SIZE);

		PartialModel mouth = size == WhistleSize.LARGE ? AllPartialModels.WHISTLE_MOUTH_LARGE
			: size == WhistleSize.MEDIUM ? AllPartialModels.WHISTLE_MOUTH_MEDIUM : AllPartialModels.WHISTLE_MOUTH_SMALL;

		float offset = be.animation.getValue(partialTicks);
		if (be.animation.getChaseTarget() > 0 && be.animation.getValue() > 0.5f) {
			float wiggleProgress = (AnimationTickHolder.getTicks(be.method_10997()) + partialTicks) / 8f;
			offset -= Math.sin(wiggleProgress * (2 * class_3532.field_29844) * (4 - size.ordinal())) / 16f;
		}

		CachedBuffers.partial(mouth, blockState)
			.center()
			.rotateYDegrees(AngleHelper.horizontalAngle(direction))
			.uncenter()
			.translate(0, offset * 4 / 16f, 0)
			.light(light)
			.renderInto(ms, buffer.getBuffer(class_1921.method_23577()));
	}

}
