package com.simibubi.create.content.decoration.copycat;

import java.util.function.Supplier;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.foundation.model.BakedModelHelper;

import net.createmod.catnip.data.Iterate;

import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.model.SpriteFinder;
import net.fabricmc.fabric.api.renderer.v1.model.WrapperBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1723;
import net.minecraft.class_1920;
import net.minecraft.class_2318;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_776;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.model.SpriteFinder;
import net.fabricmc.fabric.api.renderer.v1.model.WrapperBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;

public class CopycatPanelModel extends CopycatModel {

	protected static final class_238 CUBE_AABB = new class_238(class_2338.field_10980);

	public CopycatPanelModel(class_1087 originalModel) {
		super(originalModel);
	}

	@Override
	protected void emitBlockQuadsInner(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context, class_2680 material, CullFaceRemovalData cullFaceRemovalData, OcclusionData occlusionData) {
		class_2350 facing = state.method_28500(CopycatPanelBlock.FACING)
			.orElse(class_2350.field_11036);
		class_776 blockRenderer = class_310.method_1551()
			.method_1541();

		class_2680 specialCopycatModelState = null;
		if (CopycatSpecialCases.isBarsMaterial(material))
			specialCopycatModelState = AllBlocks.COPYCAT_BARS.getDefaultState();
		if (CopycatSpecialCases.isTrapdoorMaterial(material)) {
			((FabricBakedModel) blockRenderer.method_3349(material))
				.emitBlockQuads(blockView, material, pos, randomSupplier, context);
			return;
		}

		if (specialCopycatModelState != null) {
			class_1087 blockModel = blockRenderer
				.method_3349(specialCopycatModelState.method_11657(class_2318.field_10927, facing));

			// fabric: extra handling for wrapped models, see: #1176
			while (blockModel instanceof WrapperBakedModel wbm) {
				if (blockModel instanceof CopycatModel) break;
				blockModel = wbm.getWrappedModel();
			}

			if (blockModel instanceof CopycatModel cm) {
				cm.emitBlockQuadsInner(blockView, state, pos, randomSupplier, context, material, cullFaceRemovalData, occlusionData);
				return;
			}
		}

		class_1087 model = getModelOf(material);

		class_243 normal = class_243.method_24954(facing.method_10163());
		class_243 normalScaled14 = normal.method_1021(14 / 16f);

		SpriteFinder spriteFinder = SpriteFinder.get(class_310.method_1551().method_1554().method_24153(class_1723.field_21668));

		// Use a mesh to defer quad emission since quads cannot be emitted inside a transform
		MeshBuilder meshBuilder = RendererAccess.INSTANCE.getRenderer().meshBuilder();
		QuadEmitter emitter = meshBuilder.getEmitter();
		context.pushTransform(quad -> {
			if (cullFaceRemovalData.shouldRemove(quad.cullFace())) {
				quad.cullFace(null);
			} else if (occlusionData.isOccluded(quad.cullFace())) {
				// Add quad to mesh and do not render original quad to preserve quad render order
				// copyTo does not copy the material
				RenderMaterial quadMaterial = quad.material();
				quad.copyTo(emitter);
				emitter.material(quadMaterial);
				emitter.emit();
				return false;
			}

			// 2 Pieces
			for (boolean front : Iterate.trueAndFalse) {
				class_243 normalScaledN13 = normal.method_1021(front ? 0 : -13 / 16f);
				float contract = 16 - (front ? 1 : 2);
				class_238 bb = CUBE_AABB.method_1002(normal.field_1352 * contract / 16, normal.field_1351 * contract / 16, normal.field_1350 * contract / 16);
				if (!front)
					bb = bb.method_997(normalScaled14);

				class_2350 direction = quad.lightFace();

				if (front && direction == facing)
					continue;
				if (!front && direction == facing.method_10153())
					continue;

				// copyTo does not copy the material
				RenderMaterial quadMaterial = quad.material();
				quad.copyTo(emitter);
				emitter.material(quadMaterial);
				BakedModelHelper.cropAndMove(emitter, spriteFinder.find(emitter, 0), bb, normalScaledN13);
				emitter.emit();
			}

			return false;
		});
		((FabricBakedModel) model).emitBlockQuads(blockView, material, pos, randomSupplier, context);
		context.popTransform();
		context.meshConsumer().accept(meshBuilder.build());
	}

}
