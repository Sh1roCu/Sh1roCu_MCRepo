package com.simibubi.create.content.decoration.steamWhistle;

import java.lang.ref.WeakReference;
import java.util.List;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.api.equipment.goggles.IHaveGoggleInformation;
import com.simibubi.create.content.decoration.steamWhistle.WhistleBlock.WhistleSize;
import com.simibubi.create.content.decoration.steamWhistle.WhistleExtenderBlock.WhistleExtenderShape;
import com.simibubi.create.content.fluids.tank.FluidTankBlockEntity;
import com.simibubi.create.content.kinetics.steamEngine.SteamJetParticleData;
import com.simibubi.create.foundation.advancement.AllAdvancements;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.utility.CreateLang;
import com.tterrag.registrate.fabric.EnvExecutor;

import net.createmod.catnip.platform.CatnipServices;
import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.catnip.animation.LerpedFloat.Chaser;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.math.VecHelper;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_7225;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class WhistleBlockEntity extends SmartBlockEntity implements IHaveGoggleInformation {

	public WeakReference<FluidTankBlockEntity> source;
	public LerpedFloat animation;
	protected int pitch;

	public WhistleBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		source = new WeakReference<>(null);
		animation = LerpedFloat.linear();
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
		registerAwardables(behaviours, AllAdvancements.STEAM_WHISTLE);
	}

	public void updatePitch() {
		class_2338 currentPos = field_11867.method_10084();
		int newPitch;
		for (newPitch = 0; newPitch <= 24; newPitch += 2) {
			class_2680 blockState = field_11863.method_8320(currentPos);
			if (!AllBlocks.STEAM_WHISTLE_EXTENSION.has(blockState))
				break;
			if (blockState.method_11654(WhistleExtenderBlock.SHAPE) == WhistleExtenderShape.SINGLE) {
				newPitch++;
				break;
			}
			currentPos = currentPos.method_10084();
		}
		if (pitch == newPitch)
			return;
		pitch = newPitch;

		notifyUpdate();

		FluidTankBlockEntity tank = getTank();
		if (tank != null && tank.boiler != null)
			tank.boiler.checkPipeOrganAdvancement(tank);
	}

	@Override
	public void tick() {
		super.tick();
		if (!field_11863.method_8608()) {
			if (isPowered())
				award(AllAdvancements.STEAM_WHISTLE);
			return;
		}

		FluidTankBlockEntity tank = getTank();
		boolean powered = isPowered()
			&& (tank != null && tank.boiler.isActive() && (tank.boiler.passiveHeat || tank.boiler.activeHeat > 0)
			|| isVirtual());
		animation.chase(powered ? 1 : 0, powered ? .5f : .4f, powered ? Chaser.EXP : Chaser.LINEAR);
		animation.tickChaser();
		CatnipServices.PLATFORM.executeOnClientOnly(() -> () -> this.tickAudio(getOctave(), powered));
	}

	@Override
	protected void write(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		tag.method_10569("Pitch", pitch);
		super.write(tag, registries, clientPacket);
	}

	@Override
	protected void read(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		pitch = tag.method_10550("Pitch");
		super.read(tag, registries, clientPacket);
	}

	@Override
	public boolean addToGoggleTooltip(List<class_2561> tooltip, boolean isPlayerSneaking) {
		String[] pitches = CreateLang.translateDirect("generic.notes")
			.getString()
			.split(";");
		CreateLang.translate("generic.pitch", pitches[pitch % pitches.length]).forGoggles(tooltip);
		return true;
	}

	protected boolean isPowered() {
		return method_11010().method_28500(WhistleBlock.POWERED)
			.orElse(false);
	}

	protected WhistleSize getOctave() {
		return method_11010().method_28500(WhistleBlock.SIZE)
			.orElse(WhistleSize.MEDIUM);
	}

	@Environment(EnvType.CLIENT)
	protected WhistleSoundInstance soundInstance;

	@Environment(EnvType.CLIENT)
	protected void tickAudio(WhistleSize size, boolean powered) {
		if (!powered) {
			if (soundInstance != null) {
				soundInstance.fadeOut();
				soundInstance = null;
			}
			return;
		}

		float f = (float) Math.pow(2, -pitch / 12.0);
		boolean particle = field_11863.method_8510() % 8 == 0;
		class_243 eyePosition = class_310.method_1551().field_1719.method_33571();
		float maxVolume = (float) class_3532.method_15350((64 - eyePosition.method_1022(class_243.method_24953(field_11867))) / 64, 0, 1);

		if (soundInstance == null || soundInstance.method_4793() || soundInstance.getOctave() != size) {
			class_310.method_1551()
				.method_1483()
				.method_4873(soundInstance = new WhistleSoundInstance(size, field_11867));
			AllSoundEvents.WHISTLE_CHIFF.playAt(field_11863, field_11867, maxVolume * .175f,
				size == WhistleSize.SMALL ? f + .75f : f, false);
			particle = true;
		}

		soundInstance.keepAlive();
		soundInstance.setPitch(f);

		if (!particle)
			return;

		class_2350 facing = method_11010().method_28500(WhistleBlock.FACING)
			.orElse(class_2350.field_11035);
		float angle = 180 + AngleHelper.horizontalAngle(facing);
		class_243 sizeOffset = VecHelper.rotate(new class_243(0, -0.4f, 1 / 16f * size.ordinal()), angle, class_2351.field_11052);
		class_243 offset = VecHelper.rotate(new class_243(0, 1, 0.75f), angle, class_2351.field_11052);
		class_243 v = offset.method_1021(.45f)
			.method_1019(sizeOffset)
			.method_1019(class_243.method_24953(field_11867));
		class_243 m = offset.method_1020(class_243.method_24954(facing.method_10163())
			.method_1021(.75f));
		field_11863.method_8406(new SteamJetParticleData(1), v.field_1352, v.field_1351, v.field_1350, m.field_1352, m.field_1351, m.field_1350);
	}

	public int getPitchId() {
		return pitch + 100 * method_11010().method_28500(WhistleBlock.SIZE)
			.orElse(WhistleSize.MEDIUM)
			.ordinal();
	}

	public FluidTankBlockEntity getTank() {
		FluidTankBlockEntity tank = source.get();
		if (tank == null || tank.method_11015()) {
			if (tank != null)
				source = new WeakReference<>(null);
			class_2350 facing = WhistleBlock.getAttachedDirection(method_11010());
			class_2586 be = field_11863.method_8321(field_11867.method_10093(facing));
			if (be instanceof FluidTankBlockEntity tankBe)
				source = new WeakReference<>(tank = tankBe);
		}
		if (tank == null)
			return null;
		return tank.getControllerBE();
	}

}
