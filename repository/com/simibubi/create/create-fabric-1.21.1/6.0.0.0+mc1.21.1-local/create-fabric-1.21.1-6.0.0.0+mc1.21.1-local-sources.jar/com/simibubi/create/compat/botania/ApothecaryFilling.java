package com.simibubi.create.compat.botania;

import com.simibubi.create.api.behaviour.spouting.BlockSpoutingBehaviour;
import com.simibubi.create.content.fluids.spout.SpoutBlockEntity;
import com.simibubi.create.infrastructure.config.AllConfigs;
import vazkii.botania.api.block.PetalApothecary;

import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import com.simibubi.create.infrastructure.fabric.transfer.fluid.FluidStack;

public enum ApothecaryFilling implements BlockSpoutingBehaviour {
	INSTANCE;

	@Override
	public long fillBlock(class_1937 level, class_2338 pos, SpoutBlockEntity spout, FluidStack availableFluid, boolean simulate) {
		if (!enabled())
			return 0;

		class_2586 be = level.method_8321(pos);
		if (be == null)
			return 0;

		// this shouldn't fail but... better safe than sorry.
		if (!(be instanceof PetalApothecary apothecary))
			return 0;
		// don't insert if it's not empty
		if (apothecary.getFluid() != PetalApothecary.State.EMPTY)
			return 0;

		PetalApothecary.State fluidState;

		class_3611 fluid = availableFluid.getVariant().getFluid();
		if (fluid == class_3612.field_15910) {
			fluidState = PetalApothecary.State.WATER;
		} else if (fluid == class_3612.field_15908) {
			fluidState = PetalApothecary.State.LAVA;
		} else {
			return 0;
		}

		// don't insert if we have less than a bucket's worth of fluid
		if (availableFluid.getAmount() < FluidConstants.BUCKET) {
			return 0;
		}

		if (!simulate) {
			apothecary.setFluid(fluidState);
		}

		return FluidConstants.BUCKET;
	}

	private boolean enabled() {
		return AllConfigs.server().recipes.allowFillingBySpout.get();
	}

}
