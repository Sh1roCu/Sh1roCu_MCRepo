package com.simibubi.create.content.contraptions.bearing;

import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.foundation.block.IBE;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_9062;

public class ClockworkBearingBlock extends BearingBlock implements IBE<ClockworkBearingBlockEntity> {

	public ClockworkBearingBlock(class_2251 properties) {
		super(properties);
	}

	@Override
	protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
		if (!player.method_7294())
			return class_9062.field_47733;
		if (player.method_5715())
			return class_9062.field_47733;
		if (stack.method_7960()) {
			if (!level.field_9236) {
				withBlockEntityDo(level, pos, be -> {
					if (be.running) {
						be.disassemble();
						return;
					}
					be.assembleNextTick = true;
				});
			}
			return class_9062.field_47728;
		}
		return class_9062.field_47731;
	}

	@Override
	public Class<ClockworkBearingBlockEntity> getBlockEntityClass() {
		return ClockworkBearingBlockEntity.class;
	}

	@Override
	public class_1269 onWrenched(class_2680 state, class_1838 context) {
		class_1269 resultType = super.onWrenched(state, context);
		if (!context.method_8045().field_9236 && resultType.method_23665())
			withBlockEntityDo(context.method_8045(), context.method_8037(), ClockworkBearingBlockEntity::disassemble);
		return resultType;
	}

	@Override
	public class_2591<? extends ClockworkBearingBlockEntity> getBlockEntityType() {
		return AllBlockEntityTypes.CLOCKWORK_BEARING.get();
	}

}
