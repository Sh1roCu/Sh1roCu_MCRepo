package com.simibubi.create.content.contraptions.actors.roller;

import java.util.List;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBoxTransform;
import com.simibubi.create.foundation.blockEntity.behaviour.filtering.FilteringBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.INamedIconOptions;
import com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.ScrollOptionBehaviour;
import com.simibubi.create.foundation.gui.AllIcons;
import com.simibubi.create.foundation.utility.CreateLang;

import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.lang.Lang;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2510;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_4587;

public class RollerBlockEntity extends SmartBlockEntity {

	// For simulations such as Ponder
	private float manuallyAnimatedSpeed;

	public FilteringBehaviour filtering;
	public ScrollOptionBehaviour<RollingMode> mode;

	private boolean dontPropagate;

	public RollerBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		dontPropagate = false;
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
		behaviours.add(filtering = new FilteringBehaviour(this, new RollerValueBox(3)));
		behaviours.add(mode = new ScrollOptionBehaviour<>(RollingMode.class,
			CreateLang.translateDirect("contraptions.roller_mode"), this, new RollerValueBox(-3)));

		filtering.setLabel(CreateLang.translateDirect("contraptions.mechanical_roller.pave_material"));
		filtering.withCallback(this::onFilterChanged);
		filtering.withPredicate(this::isValidMaterial);
		mode.withCallback(this::onModeChanged);
	}

	protected void onModeChanged(int mode) {
		shareValuesToAdjacent();
	}

	protected void onFilterChanged(class_1799 newFilter) {
		shareValuesToAdjacent();
	}

	protected boolean isValidMaterial(class_1799 newFilter) {
		if (newFilter.method_7960())
			return true;
		class_2680 appliedState = RollerMovementBehaviour.getStateToPaveWith(newFilter);
		if (appliedState.method_26215())
			return false;
		if (appliedState.method_26204() instanceof class_2343)
			return false;
		if (appliedState.method_26204() instanceof class_2510)
			return false;
		class_265 shape = appliedState.method_26218(field_11863, field_11867);
		if (shape.method_1110() || !shape.method_1107()
			.equals(class_259.method_1077()
				.method_1107()))
			return false;
		class_265 collisionShape = appliedState.method_26220(field_11863, field_11867);
		if (collisionShape.method_1110())
			return false;
		return true;
	}

	@Override
	protected class_238 createRenderBoundingBox() {
		return new class_238(field_11867).method_1014(1);
	}

	public float getAnimatedSpeed() {
		return manuallyAnimatedSpeed;
	}

	public void setAnimatedSpeed(float speed) {
		manuallyAnimatedSpeed = speed;
	}

	public void searchForSharedValues() {
		class_2680 blockState = method_11010();
		class_2350 facing = blockState.method_28500(RollerBlock.field_11177)
			.orElse(class_2350.field_11035);

		for (int side : Iterate.positiveAndNegative) {
			class_2338 pos = field_11867.method_10079(facing.method_10170(), side);
			if (field_11863.method_8320(pos) != blockState)
				continue;
			if (!(field_11863.method_8321(pos) instanceof RollerBlockEntity otherRoller))
				continue;
			acceptSharedValues(otherRoller.mode.getValue(), otherRoller.filtering.getFilter());
			shareValuesToAdjacent();
			break;
		}
	}

	protected void acceptSharedValues(int mode, class_1799 filter) {
		dontPropagate = true;
		this.filtering.setFilter(filter.method_7972());
		this.mode.setValue(mode);
		dontPropagate = false;
		notifyUpdate();
	}

	public void shareValuesToAdjacent() {
		if (dontPropagate || field_11863.method_8608())
			return;
		class_2680 blockState = method_11010();
		class_2350 facing = blockState.method_28500(RollerBlock.field_11177)
			.orElse(class_2350.field_11035);

		for (int side : Iterate.positiveAndNegative) {
			for (int i = 1; i < 100; i++) {
				class_2338 pos = field_11867.method_10079(facing.method_10170(), side * i);
				if (field_11863.method_8320(pos) != blockState)
					break;
				if (!(field_11863.method_8321(pos) instanceof RollerBlockEntity otherRoller))
					break;
				otherRoller.acceptSharedValues(mode.getValue(), filtering.getFilter());
			}
		}
	}

	static enum RollingMode implements INamedIconOptions {

		TUNNEL_PAVE(AllIcons.I_ROLLER_PAVE),
		STRAIGHT_FILL(AllIcons.I_ROLLER_FILL),
		WIDE_FILL(AllIcons.I_ROLLER_WIDE_FILL),

		;

		private String translationKey;
		private AllIcons icon;

		private RollingMode(AllIcons icon) {
			this.icon = icon;
			translationKey = "contraptions.roller_mode." + Lang.asId(name());
		}

		@Override
		public AllIcons getIcon() {
			return icon;
		}

		@Override
		public String getTranslationKey() {
			return translationKey;
		}

	}

	private final class RollerValueBox extends ValueBoxTransform {

		private int hOffset;

		public RollerValueBox(int hOffset) {
			this.hOffset = hOffset;
		}

		@Override
		public void rotate(class_1936 level, class_2338 pos, class_2680 state, class_4587 ms) {
			class_2350 facing = state.method_11654(RollerBlock.field_11177);
			float yRot = AngleHelper.horizontalAngle(facing) + 180;
			TransformStack.of(ms)
				.rotateYDegrees(yRot)
				.rotateXDegrees(90);
		}

		@Override
		public boolean testHit(class_1936 level, class_2338 pos, class_2680 state, class_243 localHit) {
			class_243 offset = getLocalOffset(level, pos, state);
			if (offset == null)
				return false;
			return localHit.method_1022(offset) < scale / 3;
		}

		@Override
		public class_243 getLocalOffset(class_1936 level, class_2338 pos, class_2680 state) {
			class_2350 facing = state.method_11654(RollerBlock.field_11177);
			float stateAngle = AngleHelper.horizontalAngle(facing) + 180;
			return VecHelper.rotateCentered(VecHelper.voxelSpace(8 + hOffset, 15.5f, 11), stateAngle, class_2351.field_11052);
		}

	}

}
