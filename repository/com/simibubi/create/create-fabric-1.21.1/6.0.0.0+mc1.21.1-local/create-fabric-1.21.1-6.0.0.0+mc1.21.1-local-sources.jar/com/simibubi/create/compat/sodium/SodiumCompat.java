package com.simibubi.create.compat.sodium;

import java.util.function.Function;

import com.simibubi.create.Create;
import com.simibubi.create.compat.Mods;

import net.caffeinemc.mods.sodium.api.texture.SpriteUtil;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_1058;
import net.minecraft.class_1723;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Fixes the Mechanical Saw's sprite and Factory Gauge's sprite
 */
public class SodiumCompat {
	public static final class_2960 SAW_TEXTURE = Create.asResource("block/saw_reversed");
	public static final class_2960 FACTORY_PANEL_TEXTURE = Create.asResource("block/factory_panel_connections_animated");

	public static void init() {
		WorldRenderEvents.START.register(ctx -> {
			Function<class_2960, class_1058> atlas = class_310.method_1551().method_1549(class_1723.field_21668);
			class_1058 sawSprite = atlas.apply(SAW_TEXTURE);
			SpriteUtil.INSTANCE.markSpriteActive(sawSprite);

			class_1058 factoryPanelSprite = atlas.apply(FACTORY_PANEL_TEXTURE);
			SpriteUtil.INSTANCE.markSpriteActive(factoryPanelSprite);
		});
	}
}
