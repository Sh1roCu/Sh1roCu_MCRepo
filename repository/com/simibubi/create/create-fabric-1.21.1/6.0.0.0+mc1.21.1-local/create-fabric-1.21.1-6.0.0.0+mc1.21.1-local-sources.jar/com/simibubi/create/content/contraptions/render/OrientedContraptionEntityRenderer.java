package com.simibubi.create.content.contraptions.render;

import com.simibubi.create.AllTags.AllContraptionTypeTags;
import com.simibubi.create.content.contraptions.OrientedContraptionEntity;
import net.minecraft.class_4604;
import net.minecraft.class_5617;

public class OrientedContraptionEntityRenderer extends ContraptionEntityRenderer<OrientedContraptionEntity> {
	public OrientedContraptionEntityRenderer(class_5617.class_5618 context) {
		super(context);
	}

	@Override
	public boolean shouldRender(OrientedContraptionEntity entity, class_4604 frustum, double cameraX, double cameraY,
			double cameraZ) {
		if (!super.shouldRender(entity, frustum, cameraX, cameraY, cameraZ))
			return false;
		if (entity.method_5854() == null && AllContraptionTypeTags.REQUIRES_VEHICLE_FOR_RENDER.matches(entity.getContraption().getType()))
			return false;

		return true;
	}
}
