package com.simibubi.create.content.contraptions.sync;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.simibubi.create.AllPackets;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.foundation.utility.PersistentDataHelper;
import net.createmod.catnip.net.base.ClientboundPacketPayload;

import io.netty.buffer.ByteBuf;
import net.createmod.catnip.math.VecHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_4844;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ContraptionSeatMappingPacket(int entityId, Map<UUID, Integer> mapping, int dismountedId) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, ContraptionSeatMappingPacket> STREAM_CODEC = class_9139.method_56436(
			class_9135.field_49675, ContraptionSeatMappingPacket::entityId,
			class_9135.method_56377(HashMap::new, class_4844.field_48453, class_9135.field_49675), ContraptionSeatMappingPacket::mapping,
			class_9135.field_49675, ContraptionSeatMappingPacket::dismountedId,
	        ContraptionSeatMappingPacket::new
	);

	public ContraptionSeatMappingPacket(int entityID, Map<UUID, Integer> mapping) {
		this(entityID, mapping, -1);
	}

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		class_1297 entityByID = player.field_17892.method_8469(entityId);
		if (!(entityByID instanceof AbstractContraptionEntity contraptionEntity))
			return;

		if (dismountedId == player.method_5628()) {
			class_243 transformedVector = contraptionEntity.getPassengerPosition(player, 1);
			if (transformedVector != null)
				PersistentDataHelper.get(player)
						.method_10566("ContraptionDismountLocation", VecHelper.writeNBT(transformedVector));
		}

		contraptionEntity.getContraption()
				.setSeatMapping(mapping);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CONTRAPTION_SEAT_MAPPING;
	}
}
