package com.simibubi.create.content.contraptions.minecart.capability;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;

import javax.annotation.Nullable;

import com.simibubi.create.AllAttachmentTypes;
import com.simibubi.create.AllItems;
import com.simibubi.create.content.contraptions.minecart.CouplingHandler;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectLists;
import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.data.WorldAttached;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1688;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2818;

public class CapabilityMinecartController {

	/* Global map of loaded carts */

	public static WorldAttached<Map<UUID, MinecartController>> loadedMinecartsByUUID;
	public static WorldAttached<Set<UUID>> loadedMinecartsWithCoupling;
	static WorldAttached<List<class_1688>> queuedAdditions;
	static WorldAttached<List<UUID>> queuedUnloads;

	static {
		loadedMinecartsByUUID = new WorldAttached<>($ -> new HashMap<>());
		loadedMinecartsWithCoupling = new WorldAttached<>($ -> new HashSet<>());
		queuedAdditions = new WorldAttached<>($ -> ObjectLists.synchronize(new ObjectArrayList<>()));
		queuedUnloads = new WorldAttached<>($ -> ObjectLists.synchronize(new ObjectArrayList<>()));
	}

	public static void tick(class_1937 world) {
		Map<UUID, MinecartController> carts = loadedMinecartsByUUID.get(world);
		List<class_1688> queued = queuedAdditions.get(world);
		List<UUID> queuedRemovals = queuedUnloads.get(world);
		Set<UUID> cartsWithCoupling = loadedMinecartsWithCoupling.get(world);
		Set<UUID> keySet = carts.keySet();

		for (UUID removal : queuedRemovals) {
			keySet.remove(removal);
			cartsWithCoupling.remove(removal);
		}

		for (class_1688 cart : queued) {
			UUID uniqueID = cart.method_5667();

			if (world.field_9236 && carts.containsKey(uniqueID)) {
				MinecartController minecartController = carts.get(uniqueID);
				if (minecartController != null) {
					class_1688 minecartEntity = minecartController.cart();
					if (minecartEntity != null && minecartEntity.method_5628() != cart.method_5628())
						continue; // Away with you, Fake Entities!
				}
			}

			cartsWithCoupling.remove(uniqueID);

			MinecartController controller = cart.create$getController();
//			capability.addListener(new MinecartRemovalListener(world, cart)); // fabric: handled via AbstractMinecartMixin
			carts.put(uniqueID, controller);

			if (controller.isLeadingCoupling())
				cartsWithCoupling.add(uniqueID);
			if (!world.field_9236 && controller != null)
				controller.sendData();
		}

		queuedRemovals.clear();
		queued.clear();

		List<UUID> toRemove = new ArrayList<>();

		for (Entry<UUID, MinecartController> entry : carts.entrySet()) {
			MinecartController controller = entry.getValue();
			if (controller != null && controller.isPresent())
				continue;
			toRemove.add(entry.getKey());
		}

		for (UUID uuid : toRemove) {
			keySet.remove(uuid);
			cartsWithCoupling.remove(uuid);
		}
	}

	public static void entityTick(class_1297 entity) {
		if (!(entity instanceof class_1688))
			return;
		MinecartController data = entity.getAttached(AllAttachmentTypes.MINECART_CONTROLLER);
		if (data != MinecartController.EMPTY)
			data.tick();
	}

	public static void onChunkUnloaded(class_1937 world, class_2818 chunk) {
		class_1923 chunkPos = chunk
			.method_12004();
		Map<UUID, MinecartController> carts = loadedMinecartsByUUID.get(world);
		for (MinecartController minecartController : carts.values()) {
			if (minecartController == null)
				continue;
			if (!minecartController.isPresent())
				continue;
			class_1688 cart = minecartController.cart();
			if (cart.method_31476()
				.equals(chunkPos))
				queuedUnloads.get(world)
					.add(cart.method_5667());
		}
	}

	public static void onCartRemoved(class_1937 world, class_1688 entity) {
		entity.removeAttached(AllAttachmentTypes.MINECART_CONTROLLER);
		Map<UUID, MinecartController> carts = loadedMinecartsByUUID.get(world);
		List<UUID> unloads = queuedUnloads.get(world);
		UUID uniqueID = entity.method_5667();
		if (!carts.containsKey(uniqueID) || unloads.contains(uniqueID))
			return;
		if (world.field_9236)
			return;
		handleKilledMinecart(world, carts.get(uniqueID), entity.method_19538());
	}

	protected static void handleKilledMinecart(class_1937 world, MinecartController controller, class_243 removedPos) {
		if (controller == null)
			return;
		for (boolean forward : Iterate.trueAndFalse) {
			MinecartController next = CouplingHandler.getNextInCouplingChain(world, controller, forward);
			if (next == null || next == MinecartController.EMPTY)
				continue;

			next.removeConnection(!forward);
			if (controller.hasContraptionCoupling(forward))
				continue;
			class_1688 cart = next.cart();
			if (cart == null)
				continue;

			class_243 itemPos = cart.method_19538()
				.method_1019(removedPos)
				.method_1021(.5f);
			class_1542 itemEntity =
				new class_1542(world, itemPos.field_1352, itemPos.field_1351, itemPos.field_1350, AllItems.MINECART_COUPLING.asStack());
			itemEntity.method_6988();
			world.method_8649(itemEntity);
		}
	}

	@Nullable
	public static MinecartController getIfPresent(class_1937 world, UUID cartId) {
		Map<UUID, MinecartController> carts = loadedMinecartsByUUID.get(world);
		if (carts == null)
			return null;
		if (!carts.containsKey(cartId))
			return null;
		return carts.get(cartId);
	}

	public static void attach(class_1688 entity) {
		queuedAdditions.get(entity.method_5770())
			.add(entity);
	}

	public static void startTracking(class_1297 entity) {
		if (!(entity instanceof class_1688 cart))
			return;
		cart.create$getController().sendData();
	}
}
