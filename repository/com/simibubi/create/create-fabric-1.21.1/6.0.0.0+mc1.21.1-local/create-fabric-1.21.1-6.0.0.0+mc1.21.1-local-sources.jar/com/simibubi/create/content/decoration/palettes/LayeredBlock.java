package com.simibubi.create.content.decoration.palettes;

import net.minecraft.class_1750;
import net.minecraft.class_2465;
import net.minecraft.class_2680;

public class LayeredBlock extends class_2465 {

	public LayeredBlock(class_2251 p_55926_) {
		super(p_55926_);
	}

	@Override
	public class_2680 method_9605(class_1750 pContext) {
		class_2680 stateForPlacement = super.method_9605(pContext);
		class_2680 placedOn = pContext.method_8045()
			.method_8320(pContext.method_8037()
				.method_10093(pContext.method_8038()
					.method_10153()));
		if (placedOn.method_26204() == this && (pContext.method_8036() == null || !pContext.method_8036()
			.method_5715()))
			stateForPlacement = stateForPlacement.method_11657(field_11459, placedOn.method_11654(field_11459));
		return stateForPlacement;
	}

}
