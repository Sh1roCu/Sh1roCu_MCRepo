package com.simibubi.create.content.equipment.tool;

import java.util.function.Supplier;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_6862;
import org.jetbrains.annotations.NotNull;

import com.simibubi.create.AllItems;
import com.simibubi.create.Create;

public enum AllToolMaterials implements class_1832 {
	CARDBOARD(Create.asResource("cardboard")
		.toString(), 0, 1, 2, 1, () -> class_1856.method_8091(AllItems.CARDBOARD.method_8389()))
	;

	public final String name;

	private final int uses;
	private final float speed;
	private final float damageBonus;
	private final int enchantValue;
	private final Supplier<class_1856> repairMaterial;

	private AllToolMaterials(String name, int uses, float speed, float damageBonus, int enchantValue,
		Supplier<class_1856> repairMaterial) {
		this.name = name;
		this.uses = uses;
		this.speed = speed;
		this.damageBonus = damageBonus;
		this.enchantValue = enchantValue;
		this.repairMaterial = repairMaterial;
	}

	@Override
	public int method_8025() {
		return uses;
	}

	@Override
	public float method_8027() {
		return speed;
	}

	@Override
	public float method_8028() {
		return damageBonus;
	}

	@Override
	public @NotNull class_6862<class_2248> method_58419() {
		return class_3481.field_49930;
	}

	@Override
	public int method_8026() {
		return enchantValue;
	}

	@Override
	public @NotNull class_1856 method_8023() {
		return repairMaterial.get();
	}
}
