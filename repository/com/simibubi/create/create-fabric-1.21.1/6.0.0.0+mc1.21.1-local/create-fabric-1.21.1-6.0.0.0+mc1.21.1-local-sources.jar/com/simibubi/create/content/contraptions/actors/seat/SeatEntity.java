package com.simibubi.create.content.contraptions.actors.seat;

import com.simibubi.create.AllEntityTypes;
import com.simibubi.create.content.logistics.box.PackageEntity;

import net.fabricmc.fabric.api.entity.FakePlayer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1451;
import net.minecraft.class_1453;
import net.minecraft.class_1493;
import net.minecraft.class_1613;
import net.minecraft.class_1621;
import net.minecraft.class_1628;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2945;
import net.minecraft.class_2960;
import net.minecraft.class_4048;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_7102;
import net.minecraft.class_897;
import net.minecraft.class_9129;
import io.github.fabricators_of_create.porting_lib.entity.IEntityWithComplexSpawn;

public class SeatEntity extends class_1297 implements IEntityWithComplexSpawn {

	public SeatEntity(class_1299<?> p_i48580_1_, class_1937 p_i48580_2_) {
		super(p_i48580_1_, p_i48580_2_);
	}

	public SeatEntity(class_1937 world, class_2338 pos) {
		this(AllEntityTypes.SEAT.get(), world);
		field_5960 = true;
	}

	public static FabricEntityTypeBuilder<?> build(FabricEntityTypeBuilder<?> builder) {
//		@SuppressWarnings("unchecked")
//		EntityType.Builder<SeatEntity> entityBuilder = (EntityType.Builder<SeatEntity>) builder;
		return builder.dimensions(class_4048.method_18385(0.25f, 0.35f));
	}

	@Override
	public void method_5814(double x, double y, double z) {
		super.method_5814(x, y, z);
		class_238 bb = method_5829();
		class_243 diff = new class_243(x, y, z).method_1020(bb.method_1005());
		method_5857(bb.method_997(diff));
	}

	@Override
	protected void method_5865(class_1297 pEntity, class_1297.class_4738 pCallback) {
		if (!this.method_5626(pEntity))
			return;
		double heightOffset = this.method_52538(pEntity).field_1351 - pEntity.method_55668(this).field_1351;

		pCallback.accept(pEntity, this.method_23317(), 1.0 / 16.0 + heightOffset + getCustomEntitySeatOffset(pEntity), this.method_23321());
	}

	public static double getCustomEntitySeatOffset(class_1297 entity) {
		if (entity instanceof class_1621)
			return 0.0f;
		if (entity instanceof class_1453)
			return 1 / 12f;
		if (entity instanceof class_1613)
			return 1 / 8f;
		if (entity instanceof class_1451)
			return 1 / 12f;
		if (entity instanceof class_1493)
			return 1 / 16f;
		if (entity instanceof class_7102)
			return 1.5 / 16f;
		if (entity instanceof class_1628)
			return 1 / 8.0;
		if (entity instanceof PackageEntity)
			return 3 / 32f;
		return 0;
	}

	@Override
	public void method_18799(class_243 p_213317_1_) {}

	@Override
	public void method_5773() {
		if (method_37908().field_9236)
			return;
		boolean blockPresent = method_37908().method_8320(method_24515())
			.method_26204() instanceof SeatBlock;
		if (method_5782() && blockPresent)
			return;
		this.method_31472();
	}

	@Override
	protected boolean method_5860(class_1297 entity) {
		// Fake Players (tested with deployers) have a BUNCH of weird issues, don't let
		// them ride seats
		return !(entity instanceof class_1657 player && player instanceof FakePlayer);
	}

	@Override
	protected void method_5793(class_1297 entity) {
		super.method_5793(entity);
		if (entity instanceof class_1321 ta)
			ta.method_6179(false);
	}

	@Override
	public class_243 method_24829(class_1309 pLivingEntity) {
		return super.method_24829(pLivingEntity).method_1031(0, 0.5f, 0);
	}

	@Override
	protected void method_5693(class_2945.class_9222 builder) {}

	@Override
	protected void method_5749(class_2487 p_70037_1_) {}

	@Override
	protected void method_5652(class_2487 p_213281_1_) {}

	public static class Render extends class_897<SeatEntity> {

		public Render(class_5617.class_5618 context) {
			super(context);
		}

		@Override
		public boolean shouldRender(SeatEntity p_225626_1_, class_4604 p_225626_2_, double p_225626_3_, double p_225626_5_,
			double p_225626_7_) {
			return false;
		}

		@Override
		public class_2960 getTextureLocation(SeatEntity p_110775_1_) {
			return null;
		}
	}

	@Override
	public void writeSpawnData(class_9129 buffer) {}

	@Override
	public void readSpawnData(class_9129 additionalData) {}
}
