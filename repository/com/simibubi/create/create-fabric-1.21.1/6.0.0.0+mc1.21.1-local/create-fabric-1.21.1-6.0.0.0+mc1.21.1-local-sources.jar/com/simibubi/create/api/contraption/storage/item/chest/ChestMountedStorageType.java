package com.simibubi.create.api.contraption.storage.item.chest;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.api.contraption.storage.item.simple.SimpleMountedStorage;
import com.simibubi.create.api.contraption.storage.item.simple.SimpleMountedStorageType;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.SlottedStorage;
import net.minecraft.class_1263;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class ChestMountedStorageType extends SimpleMountedStorageType<ChestMountedStorage> {
	public ChestMountedStorageType() {
		super(ChestMountedStorage.CODEC);
	}

	@Override
	protected SlottedStorage<ItemVariant> getStorage(class_1937 level, class_2680 state, class_2338 pos, @Nullable class_2586 be) {
		// the storage provided by FAPI includes both halves, just get 1
		return be instanceof class_1263 container ? InventoryStorage.of(container, null) : null;
	}

	@Override
	protected SimpleMountedStorage createStorage(SlottedStorage<ItemVariant> storage) {
		return new ChestMountedStorage(storage);
	}
}
