package com.simibubi.create.content.equipment.armor;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SuperByteBuffer;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;

public class BacktankRenderer extends KineticBlockEntityRenderer<BacktankBlockEntity> {
	public BacktankRenderer(class_5614.class_5615 context) {
		super(context);
	}

	@Override
	protected void renderSafe(BacktankBlockEntity be, float partialTicks, class_4587 ms, class_4597 buffer,
		int light, int overlay) {
		super.renderSafe(be, partialTicks, ms, buffer, light, overlay);

		class_2680 blockState = be.method_11010();
		SuperByteBuffer cogs = CachedBuffers.partial(getCogsModel(blockState), blockState);
		cogs.center()
			.rotateYDegrees(180 + AngleHelper.horizontalAngle(blockState.method_11654(BacktankBlock.HORIZONTAL_FACING)))
			.uncenter()
			.translate(0, 6.5f / 16, 11f / 16)
			.rotate(AngleHelper.rad(be.getSpeed() / 4f * AnimationTickHolder.getRenderTime(be.method_10997()) % 360),
				class_2350.field_11034)
			.translate(0, -6.5f / 16, -11f / 16);
		cogs.light(light)
			.renderInto(ms, buffer.getBuffer(class_1921.method_23577()));
	}

	@Override
	protected SuperByteBuffer getRotatedModel(BacktankBlockEntity be, class_2680 state) {
		return CachedBuffers.partial(getShaftModel(state), state);
	}

	public static PartialModel getCogsModel(class_2680 state) {
		if (AllBlocks.NETHERITE_BACKTANK.has(state)) {
			return AllPartialModels.NETHERITE_BACKTANK_COGS;
		}
		return AllPartialModels.COPPER_BACKTANK_COGS;
	}

	public static PartialModel getShaftModel(class_2680 state) {
		if (AllBlocks.NETHERITE_BACKTANK.has(state)) {
			return AllPartialModels.NETHERITE_BACKTANK_SHAFT;
		}
		return AllPartialModels.COPPER_BACKTANK_SHAFT;
	}
}
