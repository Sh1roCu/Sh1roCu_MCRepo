package com.simibubi.create.content.decoration.steamWhistle;

import com.simibubi.create.Create;
import com.simibubi.create.foundation.data.AssetLookup;
import com.simibubi.create.foundation.data.SpecialBlockStateGen;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;

public class WhistleGenerator extends SpecialBlockStateGen {

	@Override
	protected int getXRotation(class_2680 state) {
		return 0;
	}

	@Override
	protected int getYRotation(class_2680 state) {
		return horizontalAngle(state.method_11654(WhistleBlock.FACING));
	}

	@Override
	public <T extends class_2248> ModelFile getModel(DataGenContext<class_2248, T> ctx, RegistrateBlockstateProvider prov,
												class_2680 state) {
		String wall = state.method_11654(WhistleBlock.WALL) ? "wall" : "floor";
		String size = state.method_11654(WhistleBlock.SIZE)
			.method_15434();
		boolean powered = state.method_11654(WhistleBlock.POWERED);
		ModelFile model = AssetLookup.partialBaseModel(ctx, prov, size, wall);
		if (!powered)
			return model;
		class_2960 parentLocation = model.getLocation();
		return prov.models()
			.withExistingParent(parentLocation.method_12832() + "_powered", parentLocation)
			.texture("2", Create.asResource("block/copper_redstone_plate_powered"));
	}

}
