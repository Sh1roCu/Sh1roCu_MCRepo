package com.simibubi.create.content.contraptions;

import java.util.Arrays;
import java.util.List;

import com.simibubi.create.foundation.item.TooltipHelper;
import com.simibubi.create.foundation.utility.CreateLang;

import net.createmod.catnip.lang.FontHelper.Palette;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5244;

public interface IDisplayAssemblyExceptions {

	default boolean addExceptionToTooltip(List<class_2561> tooltip) {
		AssemblyException e = getLastAssemblyException();
		if (e == null)
			return false;

		if (!tooltip.isEmpty())
			tooltip.add(class_5244.field_39003);

		CreateLang.translate("gui.assembly.exception").style(class_124.field_1065)
			.forGoggles(tooltip);

		String text = e.component.getString();
		Arrays.stream(text.split("\n"))
			.forEach(l -> TooltipHelper.cutStringTextComponent(l, Palette.GRAY_AND_WHITE)
				.forEach(c -> CreateLang.builder().add(c).forGoggles(tooltip)));

		return true;
	}

	AssemblyException getLastAssemblyException();

}
