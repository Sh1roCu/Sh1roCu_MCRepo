package com.simibubi.create.content.equipment.toolbox;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllRecipeTypes;

import com.simibubi.create.infrastructure.fabric.item.ItemUtils;

import io.github.fabricators_of_create.porting_lib.util.TagUtil;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_9694;
import io.github.fabricators_of_create.porting_lib.tags.Tags;
import io.github.fabricators_of_create.porting_lib.util.TagUtil;

public class ToolboxDyeingRecipe extends class_1852 {

	public ToolboxDyeingRecipe(class_7710 category) {
		super(category);
	}

	@Override
	public boolean matches(class_9694 input, class_1937 level) {
		int toolboxes = 0;
		int dyes = 0;

		for (int i = 0; i < input.method_59983(); ++i) {
			class_1799 stack = input.method_59984(i);
			if (!stack.method_7960()) {
				if (class_2248.method_9503(stack.method_7909()) instanceof ToolboxBlock) {
					++toolboxes;
				} else {
					if (!stack.method_31573(Tags.Items.DYES))
						return false;
					++dyes;
				}

				if (dyes > 1 || toolboxes > 1) {
					return false;
				}
			}
		}

		return toolboxes == 1 && dyes == 1;
	}

	@Override
	public class_1799 assemble(class_9694 input, class_7225.class_7874 registries) {
		class_1799 toolbox = class_1799.field_8037;
		class_1767 color = class_1767.field_7957;

		for (int i = 0; i < input.method_59983(); ++i) {
			class_1799 stack = input.method_59984(i);
			if (!stack.method_7960()) {
				if (class_2248.method_9503(stack.method_7909()) instanceof ToolboxBlock) {
					toolbox = stack;
				} else {
					class_1767 color1 = TagUtil.getColorFromStack(stack);
					if (color1 != null) {
						color = color1;
					}
				}
			}
		}

		class_1799 dyedToolbox = AllBlocks.TOOLBOXES.get(color)
			.asStack();
		if (!ItemUtils.isComponentsPatchEmpty(toolbox)) {
			dyedToolbox.method_57366(toolbox.method_57380());
		}

		return dyedToolbox;
	}

	@Override
	public boolean method_8113(int width, int height) {
		return width * height >= 2;
	}

	@Override
	public class_1865<?> method_8119() {
		return AllRecipeTypes.TOOLBOX_DYEING.getSerializer();
	}

}
