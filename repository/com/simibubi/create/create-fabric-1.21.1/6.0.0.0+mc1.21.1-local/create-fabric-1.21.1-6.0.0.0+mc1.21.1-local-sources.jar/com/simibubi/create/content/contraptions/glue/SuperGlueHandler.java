package com.simibubi.create.content.contraptions.glue;

import java.util.HashSet;
import java.util.Set;

import com.simibubi.create.AllItems;
import com.simibubi.create.api.contraption.BlockMovementChecks;
import com.simibubi.create.foundation.utility.AdventureUtil;
import com.simibubi.create.foundation.utility.fabric.ReachUtil;

import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1299;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239.class_240;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.levelWrappers.RayTraceLevel;
import net.createmod.catnip.placement.IPlacementHelper;

public class SuperGlueHandler {

	public static void glueListensForBlockPlacement(class_1750 context, class_2338 pos, class_2680 state) {
		class_1936 world = context.method_8045();
		class_1657 entity = context.method_8036();

		if (entity == null || AdventureUtil.isAdventure(entity))
			return;
		if (world.method_8608())
			return;

		Set<SuperGlueEntity> cached = new HashSet<>();
		for (class_2350 direction : Iterate.directions) {
			class_2338 relative = pos.method_10093(direction);
			if (SuperGlueEntity.isGlued(world, pos, direction, cached)
				&& BlockMovementChecks.isMovementNecessary(world.method_8320(relative), entity.method_37908(), relative))
				CatnipServices.NETWORK.sendToClientsTrackingAndSelf(entity, new GlueEffectPacket(pos, direction, true));
		}

		glueInOffHandAppliesOnBlockPlace(context.method_8045().method_8320(context.method_8037().method_10093(context.method_8038().method_10153())), pos, entity);
	}

	public static void glueInOffHandAppliesOnBlockPlace(class_2680 placedAgainst, class_2338 pos, class_1657 placer) {
		class_1799 itemstack = placer.method_6079();
		class_1324 reachAttribute = placer.method_5996(class_5134.field_47758);
		if (!AllItems.SUPER_GLUE.isIn(itemstack) || reachAttribute == null)
			return;
		if (AllItems.WRENCH.isIn(placer.method_6047()))
			return;
		if (placedAgainst == IPlacementHelper.ID)
			return;

		double distance = ReachUtil.reach(placer);
		class_243 start = placer.method_5836(1);
		class_243 look = placer.method_5828(1);
		class_243 end = start.method_1031(look.field_1352 * distance, look.field_1351 * distance, look.field_1350 * distance);
		class_1937 world = placer.method_37908();

		RayTraceLevel rayTraceLevel =
			new RayTraceLevel(world, (p, state) -> p.equals(pos) ? class_2246.field_10124.method_9564() : state);
		class_3965 ray =
			rayTraceLevel.method_17742(new class_3959(start, end, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, placer));

		class_2350 face = ray.method_17780();
		if (face == null || ray.method_17783() == class_240.field_1333)
			return;

		class_2338 gluePos = ray.method_17777();
		if (!gluePos.method_10093(face)
			.equals(pos)) {
			return;
		}

		if (SuperGlueEntity.isGlued(world, gluePos, face, null))
			return;

		SuperGlueEntity entity = new SuperGlueEntity(world, SuperGlueEntity.span(gluePos, gluePos.method_10093(face)));
		class_9279 customData = itemstack.method_57824(class_9334.field_49628);
		if (customData != null)
			class_1299.method_5881(world, placer, entity, customData);

		if (SuperGlueEntity.isValidFace(world, gluePos, face)) {
			if (!world.field_9236) {
				world.method_8649(entity);
				CatnipServices.NETWORK.sendToClientsTrackingEntity(entity,
					new GlueEffectPacket(gluePos, face, true));
			}
			if (placer.method_37908() instanceof class_3218 serverLevel && placer instanceof class_3222 serverPlayer)
				itemstack.method_7956(1, serverLevel, serverPlayer, $ -> SuperGlueItem.onBroken(serverPlayer));
		}
	}

}
