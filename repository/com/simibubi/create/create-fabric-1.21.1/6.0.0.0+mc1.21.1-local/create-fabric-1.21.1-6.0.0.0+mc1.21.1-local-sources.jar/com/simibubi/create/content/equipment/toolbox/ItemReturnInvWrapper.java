package com.simibubi.create.content.equipment.toolbox;

import net.minecraft.class_1661;
import net.minecraft.class_1799;

public class ItemReturnInvWrapper {
	private final class_1661 inv;

	public ItemReturnInvWrapper(class_1661 inv) {
		this.inv = inv;
	}

	public class_1799 insert(class_1799 stack, boolean simulate) {
		if (stack.method_7960())
			return class_1799.field_8037;

		class_1799 remaining = stack.method_7972();
		// Skip hotbar slots so this only fills main inventory rows.
		for (int slot = 9; slot <= 35 && !remaining.method_7960(); slot++) {
			class_1799 inSlot = inv.method_5438(slot);
			int maxSize = remaining.method_7914();
			if (inSlot.method_7960()) {
				int moved = Math.min(remaining.method_7947(), maxSize);
				if (!simulate)
					inv.method_5447(slot, remaining.method_46651(moved));
				remaining.method_7934(moved);
				continue;
			}
			if (!class_1799.method_31577(inSlot, remaining))
				continue;
			int space = maxSize - inSlot.method_7947();
			if (space <= 0)
				continue;
			int moved = Math.min(space, remaining.method_7947());
			if (!simulate)
				inSlot.method_7933(moved);
			remaining.method_7934(moved);
		}

		return remaining;
	}
}
