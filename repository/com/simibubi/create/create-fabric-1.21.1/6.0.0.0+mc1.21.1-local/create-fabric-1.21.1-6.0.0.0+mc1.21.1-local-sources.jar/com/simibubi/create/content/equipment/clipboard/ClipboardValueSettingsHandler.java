package com.simibubi.create.content.equipment.clipboard;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_761;

public class ClipboardValueSettingsHandler {

	@Environment(EnvType.CLIENT)
	public static boolean drawCustomBlockSelection(class_761 context, class_4184 camera, class_239 hitResult,
		float partialTicks, class_4587 ms, class_4597 buffers) {
		return false;
	}

	@Environment(EnvType.CLIENT)
	public static void clientTick() {
	}

	public static class_1269 rightClickToCopy(class_1657 player, class_1937 world, class_1268 hand,
		net.minecraft.class_3965 hitResult) {
		return class_1269.field_5811;
	}

	public static class_1269 leftClickToPaste(class_1657 player, class_1937 world, class_1268 hand, class_2338 pos,
		class_2350 direction) {
		return class_1269.field_5811;
	}
}
