package com.simibubi.create.content.contraptions.minecart;

import net.createmod.catnip.platform.CatnipServices;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllItems;
import com.simibubi.create.content.contraptions.minecart.capability.MinecartController;
import com.simibubi.create.foundation.utility.AdventureUtil;
import com.tterrag.registrate.fabric.EnvExecutor;

import net.createmod.catnip.data.Iterate;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1688;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3966;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class MinecartCouplingItem extends class_1792 {

	public MinecartCouplingItem(class_1793 p_i48487_1_) {
		super(p_i48487_1_);
	}

	public static class_1269 handleInteractionWithMinecart(class_1657 player, class_1937 world, class_1268 hand, class_1297 interacted, @Nullable class_3966 hitResult) {
		if (player.method_7325()) // forge checks this, fabric does not
			return class_1269.field_5811;
		if (AdventureUtil.isAdventure(player))
			return class_1269.field_5811;
		if (!(interacted instanceof class_1688 minecart))
			return class_1269.field_5811;
		if (player == null)
			return class_1269.field_5811;
		MinecartController controller = minecart.create$getController();

		class_1799 heldItem = player.method_5998(hand);
		if (AllItems.MINECART_COUPLING.isIn(heldItem)) {
			if (!onCouplingInteractOnMinecart(player.method_37908(), minecart, player, controller))
				return class_1269.field_5811;
		} else if (AllItems.WRENCH.isIn(heldItem)) {
			if (!onWrenchInteractOnMinecart(player.method_37908(), minecart, player, controller))
				return class_1269.field_5811;
		} else
			return class_1269.field_5811;

		return class_1269.field_5812;
	}

	protected static boolean onCouplingInteractOnMinecart(class_1937 world,
														  class_1688 minecart, class_1657 player, MinecartController controller) {
		if (controller.isFullyCoupled()) {
			if (world.field_9236) // fabric: on forge this only runs on server, here we only run
				// on client to avoid an incorrect message due to differences in timing across loaders.
				// on forge, the process is client -> server -> packet -> couple
				// on fabric, the process is client -> packet -> couple -> server
				CouplingHandler.status(player, "two_couplings_max");
			return true;
		}
		if (world != null && world.field_9236)
			CatnipServices.PLATFORM.executeOnClientOnly(() -> () -> cartClicked(player, minecart));
		return true;
	}

	private static boolean onWrenchInteractOnMinecart(class_1937 world, class_1688 minecart, class_1657 player,
													  MinecartController controller) {
		int couplings = (controller.isConnectedToCoupling() ? 1 : 0) + (controller.isLeadingCoupling() ? 1 : 0);
		if (couplings == 0)
			return false;
		if (world.field_9236)
			return true;

		for (boolean forward : Iterate.trueAndFalse) {
			if (controller.hasContraptionCoupling(forward))
				couplings--;
		}

		CouplingHandler.status(player, "removed");
		controller.decouple();
		if (!player.method_7337())
			player.method_31548()
				.method_7398(new class_1799(AllItems.MINECART_COUPLING.get(), couplings));
		return true;
	}

	@Environment(EnvType.CLIENT)
	private static void cartClicked(class_1657 player, class_1688 interacted) {
		CouplingHandlerClient.onCartClicked(player, interacted);
	}

}
