package com.simibubi.create.content.decoration.slidingDoor;

import java.util.Arrays;
import java.util.function.Consumer;

import com.simibubi.create.foundation.gui.widget.Label;
import com.simibubi.create.foundation.gui.widget.ScrollInput;
import com.simibubi.create.foundation.gui.widget.SelectionScrollInput;
import com.simibubi.create.foundation.utility.CreateLang;

import net.createmod.catnip.codecs.stream.CatnipStreamCodecBuilders;
import io.netty.buffer.ByteBuf;
import net.createmod.catnip.data.Pair;
import net.createmod.catnip.lang.Lang;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_9139;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public enum DoorControl {

	ALL, NORTH, EAST, SOUTH, WEST, NONE;

	public static final class_9139<ByteBuf, DoorControl> STREAM_CODEC = CatnipStreamCodecBuilders.ofEnum(DoorControl.class);

	private static String[] valuesAsString() {
		DoorControl[] values = values();
		return Arrays.stream(values)
			.map(dc -> Lang.asId(dc.name()))
			.toList()
			.toArray(new String[values.length]);
	}

	public boolean matches(class_2350 doorDirection) {
		return switch (this) {
		case ALL -> true;
		case NORTH -> doorDirection == class_2350.field_11043;
		case EAST -> doorDirection == class_2350.field_11034;
		case SOUTH -> doorDirection == class_2350.field_11035;
		case WEST -> doorDirection == class_2350.field_11039;
		default -> false;
		};
	}

	@Environment(EnvType.CLIENT)
	public static Pair<ScrollInput, Label> createWidget(int x, int y, Consumer<DoorControl> callback,
		DoorControl initial) {

		DoorControl playerFacing = NONE;
		class_1297 cameraEntity = class_310.method_1551().field_1719;
		if (cameraEntity != null) {
			class_2350 direction = cameraEntity.method_5735();
			if (direction == class_2350.field_11034)
				playerFacing = EAST;
			if (direction == class_2350.field_11039)
				playerFacing = WEST;
			if (direction == class_2350.field_11043)
				playerFacing = NORTH;
			if (direction == class_2350.field_11035)
				playerFacing = SOUTH;
		}

        Label label = new Label(x + 4, y + 6, class_2561.method_43473()).withShadow();
		ScrollInput input = new SelectionScrollInput(x, y, 53, 16)
			.forOptions(CreateLang.translatedOptions("contraption.door_control", valuesAsString()))
			.titled(CreateLang.translateDirect("contraption.door_control"))
			.calling(s -> {
				DoorControl mode = values()[s];
				label.text = CreateLang.translateDirect("contraption.door_control." + Lang.asId(mode.name()) + ".short");
				callback.accept(mode);
			})
			.addHint(CreateLang.translateDirect("contraption.door_control.player_facing",
				CreateLang.translateDirect("contraption.door_control." + Lang.asId(playerFacing.name()) + ".short")))
			.setState(initial.ordinal());
		input.onChanged();
		return Pair.of(input, label);
	}

}
