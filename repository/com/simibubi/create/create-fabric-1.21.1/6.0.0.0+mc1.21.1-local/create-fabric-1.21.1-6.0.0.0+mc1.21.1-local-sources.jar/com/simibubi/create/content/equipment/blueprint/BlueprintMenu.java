package com.simibubi.create.content.equipment.blueprint;

import com.simibubi.create.AllDataComponents;
import com.simibubi.create.AllMenuTypes;
import com.simibubi.create.content.equipment.blueprint.BlueprintEntity.BlueprintSection;
import com.simibubi.create.foundation.gui.menu.GhostItemMenu;
import com.simibubi.create.infrastructure.fabric.transfer.item.ItemStackHandler;
import com.simibubi.create.infrastructure.fabric.transfer.item.SlotItemHandler;

import java.util.Optional;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1715;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2653;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_8566;
import net.minecraft.class_8786;
import net.minecraft.class_9129;

public class BlueprintMenu extends GhostItemMenu<BlueprintSection> {

	public BlueprintMenu(class_3917<?> type, int id, class_1661 inv, class_9129 extraData) {
		super(type, id, inv, extraData);
	}

	public BlueprintMenu(class_3917<?> type, int id, class_1661 inv, BlueprintSection section) {
		super(type, id, inv, section);
	}

	public static BlueprintMenu create(int id, class_1661 inv, BlueprintSection section) {
		return new BlueprintMenu(AllMenuTypes.CRAFTING_BLUEPRINT.get(), id, inv, section);
	}

	@Override
	protected boolean allowRepeats() {
		return true;
	}

	@Override
	protected void addSlots() {
		addPlayerSlots(8, 131);

		int x = 29;
		int y = 21;
		int index = 0;
		for (int row = 0; row < 3; ++row)
			for (int col = 0; col < 3; ++col)
				this.method_7621(new BlueprintCraftSlot(ghostInventory, index++, x + col * 18, y + row * 18));

		method_7621(new BlueprintCraftSlot(ghostInventory, index++, 123, 40));
		method_7621(new SlotItemHandler(ghostInventory, index++, 135, 57));
	}

	public void onCraftMatrixChanged() {
		class_1937 level = contentHolder.getBlueprintWorld();
		if (level.field_9236)
			return;

		class_3222 serverplayerentity = (class_3222) player;
		class_8566 craftingInventory = new BlueprintCraftingInventory(this, ghostInventory);
		Optional<class_8786<class_3955>> optional = player.method_5682()
			.method_3772()
			.method_8132(class_3956.field_17545, craftingInventory.method_59961(), player.method_5770());

		if (!optional.isPresent()) {
			if (ghostInventory.getStackInSlot(9)
				.method_7960())
				return;
			if (!contentHolder.inferredIcon)
				return;

			ghostInventory.setStackInSlot(9, class_1799.field_8037);
			serverplayerentity.field_13987.method_14364(new class_2653(field_7763, method_37422(), 36 + 9, class_1799.field_8037));
			contentHolder.inferredIcon = false;
			return;
		}

		class_3955 icraftingrecipe = optional.get().comp_1933();
		class_1799 itemstack = icraftingrecipe.method_8116(craftingInventory.method_59961(), level.method_30349());
		ghostInventory.setStackInSlot(9, itemstack);
		contentHolder.inferredIcon = true;
		class_1799 toSend = itemstack.method_7972();
		toSend.method_57379(AllDataComponents.INFERRED_FROM_RECIPE, true);
		serverplayerentity.field_13987.method_14364(new class_2653(field_7763, method_37422(), 36 + 9, toSend));
	}

	@Override
	public void method_7619(int slotId, int stateId, class_1799 stack) {
		if (slotId == 36 + 9) {
			contentHolder.inferredIcon = stack.method_57825(AllDataComponents.INFERRED_FROM_RECIPE, false);
			stack.method_57381(AllDataComponents.INFERRED_FROM_RECIPE);
		}
		super.method_7619(slotId, stateId, stack);
	}

	@Override
	protected ItemStackHandler createGhostInventory() {
		return contentHolder.getItems();
	}

	@Override
	protected void initAndReadInventory(BlueprintSection contentHolder) {
		super.initAndReadInventory(contentHolder);
	}

	@Override
	protected void saveData(BlueprintSection contentHolder) {
		contentHolder.save(ghostInventory);
	}

	@Override
	@Environment(EnvType.CLIENT)
	protected BlueprintSection createOnClient(class_9129 extraData) {
		int entityID = extraData.method_10816();
		int section = extraData.method_10816();
		class_1297 entityByID = class_310.method_1551().field_1687.method_8469(entityID);
		if (!(entityByID instanceof BlueprintEntity blueprintEntity))
			return null;
		BlueprintSection blueprintSection = blueprintEntity.getSection(section);
		return blueprintSection;
	}

	@Override
	public boolean method_7597(class_1657 player) {
		return contentHolder != null && contentHolder.canPlayerUse(player);
	}

	static class BlueprintCraftingInventory extends class_1715 {

		public BlueprintCraftingInventory(class_1703 menu, ItemStackHandler items) {
			super(menu, 3, 3);
			for (int y = 0; y < 3; y++) {
				for (int x = 0; x < 3; x++) {
					class_1799 stack = items.getStackInSlot(y * 3 + x);
					method_5447(y * 3 + x, stack == null ? class_1799.field_8037 : stack.method_7972());
				}
			}
		}

	}

	public class BlueprintCraftSlot extends SlotItemHandler {

		public int index;

		public BlueprintCraftSlot(ItemStackHandler itemHandler, int index, int xPosition, int yPosition) {
			super(itemHandler, index, xPosition, yPosition);
			this.field_7874 = index;
		}

		@Override
		public void method_7668() {
			super.method_7668();
			if (field_7874 == 9 && method_7681() && !contentHolder.getBlueprintWorld().field_9236) {
				contentHolder.inferredIcon = false;
				class_3222 serverplayerentity = (class_3222) player;
				serverplayerentity.field_13987.method_14364(new class_2653(field_7763, method_37422(), 36 + 9, method_7677()));
			}
			if (field_7874 < 9)
				onCraftMatrixChanged();
		}

	}

}
