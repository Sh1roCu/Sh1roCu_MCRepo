package com.simibubi.create.content.contraptions.actors.trainControls;

import com.mojang.serialization.MapCodec;
import com.simibubi.create.AllShapes;
import com.simibubi.create.content.contraptions.ContraptionWorld;
import com.simibubi.create.content.equipment.wrench.IWrenchable;
import com.simibubi.create.foundation.block.ProperWaterloggedBlock;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2746;
import net.minecraft.class_3610;
import net.minecraft.class_3726;
import org.jetbrains.annotations.NotNull;

public class ControlsBlock extends class_2383 implements IWrenchable, ProperWaterloggedBlock {

	public static final class_2746 OPEN = class_2746.method_11825("open");
	public static final class_2746 VIRTUAL = class_2746.method_11825("virtual");

	public static final MapCodec<ControlsBlock> field_46280 = method_54094(ControlsBlock::new);

	public ControlsBlock(class_2251 p_54120_) {
		super(p_54120_);
		method_9590(method_9564().method_11657(OPEN, false)
			.method_11657(WATERLOGGED, false)
			.method_11657(VIRTUAL, false));
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> pBuilder) {
		super.method_9515(pBuilder.method_11667(field_11177, OPEN, WATERLOGGED, VIRTUAL));
	}

	@Override
	public class_2680 method_9559(class_2680 pState, class_2350 pDirection, class_2680 pNeighborState,
		class_1936 pLevel, class_2338 pCurrentPos, class_2338 pNeighborPos) {
		updateWater(pLevel, pState, pCurrentPos);
		return pState.method_11657(OPEN, pLevel instanceof ContraptionWorld);
	}

	@Override
	public class_3610 method_9545(class_2680 pState) {
		return fluidState(pState);
	}

	@Override
	public class_2680 method_9605(class_1750 pContext) {
		class_2680 state = withWater(super.method_9605(pContext), pContext);
		class_2350 horizontalDirection = pContext.method_8042();
		class_1657 player = pContext.method_8036();

		state = state.method_11657(field_11177, horizontalDirection.method_10153());
		if (player != null && player.method_5715())
			state = state.method_11657(field_11177, horizontalDirection);

		return state;
	}

	@Override
	public class_265 method_9530(class_2680 pState, class_1922 pLevel, class_2338 pPos, class_3726 pContext) {
		return AllShapes.CONTROLS.get(pState.method_11654(field_11177));
	}

	@Override
	public class_265 method_9549(class_2680 pState, class_1922 pLevel, class_2338 pPos,
		class_3726 pContext) {
		return AllShapes.CONTROLS_COLLISION.get(pState.method_11654(field_11177));
	}

	@Override
	protected @NotNull MapCodec<? extends class_2383> method_53969() {
		return field_46280;
	}
}
