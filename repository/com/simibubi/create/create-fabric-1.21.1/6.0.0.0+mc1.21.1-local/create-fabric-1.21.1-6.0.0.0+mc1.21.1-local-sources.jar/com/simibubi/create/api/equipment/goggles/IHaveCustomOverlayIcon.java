package com.simibubi.create.api.equipment.goggles;

import com.simibubi.create.AllItems;
import net.minecraft.class_1799;
import net.minecraft.class_2586;

public sealed interface IHaveCustomOverlayIcon permits IHaveGoggleInformation, IHaveHoveringInformation {
	/**
	 * This method will be called when looking at a {@link class_2586} that implements {@link IHaveGoggleInformation}
	 * or {@link IHaveHoveringInformation}
	 *
	 * @return The {@link class_1799} you want the overlay to show instead of the goggles
	 */
	default class_1799 getIcon(boolean isPlayerSneaking) {
		return AllItems.GOGGLES.asStack();
	}
}
