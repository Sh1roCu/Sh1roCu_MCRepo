package com.simibubi.create.api.contraption.storage.item.menu;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_1263;
import net.minecraft.class_1270;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1716;
import net.minecraft.class_2561;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import net.minecraft.class_747;
import org.jetbrains.annotations.Nullable;
import com.simibubi.create.infrastructure.fabric.transfer.item.SlottedStackStorage;

/**
 * Methods for creating generic menus usable by mounted storages.
 */
public class MountedStorageMenus {
	public static final List<class_3917<?>> GENERIC_CHEST_MENUS = List.of(
		class_3917.field_18664, class_3917.field_18665, class_3917.field_17326,
		class_3917.field_18666, class_3917.field_18667, class_3917.field_17327
	);

	@Nullable
	public static class_3908 createGeneric(class_2561 menuName, SlottedStackStorage handler,
											 Predicate<class_1657> stillValid, Consumer<class_1657> onClose) {
		int rows = handler.getSlotCount() / 9;
		if (rows < 1 || rows > 6)
			return null;

		// make sure rows are full
		if (handler.getSlotCount() % 9 != 0)
			return null;

		class_3917<?> type = GENERIC_CHEST_MENUS.get(rows - 1);
		class_1263 wrapper = new StorageInteractionWrapper(handler, stillValid, onClose);
		class_1270 constructor = (id, inv, player) -> new class_1707(type, id, inv, wrapper, rows);
		return new class_747(constructor, menuName);
	}

	@Nullable
	public static class_3908 createGeneric9x9(class_2561 name, SlottedStackStorage handler,
												Predicate<class_1657> stillValid, Consumer<class_1657> onClose) {
		if (handler.getSlotCount() != 9)
			return null;

		class_1263 wrapper = new StorageInteractionWrapper(handler, stillValid, onClose);
		class_1270 constructor = (id, inv, player) -> new class_1716(id, inv, wrapper);
		return new class_747(constructor, name);
	}
}
