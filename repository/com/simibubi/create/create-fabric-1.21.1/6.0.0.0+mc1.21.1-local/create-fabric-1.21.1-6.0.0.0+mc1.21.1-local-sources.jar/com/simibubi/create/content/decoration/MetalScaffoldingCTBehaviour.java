package com.simibubi.create.content.decoration;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.foundation.block.connected.CTSpriteShiftEntry;
import com.simibubi.create.foundation.block.connected.HorizontalCTBehaviour;
import net.minecraft.class_1058;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2680;

public class MetalScaffoldingCTBehaviour extends HorizontalCTBehaviour {

	protected CTSpriteShiftEntry insideShift;

	public MetalScaffoldingCTBehaviour(CTSpriteShiftEntry outsideShift, CTSpriteShiftEntry insideShift,
		CTSpriteShiftEntry topShift) {
		super(outsideShift, topShift);
		this.insideShift = insideShift;
	}

	@Override
	public boolean buildContextForOccludedDirections() {
		return true;
	}

	@Override
	protected boolean isBeingBlocked(class_2680 state, class_1920 reader, class_2338 pos, class_2338 otherPos,
		class_2350 face) {
		return face.method_10166() == class_2351.field_11052 && super.isBeingBlocked(state, reader, pos, otherPos, face);
	}

	@Override
	public CTSpriteShiftEntry getShift(class_2680 state, class_2350 direction, @Nullable class_1058 sprite) {
		if (direction.method_10166() != class_2351.field_11052 && sprite == insideShift.getOriginal())
			return insideShift;
		return super.getShift(state, direction, sprite);
	}

	@Override
	public boolean connectsTo(class_2680 state, class_2680 other, class_1920 reader, class_2338 pos,
		class_2338 otherPos, class_2350 face) {
		return super.connectsTo(state, other, reader, pos, otherPos, face)
			&& state.method_11654(MetalScaffoldingBlock.field_16547) && other.method_11654(MetalScaffoldingBlock.field_16547);
	}

}
