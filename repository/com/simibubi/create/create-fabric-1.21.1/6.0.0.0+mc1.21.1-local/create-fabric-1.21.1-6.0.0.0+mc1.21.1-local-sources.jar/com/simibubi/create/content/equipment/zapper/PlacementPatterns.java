package com.simibubi.create.content.equipment.zapper;

import java.util.List;
import java.util.Random;
import java.util.function.Predicate;

import com.google.common.base.Predicates;
import com.mojang.serialization.Codec;
import com.simibubi.create.AllDataComponents;
import com.simibubi.create.foundation.gui.AllIcons;

import net.createmod.catnip.lang.Lang;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_3542;
import net.minecraft.class_9139;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecBuilders;
import io.netty.buffer.ByteBuf;

import org.jetbrains.annotations.NotNull;

public enum PlacementPatterns implements class_3542 {
	Solid(AllIcons.I_PATTERN_SOLID),
	Checkered(AllIcons.I_PATTERN_CHECKERED),
	InverseCheckered(AllIcons.I_PATTERN_CHECKERED_INVERSED),
	Chance25(AllIcons.I_PATTERN_CHANCE_25),
	Chance50(AllIcons.I_PATTERN_CHANCE_50),
	Chance75(AllIcons.I_PATTERN_CHANCE_75);

	public static final Codec<PlacementPatterns> CODEC = class_3542.method_53955(PlacementPatterns::values);
	public static final class_9139<ByteBuf, PlacementPatterns> STREAM_CODEC = CatnipStreamCodecBuilders.ofEnum(PlacementPatterns.class);

	public final String translationKey;
	public final AllIcons icon;

	private PlacementPatterns(AllIcons icon) {
		this.translationKey = Lang.asId(name());
		this.icon = icon;
	}

	public static void applyPattern(List<class_2338> blocksIn, class_1799 stack) {
		PlacementPatterns pattern = stack.method_57825(AllDataComponents.PLACEMENT_PATTERN, Solid);
		Random r = new Random();
		Predicate<class_2338> filter = Predicates.alwaysFalse();

		switch (pattern) {
		case Chance25:
			filter = pos -> r.nextBoolean() || r.nextBoolean();
			break;
		case Chance50:
			filter = pos -> r.nextBoolean();
			break;
		case Chance75:
			filter = pos -> r.nextBoolean() && r.nextBoolean();
			break;
		case Checkered:
			filter = pos -> (pos.method_10263() + pos.method_10264() + pos.method_10260()) % 2 == 0;
			break;
		case InverseCheckered:
			filter = pos -> (pos.method_10263() + pos.method_10264() + pos.method_10260()) % 2 != 0;
			break;
		case Solid:
		default:
			break;
		}

		blocksIn.removeIf(filter);
	}

	@Override
	public @NotNull String method_15434() {
		return Lang.asId(name());
	}
}
