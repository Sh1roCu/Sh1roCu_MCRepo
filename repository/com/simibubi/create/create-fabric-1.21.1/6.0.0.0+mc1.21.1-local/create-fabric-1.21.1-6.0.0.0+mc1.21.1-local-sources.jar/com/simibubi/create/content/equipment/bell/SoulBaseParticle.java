package com.simibubi.create.content.equipment.bell;

import org.joml.Quaternionf;
import com.simibubi.create.AllParticleTypes;
import io.github.fabricators_of_create.porting_lib.util.ParticleHelper;
import net.minecraft.class_2338;
import net.minecraft.class_2396;
import net.minecraft.class_4002;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_7833;

public class SoulBaseParticle extends CustomRotationParticle {

	private final class_4002 animatedSprite;

	public SoulBaseParticle(class_638 worldIn, double x, double y, double z, double vx, double vy, double vz,
                            class_4002 spriteSet) {
		super(worldIn, x, y, z, spriteSet, 0);
		this.animatedSprite = spriteSet;
		this.field_17867 = 0.5f;
		this.method_3080(this.field_17867, this.field_17867);
		this.loopLength = 16 + (int) (this.field_3840.method_43057() * 2f - 1f);
		this.field_3847 = (int) (90.0F / (this.field_3840.method_43057() * 0.36F + 0.64F));
		this.selectSpriteLoopingWithAge(animatedSprite);
		ParticleHelper.setStoppedByCollision(this, true); // disable movement
	}

	@Override
	public void method_3070() {
		selectSpriteLoopingWithAge(animatedSprite);

		class_2338 pos = class_2338.method_49637(field_3874, field_3854, field_3871);
		if (field_3866++ >= field_3847 || !SoulPulseEffect.isDark(field_3851, pos))
			method_3085();
	}

	@Override
	public Quaternionf getCustomRotation(class_4184 camera, float partialTicks) {
		return class_7833.field_40714.rotationDegrees(90);
	}

	public static class Data extends BasicParticleData<SoulBaseParticle> {
		@Override
		public IBasicParticleFactory<SoulBaseParticle> getBasicFactory() {
			return SoulBaseParticle::new;
		}

		@Override
		public class_2396<?> method_10295() {
			return AllParticleTypes.SOUL_BASE.get();
		}
	}
}
