package com.simibubi.create.content.contraptions.render;

import org.joml.Matrix4f;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;

import net.createmod.catnip.animation.AnimationTickHolder;
import net.minecraft.class_1297;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

/**
 * <p>
 * ContraptionMatrices must be cleared and setup per-contraption per-frame
 * </p>
 */
public class ContraptionMatrices {

	private final class_4587 modelViewProjection = new class_4587();
	private final class_4587 viewProjection = new class_4587();
	private final class_4587 model = new class_4587();
	private final Matrix4f world = new Matrix4f();
	private final Matrix4f light = new Matrix4f();

	void setup(class_4587 viewProjection, AbstractContraptionEntity entity) {
		float partialTicks = AnimationTickHolder.getPartialTicks();

		this.viewProjection.method_22903();
		transform(this.viewProjection, viewProjection);
		model.method_22903();
		entity.applyLocalTransforms(model, partialTicks);

		modelViewProjection.method_22903();
		transform(modelViewProjection, viewProjection);
		transform(modelViewProjection, model);

		translateToEntity(world, entity, partialTicks);

		light.set(world);
		light.mul(model.method_23760()
			.method_23761());
	}

	void clear() {
		clearStack(modelViewProjection);
		clearStack(viewProjection);
		clearStack(model);
		world.identity();
		light.identity();
	}

	public class_4587 getModelViewProjection() {
		return modelViewProjection;
	}

	public class_4587 getViewProjection() {
		return viewProjection;
	}

	public class_4587 getModel() {
		return model;
	}

	public Matrix4f getWorld() {
		return world;
	}

	public Matrix4f getLight() {
		return light;
	}

	public static void transform(class_4587 ms, class_4587 transform) {
		ms.method_23760()
			.method_23761()
			.mul(transform.method_23760()
				.method_23761());
		ms.method_23760()
			.method_23762()
			.mul(transform.method_23760()
				.method_23762());
	}

	public static void translateToEntity(Matrix4f matrix, class_1297 entity, float partialTicks) {
		double x = class_3532.method_16436(partialTicks, entity.field_6038, entity.method_23317());
		double y = class_3532.method_16436(partialTicks, entity.field_5971, entity.method_23318());
		double z = class_3532.method_16436(partialTicks, entity.field_5989, entity.method_23321());
		matrix.setTranslation((float) x, (float) y, (float) z);
	}

	public static void clearStack(class_4587 ms) {
		while (!ms.method_22911()) {
			ms.method_22909();
		}
	}

}
