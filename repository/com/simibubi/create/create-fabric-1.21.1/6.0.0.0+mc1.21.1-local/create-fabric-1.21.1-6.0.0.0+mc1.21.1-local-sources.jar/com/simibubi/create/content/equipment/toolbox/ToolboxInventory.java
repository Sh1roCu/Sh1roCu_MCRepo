package com.simibubi.create.content.equipment.toolbox;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_7225;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.simibubi.create.AllDataComponents;
import com.simibubi.create.AllItems;
import com.simibubi.create.foundation.item.ItemSlots;
import com.simibubi.create.infrastructure.fabric.transfer.TransactionSuccessCallback;
import com.simibubi.create.infrastructure.fabric.transfer.item.ItemStackHandler;

import net.createmod.catnip.nbt.NBTHelper;
import net.neoforged.neoforge.items.ItemHandlerHelper;

public class ToolboxInventory extends ItemStackHandler {
	public static final Codec<ToolboxInventory> CODEC = RecordCodecBuilder.create(instance -> instance.group(
		ItemSlots.maxSizeCodec(8).fieldOf("items").forGetter(ItemSlots::fromHandler),
		class_1799.field_24671.listOf().fieldOf("filters").forGetter(toolbox -> toolbox.filters)
	).apply(instance, ToolboxInventory::deserialize));

	public static final int STACKS_PER_COMPARTMENT = 4;
	List<class_1799> filters;
	boolean settling;
	private ToolboxBlockEntity blockEntity;

	private boolean limitedMode;

	public ToolboxInventory(ToolboxBlockEntity be) {
		super(8 * STACKS_PER_COMPARTMENT);
		this.blockEntity = be;
		limitedMode = false;
		filters = new ArrayList<>();
		settling = false;
		for (int i = 0; i < 8; i++)
			filters.add(class_1799.field_8037);
	}

	public void inLimitedMode(Consumer<ToolboxInventory> action) {
		limitedMode = true;
		action.accept(this);
		limitedMode = false;
	}

	public void settle(int compartment) {
		int totalCount = 0;
		boolean valid = true;
		boolean shouldBeEmpty = false;
		class_1799 sample = class_1799.field_8037;

		for (int i = 0; i < STACKS_PER_COMPARTMENT; i++) {
			class_1799 stackInSlot = getStackInSlot(compartment * STACKS_PER_COMPARTMENT + i);
			totalCount += stackInSlot.method_7947();
			if (!shouldBeEmpty)
				shouldBeEmpty = stackInSlot.method_7960() || stackInSlot.method_7947() != stackInSlot.method_57825(class_9334.field_50071, 64);
			else if (!stackInSlot.method_7960()) {
				valid = false;
				sample = stackInSlot;
			}
		}

		if (valid)
			return;

		settling = true;
		if (!sample.method_7946()) {
			for (int i = 0; i < STACKS_PER_COMPARTMENT; i++) {
				if (!getStackInSlot(compartment * STACKS_PER_COMPARTMENT + i).method_7960())
					continue;
				for (int j = i + 1; j < STACKS_PER_COMPARTMENT; j++) {
					class_1799 stackInSlot = getStackInSlot(compartment * STACKS_PER_COMPARTMENT + j);
					if (stackInSlot.method_7960())
						continue;
					setStackInSlot(compartment * STACKS_PER_COMPARTMENT + i, stackInSlot);
					setStackInSlot(compartment * STACKS_PER_COMPARTMENT + j, class_1799.field_8037);
					break;
				}
			}
		} else {
			for (int i = 0; i < STACKS_PER_COMPARTMENT; i++) {
				class_1799 copy = totalCount <= 0 ? class_1799.field_8037
					: sample.method_46651(Math.min(totalCount, sample.method_57825(class_9334.field_50071, 64)));
				setStackInSlot(compartment * STACKS_PER_COMPARTMENT + i, copy);
				totalCount -= copy.method_7947();
			}
		}
		settling = false;
		notifyUpdate();
	}

	@Override
	public boolean isItemValid(int slot, ItemVariant var, int count) {
		class_1799 stack = var.toStack();
		if (!stack.method_7909().method_31568())
			return false;

		if (slot < 0 || slot >= getSlotCount())
			return false;
		int compartment = slot / STACKS_PER_COMPARTMENT;
		class_1799 filter = filters.get(compartment);
		if (limitedMode && filter.method_7960())
			return false;
		if (filter.method_7960() || ToolboxInventory.canItemsShareCompartment(filter, stack))
			return super.isItemValid(slot, var, count);
		return false;
	}

	@Override
	public void setStackInSlot(int slot, class_1799 stack) {
		super.setStackInSlot(slot, stack);
		updateCompartmentFilters(slot, stack, null);
	}

	private void updateCompartmentFilters(int slot, class_1799 stack, @Nullable TransactionContext ctx) {
		int compartment = slot / STACKS_PER_COMPARTMENT;
		if (!stack.method_7960() && filters.get(compartment)
				.method_7960()) {
			filters.set(compartment, stack.method_46651(1));
			if (ctx != null) TransactionSuccessCallback.register(ctx, blockEntity::notifyUpdate);
			else notifyUpdate();
		}
	}

	@Override
	public @NotNull class_2487 serializeNBT(@NotNull class_7225.class_7874 registries) {
		class_2487 compound = super.serializeNBT(registries);
		compound.method_10566("Compartments", NBTHelper.writeItemList(filters, registries));
		return compound;
	}

	@Override
	protected void onContentsChanged(int slot) {
		if (!settling && (blockEntity == null || !blockEntity.method_10997().field_9236))
			settle(slot / STACKS_PER_COMPARTMENT);
		notifyUpdate();
		super.onContentsChanged(slot);
		// fabric: since slots bypass setStackInSlot, call this here too
		class_1799 stack = this.getStackInSlot(slot);
		updateCompartmentFilters(slot, stack, null);
	}

	@Override
	public void deserializeNBT(@NotNull class_7225.class_7874 registries, class_2487 nbt) {
		filters = NBTHelper.readItemList(nbt.method_10554("Compartments", class_2520.field_33260), registries);
		if (filters.size() != 8) {
			filters.clear();
			for (int i = 0; i < 8; i++)
				filters.add(class_1799.field_8037);
		}
		super.deserializeNBT(registries, nbt);
	}

	public class_1799 distributeToCompartment(@Nonnull class_1799 stack, int compartment, TransactionContext ctx) {
		if (stack.method_7960())
			return stack;
		if (filters.get(compartment)
			.method_7960())
			return stack;

		int toInsert = stack.method_7947();
		int inserted = 0;
		ItemVariant variant = ItemVariant.of(stack);
		for (int i = STACKS_PER_COMPARTMENT - 1; i >= 0; i--) {
			int slot = compartment * STACKS_PER_COMPARTMENT + i;
			inserted += getSlot(slot).insert(variant, toInsert - inserted, ctx);
			if (inserted >= toInsert)
				break;
		}

		return ItemHandlerHelper.copyStackWithSize(stack, toInsert - inserted);
	}

	public class_1799 takeFromCompartment(int amount, int compartment, TransactionContext ctx) {
		if (amount == 0)
			return class_1799.field_8037;

		ItemVariant toExtract = null;
		int extracted = 0;
		for (int i = STACKS_PER_COMPARTMENT - 1; i >= 0; i--) {
			int slot = compartment * STACKS_PER_COMPARTMENT + i;
			SingleSlotStorage<ItemVariant> handlerSlot = getSlot(slot);
			if (handlerSlot.isResourceBlank())
				continue;
			if (toExtract == null)
				toExtract = handlerSlot.getResource();
			extracted += handlerSlot.extract(toExtract, amount - extracted, ctx);
			if (extracted >= amount)
				break;
		}

		return toExtract == null || extracted == 0 ? class_1799.field_8037 : toExtract.toStack(extracted);
	}

	public static class_1799 cleanItemNBT(class_1799 stack) {
		if (AllItems.BELT_CONNECTOR.isIn(stack))
			stack.method_57381(AllDataComponents.BELT_FIRST_SHAFT);
		return stack;
	}

	public static boolean canItemsShareCompartment(class_1799 stack1, class_1799 stack2) {
		if (!stack1.method_7946() && !stack2.method_7946() && stack1.method_7963() && stack2.method_7963())
			return stack1.method_7909() == stack2.method_7909();
		if (AllItems.BELT_CONNECTOR.isIn(stack1) && AllItems.BELT_CONNECTOR.isIn(stack2))
			return true;
		return class_1799.method_31577(stack1, stack2);
	}

	private void notifyUpdate() {
		if (blockEntity != null)
			// change to sendData if this doesn't exist
			blockEntity.notifyUpdate();
	}

	private static ToolboxInventory deserialize(ItemSlots slots, List<class_1799> filters) {
		ToolboxInventory inventory = new ToolboxInventory(null);
		slots.forEach(inventory::setStackInSlot);
		inventory.filters = filters;
		return inventory;
	}

}
