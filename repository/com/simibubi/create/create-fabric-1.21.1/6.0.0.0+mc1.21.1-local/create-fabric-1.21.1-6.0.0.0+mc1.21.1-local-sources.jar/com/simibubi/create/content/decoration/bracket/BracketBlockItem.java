package com.simibubi.create.content.decoration.bracket;

import java.util.Optional;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3419;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

public class BracketBlockItem extends class_1747 {

	public BracketBlockItem(class_2248 p_i48527_1_, class_1793 p_i48527_2_) {
		super(p_i48527_1_, p_i48527_2_);
	}

	@Override
	public class_1269 method_7884(class_1838 context) {
		class_1937 world = context.method_8045();
		class_2338 pos = context.method_8037();
		class_2680 state = world.method_8320(pos);
		BracketBlock bracketBlock = getBracketBlock();
		class_1657 player = context.method_8036();

		BracketedBlockEntityBehaviour behaviour = BlockEntityBehaviour.get(world, pos, BracketedBlockEntityBehaviour.TYPE);

		if (behaviour == null)
			return class_1269.field_5814;
		if (!behaviour.canHaveBracket())
			return class_1269.field_5814;
		if (world.field_9236)
			return class_1269.field_5812;

		Optional<class_2680> suitableBracket = bracketBlock.getSuitableBracket(state, context.method_8038());
		if (!suitableBracket.isPresent() && player != null)
			suitableBracket =
				bracketBlock.getSuitableBracket(state, class_2350.method_10159(player)[0].method_10153());
		if (!suitableBracket.isPresent())
			return class_1269.field_5812;

		class_2680 bracket = behaviour.getBracket();
		class_2680 newBracket = suitableBracket.get();
		
		if (bracket == newBracket)
			return class_1269.field_5812;
		
		world.method_8396(null, pos, newBracket
			.method_26231()
			.method_10598(), class_3419.field_15245, 0.75f, 1);
		behaviour.applyBracket(newBracket);
		
		if (player == null || !player.method_7337()) {
			context.method_8041()
				.method_7934(1);
			if (bracket != null) {
				class_1799 returnedStack = new class_1799(bracket.method_26204());
				if (player == null)
					class_2248.method_9577(world, pos, returnedStack);
				else
					player.method_31548().method_7398(returnedStack);
			}
		}
		return class_1269.field_5812;
	}

	private BracketBlock getBracketBlock() {
		return (BracketBlock) method_7711();
	}

}
