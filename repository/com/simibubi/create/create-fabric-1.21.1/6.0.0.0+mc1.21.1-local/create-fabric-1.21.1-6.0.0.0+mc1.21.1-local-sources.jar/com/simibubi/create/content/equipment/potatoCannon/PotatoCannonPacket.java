package com.simibubi.create.content.equipment.potatoCannon;

import com.simibubi.create.AllPackets;
import com.simibubi.create.CreateClient;
import com.simibubi.create.content.equipment.zapper.ShootGadgetPacket;
import com.simibubi.create.content.equipment.zapper.ShootableGadgetRenderHandler;

import net.createmod.catnip.codecs.stream.CatnipStreamCodecs;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class PotatoCannonPacket extends ShootGadgetPacket {
	public static final class_9139<class_9129, PotatoCannonPacket> STREAM_CODEC = class_9139.method_58025(
		CatnipStreamCodecs.VEC3, packet -> packet.location,
		CatnipStreamCodecs.VEC3, packet -> packet.motion,
		class_1799.field_49268, packet -> packet.item,
		CatnipStreamCodecs.HAND, packet -> packet.hand,
		class_9135.field_48552, packet -> packet.pitch,
		class_9135.field_48547, packet -> packet.self,
		PotatoCannonPacket::new
	);

	private final float pitch;
	private final class_243 motion;
	private final class_1799 item;

	public PotatoCannonPacket(class_243 location, class_243 motion, class_1799 item, class_1268 hand, float pitch, boolean self) {
		super(location, hand, self);
		this.motion = motion;
		this.item = item;
		this.pitch = pitch;
	}

	@Override
	@Environment(EnvType.CLIENT)
	protected void handleAdditional() {
		CreateClient.POTATO_CANNON_RENDER_HANDLER.beforeShoot(pitch, location, motion, item);
	}

	@Override
	@Environment(EnvType.CLIENT)
	protected ShootableGadgetRenderHandler getHandler() {
		return CreateClient.POTATO_CANNON_RENDER_HANDLER;
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.POTATO_CANNON;
	}
}
