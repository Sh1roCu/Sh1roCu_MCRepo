package com.simibubi.create.content.contraptions.behaviour.dispenser;

import java.util.function.Predicate;

import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_5819;
import net.minecraft.class_6088;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import com.simibubi.create.api.contraption.dispenser.DefaultMountedDispenseBehavior;
import com.simibubi.create.api.contraption.dispenser.MountedDispenseBehavior;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorage;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.foundation.item.ItemHelper;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;

public class DropperMovementBehaviour implements MovementBehaviour {
	@Override
	public void visitNewPosition(MovementContext context, class_2338 pos) {
		if (context.world.field_9236)
			return;

		MountedItemStorage storage = context.getItemStorage();
		if (storage == null)
			return;

		int slot = getSlot(storage, context.world.field_9229, context.contraption.getStorage().getAllItems());
		if (slot == -1) {
			// all slots empty
			failDispense(context, pos);
			return;
		}

		// copy because dispense behaviors will modify it directly
		class_1799 stack = storage.getStackInSlot(slot).method_7972();
		MountedDispenseBehavior behavior = getDispenseBehavior(context, pos, stack);
		class_1799 remainder = behavior.dispense(stack, context, pos);
		storage.setStackInSlot(slot, remainder);
	}

	protected MountedDispenseBehavior getDispenseBehavior(MovementContext context, class_2338 pos, class_1799 stack) {
		return DefaultMountedDispenseBehavior.INSTANCE;
	}

	/**
	 * Finds a dispensable slot. Empty slots are skipped and nearly-empty slots are topped off.
	 */
	private static int getSlot(MountedItemStorage storage, class_5819 random, Storage<ItemVariant> contraptionInventory) {
		IntList filledSlots = new IntArrayList();
		for (int i = 0; i < storage.getSlotCount(); i++) {
			class_1799 stack = storage.getStackInSlot(i);
			if (stack.method_7960())
				continue;

			if (stack.method_7947() == 1 && stack.method_7914() != 1) {
				stack = tryTopOff(stack, contraptionInventory);
				if (stack != null) {
					storage.setStackInSlot(i, stack);
				} else {
					continue;
				}
			}

			filledSlots.add(i);
		}

		return switch (filledSlots.size()) {
			case 0 -> -1;
			case 1 -> filledSlots.getInt(0);
			default -> class_156.method_32309(filledSlots, random);
		};
	}

	@Nullable
	private static class_1799 tryTopOff(class_1799 stack, Storage<ItemVariant> from) {
		Predicate<class_1799> test = otherStack -> class_1799.method_31577(stack, otherStack);
		int needed = stack.method_7914() - stack.method_7947();

		class_1799 extracted = ItemHelper.extract(from, test, ItemHelper.ExtractionCountMode.UPTO, needed, false);
		return extracted.method_7960() ? null : stack.method_46651(stack.method_7947() + extracted.method_7947());
	}

	private static void failDispense(MovementContext ctx, class_2338 pos) {
		ctx.world.method_20290(class_6088.field_31159, pos, 0);
	}
}
