package com.simibubi.create.content.contraptions;

import java.util.function.BiPredicate;
import com.simibubi.create.foundation.blockEntity.behaviour.CenteredSideValueBoxTransform;

import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.math.AngleHelper;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_4587;

public class DirectionalExtenderScrollOptionSlot extends CenteredSideValueBoxTransform {

	public DirectionalExtenderScrollOptionSlot(BiPredicate<class_2680, class_2350> allowedDirections) {
		super(allowedDirections);
	}

	@Override
	public class_243 getLocalOffset(class_1936 level, class_2338 pos, class_2680 state) {
		return super.getLocalOffset(level, pos, state)
				.method_1019(class_243.method_24954(state.method_11654(class_2741.field_12525).method_10163()).method_1021(-2 / 16f));
	}

	@Override
	public void rotate(class_1936 level, class_2338 pos, class_2680 state, class_4587 ms) {
		if (!getSide().method_10166().method_10179())
			TransformStack.of(ms)
					.rotateYDegrees(AngleHelper.horizontalAngle(state.method_11654(class_2741.field_12525)) + 180);
		super.rotate(level, pos, state, ms);
	}
}
