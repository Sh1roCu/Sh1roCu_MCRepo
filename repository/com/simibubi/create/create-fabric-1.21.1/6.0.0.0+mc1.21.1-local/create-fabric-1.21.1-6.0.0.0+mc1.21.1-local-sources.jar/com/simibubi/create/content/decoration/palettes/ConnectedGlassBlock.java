package com.simibubi.create.content.decoration.palettes;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_8923;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class ConnectedGlassBlock extends class_8923 {

	public ConnectedGlassBlock(class_2251 p_i48392_1_) {
		super(p_i48392_1_);
	}

	@Override
	@Environment(EnvType.CLIENT)
	public boolean method_9522(class_2680 state, class_2680 adjacentBlockState, class_2350 side) {
		return adjacentBlockState.method_26204() instanceof ConnectedGlassBlock || super.method_9522(state, adjacentBlockState, side);
	}

//	@Override
//	public boolean shouldDisplayFluidOverlay(BlockState state, BlockAndTintGetter world, BlockPos pos, FluidState fluidState) {
//		return true;
//	}
}
