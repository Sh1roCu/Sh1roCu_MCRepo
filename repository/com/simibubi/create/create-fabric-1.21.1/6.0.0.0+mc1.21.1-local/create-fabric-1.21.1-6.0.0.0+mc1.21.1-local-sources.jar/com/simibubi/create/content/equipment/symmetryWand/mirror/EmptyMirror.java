package com.simibubi.create.content.equipment.symmetryWand.mirror;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.ImmutableList;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3542;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class EmptyMirror extends SymmetryMirror {

	public static enum Align implements class_3542 {
		None("none");

		private final String name;
		private Align(String name) { this.name = name; }
		@Override public String method_15434() { return name; }
		@Override public String toString() { return name; }
	}

	public EmptyMirror(class_243 pos) {
		super(pos);
		orientation = Align.None;
	}

	@Override
	protected void setOrientation() {
	}

	@Override
	public void setOrientation(int index) {
		this.orientation = Align.values()[index];
		orientationIndex = index;
	}

	@Override
	public Map<class_2338, class_2680> process(class_2338 position, class_2680 block) {
		return new HashMap<>();
	}

	@Override
	public String typeName() {
		return EMPTY;
	}

	@Override
	@Environment(EnvType.CLIENT)
	public PartialModel getModel() {
		return null;
	}

	@Override
	public List<class_2561> getAlignToolTips() {
		return ImmutableList.of();
	}

}
