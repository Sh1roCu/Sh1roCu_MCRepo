package com.simibubi.create.content.contraptions.actors.roller;

import static net.minecraft.class_2741.field_12481;

import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.contraptions.actors.harvester.HarvesterRenderer;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.contraptions.render.ContraptionMatrices;
import com.simibubi.create.foundation.blockEntity.renderer.SmartBlockEntityRenderer;
import com.simibubi.create.foundation.virtualWorld.VirtualRenderWorld;

import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.math.VecHelper;
import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SuperByteBuffer;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614.class_5615;
import net.minecraft.class_761;

public class RollerRenderer extends SmartBlockEntityRenderer<RollerBlockEntity> {

	public RollerRenderer(class_5615 context) {
		super(context);
	}

	@Override
	protected void renderSafe(RollerBlockEntity be, float partialTicks, class_4587 ms, class_4597 buffer,
		int light, int overlay) {
		super.renderSafe(be, partialTicks, ms, buffer, light, overlay);

		class_2680 blockState = be.method_11010();
		class_4588 vc = buffer.getBuffer(class_1921.method_23579());

		ms.method_22903();
		ms.method_22904(0, -0.25, 0);
		SuperByteBuffer superBuffer = CachedBuffers.partial(AllPartialModels.ROLLER_WHEEL, blockState);
		class_2350 facing = blockState.method_11654(RollerBlock.field_11177);
		superBuffer.translate(class_243.method_24954(facing.method_10163())
			.method_1021(17 / 16f));
		HarvesterRenderer.transform(be.method_10997(), facing, superBuffer, be.getAnimatedSpeed(), class_243.field_1353);
		superBuffer.translate(0, -.5, .5)
			.rotateYDegrees(90)
			.light(light)
			.renderInto(ms, vc);
		ms.method_22909();

		CachedBuffers.partial(AllPartialModels.ROLLER_FRAME, blockState)
			.rotateCentered(AngleHelper.rad(AngleHelper.horizontalAngle(facing) + 180), class_2350.field_11036)
			.light(light)
			.renderInto(ms, vc);
	}

	public static void renderInContraption(MovementContext context, VirtualRenderWorld renderWorld,
		ContraptionMatrices matrices, class_4597 buffers) {
		class_2680 blockState = context.state;
		class_2350 facing = blockState.method_11654(field_12481);
		class_4588 vc = buffers.getBuffer(class_1921.method_23579());
		SuperByteBuffer superBuffer = CachedBuffers.partial(AllPartialModels.ROLLER_WHEEL, blockState);
		float speed = (float) (!VecHelper.isVecPointingTowards(context.relativeMotion, facing.method_10153())
			? context.getAnimationSpeed()
			: -context.getAnimationSpeed());
		if (context.contraption.stalled)
			speed = 0;

		superBuffer.transform(matrices.getModel())
			.translate(class_243.method_24954(facing.method_10163())
				.method_1021(17 / 16f));
		HarvesterRenderer.transform(context.world, facing, superBuffer, speed, class_243.field_1353);

		class_4587 viewProjection = matrices.getViewProjection();
		viewProjection.method_22903();
		viewProjection.method_22904(0, -.25, 0);
		int contraptionWorldLight = class_761.method_23794(renderWorld, context.localPos);
		superBuffer.translate(0, -.5, .5)
			.rotateYDegrees(90)
			.light(contraptionWorldLight)
			.useLevelLight(context.world, matrices.getWorld())
			.renderInto(viewProjection, vc);
		viewProjection.method_22909();

		CachedBuffers.partial(AllPartialModels.ROLLER_FRAME, blockState)
			.transform(matrices.getModel())
			.rotateCentered(AngleHelper.rad(AngleHelper.horizontalAngle(facing) + 180), class_2350.field_11036)
			.light(contraptionWorldLight)
			.useLevelLight(context.world, matrices.getWorld())
			.renderInto(viewProjection, vc);
	}

}
