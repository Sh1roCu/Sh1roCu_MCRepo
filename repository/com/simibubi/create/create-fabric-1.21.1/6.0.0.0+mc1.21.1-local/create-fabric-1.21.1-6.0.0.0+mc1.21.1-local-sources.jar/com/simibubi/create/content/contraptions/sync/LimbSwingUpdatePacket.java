package com.simibubi.create.content.contraptions.sync;

import com.simibubi.create.AllPackets;
import com.simibubi.create.foundation.utility.PersistentDataHelper;

import io.netty.buffer.ByteBuf;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecs;
import net.createmod.catnip.net.base.ClientboundPacketPayload;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record LimbSwingUpdatePacket(int entityId, class_243 position, float limbSwing) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, LimbSwingUpdatePacket> STREAM_CODEC = class_9139.method_56436(
			class_9135.field_49675, LimbSwingUpdatePacket::entityId,
			CatnipStreamCodecs.VEC3, LimbSwingUpdatePacket::position,
			class_9135.field_48552, LimbSwingUpdatePacket::limbSwing,
	        LimbSwingUpdatePacket::new
	);

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		class_1297 entity = player.field_17892.method_8469(entityId);
		if (entity == null)
			return;
		class_2487 data = PersistentDataHelper.get(entity);
		data.method_10569("LastOverrideLimbSwingUpdate", 0);
		data.method_10548("OverrideLimbSwing", limbSwing);
		entity.method_5759(position.field_1352, position.field_1351, position.field_1350, entity.method_36454(),
				entity.method_36455(), 2);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.LIMBSWING_UPDATE;
	}
}
