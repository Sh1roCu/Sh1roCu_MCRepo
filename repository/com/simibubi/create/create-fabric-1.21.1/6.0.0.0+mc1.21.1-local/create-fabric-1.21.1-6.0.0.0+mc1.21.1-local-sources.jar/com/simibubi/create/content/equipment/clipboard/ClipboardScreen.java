package com.simibubi.create.content.equipment.clipboard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.Nullable;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1109;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3544;
import net.minecraft.class_3728;
import net.minecraft.class_437;
import net.minecraft.class_474;
import net.minecraft.class_5225;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_634;
import net.minecraft.class_757;
import net.minecraft.class_768;
import net.minecraft.class_9801;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.apache.commons.lang3.mutable.MutableInt;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllDataComponents;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.content.equipment.clipboard.ClipboardOverrides.ClipboardType;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import com.simibubi.create.foundation.gui.AllIcons;
import com.simibubi.create.foundation.gui.widget.IconButton;
import com.simibubi.create.foundation.utility.CreateLang;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import net.createmod.catnip.gui.AbstractSimiScreen;
import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class ClipboardScreen extends AbstractSimiScreen {

	public class_1799 item;
	public class_2338 targetedBlock;

	List<List<ClipboardEntry>> pages;
	List<ClipboardEntry> currentEntries;
	int editingIndex;
	int frameTick;
	class_474 forward;
	class_474 backward;
	int currentPage;
	long lastClickTime;
	int lastIndex = -1;

	int hoveredEntry;
	boolean hoveredCheck;
	boolean readonly;

	DisplayCache displayCache = DisplayCache.EMPTY;
	class_3728 editContext;

	IconButton closeBtn;
	IconButton clearBtn;

	private int targetSlot;

	public ClipboardScreen(int targetSlot, class_1799 item, @Nullable class_2338 pos) {
		this.targetSlot = targetSlot;
		this.targetedBlock = pos;
		reopenWith(item);
	}

	public void reopenWith(class_1799 clipboard) {
		item = clipboard;
		pages = ClipboardEntry.readAll(item);
		if (pages.isEmpty())
			pages.add(new ArrayList<>());
		if (clearBtn == null) {
			currentPage = item.method_57825(AllDataComponents.CLIPBOARD_PREVIOUSLY_OPENED_PAGE, 0);
			currentPage = class_3532.method_15340(currentPage, 0, pages.size() - 1);
		}
		currentEntries = pages.get(currentPage);
		boolean startEmpty = currentEntries.isEmpty();
		if (startEmpty)
            currentEntries.add(new ClipboardEntry(false, class_2561.method_43473()));
		editingIndex = 0;
		editContext = new class_3728(this::getCurrentEntryText, this::setCurrentEntryText, this::getClipboard,
			this::setClipboard, this::validateTextForEntry);
		editingIndex = startEmpty ? 0 : -1;
		readonly = item.method_57826(AllDataComponents.CLIPBOARD_READ_ONLY);
		if (readonly)
			editingIndex = -1;
		if (clearBtn != null)
			method_25426();
	}

	@Override
	protected void method_25426() {
		setWindowSize(256, 256);
		super.method_25426();
		clearDisplayCache();

		int x = guiLeft;
		int y = guiTop - 8;

		method_37067();
		clearBtn = new IconButton(x + 234, y + 153, AllIcons.I_CLEAR_CHECKED).withCallback(() -> {
			editingIndex = -1;
			currentEntries.removeIf(ce -> ce.checked);
			if (currentEntries.isEmpty())
                currentEntries.add(new ClipboardEntry(false, class_2561.method_43473()));
			sendIfEditingBlock();
		});
		clearBtn.setToolTip(CreateLang.translateDirect("gui.clipboard.erase_checked"));
		closeBtn = new IconButton(x + 234, y + 175, AllIcons.I_PRIORITY_VERY_LOW)
			.withCallback(() -> field_22787.method_1507(null));
		closeBtn.setToolTip(CreateLang.translateDirect("station.close"));
		method_37063(closeBtn);
		method_37063(clearBtn);

		forward = new class_474(x + 176, y + 229, true, $ -> changePage(true), true);
		backward = new class_474(x + 53, y + 229, false, $ -> changePage(false), true);
		method_37063(forward);
		method_37063(backward);

		forward.field_22764 = currentPage < 50 && (!readonly || currentPage + 1 < pages.size());
		backward.field_22764 = currentPage > 0;
	}

	private int getNumPages() {
		return pages.size();
	}

	public void method_25393() {
		super.method_25393();
		frameTick++;

		if (targetedBlock != null) {
			if (!field_22787.field_1724.method_24515()
				.method_19771(targetedBlock, 10)) {
				method_25432();
				return;
			}
			if (!AllBlocks.CLIPBOARD.has(field_22787.field_1687.method_8320(targetedBlock))) {
				method_25432();
				return;
			}
		}

		int mx = (int) (this.field_22787.field_1729.method_1603() * (double) this.field_22787.method_22683()
			.method_4486() / (double) this.field_22787.method_22683()
				.method_4480());
		int my = (int) (this.field_22787.field_1729.method_1604() * (double) this.field_22787.method_22683()
			.method_4502() / (double) this.field_22787.method_22683()
				.method_4507());

		mx -= guiLeft + 35;
		my -= guiTop + 41;

		hoveredCheck = false;
		hoveredEntry = -1;

		if (mx > 0 && mx < 183 && my > 0 && my < 190) {
			hoveredCheck = mx < 20;
			int totalHeight = 0;
			for (int i = 0; i < currentEntries.size(); i++) {
				ClipboardEntry clipboardEntry = currentEntries.get(i);
				String text = clipboardEntry.text.getString();
				totalHeight +=
					Math.max(12, field_22793.method_1728(class_2561.method_43470(text), clipboardEntry.icon.method_7960() ? 150 : 130)
						.size() * 9 + 3);

				if (totalHeight > my) {
					hoveredEntry = i;
					return;
				}
			}
			hoveredEntry = currentEntries.size();
		}
	}

	private String getCurrentEntryText() {
		return currentEntries.get(editingIndex).text.getString();
	}

	private void setCurrentEntryText(String text) {
		currentEntries.get(editingIndex).text = class_2561.method_43470(text);
		sendIfEditingBlock();
	}

	private void setClipboard(String p_98148_) {
		if (field_22787 != null)
			class_3728.method_27551(field_22787, p_98148_);
	}

	private String getClipboard() {
		return field_22787 != null ? class_3728.method_27556(field_22787) : "";
	}

	private boolean validateTextForEntry(String newText) {
		int totalHeight = 0;
		for (int i = 0; i < currentEntries.size(); i++) {
			ClipboardEntry clipboardEntry = currentEntries.get(i);
			String text = i == editingIndex ? newText : clipboardEntry.text.getString();
			totalHeight += Math.max(12, field_22793.method_1728(class_2561.method_43470(text), 150)
				.size() * 9 + 3);
		}
		return totalHeight < 185;
	}

	private int yOffsetOfEditingEntry() {
		int totalHeight = 0;
		for (int i = 0; i < currentEntries.size(); i++) {
			if (i == editingIndex)
				break;
			ClipboardEntry clipboardEntry = currentEntries.get(i);
			totalHeight += Math.max(12, field_22793.method_1728(clipboardEntry.text, 150)
				.size() * 9 + 3);
		}
		return totalHeight;
	}

	private void changePage(boolean next) {
		int previously = currentPage;
		currentPage = class_3532.method_15340(currentPage + (next ? 1 : -1), 0, 50);
		if (currentPage == previously)
			return;
		editingIndex = -1;
		if (pages.size() <= currentPage) {
			if (readonly) {
				currentPage = previously;
				return;
			}
			pages.add(new ArrayList<>());
		}
		currentEntries = pages.get(currentPage);
		if (currentEntries.isEmpty()) {
            currentEntries.add(new ClipboardEntry(false, class_2561.method_43473()));
			if (!readonly) {
				editingIndex = 0;
				editContext.method_16204();
				clearDisplayCacheAfterChange();
			}
		}

		forward.field_22764 = currentPage < 50 && (!readonly || currentPage + 1 < pages.size());
		backward.field_22764 = currentPage > 0;

		if (next)
			return;
		if (pages.get(currentPage + 1)
			.stream()
			.allMatch(ce -> ce.text.getString()
				.isBlank()))
			pages.remove(currentPage + 1);
	}

	@Override
	protected void renderWindow(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		int x = guiLeft;
		int y = guiTop - 8;

		AllGuiTextures.CLIPBOARD.render(graphics, x, y);
		graphics.method_51439(field_22793, class_2561.method_43469("book.pageIndicator", currentPage + 1, getNumPages()),
			x + 150, y + 9, 0x43ffffff, false);

		for (int i = 0; i < currentEntries.size(); i++) {
			ClipboardEntry clipboardEntry = currentEntries.get(i);
			boolean checked = clipboardEntry.checked;
			int iconOffset = clipboardEntry.icon.method_7960() ? 0 : 16;

			class_5250 text = clipboardEntry.text;
			String string = text.getString();
			boolean isAddress = string.startsWith("#") && !string.substring(1)
				.isBlank();

			if (isAddress) {
				RenderSystem.enableBlend();
				(checked ? AllGuiTextures.CLIPBOARD_ADDRESS_INACTIVE : AllGuiTextures.CLIPBOARD_ADDRESS)
					.render(graphics, x + 44, y + 50);
				text = class_2561.method_43470(string.substring(1)
					.stripLeading());
			} else {
				graphics.method_51433(field_22793, "\u25A1", x + 45, y + 51, checked ? 0x668D7F6B : 0xff8D7F6B, false);
				if (checked)
					graphics.method_51433(field_22793, "\u2714", x + 45, y + 50, 0x31B25D, false);
			}

			List<class_5481> split = field_22793.method_1728(text, 150 - iconOffset);
			if (split.isEmpty()) {
				y += 12;
				continue;
			}

			if (!clipboardEntry.icon.method_7960())
				graphics.method_51427(clipboardEntry.icon, x + 54, y + 50);

			for (class_5481 sequence : split) {
				if (i != editingIndex)
					graphics.method_51430(field_22793, sequence, x + 58 + iconOffset, y + 50,
						checked ? isAddress ? 0x668D7F6B : 0x31B25D : 0x311A00, false);
				y += 9;
			}
			y += 3;
		}

		if (editingIndex == -1)
			return;

		method_25395(null);
		DisplayCache cache = getDisplayCache();

		for (LineInfo line : cache.lines)
			graphics.method_51439(field_22793, line.asComponent, line.x, line.y, 0x311A00, false);

		renderHighlight(cache.selection);
		renderCursor(graphics, cache.cursor, cache.cursorAtEnd);
	}

	@Override
	public void method_25432() {
		pages.forEach(list -> list.removeIf(ce -> ce.text.getString()
			.isBlank()));
		pages.removeIf(List::isEmpty);

		for (int i = 0; i < pages.size(); i++)
			if (pages.get(i) == currentEntries) {
				item.method_57379(AllDataComponents.CLIPBOARD_PREVIOUSLY_OPENED_PAGE, i);
				if (i == 0)
					item.method_57381(AllDataComponents.CLIPBOARD_PREVIOUSLY_OPENED_PAGE);
			}

		send();

		super.method_25432();
	}

	private void sendIfEditingBlock() {
		class_634 handler = field_22787.field_1724.field_3944;
		if (handler.method_2880()
			.size() > 1 && targetedBlock != null)
			send();
	}

	private void send() {
		ClipboardEntry.saveAll(pages, item);
		ClipboardOverrides.switchTo(ClipboardType.WRITTEN, item);

		if (pages.isEmpty()) {
			item.method_57381(AllDataComponents.CLIPBOARD_PAGES);
			item.method_57381(AllDataComponents.CLIPBOARD_PREVIOUSLY_OPENED_PAGE);
			item.method_57381(AllDataComponents.CLIPBOARD_READ_ONLY);
			item.method_57381(AllDataComponents.CLIPBOARD_TYPE);
			item.method_57381(AllDataComponents.CLIPBOARD_COPIED_VALUES);
		}

		CatnipServices.NETWORK.sendToServer(new ClipboardEditPacket(targetSlot, item.method_57380(), targetedBlock));
	}

	@Override
	public boolean method_25421() {
		return false;
	}

	@Override
	public boolean method_25401(double pMouseX, double pMouseY, double pScrollX, double pScrollY) {
		changePage(pScrollY < 0);
		return true;
	}

	@Override
	public boolean method_25404(int pKeyCode, int pScanCode, int pModifiers) {
		if (pKeyCode == 266) {
			backward.method_25306();
			return true;
		}
		if (pKeyCode == 267) {
			forward.method_25306();
			return true;
		}
		if (editingIndex != -1 && pKeyCode != 256) {
			keyPressedWhileEditing(pKeyCode, pScanCode, pModifiers);
			clearDisplayCache();
			return true;
		}
		if (super.method_25404(pKeyCode, pScanCode, pModifiers))
			return true;
		return true;
	}

	@Override
	public boolean method_25400(char pCodePoint, int pModifiers) {
		if (super.method_25400(pCodePoint, pModifiers))
			return true;
		if (!class_3544.method_57175(pCodePoint))
			return false;
		if (editingIndex == -1)
			return false;
		editContext.method_16197(Character.toString(pCodePoint));
		clearDisplayCache();
		return true;
	}

	private boolean keyPressedWhileEditing(int pKeyCode, int pScanCode, int pModifiers) {
		if (class_437.method_25439(pKeyCode)) {
			editContext.method_27563();
			return true;
		} else if (class_437.method_25438(pKeyCode)) {
			editContext.method_27559();
			return true;
		} else if (class_437.method_25437(pKeyCode)) {
			editContext.method_27554();
			return true;
		} else if (class_437.method_25436(pKeyCode)) {
			editContext.method_27547();
			return true;
		} else {
			switch (pKeyCode) {
			case 257:
			case 335:
				if (method_25442()) {
					editContext.method_16197("\n");
					return true;
				} else if (!method_25441()) {
					if (currentEntries.size() <= editingIndex + 1
						|| !currentEntries.get(editingIndex + 1).text.getString()
							.isEmpty())
                        currentEntries.add(editingIndex + 1, new ClipboardEntry(false, class_2561.method_43473()));
					editingIndex += 1;
					editContext.method_16204();
					if (validateTextForEntry(" "))
						return true;
					currentEntries.remove(editingIndex);
					editingIndex -= 1;
					editContext.method_16204();
					return true;
				}
				editingIndex = -1;
				return true;
			case 259:
				if (currentEntries.get(editingIndex).text.getString()
					.isEmpty() && currentEntries.size() > 1) {
					currentEntries.remove(editingIndex);
					editingIndex = Math.max(0, editingIndex - 1);
					editContext.method_16204();
					return true;
				} else if (method_25441()) {
					int prevPos = editContext.method_16201();
					editContext.method_35728(-1);
					if (prevPos != editContext.method_16201())
						editContext.method_27564(prevPos - editContext.method_16201());
					return true;
				}
				editContext.method_27564(-1);
				return true;
			case 261:
				if (method_25441()) {
					int prevPos = editContext.method_16201();
					editContext.method_35728(1);
					if (prevPos != editContext.method_16201())
						editContext.method_27564(prevPos - editContext.method_16201());
					return true;
				}
				editContext.method_27564(1);
				return true;
			case 262:
				if (method_25441()) {
					editContext.method_27555(1, class_437.method_25442());
					return true;
				}
				editContext.method_27549(1, class_437.method_25442());
				return true;
			case 263:
				if (method_25441()) {
					editContext.method_27555(-1, class_437.method_25442());
					return true;
				}
				editContext.method_27549(-1, class_437.method_25442());
				return true;
			case 264:
				keyDown();
				return true;
			case 265:
				keyUp();
				return true;
			case 268:
				keyHome();
				return true;
			case 269:
				keyEnd();
				return true;
			default:
				return false;
			}
		}
	}

	private void keyUp() {
		changeLine(-1);
	}

	private void keyDown() {
		changeLine(1);
	}

	private void changeLine(int pYChange) {
		int i = editContext.method_16201();
		int j = getDisplayCache().changeLine(i, pYChange);
		editContext.method_27560(j, class_437.method_25442());
	}

	private void keyHome() {
		int i = editContext.method_16201();
		int j = getDisplayCache().findLineStart(i);
		editContext.method_27560(j, class_437.method_25442());
	}

	private void keyEnd() {
		DisplayCache cache = getDisplayCache();
		int i = editContext.method_16201();
		int j = cache.findLineEnd(i);
		editContext.method_27560(j, class_437.method_25442());
	}

	private void renderCursor(class_332 graphics, Pos2i pCursorPos, boolean pIsEndOfText) {
		if (frameTick / 6 % 2 != 0)
			return;
		pCursorPos = convertLocalToScreen(pCursorPos);
		if (!pIsEndOfText) {
			graphics.method_25294(pCursorPos.x, pCursorPos.y - 1, pCursorPos.x + 1, pCursorPos.y + 9, -16777216);
		} else {
			graphics.method_51433(field_22793, "_", pCursorPos.x, pCursorPos.y, 0, false);
		}
	}

	private void renderHighlight(class_768[] pSelected) {
		class_289 tesselator = class_289.method_1348();
		class_287 bufferbuilder = tesselator.method_60827(class_293.class_5596.field_27382, class_290.field_1592);
		RenderSystem.setShader(class_757::method_34539);
		RenderSystem.setShaderColor(0.0F, 0.0F, 255.0F, 255.0F);
//		RenderSystem.disableTexture();
		RenderSystem.enableColorLogicOp();
		RenderSystem.logicOp(GlStateManager.class_1030.field_5110);

		for (class_768 rect2i : pSelected) {
			int i = rect2i.method_3321();
			int j = rect2i.method_3322();
			int k = i + rect2i.method_3319();
			int l = j + rect2i.method_3320();
			bufferbuilder.method_22912(i, l, 0);
			bufferbuilder.method_22912(k, l, 0);
			bufferbuilder.method_22912(k, j, 0);
			bufferbuilder.method_22912(i, j, 0);
		}

		@Nullable class_9801 meshData = bufferbuilder.method_60794();
		if (meshData != null)
			class_286.method_43433(meshData);
		RenderSystem.disableColorLogicOp();
//		RenderSystem.enableTexture();
	}

	private Pos2i convertScreenToLocal(Pos2i pScreenPos) {
		return new Pos2i(pScreenPos.x - (field_22789 - 192) / 2 - 36 + 10,
			pScreenPos.y - 32 - 24 - yOffsetOfEditingEntry() - guiTop + 14);
	}

	private Pos2i convertLocalToScreen(Pos2i pLocalScreenPos) {
		return new Pos2i(pLocalScreenPos.x + (field_22789 - 192) / 2 + 36 - 10,
			pLocalScreenPos.y + 32 + 24 + yOffsetOfEditingEntry() + guiTop - 14);
	}

	public boolean method_25402(double pMouseX, double pMouseY, int pButton) {
		if (super.method_25402(pMouseX, pMouseY, pButton))
			return true;
		if (pButton != 0)
			return true;

		if (hoveredEntry != -1) {
			if (hoveredCheck) {
				editingIndex = -1;
				if (hoveredEntry < currentEntries.size()) {
					currentEntries.get(hoveredEntry).checked ^= true;
					if (currentEntries.get(hoveredEntry).checked == true)
						class_310.method_1551()
							.method_1483()
							.method_4873(class_1109.method_4758(AllSoundEvents.CLIPBOARD_CHECKMARK.getMainEvent(),
								0.95f + (float) Math.random() * 0.05f));
					else
						class_310.method_1551()
							.method_1483()
							.method_4873(class_1109.method_4758(AllSoundEvents.CLIPBOARD_ERASE.getMainEvent(),
								0.90f + (float) Math.random() * 0.2f));
				}
				sendIfEditingBlock();
				return true;
			}

			if (hoveredEntry != editingIndex && !readonly) {
				editingIndex = hoveredEntry;
				if (hoveredEntry >= currentEntries.size()) {
                    currentEntries.add(new ClipboardEntry(false, class_2561.method_43473()));
					if (!validateTextForEntry(" ")) {
						currentEntries.remove(hoveredEntry);
						editingIndex = -1;
						return true;
					}
				}
				clearDisplayCacheAfterChange();
			}
		}

		if (editingIndex == -1)
			return false;

		if (pMouseX < guiLeft + 50 || pMouseX > guiLeft + 220 || pMouseY < guiTop + 30 || pMouseY > guiTop + 230) {
			method_25395(null);
			clearDisplayCache();
			editingIndex = -1;
			return false;
		}

		long i = class_156.method_658();
		DisplayCache cache = getDisplayCache();
		int j = cache.getIndexAtPosition(field_22793, convertScreenToLocal(new Pos2i((int) pMouseX, (int) pMouseY)));
		if (j >= 0) {
			if (j == lastIndex && i - lastClickTime < 250L) {
				if (!editContext.method_27568()) {
					selectWord(j);
				} else {
					editContext.method_27563();
				}
			} else {
				editContext.method_27560(j, class_437.method_25442());
			}

			clearDisplayCache();
		}

		lastIndex = j;
		lastClickTime = i;
		return true;
	}

	private void selectWord(int pIndex) {
		String s = getCurrentEntryText();
		editContext.method_27548(class_5225.method_27483(s, -1, pIndex, false),
			class_5225.method_27483(s, 1, pIndex, false));
	}

	public boolean method_25403(double pMouseX, double pMouseY, int pButton, double pDragX, double pDragY) {
		if (super.method_25403(pMouseX, pMouseY, pButton, pDragX, pDragY))
			return true;
		if (pButton != 0)
			return true;
		if (editingIndex == -1)
			return false;

		DisplayCache cache = getDisplayCache();
		int i = cache.getIndexAtPosition(field_22793, convertScreenToLocal(new Pos2i((int) pMouseX, (int) pMouseY)));
		editContext.method_27560(i, true);
		clearDisplayCache();
		return true;
	}

	private DisplayCache getDisplayCache() {
		if (displayCache == null)
			displayCache = rebuildDisplayCache();
		return displayCache;
	}

	private void clearDisplayCache() {
		displayCache = null;
	}

	private void clearDisplayCacheAfterChange() {
		editContext.method_16204();
		clearDisplayCache();
	}

	private DisplayCache rebuildDisplayCache() {
		String current = getCurrentEntryText();
		boolean address = current.startsWith("#") && !current.substring(1)
			.isBlank();
		int offset = 0;

		if (address) {
			String stripped = current.substring(1)
				.stripLeading();
			offset = current.length() - stripped.length();
			current = stripped;
		}

		if (current.isEmpty())
			return DisplayCache.EMPTY;

		String s = current;
		int i = editContext.method_16201();
		int j = editContext.method_16203();
		i = class_3532.method_15340(i - offset, 0, s.length());
		j = class_3532.method_15340(j - offset, 0, s.length());

		IntList intlist = new IntArrayList();
		List<LineInfo> list = Lists.newArrayList();
		MutableInt mutableint = new MutableInt();
		MutableBoolean mutableboolean = new MutableBoolean();
		class_5225 stringsplitter = field_22793.method_27527();
		stringsplitter.method_27485(s, 150, class_2583.field_24360, true, (p_98132_, p_98133_, p_98134_) -> {
			int k3 = mutableint.getAndIncrement();
			String s2 = s.substring(p_98133_, p_98134_);
			mutableboolean.setValue(s2.endsWith("\n"));
			String s3 = StringUtils.stripEnd(s2, " \n");
			int l3 = k3 * 9;
			Pos2i pos1 = convertLocalToScreen(new Pos2i(0, l3));
			intlist.add(p_98133_);
			list.add(new LineInfo(p_98132_, s3, pos1.x, pos1.y));
		});

		int[] aint = intlist.toIntArray();
		boolean flag = i == s.length();
		Pos2i pos;
		if (flag && mutableboolean.isTrue()) {
			pos = new Pos2i(0, list.size() * 9);
		} else {
			int k = findLineFromPos(aint, i);
			int l = field_22793.method_1727(s.substring(aint[k], i));
			pos = new Pos2i(l, k * 9);
		}

		List<class_768> list1 = Lists.newArrayList();
		if (i != j) {
			int l2 = Math.min(i, j);
			int i1 = Math.max(i, j);
			int j1 = findLineFromPos(aint, l2);
			int k1 = findLineFromPos(aint, i1);
			if (j1 == k1) {
				int l1 = j1 * 9;
				int i2 = aint[j1];
				list1.add(createPartialLineSelection(s, stringsplitter, l2, i1, l1, i2));
			} else {
				int i3 = j1 + 1 > aint.length ? s.length() : aint[j1 + 1];
				list1.add(createPartialLineSelection(s, stringsplitter, l2, i3, j1 * 9, aint[j1]));

				for (int j3 = j1 + 1; j3 < k1; ++j3) {
					int j2 = j3 * 9;
					String s1 = s.substring(aint[j3], aint[j3 + 1]);
					int k2 = (int) stringsplitter.method_27482(s1);
					list1.add(createSelection(new Pos2i(0, j2), new Pos2i(k2, j2 + 9)));
				}

				list1.add(createPartialLineSelection(s, stringsplitter, aint[k1], i1, k1 * 9, aint[k1]));
			}
		}

		return new DisplayCache(s, pos, flag, aint, list.toArray(new LineInfo[0]), list1.toArray(new class_768[0]));
	}

	static int findLineFromPos(int[] pLineStarts, int pFind) {
		int i = Arrays.binarySearch(pLineStarts, pFind);
		return i < 0 ? -(i + 2) : i;
	}

	private class_768 createPartialLineSelection(String pInput, class_5225 pSplitter, int p_98122_, int p_98123_,
		int p_98124_, int p_98125_) {
		String s = pInput.substring(p_98125_, p_98122_);
		String s1 = pInput.substring(p_98125_, p_98123_);
		Pos2i firstPos = new Pos2i((int) pSplitter.method_27482(s), p_98124_);
		Pos2i secondPos = new Pos2i((int) pSplitter.method_27482(s1), p_98124_ + 9);
		return createSelection(firstPos, secondPos);
	}

	private class_768 createSelection(Pos2i pCorner1, Pos2i pCorner2) {
		Pos2i firstPos = convertLocalToScreen(pCorner1);
		Pos2i secondPos = convertLocalToScreen(pCorner2);
		int i = Math.min(firstPos.x, secondPos.x);
		int j = Math.max(firstPos.x, secondPos.x);
		int k = Math.min(firstPos.y, secondPos.y);
		int l = Math.max(firstPos.y, secondPos.y);
		return new class_768(i, k, j - i, l - k);
	}

	@Environment(EnvType.CLIENT)
	static class DisplayCache {
		static final DisplayCache EMPTY = new DisplayCache("", new Pos2i(0, 0), true, new int[] { 0 },
			new LineInfo[] { new LineInfo(class_2583.field_24360, "", 0, 0) }, new class_768[0]);
		private final String fullText;
		final Pos2i cursor;
		final boolean cursorAtEnd;
		private final int[] lineStarts;
		final LineInfo[] lines;
		final class_768[] selection;

		public DisplayCache(String pFullText, Pos2i pCursor, boolean pCursorAtEnd, int[] pLineStarts, LineInfo[] pLines,
			class_768[] pSelection) {
			fullText = pFullText;
			cursor = pCursor;
			cursorAtEnd = pCursorAtEnd;
			lineStarts = pLineStarts;
			lines = pLines;
			selection = pSelection;
		}

		public int getIndexAtPosition(class_327 pFont, Pos2i pCursorPosition) {
			int i = pCursorPosition.y / 9;
			if (i < 0)
				return 0;
			if (i >= lines.length)
				return fullText.length();
			LineInfo line = lines[i];
			return lineStarts[i] + pFont.method_27527()
				.method_27484(line.contents, pCursorPosition.x, line.style);
		}

		public int changeLine(int pXChange, int pYChange) {
			int i = findLineFromPos(lineStarts, pXChange);
			int j = i + pYChange;
			int k;
			if (0 <= j && j < lineStarts.length) {
				int l = pXChange - lineStarts[i];
				int i1 = lines[j].contents.length();
				k = lineStarts[j] + Math.min(l, i1);
			} else {
				k = pXChange;
			}

			return k;
		}

		public int findLineStart(int pLine) {
			int i = findLineFromPos(lineStarts, pLine);
			return lineStarts[i];
		}

		public int findLineEnd(int pLine) {
			int i = findLineFromPos(lineStarts, pLine);
			return lineStarts[i] + lines[i].contents.length();
		}
	}

	@Environment(EnvType.CLIENT)
	static class LineInfo {
		final class_2583 style;
		final String contents;
		final class_2561 asComponent;
		final int x;
		final int y;

		public LineInfo(class_2583 pStyle, String pContents, int pX, int pY) {
			style = pStyle;
			contents = pContents;
			x = pX;
			y = pY;
			asComponent = class_2561.method_43470(pContents)
				.method_10862(pStyle);
		}
	}

	@Environment(EnvType.CLIENT)
	static class Pos2i {
		public final int x;
		public final int y;

		Pos2i(int pX, int pY) {
			x = pX;
			y = pY;
		}
	}

}
