package com.simibubi.create.content.decoration.copycat;

import java.util.Objects;
import java.util.function.Supplier;

import javax.annotation.Nullable;

import com.simibubi.create.AllBlocks;

import net.createmod.catnip.data.Iterate;

import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.MaterialFinder;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.MutableQuadView;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;

import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext.QuadTransform;
import net.fabricmc.fabric.api.rendering.data.v1.RenderAttachedBlockView;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.BlendMode;
import net.fabricmc.fabric.api.renderer.v1.material.MaterialFinder;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.MutableQuadView;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext.QuadTransform;
import net.fabricmc.fabric.api.rendering.data.v1.RenderAttachedBlockView;

import io.github.fabricators_of_create.porting_lib.models.CustomParticleIconModel;

public abstract class CopycatModel extends ForwardingBakedModel implements CustomParticleIconModel {

	public CopycatModel(class_1087 originalModel) {
		wrapped = originalModel;
	}

	private void gatherOcclusionData(class_1920 world, class_2338 pos, class_2680 state, class_2680 material,
		OcclusionData occlusionData, CopycatBlock copycatBlock) {
		class_2339 mutablePos = new class_2339();
		for (class_2350 face : Iterate.directions) {
			if (!copycatBlock.canFaceBeOccluded(state, face))
				continue;
			class_2339 neighbourPos = mutablePos.method_25505(pos, face);
			if (!class_2248.method_9607(material, world, pos, face, neighbourPos))
				occlusionData.occlude(face);
		}
	}

	@Override
	public boolean isVanillaAdapter() {
		return false;
	}

	@Override
	public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
		class_2680 material;
		if (blockView instanceof RenderAttachedBlockView attachmentView
				&& attachmentView.getBlockEntityRenderAttachment(pos) instanceof class_2680 material1) {
			material = material1;
		} else {
			material = AllBlocks.COPYCAT_BASE.getDefaultState();
		}

		OcclusionData occlusionData = new OcclusionData();
		if (state.method_26204() instanceof CopycatBlock copycatBlock) {
			gatherOcclusionData(blockView, pos, state, material, occlusionData, copycatBlock);
		}

		CullFaceRemovalData cullFaceRemovalData = new CullFaceRemovalData();
		if (state.method_26204() instanceof CopycatBlock copycatBlock) {
			for (class_2350 cullFace : Iterate.directions) {
				if (copycatBlock.shouldFaceAlwaysRender(state, cullFace)) {
					cullFaceRemovalData.remove(cullFace);
				}
			}
		}

		// fabric: If it is the default state do not push transformations, will cause issues with GhostBlockRenderer
		boolean shouldTransform = material != AllBlocks.COPYCAT_BASE.getDefaultState();

		// fabric: need to change the default render material
		if (shouldTransform)
			context.pushTransform(MaterialFixer.create(material));

		emitBlockQuadsInner(blockView, state, pos, randomSupplier, context, material, cullFaceRemovalData, occlusionData);

		// fabric: pop the material changer transform
		if (shouldTransform)
			context.popTransform();
	}

	protected abstract void emitBlockQuadsInner(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context, class_2680 material, CullFaceRemovalData cullFaceRemovalData, OcclusionData occlusionData);

	@Override
	public class_1058 getParticleIcon(Object data) {
		if (data instanceof class_2680 state) {
			class_2680 material = getMaterial(state);

			return getIcon(getModelOf(material), null);
		}

		return CustomParticleIconModel.super.getParticleIcon(data);
	}

	public static class_1058 getIcon(class_1087 model, @Nullable Object data) {
		if (model instanceof CustomParticleIconModel particleIconModel)
			return particleIconModel.getParticleIcon(data);
		return model.method_4711();
	}

	@Nullable
	public static class_2680 getMaterial(class_2680 material) {
		return material == null ? AllBlocks.COPYCAT_BASE.getDefaultState() : material;
	}

	public static class_1087 getModelOf(class_2680 state) {
		return class_310.method_1551()
			.method_1541()
			.method_3349(state);
	}

	protected static class OcclusionData {
		private final boolean[] occluded;

		public OcclusionData() {
			occluded = new boolean[6];
		}

		public void occlude(class_2350 face) {
			occluded[face.method_10146()] = true;
		}

		public boolean isOccluded(class_2350 face) {
			return face == null ? false : occluded[face.method_10146()];
		}
	}

	protected static class CullFaceRemovalData {
		private final boolean[] shouldRemove;

		public CullFaceRemovalData() {
			shouldRemove = new boolean[6];
		}

		public void remove(class_2350 face) {
			shouldRemove[face.method_10146()] = true;
		}

		public boolean shouldRemove(class_2350 face) {
			return face == null ? false : shouldRemove[face.method_10146()];
		}
	}

	private record MaterialFixer(RenderMaterial materialDefault) implements QuadTransform {
		@Override
		public boolean transform(MutableQuadView quad) {
			if (quad.material().blendMode() == BlendMode.DEFAULT) {
				// default needs to be changed from the Copycat's default (cutout) to the wrapped material's default.
				quad.material(materialDefault);
			}
			return true;
		}

		public static MaterialFixer create(class_2680 materialState) {
			class_1921 type = class_4696.method_23679(materialState);
			BlendMode blendMode = BlendMode.fromRenderLayer(type);
			MaterialFinder finder = Objects.requireNonNull(RendererAccess.INSTANCE.getRenderer()).materialFinder();
			RenderMaterial renderMaterial = finder.blendMode(0, blendMode).find();
			return new MaterialFixer(renderMaterial);
		}
	}
}
