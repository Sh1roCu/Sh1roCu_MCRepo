package com.simibubi.create.content.decoration;

import com.simibubi.create.AllShapes;
import com.simibubi.create.content.equipment.wrench.IWrenchable;
import io.github.fabricators_of_create.porting_lib.block.CustomScaffoldingBlock;
import net.minecraft.class_1309;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_3736;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

public class MetalScaffoldingBlock extends class_3736 implements IWrenchable, CustomScaffoldingBlock {

	public MetalScaffoldingBlock(class_2251 pProperties) {
		super(pProperties);
	}

	@Override
	public void method_9588(class_2680 pState, class_3218 pLevel, class_2338 pPos, class_5819 pRand) {}

	@Override
	public boolean method_9558(class_2680 pState, class_4538 pLevel, class_2338 pPos) {
		return true;
	}

	@Override
	public class_265 method_9549(class_2680 pState, class_1922 pLevel, class_2338 pPos,
		class_3726 pContext) {
		if (pState.method_11654(field_16547))
			return AllShapes.SCAFFOLD_HALF;
		return super.method_9549(pState, pLevel, pPos, pContext);
	}

	@Override
	public boolean isScaffolding(class_2680 state, class_4538 level, class_2338 pos, class_1309 entity) {
		return true;
	}

	@Override
	public class_265 method_9530(class_2680 pState, class_1922 pLevel, class_2338 pPos, class_3726 pContext) {
		if (pState.method_11654(field_16547))
			return AllShapes.SCAFFOLD_HALF;
		if (!pContext.method_17785(pState.method_26204()
			.method_8389()))
			return AllShapes.SCAFFOLD_FULL;
		return class_259.method_1077();
	}

	@Override
	public class_265 method_9584(class_2680 pState, class_1922 pLevel, class_2338 pPos) {
		return class_259.method_1077();
	}

	@Override
	public class_2680 method_9559(class_2680 pState, class_2350 pFacing, class_2680 pFacingState, class_1936 pLevel,
		class_2338 pCurrentPos, class_2338 pFacingPos) {
		super.method_9559(pState, pFacing, pFacingState, pLevel, pCurrentPos, pFacingPos);
		class_2680 stateBelow = pLevel.method_8320(pCurrentPos.method_10074());
		return pFacing == class_2350.field_11033 ? pState.method_11657(field_16547,
			!stateBelow.method_27852(this) && !stateBelow.method_26206(pLevel, pCurrentPos.method_10074(), class_2350.field_11036)) : pState;
	}

	@Override
	public boolean supportsExternalFaceHiding(class_2680 state) {
		return true;
	}

	@Override
	public boolean hidesNeighborFace(class_1922 level, class_2338 pos, class_2680 state, class_2680 neighborState,
		class_2350 dir) {
		if (!(neighborState.method_26204() instanceof MetalScaffoldingBlock))
			return false;
		if (!neighborState.method_11654(field_16547) && state.method_11654(field_16547))
			return false;
		return dir.method_10166() != class_2351.field_11052;
	}

}
