package com.simibubi.create.content.contraptions.behaviour;

import java.util.function.Supplier;
import java.util.function.UnaryOperator;

import org.jetbrains.annotations.Nullable;

import com.google.common.base.Suppliers;
import com.simibubi.create.api.contraption.storage.fluid.MountedFluidStorage;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorage;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.logistics.filter.FilterItemStack;

import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_3499.class_3501;

public class MovementContext {

	public class_243 position;
	public class_243 motion;
	public class_243 relativeMotion;
	public UnaryOperator<class_243> rotation;

	public class_1937 world;
	public class_2680 state;
	public class_2338 localPos;
	public class_2487 blockEntityData;

	public boolean stall;
	public boolean disabled;
	public boolean firstMovement;
	public class_2487 data;
	public Contraption contraption;
	public Object temporaryData;

	private FilterItemStack filter;

	private final Supplier<MountedItemStorage> itemStorage;
	private final Supplier<MountedFluidStorage> fluidStorage;

	public MovementContext(class_1937 world, class_3501 info, Contraption contraption) {
		this.world = world;
		this.state = info.comp_1342();
		this.blockEntityData = info.comp_1343();
		this.contraption = contraption;
		localPos = info.comp_1341();

		disabled = false;
		firstMovement = true;
		motion = class_243.field_1353;
		relativeMotion = class_243.field_1353;
		rotation = v -> v;
		position = null;
		data = new class_2487();
		stall = false;
		filter = null;
		this.itemStorage = Suppliers.memoize(() -> contraption.getStorage().getAllItemStorages().get(this.localPos));
		this.fluidStorage = Suppliers.memoize(() -> contraption.getStorage().getFluids().storages.get(this.localPos));
	}

	public float getAnimationSpeed() {
		int modifier = 1000;
		double length = -motion.method_1033();
		if (disabled)
			return 0;
		if (world.field_9236 && contraption.stalled)
			return 700;
		if (Math.abs(length) < 1 / 512f)
			return 0;
		return (((int) (length * modifier + 100 * Math.signum(length))) / 100) * 100;
	}

	public static MovementContext readNBT(class_1937 world, class_3501 info, class_2487 nbt, Contraption contraption) {
		MovementContext context = new MovementContext(world, info, contraption);
		context.motion = VecHelper.readNBT(nbt.method_10554("Motion", class_2520.field_33256));
		context.relativeMotion = VecHelper.readNBT(nbt.method_10554("RelativeMotion", class_2520.field_33256));
		if (nbt.method_10545("Position"))
			context.position = VecHelper.readNBT(nbt.method_10554("Position", class_2520.field_33256));
		context.stall = nbt.method_10577("Stall");
		context.firstMovement = nbt.method_10577("FirstMovement");
		context.data = nbt.method_10562("Data");
		return context;
	}

	public class_2487 writeToNBT(class_2487 nbt) {
		nbt.method_10566("Motion", VecHelper.writeNBT(motion));
		nbt.method_10566("RelativeMotion", VecHelper.writeNBT(relativeMotion));
		if (position != null)
			nbt.method_10566("Position", VecHelper.writeNBT(position));
		nbt.method_10556("Stall", stall);
		nbt.method_10556("FirstMovement", firstMovement);
		nbt.method_10566("Data", data.method_10553());
		return nbt;
	}

	public FilterItemStack getFilterFromBE() {
		if (filter != null)
			return filter;
		return filter = FilterItemStack.of(world.method_30349(), blockEntityData.method_10562("Filter"));
	}

	@Nullable
	public MountedItemStorage getItemStorage() {
		return this.itemStorage.get();
	}

	@Nullable
	public MountedFluidStorage getFluidStorage() {
		return this.fluidStorage.get();
	}
}
