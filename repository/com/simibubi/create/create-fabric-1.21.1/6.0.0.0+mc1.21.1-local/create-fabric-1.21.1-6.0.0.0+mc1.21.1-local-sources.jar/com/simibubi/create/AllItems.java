package com.simibubi.create;

import static com.simibubi.create.AllTags.AllItemTags.CREATE_INGOTS;
import static com.simibubi.create.AllTags.AllItemTags.CRUSHED_RAW_MATERIALS;
import static com.simibubi.create.AllTags.AllItemTags.PLATES;
import static com.simibubi.create.AllTags.commonItemTag;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.ALUMINUM;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.LEAD;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.NICKEL;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.OSMIUM;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.PLATINUM;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.QUICKSILVER;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.SILVER;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.TIN;
import static com.simibubi.create.foundation.data.recipe.CompatMetals.URANIUM;

import com.simibubi.create.AllTags.AllItemTags;
import com.simibubi.create.content.contraptions.glue.SuperGlueItem;
import com.simibubi.create.content.contraptions.minecart.MinecartCouplingItem;
import com.simibubi.create.content.contraptions.mounted.MinecartContraptionItem;
import com.simibubi.create.content.equipment.BuildersTeaItem;
import com.simibubi.create.content.equipment.TreeFertilizerItem;
import com.simibubi.create.content.equipment.armor.AllArmorMaterials;
import com.simibubi.create.content.equipment.armor.BacktankItem;
import com.simibubi.create.content.equipment.armor.BacktankItem.BacktankBlockItem;
import com.simibubi.create.content.equipment.armor.BaseArmorItem;
import com.simibubi.create.content.equipment.armor.CardboardArmorItem;
import com.simibubi.create.content.equipment.armor.DivingBootsItem;
import com.simibubi.create.content.equipment.armor.DivingHelmetItem;
import com.simibubi.create.content.equipment.armor.TrimmableArmorModelGenerator;
import com.simibubi.create.content.equipment.blueprint.BlueprintItem;
import com.simibubi.create.content.equipment.extendoGrip.ExtendoGripItem;
import com.simibubi.create.content.equipment.extendoGrip.ExtendoGripItemRenderer;
import com.simibubi.create.content.equipment.goggles.GogglesItem;
import com.simibubi.create.content.equipment.goggles.GogglesModel;
import com.simibubi.create.content.equipment.potatoCannon.PotatoCannonItem;
import com.simibubi.create.content.equipment.potatoCannon.PotatoCannonItemRenderer;
import com.simibubi.create.content.equipment.sandPaper.SandPaperItem;
import com.simibubi.create.content.equipment.sandPaper.SandPaperItemRenderer;
import com.simibubi.create.content.equipment.symmetryWand.SymmetryWandItem;
import com.simibubi.create.content.equipment.symmetryWand.SymmetryWandItemRenderer;
import com.simibubi.create.content.equipment.tool.AllToolMaterials;
import com.simibubi.create.content.equipment.tool.CardboardSwordItem;
import com.simibubi.create.content.equipment.tool.CardboardSwordItemRenderer;
import com.simibubi.create.content.equipment.wrench.WrenchItem;
import com.simibubi.create.content.equipment.wrench.WrenchItemRenderer;
import com.simibubi.create.content.equipment.zapper.terrainzapper.WorldshaperItem;
import com.simibubi.create.content.equipment.zapper.terrainzapper.WorldshaperItemRenderer;
import com.simibubi.create.content.kinetics.belt.item.BeltConnectorItem;
import com.simibubi.create.content.kinetics.gearbox.VerticalGearboxItem;
import com.simibubi.create.content.legacy.ChromaticCompoundColor;
import com.simibubi.create.content.legacy.ChromaticCompoundItem;
import com.simibubi.create.content.legacy.RefinedRadianceItem;
import com.simibubi.create.content.legacy.ShadowSteelItem;
import com.simibubi.create.content.logistics.box.PackageItem;
import com.simibubi.create.content.logistics.box.PackageStyles;
import com.simibubi.create.content.logistics.box.PackageStyles.PackageStyle;
import com.simibubi.create.content.logistics.filter.FilterItem;
import com.simibubi.create.content.logistics.tableCloth.ShoppingListItem;
import com.simibubi.create.content.materials.ExperienceNuggetItem;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlockItem;
import com.simibubi.create.content.processing.sequenced.SequencedAssemblyItem;
import com.simibubi.create.content.redstone.link.controller.LinkedControllerItem;
import com.simibubi.create.content.redstone.link.controller.LinkedControllerItemRenderer;
import com.simibubi.create.content.schematics.SchematicAndQuillItem;
import com.simibubi.create.content.schematics.SchematicItem;
import com.simibubi.create.content.trains.schedule.ScheduleItem;
import com.simibubi.create.foundation.data.AssetLookup;
import com.simibubi.create.foundation.data.BuilderTransformers;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.simibubi.create.foundation.data.recipe.CompatMetals;
import com.simibubi.create.foundation.item.CombustibleItem;
import com.simibubi.create.foundation.item.ItemDescription;
import com.simibubi.create.foundation.item.TagDependentIngredientItem;
import com.simibubi.create.infrastructure.fabric.HelmetOverlay;
import com.tterrag.registrate.builders.ItemBuilder;
import com.tterrag.registrate.providers.ProviderType;
import com.tterrag.registrate.util.entry.ItemEntry;
import com.tterrag.registrate.util.nullness.NonNullBiConsumer;

import net.createmod.catnip.platform.CatnipServices;
import net.neoforged.neoforge.common.Tags;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1738;
import net.minecraft.class_1738.class_8051;
import net.minecraft.class_1740;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_1829;
import net.minecraft.class_3489;
import net.minecraft.class_4174;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class AllItems {
	private static final CreateRegistrate REGISTRATE = Create.registrate();

	static {
		REGISTRATE.setCreativeTab(AllCreativeModeTabs.BASE_CREATIVE_TAB.key());
	}

	public static final ItemEntry<class_1792>
		WHEAT_FLOUR = taggedIngredient("wheat_flour", commonItemTag("flours/wheat"), commonItemTag("flours")),
		DOUGH = taggedIngredient("dough", commonItemTag("doughs"), commonItemTag("doughs/wheat")),
		CINDER_FLOUR = ingredient("cinder_flour"), ROSE_QUARTZ = ingredient("rose_quartz"),
		POLISHED_ROSE_QUARTZ = ingredient("polished_rose_quartz"), POWDERED_OBSIDIAN = ingredient("powdered_obsidian"),
		STURDY_SHEET = taggedIngredient("sturdy_sheet", commonItemTag("obsidian_plates"), PLATES.tag),
		PROPELLER = ingredient("propeller"), WHISK = ingredient("whisk"), BRASS_HAND = ingredient("brass_hand"),
		CRAFTER_SLOT_COVER = ingredient("crafter_slot_cover"), ELECTRON_TUBE = ingredient("electron_tube"),
		TRANSMITTER = ingredient("transmitter"), PULP = ingredient("pulp");

	public static final ItemEntry<CombustibleItem> CARDBOARD = REGISTRATE.item("cardboard", CombustibleItem::new)
		.tag(commonItemTag("plates/cardboard"))
		.onRegister(i -> i.setBurnTime(1000))
		.register();

	public static final ItemEntry<SequencedAssemblyItem>

		INCOMPLETE_PRECISION_MECHANISM = sequencedIngredient("incomplete_precision_mechanism"),
		INCOMPLETE_REINFORCED_SHEET = sequencedIngredient("unprocessed_obsidian_sheet"),
		INCOMPLETE_TRACK = sequencedIngredient("incomplete_track");

	public static final ItemEntry<class_1792> PRECISION_MECHANISM = ingredient("precision_mechanism");

	public static final ItemEntry<class_1792> BLAZE_CAKE_BASE = REGISTRATE.item("blaze_cake_base", class_1792::new)
		.tag(AllItemTags.UPRIGHT_ON_BELT.tag)
		.register();

	public static final ItemEntry<CombustibleItem> BLAZE_CAKE = REGISTRATE.item("blaze_cake", CombustibleItem::new)
		.tag(AllItemTags.BLAZE_BURNER_FUEL_SPECIAL.tag, AllItemTags.UPRIGHT_ON_BELT.tag)
		.onRegister(i -> i.setBurnTime(6400))
		.register();

	public static final ItemEntry<CombustibleItem> CREATIVE_BLAZE_CAKE =
		REGISTRATE.item("creative_blaze_cake", CombustibleItem::new)
			.properties(p -> p.method_7894(class_1814.field_8904))
			.tag(AllItemTags.UPRIGHT_ON_BELT.tag)
			.onRegister(i -> i.setBurnTime(Short.MAX_VALUE)) // fabric: furnaces are limited to Short values without Forge patches
			.register();

	public static final ItemEntry<class_1792> BAR_OF_CHOCOLATE = REGISTRATE.item("bar_of_chocolate", class_1792::new)
		.properties(p -> p.method_19265(new class_4174.class_4175().method_19238(6)
			.method_19237(0.3F)
			.method_19242()))
		.lang("Bar of Chocolate")
		.register();

	public static final ItemEntry<class_1792> SWEET_ROLL = REGISTRATE.item("sweet_roll", class_1792::new)
		.properties(p -> p.method_19265(new class_4174.class_4175().method_19238(6)
			.method_19237(0.8F)
			.method_19242()))
		.register();

	public static final ItemEntry<class_1792> CHOCOLATE_BERRIES = REGISTRATE.item("chocolate_glazed_berries", class_1792::new)
		.properties(p -> p.method_19265(new class_4174.class_4175().method_19238(7)
			.method_19237(0.8F)
			.method_19242()))
		.register();

	public static final ItemEntry<class_1792> HONEYED_APPLE = REGISTRATE.item("honeyed_apple", class_1792::new)
		.properties(p -> p.method_19265(new class_4174.class_4175().method_19238(8)
			.method_19237(0.8F)
			.method_19242()))
		.register();

	public static final ItemEntry<BuildersTeaItem> BUILDERS_TEA = REGISTRATE.item("builders_tea", BuildersTeaItem::new)
		.tag(AllItemTags.UPRIGHT_ON_BELT.tag)
		.properties(p -> p
			.method_7889(16)
			.method_19265(new class_4174.class_4175()
				.method_19238(1)
				.method_19237(.6F)
				.method_19240()
				.method_19239(new class_1293(class_1294.field_5917, 3 * 60 * 20, 0, false, false, false), 1F)
				.method_19242()
			)
		)
		.lang("Builder's Tea")
		.register();

	public static final ItemEntry<CardboardSwordItem> CARDBOARD_SWORD =
		REGISTRATE.item("cardboard_sword", CardboardSwordItem::new)
			.properties(p -> p.method_7889(1))
			.properties(p -> p.method_57348(class_1829.method_57394(AllToolMaterials.CARDBOARD, 3, 1)))
			.onRegister(i -> FuelRegistry.INSTANCE.add(i, 1000))
			.transform(CreateRegistrate.customRenderedItem(() -> CardboardSwordItemRenderer::new))
			.model(AssetLookup.itemModelWithPartials())
			.register();

	public static final ItemEntry<class_1792> RAW_ZINC =
		taggedIngredient("raw_zinc", commonItemTag("raw_materials/zinc"), commonItemTag("raw_materials"));

	public static final ItemEntry<class_1792> ANDESITE_ALLOY = taggedIngredient("andesite_alloy", CREATE_INGOTS.tag),
		ZINC_INGOT = taggedIngredient("zinc_ingot", commonItemTag("zinc_ingots"), CREATE_INGOTS.tag),
		BRASS_INGOT = taggedIngredient("brass_ingot", commonItemTag("brass_ingots"), CREATE_INGOTS.tag);

	public static final ItemEntry<ChromaticCompoundItem> CHROMATIC_COMPOUND =
		REGISTRATE.item("chromatic_compound", ChromaticCompoundItem::new)
			.properties(p -> p.method_7894(class_1814.field_8907))
			.model(AssetLookup.existingItemModel())
			.color(() -> ChromaticCompoundColor::new)
			.register();

	public static final ItemEntry<ShadowSteelItem> SHADOW_STEEL = REGISTRATE.item("shadow_steel", ShadowSteelItem::new)
		.properties(p -> p.method_7894(class_1814.field_8907))
		.register();

	public static final ItemEntry<RefinedRadianceItem> REFINED_RADIANCE =
		REGISTRATE.item("refined_radiance", RefinedRadianceItem::new)
			.properties(p -> p.method_7894(class_1814.field_8907))
			.register();

	public static final ItemEntry<class_1792>
		COPPER_NUGGET = taggedIngredient("copper_nugget", commonItemTag("copper_nuggets"), net.neoforged.neoforge.common.Tags.Items.NUGGETS),
		ZINC_NUGGET = taggedIngredient("zinc_nugget", commonItemTag("zinc_nuggets"), net.neoforged.neoforge.common.Tags.Items.NUGGETS),
		BRASS_NUGGET = taggedIngredient("brass_nugget", commonItemTag("brass_nuggets"), net.neoforged.neoforge.common.Tags.Items.NUGGETS);

	public static final ItemEntry<ExperienceNuggetItem> EXP_NUGGET =
		REGISTRATE.item("experience_nugget", ExperienceNuggetItem::new)
			.tag(Tags.Items.NUGGETS)
			.properties(p -> p.method_7894(class_1814.field_8907))
			.lang("Nugget of Experience")
			.register();

	public static final ItemEntry<class_1792>
		COPPER_SHEET = taggedIngredient("copper_sheet", commonItemTag("copper_plates"), PLATES.tag),
		BRASS_SHEET = taggedIngredient("brass_sheet", commonItemTag("brass_plates"), PLATES.tag),
		IRON_SHEET = taggedIngredient("iron_sheet", commonItemTag("iron_plates"), PLATES.tag),
		GOLDEN_SHEET = taggedIngredient("golden_sheet", commonItemTag("gold_plates"), PLATES.tag, class_3489.field_24481),

	CRUSHED_IRON = taggedIngredient("crushed_raw_iron", CRUSHED_RAW_MATERIALS.tag),
		CRUSHED_GOLD = taggedIngredient("crushed_raw_gold", CRUSHED_RAW_MATERIALS.tag, class_3489.field_24481),
		CRUSHED_COPPER = taggedIngredient("crushed_raw_copper", CRUSHED_RAW_MATERIALS.tag),
		CRUSHED_ZINC = taggedIngredient("crushed_raw_zinc", CRUSHED_RAW_MATERIALS.tag);

	public static final ItemEntry<TagDependentIngredientItem> CRUSHED_OSMIUM = compatCrushedOre(OSMIUM),
		CRUSHED_PLATINUM = compatCrushedOre(PLATINUM), CRUSHED_SILVER = compatCrushedOre(SILVER),
		CRUSHED_TIN = compatCrushedOre(TIN), CRUSHED_LEAD = compatCrushedOre(LEAD),
		CRUSHED_QUICKSILVER = compatCrushedOre(QUICKSILVER), CRUSHED_BAUXITE = compatCrushedOre(ALUMINUM),
		CRUSHED_URANIUM = compatCrushedOre(URANIUM), CRUSHED_NICKEL = compatCrushedOre(NICKEL);

	// Kinetics

	public static final ItemEntry<BeltConnectorItem> BELT_CONNECTOR =
		REGISTRATE.item("belt_connector", BeltConnectorItem::new)
			.lang("Mechanical Belt")
			.register();

	public static final ItemEntry<VerticalGearboxItem> VERTICAL_GEARBOX =
		REGISTRATE.item("vertical_gearbox", VerticalGearboxItem::new)
			.model(AssetLookup.customBlockItemModel("gearbox", "item_vertical"))
			.register();

	public static final ItemEntry<BlazeBurnerBlockItem> EMPTY_BLAZE_BURNER =
		REGISTRATE.item("empty_blaze_burner", BlazeBurnerBlockItem::empty)
			.model(AssetLookup.customBlockItemModel("blaze_burner", "block"))
			.register();

	public static final ItemEntry<GogglesItem> GOGGLES = REGISTRATE.item("goggles", GogglesItem::new)
		.properties(p -> p.method_7889(1))
		.properties(p -> {
			if (p instanceof FabricItemSettings fp) {
				fp.equipmentSlot(GogglesItem::getEquipmentSlot);
			}
			return p;
		})
		.onRegister(CreateRegistrate.itemModel(() -> GogglesModel::new))
		.lang("Engineer's Goggles")
		.register();

	public static final ItemEntry<SuperGlueItem> SUPER_GLUE = REGISTRATE.item("super_glue", SuperGlueItem::new)
		.properties(p -> p.method_7889(1)
			.method_7895(99))
		.register();

	public static final ItemEntry<MinecartCouplingItem> MINECART_COUPLING =
		REGISTRATE.item("minecart_coupling", MinecartCouplingItem::new)
			.register();

	public static final ItemEntry<BlueprintItem> CRAFTING_BLUEPRINT =
		REGISTRATE.item("crafting_blueprint", BlueprintItem::new)
			.register();

	// wrapped by COPPER_BACKTANK for block placement uses.
	// must be registered as of 1.18.2
	public static final ItemEntry<BacktankBlockItem> COPPER_BACKTANK_PLACEABLE = REGISTRATE
		.item("copper_backtank_placeable",
			p -> new BacktankBlockItem(AllBlocks.COPPER_BACKTANK.get(), AllItems.COPPER_BACKTANK::get, p))
		.model((c, p) -> p.withExistingParent(c.getName(), p.mcLoc("item/barrier")))
		.register();

	// wrapped by NETHERITE_BACKTANK for block placement uses.
	// must be registered as of 1.18.2
	public static final ItemEntry<BacktankBlockItem> NETHERITE_BACKTANK_PLACEABLE = REGISTRATE
		.item("netherite_backtank_placeable",
			p -> new BacktankBlockItem(AllBlocks.NETHERITE_BACKTANK.get(), AllItems.NETHERITE_BACKTANK::get, p))
		.model((c, p) -> p.withExistingParent(c.getName(), p.mcLoc("item/barrier")))
		.register();

	public static final ItemEntry<? extends BacktankItem>

		COPPER_BACKTANK =
		REGISTRATE
			.item("copper_backtank",
				p -> new BacktankItem(AllArmorMaterials.COPPER, p, Create.asResource("copper_diving"),
					COPPER_BACKTANK_PLACEABLE))
			.properties(p -> p.method_7895(-1)) // fabric: Item#canBeDepleted() isn't enough to disable durability, so we need to set its maxDamage to -1 as well
			.model(AssetLookup.customGenericItemModel("_", "item"))
			.tag(AllItemTags.PRESSURIZED_AIR_SOURCES.tag, AllItemTags.DIVING_ARMOR.tag)
			.tag(class_3489.field_48296)
			.register(),

		NETHERITE_BACKTANK = REGISTRATE
			.item("netherite_backtank",
				p -> new BacktankItem.Layered(class_1740.field_21977, p, Create.asResource("netherite_diving"),
					NETHERITE_BACKTANK_PLACEABLE))
			.model(AssetLookup.customGenericItemModel("_", "item"))
			.properties(p -> p.method_24359().method_7895(-1)) // fabric: Item#canBeDepleted() isn't enough to disable durability, so we need to set its maxDamage to -1 as well
			.tag(AllItemTags.PRESSURIZED_AIR_SOURCES.tag, AllItemTags.DIVING_ARMOR.tag)
			.tag(class_3489.field_48296)
			.register();

	public static final ItemEntry<? extends DivingHelmetItem>

		COPPER_DIVING_HELMET =
		REGISTRATE
			.item("copper_diving_helmet",
				p -> new DivingHelmetItem(AllArmorMaterials.COPPER, p, Create.asResource("copper_diving")))
			.properties(p -> p.method_7895(class_8051.field_41934.method_56690(7)))
			.tag(class_3489.field_48297, AllItemTags.DIVING_ARMOR.tag)
			.register(),

		NETHERITE_DIVING_HELMET = REGISTRATE
			.item("netherite_diving_helmet",
				p -> new DivingHelmetItem(class_1740.field_21977, p, Create.asResource("netherite_diving")))
			.properties(p -> p.method_24359().method_7895(class_8051.field_41934.method_56690(37)))
			.tag(class_3489.field_48297, AllItemTags.DIVING_ARMOR.tag)
			.register();

	public static final ItemEntry<? extends DivingBootsItem>

		COPPER_DIVING_BOOTS =
		REGISTRATE
			.item("copper_diving_boots",
				p -> new DivingBootsItem(AllArmorMaterials.COPPER, p, Create.asResource("copper_diving")))
			.properties(p -> p.method_7895(class_8051.field_41937.method_56690(7)))
			.tag(class_3489.field_48294, AllItemTags.DIVING_ARMOR.tag)
			.register(),

		NETHERITE_DIVING_BOOTS = REGISTRATE
			.item("netherite_diving_boots",
				p -> new DivingBootsItem(class_1740.field_21977, p, Create.asResource("netherite_diving")))
			.properties(p -> p.method_24359().method_7895(class_8051.field_41937.method_56690(37)))
			.tag(class_3489.field_48294, AllItemTags.DIVING_ARMOR.tag)
			.register();

	public static final ItemEntry<? extends BaseArmorItem>

			CARDBOARD_HELMET = REGISTRATE.item("cardboard_helmet", p -> new CardboardArmorItem(class_1738.class_8051.field_41934, p))
				.properties(p -> p.method_7895(class_8051.field_41934.method_56690(4)))
				.tag(class_3489.field_48297, class_3489.field_41890)
				.onRegister(i -> FuelRegistry.INSTANCE.add(i, 1000))
				.onRegisterAfter(class_7924.field_41197, v -> ItemDescription.useKey(v, "item.create.cardboard_armor"))
				.model(TrimmableArmorModelGenerator::generate)
				.onRegister(item -> CatnipServices.PLATFORM.executeOnClientOnly(() -> () -> ClientHooks.registerCardboardArmorOverlay(item)))
				.register(),

		CARDBOARD_CHESTPLATE =
			REGISTRATE.item("cardboard_chestplate", p -> new CardboardArmorItem(class_1738.class_8051.field_41935, p))
				.properties(p -> p.method_7895(class_8051.field_41935.method_56690(4)))
				.tag(class_3489.field_48296, class_3489.field_41890)
				.onRegister(i -> FuelRegistry.INSTANCE.add(i, 1000))
				.onRegisterAfter(class_7924.field_41197, v -> ItemDescription.useKey(v, "item.create.cardboard_armor"))
				.model(TrimmableArmorModelGenerator::generate)
				.register(),

		CARDBOARD_LEGGINGS =
			REGISTRATE.item("cardboard_leggings", p -> new CardboardArmorItem(class_1738.class_8051.field_41936, p))
				.properties(p -> p.method_7895(class_8051.field_41936.method_56690(4)))
				.tag(class_3489.field_48295, class_3489.field_41890)
				.onRegister(i -> FuelRegistry.INSTANCE.add(i, 1000))
				.onRegisterAfter(class_7924.field_41197, v -> ItemDescription.useKey(v, "item.create.cardboard_armor"))
				.model(TrimmableArmorModelGenerator::generate)
				.register(),

		CARDBOARD_BOOTS = REGISTRATE.item("cardboard_boots", p -> new CardboardArmorItem(class_1738.class_8051.field_41937, p))
			.properties(p -> p.method_7895(class_8051.field_41937.method_56690(4)))
			.tag(class_3489.field_48294, class_3489.field_41890)
			.onRegister(i -> FuelRegistry.INSTANCE.add(i, 1000))
			.onRegisterAfter(class_7924.field_41197, v -> ItemDescription.useKey(v, "item.create.cardboard_armor"))
			.model(TrimmableArmorModelGenerator::generate)
			.register();

	public static final ItemEntry<SandPaperItem> SAND_PAPER = REGISTRATE.item("sand_paper", SandPaperItem::new)
		.transform(CreateRegistrate.customRenderedItem(() -> SandPaperItemRenderer::new))
		.tag(AllTags.AllItemTags.SANDPAPER.tag)
		.register();

	public static final ItemEntry<SandPaperItem> RED_SAND_PAPER = REGISTRATE.item("red_sand_paper", SandPaperItem::new)
		.transform(CreateRegistrate.customRenderedItem(() -> SandPaperItemRenderer::new))
		.tag(AllTags.AllItemTags.SANDPAPER.tag)
		.onRegister(s -> ItemDescription.referKey(s, SAND_PAPER))
		.register();

	public static final ItemEntry<WrenchItem> WRENCH = REGISTRATE.item("wrench", WrenchItem::new)
		.properties(p -> p.method_7889(1))
		.transform(CreateRegistrate.customRenderedItem(() -> WrenchItemRenderer::new))
		.model(AssetLookup.itemModelWithPartials())
		.tag(AllItemTags.WRENCH.tag)
		.register();

	public static final ItemEntry<MinecartContraptionItem> MINECART_CONTRAPTION =
		REGISTRATE.item("minecart_contraption", MinecartContraptionItem::rideable)
			.register();

	public static final ItemEntry<MinecartContraptionItem> FURNACE_MINECART_CONTRAPTION =
		REGISTRATE.item("furnace_minecart_contraption", MinecartContraptionItem::furnace)
			.register();

	public static final ItemEntry<MinecartContraptionItem> CHEST_MINECART_CONTRAPTION =
		REGISTRATE.item("chest_minecart_contraption", MinecartContraptionItem::chest)
			.register();

	// Curiosities

	public static final ItemEntry<LinkedControllerItem> LINKED_CONTROLLER =
		REGISTRATE.item("linked_controller", LinkedControllerItem::new)
			.properties(p -> p.method_7889(1))
			.transform(CreateRegistrate.customRenderedItem(() -> LinkedControllerItemRenderer::new))
			.model(AssetLookup.itemModelWithPartials())
			.register();

	public static final ItemEntry<PotatoCannonItem> POTATO_CANNON =
		REGISTRATE.item("potato_cannon", PotatoCannonItem::new)
			.properties(p -> p.method_7895(100))
			.transform(CreateRegistrate.customRenderedItem(() -> PotatoCannonItemRenderer::new))
			.model(AssetLookup.itemModelWithPartials())
			.tag(net.neoforged.neoforge.common.Tags.Items.ENCHANTABLES)
			.register();

	public static final ItemEntry<ExtendoGripItem> EXTENDO_GRIP = REGISTRATE.item("extendo_grip", ExtendoGripItem::new)
		.properties(p -> p.method_7894(class_1814.field_8907))
		.transform(CreateRegistrate.customRenderedItem(() -> ExtendoGripItemRenderer::new))
		.model(AssetLookup.itemModelWithPartials())
		.register();

	public static final ItemEntry<SymmetryWandItem> WAND_OF_SYMMETRY =
		REGISTRATE.item("wand_of_symmetry", SymmetryWandItem::new)
			.properties(p -> p.method_7889(1)
				.method_7894(class_1814.field_8907))
			.transform(CreateRegistrate.customRenderedItem(() -> SymmetryWandItemRenderer::new))
			.model(AssetLookup.itemModelWithPartials())
			.register();

	public static final ItemEntry<WorldshaperItem> WORLDSHAPER =
		REGISTRATE.item("handheld_worldshaper", WorldshaperItem::new)
			.properties(p -> p.method_7894(class_1814.field_8904))
			.transform(CreateRegistrate.customRenderedItem(() -> WorldshaperItemRenderer::new))
			.lang("Creative Worldshaper")
			.model(AssetLookup.itemModelWithPartials())
			.register();

	public static final ItemEntry<TreeFertilizerItem> TREE_FERTILIZER =
		REGISTRATE.item("tree_fertilizer", TreeFertilizerItem::new)
			.register();

	// Logistics

	static {
		boolean rareCreated = false;
		boolean normalCreated = false;
		for (PackageStyle style : PackageStyles.STYLES) {
			ItemBuilder<PackageItem, CreateRegistrate> packageItem = BuilderTransformers.packageItem(style);

			if (rareCreated && style.rare() || normalCreated && !style.rare())
				packageItem.setData(ProviderType.LANG, NonNullBiConsumer.noop());

			rareCreated |= style.rare();
			normalCreated |= !style.rare();
			packageItem.register();
		}
	}

	public static final ItemEntry<FilterItem> FILTER = REGISTRATE.item("filter", FilterItem::regular)
		.lang("List Filter")
		.register(),

	ATTRIBUTE_FILTER = REGISTRATE.item("attribute_filter", FilterItem::attribute)
		.register(),

	PACKAGE_FILTER = REGISTRATE.item("package_filter", FilterItem::address)
		.register();

	public static final ItemEntry<ScheduleItem> SCHEDULE = REGISTRATE.item("schedule", ScheduleItem::new)
		.lang("Train Schedule")
		.register();

	public static final ItemEntry<ShoppingListItem> SHOPPING_LIST =
		REGISTRATE.item("shopping_list", ShoppingListItem::new)
			.properties(p -> p.method_7889(1))
			.register();

	// Schematics

	public static final ItemEntry<class_1792> EMPTY_SCHEMATIC = REGISTRATE.item("empty_schematic", class_1792::new)
		.properties(p -> p.method_7889(1))
		.register();

	public static final ItemEntry<SchematicAndQuillItem> SCHEMATIC_AND_QUILL =
		REGISTRATE.item("schematic_and_quill", SchematicAndQuillItem::new)
			.properties(p -> p.method_7889(1))
			.register();

	public static final ItemEntry<SchematicItem> SCHEMATIC = REGISTRATE.item("schematic", SchematicItem::new)
		.properties(p -> p.method_7889(1))
		.register();

	// Shortcuts

	private static ItemEntry<class_1792> ingredient(String name) {
		return REGISTRATE.item(name, class_1792::new)
			.register();
	}

	private static ItemEntry<SequencedAssemblyItem> sequencedIngredient(String name) {
		return REGISTRATE.item(name, SequencedAssemblyItem::new)
			.register();
	}

//	private static ItemEntry<HiddenIngredientItem> hiddenIngredient(String name) {
//		return REGISTRATE.item(name, HiddenIngredientItem::new)
//			.register();
//	}

	@SafeVarargs
	private static ItemEntry<class_1792> taggedIngredient(String name, class_6862<class_1792>... tags) {
		return REGISTRATE.item(name, class_1792::new)
			.tag(tags)
			.register();
	}

	private static ItemEntry<TagDependentIngredientItem> compatCrushedOre(CompatMetals metal) {
		String metalName = metal.getName();
		return REGISTRATE
			.item("crushed_raw_" + metalName,
				props -> new TagDependentIngredientItem(props, AllTags.commonItemTag(metalName + "_ores")))
			.tag(CRUSHED_RAW_MATERIALS.tag)
			.register();
	}

	// Load this class

	@Environment(EnvType.CLIENT)
	private static final class ClientHooks {
		private ClientHooks() {
		}

		private static void registerCardboardArmorOverlay(class_1792 item) {
			HelmetOverlay.REGISTRY.register(item, new com.simibubi.create.content.equipment.armor.CardboardArmorStealthOverlay());
		}
	}

	public static void register() {
	}

}
