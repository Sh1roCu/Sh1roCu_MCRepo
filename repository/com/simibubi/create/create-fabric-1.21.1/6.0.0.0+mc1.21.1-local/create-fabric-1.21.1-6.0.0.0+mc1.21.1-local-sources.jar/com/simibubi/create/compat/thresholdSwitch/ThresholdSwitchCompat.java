package com.simibubi.create.compat.thresholdSwitch;

import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.minecraft.class_2586;

public interface ThresholdSwitchCompat {

	boolean isFromThisMod(class_2586 blockEntity);

	long getSpaceInSlot(StorageView<ItemVariant> inv);

}
