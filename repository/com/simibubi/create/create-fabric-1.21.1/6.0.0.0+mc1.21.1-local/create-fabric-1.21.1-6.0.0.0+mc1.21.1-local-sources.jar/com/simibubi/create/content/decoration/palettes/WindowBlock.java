package com.simibubi.create.content.decoration.palettes;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class WindowBlock extends ConnectedGlassBlock {

	protected final boolean translucent;

	public WindowBlock(class_2251 p_i48392_1_, boolean translucent) {
		super(p_i48392_1_);
		this.translucent = translucent;
	}

	public boolean isTranslucent() {
		return translucent;
	}

	@Override
	@Environment(EnvType.CLIENT)
	public boolean method_9522(class_2680 state, class_2680 adjacentBlockState, class_2350 side) {
		if (state.method_26204() == adjacentBlockState.method_26204()) {
			return true;
		}
		if (state.method_26204() instanceof WindowBlock windowBlock
				&& adjacentBlockState.method_26204() instanceof ConnectedGlassBlock) {
			return !windowBlock.isTranslucent() && side.method_10166().method_10179();
		}
		return super.method_9522(state, adjacentBlockState, side);
	}

}
