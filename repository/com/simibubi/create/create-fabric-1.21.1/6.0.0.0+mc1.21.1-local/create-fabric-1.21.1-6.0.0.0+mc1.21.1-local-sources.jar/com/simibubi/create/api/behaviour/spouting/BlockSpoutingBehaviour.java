package com.simibubi.create.api.behaviour.spouting;

import com.simibubi.create.infrastructure.fabric.transfer.fluid.FluidStack;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.api.registry.SimpleRegistry;
import com.simibubi.create.content.fluids.spout.SpoutBlockEntity;

/**
 * Interface for custom block-filling behavior for spouts.
 * <p>
 * Behaviors are queried by block first, through {@link #BY_BLOCK}. If no behavior was provided,
 * they are then queried by block entity type, through {@link #BY_BLOCK_ENTITY}.
 * @see StateChangingBehavior
 * @see CauldronSpoutingBehavior
 */
@FunctionalInterface
public interface BlockSpoutingBehaviour {
	SimpleRegistry<class_2248, BlockSpoutingBehaviour> BY_BLOCK = SimpleRegistry.create();
	SimpleRegistry<class_2591<?>, BlockSpoutingBehaviour> BY_BLOCK_ENTITY = SimpleRegistry.create();

	/**
	 * Get the behavior that should be used for the block at the given location.
	 * Queries both the block and the block entity if needed.
	 */
	@Nullable
	static BlockSpoutingBehaviour get(class_1937 level, class_2338 pos) {
		class_2680 state = level.method_8320(pos);
		BlockSpoutingBehaviour byBlock = BY_BLOCK.get(state.method_26204());
		if (byBlock != null)
			return byBlock;

		class_2586 be = level.method_8321(pos);
		if (be == null)
			return null;

		return BY_BLOCK_ENTITY.get(be.method_11017());
	}

	/**
	 * While idle, spouts will query the behavior provided by the block below it.
	 * If one is present, this method will be called every tick with simulate == true.
	 * <p>
	 * When a value greater than 0 is returned, the spout will begin processing. It will call this method again
	 * with simulate == false, which is when any filling behavior should actually occur.
	 * <p>
	 * This method is only called on the server side, except for in Ponder.
	 * @param level          The current level
	 * @param pos            The position of the affected block
	 * @param spout          The spout block entity that is calling this
	 * @param availableFluid A copy of the fluidStack that is available, modifying this will do nothing, return the amount to be subtracted instead
	 * @param simulate       Whether the spout is testing or actually performing this behaviour
	 * @return The amount filled into the block, 0 to idle/cancel
	 */
	long fillBlock(class_1937 level, class_2338 pos, SpoutBlockEntity spout, FluidStack availableFluid, boolean simulate);
}
