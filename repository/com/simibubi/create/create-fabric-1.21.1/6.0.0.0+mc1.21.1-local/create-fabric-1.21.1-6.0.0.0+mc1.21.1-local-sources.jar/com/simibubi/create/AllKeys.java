package com.simibubi.create;

import java.util.function.BiConsumer;

import org.lwjgl.glfw.GLFW;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_437;

public enum AllKeys {

	TOOL_MENU("toolmenu", GLFW.GLFW_KEY_LEFT_ALT, "Focus Schematic Overlay"),
	ACTIVATE_TOOL(GLFW.GLFW_KEY_LEFT_CONTROL),
	TOOLBELT("toolbelt", GLFW.GLFW_KEY_LEFT_ALT, "Access Nearby Toolboxes"),
	ROTATE_MENU("rotate_menu", GLFW.GLFW_KEY_UNKNOWN, "Open Block Rotation Menu"),

	;

	private class_304 keybind;
	private final String description;
	private final String translation;
	private final int key;
	private final boolean modifiable;

	AllKeys(int defaultKey) {
		this("", defaultKey, "");
	}

	AllKeys(String description, int defaultKey, String translation) {
		this.description = Create.ID + ".keyinfo." + description;
		this.key = defaultKey;
		this.modifiable = !description.isEmpty();
		this.translation = translation;
	}

	public static void provideLang(BiConsumer<String, String> consumer) {
		for (AllKeys key : values())
			if (key.modifiable)
				consumer.accept(key.description, key.translation);
	}

	public static void register() {
		for (AllKeys key : values()) {
			if (!key.modifiable)
				continue;
			key.keybind = new class_304(key.description, key.key, Create.NAME);
			KeyBindingHelper.registerKeyBinding(key.keybind);
		}
	}

	// fabric: sometimes after opening the toolbox menu, alt gets stuck as pressed until a screen is opened.
	// why is this needed? why did this only just now break? Good questions! I wish I knew.
	public static void fixBinds() {
		long window = class_310.method_1551().method_22683().method_4490();
		for (AllKeys key : values()) {
			if (key.keybind == null || key.keybind.method_1415())
				continue;
			key.keybind.method_23481(class_3675.method_15987(window, key.getBoundCode()));
		}
	}

	public class_304 getKeybind() {
		return keybind;
	}

	public boolean isPressed() {
		if (!modifiable)
			return isKeyDown(key);
		return keybind.method_1434();
	}

	public String getBoundKey() {
		return keybind.method_16007()
			.getString()
			.toUpperCase();
	}

	public int getBoundCode() {
		return KeyBindingHelper.getBoundKeyOf(keybind)
				.method_1444();
	}

	public static boolean isKeyDown(int key) {
		return class_3675.method_15987(class_310.method_1551()
			.method_22683()
			.method_4490(), key);
	}

	public static boolean isMouseButtonDown(int button) {
		return GLFW.glfwGetMouseButton(class_310.method_1551()
			.method_22683()
			.method_4490(), button) == 1;
	}

	public static boolean ctrlDown() {
		return class_437.method_25441();
	}

	public static boolean shiftDown() {
		return class_437.method_25442();
	}

	public static boolean altDown() {
		return class_437.method_25443();
	}

}
