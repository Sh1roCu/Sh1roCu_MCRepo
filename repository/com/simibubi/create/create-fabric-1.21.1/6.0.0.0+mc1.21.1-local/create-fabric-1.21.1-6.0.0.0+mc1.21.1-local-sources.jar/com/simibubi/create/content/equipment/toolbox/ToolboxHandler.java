package com.simibubi.create.content.equipment.toolbox;

import java.util.List;
import java.util.WeakHashMap;
import java.util.stream.Collectors;

import com.simibubi.create.foundation.networking.ISyncPersistentData.PersistentDataPacket;
import com.simibubi.create.infrastructure.config.AllConfigs;

import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.createmod.catnip.data.WorldAttached;
import net.createmod.catnip.nbt.NBTHelper;

public class ToolboxHandler {

	public static final WorldAttached<WeakHashMap<class_2338, ToolboxBlockEntity>> toolboxes =
		new WorldAttached<>(w -> new WeakHashMap<>());

	public static void onLoad(ToolboxBlockEntity be) {
		toolboxes.get(be.method_10997())
			.put(be.method_11016(), be);
	}

	public static void onUnload(ToolboxBlockEntity be) {
		toolboxes.get(be.method_10997())
			.remove(be.method_11016());
	}

	static int validationTimer = 20;

	public static void entityTick(class_1297 entity, class_1937 world) {
		if (world.field_9236)
			return;
		if (!(world instanceof class_3218))
			return;
		if (!(entity instanceof class_3222 player))
			return;
		if (entity.field_6012 % validationTimer != 0)
			return;

		if (!player.getCustomData()
			.method_10545("CreateToolboxData"))
			return;

		boolean sendData = false;
		class_2487 compound = player.getCustomData()
			.method_10562("CreateToolboxData");
		for (int i = 0; i < 9; i++) {
			String key = String.valueOf(i);
			if (!compound.method_10545(key))
				continue;

			class_2487 data = compound.method_10562(key);
			class_2338 pos = NBTHelper.readBlockPos(data, "Pos");
			int slot = data.method_10550("Slot");

			if (!world.method_8477(pos))
				continue;
			if (!(world.method_8320(pos)
				.method_26204() instanceof ToolboxBlock)) {
				compound.method_10551(key);
				sendData = true;
				continue;
			}

			class_2586 prevBlockEntity = world.method_8321(pos);
			if (prevBlockEntity instanceof ToolboxBlockEntity)
				((ToolboxBlockEntity) prevBlockEntity).connectPlayer(slot, player, i);
		}

		if (sendData)
			syncData(player);
	}

	public static void playerLogin(class_1657 player) {
		if (!(player instanceof class_3222))
			return;
		if (player.getCustomData()
			.method_10545("CreateToolboxData")
			&& !player.getCustomData()
			.method_10562("CreateToolboxData")
			.method_33133()) {
			syncData(player);
		}
	}

	public static void syncData(class_1657 player) {
		CatnipServices.NETWORK.sendToClient((class_3222) player,
			new PersistentDataPacket(player));
	}

	public static List<ToolboxBlockEntity> getNearest(class_1936 world, class_1657 player, int maxAmount) {
		class_243 location = player.method_19538();
		double maxRange = getMaxRange(player);
		return toolboxes.get(world)
			.keySet()
			.stream()
			.filter(p -> distance(location, p) < maxRange * maxRange)
			.sorted((p1, p2) -> Double.compare(distance(location, p1), distance(location, p2)))
			.limit(maxAmount)
			.map(toolboxes.get(world)::get)
			.filter(ToolboxBlockEntity::isFullyInitialized)
			.collect(Collectors.toList());
	}

	public static void unequip(class_1657 player, int hotbarSlot, boolean keepItems) {
		class_2487 compound = player.getCustomData()
			.method_10562("CreateToolboxData");
		class_1937 world = player.method_37908();
		String key = String.valueOf(hotbarSlot);
		if (!compound.method_10545(key))
			return;

		class_2487 prevData = compound.method_10562(key);
		class_2338 prevPos = NBTHelper.readBlockPos(prevData, "Pos");
		int prevSlot = prevData.method_10550("Slot");

		class_2586 prevBlockEntity = world.method_8321(prevPos);
		if (prevBlockEntity instanceof ToolboxBlockEntity toolbox) {
			toolbox.unequip(prevSlot, player, hotbarSlot, keepItems || !ToolboxHandler.withinRange(player, toolbox));
		}
		compound.method_10551(key);
	}

	public static boolean withinRange(class_1657 player, ToolboxBlockEntity box) {
		if (player.method_37908() != box.method_10997())
			return false;
		double maxRange = getMaxRange(player);
		return distance(player.method_19538(), box.method_11016()) < maxRange * maxRange;
	}

	public static double distance(class_243 location, class_2338 p) {
		return location.method_1028(p.method_10263() + 0.5f, p.method_10264(), p.method_10260() + 0.5f);
	}

	public static double getMaxRange(class_1657 player) {
		return AllConfigs.server().equipment.toolboxRange.get()
			.doubleValue();
	}

}
