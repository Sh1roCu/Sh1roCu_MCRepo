package com.simibubi.create.content.contraptions.glue;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;

@Environment(EnvType.CLIENT)
public class SuperGlueRenderer extends class_897<SuperGlueEntity> {

	public SuperGlueRenderer(class_5617.class_5618 context) {
		super(context);
	}

	@Override
	public class_2960 getTextureLocation(SuperGlueEntity entity) {
		return null;
	}

	@Override
	public boolean shouldRender(SuperGlueEntity entity, class_4604 frustum, double x, double y, double z) {
		return false;
	}

}
