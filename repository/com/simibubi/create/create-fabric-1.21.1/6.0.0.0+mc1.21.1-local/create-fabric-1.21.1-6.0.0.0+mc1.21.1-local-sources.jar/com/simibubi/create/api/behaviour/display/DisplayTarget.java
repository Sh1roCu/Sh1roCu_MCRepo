package com.simibubi.create.api.behaviour.display;

import java.util.Map;
import java.util.List;
import java.util.WeakHashMap;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2625;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllDisplayTargets;
import com.simibubi.create.Create;
import com.simibubi.create.api.registry.CreateBuiltInRegistries;
import com.simibubi.create.api.registry.CreateRegistries;
import com.simibubi.create.api.registry.SimpleRegistry;
import com.simibubi.create.content.redstone.displayLink.DisplayLinkContext;
import com.simibubi.create.content.redstone.displayLink.target.DisplayTargetStats;
import com.simibubi.create.foundation.utility.CreateLang;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.util.entry.RegistryEntry;
import com.tterrag.registrate.util.nullness.NonNullUnaryOperator;

public abstract class DisplayTarget {
	public static final SimpleRegistry<class_2248, DisplayTarget> BY_BLOCK = SimpleRegistry.create();
	public static final SimpleRegistry<class_2591<?>, DisplayTarget> BY_BLOCK_ENTITY = SimpleRegistry.create();
	private static final Map<class_2586, class_2487> RESERVATION_DATA = new WeakHashMap<>();

	public abstract void acceptText(int line, List<class_5250> text, DisplayLinkContext context);

	public abstract DisplayTargetStats provideStats(DisplayLinkContext context);

	public class_238 getMultiblockBounds(class_1936 level, class_2338 pos) {
		class_265 shape = level.method_8320(pos)
			.method_26218(level, pos);
		if (shape.method_1110())
			return new class_238(pos);
		return shape.method_1107()
			.method_996(pos);
	}

	public class_2561 getLineOptionText(int line) {
		return CreateLang.translateDirect("display_target.line", line + 1);
	}

	public static void reserve(int line, class_2586 target, DisplayLinkContext context) {
		if (line == 0)
			return;

		class_2487 tag = RESERVATION_DATA.computeIfAbsent(target, be -> new class_2487());
		class_2487 compound = tag.method_10562("DisplayLink");
		compound.method_10544("Line" + line, context.blockEntity()
			.method_11016()
			.method_10063());
		tag.method_10566("DisplayLink", compound);
	}

	public boolean isReserved(int line, class_2586 target, DisplayLinkContext context) {
		class_2487 tag = RESERVATION_DATA.computeIfAbsent(target, be -> new class_2487());
		class_2487 compound = tag.method_10562("DisplayLink");

		if (!compound.method_10545("Line" + line))
			return false;

		long l = compound.method_10537("Line" + line);
		class_2338 reserved = class_2338.method_10092(l);

		if (!reserved.equals(context.blockEntity()
			.method_11016()) && AllBlocks.DISPLAY_LINK.has(target.method_10997()
				.method_8320(reserved)))
			return true;

		compound.method_10551("Line" + line);
		if (compound.method_33133())
			tag.method_10551("DisplayLink");
		return false;
	}

	public boolean requiresComponentSanitization() {
		return false;
	}

	/**
	 * Utility for use with Registrate builders. Creates a builder transformer
	 * that will register the given DisplayTarget to a block when ready.
	 */
	public static <B extends class_2248, P> NonNullUnaryOperator<BlockBuilder<B, P>> displayTarget(RegistryEntry<DisplayTarget, ? extends DisplayTarget> target) {
		return builder -> builder.onRegisterAfter(CreateRegistries.DISPLAY_TARGET, block -> BY_BLOCK.register(block, target.get()));
	}

	/**
	 * Get the DisplayTarget with the given ID, accounting for legacy names.
	 */
	@Nullable
	public static DisplayTarget get(@Nullable class_2960 id) {
		if (id == null)
			return null;

		if (id.method_12836().equals(Create.ID) && AllDisplayTargets.LEGACY_NAMES.containsKey(id.method_12832())) {
			return AllDisplayTargets.LEGACY_NAMES.get(id.method_12832()).get();
		}

		return CreateBuiltInRegistries.DISPLAY_TARGET.method_10223(id);
	}

	/**
	 * Get the DisplayTarget applicable to the given location, or null if there isn't one.
	 */
	@Nullable
	public static DisplayTarget get(class_1936 level, class_2338 pos) {
		class_2680 state = level.method_8320(pos);
		DisplayTarget byBlock = BY_BLOCK.get(state);
		// block takes priority if present, it's more granular
		if (byBlock != null)
			return byBlock;

		class_2586 be = level.method_8321(pos);
		if (be == null)
			return null;

		DisplayTarget byBe = BY_BLOCK_ENTITY.get(be.method_11017());
		if (byBe != null)
			return byBe;

		// special case: modded signs are common
		return be instanceof class_2625 ? AllDisplayTargets.SIGN.get() : null;
	}
}
