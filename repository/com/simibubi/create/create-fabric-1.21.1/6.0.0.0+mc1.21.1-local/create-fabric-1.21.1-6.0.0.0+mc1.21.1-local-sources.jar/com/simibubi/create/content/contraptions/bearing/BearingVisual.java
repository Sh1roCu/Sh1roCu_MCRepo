package com.simibubi.create.content.contraptions.bearing;

import java.util.function.Consumer;

import org.joml.Quaternionf;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.kinetics.base.OrientedRotatingVisual;

import dev.engine_room.flywheel.api.instance.Instance;
import dev.engine_room.flywheel.api.visual.DynamicVisual;
import dev.engine_room.flywheel.api.visualization.VisualizationContext;
import dev.engine_room.flywheel.lib.instance.InstanceTypes;
import dev.engine_room.flywheel.lib.instance.OrientedInstance;
import dev.engine_room.flywheel.lib.model.Models;
import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import dev.engine_room.flywheel.lib.visual.SimpleDynamicVisual;
import net.createmod.catnip.math.AngleHelper;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_7833;

public class BearingVisual<B extends KineticBlockEntity & IBearingBlockEntity> extends OrientedRotatingVisual<B> implements SimpleDynamicVisual {
	final OrientedInstance topInstance;

	final class_7833 rotationAxis;
	final Quaternionf blockOrientation;

	public BearingVisual(VisualizationContext context, B blockEntity, float partialTick) {
		super(context, blockEntity, partialTick, class_2350.field_11035, blockEntity.method_11010().method_11654(class_2741.field_12525).method_10153(), Models.partial(AllPartialModels.SHAFT_HALF));

		class_2350 facing = blockState.method_11654(class_2741.field_12525);
		rotationAxis = class_7833.method_46356(class_2350.method_10156(class_2350.class_2352.field_11056, rotationAxis()).method_23955());

		blockOrientation = getBlockStateOrientation(facing);

		PartialModel top =
				blockEntity.isWoodenTop() ? AllPartialModels.BEARING_TOP_WOODEN : AllPartialModels.BEARING_TOP;

		topInstance = instancerProvider().instancer(InstanceTypes.ORIENTED, Models.partial(top))
				.createInstance();

		topInstance.position(getVisualPosition())
				.rotation(blockOrientation)
				.setChanged();
	}

	@Override
	public void beginFrame(DynamicVisual.Context ctx) {
		float interpolatedAngle = blockEntity.getInterpolatedAngle(ctx.partialTick() - 1);
		Quaternionf rot = rotationAxis.rotationDegrees(interpolatedAngle);

		rot.mul(blockOrientation);

		topInstance.rotation(rot)
				.setChanged();
	}

	@Override
	public void updateLight(float partialTick) {
		super.updateLight(partialTick);
		relight(topInstance);
	}

	@Override
	protected void _delete() {
		super._delete();
		topInstance.delete();
	}

	static Quaternionf getBlockStateOrientation(class_2350 facing) {
		Quaternionf orientation;

		if (facing.method_10166().method_10179()) {
			orientation = class_7833.field_40716.rotationDegrees(AngleHelper.horizontalAngle(facing.method_10153()));
		} else {
			orientation = new Quaternionf();
		}

		orientation.mul(class_7833.field_40714.rotationDegrees(-90 - AngleHelper.verticalAngle(facing)));
		return orientation;
	}

	@Override
	public void collectCrumblingInstances(Consumer<Instance> consumer) {
		super.collectCrumblingInstances(consumer);
		consumer.accept(topInstance);
	}
}
