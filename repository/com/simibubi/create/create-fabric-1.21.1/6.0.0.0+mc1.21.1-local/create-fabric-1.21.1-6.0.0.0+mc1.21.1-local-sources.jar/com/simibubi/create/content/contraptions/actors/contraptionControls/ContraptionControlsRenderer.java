package com.simibubi.create.content.contraptions.actors.contraptionControls;

import java.util.Random;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.contraptions.actors.contraptionControls.ContraptionControlsMovement.ElevatorFloorSelection;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.contraptions.render.ContraptionMatrices;
import com.simibubi.create.content.redstone.nixieTube.NixieTubeRenderer;
import com.simibubi.create.foundation.blockEntity.renderer.SmartBlockEntityRenderer;
import com.simibubi.create.foundation.utility.DyeHelper;
import com.simibubi.create.foundation.virtualWorld.VirtualRenderWorld;

import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.createmod.catnip.data.Couple;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.math.VecHelper;
import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.theme.Color;
import net.minecraft.class_1297;
import net.minecraft.class_1767;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614.class_5615;
import net.minecraft.class_761;

public class ContraptionControlsRenderer extends SmartBlockEntityRenderer<ContraptionControlsBlockEntity> {

	private static Random r = new Random();

	public ContraptionControlsRenderer(class_5615 context) {
		super(context);
	}

	@Override
	protected void renderSafe(ContraptionControlsBlockEntity blockEntity, float pt, class_4587 ms,
							  class_4597 buffer, int light, int overlay) {
		class_2680 blockState = blockEntity.method_11010();
		class_2350 facing = blockState.method_11654(ContraptionControlsBlock.field_11177)
			.method_10153();
		class_243 buttonMovementAxis = VecHelper.rotate(new class_243(0, 1, -.325), AngleHelper.horizontalAngle(facing), class_2351.field_11052);
		class_243 buttonMovement = buttonMovementAxis.method_1021(-0.07f + -1 / 24f * blockEntity.button.getValue(pt));
		class_243 buttonOffset = buttonMovementAxis.method_1021(0.07f);

		ms.method_22903();
		ms.method_22904(buttonMovement.field_1352, buttonMovement.field_1351, buttonMovement.field_1350);
		super.renderSafe(blockEntity, pt, ms, buffer, light, overlay);
		ms.method_22904(buttonOffset.field_1352, buttonOffset.field_1351, buttonOffset.field_1350);

		class_4588 vc = buffer.getBuffer(class_1921.method_23577());
		CachedBuffers.partialFacing(AllPartialModels.CONTRAPTION_CONTROLS_BUTTON, blockState, facing)
			.light(light)
			.renderInto(ms, vc);

		ms.method_22909();

		int i = (((int) blockEntity.indicator.getValue(pt) / 45) % 8) + 8;
		CachedBuffers.partialFacing(AllPartialModels.CONTRAPTION_CONTROLS_INDICATOR.get(i % 8), blockState, facing)
			.light(light)
			.renderInto(ms, vc);
	}

	public static void renderInContraption(MovementContext ctx, VirtualRenderWorld renderWorld,
										   ContraptionMatrices matrices, class_4597 buffer) {

		if (!(ctx.temporaryData instanceof ElevatorFloorSelection efs))
			return;
		if (!AllBlocks.CONTRAPTION_CONTROLS.has(ctx.state))
			return;

		class_1297 cameraEntity = class_310.method_1551()
			.method_1560();
		float playerDistance = (float) (ctx.position == null || cameraEntity == null ? 0
			: ctx.position.method_1025(cameraEntity.method_33571()));

		float flicker = r.nextFloat();
		Couple<Integer> couple = DyeHelper.getDyeColors(efs.targetYEqualsSelection ? class_1767.field_7952 : class_1767.field_7946);
		int brightColor = couple.getFirst();
		int darkColor = couple.getSecond();
		int flickeringBrightColor = Color.mixColors(brightColor, darkColor, flicker / 4);
		class_327 fontRenderer = class_310.method_1551().field_1772;
		float shadowOffset = .5f;

		String text = efs.currentShortName;
		String description = efs.currentLongName;
		class_4587 ms = matrices.getViewProjection();
		var msr = TransformStack.of(ms);

		float buttondepth = 0;
		if (ctx.contraption.presentBlockEntities.get(ctx.localPos) instanceof ContraptionControlsBlockEntity cbe)
			buttondepth = -1 / 24f * cbe.button.getValue(AnimationTickHolder.getPartialTicks(renderWorld));

		ms.method_22903();
		msr.translate(ctx.localPos);
		ms.method_46416(0, buttondepth, 0);
		class_4588 vc = buffer.getBuffer(class_1921.method_23577());
		CachedBuffers.partialFacing(AllPartialModels.CONTRAPTION_CONTROLS_BUTTON, ctx.state, ctx.state.method_11654(ContraptionControlsBlock.field_11177).method_10153())
			.light(class_761.method_23794(renderWorld, ctx.localPos))
			.useLevelLight(ctx.world, matrices.getWorld())
			.renderInto(ms, vc);
		ms.method_22909();

		ms.method_22903();
		msr.translate(ctx.localPos);
		msr.rotateCentered(AngleHelper.rad(AngleHelper.horizontalAngle(ctx.state.method_11654(ContraptionControlsBlock.field_11177))),
			class_2350.field_11036);
		ms.method_46416(0.275f + 0.125f, 1 + 2 / 16f, 0.5f);
		msr.rotate(AngleHelper.rad(67.5f), class_2350.field_11039);

		if (!text.isBlank() && playerDistance < 100) {
			int actualWidth = fontRenderer.method_1727(text);
			int width = Math.max(actualWidth, 12);
			float scale = 1 / (5f * (width - .5f));
			float heightCentering = (width - 8f) / 2;

			ms.method_22903();
			ms.method_46416(0, .15f, buttondepth - .25f);
			ms.method_22905(scale, -scale, scale);
			ms.method_46416((float) Math.max(0, width - actualWidth) / 2, heightCentering, 0);
			NixieTubeRenderer.drawInWorldString(ms, buffer, text, flickeringBrightColor);
			ms.method_46416(shadowOffset, shadowOffset, -1 / 16f);
			NixieTubeRenderer.drawInWorldString(ms, buffer, text, Color.mixColors(darkColor, 0, .35f));
			ms.method_22909();
		}

		if (!description.isBlank() && playerDistance < 20) {
			int actualWidth = fontRenderer.method_1727(description);
			int width = Math.max(actualWidth, 55);
			float scale = 1 / (3f * (width - .5f));
			float heightCentering = (width - 8f) / 2;

			ms.method_22903();
			ms.method_46416(-.0635f, 0.06f, buttondepth);
			ms.method_22905(scale, -scale, scale);
			ms.method_46416((float) Math.max(0, width - actualWidth) / 2, heightCentering, 0);
			NixieTubeRenderer.drawInWorldString(ms, buffer, description, flickeringBrightColor);
			ms.method_22909();
		}

		ms.method_22909();

	}

}
