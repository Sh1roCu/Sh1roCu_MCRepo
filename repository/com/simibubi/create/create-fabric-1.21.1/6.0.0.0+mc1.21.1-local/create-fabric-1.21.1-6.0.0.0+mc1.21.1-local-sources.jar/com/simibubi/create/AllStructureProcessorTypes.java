package com.simibubi.create;

import com.simibubi.create.content.schematics.SchematicProcessor;
import net.minecraft.class_2378;
import net.minecraft.class_3828;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class AllStructureProcessorTypes {
	@SuppressWarnings({"rawtypes", "unchecked"})
	public static final class_6880.class_6883<class_3828<?>> SCHEMATIC = class_2378.method_47985(
		class_7923.field_41161,
		Create.asResource("schematic"),
		(class_3828) (() -> SchematicProcessor.CODEC)
	);

	public static void register() {
	}
}
