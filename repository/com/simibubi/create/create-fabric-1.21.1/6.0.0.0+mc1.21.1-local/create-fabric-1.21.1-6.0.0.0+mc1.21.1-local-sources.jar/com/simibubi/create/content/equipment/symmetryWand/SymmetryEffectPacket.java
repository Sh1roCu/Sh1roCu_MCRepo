package com.simibubi.create.content.equipment.symmetryWand;

import java.util.List;

import com.simibubi.create.AllPackets;
import net.createmod.catnip.net.base.ClientboundPacketPayload;

import net.createmod.catnip.codecs.stream.CatnipStreamCodecBuilders;
import io.netty.buffer.ByteBuf;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_746;
import net.minecraft.class_9139;

public record SymmetryEffectPacket(class_2338 mirror, List<class_2338> positions) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, SymmetryEffectPacket> STREAM_CODEC = class_9139.method_56435(
	        class_2338.field_48404, SymmetryEffectPacket::mirror,
			CatnipStreamCodecBuilders.list(class_2338.field_48404), SymmetryEffectPacket::positions,
	        SymmetryEffectPacket::new
	);

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.SYMMETRY_EFFECT;
	}

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		if (player.method_19538().method_1022(class_243.method_24954(mirror)) > 100)
			return;
		for (class_2338 to : positions)
			SymmetryHandler.drawEffect(mirror, to);
	}
}
