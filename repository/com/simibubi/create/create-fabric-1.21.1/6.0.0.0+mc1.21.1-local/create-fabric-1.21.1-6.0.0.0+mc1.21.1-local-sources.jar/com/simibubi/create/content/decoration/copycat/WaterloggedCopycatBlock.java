package com.simibubi.create.content.decoration.copycat;

import com.simibubi.create.foundation.block.ProperWaterloggedBlock;
import net.minecraft.class_1750;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_3610;

public abstract class WaterloggedCopycatBlock extends CopycatBlock implements ProperWaterloggedBlock {

	public WaterloggedCopycatBlock(class_2251 pProperties) {
		super(pProperties);
		method_9590(method_9564().method_11657(WATERLOGGED, false));
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> pBuilder) {
		super.method_9515(pBuilder.method_11667(WATERLOGGED));
	}

	@Override
	public class_3610 method_9545(class_2680 pState) {
		return fluidState(pState);
	}

	@Override
	public class_2680 method_9605(class_1750 pContext) {
		return withWater(super.method_9605(pContext), pContext);
	}
	
	@Override
	public class_2680 method_9559(class_2680 pState, class_2350 pDirection, class_2680 pNeighborState,
		class_1936 pLevel, class_2338 pCurrentPos, class_2338 pNeighborPos) {
		updateWater(pLevel, pState, pCurrentPos);
		return pState;
	}

}
