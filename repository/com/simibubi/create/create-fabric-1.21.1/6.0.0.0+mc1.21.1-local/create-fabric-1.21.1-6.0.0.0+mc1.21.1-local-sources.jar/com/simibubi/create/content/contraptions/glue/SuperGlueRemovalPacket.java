package com.simibubi.create.content.contraptions.glue;

import com.simibubi.create.AllPackets;
import com.simibubi.create.AllSoundEvents;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_3222;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.netty.buffer.ByteBuf;
import com.simibubi.create.foundation.utility.AdventureUtil;

import io.netty.buffer.ByteBuf;

public record SuperGlueRemovalPacket(int entityId, class_2338 soundSource) implements ServerboundPacketPayload {
	public static final class_9139<ByteBuf, com.simibubi.create.content.contraptions.glue.SuperGlueRemovalPacket> STREAM_CODEC = class_9139.method_56435(
			class_9135.field_49675, com.simibubi.create.content.contraptions.glue.SuperGlueRemovalPacket::entityId,
			class_2338.field_48404, com.simibubi.create.content.contraptions.glue.SuperGlueRemovalPacket::soundSource,
			com.simibubi.create.content.contraptions.glue.SuperGlueRemovalPacket::new
	);

	@Override
	public void handle(class_3222 player) {
		if (AdventureUtil.isAdventure(player))
				return;
			class_1297 entity = player.method_37908().method_8469(entityId);
			if (!(entity instanceof SuperGlueEntity superGlue))
				return;
			double range = 32;
			if (player.method_5707(superGlue.method_19538()) > range * range)
				return;
			AllSoundEvents.SLIME_ADDED.play(player.method_37908(), null, soundSource, 0.5F, 0.5F);
			superGlue.spawnParticles();
			entity.method_31472();

	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.GLUE_REMOVED;
	}
}
