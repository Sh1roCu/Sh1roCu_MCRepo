package com.simibubi.create.content.contraptions.actors.psi;

import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_6328;
import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllShapes;
import com.simibubi.create.foundation.advancement.AdvancementBehaviour;
import com.simibubi.create.foundation.block.IBE;
import com.simibubi.create.foundation.block.WrenchableDirectionalBlock;

@ParametersAreNonnullByDefault
@class_6328
public class PortableStorageInterfaceBlock extends WrenchableDirectionalBlock
	implements IBE<PortableStorageInterfaceBlockEntity> {

	boolean fluids;

	public static PortableStorageInterfaceBlock forItems(class_2251 p_i48415_1_) {
		return new PortableStorageInterfaceBlock(p_i48415_1_, false);
	}

	public static PortableStorageInterfaceBlock forFluids(class_2251 p_i48415_1_) {
		return new PortableStorageInterfaceBlock(p_i48415_1_, true);
	}

	private PortableStorageInterfaceBlock(class_2251 p_i48415_1_, boolean fluids) {
		super(p_i48415_1_);
		this.fluids = fluids;
	}

	@Override
	public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 p_220069_4_, class_2338 p_220069_5_,
		boolean p_220069_6_) {
		withBlockEntityDo(world, pos, PortableStorageInterfaceBlockEntity::neighbourChanged);
	}

	@Override
	public void method_9567(class_1937 pLevel, class_2338 pPos, class_2680 pState, class_1309 pPlacer, class_1799 pStack) {
		super.method_9567(pLevel, pPos, pState, pPlacer, pStack);
		AdvancementBehaviour.setPlacedBy(pLevel, pPos, pPlacer);
	}
	
	@Override
	public class_2680 method_9605(class_1750 context) {
		class_2350 direction = context.method_7715();
		if (context.method_8036() != null && context.method_8036()
			.method_5715())
			direction = direction.method_10153();
		return method_9564().method_11657(field_10927, direction.method_10153());
	}

	@Override
	public class_265 method_9530(class_2680 state, class_1922 worldIn, class_2338 pos, class_3726 context) {
		return AllShapes.PORTABLE_STORAGE_INTERFACE.get(state.method_11654(field_10927));
	}

	@Override
	public boolean method_9498(class_2680 state) {
		return true;
	}

	@Override
	public int method_9572(class_2680 blockState, class_1937 worldIn, class_2338 pos) {
		return getBlockEntityOptional(worldIn, pos).map(be -> be.isConnected() ? 15 : 0)
			.orElse(0);
	}

	@Override
	public Class<PortableStorageInterfaceBlockEntity> getBlockEntityClass() {
		return PortableStorageInterfaceBlockEntity.class;
	}

	@Override
	public class_2591<? extends PortableStorageInterfaceBlockEntity> getBlockEntityType() {
		return fluids ? AllBlockEntityTypes.PORTABLE_FLUID_INTERFACE.get()
			: AllBlockEntityTypes.PORTABLE_STORAGE_INTERFACE.get();
	}

}
