package com.simibubi.create.content.equipment.clipboard;

import java.util.List;

import com.simibubi.create.infrastructure.fabric.item.ItemUtils;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import org.jetbrains.annotations.NotNull;

import com.google.common.collect.ImmutableList;
import com.mojang.serialization.MapCodec;
import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllShapes;
import com.simibubi.create.content.equipment.wrench.IWrenchable;
import com.simibubi.create.foundation.block.IBE;
import com.simibubi.create.foundation.block.ProperWaterloggedBlock;

import net.createmod.catnip.gui.ScreenOpener;
import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2341;
import net.minecraft.class_2350;
import net.minecraft.class_2480;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2738;
import net.minecraft.class_2746;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_8567;
import io.github.fabricators_of_create.porting_lib.common.util.EnvExecutor;

public class ClipboardBlock extends class_2341
	implements IBE<ClipboardBlockEntity>, IWrenchable, ProperWaterloggedBlock {

	public static final class_2746 WRITTEN = class_2746.method_11825("written");

	public static final MapCodec<ClipboardBlock> CODEC = method_54094(ClipboardBlock::new);

	public ClipboardBlock(class_2251 pProperties) {
		super(pProperties);
		method_9590(method_9564().method_11657(WATERLOGGED, false)
			.method_11657(WRITTEN, false));
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> pBuilder) {
		super.method_9515(pBuilder.method_11667(WRITTEN, field_11007, field_11177, WATERLOGGED));
	}

	@Override
	public class_2680 method_9605(class_1750 pContext) {
		class_2680 stateForPlacement = super.method_9605(pContext);
		if (stateForPlacement == null)
			return null;
		if (stateForPlacement.method_11654(field_11007) != class_2738.field_12471)
			stateForPlacement = stateForPlacement.method_11657(field_11177, stateForPlacement.method_11654(field_11177)
				.method_10153());
		return withWater(stateForPlacement, pContext).method_11657(WRITTEN, !ItemUtils.isComponentsPatchEmpty(pContext.method_8041()));
	}

	@Override
	public class_265 method_9530(class_2680 pState, class_1922 pLevel, class_2338 pPos, class_3726 pContext) {
		return (switch (pState.method_11654(field_11007)) {
		case field_12475 -> AllShapes.CLIPBOARD_FLOOR;
		case field_12473 -> AllShapes.CLIPBOARD_CEILING;
		default -> AllShapes.CLIPBOARD_WALL;
		}).get(pState.method_11654(field_11177));
	}

	public boolean method_9558(class_2680 pState, class_4538 pLevel, class_2338 pPos) {
		return !pLevel.method_8320(pPos.method_10093(method_10119(pState).method_10153()))
			.method_45474();
	}

	@Override
	protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
		if (player.method_5715()) {
			breakAndCollect(state, level, pos, player);
			return class_1269.field_5812;
		}

		return onBlockEntityUse(level, pos, cbe -> {
			if (level.method_8608())
				CatnipServices.PLATFORM.executeOnClientOnly(() -> () -> openScreen(player, cbe.dataContainer, pos));
			return class_1269.field_5812;
		});
	}

	@Environment(EnvType.CLIENT)
	private void openScreen(class_1657 player, class_1799 stack, class_2338 pos) {
		if (class_310.method_1551().field_1724 == player)
			ScreenOpener.open(new ClipboardScreen(player.method_31548().field_7545, stack, pos));
	}

	@Override
	public void method_9606(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_1657 pPlayer) {
		breakAndCollect(pState, pLevel, pPos, pPlayer);
	}

	private void breakAndCollect(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_1657 pPlayer) {
		if (pPlayer instanceof FakePlayer)
			return;
		if (pLevel.field_9236)
			return;
		class_1799 cloneItemStack = method_9574(pLevel, pPos, pState);
		pLevel.method_22352(pPos, false);
		if (pLevel.method_8320(pPos) != pState)
			pPlayer.method_31548()
				.method_7398(cloneItemStack);
	}

	@Override
	public class_1799 method_9574(class_4538 level, class_2338 pos, class_2680 state) {
		if (level.method_8321(pos) instanceof ClipboardBlockEntity cbe)
			return cbe.dataContainer;
		return new class_1799(this);
	}

	@Override
	public class_2680 method_9576(class_1937 pLevel, class_2338 pPos, class_2680 pState, class_1657 pPlayer) {
		if (!(pLevel.method_8321(pPos) instanceof ClipboardBlockEntity cbe))
			return pState;
		if (pLevel.field_9236 || pPlayer.method_7337())
			return pState;
		class_2248.method_9577(pLevel, pPos, cbe.dataContainer.method_7972());

		return pState;
	}

	@Override
	@SuppressWarnings("deprecation")
	public List<class_1799> method_9560(class_2680 pState, class_8567.class_8568 pBuilder) {
		if (!(pBuilder.method_51876(class_181.field_1228) instanceof ClipboardBlockEntity cbe))
			return super.method_9560(pState, pBuilder);
		pBuilder.method_51872(class_2480.field_11495, p_56219_ -> p_56219_.accept(cbe.dataContainer.method_7972()));
		return ImmutableList.of(cbe.dataContainer.method_7972());
	}

	@Override
	public class_3610 method_9545(class_2680 pState) {
		return fluidState(pState);
	}

	@Override
	public class_2680 method_9559(class_2680 pState, class_2350 pFacing, class_2680 pFacingState, class_1936 pLevel,
		class_2338 pCurrentPos, class_2338 pFacingPos) {
		updateWater(pLevel, pState, pCurrentPos);
		return super.method_9559(pState, pFacing, pFacingState, pLevel, pCurrentPos, pFacingPos);
	}

	@Override
	public Class<ClipboardBlockEntity> getBlockEntityClass() {
		return ClipboardBlockEntity.class;
	}

	@Override
	public class_2591<? extends ClipboardBlockEntity> getBlockEntityType() {
		return AllBlockEntityTypes.CLIPBOARD.get();
	}

	@Override
	protected @NotNull MapCodec<? extends class_2341> method_53969() {
		return field_46280;
	}
}
