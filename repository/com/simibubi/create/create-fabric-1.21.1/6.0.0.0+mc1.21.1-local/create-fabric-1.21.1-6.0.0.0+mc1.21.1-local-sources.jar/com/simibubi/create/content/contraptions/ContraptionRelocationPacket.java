package com.simibubi.create.content.contraptions;

import com.simibubi.create.AllPackets;
import net.createmod.catnip.net.base.ClientboundPacketPayload;

import io.netty.buffer.ByteBuf;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ContraptionRelocationPacket(int entityId) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, ContraptionRelocationPacket> STREAM_CODEC = class_9135.field_49675.method_56432(
			ContraptionRelocationPacket::new, ContraptionRelocationPacket::entityId
	);

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		OrientedContraptionEntity.handleRelocationPacket(this);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CONTRAPTION_RELOCATION;
	}
}
