package com.simibubi.create.content.decoration.bracket;

import com.simibubi.create.foundation.data.DirectionalAxisBlockStateGen;
import com.tterrag.registrate.builders.ItemBuilder;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;
import net.minecraft.class_1747;
import net.minecraft.class_2248;
import net.minecraft.class_2680;

public class BracketGenerator extends DirectionalAxisBlockStateGen {

	private String material;

	public BracketGenerator(String material) {
		this.material = material;
	}

	@Override
	public <T extends class_2248> String getModelPrefix(DataGenContext<class_2248, T> ctx, RegistrateBlockstateProvider prov,
		class_2680 state) {
		return "";
	}

	@Override
	public <T extends class_2248> ModelFile getModel(DataGenContext<class_2248, T> ctx, RegistrateBlockstateProvider prov,
												class_2680 state) {
		String type = state.method_11654(BracketBlock.TYPE)
			.method_15434();
		boolean vertical = state.method_11654(BracketBlock.field_10927)
			.method_10166()
			.method_10178();

		String path = "block/bracket/" + type + "/" + (vertical ? "ground" : "wall");

		return prov.models()
			.withExistingParent(path + "_" + material, prov.modLoc(path))
			.texture("bracket", prov.modLoc("block/bracket_" + material))
			.texture("plate", prov.modLoc("block/bracket_plate_" + material));
	}

	public static <I extends class_1747, P> NonNullFunction<ItemBuilder<I, P>, P> itemModel(String material) {
		return b -> b.model((c, p) -> p.withExistingParent(c.getName(), p.modLoc("block/bracket/item"))
			.texture("bracket", p.modLoc("block/bracket_" + material))
			.texture("plate", p.modLoc("block/bracket_plate_" + material)))
			.build();
	}

}
