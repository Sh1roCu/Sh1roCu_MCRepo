package com.simibubi.create.content.contraptions;

import static net.createmod.catnip.math.AngleHelper.angleLerp;

import java.util.Optional;
import java.util.UUID;

import javax.annotation.Nullable;
import com.simibubi.create.AllAttachmentTypes;
import com.simibubi.create.AllEntityTypes;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorageWrapper;
import com.simibubi.create.content.contraptions.bearing.StabilizedContraption;
import com.simibubi.create.content.contraptions.minecart.MinecartSim2020;
import com.simibubi.create.content.contraptions.minecart.capability.CapabilityMinecartController;
import com.simibubi.create.content.contraptions.minecart.capability.MinecartController;
import com.simibubi.create.content.contraptions.mounted.CartAssemblerBlockEntity.CartMovementMode;
import com.simibubi.create.content.contraptions.mounted.MountedContraption;
import com.simibubi.create.foundation.item.ItemHelper;
import com.simibubi.create.foundation.mixin.accessor.MinecartFurnaceAccessor;

import dev.engine_room.flywheel.lib.transform.TransformStack;

import io.github.fabricators_of_create.porting_lib.util.MinecartAndRailUtil;

import net.createmod.catnip.data.Couple;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.math.VecHelper;
import net.createmod.catnip.nbt.NBTHelper;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1688;
import net.minecraft.class_1696;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2241;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_310;
import net.minecraft.class_3481;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7225;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import io.github.fabricators_of_create.porting_lib.util.MinecartAndRailUtil;


/**
 * Ex: Minecarts, Couplings <br>
 * Oriented Contraption Entities can rotate freely around two axes
 * simultaneously.
 */
public class OrientedContraptionEntity extends AbstractContraptionEntity {

	private static final class_1856 FUEL_ITEMS = class_1856.method_8091(class_1802.field_8713, class_1802.field_8665);

	private static final class_2940<Optional<UUID>> COUPLING =
		class_2945.method_12791(OrientedContraptionEntity.class, class_2943.field_13313);
	private static final class_2940<class_2350> INITIAL_ORIENTATION =
		class_2945.method_12791(OrientedContraptionEntity.class, class_2943.field_13321);

	protected class_243 motionBeforeStall;
	protected boolean forceAngle;
	private boolean attachedExtraInventories;
	private boolean manuallyPlaced;

	public float prevYaw;
	public float yaw;
	public float targetYaw;

	public float prevPitch;
	public float pitch;

	public int nonDamageTicks;

	public OrientedContraptionEntity(class_1299<?> type, class_1937 world) {
		super(type, world);
		motionBeforeStall = class_243.field_1353;
		attachedExtraInventories = false;
		nonDamageTicks = 10;
	}

	public static OrientedContraptionEntity create(class_1937 world, Contraption contraption, class_2350 initialOrientation) {
		OrientedContraptionEntity entity =
			new OrientedContraptionEntity(AllEntityTypes.ORIENTED_CONTRAPTION.get(), world);
		entity.setContraption(contraption);
		entity.setInitialOrientation(initialOrientation);
		entity.startAtInitialYaw();
		return entity;
	}

	public static OrientedContraptionEntity createAtYaw(class_1937 world, Contraption contraption,
														class_2350 initialOrientation, float initialYaw) {
		OrientedContraptionEntity entity = create(world, contraption, initialOrientation);
		entity.startAtYaw(initialYaw);
		entity.manuallyPlaced = true;
		return entity;
	}

	public void setInitialOrientation(class_2350 direction) {
		field_6011.method_12778(INITIAL_ORIENTATION, direction);
	}

	public class_2350 getInitialOrientation() {
		return field_6011.method_12789(INITIAL_ORIENTATION);
	}

	@Override
	public float getYawOffset() {
		return getInitialYaw();
	}

	public float getInitialYaw() {
		return (isInitialOrientationPresent() ? field_6011.method_12789(INITIAL_ORIENTATION) : class_2350.field_11035).method_10144();
	}

	@Override
	protected void method_5693(class_2945.class_9222 builder) {
		super.method_5693(builder);
		builder.method_56912(COUPLING, Optional.empty());
		builder.method_56912(INITIAL_ORIENTATION, class_2350.field_11036);
	}

	@Override
	public ContraptionRotationState getRotationState() {
		ContraptionRotationState crs = new ContraptionRotationState();

		float yawOffset = getYawOffset();
		crs.zRotation = pitch;
		crs.yRotation = -yaw + yawOffset;

		if (pitch != 0 && yaw != 0) {
			crs.secondYRotation = -yaw;
			crs.yRotation = yawOffset;
		}

		return crs;
	}

	@Override
	public void method_5650(class_5529 p_146834_) {
		super.method_5650(p_146834_);
	}

	@Override
	public void method_5848() {
		if (!method_37908().field_9236 && method_5805())
			disassemble();
		super.method_5848();
	}

	@Override
	protected void readAdditional(class_2487 compound, boolean spawnPacket) {
		super.readAdditional(compound, spawnPacket);

		if (compound.method_10545("InitialOrientation"))
			setInitialOrientation(NBTHelper.readEnum(compound, "InitialOrientation", class_2350.class));

		yaw = compound.method_10583("Yaw");
		pitch = compound.method_10583("Pitch");
		manuallyPlaced = compound.method_10577("Placed");

		if (compound.method_10545("ForceYaw"))
			startAtYaw(compound.method_10583("ForceYaw"));

		class_2499 vecNBT = compound.method_10554("CachedMotion", 6);
		if (!vecNBT.isEmpty()) {
			motionBeforeStall = new class_243(vecNBT.method_10611(0), vecNBT.method_10611(1), vecNBT.method_10611(2));
			if (!motionBeforeStall.equals(class_243.field_1353))
				targetYaw = prevYaw = yaw += yawFromVector(motionBeforeStall);
			method_18799(class_243.field_1353);
		}

		setCouplingId(compound.method_10545("OnCoupling") ? compound.method_25926("OnCoupling") : null);
	}

	@Override
	protected void writeAdditional(class_2487 compound, class_7225.class_7874 registries, boolean spawnPacket) {
		super.writeAdditional(compound, registries, spawnPacket);

		if (motionBeforeStall != null)
			compound.method_10566("CachedMotion", method_5846(motionBeforeStall.field_1352, motionBeforeStall.field_1351, motionBeforeStall.field_1350));

		class_2350 optional = field_6011.method_12789(INITIAL_ORIENTATION);
		if (optional.method_10166()
			.method_10179())
			NBTHelper.writeEnum(compound, "InitialOrientation", optional);
		if (forceAngle) {
			compound.method_10548("ForceYaw", yaw);
			forceAngle = false;
		}

		compound.method_10556("Placed", manuallyPlaced);
		compound.method_10548("Yaw", yaw);
		compound.method_10548("Pitch", pitch);

		if (getCouplingId() != null)
			compound.method_25927("OnCoupling", getCouplingId());
	}

	@Override
	public void method_5674(class_2940<?> key) {
		super.method_5674(key);
		if (INITIAL_ORIENTATION.equals(key) && isInitialOrientationPresent() && !manuallyPlaced)
			startAtInitialYaw();
	}

	public boolean isInitialOrientationPresent() {
		return field_6011.method_12789(INITIAL_ORIENTATION)
			.method_10166()
			.method_10179();
	}

	public void startAtInitialYaw() {
		startAtYaw(getInitialYaw());
	}

	public void startAtYaw(float yaw) {
		targetYaw = this.yaw = prevYaw = yaw;
		forceAngle = true;
	}

	@Override
	public class_243 applyRotation(class_243 localPos, float partialTicks) {
		localPos = VecHelper.rotate(localPos, getInitialYaw(), class_2351.field_11052);
		localPos = VecHelper.rotate(localPos, method_5695(partialTicks), class_2351.field_11051);
		localPos = VecHelper.rotate(localPos, method_5705(partialTicks), class_2351.field_11052);
		return localPos;
	}

	@Override
	public class_243 reverseRotation(class_243 localPos, float partialTicks) {
		localPos = VecHelper.rotate(localPos, -method_5705(partialTicks), class_2351.field_11052);
		localPos = VecHelper.rotate(localPos, -method_5695(partialTicks), class_2351.field_11051);
		localPos = VecHelper.rotate(localPos, -getInitialYaw(), class_2351.field_11052);
		return localPos;
	}

	public float method_5705(float partialTicks) {
		return -(partialTicks == 1.0F ? yaw : angleLerp(partialTicks, prevYaw, yaw));
	}

	public float method_5695(float partialTicks) {
		return partialTicks == 1.0F ? pitch : angleLerp(partialTicks, prevPitch, pitch);
	}

	@Override
	protected void tickContraption() {
		if (nonDamageTicks > 0)
			nonDamageTicks--;
		class_1297 e = method_5854();
		if (e == null)
			return;

		boolean rotationLock = false;
		boolean pauseWhileRotating = false;
		boolean wasStalled = isStalled();
		if (contraption instanceof MountedContraption mountedContraption) {
			rotationLock = mountedContraption.rotationMode == CartMovementMode.ROTATION_LOCKED;
			pauseWhileRotating = mountedContraption.rotationMode == CartMovementMode.ROTATE_PAUSED;
		}

		class_1297 riding = e;
		while (riding.method_5854() != null && !(contraption instanceof StabilizedContraption))
			riding = riding.method_5854();

		boolean isOnCoupling = false;
		UUID couplingId = getCouplingId();
		isOnCoupling = couplingId != null && riding instanceof class_1688;

		if (!attachedExtraInventories) {
			attachInventoriesFromRidingCarts(riding, isOnCoupling, couplingId);
			attachedExtraInventories = true;
		}

		boolean rotating = updateOrientation(rotationLock, wasStalled, riding, isOnCoupling);
		if (!rotating || !pauseWhileRotating)
			tickActors();
		boolean isStalled = isStalled();

		MinecartController capability = null;
		if(riding instanceof class_1688 minecart)
			capability = minecart.create$getController();

		if (capability != null) {
			if (!method_37908().method_8608())
				capability.setStalledExternally(isStalled);
		} else {
			if (isStalled) {
				if (!wasStalled)
					motionBeforeStall = riding.method_18798();
				riding.method_18800(0, 0, 0);
			}
			if (wasStalled && !isStalled) {
				riding.method_18799(motionBeforeStall);
				motionBeforeStall = class_243.field_1353;
			}
		}

		if (method_37908().field_9236)
			return;

		if (!isStalled()) {
			if (isOnCoupling) {
				Couple<MinecartController> coupledCarts = getCoupledCartsIfPresent();
				if (coupledCarts == null)
					return;
				coupledCarts.map(MinecartController::cart)
					.forEach(this::powerFurnaceCartWithFuelFromStorage);
				return;
			}
			powerFurnaceCartWithFuelFromStorage(riding);
		}
	}

	protected boolean updateOrientation(boolean rotationLock, boolean wasStalled, class_1297 riding, boolean isOnCoupling) {
		if (isOnCoupling) {
			Couple<MinecartController> coupledCarts = getCoupledCartsIfPresent();
			if (coupledCarts == null)
				return false;

			class_243 positionVec = coupledCarts.getFirst()
				.cart()
				.method_19538();
			class_243 coupledVec = coupledCarts.getSecond()
				.cart()
				.method_19538();

			double diffX = positionVec.field_1352 - coupledVec.field_1352;
			double diffY = positionVec.field_1351 - coupledVec.field_1351;
			double diffZ = positionVec.field_1350 - coupledVec.field_1350;

			prevYaw = yaw;
			prevPitch = pitch;
			yaw = (float) (class_3532.method_15349(diffZ, diffX) * 180 / Math.PI);
			pitch = (float) (Math.atan2(diffY, Math.sqrt(diffX * diffX + diffZ * diffZ)) * 180 / Math.PI);

			if (getCouplingId().equals(riding.method_5667())) {
				pitch *= -1;
				yaw += 180;
			}
			return false;
		}

		if (contraption instanceof StabilizedContraption stabilized) {
			if (!(riding instanceof OrientedContraptionEntity parent))
				return false;
			class_2350 facing = stabilized.getFacing();
			if (facing.method_10166()
				.method_10178())
				return false;
			prevYaw = yaw;
			yaw = AngleHelper.wrapAngle180(getInitialYaw() - parent.getInitialYaw()) - parent.method_5705(1);
			return false;
		}

		prevYaw = yaw;
		if (wasStalled)
			return false;

		boolean rotating = false;
		class_243 movementVector = riding.method_18798();
		class_243 locationDiff = riding.method_19538()
			.method_1023(riding.field_6014, riding.field_6036, riding.field_5969);
		if (!(riding instanceof class_1688))
			movementVector = locationDiff;
		class_243 motion = movementVector.method_1029();

		if (!rotationLock) {
			if (riding instanceof class_1688 minecartEntity) {
				class_2338 railPosition = minecartEntity.getCurrentRailPos();
				class_2680 blockState = method_37908().method_8320(railPosition);
				if (blockState.method_26204() instanceof class_2241 abstractRailBlock) {
					class_2768 railDirection =
						MinecartAndRailUtil.getDirectionOfRail(blockState, method_37908(), railPosition, abstractRailBlock);
					motion = VecHelper.project(motion, MinecartSim2020.getRailVec(railDirection));
				}
			}

			if (motion.method_1033() > 0) {
				targetYaw = yawFromVector(motion);
				if (targetYaw < 0)
					targetYaw += 360;
				if (yaw < 0)
					yaw += 360;
			}

			prevYaw = yaw;
			float maxApproachSpeed = (float) (motion.method_1033() * 12f / (Math.max(1, method_5829().method_17939() / 6f)));
			float yawHint = AngleHelper.getShortestAngleDiff(yaw, yawFromVector(locationDiff));
			float approach = AngleHelper.getShortestAngleDiff(yaw, targetYaw, yawHint);
			approach = class_3532.method_15363(approach, -maxApproachSpeed, maxApproachSpeed);
			yaw += approach;
			if (Math.abs(AngleHelper.getShortestAngleDiff(yaw, targetYaw)) < 1f)
				yaw = targetYaw;
			else
				rotating = true;
		}
		return rotating;
	}

	protected void powerFurnaceCartWithFuelFromStorage(class_1297 riding) {
		if (!(riding instanceof class_1696 furnaceCart))
			return;
		if (!(riding instanceof MinecartFurnaceAccessor furnaceCartAccessor))
			return;

		int fuel = furnaceCartAccessor.create$getFuel();
		int fuelBefore = fuel;
		double pushX = furnaceCart.field_7737;
		double pushZ = furnaceCart.field_7736;

		int i = class_3532.method_15357(furnaceCart.method_23317());
		int j = class_3532.method_15357(furnaceCart.method_23318());
		int k = class_3532.method_15357(furnaceCart.method_23321());
		if (furnaceCart.method_37908().method_8320(new class_2338(i, j - 1, k))
			.method_26164(class_3481.field_15463))
			--j;

		class_2338 blockpos = new class_2338(i, j, k);
		class_2680 blockstate = this.method_37908().method_8320(blockpos);
		if (blockstate.method_26164(class_3481.field_15463))
			if (fuel > 1)
				riding.method_18799(riding.method_18798()
					.method_1029()
					.method_1021(1));
		if (fuel < 5 && contraption != null) {
			MountedItemStorageWrapper fuelItems = contraption.getStorage().getFuelItems();
			if (fuelItems != null) {
				class_1799 coal = ItemHelper.extract(fuelItems, FUEL_ITEMS, 1, false);
				if (!coal.method_7960())
					fuel += 3600;
			}
		}

		if (fuel != fuelBefore || pushX != 0 || pushZ != 0) {
			furnaceCart.field_7737 = pushX;
			furnaceCart.field_7736 = pushZ;
			furnaceCartAccessor.create$setFuel(fuel);
		}
	}

	@Nullable
	public Couple<MinecartController> getCoupledCartsIfPresent() {
		UUID couplingId = getCouplingId();
		if (couplingId == null)
			return null;
		MinecartController controller = CapabilityMinecartController.getIfPresent(method_37908(), couplingId);
		if (controller == null || !controller.isPresent())
			return null;
		UUID coupledCart = controller.getCoupledCart(true);
		MinecartController coupledController = CapabilityMinecartController.getIfPresent(method_37908(), coupledCart);
		if (coupledController == null || !coupledController.isPresent())
			return null;
		return Couple.create(controller, coupledController);
	}

	protected void attachInventoriesFromRidingCarts(class_1297 riding, boolean isOnCoupling, UUID couplingId) {
		if (!(contraption instanceof MountedContraption mc))
			return;
		if (!isOnCoupling) {
			mc.addExtraInventories(riding);
			return;
		}
		Couple<MinecartController> coupledCarts = getCoupledCartsIfPresent();
		if (coupledCarts == null)
			return;
		coupledCarts.map(MinecartController::cart)
			.forEach(mc::addExtraInventories);
	}

	@Nullable
	public UUID getCouplingId() {
		Optional<UUID> uuid = field_6011.method_12789(COUPLING);
		return uuid == null ? null : uuid.isPresent() ? uuid.get() : null;
	}

	public void setCouplingId(UUID id) {
		field_6011.method_12778(COUPLING, Optional.ofNullable(id));
	}

	@Override
	public class_243 method_55668(class_1297 entity) {
		return entity instanceof AbstractContraptionEntity ? class_243.field_1353 : new class_243(0, 0.19, 0);
	}

	@Override
	public class_243 getAnchorVec() {
		class_243 anchorVec = super.getAnchorVec();
		return anchorVec.method_1023(.5, 0, .5);
	}

	@Override
	public class_243 getPrevAnchorVec() {
		class_243 prevAnchorVec = super.getPrevAnchorVec();
		return prevAnchorVec.method_1023(.5, 0, .5);
	}

	@Override
	protected StructureTransform makeStructureTransform() {
		class_2338 offset = class_2338.method_49638(getAnchorVec().method_1031(.5, .5, .5));
		return new StructureTransform(offset, 0, -yaw + getInitialYaw(), 0);
	}

	@Override
	protected float getStalledAngle() {
		return yaw;
	}

	@Override
	protected void handleStallInformation(double x, double y, double z, float angle) {
		yaw = angle;
	}

	@Override
	@Environment(EnvType.CLIENT)
	public void applyLocalTransforms(class_4587 matrixStack, float partialTicks) {
		float angleInitialYaw = getInitialYaw();
		float angleYaw = method_5705(partialTicks);
		float anglePitch = method_5695(partialTicks);

		matrixStack.method_46416(-.5f, 0, -.5f);

		class_1297 ridingEntity = method_5854();
		if (ridingEntity instanceof class_1688)
			repositionOnCart(matrixStack, partialTicks, ridingEntity);
		else if (ridingEntity instanceof AbstractContraptionEntity) {
			if (ridingEntity.method_5854() instanceof class_1688)
				repositionOnCart(matrixStack, partialTicks, ridingEntity.method_5854());
			else
				repositionOnContraption(matrixStack, partialTicks, ridingEntity);
		}

		TransformStack.of(matrixStack)
			.nudge(method_5628())
			.center()
			.rotateYDegrees(angleYaw)
			.rotateZDegrees(anglePitch)
			.rotateYDegrees(angleInitialYaw)
			.uncenter();
	}

	@Environment(EnvType.CLIENT)
	private void repositionOnContraption(class_4587 matrixStack, float partialTicks, class_1297 ridingEntity) {
		class_243 pos = getContraptionOffset(partialTicks, ridingEntity);
		matrixStack.method_22904(pos.field_1352, pos.field_1351, pos.field_1350);
	}

	// Minecarts do not always render at their exact location, so the contraption
	// has to adjust aswell
	@Environment(EnvType.CLIENT)
	private void repositionOnCart(class_4587 matrixStack, float partialTicks, class_1297 ridingEntity) {
		class_243 cartPos = getCartOffset(partialTicks, ridingEntity);

		if (cartPos == class_243.field_1353)
			return;

		matrixStack.method_22904(cartPos.field_1352, cartPos.field_1351, cartPos.field_1350);
	}

	@Environment(EnvType.CLIENT)
	private class_243 getContraptionOffset(float partialTicks, class_1297 ridingEntity) {
		AbstractContraptionEntity parent = (AbstractContraptionEntity) ridingEntity;
		class_243 passengerPosition = parent.getPassengerPosition(this, partialTicks);
		if (passengerPosition == null)
			return class_243.field_1353;

		double x = passengerPosition.field_1352 - class_3532.method_16436(partialTicks, this.field_6038, this.method_23317());
		double y = passengerPosition.field_1351 - class_3532.method_16436(partialTicks, this.field_5971, this.method_23318());
		double z = passengerPosition.field_1350 - class_3532.method_16436(partialTicks, this.field_5989, this.method_23321());

		return new class_243(x, y, z);
	}

	@Environment(EnvType.CLIENT)
	private class_243 getCartOffset(float partialTicks, class_1297 ridingEntity) {
		class_1688 cart = (class_1688) ridingEntity;
		double cartX = class_3532.method_16436(partialTicks, cart.field_6038, cart.method_23317());
		double cartY = class_3532.method_16436(partialTicks, cart.field_5971, cart.method_23318());
		double cartZ = class_3532.method_16436(partialTicks, cart.field_5989, cart.method_23321());
		class_243 cartPos = cart.method_7508(cartX, cartY, cartZ);

		if (cartPos != null) {
			class_243 cartPosFront = cart.method_7505(cartX, cartY, cartZ, (double) 0.3F);
			class_243 cartPosBack = cart.method_7505(cartX, cartY, cartZ, (double) -0.3F);
			if (cartPosFront == null)
				cartPosFront = cartPos;
			if (cartPosBack == null)
				cartPosBack = cartPos;

			cartX = cartPos.field_1352 - cartX;
			cartY = (cartPosFront.field_1351 + cartPosBack.field_1351) / 2.0D - cartY;
			cartZ = cartPos.field_1350 - cartZ;

			return new class_243(cartX, cartY, cartZ);
		}

		return class_243.field_1353;
	}

	@Environment(EnvType.CLIENT)
	public static void handleRelocationPacket(ContraptionRelocationPacket packet) {
		if (class_310.method_1551().field_1687.method_8469(packet.entityId()) instanceof OrientedContraptionEntity oce)
			oce.nonDamageTicks = 10;
	}
}
