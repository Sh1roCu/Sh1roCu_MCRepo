package com.simibubi.create.content.decoration.girder;

import java.util.Arrays;
import java.util.function.Supplier;

import com.simibubi.create.AllPartialModels;
import com.simibubi.create.foundation.block.connected.CTModel;

import net.createmod.catnip.data.Iterate;

import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;

public class ConnectedGirderModel extends CTModel {

	public ConnectedGirderModel(class_1087 originalModel) {
		super(originalModel, new GirderCTBehaviour());
	}

	@Override
	public void emitBlockQuads(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context) {
		ConnectionData data = new ConnectionData();
		for (class_2350 d : Iterate.horizontalDirections)
			data.setConnected(d, GirderBlock.isConnected(blockView, pos, state, d));

		super.emitBlockQuads(blockView, state, pos, randomSupplier, context);

		for (class_2350 d : Iterate.horizontalDirections)
			if (data.isConnected(d))
				((FabricBakedModel) AllPartialModels.METAL_GIRDER_BRACKETS.get(d)
					.get())
					.emitBlockQuads(blockView, state, pos, randomSupplier, context);
	}

	private static class ConnectionData {
		boolean[] connectedFaces;

		public ConnectionData() {
			connectedFaces = new boolean[4];
			Arrays.fill(connectedFaces, false);
		}

		void setConnected(class_2350 face, boolean connected) {
			connectedFaces[face.method_10161()] = connected;
		}

		boolean isConnected(class_2350 face) {
			return connectedFaces[face.method_10161()];
		}
	}

}
