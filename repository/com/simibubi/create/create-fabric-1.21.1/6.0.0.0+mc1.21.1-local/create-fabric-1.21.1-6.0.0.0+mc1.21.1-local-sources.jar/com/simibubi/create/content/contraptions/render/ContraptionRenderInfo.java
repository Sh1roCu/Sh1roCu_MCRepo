package com.simibubi.create.content.contraptions.render;

import org.apache.commons.lang3.tuple.Pair;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.Contraption.RenderedBlocks;
import com.simibubi.create.content.contraptions.ContraptionWorld;
import com.simibubi.create.foundation.render.fabric.LayerFilteringBakedModel;
import com.simibubi.create.foundation.virtualWorld.VirtualRenderWorld;

import dev.engine_room.flywheel.api.visualization.VisualizationManager;
import net.createmod.catnip.render.ShadedBlockSbbBuilder;
import net.createmod.catnip.render.SuperByteBuffer;
import net.createmod.catnip.render.SuperByteBufferCache;
import net.minecraft.class_1087;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3499;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_4696;
import net.minecraft.class_5819;
import net.minecraft.class_776;
import net.minecraft.class_778;

public class ContraptionRenderInfo {
	public static final SuperByteBufferCache.Compartment<Pair<Contraption, class_1921>> CONTRAPTION = new SuperByteBufferCache.Compartment<>();
	private static final ThreadLocal<ThreadLocalObjects> THREAD_LOCAL_OBJECTS = ThreadLocal.withInitial(ThreadLocalObjects::new);

	private final Contraption contraption;
	private final VirtualRenderWorld renderWorld;
	private final ContraptionMatrices matrices = new ContraptionMatrices();

	ContraptionRenderInfo(class_1937 level, Contraption contraption) {
		this.contraption = contraption;
		this.renderWorld = setupRenderWorld(level, contraption);
	}

	public static ContraptionRenderInfo get(Contraption contraption) {
		return ContraptionRenderInfoManager.MANAGERS.get(contraption.entity.method_37908()).getRenderInfo(contraption);
	}

	/**
	 * Reset a contraption's renderer.
	 *
	 * @param contraption The contraption to invalidate.
	 * @return true if there was a renderer associated with the given contraption.
	 */
	public static boolean invalidate(Contraption contraption) {
		return ContraptionRenderInfoManager.MANAGERS.get(contraption.entity.method_37908()).invalidate(contraption);
	}

	public boolean isDead() {
		return !contraption.entity.isAliveOrStale();
	}

	public Contraption getContraption() {
		return contraption;
	}

	public VirtualRenderWorld getRenderWorld() {
		return renderWorld;
	}

	public ContraptionMatrices getMatrices() {
		return matrices;
	}

	public SuperByteBuffer getBuffer(class_1921 renderType) {
		return SuperByteBufferCache.getInstance().get(CONTRAPTION, Pair.of(contraption, renderType), () -> buildStructureBuffer(renderType));
	}

	public void invalidate() {
		for (class_1921 renderType : class_1921.method_22720()) {
			SuperByteBufferCache.getInstance().invalidate(CONTRAPTION, Pair.of(contraption, renderType));
		}
	}

	public static VirtualRenderWorld setupRenderWorld(class_1937 level, Contraption c) {
		ContraptionWorld contraptionWorld = c.getContraptionWorld();

		class_2338 origin = c.anchor;
		int minBuildHeight = contraptionWorld.method_31607();
		int height = contraptionWorld.method_31605();
		VirtualRenderWorld renderWorld = new VirtualRenderWorld(level, minBuildHeight, height, origin) {
			@Override
			public boolean supportsVisualization() {
				return VisualizationManager.supportsVisualization(level);
			}
		};

		renderWorld.setBlockEntities(c.presentBlockEntities.values());
		for (class_3499.class_3501 info : c.getBlocks()
			.values())
			renderWorld.method_8652(info.comp_1341(), info.comp_1342(), 0);

		renderWorld.runLightEngine();
		return renderWorld;
	}

	private SuperByteBuffer buildStructureBuffer(class_1921 layer) {
		class_776 dispatcher = class_310.method_1551().method_1541();
		class_778 renderer = dispatcher.method_3350();
		ThreadLocalObjects objects = THREAD_LOCAL_OBJECTS.get();

		class_4587 poseStack = objects.poseStack;
		class_5819 random = objects.random;
		RenderedBlocks blocks = contraption.getRenderedBlocks();

		ShadedBlockSbbBuilder sbbBuilder = objects.sbbBuilder;
		sbbBuilder.begin();

		class_778.method_20544();
		for (class_2338 pos : blocks.positions()) {
			class_2680 state = blocks.lookup().apply(pos);
			if (state.method_26217() == class_2464.field_11458) {
				class_1087 model = dispatcher.method_3349(state);
				if (model.isVanillaAdapter()) {
					if (class_4696.method_23679(state) != layer) {
						model = null;
					}
				} else {
					model = LayerFilteringBakedModel.wrap(model, layer);
				}
				if (model != null) {
					// FIXME HIGH LOGISTICS
//					model = shadeSeparatingWrapper.wrapModel(model);
					dispatcher.method_3350()
							.method_3374(renderWorld, model, state, pos, poseStack, sbbBuilder, true, random, state.method_26190(pos), class_4608.field_21444);
				}
			}
		}
		class_778.method_20545();

		return sbbBuilder.end();
	}

	private static class ThreadLocalObjects {
		public final class_4587 poseStack = new class_4587();
		public final class_5819 random = class_5819.method_43053();
		public final ShadedBlockSbbBuilder sbbBuilder = ShadedBlockSbbBuilder.create();
	}
}
