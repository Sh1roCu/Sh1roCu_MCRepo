package com.simibubi.create.content.contraptions.actors.psi;

import java.util.List;

import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.foundation.advancement.AllAdvancements;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.infrastructure.config.AllConfigs;

import net.createmod.catnip.animation.LerpedFloat;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_7225;
import io.github.fabricators_of_create.porting_lib.block.CustomRenderBoundingBoxBlockEntity;

public abstract class PortableStorageInterfaceBlockEntity extends SmartBlockEntity implements CustomRenderBoundingBoxBlockEntity {

	public static final int ANIMATION = 4;
	protected int transferTimer;
	protected float distance;
	protected LerpedFloat connectionAnimation;
	protected boolean powered;
	protected class_1297 connectedEntity;

	public int keepAlive = 0;

	public PortableStorageInterfaceBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		transferTimer = 0;
		connectionAnimation = LerpedFloat.linear()
			.startWithValue(0);
		powered = false;
	}

	public void startTransferringTo(Contraption contraption, float distance) {
		if (connectedEntity == contraption.entity)
			return;
		this.distance = Math.min(2, distance);
		connectedEntity = contraption.entity;
		startConnecting();
		notifyUpdate();
	}

	protected void stopTransferring() {
		connectedEntity = null;
		field_11863.method_8452(field_11867, method_11010().method_26204());
	}

	public boolean canTransfer() {
		if (connectedEntity != null && !connectedEntity.method_5805())
			stopTransferring();
		return connectedEntity != null && isConnected();
	}

	@Override
	public void initialize() {
		super.initialize();
		powered = field_11863.method_49803(field_11867);
		if (!powered)
			notifyContraptions();
	}

	protected abstract void invalidateCapability();

	@Override
	public void tick() {
		super.tick();
		boolean wasConnected = isConnected();
		int timeUnit = getTransferTimeout();
		int animation = ANIMATION;

		if (keepAlive > 0) {
			keepAlive--;
			if (keepAlive == 0 && !field_11863.field_9236) {
				stopTransferring();
				transferTimer = ANIMATION - 1;
				sendData();
				return;
			}
		}

		transferTimer = Math.min(transferTimer, ANIMATION * 2 + timeUnit);

		boolean timerCanDecrement = transferTimer > ANIMATION || transferTimer > 0 && keepAlive == 0
			&& (isVirtual() || !field_11863.field_9236 || transferTimer != ANIMATION);

		if (timerCanDecrement && (!isVirtual() || transferTimer != ANIMATION)) {
			transferTimer--;
			if (transferTimer == ANIMATION - 1)
				sendData();
			if (transferTimer <= 0 || powered)
				stopTransferring();
		}

		boolean isConnected = isConnected();
		if (wasConnected != isConnected && !field_11863.field_9236)
			method_5431();

		float progress = 0;
		if (isConnected)
			progress = 1;
		else if (transferTimer >= timeUnit + animation)
			progress = class_3532.method_16439((transferTimer - timeUnit - animation) / (float) animation, 1, 0);
		else if (transferTimer < animation)
			progress = class_3532.method_16439(transferTimer / (float) animation, 0, 1);
		connectionAnimation.setValue(progress);
	}

	@Override
	public void invalidate() {
		super.invalidate();
		invalidateCapability();
	}

	@Override
	protected void read(class_2487 compound, class_7225.class_7874 registries, boolean clientPacket) {
		super.read(compound, registries, clientPacket);
		transferTimer = compound.method_10550("Timer");
		distance = compound.method_10583("Distance");
		boolean poweredPreviously = powered;
		powered = compound.method_10577("Powered");
		if (clientPacket && powered != poweredPreviously && !powered)
			notifyContraptions();
	}

	@Override
	protected void write(class_2487 compound, class_7225.class_7874 registries, boolean clientPacket) {
		super.write(compound, registries, clientPacket);
		compound.method_10569("Timer", transferTimer);
		compound.method_10548("Distance", distance);
		compound.method_10556("Powered", powered);
	}

	public void neighbourChanged() {
		boolean isBlockPowered = field_11863.method_49803(field_11867);
		if (isBlockPowered == powered)
			return;
		powered = isBlockPowered;
		if (!powered)
			notifyContraptions();
		if (powered)
			stopTransferring();
		sendData();
	}

	private void notifyContraptions() {
		field_11863.method_18467(AbstractContraptionEntity.class, new class_238(field_11867).method_1014(3))
			.forEach(AbstractContraptionEntity::refreshPSIs);
	}

	public boolean isPowered() {
		return powered;
	}

	@Override
	protected class_238 createRenderBoundingBox() {
		return super.createRenderBoundingBox().method_1014(2);
	}

	public boolean isTransferring() {
		return transferTimer > ANIMATION;
	}

	boolean isConnected() {
		int timeUnit = getTransferTimeout();
		return transferTimer >= ANIMATION && transferTimer <= timeUnit + ANIMATION;
	}

	float getExtensionDistance(float partialTicks) {
		return (float) (Math.pow(connectionAnimation.getValue(partialTicks), 2) * distance / 2);
	}

	float getConnectionDistance() {
		return distance;
	}

	public void startConnecting() {
		transferTimer = 6 + ANIMATION * 2;
	}

	public void onContentTransferred() {
		int timeUnit = getTransferTimeout();
		transferTimer = timeUnit + ANIMATION;
		award(AllAdvancements.PSI);
		sendData();
	}

	protected Integer getTransferTimeout() {
		return AllConfigs.server().logistics.psiTimeout.get();
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
		registerAwardables(behaviours, AllAdvancements.PSI);
	}

}
