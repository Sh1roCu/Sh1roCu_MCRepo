package com.simibubi.create.api.schematic.nbt;

import net.minecraft.class_2487;
import net.minecraft.class_7225;

public interface PartialSafeNBT {
	/**
	 * This will always be called from the logical server
	 */
	void writeSafe(class_2487 compound, class_7225.class_7874 registries);
}
