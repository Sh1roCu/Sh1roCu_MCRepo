package com.simibubi.create;

import com.simibubi.create.api.contraption.ContraptionMovementSetting;
import com.simibubi.create.infrastructure.config.AllConfigs;
import net.minecraft.class_2246;

public class AllContraptionMovementSettings {
	public static void registerDefaults() {
		ContraptionMovementSetting.REGISTRY.register(class_2246.field_10260, () -> AllConfigs.server().kinetics.spawnerMovement.get());
		ContraptionMovementSetting.REGISTRY.register(class_2246.field_27160, () -> AllConfigs.server().kinetics.amethystMovement.get());
		ContraptionMovementSetting.REGISTRY.register(class_2246.field_10540, () -> AllConfigs.server().kinetics.obsidianMovement.get());
		ContraptionMovementSetting.REGISTRY.register(class_2246.field_22423, () -> AllConfigs.server().kinetics.obsidianMovement.get());
		ContraptionMovementSetting.REGISTRY.register(class_2246.field_23152, () -> AllConfigs.server().kinetics.obsidianMovement.get());
		ContraptionMovementSetting.REGISTRY.register(class_2246.field_38420, () -> AllConfigs.server().kinetics.reinforcedDeepslateMovement.get());
	}
}
