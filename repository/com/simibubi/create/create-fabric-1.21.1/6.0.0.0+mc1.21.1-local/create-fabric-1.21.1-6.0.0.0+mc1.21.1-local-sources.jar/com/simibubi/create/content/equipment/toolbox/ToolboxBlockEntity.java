package com.simibubi.create.content.equipment.toolbox;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;

import io.netty.buffer.Unpooled;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllDataComponents;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.animatedContainer.AnimatedContainerBehaviour;
import com.simibubi.create.foundation.item.ItemHelper;
import com.simibubi.create.foundation.utility.ResetableLazy;

import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.catnip.animation.LerpedFloat.Chaser;
import net.createmod.catnip.math.VecHelper;

import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.item.PlayerInventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SidedStorageBlockEntity;

import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1275;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3908;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9288;
import net.minecraft.class_9323.class_9324;
import net.minecraft.class_9334;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.item.PlayerInventoryStorage;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SidedStorageBlockEntity;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;

import com.simibubi.create.infrastructure.fabric.transfer.TransferUtil;
import com.simibubi.create.infrastructure.fabric.transfer.item.ItemStackHandler;

import org.jetbrains.annotations.Nullable;

public class ToolboxBlockEntity extends SmartBlockEntity implements class_3908, class_1275, SidedStorageBlockEntity, ExtendedScreenHandlerFactory<class_9129> {

	public LerpedFloat lid = LerpedFloat.linear()
		.startWithValue(0);

	public LerpedFloat drawers = LerpedFloat.linear()
		.startWithValue(0);

	UUID uniqueId;
	ToolboxInventory inventory;
	ResetableLazy<class_1767> colorProvider;

	Map<Integer, WeakHashMap<class_1657, Integer>> connectedPlayers;

	private class_2561 customName;

	private AnimatedContainerBehaviour<ToolboxMenu> openTracker;

	public ToolboxBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		connectedPlayers = new HashMap<>();
		inventory = new ToolboxInventory(this);
		colorProvider = ResetableLazy.of(() -> {
			class_2680 blockState = method_11010();
			if (blockState != null && blockState.method_26204() instanceof ToolboxBlock)
				return ((ToolboxBlock) blockState.method_26204()).getColor();
			return class_1767.field_7957;
		});
		setLazyTickRate(10);
	}

	public static void registerCapabilities(net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent event) {
		event.registerBlockEntity(
				net.neoforged.neoforge.capabilities.Capabilities.ItemHandler.BLOCK,
				AllBlockEntityTypes.TOOLBOX.get(),
				(be, context) -> be.inventory
		);
	}

	public class_1767 getColor() {
		return colorProvider.get();
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
		behaviours.add(openTracker = new AnimatedContainerBehaviour<>(this, ToolboxMenu.class));
	}

	@Override
	public void initialize() {
		super.initialize();
		ToolboxHandler.onLoad(this);
	}

	@Override
	public void invalidate() {
		super.invalidate();
		ToolboxHandler.onUnload(this);
	}

	@Override
	public void tick() {
		super.tick();

		if (field_11863.field_9236)
			tickAudio();
		if (!field_11863.field_9236)
			tickPlayers();

		lid.chase(openTracker.openCount > 0 ? 1 : 0, 0.2f, Chaser.LINEAR);
		drawers.chase(openTracker.openCount > 0 ? 1 : 0, 0.2f, Chaser.EXP);
		lid.tickChaser();
		drawers.tickChaser();
	}

	private void tickPlayers() {
		boolean update = false;

		for (Iterator<Entry<Integer, WeakHashMap<class_1657, Integer>>> toolboxSlots = connectedPlayers.entrySet()
			.iterator(); toolboxSlots.hasNext(); ) {

			Entry<Integer, WeakHashMap<class_1657, Integer>> toolboxSlotEntry = toolboxSlots.next();
			WeakHashMap<class_1657, Integer> set = toolboxSlotEntry.getValue();
			int slot = toolboxSlotEntry.getKey();

			class_1799 referenceItem = inventory.filters.get(slot);
			boolean clear = referenceItem.method_7960();

			for (Iterator<Entry<class_1657, Integer>> playerEntries = set.entrySet()
				.iterator(); playerEntries.hasNext(); ) {
				Entry<class_1657, Integer> playerEntry = playerEntries.next();

				class_1657 player = playerEntry.getKey();
				int hotbarSlot = playerEntry.getValue();

				if (!clear && !ToolboxHandler.withinRange(player, this))
					continue;

				class_1661 playerInv = player.method_31548();
				class_1799 playerStack = playerInv.method_5438(hotbarSlot);

				if (clear || !playerStack.method_7960()
					&& !ToolboxInventory.canItemsShareCompartment(playerStack, referenceItem)) {
					player.getCustomData()
						.method_10562("CreateToolboxData")
						.method_10551(String.valueOf(hotbarSlot));
					playerEntries.remove();
					if (player instanceof class_3222)
						ToolboxHandler.syncData(player);
					continue;
				}

				int count = playerStack.method_7947();
				int targetAmount = (referenceItem.method_57825(class_9334.field_50071, 64) + 1) / 2;

				if (count < targetAmount) {
					int amountToReplenish = targetAmount - count;

					if (isOpenInContainer(player)) {
						try (Transaction t = Transaction.openOuter()) {
							class_1799 extracted = inventory.takeFromCompartment(amountToReplenish, slot, t);
							if (!extracted.method_7960()) {
								ToolboxHandler.unequip(player, hotbarSlot, false);
								ToolboxHandler.syncData(player);
								continue;
							}
						}
					}

					try (Transaction t = Transaction.openOuter()) {
						class_1799 extracted = inventory.takeFromCompartment(amountToReplenish, slot, t);
						if (!extracted.method_7960()) {
							update = true;
							class_1799 template = playerStack.method_7960() ? extracted : playerStack;
							playerInv.method_5447(hotbarSlot,
								template.method_46651(count + extracted.method_7947()));
							t.commit();
						}
					}
				}

				if (count > targetAmount) {
					int amountToDeposit = count - targetAmount;
					class_1799 toDistribute = playerStack.method_46651(amountToDeposit);

					if (isOpenInContainer(player)) {
						try (Transaction t = Transaction.openOuter()) {
							int deposited = amountToDeposit - inventory.distributeToCompartment(toDistribute, slot, t)
									.method_7947();
							if (deposited > 0) {
								ToolboxHandler.unequip(player, hotbarSlot, true);
								ToolboxHandler.syncData(player);
								continue;
							}
						}

					}

					try (Transaction t = Transaction.openOuter()) {
						int deposited = amountToDeposit - inventory.distributeToCompartment(toDistribute, slot, t)
								.method_7947();
						if (deposited > 0) {
							update = true;
							playerInv.method_5447(hotbarSlot,
								playerStack.method_46651(count - deposited));
							t.commit();
						}
					}
				}
			}

			if (clear)
				toolboxSlots.remove();
		}

		if (update)

			sendData();

	}

	private boolean isOpenInContainer(class_1657 player) {
		return player.field_7512 instanceof ToolboxMenu
			&& ((ToolboxMenu) player.field_7512).contentHolder == this;
	}

	public void unequipTracked() {
		if (field_11863.field_9236)
			return;

		Set<class_3222> affected = new HashSet<>();

		for (Entry<Integer, WeakHashMap<class_1657, Integer>> toolboxSlotEntry : connectedPlayers.entrySet()) {

			WeakHashMap<class_1657, Integer> set = toolboxSlotEntry.getValue();

			for (Entry<class_1657, Integer> playerEntry : set.entrySet()) {
				class_1657 player = playerEntry.getKey();
				int hotbarSlot = playerEntry.getValue();

				ToolboxHandler.unequip(player, hotbarSlot, false);
				if (player instanceof class_3222)
					affected.add((class_3222) player);
			}
		}

		for (class_3222 player : affected)
			ToolboxHandler.syncData(player);
		connectedPlayers.clear();
	}

	public void unequip(int slot, class_1657 player, int hotbarSlot, boolean keepItems) {
		if (!connectedPlayers.containsKey(slot))
			return;
		connectedPlayers.get(slot)
			.remove(player);
		if (keepItems)
			return;

		PlayerInventoryStorage playerInv = PlayerInventoryStorage.of(player);
		SingleSlotStorage<ItemVariant> storage = playerInv.getSlot(hotbarSlot);
		if (storage.isResourceBlank())
			return;
		ItemVariant resource = storage.getResource();
		int amount = (int) storage.getAmount();
		class_1799 toInsert = ToolboxInventory.cleanItemNBT(resource.toStack(amount));
		try (Transaction t = Transaction.openOuter()) {
			class_1799 remainder = inventory.distributeToCompartment(toInsert, slot, t);
			int inserted = amount - remainder.method_7947();
			storage.extract(resource, inserted, t);
			t.commit();
		}
	}

	private void tickAudio() {
		class_243 vec = VecHelper.getCenterOf(field_11867);
		if (lid.settled()) {
			if (openTracker.openCount > 0 && lid.getChaseTarget() == 0) {
				field_11863.method_8486(vec.field_1352, vec.field_1351, vec.field_1350, class_3417.field_14567, class_3419.field_15245, 0.25F,
					field_11863.field_9229.method_43057() * 0.1F + 1.2F, true);
				field_11863.method_8486(vec.field_1352, vec.field_1351, vec.field_1350, class_3417.field_14982, class_3419.field_15245, 0.1F,
					field_11863.field_9229.method_43057() * 0.1F + 1.1F, true);
			}
			if (openTracker.openCount == 0 && lid.getChaseTarget() == 1)
				field_11863.method_8486(vec.field_1352, vec.field_1351, vec.field_1350, class_3417.field_14823, class_3419.field_15245, 0.1F,
					field_11863.field_9229.method_43057() * 0.1F + 1.1F, true);

		} else if (openTracker.openCount == 0 && lid.getChaseTarget() == 0 && lid.getValue(0) > 1 / 16f
			&& lid.getValue(1) < 1 / 16f)
			field_11863.method_8486(vec.field_1352, vec.field_1351, vec.field_1350, class_3417.field_14819, class_3419.field_15245, 0.25F,
				field_11863.field_9229.method_43057() * 0.1F + 1.2F, true);
	}

	@Nullable
	@Override
	public Storage<ItemVariant> getItemStorage(@Nullable class_2350 face) {
		return inventory;
	}


	@Nullable
	@Override
	protected void read(class_2487 compound, class_7225.class_7874 registries, boolean clientPacket) {
		inventory.deserializeNBT(registries, compound.method_10562("Inventory"));
		super.read(compound, registries, clientPacket);
		if (compound.method_10573("UniqueId", 11))
			this.uniqueId = compound.method_25926("UniqueId");
		if (compound.method_10573("CustomName", 8))
			this.customName = class_2561.class_2562.method_10877(compound.method_10558("CustomName"), registries);
	}

	@Override
	protected void write(class_2487 compound, class_7225.class_7874 registries, boolean clientPacket) {
		if (uniqueId == null)
			uniqueId = UUID.randomUUID();

		compound.method_10566("Inventory", inventory.serializeNBT(registries));
		compound.method_25927("UniqueId", uniqueId);

		if (customName != null)
			compound.method_10582("CustomName", class_2561.class_2562.method_10867(customName, registries));
		super.write(compound, registries, clientPacket);
	}

	@Override
	public class_1703 createMenu(int id, class_1661 inv, class_1657 player) {
		return ToolboxMenu.create(id, inv, this);
	}

	@Override
	public class_9129 getScreenOpeningData(class_3222 player) {
		class_9129 buffer = new class_9129(Unpooled.buffer(), player.method_56673());
		sendToMenu(buffer);
		return buffer;
	}

	@Override
	public void lazyTick() {
		// keep re-advertising active TEs
		ToolboxHandler.onLoad(this);
		super.lazyTick();
	}

	public void connectPlayer(int slot, class_1657 player, int hotbarSlot) {
		if (field_11863.field_9236)
			return;
		WeakHashMap<class_1657, Integer> map = connectedPlayers.computeIfAbsent(slot, WeakHashMap::new);
		Integer previous = map.get(player);
		if (previous != null) {
			if (previous == hotbarSlot)
				return;
			ToolboxHandler.unequip(player, previous, false);
		}
		map.put(player, hotbarSlot);
	}

	public void readInventory(class_9288 contents) {
		ItemHelper.fillItemStackHandler(contents, inventory);
	}

	public void setUniqueId(UUID uniqueId) {
		this.uniqueId = uniqueId;
	}

	public UUID getUniqueId() {
		return uniqueId;
	}

	public boolean isFullyInitialized() {
		// returns true when uniqueId has been initialized
		return uniqueId != null;
	}

	public void setCustomName(class_2561 customName) {
		this.customName = customName;
	}

	@Override
	public class_2561 method_5476() {
		return customName != null ? customName
			: AllBlocks.TOOLBOXES.get(getColor())
			.get()
			.method_9518();
	}

	@Override
	public class_2561 method_5797() {
		return customName;
	}

	@Override
	public boolean method_16914() {
		return customName != null;
	}

	@Override
	public class_2561 method_5477() {
		return customName;
	}

	@SuppressWarnings("deprecation")
	@Override
	public void method_31664(class_2680 state) {
		super.method_31664(state);
		colorProvider.reset();
	}

	@Override
	protected void method_57568(class_9473 componentInput) {
		setUniqueId(componentInput.method_58694(AllDataComponents.TOOLBOX_UUID));
		readInventory(componentInput.method_58695(AllDataComponents.TOOLBOX_INVENTORY, class_9288.field_49334));
	}

	@Override
	protected void method_57567(class_9324 components) {
		components.method_57840(AllDataComponents.TOOLBOX_UUID, uniqueId);
		components.method_57840(AllDataComponents.TOOLBOX_INVENTORY, ItemHelper.containerContentsFromHandler(inventory));
	}
}
