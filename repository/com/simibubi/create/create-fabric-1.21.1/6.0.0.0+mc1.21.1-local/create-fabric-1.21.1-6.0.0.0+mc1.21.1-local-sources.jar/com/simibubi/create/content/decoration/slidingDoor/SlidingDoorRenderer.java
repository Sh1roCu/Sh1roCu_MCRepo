package com.simibubi.create.content.decoration.slidingDoor;

import com.simibubi.create.AllPartialModels;
import com.simibubi.create.foundation.blockEntity.renderer.SafeBlockEntityRenderer;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import net.createmod.catnip.data.Couple;
import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SuperByteBuffer;
import net.minecraft.class_1921;
import net.minecraft.class_2323;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2750;
import net.minecraft.class_2756;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614.class_5615;
import net.minecraft.class_7923;

public class SlidingDoorRenderer extends SafeBlockEntityRenderer<SlidingDoorBlockEntity> {

	public SlidingDoorRenderer(class_5615 context) {}

	@Override
	protected void renderSafe(SlidingDoorBlockEntity be, float partialTicks, class_4587 ms, class_4597 buffer,
		int light, int overlay) {
		class_2680 blockState = be.method_11010();
		if (!be.shouldRenderSpecial(blockState))
			return;

		class_2350 facing = blockState.method_11654(class_2323.field_10938);
		class_2350 movementDirection = facing.method_10170();

		if (blockState.method_11654(class_2323.field_10941) == class_2750.field_12588)
			movementDirection = movementDirection.method_10153();

		float value = be.animation.getValue(partialTicks);
		float value2 = class_3532.method_15363(value * 10, 0, 1);

		class_4588 vb = buffer.getBuffer(class_1921.method_23579());
		class_243 offset = class_243.method_24954(movementDirection.method_10163())
			.method_1021(value * value * 13 / 16f)
			.method_1019(class_243.method_24954(facing.method_10163())
				.method_1021(value2 * 1 / 32f));

		if (((SlidingDoorBlock) blockState.method_26204()).isFoldingDoor()) {
			Couple<PartialModel> partials =
				AllPartialModels.FOLDING_DOORS.get(class_7923.field_41175.method_10221(blockState.method_26204()));

			boolean flip = blockState.method_11654(class_2323.field_10941) == class_2750.field_12586;
			for (boolean left : Iterate.trueAndFalse) {
				SuperByteBuffer partial = CachedBuffers.partial(partials.get(left ^ flip), blockState);
				float f = flip ? -1 : 1;

				partial.translate(0, -1 / 512f, 0)
					.translate(class_243.method_24954(facing.method_10163())
						.method_1021(value2 * 1 / 32f));
				partial.rotateCentered(
					class_3532.field_29847 * AngleHelper.horizontalAngle(facing.method_10170()), class_2350.field_11036);

				if (flip)
					partial.translate(0, 0, 1);
				partial.rotateYDegrees(91 * f * value * value);

				if (!left)
					partial.translate(0, 0, f / 2f)
						.rotateYDegrees(-181 * f * value * value);

				if (flip)
					partial.translate(0, 0, -1 / 2f);

				partial.light(light)
					.renderInto(ms, vb);
			}

			return;
		}

		for (class_2756 half : class_2756.values()) {
			CachedBuffers.block(blockState.method_11657(class_2323.field_10945, false)
				.method_11657(class_2323.field_10946, half))
				.translate(0, half == class_2756.field_12609 ? 1 - 1 / 512f : 0, 0)
				.translate(offset)
				.light(light)
				.renderInto(ms, vb);
		}

	}

}
