package com.simibubi.create.content.contraptions.behaviour;

import com.simibubi.create.content.contraptions.Contraption;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2401;
import net.minecraft.class_2680;
import net.minecraft.class_3417;

public class LeverMovingInteraction extends SimpleBlockMovingInteraction {

	@Override
	protected class_2680 handle(class_1657 player, Contraption contraption, class_2338 pos, class_2680 currentState) {
		playSound(player, class_3417.field_14962, currentState.method_11654(class_2401.field_11265) ? 0.5f : 0.6f);
		return currentState.method_28493(class_2401.field_11265);
	}

}
