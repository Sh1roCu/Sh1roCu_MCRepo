package com.simibubi.create.content.equipment.tool;

import com.simibubi.create.Create;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModel;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModelRenderer;
import com.simibubi.create.foundation.item.render.PartialItemModelRenderer;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;

public class CardboardSwordItemRenderer extends CustomRenderedItemModelRenderer {

	protected static final PartialModel HELD = PartialModel.of(Create.asResource("item/cardboard_sword/item_in_hand"));

	@Override
	protected void render(class_1799 stack, CustomRenderedItemModel model, PartialItemModelRenderer renderer,
		class_811 transformType, class_4587 ms, class_4597 buffer, int light, int overlay) {
		renderer.render(transformType == class_811.field_4317 ? model.getOriginalModel() : HELD.get(), light);
	}

}
