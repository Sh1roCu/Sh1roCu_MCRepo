package com.simibubi.create.content.contraptions.actors.contraptionControls;

import java.util.List;
import com.simibubi.create.AllTags.AllItemTags;
import com.simibubi.create.content.contraptions.actors.trainControls.ControlsBlock;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBoxTransform;
import com.simibubi.create.foundation.blockEntity.behaviour.filtering.FilteringBehaviour;
import com.simibubi.create.foundation.utility.CreateLang;
import com.simibubi.create.foundation.utility.DyeHelper;

import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.catnip.animation.LerpedFloat.Chaser;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_5250;
import net.minecraft.class_7225;

public class ContraptionControlsBlockEntity extends SmartBlockEntity {

	public FilteringBehaviour filtering;
	public boolean disabled;
	public boolean powered;

	public LerpedFloat indicator;
	public LerpedFloat button;

	public ContraptionControlsBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		indicator = LerpedFloat.angular()
			.startWithValue(0);
		button = LerpedFloat.linear()
			.startWithValue(0)
			.chase(0, 0.125f, Chaser.EXP);
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
		behaviours.add(filtering = new FilteringBehaviour(this, new ControlsSlot()));
		filtering.setLabel(CreateLang.translateDirect("contraptions.contoller.target"));
		filtering.withPredicate(AllItemTags.CONTRAPTION_CONTROLLED::matches);
	}

	public void pressButton() {
		button.setValue(1);
	}

	public void updatePoweredState() {
		if (field_11863.method_8608())
			return;
		boolean powered = field_11863.method_49803(field_11867);
		if (this.powered == powered)
			return;
		this.powered = powered;
		this.disabled = powered;
		notifyUpdate();
	}

	@Override
	public void initialize() {
		super.initialize();
		updatePoweredState();
	}

	@Override
	public void tick() {
		super.tick();
		if (!field_11863.method_8608())
			return;
		tickAnimations();
		int value = disabled ? 4 * 45 : 0;
		indicator.setValue(value);
		indicator.updateChaseTarget(value);
	}

	public void tickAnimations() {
		button.tickChaser();
		indicator.tickChaser();
	}

	@Override
	protected void read(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		super.read(tag, registries, clientPacket);
		disabled = tag.method_10577("Disabled");
		powered = tag.method_10577("Powered");
	}

	@Override
	protected void write(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		super.write(tag, registries, clientPacket);
		tag.method_10556("Disabled", disabled);
		tag.method_10556("Powered", powered);
	}

	public static void sendStatus(class_1657 player, class_1799 filter, boolean enabled) {
		class_5250 state = CreateLang.translate("contraption.controls.actor_toggle." + (enabled ? "on" : "off"))
			.color(DyeHelper.getDyeColors(enabled ? class_1767.field_7961 : class_1767.field_7946)
				.getFirst())
			.component();

		if (filter.method_7960()) {
			CreateLang.translate("contraption.controls.all_actor_toggle", state)
				.sendStatus(player);
			return;
		}

		CreateLang.translate("contraption.controls.specific_actor_toggle", filter.method_7964()
			.getString(), state)
			.sendStatus(player);
	}

	public static class ControlsSlot extends ValueBoxTransform.Sided {

		@Override
		public class_243 getLocalOffset(class_1936 level, class_2338 pos, class_2680 state) {
			class_2350 facing = state.method_11654(ControlsBlock.field_11177);
			float yRot = AngleHelper.horizontalAngle(facing);
			return VecHelper.rotateCentered(VecHelper.voxelSpace(8, 14f, 5.5f), yRot, class_2351.field_11052);
		}

		@Override
		public void rotate(class_1936 level, class_2338 pos, class_2680 state, class_4587 ms) {
			class_2350 facing = state.method_11654(ControlsBlock.field_11177);
			float yRot = AngleHelper.horizontalAngle(facing);
			TransformStack.of(ms)
				.rotateYDegrees(yRot + 180)
				.rotateXDegrees(67.5f);
		}

		@Override
		public float getScale() {
			return .508f;
		}

		@Override
		protected class_243 getSouthLocation() {
			return class_243.field_1353;
		}

	}

}
