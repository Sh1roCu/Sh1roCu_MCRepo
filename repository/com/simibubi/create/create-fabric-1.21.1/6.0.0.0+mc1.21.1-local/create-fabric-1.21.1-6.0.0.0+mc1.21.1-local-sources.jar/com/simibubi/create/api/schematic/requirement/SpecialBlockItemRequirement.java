package com.simibubi.create.api.schematic.requirement;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public interface SpecialBlockItemRequirement {
	ItemRequirement getRequiredItems(class_2680 state, @Nullable class_2586 blockEntity);
}
