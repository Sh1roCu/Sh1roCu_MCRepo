package com.simibubi.create.content.contraptions.actors.seat;

import java.util.Map;
import java.util.UUID;

import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;

import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2771;

public class SeatMovementBehaviour implements MovementBehaviour {

	@Override
	public void startMoving(MovementContext context) {
		MovementBehaviour.super.startMoving(context);
		int indexOf = context.contraption.getSeats()
			.indexOf(context.localPos);
		context.data.method_10569("SeatIndex", indexOf);
	}

	@Override
	public void visitNewPosition(MovementContext context, class_2338 pos) {
		MovementBehaviour.super.visitNewPosition(context, pos);

		AbstractContraptionEntity contraptionEntity = context.contraption.entity;
		if (contraptionEntity == null)
			return;
		int index = context.data.method_10550("SeatIndex");
		if (index == -1)
			return;

		Map<UUID, Integer> seatMapping = context.contraption.getSeatMapping();
		class_2680 blockState = context.world.method_8320(pos);
		boolean slab =
			blockState.method_26204() instanceof class_2482 && blockState.method_11654(class_2482.field_11501) == class_2771.field_12681;
		boolean solid = blockState.method_26225() || slab;

		// Occupied
		if (!seatMapping.containsValue(index))
			return;
		if (!solid)
			return;
		class_1297 toDismount = null;
		for (Map.Entry<UUID, Integer> entry : seatMapping.entrySet()) {
			if (entry.getValue() != index)
				continue;
			for (class_1297 entity : contraptionEntity.method_5685()) {
				if (!entry.getKey()
					.equals(entity.method_5667()))
					continue;
				toDismount = entity;
			}
		}
		if (toDismount == null)
			return;
		toDismount.method_5848();
		class_243 position = VecHelper.getCenterOf(pos)
			.method_1031(0, slab ? .5f : 1f, 0);
		toDismount.method_5859(position.field_1352, position.field_1351, position.field_1350);
		toDismount.getCustomData()
			.method_10551("ContraptionDismountLocation");
	}

}
