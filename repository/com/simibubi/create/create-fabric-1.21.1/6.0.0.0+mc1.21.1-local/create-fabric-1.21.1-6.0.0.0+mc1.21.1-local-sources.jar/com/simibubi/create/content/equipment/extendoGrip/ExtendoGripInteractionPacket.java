package com.simibubi.create.content.equipment.extendoGrip;

import com.simibubi.create.AllPackets;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecBuilders;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecs;
import io.netty.buffer.ByteBuf;

public record ExtendoGripInteractionPacket(class_1268 hand, int target, class_243 point) implements ServerboundPacketPayload {
	public static final class_9139<ByteBuf, ExtendoGripInteractionPacket> STREAM_CODEC = class_9139.method_56436(
			CatnipStreamCodecBuilders.nullable(CatnipStreamCodecs.HAND), ExtendoGripInteractionPacket::hand,
			class_9135.field_49675, ExtendoGripInteractionPacket::target,
			CatnipStreamCodecBuilders.nullable(CatnipStreamCodecs.VEC3), ExtendoGripInteractionPacket::point,
	        ExtendoGripInteractionPacket::new
	);

	public ExtendoGripInteractionPacket(class_1297 target) {
		this(target, null);
	}

	public ExtendoGripInteractionPacket(class_1297 target, class_1268 hand) {
		this(target, hand, null);
	}

	public ExtendoGripInteractionPacket(class_1297 target, class_1268 hand, class_243 specificPoint) {
		this(hand, target.method_5628(), specificPoint);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.EXTENDO_INTERACT;
	}

	@Override
	public void handle(class_3222 sender) {
		if (sender == null)
			return;
		class_1297 entityByID = sender.method_37908()
				.method_8469(this.target);
		if (entityByID != null && ExtendoGripItem.isHoldingExtendoGrip(sender)) {
			double d = sender.method_45325(class_5134.field_47758);
			if (!sender.method_6057(entityByID))
				d -= 3;
			d *= d;
			if (sender.method_5858(entityByID) > d)
				return;
			if (this.hand == null)
				sender.method_7324(entityByID);
			else if (this.point == null)
				sender.method_7287(entityByID, this.hand);
			else
				entityByID.method_5664(sender, this.point, this.hand);
		}
	}
}
