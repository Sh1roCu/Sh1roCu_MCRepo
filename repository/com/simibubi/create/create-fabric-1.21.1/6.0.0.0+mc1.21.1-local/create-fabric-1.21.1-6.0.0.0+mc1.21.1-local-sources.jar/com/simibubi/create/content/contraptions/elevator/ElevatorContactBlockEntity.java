package com.simibubi.create.content.contraptions.elevator;

import java.util.List;

import com.simibubi.create.content.contraptions.elevator.ElevatorColumn.ColumnCoords;
import com.simibubi.create.content.decoration.slidingDoor.DoorControlBehaviour;
import com.simibubi.create.content.redstone.displayLink.DisplayLinkBlock;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

import net.createmod.catnip.data.Couple;
import net.createmod.catnip.nbt.NBTHelper;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

public class ElevatorContactBlockEntity extends SmartBlockEntity {

	public DoorControlBehaviour doorControls;
	public ColumnCoords columnCoords;
	public boolean activateBlock;

	public String shortName;
	public String longName;

	public String lastReportedCurrentFloor = "";

	private int yTargetFromNBT = Integer.MIN_VALUE;
	private boolean deferNameGenerator;

	public ElevatorContactBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		shortName = "";
		longName = "";
		deferNameGenerator = false;
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
		behaviours.add(doorControls = new DoorControlBehaviour(this));
	}

	@Override
	protected void write(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		super.write(tag, registries, clientPacket);

		tag.method_10582("ShortName", shortName);
		tag.method_10582("LongName", longName);

		if (lastReportedCurrentFloor != null)
			tag.method_10582("LastReportedCurrentFloor", lastReportedCurrentFloor);

		if (clientPacket)
			return;
		tag.method_10556("Activate", activateBlock);
		if (columnCoords == null)
			return;

		ElevatorColumn column = ElevatorColumn.get(field_11863, columnCoords);
		if (column == null)
			return;
		tag.method_10569("ColumnTarget", column.getTargetedYLevel());
		if (column.isActive())
			NBTHelper.putMarker(tag, "ColumnActive");
	}

	@Override
	protected void read(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		super.read(tag, registries, clientPacket);

		shortName = tag.method_10558("ShortName");
		longName = tag.method_10558("LongName");

		if (tag.method_10545("LastReportedCurrentFloor"))
			lastReportedCurrentFloor = tag.method_10558("LastReportedCurrentFloor");

		if (clientPacket)
			return;
		activateBlock = tag.method_10577("Activate");
		if (!tag.method_10545("ColumnTarget"))
			return;

		int target = tag.method_10550("ColumnTarget");
		boolean active = tag.method_10545("ColumnActive");

		if (columnCoords == null) {
			yTargetFromNBT = target;
			return;
		}

		ElevatorColumn column = ElevatorColumn.getOrCreate(field_11863, columnCoords);
		column.target(target);
		column.setActive(active);
	}

	public void updateDisplayedFloor(String floor) {
		if (floor.equals(lastReportedCurrentFloor))
			return;
		lastReportedCurrentFloor = floor;
		DisplayLinkBlock.notifyGatherers(field_11863, field_11867);
	}

	@Override
	public void initialize() {
		super.initialize();
		if (field_11863.method_8608())
			return;
		columnCoords = ElevatorContactBlock.getColumnCoords(field_11863, field_11867);
		if (columnCoords == null)
			return;
		ElevatorColumn column = ElevatorColumn.getOrCreate(field_11863, columnCoords);
		column.add(field_11867);
		if (shortName.isBlank())
			deferNameGenerator = true;
		if (yTargetFromNBT == Integer.MIN_VALUE)
			return;
		column.target(yTargetFromNBT);
		yTargetFromNBT = Integer.MIN_VALUE;
	}

	@Override
	public void tick() {
		super.tick();
		if (!deferNameGenerator)
			return;
		if (columnCoords != null)
			ElevatorColumn.getOrCreate(field_11863, columnCoords)
				.initNames(field_11863);
		deferNameGenerator = false;
	}

	@Override
	public void invalidate() {
		if (columnCoords != null) {
			ElevatorColumn column = ElevatorColumn.get(field_11863, columnCoords);
			if (column != null)
				column.remove(field_11867);
		}
		super.invalidate();
	}

	public void updateName(String shortName, String longName) {
		this.shortName = shortName;
		this.longName = longName;
		this.deferNameGenerator = false;
		notifyUpdate();

		ElevatorColumn column = ElevatorColumn.get(field_11863, columnCoords);
		if (column != null)
			column.namesChanged();
	}

	public Couple<String> getNames() {
		return Couple.create(shortName, longName);
	}

}
