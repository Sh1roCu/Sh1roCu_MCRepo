package com.simibubi.create.content.contraptions.render;

import org.apache.commons.lang3.tuple.Pair;
import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.foundation.render.BlockEntityRenderHelper;
import com.simibubi.create.foundation.virtualWorld.VirtualRenderWorld;

import dev.engine_room.flywheel.api.visualization.VisualizationManager;
import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.render.SuperByteBuffer;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3499;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_5617;
import net.minecraft.class_897;

public class ContraptionEntityRenderer<C extends AbstractContraptionEntity> extends class_897<C> {
	public ContraptionEntityRenderer(class_5617.class_5618 context) {
		super(context);
	}

	@Override
	public class_2960 getTextureLocation(C entity) {
		return null;
	}

	@Override
	public boolean shouldRender(C entity, class_4604 frustum, double cameraX, double cameraY,
		double cameraZ) {
		if (entity.getContraption() == null)
			return false;
		if (!entity.isAliveOrStale())
			return false;
		if (!entity.isReadyForRender())
			return false;

		return super.method_3933(entity, frustum, cameraX, cameraY, cameraZ);
	}

	@Override
	public void render(C entity, float yaw, float partialTicks, class_4587 poseStack, class_4597 buffers,
		int overlay) {
		super.method_3936(entity, yaw, partialTicks, poseStack, buffers, overlay);

		Contraption contraption = entity.getContraption();
		if (contraption == null) {
			return;
		}

		class_1937 level = entity.method_37908();
		ContraptionRenderInfo renderInfo = ContraptionRenderInfo.get(contraption);
		VirtualRenderWorld renderWorld = renderInfo.getRenderWorld();
		ContraptionMatrices matrices = renderInfo.getMatrices();
		matrices.setup(poseStack, entity);

		if (!VisualizationManager.supportsVisualization(level)) {
			for (class_1921 renderType : class_1921.method_22720()) {
				SuperByteBuffer sbb = renderInfo.getBuffer(renderType);
				if (!sbb.isEmpty()) {
					class_4588 vc = buffers.getBuffer(renderType);
					sbb.transform(matrices.getModel())
						.useLevelLight(level, matrices.getWorld())
						.renderInto(poseStack, vc);
				}
			}
		}

		renderBlockEntities(level, renderWorld, contraption, matrices, buffers);
		renderActors(level, renderWorld, contraption, matrices, buffers);

		matrices.clear();
	}

	private static void renderBlockEntities(class_1937 level, VirtualRenderWorld renderWorld, Contraption c,
		ContraptionMatrices matrices, class_4597 buffer) {
		BlockEntityRenderHelper.renderBlockEntities(level, renderWorld, c.getRenderedBEs(),
			matrices.getModelViewProjection(), matrices.getLight(), buffer);
	}

	private static void renderActors(class_1937 level, VirtualRenderWorld renderWorld, Contraption c,
		ContraptionMatrices matrices, class_4597 buffer) {
		class_4587 m = matrices.getModel();

		for (Pair<class_3499.class_3501, MovementContext> actor : c.getActors()) {
			MovementContext context = actor.getRight();
			if (context == null)
				continue;
			if (context.world == null)
				context.world = level;
			class_3499.class_3501 blockInfo = actor.getLeft();

			MovementBehaviour movementBehaviour = MovementBehaviour.REGISTRY.get(blockInfo.comp_1342());
			if (movementBehaviour != null) {
				if (c.isHiddenInPortal(blockInfo.comp_1341()))
					continue;
				m.method_22903();
				TransformStack.of(m)
					.translate(blockInfo.comp_1341());
				movementBehaviour.renderInContraption(context, renderWorld, matrices, buffer);
				m.method_22909();
			}
		}
	}
}
