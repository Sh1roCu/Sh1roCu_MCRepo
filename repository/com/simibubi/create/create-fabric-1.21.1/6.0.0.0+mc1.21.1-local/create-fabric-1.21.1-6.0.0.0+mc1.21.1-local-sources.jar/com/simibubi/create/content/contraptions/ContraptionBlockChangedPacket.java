package com.simibubi.create.content.contraptions;

import com.simibubi.create.AllPackets;
import net.createmod.catnip.net.base.ClientboundPacketPayload;

import net.createmod.catnip.codecs.stream.CatnipStreamCodecs;
import io.netty.buffer.ByteBuf;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ContraptionBlockChangedPacket(int entityId, class_2338 localPos, class_2680 newState) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, ContraptionBlockChangedPacket> STREAM_CODEC = class_9139.method_56436(
			class_9135.field_49675, ContraptionBlockChangedPacket::entityId,
			class_2338.field_48404, ContraptionBlockChangedPacket::localPos,
			CatnipStreamCodecs.BLOCK_STATE, ContraptionBlockChangedPacket::newState,
			ContraptionBlockChangedPacket::new
	);

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		AbstractContraptionEntity.handleBlockChangedPacket(this);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CONTRAPTION_BLOCK_CHANGED;
	}
}
