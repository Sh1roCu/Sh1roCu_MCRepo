package com.simibubi.create;

import static net.minecraft.class_1802.field_8550;
import static net.minecraft.class_1802.field_8469;
import static net.minecraft.class_1802.field_20417;

import java.util.List;

import javax.annotation.Nullable;

import com.simibubi.create.content.decoration.palettes.AllPaletteStoneTypes;
import com.simibubi.create.content.fluids.VirtualFluid;
import com.simibubi.create.content.fluids.potion.PotionFluid;
import com.simibubi.create.content.fluids.potion.PotionFluidHandler;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.simibubi.create.foundation.fluid.FluidHelper;
import com.simibubi.create.infrastructure.fabric.transfer.TransferUtil;
import com.tterrag.registrate.fabric.SimpleFlowableFluid;
import com.tterrag.registrate.util.entry.FluidEntry;

import io.github.fabricators_of_create.porting_lib.tags.Tags;

import net.createmod.catnip.data.Iterate;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRenderHandler;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributeHandler;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.EmptyItemFluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.FullItemFluidStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.minecraft.class_1836;
import net.minecraft.class_1920;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_7924;
import io.github.fabricators_of_create.porting_lib.event.common.FluidPlaceBlockCallback;

@SuppressWarnings("UnstableApiUsage")
public class AllFluids {
	private static final CreateRegistrate REGISTRATE = Create.registrate();

	static {
		REGISTRATE.setCreativeTab(AllCreativeModeTabs.BASE_CREATIVE_TAB.key());
	}
	// Fabric: since a honey block is 4 bottles, we can't use the default 1/3 (27000)
	// we can't make a block take 108000, since then it can't fit in the basin
	public static final long HONEY_BOTTLE_AMOUNT = FluidConstants.BLOCK / 4;

	// fabric: various Attributes/Types replaced with corresponding handlers

	public static final FluidEntry<PotionFluid> POTION =
			REGISTRATE.virtualFluid("potion", /*PotionFluidAttributes::new,*/ PotionFluid::createSource, PotionFluid::createFlowing)
					.lang("Potion")
					.fluidAttributes(PotionFluidVariantAttributeHandler::new)
					.register();

	public static final FluidEntry<VirtualFluid> TEA = REGISTRATE.virtualFluid("tea")
			.lang("Builder's Tea")
		.tag(AllTags.commonFluidTag("teas"))
			.fluidAttributes(() -> new CreateAttributeHandler("fluid.create.tea"))
			.onRegisterAfter(class_7924.field_41197, tea -> {
				class_3611 still = tea.method_15751();
				FluidStorage.combinedItemApiProvider(AllItems.BUILDERS_TEA.get()).register(context ->
						new FullItemFluidStorage(context, bottle -> ItemVariant.of(field_8469), TransferUtil.fluidVariantOf(still), FluidConstants.BOTTLE));
				FluidStorage.combinedItemApiProvider(field_8469).register(context ->
						new EmptyItemFluidStorage(context, bottle -> ItemVariant.of(AllItems.BUILDERS_TEA.get()), still, FluidConstants.BOTTLE));
			})
			.register();

	public static final FluidEntry<SimpleFlowableFluid.Flowing> HONEY =
			REGISTRATE.standardFluid("honey")
					.lang("Honey")
					.fluidProperties(p -> p.levelDecreasePerBlock(2)
							.tickRate(25)
							.flowSpeed(3)
							.blastResistance(100f))
					.fluidAttributes(() -> new CreateAttributeHandler("block.create.honey", 2000, 1400))
					.tag(Tags.Fluids.HONEY, class_3486.field_15517) // fabric: water tag controls physics
					.source(SimpleFlowableFluid.Source::new) // TODO: remove when Registrate fixes FluidBuilder
					.bucket()
					.tag(AllTags.commonItemTag("buckets/honey"))
					.build()
					.onRegisterAfter(class_7924.field_41197, honey -> {
						class_3611 source = FluidHelper.convertToStill(honey);
						FluidStorage.combinedItemApiProvider(field_20417).register(context ->
								new FullItemFluidStorage(context, bottle -> ItemVariant.of(field_8469), TransferUtil.fluidVariantOf(source), HONEY_BOTTLE_AMOUNT));
						FluidStorage.combinedItemApiProvider(field_8469).register(context ->
								new EmptyItemFluidStorage(context, bottle -> ItemVariant.of(field_20417), source, HONEY_BOTTLE_AMOUNT));
						FluidStorage.combinedItemApiProvider(source.method_15774()).register(context ->
								new FullItemFluidStorage(context, bucket -> ItemVariant.of(field_8550), TransferUtil.fluidVariantOf(source), FluidConstants.BUCKET));
						FluidStorage.combinedItemApiProvider(field_8550).register(context ->
								new EmptyItemFluidStorage(context, bucket -> ItemVariant.of(source.method_15774()), source, FluidConstants.BUCKET));
					})
					.register();

	public static final FluidEntry<SimpleFlowableFluid.Flowing> CHOCOLATE =
			REGISTRATE.standardFluid("chocolate")
					.lang("Chocolate")
					.tag(AllTags.commonFluidTag("chocolates"), class_3486.field_15517) // fabric: water tag controls physics
					.fluidProperties(p -> p.levelDecreasePerBlock(2)
							.tickRate(25)
							.flowSpeed(3)
							.blastResistance(100f))
					.fluidAttributes(() -> new CreateAttributeHandler("block.create.chocolate", 1500, 1400))
					.onRegisterAfter(class_7924.field_41197, chocolate -> {
						class_3611 source = FluidHelper.convertToStill(chocolate);
						// transfer values
						FluidStorage.combinedItemApiProvider(source.method_15774()).register(context ->
								new FullItemFluidStorage(context, bucket -> ItemVariant.of(field_8550), TransferUtil.fluidVariantOf(source), FluidConstants.BUCKET));
						FluidStorage.combinedItemApiProvider(field_8550).register(context ->
								new EmptyItemFluidStorage(context, bucket -> ItemVariant.of(source.method_15774()), source, FluidConstants.BUCKET));
					})
					.register();

	// Load this class

	public static void register() {
	}

	@Environment(EnvType.CLIENT)
	public static void initRendering() {
		// FluidRenderHandler has sane defaults and is handled by registrate
		// potion is the only fluid with custom variant rendering
		PotionFluidVariantRenderHandler handler = new PotionFluidVariantRenderHandler();
		PotionFluid potionFluid = AllFluids.POTION.get();
		FluidVariantRendering.register(potionFluid.method_15750(), handler);
		FluidVariantRendering.register(potionFluid.method_15751(), handler);
	}

	public static void registerFluidInteractions() {
		// fabric: no fluid interaction API, use legacy method
		FluidPlaceBlockCallback.EVENT.register(AllFluids::whenFluidsMeet);
	}

	public static class_2680 whenFluidsMeet(class_1936 world, class_2338 pos, class_2680 blockState) {
		class_3610 fluidState = blockState.method_26227();

		if (fluidState.method_15771() && FluidHelper.isLava(fluidState.method_15772()))
			return null;

		for (class_2350 direction : Iterate.directions) {
			class_3610 metFluidState =
					fluidState.method_15771() ? fluidState : world.method_8316(pos.method_10093(direction));
			if (!metFluidState.method_15767(class_3486.field_15517))
				continue;
			class_2680 lavaInteraction = AllFluids.getLavaInteraction(metFluidState);
			if (lavaInteraction == null)
				continue;
			return lavaInteraction;
		}
		return null;
	}

	@Nullable
	public static class_2680 getLavaInteraction(class_3610 fluidState) {
		class_3611 fluid = fluidState.method_15772();
		if (fluid.method_15780(HONEY.get()))
			return AllPaletteStoneTypes.LIMESTONE.getBaseBlock()
					.get()
					.method_9564();
		if (fluid.method_15780(CHOCOLATE.get()))
			return AllPaletteStoneTypes.SCORIA.getBaseBlock()
					.get()
					.method_9564();
		return null;
	}

//	/**
//	 * Removing alpha from tint prevents optifine from forcibly applying biome
//	 * colors to modded fluids (Makes translucent fluids disappear)
//	 */
//	private static class NoColorFluidAttributes extends FluidAttributes {
//
//		protected NoColorFluidAttributes(Builder builder, Fluid fluid) {
//			super(builder, fluid);
//		}
//
//		@Override
//		public int getColor(BlockAndTintGetter world, BlockPos pos) {
//			return 0x00ffffff;
//		}
//
//	}

	@Environment(EnvType.CLIENT)
	public static class PotionFluidVariantRenderHandler implements FluidVariantRenderHandler {
		@Override
		public int getColor(FluidVariant fluidVariant, @Nullable class_1920 view, @Nullable class_2338 pos) {
			return 0xff385dc6;
		}

		@Override
		public void appendTooltip(FluidVariant fluidVariant, List<class_2561> tooltip, class_1836 tooltipContext) {
			PotionFluidHandler.addPotionTooltip(fluidVariant, tooltip::add, 1);
		}
	}

	private static class PotionFluidVariantAttributeHandler implements FluidVariantAttributeHandler {
		@Override
		public class_2561 getName(FluidVariant fluidVariant) {
			return class_2561.method_43471(getTranslationKey(fluidVariant));
		}

		public String getTranslationKey(FluidVariant stack) {
			return "item.minecraft.potion.effect.empty";
		}
	}

	private record CreateAttributeHandler(class_2561 name, int viscosity, boolean lighterThanAir) implements FluidVariantAttributeHandler {
		private CreateAttributeHandler(String key, int viscosity, int density) {
			this(class_2561.method_43471(key), viscosity, density <= 0);
		}

		public CreateAttributeHandler(String key) {
			this(key, FluidConstants.WATER_VISCOSITY, 1000);
		}

		@Override
		public class_2561 getName(FluidVariant fluidVariant) {
			return name.method_27661();
		}

		@Override
		public int getViscosity(FluidVariant variant, @Nullable class_1937 world) {
			return viscosity;
		}

		@Override
		public boolean isLighterThanAir(FluidVariant variant) {
			return lighterThanAir;
		}
	}
}
