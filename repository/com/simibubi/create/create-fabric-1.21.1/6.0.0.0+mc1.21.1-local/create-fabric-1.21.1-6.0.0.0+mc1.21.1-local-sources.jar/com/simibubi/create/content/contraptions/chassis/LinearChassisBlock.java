package com.simibubi.create.content.contraptions.chassis;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllSpriteShifts;
import com.simibubi.create.foundation.block.connected.CTSpriteShiftEntry;
import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;
import net.minecraft.class_1058;
import net.minecraft.class_1750;
import net.minecraft.class_1920;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2746;

public class LinearChassisBlock extends AbstractChassisBlock {

	public static final class_2746 STICKY_TOP = class_2746.method_11825("sticky_top");
	public static final class_2746 STICKY_BOTTOM = class_2746.method_11825("sticky_bottom");

	public LinearChassisBlock(class_2251 properties) {
		super(properties);
		method_9590(method_9564().method_11657(STICKY_TOP, false)
			.method_11657(STICKY_BOTTOM, false));
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> builder) {
		builder.method_11667(STICKY_TOP, STICKY_BOTTOM);
		super.method_9515(builder);
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		class_2338 placedOnPos = context.method_8037()
			.method_10093(context.method_8038()
				.method_10153());
		class_2680 blockState = context.method_8045()
			.method_8320(placedOnPos);

		if (context.method_8036() == null || !context.method_8036()
			.method_5715()) {
			if (isChassis(blockState))
				return method_9564().method_11657(field_11459, blockState.method_11654(field_11459));
			return method_9564().method_11657(field_11459, context.method_7715()
				.method_10166());
		}
		return super.method_9605(context);
	}

	@Override
	public class_2680 method_9559(class_2680 state, class_2350 side, class_2680 other, class_1936 p_196271_4_,
		class_2338 p_196271_5_, class_2338 p_196271_6_) {
		class_2746 property = getGlueableSide(state, side);
		if (property == null || !sameKind(state, other) || state.method_11654(field_11459) != other.method_11654(field_11459))
			return state;
		return state.method_11657(property, false);
	}

	@Override
	public class_2746 getGlueableSide(class_2680 state, class_2350 face) {
		if (face.method_10166() != state.method_11654(field_11459))
			return null;
		return face.method_10171() == class_2352.field_11056 ? STICKY_TOP : STICKY_BOTTOM;
	}

	@Override
	protected boolean glueAllowedOnSide(class_1922 world, class_2338 pos, class_2680 state, class_2350 side) {
		class_2680 other = world.method_8320(pos.method_10093(side));
		return !sameKind(other, state) || state.method_11654(field_11459) != other.method_11654(field_11459);
	}

	public static boolean isChassis(class_2680 state) {
		return AllBlocks.LINEAR_CHASSIS.has(state) || AllBlocks.SECONDARY_LINEAR_CHASSIS.has(state);
	}

	public static boolean sameKind(class_2680 state1, class_2680 state2) {
		return state1.method_26204() == state2.method_26204();
	}

	public static class ChassisCTBehaviour extends ConnectedTextureBehaviour.Base {

		@Override
		public CTSpriteShiftEntry getShift(class_2680 state, class_2350 direction, @Nullable class_1058 sprite) {
			class_2248 block = state.method_26204();
			class_2746 glueableSide = ((LinearChassisBlock) block).getGlueableSide(state, direction);
			if (glueableSide == null)
				return AllBlocks.LINEAR_CHASSIS.has(state) ? AllSpriteShifts.CHASSIS_SIDE
					: AllSpriteShifts.SECONDARY_CHASSIS_SIDE;
			return state.method_11654(glueableSide) ? AllSpriteShifts.CHASSIS_STICKY : AllSpriteShifts.CHASSIS;
		}

		@Override
		protected class_2350 getUpDirection(class_1920 reader, class_2338 pos, class_2680 state, class_2350 face) {
			class_2351 axis = state.method_11654(field_11459);
			if (face.method_10166() == axis)
				return super.getUpDirection(reader, pos, state, face);
			return class_2350.method_10156(class_2352.field_11056, axis);
		}

		@Override
		protected class_2350 getRightDirection(class_1920 reader, class_2338 pos, class_2680 state, class_2350 face) {
			class_2351 axis = state.method_11654(field_11459);
			return axis != face.method_10166() && axis.method_10179() ? (face.method_10166()
				.method_10179() ? class_2350.field_11033 : (axis == class_2351.field_11048 ? class_2350.field_11043 : class_2350.field_11034))
				: super.getRightDirection(reader, pos, state, face);
		}

		@Override
		protected boolean reverseUVsHorizontally(class_2680 state, class_2350 face) {
			class_2351 axis = state.method_11654(field_11459);
			boolean side = face.method_10166() != axis;
			if (side && axis == class_2351.field_11048 && face.method_10166()
				.method_10179())
				return true;
			return super.reverseUVsHorizontally(state, face);
		}

		@Override
		protected boolean reverseUVsVertically(class_2680 state, class_2350 face) {
			return super.reverseUVsVertically(state, face);
		}

		@Override
		public boolean reverseUVs(class_2680 state, class_2350 face) {
			class_2351 axis = state.method_11654(field_11459);
			boolean end = face.method_10166() == axis;
			if (end && axis.method_10179() && (face.method_10171() == class_2352.field_11056))
				return true;
			if (!end && axis.method_10179() && face == class_2350.field_11033)
				return true;
			return super.reverseUVs(state, face);
		}

		@Override
		public boolean connectsTo(class_2680 state, class_2680 other, class_1920 reader, class_2338 pos,
			class_2338 otherPos, class_2350 face) {
			class_2351 axis = state.method_11654(field_11459);
			boolean superConnect = face.method_10166() == axis ? super.connectsTo(state, other, reader, pos, otherPos, face)
				: sameKind(state, other);
			return superConnect && axis == other.method_11654(field_11459);
		}

	}

}
