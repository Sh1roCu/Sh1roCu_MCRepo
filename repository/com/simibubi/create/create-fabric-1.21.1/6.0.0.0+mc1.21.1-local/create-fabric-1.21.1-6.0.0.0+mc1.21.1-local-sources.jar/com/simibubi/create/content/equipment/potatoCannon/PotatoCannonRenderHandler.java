package com.simibubi.create.content.equipment.potatoCannon;

import com.simibubi.create.content.equipment.zapper.ShootableGadgetRenderHandler;
import com.simibubi.create.foundation.particle.AirParticleData;

import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_638;

public class PotatoCannonRenderHandler extends ShootableGadgetRenderHandler {

	private float nextPitch;

	@Override
	protected void playSound(class_1268 hand, class_243 position) {
		PotatoProjectileEntity.playLaunchSound(class_310.method_1551().field_1687, position, nextPitch);
	}

	@Override
	protected boolean appliesTo(class_1799 stack) {
		return stack.method_7909() instanceof PotatoCannonItem;
	}

	public void beforeShoot(float nextPitch, class_243 location, class_243 motion, class_1799 stack) {
		this.nextPitch = nextPitch;
		if (stack.method_7960())
			return;
		class_638 world = class_310.method_1551().field_1687;
		for (int i = 0; i < 2; i++) {
			class_243 m = VecHelper.offsetRandomly(motion.method_1021(0.1f), world.field_9229, .025f);
			world.method_8406(new class_2392(class_2398.field_11218, stack), location.field_1352, location.field_1351, location.field_1350, m.field_1352,
				m.field_1351, m.field_1350);

			class_243 m2 = VecHelper.offsetRandomly(motion.method_1021(2f), world.field_9229, .5f);
			world.method_8406(new AirParticleData(1, 1 / 4f), location.field_1352, location.field_1351, location.field_1350, m2.field_1352, m2.field_1351, m2.field_1350);
		}
	}

	@Override
	protected void transformTool(class_4587 ms, float flip, float equipProgress, float recoil, float pt) {
		ms.method_46416(flip * -.1f, 0, .14f);
		ms.method_22905(.75f, .75f, .75f);
		TransformStack.of(ms)
			.rotateXDegrees(recoil * 80);
	}

	@Override
	protected void transformHand(class_4587 ms, float flip, float equipProgress, float recoil, float pt) {
		ms.method_22904(flip * -.09, -.275, -.25);
		TransformStack.of(ms)
			.rotateZDegrees(flip * -10);
	}

}
