package com.simibubi.create.content.decoration.palettes;

import java.util.List;
import net.minecraft.class_1058;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllSpriteShifts;
import com.simibubi.create.foundation.block.connected.AllCTTypes;
import com.simibubi.create.foundation.block.connected.CTSpriteShiftEntry;
import com.simibubi.create.foundation.block.connected.CTType;
import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;

public class WeatheredIronWindowCTBehaviour extends ConnectedTextureBehaviour.Base {

	private List<CTSpriteShiftEntry> shifts;

	public WeatheredIronWindowCTBehaviour() {
		this.shifts = List.of(AllSpriteShifts.OLD_FACTORY_WINDOW_1, AllSpriteShifts.OLD_FACTORY_WINDOW_2,
			AllSpriteShifts.OLD_FACTORY_WINDOW_3, AllSpriteShifts.OLD_FACTORY_WINDOW_4);
	}

	@Override
	public @Nullable CTSpriteShiftEntry getShift(class_2680 state, class_5819 rand, class_2350 direction,
		@NotNull class_1058 sprite) {
		if (direction.method_10166() == class_2351.field_11052 || sprite == null)
			return null;
		CTSpriteShiftEntry entry = shifts.get(rand.method_43048(shifts.size()));
		if (entry.getOriginal() == sprite)
			return entry;
		return super.getShift(state, rand, direction, sprite);
	}

	@Override
	public @Nullable CTSpriteShiftEntry getShift(class_2680 state, class_2350 direction,
		@Nullable class_1058 sprite) {
		return null;
	}

	@Override
	public @Nullable CTType getDataType(class_1920 world, class_2338 pos, class_2680 state, class_2350 direction) {
		return AllCTTypes.RECTANGLE;
	}

}
