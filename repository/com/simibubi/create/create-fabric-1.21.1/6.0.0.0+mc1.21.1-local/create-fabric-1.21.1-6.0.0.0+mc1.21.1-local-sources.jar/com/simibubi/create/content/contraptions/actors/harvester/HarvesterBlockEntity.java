package com.simibubi.create.content.contraptions.actors.harvester;

import com.simibubi.create.foundation.blockEntity.CachedRenderBBBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2591;
import net.minecraft.class_2680;

public class HarvesterBlockEntity extends CachedRenderBBBlockEntity {

	// For simulations such as Ponder
	private float manuallyAnimatedSpeed;

	public HarvesterBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
	}

	@Override
	protected class_238 createRenderBoundingBox() {
		return new class_238(field_11867);
	}

	public float getAnimatedSpeed() {
		return manuallyAnimatedSpeed;
	}

	public void setAnimatedSpeed(float speed) {
		manuallyAnimatedSpeed = speed;
	}

}
