package com.simibubi.create.content.contraptions.bearing;

import com.simibubi.create.content.contraptions.DirectionalExtenderScrollOptionSlot;
import com.simibubi.create.content.contraptions.IControlContraption;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBoxTransform;
import net.minecraft.class_2350.class_2351;

public interface IBearingBlockEntity extends IControlContraption {

	float getInterpolatedAngle(float partialTicks);

	boolean isWoodenTop();

	default ValueBoxTransform getMovementModeSlot() {
		return new DirectionalExtenderScrollOptionSlot((state, d) -> {
			class_2351 axis = d.method_10166();
			class_2351 bearingAxis = state.method_11654(BearingBlock.FACING)
				.method_10166();
			return bearingAxis != axis;
		});
	}
	
	void setAngle(float forcedAngle);

}
