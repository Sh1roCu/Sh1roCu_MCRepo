package com.simibubi.create.content.equipment.toolbox;

import org.apache.commons.lang3.mutable.MutableBoolean;

import com.simibubi.create.AllPackets;
import com.simibubi.create.foundation.utility.PersistentDataHelper;

import net.createmod.catnip.nbt.NBTHelper;
import net.createmod.catnip.net.base.ServerboundPacketPayload;

import io.netty.buffer.ByteBuf;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.item.PlayerInventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_3222;
import net.minecraft.class_9139;
import com.simibubi.create.infrastructure.fabric.transfer.TransferUtil;

public record ToolboxDisposeAllPacket(class_2338 toolboxPos) implements ServerboundPacketPayload {
	public static final class_9139<ByteBuf, com.simibubi.create.content.equipment.toolbox.ToolboxDisposeAllPacket> STREAM_CODEC = class_2338.field_48404.method_56432(
			com.simibubi.create.content.equipment.toolbox.ToolboxDisposeAllPacket::new, com.simibubi.create.content.equipment.toolbox.ToolboxDisposeAllPacket::toolboxPos
	);

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.TOOLBOX_DISPOSE_ALL;
	}

	@Override
	public void handle(class_3222 player) {
		class_1937 world = player.method_37908();
		class_2586 blockEntity = world.method_8321(toolboxPos);

		double maxRange = ToolboxHandler.getMaxRange(player);
		if (player.method_5649(toolboxPos.method_10263() + 0.5, toolboxPos.method_10264(), toolboxPos.method_10260() + 0.5) > maxRange
				* maxRange)
			return;
		if (!(blockEntity instanceof ToolboxBlockEntity toolbox))
			return;

		class_2487 compound = PersistentDataHelper.get(player)
				.method_10562("CreateToolboxData");
		MutableBoolean sendData = new MutableBoolean(false);

			toolbox.inventory.inLimitedMode(inventory -> {
				try (Transaction t = Transaction.openOuter()) {
					PlayerInventoryStorage playerInv = PlayerInventoryStorage.of(player);
					for (int i = 0; i < 36; i++) {
						String key = String.valueOf(i);
						if (compound.method_10545(key) && NBTHelper.readBlockPos(compound.method_10562(key), "Pos")
							.equals(toolboxPos)) {
							ToolboxHandler.unequip(player, i, true);
							sendData.setTrue();
						}

						SingleSlotStorage<ItemVariant> slot = playerInv.getSlot(i);
						if (slot.isResourceBlank())
							continue;
						long amount = slot.getAmount();
						ItemVariant resource = slot.getResource();

						long inserted = inventory.insert(resource, amount, t);
						if (inserted == 0)
							continue;
						slot.extract(resource, inserted, t);
					}
					t.commit();
				}
			});

		if (sendData.booleanValue())
			ToolboxHandler.syncData(player);
	}
}
