package com.simibubi.create.api.behaviour.spouting;

import com.simibubi.create.api.registry.SimpleRegistry;
import com.simibubi.create.content.fluids.spout.SpoutBlockEntity;
import com.simibubi.create.infrastructure.fabric.transfer.fluid.FluidStack;
import net.minecraft.class_156;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3611;
import net.minecraft.class_3612;

/**
 * {@link BlockSpoutingBehaviour} for empty cauldrons. Mods can register their fluids
 * to {@link #CAULDRON_INFO} to allow spouts to fill empty cauldrons with their fluids.
 */
public enum CauldronSpoutingBehavior implements BlockSpoutingBehaviour {
	INSTANCE;

	public static final SimpleRegistry<class_3611, CauldronInfo> CAULDRON_INFO = class_156.method_656(() -> {
		SimpleRegistry<class_3611, CauldronInfo> registry = SimpleRegistry.create();
		registry.register(class_3612.field_15910, new CauldronInfo(250, class_2246.field_27097));
		registry.register(class_3612.field_15908, new CauldronInfo(1000, class_2246.field_27098));
		return registry;
	});

	@Override
	public long fillBlock(class_1937 level, class_2338 pos, SpoutBlockEntity spout, FluidStack availableFluid, boolean simulate) {
		CauldronInfo info = CAULDRON_INFO.get(availableFluid.getFluid());
		if (info == null)
			return 0;

		if (availableFluid.getAmount() < info.amount)
			return 0;

		if (!simulate) {
			level.method_8501(pos, info.cauldron);
		}

		return info.amount;
	}

	/**
	 * @param amount the amount of fluid that must be inserted into an empty cauldron
	 * @param cauldron the BlockState to set after filling an empty cauldron with the given amount of fluid
	 */
	public record CauldronInfo(int amount, class_2680 cauldron) {
		public CauldronInfo(int amount, class_2248 block) {
			this(amount, block.method_9564());
		}
	}
}
