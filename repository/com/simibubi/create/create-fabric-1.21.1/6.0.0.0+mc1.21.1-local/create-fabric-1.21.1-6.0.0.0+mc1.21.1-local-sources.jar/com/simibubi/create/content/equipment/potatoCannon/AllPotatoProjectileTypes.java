package com.simibubi.create.content.equipment.potatoCannon;

import com.simibubi.create.AllItems;
import com.simibubi.create.Create;
import com.simibubi.create.api.equipment.potatoCannon.PotatoCannonProjectileType;
import com.simibubi.create.api.registry.CreateRegistries;
import com.simibubi.create.content.equipment.potatoCannon.AllPotatoProjectileBlockHitActions.PlaceBlockOnGround;
import com.simibubi.create.content.equipment.potatoCannon.AllPotatoProjectileBlockHitActions.PlantCrop;
import com.simibubi.create.content.equipment.potatoCannon.AllPotatoProjectileEntityHitActions.ChorusTeleport;
import com.simibubi.create.content.equipment.potatoCannon.AllPotatoProjectileEntityHitActions.CureZombieVillager;
import com.simibubi.create.content.equipment.potatoCannon.AllPotatoProjectileEntityHitActions.FoodEffects;
import com.simibubi.create.content.equipment.potatoCannon.AllPotatoProjectileEntityHitActions.PotionEffect;
import com.simibubi.create.content.equipment.potatoCannon.AllPotatoProjectileEntityHitActions.SetOnFire;
import com.simibubi.create.content.equipment.potatoCannon.AllPotatoProjectileEntityHitActions.SuspiciousStew;
import net.minecraft.class_1294;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_4176;
import net.minecraft.class_5321;
import net.minecraft.class_7891;

public class AllPotatoProjectileTypes {
	public static final class_5321<PotatoCannonProjectileType> FALLBACK = class_5321.method_29179(CreateRegistries.POTATO_PROJECTILE_TYPE, Create.asResource("fallback"));

	public static void bootstrap(class_7891<PotatoCannonProjectileType> ctx) {
		register(ctx, "fallback", new PotatoCannonProjectileType.Builder()
			.damage(0)
			.build());

		register(ctx, "potato", new PotatoCannonProjectileType.Builder()
			.damage(5)
			.reloadTicks(15)
			.velocity(1.25f)
			.knockback(1.5f)
			.renderTumbling()
			.onBlockHit(new PlantCrop(class_2246.field_10247))
			.addItems(class_1802.field_8567)
			.build());

		register(ctx, "baked_potato", new PotatoCannonProjectileType.Builder()
			.damage(5)
			.reloadTicks(15)
			.velocity(1.25f)
			.knockback(0.5f)
			.renderTumbling()
			.preEntityHit(SetOnFire.seconds(3))
			.addItems(class_1802.field_8512)
			.build());

		register(ctx, "carrot", new PotatoCannonProjectileType.Builder()
			.damage(4)
			.reloadTicks(12)
			.velocity(1.45f)
			.knockback(0.3f)
			.renderTowardMotion(140, 1)
			.soundPitch(1.5f)
			.onBlockHit(new PlantCrop(class_2246.field_10609))
			.addItems(class_1802.field_8179)
			.build());

		register(ctx, "golden_carrot", new PotatoCannonProjectileType.Builder()
			.damage(12)
			.reloadTicks(15)
			.velocity(1.45f)
			.knockback(0.5f)
			.renderTowardMotion(140, 2)
			.soundPitch(1.5f)
			.addItems(class_1802.field_8071)
			.build());

		register(ctx, "sweet_berry", new PotatoCannonProjectileType.Builder()
			.damage(3)
			.reloadTicks(10)
			.knockback(0.1f)
			.velocity(1.05f)
			.renderTumbling()
			.splitInto(3)
			.soundPitch(1.25f)
			.addItems(class_1802.field_16998)
			.build());

		register(ctx, "glow_berry", new PotatoCannonProjectileType.Builder()
			.damage(2)
			.reloadTicks(10)
			.knockback(0.05f)
			.velocity(1.05f)
			.renderTumbling()
			.splitInto(2)
			.soundPitch(1.2f)
			.onEntityHit(new PotionEffect(class_1294.field_5912, 1, 200, false))
			.addItems(class_1802.field_28659)
			.build());

		register(ctx, "chocolate_berry", new PotatoCannonProjectileType.Builder()
			.damage(4)
			.reloadTicks(10)
			.knockback(0.2f)
			.velocity(1.05f)
			.renderTumbling()
			.splitInto(3)
			.soundPitch(1.25f)
			.addItems(AllItems.CHOCOLATE_BERRIES.get())
			.build());

		register(ctx, "poison_potato", new PotatoCannonProjectileType.Builder()
			.damage(5)
			.reloadTicks(15)
			.knockback(0.05f)
			.velocity(1.25f)
			.renderTumbling()
			.onEntityHit(new PotionEffect(class_1294.field_5899, 1, 160, true))
			.addItems(class_1802.field_8635)
			.build());

		register(ctx, "chorus_fruit", new PotatoCannonProjectileType.Builder()
			.damage(3)
			.reloadTicks(15)
			.velocity(1.20f)
			.knockback(0.05f)
			.renderTumbling()
			.onEntityHit(new ChorusTeleport(20))
			.addItems(class_1802.field_8233)
			.build());

		register(ctx, "apple", new PotatoCannonProjectileType.Builder()
			.damage(5)
			.reloadTicks(10)
			.velocity(1.45f)
			.knockback(0.5f)
			.renderTumbling()
			.soundPitch(1.1f)
			.addItems(class_1802.field_8279)
			.build());

		register(ctx, "honeyed_apple", new PotatoCannonProjectileType.Builder()
			.damage(6)
			.reloadTicks(15)
			.velocity(1.35f)
			.knockback(0.1f)
			.renderTumbling()
			.soundPitch(1.1f)
			.onEntityHit(new PotionEffect(class_1294.field_5909, 2, 160, true))
			.addItems(AllItems.HONEYED_APPLE.get())
			.build());

		register(ctx, "golden_apple", new PotatoCannonProjectileType.Builder()
			.damage(1)
			.reloadTicks(100)
			.velocity(1.45f)
			.knockback(0.05f)
			.renderTumbling()
			.soundPitch(1.1f)
			.onEntityHit(CureZombieVillager.INSTANCE)
			.addItems(class_1802.field_8463)
			.build());

		register(ctx, "enchanted_golden_apple", new PotatoCannonProjectileType.Builder()
			.damage(1)
			.reloadTicks(100)
			.velocity(1.45f)
			.knockback(0.05f)
			.renderTumbling()
			.soundPitch(1.1f)
			.onEntityHit(new FoodEffects(class_4176.field_18657, false))
			.addItems(class_1802.field_8367)
			.build());

		register(ctx, "beetroot", new PotatoCannonProjectileType.Builder()
			.damage(2)
			.reloadTicks(5)
			.velocity(1.6f)
			.knockback(0.1f)
			.renderTowardMotion(140, 2)
			.soundPitch(1.6f)
			.addItems(class_1802.field_8186)
			.build());

		register(ctx, "melon_slice", new PotatoCannonProjectileType.Builder()
			.damage(3)
			.reloadTicks(8)
			.knockback(0.1f)
			.velocity(1.45f)
			.renderTumbling()
			.soundPitch(1.5f)
			.addItems(class_1802.field_8497)
			.build());

		register(ctx, "glistering_melon", new PotatoCannonProjectileType.Builder()
			.damage(5)
			.reloadTicks(8)
			.knockback(0.1f)
			.velocity(1.45f)
			.renderTumbling()
			.soundPitch(1.5f)
			.onEntityHit(new PotionEffect(class_1294.field_5912, 1, 100, true))
			.addItems(class_1802.field_8597)
			.build());

		register(ctx, "melon_block", new PotatoCannonProjectileType.Builder()
			.damage(8)
			.reloadTicks(20)
			.knockback(2.0f)
			.velocity(0.95f)
			.renderTumbling()
			.soundPitch(0.9f)
			.onBlockHit(new PlaceBlockOnGround(class_2246.field_46283))
			.addItems(class_2246.field_46283)
			.build());

		register(ctx, "pumpkin_block", new PotatoCannonProjectileType.Builder()
			.damage(6)
			.reloadTicks(15)
			.knockback(2.0f)
			.velocity(0.95f)
			.renderTumbling()
			.soundPitch(0.9f)
			.onBlockHit(new PlaceBlockOnGround(class_2246.field_46282))
			.addItems(class_2246.field_46282)
			.build());

		register(ctx, "pumpkin_pie", new PotatoCannonProjectileType.Builder()
			.damage(7)
			.reloadTicks(15)
			.knockback(0.05f)
			.velocity(1.1f)
			.renderTumbling()
			.sticky()
			.soundPitch(1.1f)
			.addItems(class_1802.field_8741)
			.build());

		register(ctx, "cake", new PotatoCannonProjectileType.Builder()
			.damage(8)
			.reloadTicks(15)
			.knockback(0.1f)
			.velocity(1.1f)
			.renderTumbling()
			.sticky()
			.addItems(class_1802.field_17534)
			.build());

		register(ctx, "blaze_cake", new PotatoCannonProjectileType.Builder()
			.damage(15)
			.reloadTicks(20)
			.knockback(0.3f)
			.velocity(1.1f)
			.renderTumbling()
			.sticky()
			.preEntityHit(SetOnFire.seconds(12))
			.addItems(AllItems.BLAZE_CAKE.get())
			.build());

		register(ctx, "fish", new PotatoCannonProjectileType.Builder()
			.damage(4)
			.knockback(0.6f)
			.velocity(1.3f)
			.renderTowardMotion(140, 1)
			.sticky()
			.soundPitch(1.3f)
			.addItems(class_1802.field_8429, class_1802.field_8373, class_1802.field_8209, class_1802.field_8509, class_1802.field_8846)
			.build());

		register(ctx, "pufferfish", new PotatoCannonProjectileType.Builder()
			.damage(4)
			.knockback(0.4f)
			.velocity(1.1f)
			.renderTowardMotion(140, 1)
			.sticky()
			.onEntityHit(new FoodEffects(class_4176.field_18628, false))
			.soundPitch(1.1f)
			.addItems(class_1802.field_8323)
			.build());

		register(ctx, "suspicious_stew", new PotatoCannonProjectileType.Builder()
			.damage(3)
			.reloadTicks(40)
			.knockback(0.2f)
			.velocity(0.8f)
			.renderTowardMotion(140, 1)
			.dropStack(class_1802.field_8428.method_7854())
			.onEntityHit(SuspiciousStew.INSTANCE)
			.addItems(class_1802.field_8766)
			.build());
	}

	private static void register(class_7891<PotatoCannonProjectileType> ctx, String name, PotatoCannonProjectileType type) {
		ctx.method_46838(class_5321.method_29179(CreateRegistries.POTATO_PROJECTILE_TYPE, Create.asResource(name)), type);
	}
}
