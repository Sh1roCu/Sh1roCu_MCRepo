package com.simibubi.create.content.contraptions.piston;

import static com.simibubi.create.content.contraptions.piston.MechanicalPistonBlock.isExtensionPole;
import static com.simibubi.create.content.contraptions.piston.MechanicalPistonBlock.isPiston;
import static com.simibubi.create.content.contraptions.piston.MechanicalPistonBlock.isPistonHead;

import java.util.function.Predicate;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllShapes;
import com.simibubi.create.content.contraptions.piston.MechanicalPistonBlock.PistonState;
import com.simibubi.create.content.equipment.wrench.IWrenchable;
import com.simibubi.create.foundation.block.WrenchableDirectionalBlock;
import com.simibubi.create.foundation.placement.PoleHelper;

import net.createmod.catnip.placement.IPlacementHelper;
import net.createmod.catnip.placement.PlacementHelpers;
import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2741;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_6328;
import net.minecraft.class_9062;

public class PistonExtensionPoleBlock extends WrenchableDirectionalBlock implements IWrenchable, class_3737 {

	private static final int placementHelperId = PlacementHelpers.register(PlacementHelper.get());

	public PistonExtensionPoleBlock(class_2251 properties) {
		super(properties);
		method_9590(method_9564().method_11657(field_10927, class_2350.field_11036).method_11657(class_2741.field_12508, false));
	}

	@Override
	public class_2680 method_9576(class_1937 worldIn, class_2338 pos, class_2680 state, class_1657 player) {
		class_2351 axis = state.method_11654(field_10927)
			.method_10166();
		class_2350 direction = class_2350.method_10156(class_2352.field_11056, axis);
		class_2338 pistonHead = null;
		class_2338 pistonBase = null;

		for (int modifier : new int[]{1, -1}) {
			for (int offset = modifier; modifier * offset < MechanicalPistonBlock.maxAllowedPistonPoles(); offset +=
				modifier) {
				class_2338 currentPos = pos.method_10079(direction, offset);
				class_2680 block = worldIn.method_8320(currentPos);

				if (isExtensionPole(block) && axis == block.method_11654(field_10927)
					.method_10166())
					continue;

				if (isPiston(block) && block.method_11654(class_2741.field_12525)
					.method_10166() == axis)
					pistonBase = currentPos;

				if (isPistonHead(block) && block.method_11654(class_2741.field_12525)
					.method_10166() == axis)
					pistonHead = currentPos;

				break;
			}
		}

		if (pistonHead != null && pistonBase != null && worldIn.method_8320(pistonHead)
			.method_11654(class_2741.field_12525) == worldIn.method_8320(pistonBase)
			.method_11654(class_2741.field_12525)) {

			final class_2338 basePos = pistonBase;
			class_2338.method_20437(pistonBase, pistonHead)
				.filter(p -> !p.equals(pos) && !p.equals(basePos))
				.forEach(p -> worldIn.method_22352(p, !player.method_7337()));
			worldIn.method_8501(basePos, worldIn.method_8320(basePos)
				.method_11657(MechanicalPistonBlock.STATE, PistonState.RETRACTED));

			class_2586 be = worldIn.method_8321(basePos);
			if (be instanceof MechanicalPistonBlockEntity baseBE) {
				baseBE.offset = 0;
				baseBE.onLengthBroken();
			}
		}

		return super.method_9576(worldIn, pos, state, player);
	}

	@Override
	public class_265 method_9530(class_2680 state, class_1922 worldIn, class_2338 pos, class_3726 context) {
		return AllShapes.FOUR_VOXEL_POLE.get(state.method_11654(field_10927)
			.method_10166());
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		class_3610 FluidState = context.method_8045()
			.method_8316(context.method_8037());
		return method_9564().method_11657(field_10927, context.method_8038()
				.method_10153())
			.method_11657(class_2741.field_12508, Boolean.valueOf(FluidState.method_15772() == class_3612.field_15910));
	}

	@Override
	protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
        IPlacementHelper placementHelper = PlacementHelpers.get(placementHelperId);
        if (placementHelper.matchesItem(stack) && !player.method_5715())
			return placementHelper.getOffset(player, level, state, pos, hitResult).placeInWorld(level, (class_1747) stack.method_7909(), player, hand, hitResult);

		return class_9062.field_47731;
	}

	@Override
	public class_3610 method_9545(class_2680 state) {
		return state.method_11654(class_2741.field_12508) ? class_3612.field_15910.method_15729(false)
			: class_3612.field_15906.method_15785();
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> builder) {
		builder.method_11667(class_2741.field_12508);
		super.method_9515(builder);
	}

	@Override
	public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighbourState, class_1936 world, class_2338 pos, class_2338 neighbourPos) {
		if (state.method_11654(class_2741.field_12508))
			world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
		return state;
	}

	@Override
	protected boolean method_9516(class_2680 state, class_10 pathComputationType) {
		return false;
	}

	@class_6328
	public static class PlacementHelper extends PoleHelper<class_2350> {

		private static final PlacementHelper instance = new PlacementHelper();

		public static PlacementHelper get() {
			return instance;
		}

		private PlacementHelper() {
			super(
				AllBlocks.PISTON_EXTENSION_POLE::has,
				state -> state.method_11654(field_10927).method_10166(),
				field_10927
			);
		}

		@Override
		public Predicate<class_1799> getItemPredicate() {
			return AllBlocks.PISTON_EXTENSION_POLE::isIn;
		}
	}
}
