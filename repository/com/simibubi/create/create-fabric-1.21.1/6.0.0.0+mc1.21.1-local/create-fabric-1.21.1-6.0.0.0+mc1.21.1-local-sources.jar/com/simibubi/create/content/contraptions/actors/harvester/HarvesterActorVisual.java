package com.simibubi.create.content.contraptions.actors.harvester;

import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.contraptions.render.ActorVisual;
import com.simibubi.create.foundation.virtualWorld.VirtualRenderWorld;

import dev.engine_room.flywheel.api.visualization.VisualizationContext;
import dev.engine_room.flywheel.lib.instance.InstanceTypes;
import dev.engine_room.flywheel.lib.instance.TransformedInstance;
import dev.engine_room.flywheel.lib.model.Models;
import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;

public class HarvesterActorVisual extends ActorVisual {
    static float originOffset = 1 / 16f;
    static class_243 rotOffset = new class_243(0.5f, -2 * originOffset + 0.5f, originOffset + 0.5f);

    protected TransformedInstance harvester;
    private class_2350 facing;

    protected float horizontalAngle;

    private double rotation;
    private double previousRotation;

    public HarvesterActorVisual(VisualizationContext visualizationContext, VirtualRenderWorld simulationWorld, MovementContext movementContext) {
        super(visualizationContext, simulationWorld, movementContext);

        class_2680 state = movementContext.state;

        facing = state.method_11654(class_2741.field_12481);

        harvester = instancerProvider.instancer(InstanceTypes.TRANSFORMED, Models.partial(getRollingPartial()))
				.createInstance();

        horizontalAngle = facing.method_10144() + ((facing.method_10166() == class_2350.class_2351.field_11048) ? 180 : 0);

		harvester.light(localBlockLight(), 0);
		harvester.setChanged();
	}

	protected PartialModel getRollingPartial() {
		return AllPartialModels.HARVESTER_BLADE;
	}

	protected class_243 getRotationOffset() {
		return rotOffset;
	}

	protected double getRadius() {
		return 6.5;
	}

	@Override
	public void tick() {
		super.tick();

		previousRotation = rotation;

		if (context.contraption.stalled || context.disabled
			|| VecHelper.isVecPointingTowards(context.relativeMotion, facing.method_10153()))
			return;

		double arcLength = context.motion.method_1033();

		double radians = arcLength * 16 / getRadius();

		float deg = AngleHelper.deg(radians);

		deg = (float) (((int) (deg * 3000)) / 3000);

		rotation += deg * 1.25;

		rotation %= 360;
	}

    @Override
    public void beginFrame() {
        harvester.setIdentityTransform()
				.translate(context.localPos)
				.center()
				.rotateYDegrees(horizontalAngle)
				.uncenter()
				.translate(getRotationOffset())
				.rotateXDegrees((float) getRotation())
				.translateBack(getRotationOffset())
				.setChanged();
	}

	@Override
	protected void _delete() {
		harvester.delete();
	}

	protected double getRotation() {
        return AngleHelper.angleLerp(AnimationTickHolder.getPartialTicks(), previousRotation, rotation);
    }
}
