package com.simibubi.create.content.contraptions.behaviour;

import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.decoration.slidingDoor.SlidingDoorBlock;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2750;
import net.minecraft.class_2756;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3499.class_3501;

public class DoorMovingInteraction extends SimpleBlockMovingInteraction {

	@Override
	protected class_2680 handle(class_1657 player, Contraption contraption, class_2338 pos, class_2680 currentState) {
		if (!(currentState.method_26204() instanceof class_2323))
			return currentState;

		boolean trainDoor = currentState.method_26204() instanceof SlidingDoorBlock;
		class_3414 sound = currentState.method_11654(class_2323.field_10945) ? trainDoor ? null : class_3417.field_14541
			: trainDoor ? class_3417.field_14567 : class_3417.field_14664;

		class_2338 otherPos = currentState.method_11654(class_2323.field_10946) == class_2756.field_12607 ? pos.method_10084() : pos.method_10074();
		class_3501 info = contraption.getBlocks()
			.get(otherPos);
		if (info != null && info.comp_1342().method_28498(class_2323.field_10945)) {
			class_2680 newState = info.comp_1342().method_28493(class_2323.field_10945);
			setContraptionBlockData(contraption.entity, otherPos, new class_3501(info.comp_1341(), newState, info.comp_1343()));
		}

		currentState = currentState.method_28493(class_2323.field_10945);

		if (player != null) {

			if (trainDoor) {
				class_2750 hinge = currentState.method_11654(SlidingDoorBlock.field_10941);
				class_2350 facing = currentState.method_11654(SlidingDoorBlock.field_10938);
				class_2338 doublePos =
					pos.method_10093(hinge == class_2750.field_12588 ? facing.method_10170() : facing.method_10160());
				class_3501 doubleInfo = contraption.getBlocks()
					.get(doublePos);
				if (doubleInfo != null && SlidingDoorBlock.isDoubleDoor(currentState, hinge, facing, doubleInfo.comp_1342()))
					handlePlayerInteraction(null, class_1268.field_5808, doublePos, contraption.entity);
			}

			float pitch = player.method_37908().field_9229.method_43057() * 0.1F + 0.9F;
			if (sound != null)
				playSound(player, sound, pitch);
		}

		return currentState;
	}

	@Override
	protected boolean updateColliders() {
		return true;
	}

}
