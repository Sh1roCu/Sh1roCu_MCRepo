package com.simibubi.create.content.decoration.palettes;

import static com.simibubi.create.content.decoration.palettes.PaletteBlockPattern.STANDARD_RANGE;
import static com.simibubi.create.content.decoration.palettes.PaletteBlockPattern.VANILLA_RANGE;

import java.util.function.Function;

import com.simibubi.create.AllTags;
import com.simibubi.create.Create;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.tterrag.registrate.util.nullness.NonNullSupplier;

import net.createmod.catnip.lang.Lang;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_3620;
import net.minecraft.class_6862;
import net.minecraft.class_7923;

public enum AllPaletteStoneTypes {

	GRANITE(VANILLA_RANGE, r -> () -> class_2246.field_10474),
	DIORITE(VANILLA_RANGE, r -> () -> class_2246.field_10508),
	ANDESITE(VANILLA_RANGE, r -> () -> class_2246.field_10115),
	CALCITE(VANILLA_RANGE, r -> () -> class_2246.field_27114),
	DRIPSTONE(VANILLA_RANGE, r -> () -> class_2246.field_28049),
	DEEPSLATE(VANILLA_RANGE, r -> () -> class_2246.field_28888),
	TUFF(VANILLA_RANGE, r -> () -> class_2246.field_27165),

	ASURINE(STANDARD_RANGE, r -> r.paletteStoneBlock("asurine", () -> class_2246.field_28888, true, true)
		.properties(p -> p.method_36557(1.25f)
			.method_31710(class_3620.field_15984))
		.register()),

	CRIMSITE(STANDARD_RANGE, r -> r.paletteStoneBlock("crimsite", () -> class_2246.field_28888, true, true)
		.properties(p -> p.method_36557(1.25f)
			.method_31710(class_3620.field_16020))
		.register()),

	LIMESTONE(STANDARD_RANGE, r -> r.paletteStoneBlock("limestone", () -> class_2246.field_9979, true, false)
		.properties(p -> p.method_36557(1.25f)
			.method_31710(class_3620.field_15986))
		.register()),

	OCHRUM(STANDARD_RANGE, r -> r.paletteStoneBlock("ochrum", () -> class_2246.field_27114, true, true)
		.properties(p -> p.method_36557(1.25f)
			.method_31710(class_3620.field_16013))
		.register()),

	SCORIA(STANDARD_RANGE, r -> r.paletteStoneBlock("scoria", () -> class_2246.field_23869, true, false)
		.properties(p -> p.method_31710(class_3620.field_15977))
		.register()),

	SCORCHIA(STANDARD_RANGE, r -> r.paletteStoneBlock("scorchia", () -> class_2246.field_23869, true, false)
		.properties(p -> p.method_31710(class_3620.field_16027))
		.register()),

	VERIDIUM(STANDARD_RANGE, r -> r.paletteStoneBlock("veridium", () -> class_2246.field_27165, true, true)
		.properties(p -> p.method_36557(1.25f)
			.method_31710(class_3620.field_25705))
		.register())

	;

	private Function<CreateRegistrate, NonNullSupplier<class_2248>> factory;
	private PalettesVariantEntry variants;

	public NonNullSupplier<class_2248> baseBlock;
	public PaletteBlockPattern[] variantTypes;
	public class_6862<class_1792> materialTag;

	private AllPaletteStoneTypes(PaletteBlockPattern[] variantTypes,
		Function<CreateRegistrate, NonNullSupplier<class_2248>> factory) {
		this.factory = factory;
		this.variantTypes = variantTypes;
	}

	public NonNullSupplier<class_2248> getBaseBlock() {
		return baseBlock;
	}

	public PalettesVariantEntry getVariants() {
		return variants;
	}

	public static void register(CreateRegistrate registrate) {
		for (AllPaletteStoneTypes paletteStoneVariants : values()) {
			NonNullSupplier<class_2248> baseBlock = paletteStoneVariants.factory.apply(registrate);
			paletteStoneVariants.baseBlock = baseBlock;
			String id = Lang.asId(paletteStoneVariants.name());
			paletteStoneVariants.materialTag =
				AllTags.optionalTag(class_7923.field_41178, Create.asResource("stone_types/" + id));
			paletteStoneVariants.variants = new PalettesVariantEntry(id, paletteStoneVariants);
		}
	}

}
