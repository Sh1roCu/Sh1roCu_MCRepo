package com.simibubi.create.content.decoration;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllSpriteShifts;
import com.simibubi.create.foundation.block.connected.CTSpriteShiftEntry;
import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;
import net.minecraft.class_1058;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

public class TrapdoorCTBehaviour extends ConnectedTextureBehaviour.Base {

	@Override
	public CTSpriteShiftEntry getShift(class_2680 state, class_2350 direction, @Nullable class_1058 sprite) {
		return AllSpriteShifts.FRAMED_GLASS;
	}

	@Override
	public boolean connectsTo(class_2680 state, class_2680 other, class_1920 reader, class_2338 pos,
		class_2338 otherPos, class_2350 face, class_2350 primaryOffset, class_2350 secondaryOffset) {
		return state.method_26204() == other.method_26204()
			&& TrainTrapdoorBlock.isConnected(state, other, primaryOffset == null ? secondaryOffset : primaryOffset);
	}

}
