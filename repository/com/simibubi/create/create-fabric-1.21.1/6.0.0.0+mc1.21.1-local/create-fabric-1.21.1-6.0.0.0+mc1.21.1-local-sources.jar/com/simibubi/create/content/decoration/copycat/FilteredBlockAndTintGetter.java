package com.simibubi.create.content.decoration.copycat;

import java.util.function.Predicate;
import net.minecraft.class_1920;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3568;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_6539;

public class FilteredBlockAndTintGetter implements class_1920 {

	private class_1920 wrapped;
	private Predicate<class_2338> filter;

	public FilteredBlockAndTintGetter(class_1920 wrapped, Predicate<class_2338> filter) {
		this.wrapped = wrapped;
		this.filter = filter;
	}

	@Override
	public class_2586 method_8321(class_2338 pPos) {
		return filter.test(pPos) ? wrapped.method_8321(pPos) : null;
	}

	@Override
	public class_2680 method_8320(class_2338 pPos) {
		return filter.test(pPos) ? wrapped.method_8320(pPos) : class_2246.field_10124.method_9564();
	}

	@Override
	public class_3610 method_8316(class_2338 pPos) {
		return filter.test(pPos) ? wrapped.method_8316(pPos) : class_3612.field_15906.method_15785();
	}

	@Override
	public int method_31605() {
		return wrapped.method_31605();
	}

	@Override
	public int method_31607() {
		return wrapped.method_31607();
	}

	@Override
	public float method_24852(class_2350 pDirection, boolean pShade) {
		return wrapped.method_24852(pDirection, pShade);
	}

	@Override
	public class_3568 method_22336() {
		return wrapped.method_22336();
	}

	@Override
	public int method_23752(class_2338 pBlockPos, class_6539 pColorResolver) {
		return wrapped.method_23752(pBlockPos, pColorResolver);
	}

}
