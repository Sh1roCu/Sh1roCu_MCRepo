package com.simibubi.create.content.contraptions.gantry;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllContraptionTypes;
import com.simibubi.create.api.contraption.ContraptionType;
import com.simibubi.create.content.contraptions.AssemblyException;
import com.simibubi.create.content.contraptions.TranslatingContraption;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_3499.class_3501;
import net.minecraft.class_7225;

public class GantryContraption extends TranslatingContraption {

	protected class_2350 facing;

	public GantryContraption() {}

	public GantryContraption(class_2350 facing) {
		this.facing = facing;
	}

	@Override
	public boolean assemble(class_1937 world, class_2338 pos) throws AssemblyException {
		if (!searchMovedStructure(world, pos, null))
			return false;
		startMoving(world);
		return true;
	}

	@Override
	public class_2487 writeNBT(class_7225.class_7874 registries, boolean spawnPacket) {
		class_2487 tag = super.writeNBT(registries, spawnPacket);
		tag.method_10569("Facing", facing.method_10146());
		return tag;
	}

	@Override
	public void readNBT(class_1937 world, class_2487 tag, boolean spawnData) {
		facing = class_2350.method_10143(tag.method_10550("Facing"));
		super.readNBT(world, tag, spawnData);
	}

	@Override
	protected boolean isAnchoringBlockAt(class_2338 pos) {
		return super.isAnchoringBlockAt(pos.method_10093(facing));
	}

	@Override
	public ContraptionType getType() {
		return AllContraptionTypes.GANTRY.comp_349();
	}

	public class_2350 getFacing() {
		return facing;
	}

	@Override
	protected boolean shouldUpdateAfterMovement(class_3501 info) {
		return super.shouldUpdateAfterMovement(info) && !AllBlocks.GANTRY_CARRIAGE.has(info.comp_1342());
	}

}
