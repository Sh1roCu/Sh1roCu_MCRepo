package com.simibubi.create.content.decoration.bracket;

import java.util.Optional;

import com.simibubi.create.content.fluids.FluidPropagator;
import com.simibubi.create.content.kinetics.base.DirectionalAxisKineticBlock;
import com.simibubi.create.content.kinetics.base.RotatedPillarKineticBlock;
import com.simibubi.create.content.kinetics.simpleRelays.AbstractSimpleShaftBlock;
import com.simibubi.create.content.kinetics.simpleRelays.CogWheelBlock;
import com.simibubi.create.foundation.block.WrenchableDirectionalBlock;

import net.createmod.catnip.lang.Lang;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3542;

public class BracketBlock extends WrenchableDirectionalBlock {

	public static final class_2746 AXIS_ALONG_FIRST_COORDINATE =
		DirectionalAxisKineticBlock.AXIS_ALONG_FIRST_COORDINATE;
	public static final class_2754<BracketType> TYPE = class_2754.method_11850("type", BracketType.class);

	public static enum BracketType implements class_3542 {
		PIPE, COG, SHAFT;

		@Override
		public String method_15434() {
			return Lang.asId(name());
		}

	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> builder) {
		super.method_9515(builder.method_11667(AXIS_ALONG_FIRST_COORDINATE)
			.method_11667(TYPE));
	}

	public BracketBlock(class_2251 properties) {
		super(properties);
	}

	public Optional<class_2680> getSuitableBracket(class_2680 blockState, class_2350 direction) {
		if (blockState.method_26204() instanceof AbstractSimpleShaftBlock)
			return getSuitableBracket(blockState.method_11654(RotatedPillarKineticBlock.AXIS), direction,
				blockState.method_26204() instanceof CogWheelBlock ? BracketType.COG : BracketType.SHAFT);
		return getSuitableBracket(FluidPropagator.getStraightPipeAxis(blockState), direction, BracketType.PIPE);
	}

	private Optional<class_2680> getSuitableBracket(class_2351 targetBlockAxis, class_2350 direction, BracketType type) {
		class_2351 axis = direction.method_10166();
		if (targetBlockAxis == null || targetBlockAxis == axis)
			return Optional.empty();

		boolean alongFirst = axis != class_2351.field_11051 ? targetBlockAxis == class_2351.field_11051 : targetBlockAxis == class_2351.field_11052;
		return Optional.of(method_9564().method_11657(TYPE, type)
			.method_11657(field_10927, direction)
			.method_11657(AXIS_ALONG_FIRST_COORDINATE, !alongFirst));
	}

	@Override
	public class_2680 method_9598(class_2680 state, class_2470 rot) {
		if (rot.ordinal() % 2 == 1)
			state = state.method_28493(AXIS_ALONG_FIRST_COORDINATE);
		return super.method_9598(state, rot);
	}

}
