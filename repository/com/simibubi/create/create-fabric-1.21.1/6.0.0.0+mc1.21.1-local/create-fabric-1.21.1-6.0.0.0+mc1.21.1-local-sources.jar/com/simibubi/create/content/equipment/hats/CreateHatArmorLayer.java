package com.simibubi.create.content.equipment.hats;

import java.util.ArrayList;
import java.util.List;
import com.simibubi.create.content.trains.schedule.hat.TrainHatInfo;
import com.simibubi.create.content.trains.schedule.hat.TrainHatInfoReloadListener;
import com.simibubi.create.foundation.mixin.accessor.AgeableListModelAccessor;
import com.simibubi.create.foundation.mixin.accessor.EntityRenderDispatcherAccessor;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import dev.engine_room.flywheel.lib.transform.TransformStack;

import io.github.fabricators_of_create.porting_lib.mixin.accessors.client.accessor.ModelPartAccessor;

import net.createmod.catnip.render.CachedBuffers;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback.RegistrationHelper;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4592;
import net.minecraft.class_4597;
import net.minecraft.class_4722;
import net.minecraft.class_5597;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.class_630.class_628;
import net.minecraft.class_897;
import net.minecraft.class_922;

public class CreateHatArmorLayer<T extends class_1309, M extends class_583<T>> extends class_3887<T, M> {

	public CreateHatArmorLayer(class_3883<T, M> renderer) {
			super(renderer);
	}

		public void render(class_4587 ms, class_4597 buffer, int light, class_1309 entity, float limbSwing, float limbSwingAmount,
		float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
			PartialModel hat = EntityHats.getHatFor(entity);
			if (hat == null)
				return;

			M entityModel = method_17165();
				ms.method_22903();

				var msr = TransformStack.of(ms);
				TrainHatInfo info = TrainHatInfoReloadListener.getHatInfoFor(entity.method_5864());
				List<class_630> partsToHead = new ArrayList<>();

				if (entityModel instanceof class_4592<?> model) {
					if (model.field_3448) {
						AgeableListModelAccessor accessor = (AgeableListModelAccessor) model;
						if (accessor.getScaleHead()) {
							float f = 1.5F / accessor.getBabyHeadScale();
							ms.method_22905(f, f, f);
						}
						ms.method_22904(0.0D, accessor.getBabyYHeadOffset() / 16.0F, accessor.getBabyZHeadOffset() / 16.0F);
					}

					class_630 head = getHeadPart(model);
					if (head != null) {
						partsToHead.addAll(TrainHatInfo.getAdjustedPart(info, head, ""));
					}
				} else if (entityModel instanceof class_5597<?> model) {
					partsToHead.addAll(TrainHatInfo.getAdjustedPart(info, model.method_32008(), "head"));
				}

				if (!partsToHead.isEmpty()) {
					partsToHead.forEach(part -> part.method_22703(ms));

					class_630 lastChild = partsToHead.get(partsToHead.size() - 1);
					if (!lastChild.method_32087()) {
						List<class_628> cubes = ((ModelPartAccessor) (Object) lastChild).porting_lib$cubes();
						class_628 cube = cubes.get(class_3532.method_15340(info.cubeIndex(), 0, cubes.size() - 1));
						ms.method_22904(info.offset().method_10216() / 16.0F, (cube.field_3644 - cube.field_3647 + info.offset().method_10214()) / 16.0F, info.offset().method_10215() / 16.0F);
						float max = Math.max(cube.field_3648 - cube.field_3645, cube.field_3646 - cube.field_3643) / 8.0F * info.scale();
						ms.method_22905(max, max, max);
					}

					ms.method_22905(1, -1, -1);
					ms.method_46416(0, -2.25F / 16.0F, 0);
					msr.rotateXDegrees(-8.5F);
					class_2680 air = class_2246.field_10124.method_9564();
					CachedBuffers.partial(hat, air)
						.disableDiffuse()
						.light(light)
						.renderInto(ms, buffer.getBuffer(class_4722.method_24074()));
				}

				ms.method_22909();
			}

			// fabric: remove registerOnAll, event is per-renderer

			public static void registerOn(class_897<?> entityRenderer, RegistrationHelper helper) {
				if (!(entityRenderer instanceof class_922<?, ?> livingRenderer))
					return;

				class_583<?> model = livingRenderer.method_4038();

				if (!(model instanceof class_5597) && !(model instanceof class_4592))
					return;

				CreateHatArmorLayer<?, ?> layer = new CreateHatArmorLayer<>(livingRenderer);
				helper.register(layer);
			}

			private static class_630 getHeadPart(class_4592<?> model) {
				for (class_630 part : ((AgeableListModelAccessor) model).create$callHeadParts())
					return part;
				for (class_630 part : ((AgeableListModelAccessor) model).create$callBodyParts())
					return part;
				return null;
			}

		}
