package com.simibubi.create.content.contraptions.actors.seat;

import java.util.List;

import javax.annotation.ParametersAreNonnullByDefault;

import com.google.common.base.Optional;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllShapes;
import com.simibubi.create.AllTags.AllEntityTags;
import com.simibubi.create.foundation.block.ProperWaterloggedBlock;
import com.simibubi.create.foundation.utility.AdventureUtil;
import com.simibubi.create.foundation.utility.BlockHelper;
import com.simibubi.create.infrastructure.config.AllConfigs;

import net.fabricmc.fabric.api.registry.LandPathNodeTypesRegistry;
import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1606;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_3610;
import net.minecraft.class_3726;
import net.minecraft.class_3727;
import net.minecraft.class_3965;
import net.minecraft.class_6328;
import net.minecraft.class_7;
import net.minecraft.class_9062;
import net.fabricmc.fabric.api.entity.FakePlayer;

import io.github.fabricators_of_create.porting_lib.util.TagUtil;

@ParametersAreNonnullByDefault
@class_6328
public class SeatBlock extends class_2248 implements ProperWaterloggedBlock {

	protected final class_1767 color;

	public SeatBlock(class_2251 properties, class_1767 color) {
		super(properties);
		this.color = color;
		method_9590(method_9564().method_11657(WATERLOGGED, false));
		LandPathNodeTypesRegistry.register(this, class_7.field_21, null);
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> pBuilder) {
		super.method_9515(pBuilder.method_11667(WATERLOGGED));
	}

	@Override
	public class_2680 method_9605(class_1750 pContext) {
		return withWater(super.method_9605(pContext), pContext);
	}

	@Override
	public class_2680 method_9559(class_2680 pState, class_2350 pDirection, class_2680 pNeighborState,
		class_1936 pLevel, class_2338 pCurrentPos, class_2338 pNeighborPos) {
		updateWater(pLevel, pState, pCurrentPos);
		return pState;
	}

	@Override
	public class_3610 method_9545(class_2680 pState) {
		return fluidState(pState);
	}

	@Override
	public void method_9554(class_1937 p_152426_, class_2680 p_152427_, class_2338 p_152428_, class_1297 p_152429_, float p_152430_) {
		super.method_9554(p_152426_, p_152427_, p_152428_, p_152429_, p_152430_ * 0.5F);
	}

	@Override
	public void method_9502(class_1922 reader, class_1297 entity) {
		class_2338 pos = entity.method_24515();
		if (entity instanceof class_1657 || !(entity instanceof class_1309) || !canBePickedUp(entity)
			|| isSeatOccupied(entity.method_37908(), pos)) {
			if (entity.method_21750()) {
				super.method_9502(reader, entity);
				return;
			}

			class_243 vec3 = entity.method_18798();
			if (vec3.field_1351 < 0.0D) {
				double d0 = entity instanceof class_1309 ? 1.0D : 0.8D;
				entity.method_18800(vec3.field_1352, -vec3.field_1351 * (double) 0.66F * d0, vec3.field_1350);
			}

			return;
		}
		if (reader.method_8320(pos)
			.method_26204() != this)
			return;
		sitDown(entity.method_37908(), pos, entity);
	}

	@Override
	public class_265 method_9530(class_2680 p_220053_1_, class_1922 p_220053_2_, class_2338 p_220053_3_,
		class_3726 p_220053_4_) {
		return AllShapes.SEAT;
	}

	@Override
	public class_265 method_9549(class_2680 p_220071_1_, class_1922 p_220071_2_, class_2338 p_220071_3_,
		class_3726 ctx) {
		if (ctx instanceof class_3727 ecc && ecc.method_32480() instanceof class_1657)
			return AllShapes.SEAT_COLLISION_PLAYERS;
		return AllShapes.SEAT_COLLISION;
	}

	@Override
	protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
		if (player.method_5715() || player instanceof FakePlayer)
			return class_9062.field_47731;

		class_1799 heldItem = player.method_5998(hand);
		class_1767 color = TagUtil.getColorFromStack(heldItem);
		if (color != null && color != this.color) {
			if (level.field_9236)
				return class_9062.field_47728;
			class_2680 newState = BlockHelper.copyProperties(state, AllBlocks.SEATS.get(color)
				.getDefaultState());
			level.method_8501(pos, newState);
			return class_9062.field_47728;
		}

		List<SeatEntity> seats = level.method_18467(SeatEntity.class, new class_238(pos));
		if (!seats.isEmpty()) {
			SeatEntity seatEntity = seats.get(0);
			List<class_1297> passengers = seatEntity.method_5685();
			if (!passengers.isEmpty() && !canReplaceSeatedEntity(passengers.get(0), player))
				return class_9062.field_47731;
			if (!level.field_9236) {
				seatEntity.method_5772();
				player.method_5804(seatEntity);
			}
			return class_9062.field_47728;
		}

		if (level.field_9236)
			return class_9062.field_47728;
		sitDown(level, pos, getLeashed(level, player).or(player));
		return class_9062.field_47728;
	}

	public static boolean canReplaceSeatedEntity(class_1297 seated, class_1657 player) {
		return !(seated instanceof class_1657) && !AdventureUtil.isAdventure(player);
	}

	public static boolean isSeatOccupied(class_1937 world, class_2338 pos) {
		return !world.method_18467(SeatEntity.class, new class_238(pos))
			.isEmpty();
	}

	public static Optional<class_1297> getLeashed(class_1937 level, class_1657 player) {
		List<class_1297> entities = player.method_37908().method_8333((class_1297) null, player.method_5829()
			.method_1014(10), e -> true);
		for (class_1297 e : entities)
			if (e instanceof class_1308 mob && mob.method_60952() == player && SeatBlock.canBePickedUp(e))
				return Optional.of(mob);
		return Optional.absent();
	}

	public static boolean canBePickedUp(class_1297 passenger) {
		if (passenger instanceof class_1606)
			return false;
		if (passenger instanceof class_1657)
			return false;
		if (AllEntityTags.IGNORE_SEAT.matches(passenger))
			return false;
		if (!AllConfigs.server().logistics.seatHostileMobs.get() && !passenger.method_5864()
			.method_5891()
			.method_6136())
			return false;
		return passenger instanceof class_1309;
	}

	public static void sitDown(class_1937 world, class_2338 pos, class_1297 entity) {
		if (world.field_9236)
			return;
		SeatEntity seat = new SeatEntity(world, pos);
		seat.method_5814(pos.method_10263() + .5f, pos.method_10264(), pos.method_10260() + .5f);
		world.method_8649(seat);
		entity.method_5873(seat, true);
		if (entity instanceof class_1321 ta)
			ta.method_6179(true);
	}

	public class_1767 getColor() {
		return color;
	}

	@Override
	protected boolean method_9516(class_2680 state, class_10 pathComputationType) {
		return false;
	}

}
