package com.simibubi.create.content.decoration.girder;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_638;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllItems;

import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.data.Pair;
import net.createmod.catnip.math.VecHelper;
import net.createmod.catnip.outliner.Outliner;
import net.createmod.catnip.placement.IPlacementHelper;
import net.createmod.catnip.theme.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class GirderWrenchBehavior {

	@Environment(EnvType.CLIENT)
	public static void tick() {
		class_310 mc = class_310.method_1551();
		if (mc.field_1724 == null || mc.field_1687 == null || !(mc.field_1765 instanceof class_3965 result))
			return;

		class_638 world = mc.field_1687;
		class_2338 pos = result.method_17777();
		class_1657 player = mc.field_1724;
		class_1799 heldItem = player.method_6047();

		if (player.method_5715())
			return;

		if (!AllBlocks.METAL_GIRDER.has(world.method_8320(pos)))
			return;

		if (!AllItems.WRENCH.isIn(heldItem))
			return;

		Pair<class_2350, Action> dirPair = getDirectionAndAction(result, world, pos);
		if (dirPair == null)
			return;

		class_243 center = VecHelper.getCenterOf(pos);
		class_243 edge = center.method_1019(class_243.method_24954(dirPair.getFirst()
			.method_10163())
			.method_1021(0.4));
		class_2350.class_2351[] axes = Arrays.stream(Iterate.axes)
			.filter(axis -> axis != dirPair.getFirst()
				.method_10166())
			.toArray(class_2350.class_2351[]::new);

		double normalMultiplier = dirPair.getSecond() == Action.PAIR ? 4 : 1;
		class_243 corner1 = edge
			.method_1019(class_243.method_24954(class_2350.method_10169(axes[0], class_2350.class_2352.field_11056)
				.method_10163())
				.method_1021(0.3))
			.method_1019(class_243.method_24954(class_2350.method_10169(axes[1], class_2350.class_2352.field_11056)
				.method_10163())
				.method_1021(0.3))
			.method_1019(class_243.method_24954(dirPair.getFirst()
				.method_10163())
				.method_1021(0.1 * normalMultiplier));

		normalMultiplier = dirPair.getSecond() == Action.HORIZONTAL ? 9 : 2;
		class_243 corner2 = edge
			.method_1019(class_243.method_24954(class_2350.method_10169(axes[0], class_2350.class_2352.field_11060)
				.method_10163())
				.method_1021(0.3))
			.method_1019(class_243.method_24954(class_2350.method_10169(axes[1], class_2350.class_2352.field_11060)
				.method_10163())
				.method_1021(0.3))
			.method_1019(class_243.method_24954(dirPair.getFirst()
				.method_10153()
				.method_10163())
				.method_1021(0.1 * normalMultiplier));

		Outliner.getInstance().showAABB("girderWrench", new class_238(corner1, corner2))
			.lineWidth(1 / 32f)
			.colored(new Color(127, 127, 127));
	}

	@Nullable
	private static Pair<class_2350, Action> getDirectionAndAction(class_3965 result, class_1937 world, class_2338 pos) {
		List<Pair<class_2350, Action>> validDirections = getValidDirections(world, pos);

		if (validDirections.isEmpty())
			return null;

		List<class_2350> directions = IPlacementHelper.orderedByDistance(pos, result.method_17784(),
			validDirections.stream()
				.map(Pair::getFirst)
				.toList());

		if (directions.isEmpty())
			return null;

		class_2350 dir = directions.get(0);
		return validDirections.stream()
			.filter(pair -> pair.getFirst() == dir)
			.findFirst()
			.orElseGet(() -> Pair.of(dir, Action.SINGLE));
	}

	public static List<Pair<class_2350, Action>> getValidDirections(class_1922 level, class_2338 pos) {
		class_2680 blockState = level.method_8320(pos);

		if (!AllBlocks.METAL_GIRDER.has(blockState))
			return Collections.emptyList();

		return Arrays.stream(Iterate.directions)
			.<Pair<class_2350, Action>>mapMulti((direction, consumer) -> {
				class_2680 other = level.method_8320(pos.method_10093(direction));

				if (!blockState.method_11654(GirderBlock.X) && !blockState.method_11654(GirderBlock.Z))
					return;

				// up and down
				if (direction.method_10166() == class_2350.class_2351.field_11052) {
					// no other girder in target dir
					if (!AllBlocks.METAL_GIRDER.has(other)) {
						if (!blockState.method_11654(GirderBlock.X) ^ !blockState.method_11654(GirderBlock.Z))
							consumer.accept(Pair.of(direction, Action.SINGLE));
						return;
					}
					// this girder is a pole or cross
					if (blockState.method_11654(GirderBlock.X) == blockState.method_11654(GirderBlock.Z))
						return;
					// other girder is a pole or cross
					if (other.method_11654(GirderBlock.X) == other.method_11654(GirderBlock.Z))
						return;
					// toggle up/down connection for both
					consumer.accept(Pair.of(direction, Action.PAIR));

					return;
				}

//					if (AllBlocks.METAL_GIRDER.has(other))
//						consumer.accept(Pair.of(direction, Action.HORIZONTAL));

			})
			.toList();
	}

	public static boolean handleClick(class_1937 level, class_2338 pos, class_2680 state, class_3965 result) {
		Pair<class_2350, Action> dirPair = getDirectionAndAction(result, level, pos);
		if (dirPair == null)
			return false;
		if (level.field_9236)
			return true;
		if (!state.method_11654(GirderBlock.X) && !state.method_11654(GirderBlock.Z))
			return false;

		class_2350 dir = dirPair.getFirst();

		class_2338 otherPos = pos.method_10093(dir);
		class_2680 other = level.method_8320(otherPos);

		if (dir == class_2350.field_11036) {
			level.method_8652(pos, postProcess(state.method_28493(GirderBlock.TOP)), 2 | 16);
			if (dirPair.getSecond() == Action.PAIR && AllBlocks.METAL_GIRDER.has(other))
				level.method_8652(otherPos, postProcess(other.method_28493(GirderBlock.BOTTOM)), 2 | 16);
			return true;
		}

		if (dir == class_2350.field_11033) {
			level.method_8652(pos, postProcess(state.method_28493(GirderBlock.BOTTOM)), 2 | 16);
			if (dirPair.getSecond() == Action.PAIR && AllBlocks.METAL_GIRDER.has(other))
				level.method_8652(otherPos, postProcess(other.method_28493(GirderBlock.TOP)), 2 | 16);
			return true;
		}

//		if (dirPair.getSecond() == Action.HORIZONTAL) {
//			BooleanProperty property = dir.getAxis() == Direction.Axis.X ? GirderBlock.X : GirderBlock.Z;
//			level.setBlock(pos, state.cycle(property), 2 | 16);
//
//			return true;
//		}

		return true;
	}

	private static class_2680 postProcess(class_2680 newState) {
		if (newState.method_11654(GirderBlock.TOP) && newState.method_11654(GirderBlock.BOTTOM))
			return newState;
		if (newState.method_11654(GirderBlock.AXIS) != class_2351.field_11052)
			return newState;
		return newState.method_11657(GirderBlock.AXIS, newState.method_11654(GirderBlock.X) ? class_2351.field_11048 : class_2351.field_11051);
	}

	private enum Action {
		SINGLE, PAIR, HORIZONTAL
	}

}
