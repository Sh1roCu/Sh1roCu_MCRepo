package com.simibubi.create.content.equipment.clipboard;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3542;
import net.minecraft.class_5272;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

import com.mojang.serialization.Codec;
import com.simibubi.create.AllDataComponents;
import com.simibubi.create.Create;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateItemModelProvider;

import io.netty.buffer.ByteBuf;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecBuilders;
import net.createmod.catnip.lang.Lang;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile.UncheckedModelFile;
import io.github.fabricators_of_create.porting_lib.models.generators.ItemModelBuilder;

public class ClipboardOverrides {

	public enum ClipboardType implements class_3542 {
		EMPTY("empty_clipboard"), WRITTEN("clipboard"), EDITING("clipboard_and_quill");

		public static final Codec<ClipboardType> CODEC = class_3542.method_53955(ClipboardType::values);
		public static final class_9139<ByteBuf, ClipboardType> STREAM_CODEC = CatnipStreamCodecBuilders.ofEnum(ClipboardType.class);

		public String file;
		public static class_2960 ID = Create.asResource("clipboard_type");

		ClipboardType(String file) {
			this.file = file;
		}

		@Override
		public @NotNull String method_15434() {
			return Lang.asId(name());
		}
	}

	public static void switchTo(ClipboardType type, class_1799 clipboardItem) {
		clipboardItem.method_57379(AllDataComponents.CLIPBOARD_TYPE, type);
	}

	@Environment(EnvType.CLIENT)
	public static void registerModelOverridesClient(ClipboardBlockItem item) {
		class_5272.method_27879(item, ClipboardType.ID, (pStack, pLevel, pEntity, pSeed) ->
				pStack.method_57825(AllDataComponents.CLIPBOARD_TYPE, ClipboardType.EMPTY).ordinal()
		);
	}

	public static ItemModelBuilder addOverrideModels(DataGenContext<class_1792, ClipboardBlockItem> c,
		RegistrateItemModelProvider p) {
		ItemModelBuilder builder = p.generated(c::get);
		for (ClipboardType type : ClipboardType.values()) {
			int i = type.ordinal();
			builder.override()
					.predicate(ClipboardType.ID, i)
					.model(p.getBuilder(c.getName() + "_" + i)
							.parent(new UncheckedModelFile("item/generated"))
							.texture("layer0", Create.asResource("item/" + type.file)))
					.end();
		}
		return builder;
	}

}
