package com.simibubi.create.content.equipment;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1839;
import net.minecraft.class_1937;

public class BuildersTeaItem extends class_1792 {
	public BuildersTeaItem(class_1793 properties) {
		super(properties);
	}

	@Override
	public class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 livingEntity) {
		class_1799 eatResult = super.method_7861(stack, level, livingEntity);
		if (livingEntity instanceof class_1657 player && !player.method_31549().field_7477) {
			if (eatResult.method_7960()) {
				return class_1802.field_8469.method_7854();
			} else {
				player.method_31548().method_7394(class_1802.field_8469.method_7854());
			}
		}
		return eatResult;
	}

	@Override
	public int method_7881(class_1799 stack, class_1309 entity) {
		return 42;
	}

	@Override
	public class_1839 method_7853(class_1799 stack) {
		return class_1839.field_8946;
	}
}
