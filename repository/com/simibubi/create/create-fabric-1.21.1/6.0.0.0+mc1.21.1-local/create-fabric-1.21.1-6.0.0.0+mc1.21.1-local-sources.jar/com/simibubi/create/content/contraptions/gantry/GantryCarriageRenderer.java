package com.simibubi.create.content.contraptions.gantry;

import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;

import dev.engine_room.flywheel.api.visualization.VisualizationManager;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SuperByteBuffer;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;

public class GantryCarriageRenderer extends KineticBlockEntityRenderer<GantryCarriageBlockEntity> {

	public GantryCarriageRenderer(class_5614.class_5615 context) {
		super(context);
	}

	@Override
	protected void renderSafe(GantryCarriageBlockEntity be, float partialTicks, class_4587 ms, class_4597 buffer,
		int light, int overlay) {
		super.renderSafe(be, partialTicks, ms, buffer, light, overlay);

		if (VisualizationManager.supportsVisualization(be.method_10997())) return;

		class_2680 state = be.method_11010();
		class_2350 facing = state.method_11654(GantryCarriageBlock.FACING);
		Boolean alongFirst = state.method_11654(GantryCarriageBlock.AXIS_ALONG_FIRST_COORDINATE);
		class_2351 rotationAxis = getRotationAxisOf(be);
		class_2338 visualPos = facing.method_10171() == class_2352.field_11056 ? be.method_11016()
				: be.method_11016()
				.method_10093(facing.method_10153());
		float angleForBE = getAngleForBE(be, visualPos, rotationAxis);

		class_2351 gantryAxis = class_2351.field_11048;
		for (class_2351 axis : Iterate.axes)
			if (axis != rotationAxis && axis != facing.method_10166())
				gantryAxis = axis;

		if (gantryAxis == class_2351.field_11048)
			if (facing == class_2350.field_11036)
				angleForBE *= -1;
		if (gantryAxis == class_2351.field_11052)
			if (facing == class_2350.field_11043 || facing == class_2350.field_11034)
				angleForBE *= -1;

		SuperByteBuffer cogs = CachedBuffers.partial(AllPartialModels.GANTRY_COGS, state);
		cogs.center()
				.rotateYDegrees(AngleHelper.horizontalAngle(facing))
				.rotateXDegrees(facing == class_2350.field_11036 ? 0 : facing == class_2350.field_11033 ? 180 : 90)
				.rotateYDegrees(alongFirst ^ facing.method_10166() == class_2351.field_11048 ? 0 : 90)
				.translate(0, -9 / 16f, 0)
				.rotateXDegrees(-angleForBE)
				.translate(0, 9 / 16f, 0)
				.uncenter();

		cogs.light(light)
			.renderInto(ms, buffer.getBuffer(class_1921.method_23577()));

	}

	public static float getAngleForBE(KineticBlockEntity be, final class_2338 pos, class_2351 axis) {
		float time = AnimationTickHolder.getRenderTime(be.method_10997());
		float offset = getRotationOffsetForPosition(be, pos, axis);
		return (time * be.getSpeed() * 3f / 20 + offset) % 360;
	}

	@Override
	protected class_2680 getRenderedBlockState(GantryCarriageBlockEntity be) {
		return shaft(getRotationAxisOf(be));
	}

}
