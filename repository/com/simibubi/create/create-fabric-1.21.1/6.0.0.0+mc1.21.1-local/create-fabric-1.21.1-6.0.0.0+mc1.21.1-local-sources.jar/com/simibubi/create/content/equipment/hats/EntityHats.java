package com.simibubi.create.content.equipment.hats;

import javax.annotation.Nullable;

import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.actors.seat.SeatEntity;
import com.simibubi.create.content.logistics.stockTicker.StockTickerBlock;
import com.simibubi.create.content.trains.entity.CarriageContraption;
import com.simibubi.create.content.trains.entity.CarriageContraptionEntity;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import net.createmod.catnip.data.Couple;
import net.createmod.catnip.data.Iterate;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

// TODO: Behavioural Registry?
public class EntityHats {

	@Nullable
	public static PartialModel getHatFor(class_1309 entity) {
		if (entity == null)
			return null;
		class_1799 headItem = entity.method_6118(class_1304.field_6169);
		if (!headItem.method_7960())
			return null;

		if (shouldRenderTrainHat(entity))
			return AllPartialModels.TRAIN_HAT;

		return getLogisticsHatFor(entity);
	}

	public static PartialModel getLogisticsHatFor(class_1309 entity) {
		if (!entity.method_5765())
			return null;
		if (!(entity.method_5854() instanceof SeatEntity cce))
			return null;

		int stations = 0;
		class_1937 level = entity.method_37908();
		class_2338 pos = entity.method_24515();
		PartialModel hat = null;

		for (class_2350 d : Iterate.horizontalDirections) {
			for (int y : Iterate.zeroAndOne) {
				if (!(level.method_8320(pos.method_10093(d)
					.method_10086(y))
					.method_26204() instanceof StockTickerBlock lw))
					continue;
				PartialModel hatOfStation = lw.getHat(level, pos, entity);
				if (hatOfStation == null)
					continue;
				hat = hatOfStation;
				stations++;
			}
		}

		if (stations == 1)
			return hat;

		return null;
	}

	public static boolean shouldRenderTrainHat(class_1309 entity) {
		if (entity.getCustomData()
			.method_10545("TrainHat"))
			return true;
		if (!entity.method_5765())
			return false;
		if (!(entity.method_5854() instanceof CarriageContraptionEntity cce))
			return false;
		if (!cce.hasSchedule() && !(entity instanceof class_1657))
			return false;
		Contraption contraption = cce.getContraption();
		if (!(contraption instanceof CarriageContraption cc))
			return false;
		class_2338 seatOf = cc.getSeatOf(entity.method_5667());
		if (seatOf == null)
			return false;
		Couple<Boolean> validSides = cc.conductorSeats.get(seatOf);
		return validSides != null;
	}

}
