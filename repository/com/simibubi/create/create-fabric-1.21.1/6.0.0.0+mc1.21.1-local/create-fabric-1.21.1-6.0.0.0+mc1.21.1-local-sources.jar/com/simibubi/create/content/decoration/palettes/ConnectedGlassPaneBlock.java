package com.simibubi.create.content.decoration.palettes;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class ConnectedGlassPaneBlock extends GlassPaneBlock {

	public ConnectedGlassPaneBlock(class_2251 builder) {
		super(builder);
	}

	@Override
	@Environment(EnvType.CLIENT)
	public boolean method_9522(class_2680 state, class_2680 adjacentBlockState, class_2350 side) {
		if (side.method_10166()
			.method_10178())
			return adjacentBlockState == state;
		return super.method_9522(state, adjacentBlockState, side);
	}

}
