package com.simibubi.create.content.contraptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;

import com.simibubi.create.AllTags.AllMountedItemStorageTypeTags;

import net.createmod.catnip.codecs.CatnipCodecUtils;

import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.SlottedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.CombinedSlottedStorage;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3499.class_3501;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;
import com.simibubi.create.Create;
import com.simibubi.create.api.contraption.storage.SyncedMountedStorage;
import com.simibubi.create.api.contraption.storage.fluid.MountedFluidStorage;
import com.simibubi.create.api.contraption.storage.fluid.MountedFluidStorageType;
import com.simibubi.create.api.contraption.storage.fluid.MountedFluidStorageWrapper;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorage;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorageType;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorageWrapper;
import com.simibubi.create.content.equipment.toolbox.ToolboxMountedStorage;
import com.simibubi.create.content.fluids.tank.storage.FluidTankMountedStorage;
import com.simibubi.create.content.fluids.tank.storage.creative.CreativeFluidTankMountedStorage;
import com.simibubi.create.content.logistics.crate.CreativeCrateMountedStorage;
import com.simibubi.create.content.logistics.depot.storage.DepotMountedStorage;
import com.simibubi.create.content.logistics.vault.ItemVaultMountedStorage;

import net.createmod.catnip.nbt.NBTHelper;
import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.SlottedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.CombinedSlottedStorage;

public class MountedStorageManager {
	// builders used during assembly, null afterward
	// ImmutableMap.Builder is not used because it will throw with duplicate keys, not override them
	private Map<class_2338, MountedItemStorage> itemsBuilder;
	private Map<class_2338, MountedFluidStorage> fluidsBuilder;
	private Map<class_2338, SyncedMountedStorage> syncedItemsBuilder;
	private Map<class_2338, SyncedMountedStorage> syncedFluidsBuilder;

	// built data structures after assembly, null before
	private ImmutableMap<class_2338, MountedItemStorage> allItemStorages;
	// different from allItemStorages, does not contain internal ones
	protected MountedItemStorageWrapper items;
	@Nullable
	protected MountedItemStorageWrapper fuelItems;
	protected MountedFluidStorageWrapper fluids;

	private ImmutableMap<class_2338, SyncedMountedStorage> syncedItems;
	private ImmutableMap<class_2338, SyncedMountedStorage> syncedFluids;

	private List<SlottedStorage<ItemVariant>> externalHandlers;
	private CombinedSlottedStorage<ItemVariant, ? extends SlottedStorage<ItemVariant>> allItems;

	// ticks until storage can sync again
	private int syncCooldown;

	// client-side: not all storages are synced, this determines which interactions are valid
	private Set<class_2338> interactablePositions;

	public MountedStorageManager() {
		this.reset();
	}

	public void initialize() {
		if (this.isInitialized()) {
			// originally this threw an exception to try to catch mistakes.
			// however, in the case where a Contraption is deserialized before its Entity, that would also throw,
			// since both the deserialization and the onEntityCreated callback initialize the storage.
			// this case occurs when placing a picked up minecart contraption.
			// the reverse case is fine since deserialization also resets the manager first.
			return;
		}

		this.allItemStorages = ImmutableMap.copyOf(this.itemsBuilder);

		this.items = new MountedItemStorageWrapper(subMap(this.allItemStorages, this::isExposed));

		this.allItems = this.items;
		this.itemsBuilder = null;

		ImmutableMap<class_2338, MountedItemStorage> fuelMap = subMap(this.allItemStorages, this::canUseForFuel);
		this.fuelItems = fuelMap.isEmpty() ? null : new MountedItemStorageWrapper(fuelMap);

		ImmutableMap<class_2338, MountedFluidStorage> fluids = ImmutableMap.copyOf(this.fluidsBuilder);
		this.fluids = new MountedFluidStorageWrapper(fluids);
		this.fluidsBuilder = null;

		this.syncedItems = ImmutableMap.copyOf(this.syncedItemsBuilder);
		this.syncedItemsBuilder = null;
		this.syncedFluids = ImmutableMap.copyOf(this.syncedFluidsBuilder);
		this.syncedFluidsBuilder = null;
	}

	private boolean isExposed(MountedItemStorage storage) {
		return !AllMountedItemStorageTypeTags.INTERNAL.matches(storage);
	}

	private boolean canUseForFuel(MountedItemStorage storage) {
		return this.isExposed(storage) && !AllMountedItemStorageTypeTags.FUEL_BLACKLIST.matches(storage);
	}

	private boolean isInitialized() {
		return this.itemsBuilder == null;
	}

	private void assertInitialized() {
		if (!this.isInitialized()) {
			throw new IllegalStateException("MountedStorageManager is uninitialized");
		}
	}

	protected void reset() {
		this.allItemStorages = null;
		this.items = null;
		this.fuelItems = null;
		this.fluids = null;
		this.externalHandlers = new ArrayList<>();
		this.allItems = null;
		this.itemsBuilder = new HashMap<>();
		this.fluidsBuilder = new HashMap<>();
		this.syncedItemsBuilder = new HashMap<>();
		this.syncedFluidsBuilder = new HashMap<>();
		// interactablePositions intentionally not reset
	}

	public void addBlock(class_1937 level, class_2680 state, class_2338 globalPos, class_2338 localPos, @Nullable class_2586 be) {
		MountedItemStorageType<?> itemType = MountedItemStorageType.REGISTRY.get(state.method_26204());
		if (itemType != null) {
			MountedItemStorage storage = itemType.mount(level, state, globalPos, be);
			if (storage != null) {
				this.addStorage(storage, localPos);
			}
		}

		MountedFluidStorageType<?> fluidType = MountedFluidStorageType.REGISTRY.get(state.method_26204());
		if (fluidType != null) {
			MountedFluidStorage storage = fluidType.mount(level, state, globalPos, be);
			if (storage != null) {
				this.addStorage(storage, localPos);
			}
		}
	}

	public void unmount(class_1937 level, class_3501 info, class_2338 globalPos, @Nullable class_2586 be) {
		class_2338 localPos = info.comp_1341();
		class_2680 state = info.comp_1342();

		MountedItemStorage itemStorage = this.getAllItemStorages().get(localPos);
		if (itemStorage != null) {
			MountedItemStorageType<?> expectedType = MountedItemStorageType.REGISTRY.get(state.method_26204());
			if (itemStorage.type == expectedType) {
				itemStorage.unmount(level, state, globalPos, be);
			}
		}

		MountedFluidStorage fluidStorage = this.getFluids().storages.get(localPos);
		if (fluidStorage != null) {
			MountedFluidStorageType<?> expectedType = MountedFluidStorageType.REGISTRY.get(state.method_26204());
			if (fluidStorage.type == expectedType) {
				fluidStorage.unmount(level, state, globalPos, be);
			}
		}
	}

	public void tick(AbstractContraptionEntity entity) {
		if (this.syncCooldown > 0) {
			this.syncCooldown--;
			return;
		}

		Map<class_2338, MountedItemStorage> items = new HashMap<>();
		Map<class_2338, MountedFluidStorage> fluids = new HashMap<>();
		this.syncedItems.forEach((pos, storage) -> {
			if (storage.isDirty()) {
				items.put(pos, (MountedItemStorage) storage);
				storage.markClean();
			}
		});
		this.syncedFluids.forEach((pos, storage) -> {
			if (storage.isDirty()) {
				fluids.put(pos, (MountedFluidStorage) storage);
				storage.markClean();
			}
		});

		if (!items.isEmpty() || !fluids.isEmpty()) {
			MountedStorageSyncPacket packet = new MountedStorageSyncPacket(entity.method_5628(), items, fluids);
			CatnipServices.NETWORK.sendToClientsTrackingEntity(entity, packet);
			this.syncCooldown = 8;
		}
	}

	public void handleSync(MountedStorageSyncPacket packet, AbstractContraptionEntity entity) {
		// packet only contains changed storages, grab existing ones before resetting
		ImmutableMap<class_2338, MountedItemStorage> items = this.getAllItemStorages();
		MountedFluidStorageWrapper fluids = this.getFluids();
		this.reset();

		// track freshly synced storages
		Map<SyncedMountedStorage, class_2338> syncedStorages = new IdentityHashMap<>();

		try {
			// re-add existing ones
			this.itemsBuilder.putAll(items);
			this.fluidsBuilder.putAll(fluids.storages);
			// add newly synced ones, overriding existing ones if present
			packet.items().forEach((pos, storage) -> {
				this.itemsBuilder.put(pos, storage);
				syncedStorages.put((SyncedMountedStorage) storage, pos);
			});
			packet.fluids().forEach((pos, storage) -> {
				this.fluidsBuilder.put(pos, storage);
				syncedStorages.put((SyncedMountedStorage) storage, pos);
			});
		} catch (Throwable t) {
			// an exception will leave the manager in an invalid state
			Create.LOGGER.error("An error occurred while syncing a MountedStorageManager", t);
		}

		this.initialize();

		// call all afterSync methods
		Contraption contraption = entity.getContraption();
		syncedStorages.forEach((storage, pos) -> storage.afterSync(contraption, pos));
	}

	// contraption is provided on the client for initial afterSync storage callbacks
	public void read(class_2487 nbt, class_7225.class_7874 registries, boolean clientPacket, @Nullable Contraption contraption) {
		this.reset();

		try {
			NBTHelper.iterateCompoundList(nbt.method_10554("items", class_2520.field_33260), tag -> {
				class_2338 pos = NBTHelper.readBlockPos(tag, "pos");
				class_2487 data = tag.method_10562("storage");
				CatnipCodecUtils.decode(MountedItemStorage.CODEC, registries, data)
					.ifPresent(storage -> this.addStorage(storage, pos));
			});

			NBTHelper.iterateCompoundList(nbt.method_10554("fluids", class_2520.field_33260), tag -> {
				class_2338 pos = NBTHelper.readBlockPos(tag, "pos");
				class_2487 data = tag.method_10562("storage");
				CatnipCodecUtils.decode(MountedFluidStorage.CODEC, registries, data)
					.ifPresent(storage -> this.addStorage(storage, pos));
			});

			this.readLegacy(registries, nbt);

			if (nbt.method_10545("interactable_positions")) {
				this.interactablePositions = new HashSet<>();
				NBTHelper.iterateCompoundList(nbt.method_10554("interactable_positions", class_2520.field_33260), tag -> {
					class_2338 pos = new class_2338(tag.method_10550("X"), tag.method_10550("Y"), tag.method_10550("Z"));
					this.interactablePositions.add(pos);
				});
			}
		} catch (Throwable t) {
			Create.LOGGER.error("Error deserializing mounted storage", t);
			// an exception will leave the manager in an invalid state, initialize must be called
		}

		this.initialize();

		// for client sync, run initial afterSync callbacks
		if (!clientPacket || contraption == null)
			return;

		this.getAllItemStorages().forEach((pos, storage) -> {
			if (storage instanceof SyncedMountedStorage synced) {
				synced.afterSync(contraption, pos);
			}
		});
		this.getFluids().storages.forEach((pos, storage) -> {
			if (storage instanceof SyncedMountedStorage synced) {
				synced.afterSync(contraption, pos);
			}
		});
	}

	public void write(class_2487 nbt, class_7225.class_7874 registries, boolean clientPacket) {
		class_2499 items = new class_2499();
		this.getAllItemStorages().forEach((pos, storage) -> {
				if (!clientPacket || storage instanceof SyncedMountedStorage) {
					CatnipCodecUtils.encode(MountedItemStorage.CODEC, registries, storage).ifPresent(encoded -> {
						class_2487 tag = new class_2487();
						tag.method_10566("pos", class_2512.method_10692(pos));
						tag.method_10566("storage", encoded);
						items.add(tag);
					});
				}
			}
		);
		if (!items.isEmpty()) {
			nbt.method_10566("items", items);
		}

		class_2499 fluids = new class_2499();
		this.getFluids().storages.forEach((pos, storage) -> {
				if (!clientPacket || storage instanceof SyncedMountedStorage) {
					CatnipCodecUtils.encode(MountedFluidStorage.CODEC, registries, storage).ifPresent(encoded -> {
						class_2487 tag = new class_2487();
						tag.method_10566("pos", class_2512.method_10692(pos));
						tag.method_10566("storage", encoded);
						fluids.add(tag);
					});
				}
			}
		);
		if (!fluids.isEmpty()) {
			nbt.method_10566("fluids", fluids);
		}

		if (clientPacket) {
			// let the client know of all non-synced ones too
			SetView<class_2338> positions = Sets.union(this.getAllItemStorages().keySet(), this.getFluids().storages.keySet());
			class_2499 list = new class_2499();
			for (class_2338 pos : positions) {
				class_2487 tag = new class_2487();
				tag.method_10569("X", pos.method_10263());
				tag.method_10569("Y", pos.method_10264());
				tag.method_10569("Z", pos.method_10260());

				list.add(tag);
			}
			nbt.method_10566("interactable_positions", list);
		}
	}

	public void attachExternal(SlottedStorage<ItemVariant> externalStorage) {
		this.externalHandlers.add(externalStorage);
		List<SlottedStorage<ItemVariant>> all = new ArrayList<>(this.externalHandlers.size() + 1);
		all.add(0, this.items);
		all.addAll(this.externalHandlers);
		this.allItems = new CombinedSlottedStorage<>(all);
	}

	/**
	 * The primary way to access a contraption's inventory. Includes all
	 * non-internal mounted storages as well as all external storage.
	 */
	public CombinedSlottedStorage<ItemVariant, ? extends SlottedStorage<ItemVariant>> getAllItems() {
		this.assertInitialized();
		return this.allItems;
	}

	/**
	 * Gets a map of all MountedItemStorages in the contraption, irrelevant of them being internal or providing fuel.
	 */
	public ImmutableMap<class_2338, MountedItemStorage> getAllItemStorages() {
		this.assertInitialized();
		return this.allItemStorages;
	}

	/**
	 * Gets an item handler wrapping all non-internal mounted storages. This is not
	 * the whole contraption inventory as it does not include external storages.
	 * Most often, you want {@link #getAllItems()}, which does.
	 */
	public MountedItemStorageWrapper getMountedItems() {
		this.assertInitialized();
		return this.items;
	}

	/**
	 * Gets an item handler wrapping all non-internal mounted storages that provide fuel.
	 * May be null if none are present.
	 */
	@Nullable
	public MountedItemStorageWrapper getFuelItems() {
		this.assertInitialized();
		return this.fuelItems;
	}

	/**
	 * Gets a fluid handler wrapping all mounted fluid storages.
	 */
	public MountedFluidStorageWrapper getFluids() {
		this.assertInitialized();
		return this.fluids;
	}

	public boolean handlePlayerStorageInteraction(Contraption contraption, class_1657 player, class_2338 localPos) {
		if (!(player instanceof class_3222 serverPlayer)) {
			return this.interactablePositions != null && this.interactablePositions.contains(localPos);
		}

		class_3501 info = contraption.getBlocks().get(localPos);
		if (info == null)
			return false;

		MountedStorageManager storageManager = contraption.getStorage();
		MountedItemStorage storage = storageManager.getAllItemStorages().get(localPos);

		if (storage != null) {
			return storage.handleInteraction(serverPlayer, contraption, info);
		} else {
			return false;
		}
	}

	private void readLegacy(class_7225.class_7874 registries, class_2487 nbt) {
		NBTHelper.iterateCompoundList(nbt.method_10554("Storage", class_2520.field_33260), tag -> {
			class_2338 pos = NBTHelper.readBlockPos(tag, "Pos");
			class_2487 data = tag.method_10562("Data");

			if (data.method_10545("Toolbox")) {
				this.addStorage(ToolboxMountedStorage.fromLegacy(registries, data), pos);
			} else if (data.method_10545("NoFuel")) {
				this.addStorage(ItemVaultMountedStorage.fromLegacy(registries, data), pos);
			} else if (data.method_10545("Bottomless")) {
				class_1799 supplied = class_1799.method_57359(registries, data.method_10562("ProvidedStack"));
				this.addStorage(new CreativeCrateMountedStorage(supplied), pos);
			} else if (data.method_10545("Synced")) {
				this.addStorage(DepotMountedStorage.fromLegacy(registries, data), pos);
			}
		});

		NBTHelper.iterateCompoundList(nbt.method_10554("FluidStorage", class_2520.field_33260), tag -> {
			class_2338 pos = NBTHelper.readBlockPos(tag, "Pos");
			class_2487 data = tag.method_10562("Data");

			if (data.method_10545("Bottomless")) {
				this.addStorage(CreativeFluidTankMountedStorage.fromLegacy(registries, data), pos);
			} else {
				this.addStorage(FluidTankMountedStorage.fromLegacy(registries, data), pos);
			}
		});
	}

	private void addStorage(MountedItemStorage storage, class_2338 pos) {
		this.itemsBuilder.put(pos, storage);
		if (storage instanceof SyncedMountedStorage synced)
			this.syncedItemsBuilder.put(pos, synced);
	}

	private void addStorage(MountedFluidStorage storage, class_2338 pos) {
		this.fluidsBuilder.put(pos, storage);
		if (storage instanceof SyncedMountedStorage synced)
			this.syncedFluidsBuilder.put(pos, synced);
	}

	private static <K, V> ImmutableMap<K, V> subMap(Map<K, V> map, Predicate<V> predicate) {
		ImmutableMap.Builder<K, V> builder = ImmutableMap.builder();
		map.forEach((key, value) -> {
			if (predicate.test(value)) {
				builder.put(key, value);
			}
		});
		return builder.build();
	}
}
