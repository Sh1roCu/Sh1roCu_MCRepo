package com.simibubi.create.content.equipment.extendoGrip;

import com.mojang.blaze3d.systems.RenderSystem;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllPartialModels;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.minecraft.class_1007;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_759;
import net.minecraft.class_811;
import io.github.fabricators_of_create.porting_lib.event.client.RenderHandCallback.RenderHandEvent;
import io.github.fabricators_of_create.porting_lib.util.FirstPersonRendererHelper;

public class ExtendoGripRenderHandler {

	public static float mainHandAnimation;
	public static float lastMainHandAnimation;
	public static PartialModel pose = AllPartialModels.DEPLOYER_HAND_PUNCHING;

	public static void tick() {
		lastMainHandAnimation = mainHandAnimation;
		mainHandAnimation *= class_3532.method_15363(mainHandAnimation, 0.8f, 0.99f);

		pose = AllPartialModels.DEPLOYER_HAND_PUNCHING;
		if (!AllItems.EXTENDO_GRIP.isIn(getRenderedOffHandStack()))
			return;
		class_1799 main = getRenderedMainHandStack();
		if (main.method_7960())
			return;
		if (!(main.method_7909() instanceof class_1747))
			return;
		if (!class_310.method_1551()
			.method_1480()
			.method_4019(main, null, null, 0)
			.method_4712())
			return;
		pose = AllPartialModels.DEPLOYER_HAND_HOLDING;
	}

	public static void onRenderPlayerHand(RenderHandEvent event) {
		class_1799 heldItem = event.getItemStack();
		class_310 mc = class_310.method_1551();
		class_746 player = mc.field_1724;
		boolean rightHand = event.getHand() == class_1268.field_5808 ^ player.method_6068() == class_1306.field_6182;

		class_1799 offhandItem = getRenderedOffHandStack();
		boolean notInOffhand = !AllItems.EXTENDO_GRIP.isIn(offhandItem);
		if (notInOffhand && !AllItems.EXTENDO_GRIP.isIn(heldItem))
			return;

		class_4587 ms = event.getPoseStack();
		var msr = TransformStack.of(ms);
		class_742 abstractclientplayerentity = mc.field_1724;
		RenderSystem.setShaderTexture(0, abstractclientplayerentity.method_52814().comp_1626());

		float flip = rightHand ? 1.0F : -1.0F;
		float swingProgress = event.getSwingProgress();
		boolean blockItem = heldItem.method_7909() instanceof class_1747;
		float equipProgress = blockItem ? 0 : event.getEquipProgress() / 4;

		ms.method_22903();
		if (event.getHand() == class_1268.field_5808) {

			if (1 - swingProgress > mainHandAnimation && swingProgress > 0)
				mainHandAnimation = 0.95f;
			float animation = class_3532.method_16439(AnimationTickHolder.getPartialTicks(),
											  ExtendoGripRenderHandler.lastMainHandAnimation,
											  ExtendoGripRenderHandler.mainHandAnimation);
			animation = animation * animation * animation;

			ms.method_46416(flip * (0.64000005F - .1f), -0.4F + equipProgress * -0.6F, -0.71999997F + .3f);

			ms.method_22903();
			msr.rotateYDegrees(flip * 75.0F);
			ms.method_46416(flip * -1.0F, 3.6F, 3.5F);
			msr.rotateZDegrees(flip * 120)
				.rotateXDegrees(200)
				.rotateYDegrees(flip * -135.0F);
			ms.method_46416(flip * 5.6F, 0.0F, 0.0F);
			msr.rotateYDegrees(flip * 40.0F);
			ms.method_46416(flip * 0.05f, -0.3f, -0.3f);

			class_1007 playerrenderer = (class_1007) mc.method_1561()
				.method_3953(player);
			if (rightHand)
				playerrenderer.method_4220(event.getPoseStack(), event.getMultiBufferSource(),
					event.getPackedLight(), player);
			else
				playerrenderer.method_4221(event.getPoseStack(), event.getMultiBufferSource(),
					event.getPackedLight(), player);
			ms.method_22909();

			// Render gun
			ms.method_22903();
			ms.method_46416(flip * -0.1f, 0, -0.3f);
			class_759 firstPersonRenderer = mc.method_1561().method_43336();
			class_811 transform =
				rightHand ? class_811.field_4322 : class_811.field_4321;
				firstPersonRenderer.method_3233(mc.field_1724, notInOffhand ? heldItem : offhandItem, transform, !rightHand,
					event.getPoseStack(), event.getMultiBufferSource(), event.getPackedLight());

				if (!notInOffhand) {
					ms.method_46416(flip * -.05f, .15f, -1.2f);
					ms.method_46416(0, 0, -animation * 2.25f);
					if (blockItem && mc.method_1480()
					.method_4019(heldItem, null, null, 0)
					.method_4712()) {
					msr.rotateYDegrees(flip * 45);
					ms.method_46416(flip * 0.15f, -0.15f, -.05f);
					ms.method_22905(1.25f, 1.25f, 1.25f);
				}

				firstPersonRenderer.method_3233(mc.field_1724, heldItem, transform, !rightHand, event.getPoseStack(),
					event.getMultiBufferSource(), event.getPackedLight());
			}

			ms.method_22909();
		}
		ms.method_22909();
		event.setCanceled(true);
	}

	private static class_1799 getRenderedMainHandStack() {
		return FirstPersonRendererHelper.getStackInMainHand(class_310.method_1551().method_1561().method_43336());
	}

	private static class_1799 getRenderedOffHandStack() {
		return FirstPersonRendererHelper.getStackInOffHand(class_310.method_1551().method_1561().method_43336());
	}

}
