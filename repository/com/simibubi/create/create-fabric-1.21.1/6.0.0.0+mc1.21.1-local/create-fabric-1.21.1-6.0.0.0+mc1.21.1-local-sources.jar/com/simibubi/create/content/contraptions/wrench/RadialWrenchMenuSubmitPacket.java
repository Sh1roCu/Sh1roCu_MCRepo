package com.simibubi.create.content.contraptions.wrench;

import com.simibubi.create.AllPackets;
import com.simibubi.create.content.equipment.wrench.IWrenchable;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;

import io.netty.buffer.ByteBuf;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecs;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_9139;

public record RadialWrenchMenuSubmitPacket(class_2338 blockPos, class_2680 newState) implements ServerboundPacketPayload {
	public static final class_9139<ByteBuf, RadialWrenchMenuSubmitPacket> STREAM_CODEC = class_9139.method_56435(
	    class_2338.field_48404, RadialWrenchMenuSubmitPacket::blockPos,
		CatnipStreamCodecs.BLOCK_STATE, RadialWrenchMenuSubmitPacket::newState,
	    RadialWrenchMenuSubmitPacket::new
	);

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.RADIAL_WRENCH_MENU_SUBMIT;
	}

	@Override
	public void handle(class_3222 player) {
		class_1937 level = player.method_37908();

		if (!level.method_8320(blockPos).method_27852(newState.method_26204()))
			return;

		class_2680 updatedState = class_2248.method_9510(newState, level, blockPos);
		KineticBlockEntity.switchToBlockState(level, blockPos, updatedState);

		IWrenchable.playRotateSound(level, blockPos);
	}
}
