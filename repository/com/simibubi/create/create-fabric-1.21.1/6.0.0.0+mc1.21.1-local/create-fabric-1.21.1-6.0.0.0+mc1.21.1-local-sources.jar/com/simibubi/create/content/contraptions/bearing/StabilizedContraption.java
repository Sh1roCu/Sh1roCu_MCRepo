package com.simibubi.create.content.contraptions.bearing;

import com.simibubi.create.AllContraptionTypes;
import com.simibubi.create.api.contraption.ContraptionType;
import com.simibubi.create.content.contraptions.AssemblyException;
import com.simibubi.create.content.contraptions.Contraption;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_7225;

public class StabilizedContraption extends Contraption {

	private class_2350 facing;

	public StabilizedContraption() {}

	public StabilizedContraption(class_2350 facing) {
		this.facing = facing;
	}

	@Override
	public boolean assemble(class_1937 world, class_2338 pos) throws AssemblyException {
		class_2338 offset = pos.method_10093(facing);
		if (!searchMovedStructure(world, offset, null))
			return false;
		startMoving(world);
		if (blocks.isEmpty())
			return false;
		return true;
	}

	@Override
	protected boolean isAnchoringBlockAt(class_2338 pos) {
		return false;
	}

	@Override
	public ContraptionType getType() {
		return AllContraptionTypes.STABILIZED.comp_349();
	}

	@Override
	public class_2487 writeNBT(class_7225.class_7874 registries, boolean spawnPacket) {
		class_2487 tag = super.writeNBT(registries, spawnPacket);
		tag.method_10569("Facing", facing.method_10146());
		return tag;
	}

	@Override
	public void readNBT(class_1937 world, class_2487 tag, boolean spawnData) {
		facing = class_2350.method_10143(tag.method_10550("Facing"));
		super.readNBT(world, tag, spawnData);
	}

	@Override
	public boolean canBeStabilized(class_2350 facing, class_2338 localPos) {
		return false;
	}

	public class_2350 getFacing() {
		return facing;
	}

}
