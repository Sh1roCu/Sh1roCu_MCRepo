package com.simibubi.create.content.equipment.armor;

import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_9334;
import com.simibubi.create.AllTags.AllFluidTags;
import com.simibubi.create.foundation.advancement.AllAdvancements;

public class DivingHelmetItem extends BaseArmorItem {
	public static final class_1304 SLOT = class_1304.field_6169;
	public static final class_1738.class_8051 TYPE = class_1738.class_8051.field_41934;

	public DivingHelmetItem(class_6880<class_1741> material, class_1793 properties, class_2960 textureLoc) {
		super(material, TYPE, properties, textureLoc);
	}

	public static boolean isWornBy(class_1297 entity) {
		return !getWornItem(entity).method_7960();
	}

	public static class_1799 getWornItem(class_1297 entity) {
		if (!(entity instanceof class_1309 livingEntity)) {
			return class_1799.field_8037;
		}
		class_1799 stack = livingEntity.method_6118(SLOT);
		if (!(stack.method_7909() instanceof DivingHelmetItem)) {
			return class_1799.field_8037;
		}
		return stack;
	}

	public static void breatheUnderwater(class_1309 entity) {
		class_1937 world = entity.method_37908();
		boolean second = world.method_8510() % 20 == 0;
		boolean drowning = entity.method_5669() == 0;

		if (world.field_9236)
			entity.getCustomData()
				.method_10551("VisualBacktankAir");

		class_1799 helmet = getWornItem(entity);
		if (helmet.method_7960())
			return;

		boolean lavaDiving = entity.method_5771();
		if (!helmet.method_57826(class_9334.field_50076) && lavaDiving)
			return;
		if (!entity.method_5777(AllFluidTags.DIVING_FLUIDS.tag) && !lavaDiving)
			return;
		if (entity instanceof class_1657 && ((class_1657) entity).method_7337())
			return;

		List<class_1799> backtanks = BacktankUtil.getAllWithAir(entity);
		if (backtanks.isEmpty())
			return;

		if (lavaDiving) {
			if (entity instanceof class_3222 sp)
				AllAdvancements.DIVING_SUIT_LAVA.awardTo(sp);
			if (backtanks.stream()
				.noneMatch(backtank -> backtank.method_57826(class_9334.field_50076)))
				return;
		}

		if (drowning)
			entity.method_5855(10);

		if (world.field_9236)
			entity.getCustomData()
				.method_10569("VisualBacktankAir", Math.round(backtanks.stream()
					.map(BacktankUtil::getAir)
					.reduce(0, Integer::sum)));

		if (!second)
			return;

		BacktankUtil.consumeAir(entity, backtanks.get(0), 1);

		if (lavaDiving)
			return;

		if (entity instanceof class_3222 sp)
			AllAdvancements.DIVING_SUIT.awardTo(sp);

		entity.method_5855(Math.min(entity.method_5748(), entity.method_5669() + 10));
		entity.method_6092(new class_1293(class_1294.field_5923, 30, 0, true, false, true));
	}
}
