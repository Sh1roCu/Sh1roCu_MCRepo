package com.simibubi.create.content.contraptions.gantry;

import com.simibubi.create.AllPackets;
import net.createmod.catnip.net.base.ClientboundPacketPayload;

import io.netty.buffer.ByteBuf;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record GantryContraptionUpdatePacket(int entityID, double coord, double motion, double sequenceLimit) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, GantryContraptionUpdatePacket> STREAM_CODEC = class_9139.method_56905(
			class_9135.field_49675, GantryContraptionUpdatePacket::entityID,
			class_9135.field_48553, GantryContraptionUpdatePacket::coord,
			class_9135.field_48553, GantryContraptionUpdatePacket::motion,
			class_9135.field_48553, GantryContraptionUpdatePacket::sequenceLimit,
			GantryContraptionUpdatePacket::new
	);

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		class_310 minecraft = class_310.method_1551();
		if (minecraft.method_18854()) {
			GantryContraptionEntity.handlePacket(this);
			return;
		}
		minecraft.execute(() -> GantryContraptionEntity.handlePacket(this));
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.GANTRY_UPDATE;
	}
}
