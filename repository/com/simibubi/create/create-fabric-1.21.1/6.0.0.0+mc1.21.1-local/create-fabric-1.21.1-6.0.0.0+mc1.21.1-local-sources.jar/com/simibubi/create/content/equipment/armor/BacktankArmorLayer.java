package com.simibubi.create.content.equipment.armor;

import net.createmod.catnip.animation.AnimationTickHolder;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SuperByteBuffer;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback.RegistrationHelper;
import net.minecraft.class_1309;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4050;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4722;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_897;
import net.minecraft.class_922;

public class BacktankArmorLayer<T extends class_1309, M extends class_583<T>> extends class_3887<T, M> {

	public BacktankArmorLayer(class_3883<T, M> renderer) {
		super(renderer);
	}

	@Override
	public void render(class_4587 ms, class_4597 buffer, int light, class_1309 entity, float yaw, float pitch,
					   float pt, float p_225628_8_, float p_225628_9_, float p_225628_10_) {
		if (entity.method_18376() == class_4050.field_18078)
			return;

		BacktankItem item = BacktankItem.getWornBy(entity);
		if (item == null)
			return;

		M entityModel = method_17165();
		if (!(entityModel instanceof class_572<?> model))
			return;

		class_4588 vc = buffer.getBuffer(class_4722.method_24074());
		class_2680 renderedState = item.getBlock().method_9564()
			.method_11657(BacktankBlock.HORIZONTAL_FACING, class_2350.field_11035);
		SuperByteBuffer backtank = CachedBuffers.block(renderedState);
		SuperByteBuffer cogs = CachedBuffers.partial(BacktankRenderer.getCogsModel(renderedState), renderedState);
		SuperByteBuffer nob = CachedBuffers.partial(BacktankRenderer.getShaftModel(renderedState), renderedState);

		ms.method_22903();

		model.field_3391.method_22703(ms);
		ms.method_46416(-1 / 2f, 10 / 16f, 1f);
		ms.method_22905(1, -1, -1);

		backtank.disableDiffuse()
			.light(light)
			.renderInto(ms, vc);

		nob.disableDiffuse()
			.translate(0, -3f / 16, 0)
			.light(light)
			.renderInto(ms, vc);

		cogs.center()
			.rotateYDegrees(180)
			.uncenter()
			.translate(0, 6.5f / 16, 11f / 16)
			.rotate(AngleHelper.rad(2 * AnimationTickHolder.getRenderTime(entity.method_37908()) % 360), class_2350.field_11034)
			.translate(0, -6.5f / 16, -11f / 16);

		cogs.disableDiffuse()
			.light(light)
			.renderInto(ms, vc);

		ms.method_22909();
	}

//	public static void registerOnAll(EntityRenderDispatcher renderManager) {
//		for (EntityRenderer<? extends Player> renderer : renderManager.getSkinMap().values())
//			registerOn(renderer);
//		for (EntityRenderer<?> renderer : renderManager.renderers.values())
//			registerOn(renderer);
//	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	public static void registerOn(class_897<?> entityRenderer, RegistrationHelper helper) {
		if (!(entityRenderer instanceof class_922<?, ?> livingRenderer))
			return;
		if (!(livingRenderer.method_4038() instanceof class_572))
			return;
		BacktankArmorLayer<?, ?> layer = new BacktankArmorLayer<>(livingRenderer);
		helper.register(layer);
	}

}
