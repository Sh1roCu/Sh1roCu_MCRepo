package com.simibubi.create.content.contraptions.actors.plough;

import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.mojang.serialization.MapCodec;
import com.simibubi.create.content.contraptions.actors.AttachedActorBlock;
import org.jetbrains.annotations.NotNull;

import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.class_2383;
import net.minecraft.class_3218;

public class PloughBlock extends AttachedActorBlock {

	public static final MapCodec<PloughBlock> CODEC = method_54094(PloughBlock::new);

	public PloughBlock(class_2251 p_i48377_1_) {
		super(p_i48377_1_);
	}

	/**
	 * The OnHoeUse event takes a player, so we better not pass null
	 */
	static class PloughFakePlayer extends FakePlayer {

		public static final GameProfile PLOUGH_PROFILE =
				new GameProfile(UUID.fromString("9e2faded-eeee-4ec2-c314-dad129ae971d"), "Plough");

		public PloughFakePlayer(class_3218 world) {
			super(world, PLOUGH_PROFILE);
		}

	}

	@Override
	protected @NotNull MapCodec<? extends class_2383> method_53969() {
		return field_46280;
	}
}
