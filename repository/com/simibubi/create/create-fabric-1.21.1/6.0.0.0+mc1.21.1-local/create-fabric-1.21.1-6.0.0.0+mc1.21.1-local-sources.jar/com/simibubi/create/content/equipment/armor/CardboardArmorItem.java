package com.simibubi.create.content.equipment.armor;

import com.simibubi.create.Create;

public class CardboardArmorItem extends BaseArmorItem {

	public CardboardArmorItem(class_8051 type, class_1793 properties) {
		super(AllArmorMaterials.CARDBOARD, type, properties, Create.asResource("cardboard"));
	}

	// fabric: done in the .onRegister() callback in the
//	@Override
//	public int getBurnTime(ItemStack itemStack, @Nullable RecipeType<?> recipeType) {
//		return 1000;
//	}

}
