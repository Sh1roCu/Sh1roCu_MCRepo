package com.simibubi.create.content.equipment.symmetryWand.mirror;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.ImmutableList;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.foundation.utility.CreateLang;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import dev.engine_room.flywheel.lib.transform.TransformStack;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3542;
import net.minecraft.class_4587;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class PlaneMirror extends SymmetryMirror {

	public static enum Align implements class_3542 {
		XY("xy"), YZ("yz");

		private final String name;

		private Align(String name) {
			this.name = name;
		}

		@Override
		public String method_15434() {
			return name;
		}

		@Override
		public String toString() {
			return name;
		}
	}

	public PlaneMirror(class_243 pos) {
		super(pos);
		orientation = Align.XY;
	}

	@Override
	protected void setOrientation() {
		if (orientationIndex < 0)
			orientationIndex += Align.values().length;
		if (orientationIndex >= Align.values().length)
			orientationIndex -= Align.values().length;
		orientation = Align.values()[orientationIndex];
	}

	@Override
	public void setOrientation(int index) {
		this.orientation = Align.values()[index];
		orientationIndex = index;
	}

	@Override
	public Map<class_2338, class_2680> process(class_2338 position, class_2680 block) {
		Map<class_2338, class_2680> result = new HashMap<>();
		switch ((Align) orientation) {

		case XY:
			result.put(flipZ(position), flipZ(block));
			break;
		case YZ:
			result.put(flipX(position), flipX(block));
			break;
		default:
			break;

		}
		return result;
	}

	@Override
	public String typeName() {
		return PLANE;
	}

	@Override
	@Environment(EnvType.CLIENT)
	public PartialModel getModel() {
		return AllPartialModels.SYMMETRY_PLANE;
	}

	@Override
	public void applyModelTransform(class_4587 ms) {
		super.applyModelTransform(ms);
		TransformStack.of(ms)
			.center()
			.rotateYDegrees(((Align) orientation) == Align.XY ? 0 : 90)
			.uncenter();
	}

	@Override
	public List<class_2561> getAlignToolTips() {
		return ImmutableList.of(CreateLang.translateDirect("orientation.alongZ"), CreateLang.translateDirect("orientation.alongX"));
	}

}
