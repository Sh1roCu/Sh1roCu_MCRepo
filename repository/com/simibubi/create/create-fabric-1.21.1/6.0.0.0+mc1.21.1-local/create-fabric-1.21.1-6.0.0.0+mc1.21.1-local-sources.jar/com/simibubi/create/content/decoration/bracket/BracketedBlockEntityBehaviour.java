package com.simibubi.create.content.decoration.bracket;

import java.util.function.Predicate;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.content.contraptions.StructureTransform;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BehaviourType;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

import net.createmod.catnip.nbt.NBTHelper;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

public class BracketedBlockEntityBehaviour extends BlockEntityBehaviour {

	public static final BehaviourType<BracketedBlockEntityBehaviour> TYPE = new BehaviourType<>();

	private class_2680 bracket;
	private boolean reRender;

	private Predicate<class_2680> pred;

	public BracketedBlockEntityBehaviour(SmartBlockEntity be) {
		this(be, state -> true);
	}

	public BracketedBlockEntityBehaviour(SmartBlockEntity be, Predicate<class_2680> pred) {
		super(be);
		this.pred = pred;
	}

	@Override
	public BehaviourType<?> getType() {
		return TYPE;
	}

	public void applyBracket(class_2680 state) {
		this.bracket = state;
		reRender = true;
		blockEntity.notifyUpdate();
		class_1937 world = getWorld();
		if (world.field_9236)
			return;
		blockEntity.method_11010()
			.method_30101(world, getPos(), 3);
	}

	public void transformBracket(StructureTransform transform) {
		if (isBracketPresent()) {
			class_2680 transformedBracket = transform.apply(bracket);
			applyBracket(transformedBracket);
		}
	}

	@Nullable
	public class_2680 removeBracket(boolean inOnReplacedContext) {
		if (bracket == null) {
			return null;
		}

		class_2680 removed = this.bracket;
		class_1937 world = getWorld();
		if (!world.field_9236)
			world.method_20290(2001, getPos(), class_2248.method_9507(bracket));
		this.bracket = null;
		reRender = true;
		if (inOnReplacedContext) {
			blockEntity.sendData();
			return removed;
		}
		blockEntity.notifyUpdate();
		if (world.field_9236)
			return removed;
		blockEntity.method_11010()
			.method_30101(world, getPos(), 3);
		return removed;
	}

	public boolean isBracketPresent() {
		return bracket != null;
	}

	public boolean isBracketValid(class_2680 bracketState) {
		return bracketState.method_26204() instanceof BracketBlock;
	}

	@Nullable
	public class_2680 getBracket() {
		return bracket;
	}

	public boolean canHaveBracket() {
		return pred.test(blockEntity.method_11010());
	}

	@Override
	public ItemRequirement getRequiredItems() {
		if (!isBracketPresent()) {
			return ItemRequirement.NONE;
		}
		return ItemRequirement.of(bracket, null);
	}

	@Override
	public boolean isSafeNBT() {
		return true;
	}

	@Override
	public void write(class_2487 nbt, class_7225.class_7874 registries, boolean clientPacket) {
		if (isBracketPresent() && isBracketValid(bracket)) {
			nbt.method_10566("Bracket", class_2512.method_10686(bracket));
		}
		if (clientPacket && reRender) {
			NBTHelper.putMarker(nbt, "Redraw");
			reRender = false;
		}
		super.write(nbt, registries, clientPacket);
	}

	@Override
	public void read(class_2487 nbt, class_7225.class_7874 registries, boolean clientPacket) {
		if (nbt.method_10545("Bracket")) {
			bracket = null;
			class_2680 readBlockState = class_2512.method_10681(blockEntity.blockHolderGetter(), nbt.method_10562("Bracket"));
			if (isBracketValid(readBlockState))
				bracket = readBlockState;
		}
		if (clientPacket && nbt.method_10545("Redraw"))
			getWorld().method_8413(getPos(), blockEntity.method_11010(), blockEntity.method_11010(), 16);
		super.read(nbt, registries, clientPacket);
	}

}
