package com.simibubi.create.content.equipment.potatoCannon;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.simibubi.create.Create;
import com.simibubi.create.api.equipment.potatoCannon.PotatoProjectileRenderMode;
import com.simibubi.create.api.registry.CreateBuiltInRegistries;

import dev.engine_room.flywheel.lib.transform.TransformStack;
import net.createmod.catnip.math.AngleHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public class AllPotatoProjectileRenderModes {

	static {
		register("billboard", Billboard.CODEC);
		register("tumble", Tumble.CODEC);
		register("toward_motion", TowardMotion.CODEC);
		register("stuck_to_entity", StuckToEntity.CODEC);
	}

	public static void init() {
	}

	private static void register(String name, MapCodec<? extends PotatoProjectileRenderMode> codec) {
		class_2378.method_10230(CreateBuiltInRegistries.POTATO_PROJECTILE_RENDER_MODE, Create.asResource(name), codec);
	}

	public enum Billboard implements PotatoProjectileRenderMode {
		INSTANCE;

		public static final MapCodec<Billboard> CODEC = MapCodec.unit(INSTANCE);

		@Override
		@Environment(EnvType.CLIENT)
		public void transform(class_4587 ms, PotatoProjectileEntity entity, float pt) {
			class_310 mc = class_310.method_1551();
			class_243 p1 = mc.method_1560()
				.method_5836(pt);
			class_243 diff = entity.method_5829()
				.method_1005()
				.method_1020(p1);

			TransformStack.of(ms)
				.rotateYDegrees(AngleHelper.deg(class_3532.method_15349(diff.field_1352, diff.field_1350)) + 180)
				.rotateXDegrees(AngleHelper.deg(class_3532.method_15349(diff.field_1351, class_3532.method_15355((float) (diff.field_1352 * diff.field_1352 + diff.field_1350 * diff.field_1350)))));
		}

		@Override
		public MapCodec<? extends PotatoProjectileRenderMode> codec() {
			return CODEC;
		}
	}

	public enum Tumble implements PotatoProjectileRenderMode {
		INSTANCE;

		public static final MapCodec<Tumble> CODEC = MapCodec.unit(INSTANCE);

		@Override
		@Environment(EnvType.CLIENT)
		public void transform(class_4587 ms, PotatoProjectileEntity entity, float pt) {
			Billboard.INSTANCE.transform(ms, entity, pt);
			TransformStack.of(ms)
				.rotateZDegrees((entity.field_6012 + pt) * 2 * entityRandom(entity, 16))
				.rotateXDegrees((entity.field_6012 + pt) * entityRandom(entity, 32));
		}

		@Override
		public MapCodec<? extends PotatoProjectileRenderMode> codec() {
			return CODEC;
		}
	}

	public record TowardMotion(int spriteAngleOffset, float spin) implements PotatoProjectileRenderMode {
		public static final MapCodec<TowardMotion> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
			Codec.INT.fieldOf("sprite_angle_offset").forGetter(i -> i.spriteAngleOffset),
			Codec.FLOAT.fieldOf("spin").forGetter(i -> i.spin)
		).apply(instance, TowardMotion::new));

		@Override
		@Environment(EnvType.CLIENT)
		public void transform(class_4587 ms, PotatoProjectileEntity entity, float pt) {
			class_243 diff = entity.method_18798();
			TransformStack.of(ms)
				.rotateYDegrees(AngleHelper.deg(class_3532.method_15349(diff.field_1352, diff.field_1350)))
				.rotateXDegrees(270
					+ AngleHelper.deg(class_3532.method_15349(diff.field_1351, -class_3532.method_15355((float) (diff.field_1352 * diff.field_1352 + diff.field_1350 * diff.field_1350)))));
			TransformStack.of(ms)
				.rotateYDegrees((entity.field_6012 + pt) * 20 * spin + entityRandom(entity, 360))
				.rotateZDegrees(-spriteAngleOffset);
		}

		@Override
		public MapCodec<? extends PotatoProjectileRenderMode> codec() {
			return CODEC;
		}
	}

	public record StuckToEntity(class_243 offset) implements PotatoProjectileRenderMode {
		public static final MapCodec<StuckToEntity> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
			class_243.field_38277.fieldOf("offset").forGetter(i -> i.offset)
		).apply(instance, StuckToEntity::new));

		@Override
		@Environment(EnvType.CLIENT)
		public void transform(class_4587 ms, PotatoProjectileEntity entity, float pt) {
			TransformStack.of(ms).rotateYDegrees(AngleHelper.deg(class_3532.method_15349(offset.field_1352, offset.field_1350)));
		}

		@Override
		public MapCodec<? extends PotatoProjectileRenderMode> codec() {
			return CODEC;
		}
	}

	private static int entityRandom(class_1297 entity, int maxValue) {
		return (System.identityHashCode(entity) * 31) % maxValue;
	}
}
