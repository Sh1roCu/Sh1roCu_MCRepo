package com.simibubi.create.content.equipment.potatoCannon;

import com.simibubi.create.AllItems;
import com.simibubi.create.Create;
import com.simibubi.create.CreateClient;
import com.simibubi.create.content.equipment.potatoCannon.PotatoCannonItem.Ammo;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModel;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModelRenderer;
import com.simibubi.create.foundation.item.render.PartialItemModelRenderer;
import com.simibubi.create.infrastructure.fabric.RenderItemDecorationsCallback;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_746;
import net.minecraft.class_7833;
import net.minecraft.class_811;

public class PotatoCannonItemRenderer extends CustomRenderedItemModelRenderer {
	public static final RenderItemDecorationsCallback DECORATOR = (guiGraphics, font, stack, xOffset, yOffset) -> {
		class_746 player = class_310.method_1551().field_1724;
		if (player == null) {
			return;
		}

		Ammo ammo = PotatoCannonItem.getAmmo(player, stack);
		if (ammo == null || AllItems.POTATO_CANNON.is(ammo.stack())) {
			return;
		}

		class_4587 poseStack = guiGraphics.method_51448();
		poseStack.method_22903();
		poseStack.method_46416(xOffset, yOffset + 8, 100);
		poseStack.method_22905(.5f, .5f, .5f);
		guiGraphics.method_51427(ammo.stack(), 0, 0);
		poseStack.method_22909();
	};

	protected static final PartialModel COG = PartialModel.of(Create.asResource("item/potato_cannon/cog"));

	@Override
	protected void render(class_1799 stack, CustomRenderedItemModel model, PartialItemModelRenderer renderer,
						  class_811 transformType, class_4587 ms, class_4597 buffer, int light, int overlay) {
		renderer.render(model.getOriginalModel(), light);
		class_310 mc = class_310.method_1551();
		class_746 player = mc.field_1724;

		float angle = AnimationTickHolder.getRenderTime() * -2.5f;

		if (player != null) {
			boolean inMainHand = player.method_6047() == stack;
			boolean inOffHand = player.method_6079() == stack;

			if (inMainHand || inOffHand) {
				boolean leftHanded = player.method_6068() == class_1306.field_6182;
				float speed = CreateClient.POTATO_CANNON_RENDER_HANDLER.getAnimation(inMainHand ^ leftHanded,
					AnimationTickHolder.getPartialTicks());
				angle += 360 * class_3532.method_15363(speed * 5, 0, 1);
			}
		}

		angle %= 360;
		float offset = .5f / 16;

		ms.method_22903();
		ms.method_46416(0, offset, 0);
		ms.method_22907(class_7833.field_40718.rotationDegrees(angle));
		ms.method_46416(0, -offset, 0);
		renderer.render(COG.get(), light);
		ms.method_22909();
	}
}
