package com.simibubi.create;

import static com.simibubi.create.AllTags.NameSpace.COMMON;
import static com.simibubi.create.AllTags.NameSpace.MOD;
import static com.simibubi.create.AllTags.NameSpace.QUARK;
import static com.simibubi.create.AllTags.NameSpace.TIC;
import static com.simibubi.create.AllTags.NameSpace.TRINKETS;

import com.simibubi.create.api.contraption.ContraptionType;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorage;
import com.simibubi.create.api.contraption.storage.item.MountedItemStorageType;
import com.simibubi.create.api.registry.CreateRegistries;

import net.createmod.catnip.lang.Lang;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1865;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class AllTags {
	public static <T> class_6862<T> optionalTag(class_2378<T> registry, class_2960 id) {
		return class_6862.method_40092(registry.method_30517(), id);
	}

	public static <T> class_6862<T> commonTag(class_2378<T> registry, String path) {
		return optionalTag(registry, class_2960.method_60655("c", path));
	}

	public static class_6862<class_2248> commonBlockTag(String path) {
		return commonTag(class_7923.field_41175, path);
	}

	public static class_6862<class_1792> commonItemTag(String path) {
		return commonTag(class_7923.field_41178, path);
	}

	public static class_6862<class_3611> commonFluidTag(String path) {
		return commonTag(class_7923.field_41173, path);
	}

	public enum NameSpace {

		MOD(Create.ID, false, true),
		COMMON("c"),
		TIC("tconstruct"),
		QUARK("quark"),
		GS("galosphere"),
		// fabric: Trinkets compat is used instead
		CURIOS("curios"),
		TRINKETS("trinkets");

		public final String id;
		public final boolean optionalDefault;
		public final boolean alwaysDatagenDefault;

		NameSpace(String id) {
			this(id, true, false);
		}

		NameSpace(String id, boolean optionalDefault, boolean alwaysDatagenDefault) {
			this.id = id;
			this.optionalDefault = optionalDefault;
			this.alwaysDatagenDefault = alwaysDatagenDefault;
		}
	}

	public enum AllBlockTags {

		BRITTLE,
		CASING,
		COPYCAT_ALLOW,
		COPYCAT_DENY,
		FAN_PROCESSING_CATALYSTS_BLASTING(MOD, "fan_processing_catalysts/blasting"),
		FAN_PROCESSING_CATALYSTS_HAUNTING(MOD, "fan_processing_catalysts/haunting"),
		FAN_PROCESSING_CATALYSTS_SMOKING(MOD, "fan_processing_catalysts/smoking"),
		FAN_PROCESSING_CATALYSTS_SPLASHING(MOD, "fan_processing_catalysts/splashing"),
		FAN_TRANSPARENT,
		GIRDABLE_TRACKS,
		MOVABLE_EMPTY_COLLIDER,
		NON_MOVABLE,
		NON_BREAKABLE,
		ORE_OVERRIDE_STONE,
		PASSIVE_BOILER_HEATERS,
		SAFE_NBT,
		SEATS,
		POSTBOXES,
		TABLE_CLOTHS,
		TOOLBOXES,
		TRACKS,
		TREE_ATTACHMENTS,
		VALVE_HANDLES,
		WINDMILL_SAILS,
		WRENCH_PICKUP,
		CHEST_MOUNTED_STORAGE,
		SIMPLE_MOUNTED_STORAGE,
		ROOTS,
		SUGAR_CANE_VARIANTS,
		NON_HARVESTABLE,

		HAS_REDUCED_DESTROY_EFFECTS,

		CORALS,

		RELOCATION_NOT_SUPPORTED(COMMON),

		SLIMY_LOGS(TIC),
		NON_DOUBLE_DOOR(QUARK),

		;

		public final class_6862<class_2248> tag;
		public final boolean alwaysDatagen;

		AllBlockTags() {
			this(MOD);
		}

		AllBlockTags(NameSpace namespace) {
			this(namespace, namespace.optionalDefault, namespace.alwaysDatagenDefault);
		}

		AllBlockTags(NameSpace namespace, String path) {
			this(namespace, path, namespace.optionalDefault, namespace.alwaysDatagenDefault);
		}

		AllBlockTags(NameSpace namespace, boolean optional, boolean alwaysDatagen) {
			this(namespace, null, optional, alwaysDatagen);
		}

		AllBlockTags(NameSpace namespace, String path, boolean optional, boolean alwaysDatagen) {
			class_2960 id = class_2960.method_60655(namespace.id, path == null ? Lang.asId(name()) : path);
			tag = optionalTag(class_7923.field_41175, id);
			this.alwaysDatagen = alwaysDatagen;
		}

		@SuppressWarnings("deprecation")
		public boolean matches(class_2248 block) {
			return block.method_40142()
				.method_40220(tag);
		}

		public boolean matches(class_1799 stack) {
			return stack != null && stack.method_7909() instanceof class_1747 blockItem && matches(blockItem.method_7711());
		}

		public boolean matches(class_2680 state) {
			return state.method_26164(tag);
		}

		private static void init() {
		}

	}

	public enum AllItemTags {

		BLAZE_BURNER_FUEL_REGULAR(MOD, "blaze_burner_fuel/regular"),
		BLAZE_BURNER_FUEL_SPECIAL(MOD, "blaze_burner_fuel/special"),
		CASING,
		CONTRAPTION_CONTROLLED,
		CREATE_INGOTS,
		CRUSHED_RAW_MATERIALS,
		DIVING_ARMOR,
		INVALID_FOR_TRACK_PAVING,
		DEPLOYABLE_DRINK,
		PRESSURIZED_AIR_SOURCES,
		SANDPAPER,
		SEATS,
		POSTBOXES,
		TABLE_CLOTHS,
		DYED_TABLE_CLOTHS,
		PULPIFIABLE,
		SLEEPERS,
		TOOLBOXES,
		PACKAGES,
		CHAIN_RIDEABLE,
		TRACKS,
		UPRIGHT_ON_BELT,
		VALVE_HANDLES,
		DISPENSE_BEHAVIOR_WRAP_BLACKLIST,

		PLATES(COMMON),
		OBSIDIAN_DUST(COMMON, "dusts/obsidian"),
		WRENCH(COMMON, "tools/wrench"),

		ALLURITE(MOD, "stone_types/galosphere/allurite"),
		AMETHYST(MOD, "stone_types/galosphere/amethyst"),
		LUMIERE(MOD, "stone_types/galosphere/lumiere"),

		UA_CORAL(MOD, "upgrade_aquatic/coral"),
		// fabric: Trinkets compat is used instead
		//CURIOS_HEAD(CURIOS, "head"),
		TRINKETS_FACE(TRINKETS, "head/face");

		public final class_6862<class_1792> tag;
		public final boolean alwaysDatagen;

		AllItemTags() {
			this(MOD);
		}

		AllItemTags(NameSpace namespace) {
			this(namespace, namespace.optionalDefault, namespace.alwaysDatagenDefault);
		}

		AllItemTags(NameSpace namespace, String path) {
			this(namespace, path, namespace.optionalDefault, namespace.alwaysDatagenDefault);
		}

		AllItemTags(NameSpace namespace, boolean optional, boolean alwaysDatagen) {
			this(namespace, null, optional, alwaysDatagen);
		}

		AllItemTags(NameSpace namespace, String path, boolean optional, boolean alwaysDatagen) {
			class_2960 id = class_2960.method_60655(namespace.id, path == null ? Lang.asId(name()) : path);
			tag = optionalTag(class_7923.field_41178, id);

			this.alwaysDatagen = alwaysDatagen;
		}

		@SuppressWarnings("deprecation")
		public boolean matches(class_1792 item) {
			return item.method_40131()
				.method_40220(tag);
		}

		public boolean matches(class_1799 stack) {
			return stack.method_31573(tag);
		}

		private static void init() {
		}

	}

	public enum AllFluidTags {
		// fabric: extra tag for diving helmet behavior
		DIVING_FLUIDS,

		BOTTOMLESS_ALLOW(MOD, "bottomless/allow"),
		BOTTOMLESS_DENY(MOD, "bottomless/deny"),
		FAN_PROCESSING_CATALYSTS_BLASTING(MOD, "fan_processing_catalysts/blasting"),
		FAN_PROCESSING_CATALYSTS_HAUNTING(MOD, "fan_processing_catalysts/haunting"),
		FAN_PROCESSING_CATALYSTS_SMOKING(MOD, "fan_processing_catalysts/smoking"),
		FAN_PROCESSING_CATALYSTS_SPLASHING(MOD, "fan_processing_catalysts/splashing"),

		;

		public final class_6862<class_3611> tag;
		public final boolean alwaysDatagen;

		AllFluidTags() {
			this(MOD);
		}

		AllFluidTags(NameSpace namespace) {
			this(namespace, namespace.optionalDefault, namespace.alwaysDatagenDefault);
		}

		AllFluidTags(NameSpace namespace, String path) {
			this(namespace, path, namespace.optionalDefault, namespace.alwaysDatagenDefault);
		}

		AllFluidTags(NameSpace namespace, boolean optional, boolean alwaysDatagen) {
			this(namespace, null, optional, alwaysDatagen);
		}

		AllFluidTags(NameSpace namespace, String path, boolean optional, boolean alwaysDatagen) {
			class_2960 id = class_2960.method_60655(namespace.id, path == null ? Lang.asId(name()) : path);
			tag = optionalTag(class_7923.field_41173, id);
			this.alwaysDatagen = alwaysDatagen;
		}

		@SuppressWarnings("deprecation")
		public boolean matches(class_3611 fluid) {
			return fluid.method_15791(tag);
		}

		public boolean matches(class_3610 state) {
			return state.method_15767(tag);
		}

		private static void init() {
		}

	}

	public enum AllEntityTags {
		BLAZE_BURNER_CAPTURABLE,
		IGNORE_SEAT,

		;

		public final class_6862<class_1299<?>> tag;
		public final boolean alwaysDatagen;

		AllEntityTags() {
			this(MOD);
		}

		AllEntityTags(NameSpace namespace) {
			this(namespace, namespace.optionalDefault, namespace.alwaysDatagenDefault);
		}

		AllEntityTags(NameSpace namespace, String path) {
			this(namespace, path, namespace.optionalDefault, namespace.alwaysDatagenDefault);
		}

		AllEntityTags(NameSpace namespace, boolean optional, boolean alwaysDatagen) {
			this(namespace, null, optional, alwaysDatagen);
		}

		AllEntityTags(NameSpace namespace, String path, boolean optional, boolean alwaysDatagen) {
			class_2960 id = class_2960.method_60655(namespace.id, path == null ? Lang.asId(name()) : path);
			if (optional) {
				tag = optionalTag(class_7923.field_41177, id);
			} else {
				tag = class_6862.method_40092(class_7924.field_41266, id);
			}
			this.alwaysDatagen = alwaysDatagen;
		}

		public boolean matches(class_1299<?> type) {
			return type.method_20210(tag);
		}

		public boolean matches(class_1297 entity) {
			return matches(entity.method_5864());
		}

		private static void init() {
		}

	}

	public enum AllRecipeSerializerTags {

		AUTOMATION_IGNORE,

		;

		public final class_6862<class_1865<?>> tag;
		public final boolean alwaysDatagen;

		AllRecipeSerializerTags() {
			this(MOD);
		}

		AllRecipeSerializerTags(NameSpace namespace) {
			this(namespace, namespace.optionalDefault, namespace.alwaysDatagenDefault);
		}

		AllRecipeSerializerTags(NameSpace namespace, String path) {
			this(namespace, path, namespace.optionalDefault, namespace.alwaysDatagenDefault);
		}

		AllRecipeSerializerTags(NameSpace namespace, boolean optional, boolean alwaysDatagen) {
			this(namespace, null, optional, alwaysDatagen);
		}

		AllRecipeSerializerTags(NameSpace namespace, String path, boolean optional, boolean alwaysDatagen) {
			class_2960 id = class_2960.method_60655(namespace.id, path == null ? Lang.asId(name()) : path);
			if (optional) {
				tag = optionalTag(class_7923.field_41189, id);
			} else {
				tag = class_6862.method_40092(class_7924.field_41216, id);
			}
			this.alwaysDatagen = alwaysDatagen;
		}

		public boolean matches(class_1865<?> recipeSerializer) {
			class_5321<class_1865<?>> key = class_7923.field_41189.method_29113(recipeSerializer).orElseThrow();
			return class_7923.field_41189.method_40264(key).orElseThrow().method_40220(tag);
		}

		private static void init() {
		}
	}

	public enum AllContraptionTypeTags {
		OPENS_CONTROLS,
		REQUIRES_VEHICLE_FOR_RENDER;

		public final class_6862<ContraptionType> tag;
		public final boolean alwaysDatagen;

		AllContraptionTypeTags() {
			class_2960 tagId = Create.asResource(Lang.asId(this.name()));
			this.tag = class_6862.method_40092(CreateRegistries.CONTRAPTION_TYPE, tagId);
			this.alwaysDatagen = true;
		}

		public boolean matches(ContraptionType type) {
			return type.is(this.tag);
		}

		private static void init() {
		}
	}

	public enum AllMountedItemStorageTypeTags {
		INTERNAL,
		FUEL_BLACKLIST;

		public final class_6862<MountedItemStorageType<?>> tag;
		public final boolean alwaysDatagen;

		AllMountedItemStorageTypeTags() {
			class_2960 tagId = Create.asResource(Lang.asId(this.name()));
			this.tag = class_6862.method_40092(CreateRegistries.MOUNTED_ITEM_STORAGE_TYPE, tagId);
			this.alwaysDatagen = true;
		}

		public boolean matches(MountedItemStorage storage) {
			return this.matches(storage.type);
		}

		public boolean matches(MountedItemStorageType<?> type) {
			return type.is(this.tag);
		}

		private static void init() {
		}
	}

	public static void init() {
		AllBlockTags.init();
		AllItemTags.init();
		AllFluidTags.init();
		AllEntityTags.init();
		AllRecipeSerializerTags.init();
		AllContraptionTypeTags.init();
		AllMountedItemStorageTypeTags.init();
	}
}
