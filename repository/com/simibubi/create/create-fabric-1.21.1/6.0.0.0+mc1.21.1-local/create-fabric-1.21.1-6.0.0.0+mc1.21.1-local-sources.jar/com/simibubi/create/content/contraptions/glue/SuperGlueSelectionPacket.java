package com.simibubi.create.content.contraptions.glue;

import com.simibubi.create.AllPackets;
import com.simibubi.create.foundation.advancement.AllAdvancements;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.class_9139;
import io.netty.buffer.ByteBuf;
import com.simibubi.create.foundation.utility.AdventureUtil;
import com.simibubi.create.foundation.utility.fabric.ReachUtil;

import io.netty.buffer.ByteBuf;
import java.util.Set;

public record SuperGlueSelectionPacket(class_2338 from, class_2338 to) implements ServerboundPacketPayload {
	public static final class_9139<ByteBuf, SuperGlueSelectionPacket> STREAM_CODEC = class_9139.method_56435(
			class_2338.field_48404, SuperGlueSelectionPacket::from,
			class_2338.field_48404, SuperGlueSelectionPacket::to,
			SuperGlueSelectionPacket::new
	);

	@Override
	public void handle(class_3222 player) {
		double range = player.method_45325(class_5134.field_47758) + 2;
		if (player.method_5707(class_243.method_24953(to)) > range * range)
			return;
		if (!to.method_19771(from, 25))
			return;

		Set<class_2338> group = SuperGlueSelectionHelper.searchGlueGroup(player.method_37908(), from, to, false);
		if (group == null)
			return;
		if (!group.contains(to))
			return;
		if (!SuperGlueSelectionHelper.collectGlueFromInventory(player, 1, true))
			return;

		class_238 bb = SuperGlueEntity.span(from, to);
		SuperGlueSelectionHelper.collectGlueFromInventory(player, 1, false);
		SuperGlueEntity entity = new SuperGlueEntity(player.method_37908(), bb);
		player.method_37908().method_8649(entity);
		entity.spawnParticles();

		AllAdvancements.SUPER_GLUE.awardTo(player);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.GLUE_IN_AREA;
	}
}
