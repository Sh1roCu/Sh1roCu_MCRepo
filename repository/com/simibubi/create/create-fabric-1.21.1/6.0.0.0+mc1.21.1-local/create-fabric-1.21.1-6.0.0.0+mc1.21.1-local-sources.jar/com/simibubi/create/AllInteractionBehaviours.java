package com.simibubi.create;

import com.simibubi.create.api.behaviour.interaction.MovingInteractionBehaviour;
import com.simibubi.create.api.registry.SimpleRegistry;
import com.simibubi.create.content.contraptions.behaviour.DoorMovingInteraction;
import com.simibubi.create.content.contraptions.behaviour.LeverMovingInteraction;
import com.simibubi.create.content.contraptions.behaviour.TrapdoorMovingInteraction;
import net.minecraft.class_2246;
import net.minecraft.class_3481;

public class AllInteractionBehaviours {
	static void registerDefaults() {
		MovingInteractionBehaviour.REGISTRY.register(class_2246.field_10363, new LeverMovingInteraction());

		MovingInteractionBehaviour.REGISTRY.registerProvider(SimpleRegistry.Provider.forBlockTag(class_3481.field_15494, new DoorMovingInteraction()));
		MovingInteractionBehaviour.REGISTRY.registerProvider(SimpleRegistry.Provider.forBlockTag(class_3481.field_15491, new TrapdoorMovingInteraction()));
		MovingInteractionBehaviour.REGISTRY.registerProvider(SimpleRegistry.Provider.forBlockTag(class_3481.field_25147, new TrapdoorMovingInteraction()));
	}
}
