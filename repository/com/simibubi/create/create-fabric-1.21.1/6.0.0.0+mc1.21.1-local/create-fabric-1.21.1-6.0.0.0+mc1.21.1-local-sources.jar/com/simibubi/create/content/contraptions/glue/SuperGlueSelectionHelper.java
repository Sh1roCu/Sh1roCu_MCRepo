package com.simibubi.create.content.contraptions.glue;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.simibubi.create.api.contraption.BlockMovementChecks;

import net.createmod.catnip.data.Iterate;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_9334;

public class SuperGlueSelectionHelper {

	public static Set<class_2338> searchGlueGroup(class_1937 level, class_2338 startPos, class_2338 endPos, boolean includeOther) {
		if (endPos == null || startPos == null)
			return null;

		class_238 bb = SuperGlueEntity.span(startPos, endPos);

		List<class_2338> frontier = new ArrayList<>();
		Set<class_2338> visited = new HashSet<>();
		Set<class_2338> attached = new HashSet<>();
		Set<SuperGlueEntity> cachedOther = new HashSet<>();

		visited.add(startPos);
		frontier.add(startPos);

		while (!frontier.isEmpty()) {
			class_2338 currentPos = frontier.remove(0);
			attached.add(currentPos);

			for (class_2350 d : Iterate.directions) {
				class_2338 offset = currentPos.method_10093(d);
				boolean gluePresent = includeOther && SuperGlueEntity.isGlued(level, currentPos, d, cachedOther);
				boolean alreadySticky = includeOther && SuperGlueEntity.isSideSticky(level, currentPos, d)
					|| SuperGlueEntity.isSideSticky(level, offset, d.method_10153());

				if (!alreadySticky && !gluePresent && !bb.method_1006(class_243.method_24953(offset)))
					continue;
				if (!BlockMovementChecks.isMovementNecessary(level.method_8320(offset), level, offset))
					continue;
				if (!SuperGlueEntity.isValidFace(level, currentPos, d)
					|| !SuperGlueEntity.isValidFace(level, offset, d.method_10153()))
					continue;

				if (visited.add(offset))
					frontier.add(offset);
			}
		}

		if (attached.size() < 2 && attached.contains(endPos))
			return null;

		return attached;
	}

	public static boolean collectGlueFromInventory(class_1657 player, int requiredAmount, boolean simulate) {
		if (player.method_31549().field_7477)
			return true;
		if (requiredAmount == 0)
			return true;

		class_2371<class_1799> items = player.method_31548().field_7547;
		for (int i = -1; i < items.size(); i++) {
			int slot = i == -1 ? player.method_31548().field_7545 : i;
			class_1799 stack = items.get(slot);
			if (stack.method_7960())
				continue;
			if (stack.method_57826(class_9334.field_49630))
				return true;
			if (!stack.method_7963())
				continue;
			if (!(stack.method_7909() instanceof SuperGlueItem))
				continue;

			int charges = Math.min(requiredAmount, stack.method_7936() - stack.method_7919());

				if (!simulate && player.method_37908() instanceof class_3218 serverLevel && player instanceof class_3222 serverPlayer)
					stack.method_7956(charges, serverLevel, serverPlayer, i == -1 ? $ -> SuperGlueItem.onBroken(serverPlayer) : $ -> {});

			requiredAmount -= charges;
			if (requiredAmount <= 0)
				return true;
		}

		return false;
	}

}
