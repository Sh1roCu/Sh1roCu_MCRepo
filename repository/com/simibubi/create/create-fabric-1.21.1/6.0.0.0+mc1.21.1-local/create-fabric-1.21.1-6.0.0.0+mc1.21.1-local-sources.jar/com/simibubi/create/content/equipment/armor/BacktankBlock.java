package com.simibubi.create.content.equipment.armor;

import java.util.Optional;

import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllDataComponents;
import com.simibubi.create.AllEnchantments;
import com.simibubi.create.AllShapes;
import com.simibubi.create.api.schematic.requirement.SpecialBlockItemRequirement;
import com.simibubi.create.content.kinetics.base.HorizontalKineticBlock;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.content.schematics.requirement.ItemRequirement.ItemUseType;
import com.simibubi.create.foundation.block.IBE;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2741;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9062;
import net.minecraft.class_9326;
import net.minecraft.class_9334;

public class BacktankBlock extends HorizontalKineticBlock implements IBE<BacktankBlockEntity>, class_3737, SpecialBlockItemRequirement {

	public BacktankBlock(class_2251 properties) {
		super(properties);
		method_9590(method_9564().method_11657(class_2741.field_12508, false));
	}

	@Override
	public class_3610 method_9545(class_2680 state) {
		return state.method_11654(class_2741.field_12508) ? class_3612.field_15910.method_15729(false)
			: class_3612.field_15906.method_15785();
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> builder) {
		builder.method_11667(class_2741.field_12508);
		super.method_9515(builder);
	}
	@Override
	public boolean method_9498(class_2680 p_149740_1_) {
		return true;
	}

	@Override
	public int method_9572(class_2680 state, class_1937 world, class_2338 pos) {
		return getBlockEntityOptional(world, pos).map(BacktankBlockEntity::getComparatorOutput)
			.orElse(0);
	}

	@Override
	public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighbourState, class_1936 world,
		class_2338 pos, class_2338 neighbourPos) {
		if (state.method_11654(class_2741.field_12508))
			world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
		return state;
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		class_3610 fluidState = context.method_8045()
			.method_8316(context.method_8037());
		return super.method_9605(context).method_11657(class_2741.field_12508,
			fluidState.method_15772() == class_3612.field_15910);
	}

	@Override
	public boolean hasShaftTowards(class_4538 world, class_2338 pos, class_2680 state, class_2350 face) {
		return face == class_2350.field_11036;
	}

	@Override
	public class_2351 getRotationAxis(class_2680 state) {
		return class_2351.field_11052;
	}

	@Override
	public void method_9567(class_1937 worldIn, class_2338 pos, class_2680 state, class_1309 placer, class_1799 stack) {
		super.method_9567(worldIn, pos, state, placer, stack);
		if (worldIn.field_9236)
			return;
			if (stack == null)
				return;
			withBlockEntityDo(worldIn, pos, be -> {
				class_6880<class_1887> capacity = worldIn.method_30349()
					.method_46762(class_7924.field_41265)
					.method_46747(AllEnchantments.CAPACITY);
				be.setCapacityEnchantLevel(class_1890.method_8225(capacity, stack));
				be.setAirLevel(stack.method_57825(AllDataComponents.BACKTANK_AIR, 0));
				if (stack.method_57826(class_9334.field_49631))
					be.setCustomName(stack.method_7964());

			be.setComponentPatch(stack.method_57380());

			// fabric: forge mangles item placement logic, so this isn't needed there.
			// here, we need to do this manually so neighboring blocks are updated (comparators, #1396)
			// this isn't needed for other items with block entity data (ex. chests) since they use the BlockEntityTag
			// nbt, and that system calls this after updating it.
			be.method_5431();
		});
	}

	// fabric: unused
//	@Override
//	public List<ItemStack> getDrops(BlockState pState, LootParams.Builder pBuilder) {
//		List<ItemStack> lootDrops = super.getDrops(pState, pBuilder);
//
//		BlockEntity blockEntity = pBuilder.getOptionalParameter(LootContextParams.BLOCK_ENTITY);
//		if (!(blockEntity instanceof BacktankBlockEntity bbe))
//			return lootDrops;
//
//		DataComponentPatch components = bbe.getComponentPatch()
//			.forget(c -> c.equals(AllDataComponents.BACKTANK_AIR));
//		if (components.isEmpty())
//			return lootDrops;
//
//		return lootDrops.stream()
//			.peek(stack -> {
//				if (stack.getItem() instanceof BacktankItem)
//					stack.applyComponents(components);
//			})
//			.toList();
//	}

	@Override
	protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
		if (player == null)
			return class_9062.field_47731;
		if (player instanceof FakePlayer)
			return class_9062.field_47731;
		if (player.method_5715())
			return class_9062.field_47731;
		if (player.method_6047()
				.method_7909() instanceof class_1747)
			return class_9062.field_47731;
		if (!player.method_6118(class_1304.field_6174)
				.method_7960())
			return class_9062.field_47731;
		if (!level.field_9236) {
			level.method_8396(null, pos, class_3417.field_15197, class_3419.field_15248, .75f, 1);
			player.method_5673(class_1304.field_6174, method_9574(level, pos, state));
			level.method_22352(pos, false);
		}
		return class_9062.field_47728;
	}

	@Override
	public class_1799 method_9574(class_4538 pLevel, class_2338 pos, class_2680 state) {
		class_1792 item = method_8389();
		if (item instanceof BacktankItem.BacktankBlockItem placeable)
			item = placeable.getActualItem();

		Optional<BacktankBlockEntity> blockEntityOptional = getBlockEntityOptional(pLevel, pos);

		class_9326 components = blockEntityOptional.map(BacktankBlockEntity::getComponentPatch)
			.orElse(class_9326.field_49588);
		int air = blockEntityOptional.map(BacktankBlockEntity::getAirLevel)
			.orElse(0);

		class_1799 stack = new class_1799(item.method_40131(), 1, components);
		stack.method_57379(AllDataComponents.BACKTANK_AIR, air);
		return stack;
	}

	@Override
	public class_265 method_9530(class_2680 p_220053_1_, class_1922 p_220053_2_, class_2338 p_220053_3_,
		class_3726 p_220053_4_) {
		return AllShapes.BACKTANK;
	}

	@Override
	public Class<BacktankBlockEntity> getBlockEntityClass() {
		return BacktankBlockEntity.class;
	}

	@Override
	public class_2591<? extends BacktankBlockEntity> getBlockEntityType() {
		return AllBlockEntityTypes.BACKTANK.get();
	}

	@Override
	protected boolean method_9516(class_2680 state, class_10 pathComputationType) {
		return false;
	}

	@Override
	public ItemRequirement getRequiredItems(class_2680 state, class_2586 blockEntity) {
		class_1792 item = method_8389();
		if (item instanceof BacktankItem.BacktankBlockItem placeable)
			item = placeable.getActualItem();
		return new ItemRequirement(ItemUseType.CONSUME, item);
	}

}
