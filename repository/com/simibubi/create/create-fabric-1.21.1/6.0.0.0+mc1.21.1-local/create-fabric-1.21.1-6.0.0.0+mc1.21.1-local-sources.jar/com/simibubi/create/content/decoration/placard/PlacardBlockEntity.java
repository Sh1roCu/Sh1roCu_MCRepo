package com.simibubi.create.content.decoration.placard;

import java.util.List;



import org.joml.Vector3f;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2390;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7225;



public class PlacardBlockEntity extends SmartBlockEntity {

	class_1799 heldItem;
	int poweredTicks;

	public PlacardBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		heldItem = class_1799.field_8037;
		poweredTicks = 0;
	}

	@Override
	public void tick() {
		super.tick();
		if (field_11863.field_9236)
			return;
		if (poweredTicks == 0)
			return;

		poweredTicks--;
		if (poweredTicks > 0)
			return;

		class_2680 blockState = method_11010();
		field_11863.method_8652(field_11867, blockState.method_11657(PlacardBlock.POWERED, false), 3);
		PlacardBlock.updateNeighbours(blockState, field_11863, field_11867);
	}

	public class_1799 getHeldItem() {
		return heldItem;
	}

	public void setHeldItem(class_1799 heldItem) {
		this.heldItem = heldItem;
		notifyUpdate();
	}

	@Override
	protected void write(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		tag.method_10569("PoweredTicks", poweredTicks);
		tag.method_10566("Item", heldItem.method_57375(registries));
		super.write(tag, registries, clientPacket);
	}

	@Override
	protected void read(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		int prevTicks = poweredTicks;
		poweredTicks = tag.method_10550("PoweredTicks");
		heldItem = class_1799.method_57359(registries, tag.method_10562("Item"));
		super.read(tag, registries, clientPacket);

		if (clientPacket && prevTicks < poweredTicks)
			spawnParticles();
	}

	private void spawnParticles() {
		class_2680 blockState = method_11010();
		if (!AllBlocks.PLACARD.has(blockState))
			return;

		class_2390 pParticleData = new class_2390(new Vector3f(1, .2f, 0), 1);
		class_243 centerOf = VecHelper.getCenterOf(field_11867);
		class_243 normal = class_243.method_24954(PlacardBlock.connectedDirection(blockState)
			.method_10163());
		class_243 offset = VecHelper.axisAlingedPlaneOf(normal);

		for (int i = 0; i < 10; i++) {
			class_243 v = VecHelper.offsetRandomly(class_243.field_1353, field_11863.field_9229, .5f)
				.method_18806(offset)
				.method_1029()
				.method_1021(.45f)
				.method_1019(normal.method_1021(-.45f))
				.method_1019(centerOf);
			field_11863.method_8406(pParticleData, v.field_1352, v.field_1351, v.field_1350, 0, 0, 0);
		}
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {}

}
