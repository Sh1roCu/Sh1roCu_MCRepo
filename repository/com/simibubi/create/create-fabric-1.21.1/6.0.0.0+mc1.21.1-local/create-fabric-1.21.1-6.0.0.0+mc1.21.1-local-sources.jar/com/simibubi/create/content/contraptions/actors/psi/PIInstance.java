package com.simibubi.create.content.contraptions.actors.psi;

import java.util.function.Consumer;

import dev.engine_room.flywheel.api.instance.Instance;
import dev.engine_room.flywheel.api.instance.InstancerProvider;
import dev.engine_room.flywheel.lib.instance.InstanceTypes;
import dev.engine_room.flywheel.lib.instance.TransformedInstance;
import dev.engine_room.flywheel.lib.model.Models;
import net.createmod.catnip.math.AngleHelper;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

public class PIInstance {
	private final InstancerProvider instancerProvider;
	private final class_2680 blockState;
	private final class_2338 instancePos;
	private final float angleX;
	private final float angleY;

	private boolean lit;
	TransformedInstance middle;
	TransformedInstance top;

	public PIInstance(InstancerProvider instancerProvider, class_2680 blockState, class_2338 instancePos, boolean lit) {
		this.instancerProvider = instancerProvider;
		this.blockState = blockState;
		this.instancePos = instancePos;
		class_2350 facing = blockState.method_11654(PortableStorageInterfaceBlock.field_10927);
		angleX = facing == class_2350.field_11036 ? 0 : facing == class_2350.field_11033 ? 180 : 90;
		angleY = AngleHelper.horizontalAngle(facing);
		this.lit = lit;

		middle = instancerProvider.instancer(InstanceTypes.TRANSFORMED, Models.partial(PortableStorageInterfaceRenderer.getMiddleForState(blockState, lit)))
				.createInstance();
		top = instancerProvider.instancer(InstanceTypes.TRANSFORMED, Models.partial(PortableStorageInterfaceRenderer.getTopForState(blockState)))
				.createInstance();
	}

	public void beginFrame(float progress) {
		middle.setIdentityTransform()
				.translate(instancePos)
				.center()
				.rotateYDegrees(angleY)
				.rotateXDegrees(angleX)
				.uncenter();

		top.setIdentityTransform()
				.translate(instancePos)
				.center()
				.rotateYDegrees(angleY)
				.rotateXDegrees(angleX)
				.uncenter();

		middle.translate(0, progress * 0.5f + 0.375f, 0);
		top.translate(0, progress, 0);

		middle.setChanged();
		top.setChanged();
	}

	public void tick(boolean lit) {
		if (this.lit != lit) {
			this.lit = lit;
			instancerProvider.instancer(InstanceTypes.TRANSFORMED, Models.partial(PortableStorageInterfaceRenderer.getMiddleForState(blockState, lit)))
					.stealInstance(middle);
		}
	}

	public void remove() {
		middle.delete();
		top.delete();
	}

	public void collectCrumblingInstances(Consumer<Instance> consumer) {
		consumer.accept(middle);
		consumer.accept(top);
	}
}
