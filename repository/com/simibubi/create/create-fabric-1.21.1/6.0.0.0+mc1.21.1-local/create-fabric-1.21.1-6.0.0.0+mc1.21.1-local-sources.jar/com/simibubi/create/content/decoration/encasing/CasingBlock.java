package com.simibubi.create.content.decoration.encasing;

import com.simibubi.create.content.equipment.wrench.IWrenchable;
import net.minecraft.class_1269;
import net.minecraft.class_1838;
import net.minecraft.class_2248;
import net.minecraft.class_2680;

public class CasingBlock extends class_2248 implements IWrenchable {

	public CasingBlock(class_2251 p_i48440_1_) {
		super(p_i48440_1_);
	}

	@Override
	public class_1269 onWrenched(class_2680 state, class_1838 context) {
		return class_1269.field_5814;
	}

}
