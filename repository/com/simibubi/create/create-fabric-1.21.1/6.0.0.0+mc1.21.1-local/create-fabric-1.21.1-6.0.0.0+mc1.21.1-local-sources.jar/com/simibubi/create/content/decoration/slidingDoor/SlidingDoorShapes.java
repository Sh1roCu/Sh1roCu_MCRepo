package com.simibubi.create.content.decoration.slidingDoor;

import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_265;

public class SlidingDoorShapes {

	protected static final class_265 SE_AABB = class_2248.method_9541(0.0D, 0.0D, -13.0D, 3.0D, 16.0D, 3.0D);
	protected static final class_265 ES_AABB = class_2248.method_9541(-13.0D, 0.0D, 0.0D, 3.0D, 16.0D, 3.0D);
	protected static final class_265 NW_AABB = class_2248.method_9541(13.0D, 0.0D, 13.0D, 16.0D, 16.0D, 29.0D);
	protected static final class_265 WN_AABB = class_2248.method_9541(13.0D, 0.0D, 13.0D, 29.0D, 16.0D, 16.0D);
	protected static final class_265 SW_AABB = class_2248.method_9541(13.0D, 0.0D, -13.0D, 16.0D, 16.0D, 3.0D);
	protected static final class_265 WS_AABB = class_2248.method_9541(13.0D, 0.0D, 0.0D, 29.0D, 16.0D, 3.0D);
	protected static final class_265 NE_AABB = class_2248.method_9541(0.0D, 0.0D, 13.0D, 3.0D, 16.0D, 29.0D);
	protected static final class_265 EN_AABB = class_2248.method_9541(-13.0D, 0.0D, 13.0D, 3.0D, 16.0D, 16.0D);

	protected static final class_265 SE_AABB_FOLD = class_2248.method_9541(0.0D, 0.0D, -3.0D, 9.0D, 16.0D, 3.0D);
	protected static final class_265 ES_AABB_FOLD = class_2248.method_9541(-3.0D, 0.0D, 0.0D, 3.0D, 16.0D, 9.0D);
	protected static final class_265 NW_AABB_FOLD = class_2248.method_9541(7.0D, 0.0D, 13.0D, 16.0D, 16.0D, 19.0D);
	protected static final class_265 WN_AABB_FOLD = class_2248.method_9541(13.0D, 0.0D, 7.0D, 19.0D, 16.0D, 16.0D);
	protected static final class_265 SW_AABB_FOLD = class_2248.method_9541(7.0D, 0.0D, -3.0D, 16.0D, 16.0D, 3.0D);
	protected static final class_265 WS_AABB_FOLD = class_2248.method_9541(13.0D, 0.0D, 0.0D, 19.0D, 16.0D, 9.0D);
	protected static final class_265 NE_AABB_FOLD = class_2248.method_9541(0.0D, 0.0D, 13.0D, 9.0D, 16.0D, 19.0D);
	protected static final class_265 EN_AABB_FOLD = class_2248.method_9541(-3.0D, 0.0D, 7.0D, 3.0D, 16.0D, 16.0D);

	public static class_265 get(class_2350 facing, boolean hinge, boolean fold) {
		if (fold)
			return switch (facing) {
			case field_11035 -> (hinge ? ES_AABB_FOLD : WS_AABB_FOLD);
			case field_11039 -> (hinge ? SW_AABB_FOLD : NW_AABB_FOLD);
			case field_11043 -> (hinge ? WN_AABB_FOLD : EN_AABB_FOLD);
			default -> (hinge ? NE_AABB_FOLD : SE_AABB_FOLD);
			};

		return switch (facing) {
		case field_11035 -> (hinge ? ES_AABB : WS_AABB);
		case field_11039 -> (hinge ? SW_AABB : NW_AABB);
		case field_11043 -> (hinge ? WN_AABB : EN_AABB);
		default -> (hinge ? NE_AABB : SE_AABB);
		};
	}

}
