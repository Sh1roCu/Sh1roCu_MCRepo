package com.simibubi.create.content.decoration.encasing;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

/**
 * Implement this interface to indicate that this block is encased.
 */
public interface EncasedBlock {
	class_2248 getCasing();

	/**
	 * Handles how encasing should be done if {@link EncasableBlock#tryEncase(class_2680, class_1937, class_2338, class_1799, class_1657, class_1268, class_3965)} is successful.
	 */
	default void handleEncasing(class_2680 state, class_1937 level, class_2338 pos, class_1799 heldItem, class_1657 player, class_1268 hand, class_3965 ray) {
	}
}
