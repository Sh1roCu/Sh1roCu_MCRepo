package com.simibubi.create.content.equipment.wrench;

import javax.annotation.Nonnull;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1688;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3966;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllItems;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.AllTags;
import com.simibubi.create.Create;

public class WrenchItem extends class_1792 {

	public WrenchItem(class_1793 properties) {
		super(properties);
	}

	@Nonnull
	@Override
	public class_1269 method_7884(class_1838 context) {
		class_1657 player = context.method_8036();
		if (player == null || !player.method_7294())
			return super.method_7884(context);

		class_2680 state = context.method_8045()
				.method_8320(context.method_8037());
		class_2248 block = state.method_26204();

		if (!(block instanceof IWrenchable actor)) {
			if (player.method_5715() && canWrenchPickup(state))
				return onItemUseOnOther(context);
			return super.method_7884(context);
		}

		if (player.method_5715())
			return actor.onSneakWrenched(state, context);
		return actor.onWrenched(state, context);
	}

	private static boolean canWrenchPickup(class_2680 state) {
		return AllTags.AllBlockTags.WRENCH_PICKUP.matches(state);
	}

	private static class_1269 onItemUseOnOther(class_1838 context) {
		class_1657 player = context.method_8036();
		class_1937 world = context.method_8045();
		class_2338 pos = context.method_8037();
		class_2680 state = world.method_8320(pos);
		if (!(world instanceof class_3218))
			return class_1269.field_5812;
		if (player != null && !player.method_7337())
			class_2248.method_9609(state, (class_3218) world, pos, world.method_8321(pos), player, context.method_8041())
				.forEach(itemStack -> player.method_31548().method_7398(itemStack));
		state.method_26180((class_3218) world, pos, class_1799.field_8037, true);
		world.method_22352(pos, false);
		AllSoundEvents.WRENCH_REMOVE.playOnServer(world, pos, 1, Create.RANDOM.nextFloat() * .5f + .5f);
		return class_1269.field_5812;
	}

	public static class_1269 wrenchInstaKillsMinecarts(class_1657 player, class_1937 world, class_1268 hand, class_1297 target, @Nullable class_3966 entityRayTraceResult) {
		if (!(target instanceof class_1688 minecart))
			return class_1269.field_5811;
		class_1799 heldItem = player.method_6047();
		if (!AllItems.WRENCH.isIn(heldItem))
			return class_1269.field_5811;
		if (player.method_7337())
			return class_1269.field_5811;
		minecart.method_5643(minecart.method_48923().method_48802(player), 100);
		return class_1269.field_5812;
	}

//	@Override
//	@Environment(EnvType.CLIENT)
//	public void initializeClient(Consumer<IClientItemExtensions> consumer) {
//		consumer.accept(SimpleCustomRenderer.create(this, new WrenchItemRenderer()));
//	}

}
