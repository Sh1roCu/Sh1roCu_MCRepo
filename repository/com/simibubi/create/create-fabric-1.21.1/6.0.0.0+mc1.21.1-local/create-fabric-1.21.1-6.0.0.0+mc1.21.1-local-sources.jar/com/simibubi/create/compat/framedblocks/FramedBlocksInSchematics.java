package com.simibubi.create.compat.framedblocks;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2248;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_7871;
import net.minecraft.class_7924;
import com.simibubi.create.compat.Mods;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.content.schematics.requirement.ItemRequirement.ItemUseType;
import com.simibubi.create.content.schematics.requirement.ItemRequirement.StackRequirement;

public class FramedBlocksInSchematics {

	static final List<String> KEYS_TO_RETAIN =
		List.of("intangible", "glowing", "reinforced", "camo", "camo_two");

	public static class_2487 prepareBlockEntityData(class_2680 blockState, class_2586 blockEntity) {
		class_2487 data = null;
		if (blockEntity == null)
			return data;

		data = blockEntity.method_38242(blockEntity.method_10997().method_30349());

		List<String> keysToRemove = new ArrayList<>();
		for (String key : data.method_10541())
			if (!KEYS_TO_RETAIN.contains(key))
				keysToRemove.add(key);
		for (String key : keysToRemove)
			data.method_10551(key);

		if (data.method_10562("camo")
			.method_10545("fluid"))
			data.method_10551("camo");

		if (data.method_10562("camo_two")
			.method_10545("fluid"))
			data.method_10551("camo_two");

		return data;
	}

	public static ItemRequirement getRequiredItems(class_2680 blockState, class_2586 blockEntity) {
		if (blockEntity == null)
			return ItemRequirement.NONE;

		class_2487 data = blockEntity.method_38242(blockEntity.method_10997().method_30349());
		List<StackRequirement> list = new ArrayList<>();

		if (data.method_10577("intangible"))
			list.add(new StackRequirement(new class_1799(class_1802.field_8614), ItemUseType.CONSUME));

		if (data.method_10577("glowing"))
			list.add(new StackRequirement(new class_1799(class_1802.field_8601), ItemUseType.CONSUME));

		if (data.method_10577("reinforced"))
			list.add(new StackRequirement(new class_1799(Mods.FRAMEDBLOCKS.getItem("framed_reinforcement")),
				ItemUseType.CONSUME));

		if (data.method_10545("camo"))
			addCamoStack(blockEntity.method_10997().method_45448(class_7924.field_41254), data.method_10562("camo"), list);

		if (data.method_10545("camo_two"))
			addCamoStack(blockEntity.method_10997().method_45448(class_7924.field_41254), data.method_10562("camo_two"), list);

		return new ItemRequirement(list);
	}

	private static void addCamoStack(class_7871<class_2248> level, class_2487 tag, List<StackRequirement> list) {
		if (!tag.method_10545("state"))
			return;
		class_2680 blockState = class_2512.method_10681(level, tag.method_10562("state"));
		class_1799 itemStack = new class_1799(blockState.method_26204());
		if (!itemStack.method_7960())
			list.add(new StackRequirement(itemStack, ItemUseType.CONSUME));
	}

}
