package com.simibubi.create;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_6880.class_6883;
import com.simibubi.create.api.contraption.ContraptionType;
import com.simibubi.create.api.registry.CreateBuiltInRegistries;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.bearing.BearingContraption;
import com.simibubi.create.content.contraptions.bearing.ClockworkContraption;
import com.simibubi.create.content.contraptions.bearing.StabilizedContraption;
import com.simibubi.create.content.contraptions.elevator.ElevatorContraption;
import com.simibubi.create.content.contraptions.gantry.GantryContraption;
import com.simibubi.create.content.contraptions.mounted.MountedContraption;
import com.simibubi.create.content.contraptions.piston.PistonContraption;
import com.simibubi.create.content.contraptions.pulley.PulleyContraption;
import com.simibubi.create.content.trains.entity.CarriageContraption;

public class AllContraptionTypes {
	public static final Map<String, ContraptionType> BY_LEGACY_NAME = new HashMap<>();

	public static final class_6883<ContraptionType> PISTON = register("piston", PistonContraption::new);
	public static final class_6883<ContraptionType> BEARING = register("bearing", BearingContraption::new);
	public static final class_6883<ContraptionType> PULLEY = register("pulley", PulleyContraption::new);
	public static final class_6883<ContraptionType> CLOCKWORK = register("clockwork", ClockworkContraption::new);
	public static final class_6883<ContraptionType> MOUNTED = register("mounted", MountedContraption::new);
	public static final class_6883<ContraptionType> STABILIZED = register("stabilized", StabilizedContraption::new);
	public static final class_6883<ContraptionType> GANTRY = register("gantry", GantryContraption::new);
	public static final class_6883<ContraptionType> CARRIAGE = register("carriage", CarriageContraption::new);
	public static final class_6883<ContraptionType> ELEVATOR = register("elevator", ElevatorContraption::new);

	private static class_6883<ContraptionType> register(String name, Supplier<? extends Contraption> factory) {
		ContraptionType type = new ContraptionType(factory);
		BY_LEGACY_NAME.put(name, type);

		return class_2378.method_47985(CreateBuiltInRegistries.CONTRAPTION_TYPE, Create.asResource(name), type);
	}

	public static void init() {
	}
}
