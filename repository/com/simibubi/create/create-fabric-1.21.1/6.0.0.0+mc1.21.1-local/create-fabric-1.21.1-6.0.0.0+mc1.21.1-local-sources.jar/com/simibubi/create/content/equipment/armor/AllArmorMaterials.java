package com.simibubi.create.content.equipment.armor;

import java.util.EnumMap;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2378;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.Create;

public class AllArmorMaterials {
	public static final class_6880<class_1741> COPPER = register(
				"copper",
				new int[] { 2, 4, 3, 1, 4 },
				7,
				AllSoundEvents.COPPER_ARMOR_EQUIP.getMainEventHolder(),
				0.0F,
				0.0F,
				() -> class_1856.method_8091(class_1802.field_27022)
			);

	public static final class_6880<class_1741> CARDBOARD = register(
				"cardboard",
				new int[] { 1, 1, 1, 1, 2 },
				4,
				class_3417.field_14581,
				0.0F,
				0.0F,
				() -> class_1856.method_8091(AllItems.CARDBOARD)
	);

	private static class_6880<class_1741> register(
			String name,
			int[] defense,
			int enchantmentValue,
			class_6880<class_3414> equipSound,
			float toughness,
			float knockbackResistance,
			Supplier<class_1856> repairIngredient
	) {
		List<class_1741.class_9196> list = List.of(new class_1741.class_9196(Create.asResource(name)));
		return register(name, defense, enchantmentValue, equipSound, toughness, knockbackResistance, repairIngredient, list);
	}

	private static class_6880<class_1741> register(
			String name,
			int[] defense,
			int enchantmentValue,
			class_6880<class_3414> equipSound,
			float toughness,
			float knockbackResistance,
			Supplier<class_1856> repairIngridient,
			List<class_1741.class_9196> layers
	) {
		EnumMap<class_1738.class_8051, Integer> enummap = new EnumMap<>(class_1738.class_8051.class);

		for (class_1738.class_8051 armoritem$type : class_1738.class_8051.values()) {
			enummap.put(armoritem$type, defense[armoritem$type.ordinal()]);
		}

		return class_2378.method_47985(class_7923.field_48976, Create.asResource(name),
			new class_1741(enummap, enchantmentValue, equipSound, repairIngridient, layers, toughness, knockbackResistance)
		);
	}

	public static void register() {
	}
}
