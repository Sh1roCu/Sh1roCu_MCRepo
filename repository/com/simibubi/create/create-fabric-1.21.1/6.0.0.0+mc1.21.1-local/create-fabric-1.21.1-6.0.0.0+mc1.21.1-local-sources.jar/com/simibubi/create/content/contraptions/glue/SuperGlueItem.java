package com.simibubi.create.content.contraptions.glue;

import com.simibubi.create.content.contraptions.chassis.AbstractChassisBlock;

import net.createmod.catnip.math.VecHelper;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class SuperGlueItem extends class_1792 {

	public static class_1269 glueItemAlwaysPlacesWhenUsed(class_1657 player, class_1937 world, class_1268 hand, class_3965 hitResult) {
		if (hitResult != null) {
			class_2680 blockState = world
				.method_8320(hitResult
					.method_17777());
			if (blockState.method_26204()instanceof AbstractChassisBlock cb)
				if (cb.getGlueableSide(blockState, hitResult.method_17780()) != null)
					return class_1269.field_5811;
		}

		if (player.method_5998(hand).method_7909() instanceof SuperGlueItem)
			return class_1269.field_5814;
		return class_1269.field_5811;
	}

	public SuperGlueItem(class_1793 properties) {
		super(properties.method_7895(99));
	}

	@Override
	public boolean method_7885(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_1657 pPlayer) {
		return false;
	}

	public static void onBroken(class_1657 player) {}

	@Environment(EnvType.CLIENT)
	public static void spawnParticles(class_1937 world, class_2338 pos, class_2350 direction, boolean fullBlock) {
		class_243 vec = class_243.method_24954(direction.method_10163());
		class_243 plane = VecHelper.axisAlingedPlaneOf(vec);
		class_243 facePos = VecHelper.getCenterOf(pos)
			.method_1019(vec.method_1021(.5f));

		float distance = fullBlock ? 1f : .25f + .25f * (world.field_9229.method_43057() - .5f);
		plane = plane.method_1021(distance);
		class_1799 stack = new class_1799(class_1802.field_8777);

		for (int i = fullBlock ? 40 : 15; i > 0; i--) {
			class_243 offset = VecHelper.rotate(plane, 360 * world.field_9229.method_43057(), direction.method_10166());
			class_243 motion = offset.method_1029()
				.method_1021(1 / 16f);
			if (fullBlock)
				offset =
					new class_243(class_3532.method_15350(offset.field_1352, -.5, .5), class_3532.method_15350(offset.field_1351, -.5, .5), class_3532.method_15350(offset.field_1350, -.5, .5));
			class_243 particlePos = facePos.method_1019(offset);
			world.method_8406(new class_2392(class_2398.field_11218, stack), particlePos.field_1352, particlePos.field_1351,
				particlePos.field_1350, motion.field_1352, motion.field_1351, motion.field_1350);
		}

	}

}
