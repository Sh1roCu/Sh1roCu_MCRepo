package com.simibubi.create.compat.dynamictrees;

import java.util.function.BiConsumer;

import javax.annotation.Nullable;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import com.simibubi.create.foundation.utility.AbstractBlockBreakQueue;

public class DynamicTree extends AbstractBlockBreakQueue {

	private class_2338 startCutPos;

	public DynamicTree(class_2338 startCutPos) {
		this.startCutPos = startCutPos;
	}

	public static boolean isDynamicBranch(class_2248 block) {
		//return TreeHelper.isBranch(block) || block instanceof TrunkShellBlock;
		return false;
	}


	@Override
	public void destroyBlocks(class_1937 world, class_1799 toDamage, @Nullable class_1657 playerEntity, BiConsumer<class_2338, class_1799> drop) {

//		BranchBlock start = TreeHelper.getBranch(world.getBlockState(startCutPos));
//		if (start == null) //if start is null, it was not a branch
//			start = setBranchToShellMuse(world, world.getBlockState(startCutPos)); //we check for a trunk shell instead
//
//		if (start == null) //if it is null again, it was neither a branch nor a trunk shell and thus we return
//			return;
//
//		// Play and render block break sound and particles
//		world.levelEvent(null, 2001, startCutPos, Block.getId(world.getBlockState(startCutPos)));
//
//		// Actually breaks the tree
//		BranchDestructionData data = start.destroyBranchFromNode(world, startCutPos, Direction.DOWN, false, playerEntity);
//
//		// Feed all the tree drops to drop bi-consumer
//		data.leavesDrops.forEach(stackPos -> drop.accept(stackPos.pos.offset(startCutPos), stackPos.stack));
//		start.getFamily().getCommonSpecies().getBranchesDrops(world, data.woodVolume).forEach(stack -> drop.accept(startCutPos, stack));

	}


//	private BranchBlock setBranchToShellMuse(Level world, BlockState state) {
//
//		Block block = state.getBlock();
//		if (block instanceof TrunkShellBlock){
//			TrunkShellBlock.ShellMuse muse = ((TrunkShellBlock)block).getMuse(world, startCutPos);
//			if (muse != null){
//				startCutPos = muse.pos; //the cut pos is moved to the center of the trunk
//				return TreeHelper.getBranch(muse.state);
//			}
//		}
//
//		return null;
//	}


}
