package com.simibubi.create.content.equipment.symmetryWand;

import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_5244;
import net.minecraft.class_7833;
import org.joml.Vector3f;
import com.simibubi.create.content.equipment.symmetryWand.mirror.CrossPlaneMirror;
import com.simibubi.create.content.equipment.symmetryWand.mirror.EmptyMirror;
import com.simibubi.create.content.equipment.symmetryWand.mirror.PlaneMirror;
import com.simibubi.create.content.equipment.symmetryWand.mirror.SymmetryMirror;
import com.simibubi.create.content.equipment.symmetryWand.mirror.TriplePlaneMirror;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import com.simibubi.create.foundation.gui.AllIcons;
import com.simibubi.create.foundation.gui.widget.IconButton;
import com.simibubi.create.foundation.gui.widget.Label;
import com.simibubi.create.foundation.gui.widget.ScrollInput;
import com.simibubi.create.foundation.gui.widget.SelectionScrollInput;
import com.simibubi.create.foundation.utility.CreateLang;

import net.createmod.catnip.gui.AbstractSimiScreen;
import net.createmod.catnip.gui.element.GuiGameElement;

public class SymmetryWandScreen extends AbstractSimiScreen {

	private AllGuiTextures background;

	private ScrollInput areaType;
	private Label labelType;
	private ScrollInput areaAlign;
	private Label labelAlign;
	private IconButton confirmButton;

	private final class_2561 mirrorType = CreateLang.translateDirect("gui.symmetryWand.mirrorType");
	private final class_2561 orientation = CreateLang.translateDirect("gui.symmetryWand.orientation");

	private SymmetryMirror currentElement;
	private class_1799 wand;
	private class_1268 hand;

	public SymmetryWandScreen(class_1799 wand, class_1268 hand) {
		background = AllGuiTextures.WAND_OF_SYMMETRY;

		currentElement = SymmetryWandItem.getMirror(wand);
		if (currentElement instanceof EmptyMirror) {
			currentElement = new PlaneMirror(class_243.field_1353);
		}
		this.hand = hand;
		this.wand = wand;
	}

	@Override
	public void method_25426() {
		setWindowSize(background.getWidth(), background.getHeight());
		setWindowOffset(-20, 0);
		super.method_25426();

		int x = guiLeft;
		int y = guiTop;

		labelType = new Label(x + 51, y + 28, class_5244.field_39003).colored(0xFFFFFFFF)
			.withShadow();
		labelAlign = new Label(x + 51, y + 50, class_5244.field_39003).colored(0xFFFFFFFF)
			.withShadow();

		int state =
			currentElement instanceof TriplePlaneMirror ? 2 : currentElement instanceof CrossPlaneMirror ? 1 : 0;
		areaType = new SelectionScrollInput(x + 45, y + 21, 109, 18).forOptions(SymmetryMirror.getMirrors())
			.titled(mirrorType.method_27662())
			.writingTo(labelType)
			.setState(state);

		areaType.calling(position -> {
			switch (position) {
				case 0:
					currentElement = new PlaneMirror(currentElement.getPosition());
					break;
				case 1:
					currentElement = new CrossPlaneMirror(currentElement.getPosition());
					break;
				case 2:
					currentElement = new TriplePlaneMirror(currentElement.getPosition());
					break;
				default:
					break;
			}
			initAlign(currentElement, x, y);
		});

		initAlign(currentElement, x, y);

		method_37063(labelAlign);
		method_37063(areaType);
		method_37063(labelType);

		confirmButton = new IconButton(x + background.getWidth() - 33, y + background.getHeight() - 24, AllIcons.I_CONFIRM);
		confirmButton.withCallback(() -> {
			method_25419();
		});
		method_37063(confirmButton);
	}

	private void initAlign(SymmetryMirror element, int x, int y) {
		if (areaAlign != null)
			method_37066(areaAlign);

		areaAlign = new SelectionScrollInput(x + 45, y + 43, 109, 18).forOptions(element.getAlignToolTips())
			.titled(orientation.method_27662())
			.writingTo(labelAlign)
			.setState(element.getOrientationIndex())
			.calling(element::setOrientation);

		method_37063(areaAlign);
	}

	@Override
	protected void renderWindow(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		int x = guiLeft;
		int y = guiTop;

		background.render(graphics, x, y);
		graphics.method_51439(field_22793, wand.method_7964(),
			x + (background.getWidth() - field_22793.method_27525(wand.method_7964())) / 2, y + 4, 0x592424, false);

		renderBlock(graphics, x, y);
		GuiGameElement.of(wand)
			.scale(4)
			.rotate(-70, 20, 20)
			.at(x + 178, y + 448, -150)
			.render(graphics);
	}

	protected void renderBlock(class_332 graphics, int x, int y) {
		class_4587 ms = graphics.method_51448();

		ms.method_22903();
		ms.method_46416(x + 26, y + 39, 20);
		ms.method_22905(16, 16, 16);
		ms.method_22907(class_7833.method_46356(new Vector3f(.3f, 1f, 0f)).rotationDegrees(-22.5f));
		currentElement.applyModelTransform(ms);
		// RenderSystem.multMatrix(ms.peek().getModel());
		GuiGameElement.of(currentElement.getModel())
			.render(graphics);

		ms.method_22909();
	}

	@Override
	public void method_25432() {
		SymmetryWandItem.configureSettings(wand, currentElement);
		CatnipServices.NETWORK.sendToServer(new ConfigureSymmetryWandPacket(hand, currentElement));
	}

}
