package com.simibubi.create.content.contraptions.chassis;

import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2746;

public class RadialChassisBlock extends AbstractChassisBlock {

	public static final class_2746 STICKY_NORTH = class_2746.method_11825("sticky_north");
	public static final class_2746 STICKY_SOUTH = class_2746.method_11825("sticky_south");
	public static final class_2746 STICKY_EAST = class_2746.method_11825("sticky_east");
	public static final class_2746 STICKY_WEST = class_2746.method_11825("sticky_west");

	public RadialChassisBlock(class_2251 properties) {
		super(properties);
		method_9590(method_9564().method_11657(STICKY_EAST, false).method_11657(STICKY_SOUTH, false).method_11657(STICKY_NORTH, false)
				.method_11657(STICKY_WEST, false));
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> builder) {
		builder.method_11667(STICKY_NORTH, STICKY_EAST, STICKY_SOUTH, STICKY_WEST);
		super.method_9515(builder);
	}

	@Override
	public class_2746 getGlueableSide(class_2680 state, class_2350 face) {
		class_2351 axis = state.method_11654(field_11459);

		if (axis == class_2351.field_11048) {
			if (face == class_2350.field_11043)
				return STICKY_WEST;
			if (face == class_2350.field_11035)
				return STICKY_EAST;
			if (face == class_2350.field_11036)
				return STICKY_NORTH;
			if (face == class_2350.field_11033)
				return STICKY_SOUTH;
		}

		if (axis == class_2351.field_11052) {
			if (face == class_2350.field_11043)
				return STICKY_NORTH;
			if (face == class_2350.field_11035)
				return STICKY_SOUTH;
			if (face == class_2350.field_11034)
				return STICKY_EAST;
			if (face == class_2350.field_11039)
				return STICKY_WEST;
		}

		if (axis == class_2351.field_11051) {
			if (face == class_2350.field_11036)
				return STICKY_NORTH;
			if (face == class_2350.field_11033)
				return STICKY_SOUTH;
			if (face == class_2350.field_11034)
				return STICKY_EAST;
			if (face == class_2350.field_11039)
				return STICKY_WEST;
		}

		return null;
	}

}
