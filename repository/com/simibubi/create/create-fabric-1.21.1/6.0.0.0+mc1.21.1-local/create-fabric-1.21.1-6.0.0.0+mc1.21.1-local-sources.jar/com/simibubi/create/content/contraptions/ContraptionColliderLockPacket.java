package com.simibubi.create.content.contraptions;

import com.simibubi.create.AllPackets;
import net.createmod.catnip.net.base.ClientboundPacketPayload;
import net.createmod.catnip.platform.CatnipServices;
import net.createmod.catnip.net.base.ServerboundPacketPayload;

import io.netty.buffer.ByteBuf;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3222;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ContraptionColliderLockPacket(int contraption, double offset, int sender) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, ContraptionColliderLockPacket> STREAM_CODEC = class_9139.method_56436(
			class_9135.field_48550, ContraptionColliderLockPacket::contraption,
			class_9135.field_48553, ContraptionColliderLockPacket::offset,
			class_9135.field_48550, ContraptionColliderLockPacket::sender,
	        ContraptionColliderLockPacket::new
	);

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		ContraptionCollider.lockPacketReceived(contraption, sender, offset);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CONTRAPTION_COLLIDER_LOCK;
	}

	public record ContraptionColliderLockPacketRequest(int contraption, double offset) implements ServerboundPacketPayload {
		public static final class_9139<ByteBuf, ContraptionColliderLockPacketRequest> STREAM_CODEC = class_9139.method_56435(
		        class_9135.field_48550, ContraptionColliderLockPacketRequest::contraption,
				class_9135.field_48553, ContraptionColliderLockPacketRequest::offset,
		        ContraptionColliderLockPacketRequest::new
		);

		@Override
		public void handle(class_3222 player) {
			CatnipServices.NETWORK.sendToClientsTrackingEntity(player, new ContraptionColliderLockPacket(contraption, offset, player.method_5628()));
		}

		@Override
		public PacketTypeProvider getTypeProvider() {
			return AllPackets.CONTRAPTION_COLLIDER_LOCK_REQUEST;
		}
	}

}
