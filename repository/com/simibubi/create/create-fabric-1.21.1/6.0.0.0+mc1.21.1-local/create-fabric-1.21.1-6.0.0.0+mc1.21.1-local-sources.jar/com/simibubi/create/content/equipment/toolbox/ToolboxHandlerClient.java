package com.simibubi.create.content.equipment.toolbox;

import static com.simibubi.create.foundation.gui.AllGuiTextures.TOOLBELT_HOTBAR_OFF;
import static com.simibubi.create.foundation.gui.AllGuiTextures.TOOLBELT_HOTBAR_ON;
import static com.simibubi.create.foundation.gui.AllGuiTextures.TOOLBELT_SELECTED_OFF;
import static com.simibubi.create.foundation.gui.AllGuiTextures.TOOLBELT_SELECTED_ON;

import java.util.Comparator;
import java.util.List;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.systems.RenderSystem;
import com.simibubi.create.AllKeys;
import com.simibubi.create.foundation.gui.AllGuiTextures;

import net.createmod.catnip.gui.ScreenOpener;
import net.createmod.catnip.nbt.NBTHelper;
import net.createmod.catnip.platform.CatnipServices;

import net.fabricmc.fabric.api.block.BlockPickInteractionAware;
import net.fabricmc.fabric.api.entity.EntityPickInteractionAware;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.class_9080;
import net.minecraft.class_9779;

public class ToolboxHandlerClient {

	public static final class_9080.class_9081 OVERLAY = ToolboxHandlerClient::renderOverlay;

	static int COOLDOWN = 0;

	public static void clientTick() {
		if (COOLDOWN > 0 && !AllKeys.TOOLBELT.isPressed())
			COOLDOWN--;
	}

	public static boolean onPickItem() {
		class_310 mc = class_310.method_1551();
		class_746 player = mc.field_1724;
		if (player == null)
			return false;
		class_1937 level = player.method_37908();
		class_239 hitResult = mc.field_1765;

		if (hitResult == null || hitResult.method_17783() == class_239.class_240.field_1333)
			return false;
		if (player.method_7337())
			return false;

		class_1799 result = class_1799.field_8037;
		List<ToolboxBlockEntity> toolboxes = ToolboxHandler.getNearest(player.method_37908(), player, 8);

		if (toolboxes.isEmpty())
			return false;

		if (hitResult.method_17783() == class_239.class_240.field_1332) {
			class_2338 pos = ((class_3965) hitResult).method_17777();
			class_2680 state = level.method_8320(pos);
			if (state.method_26215())
				return false;
			class_2248 block = state.method_26204();
			result = block instanceof BlockPickInteractionAware aware
					? aware.getPickedStack(state, level, pos, player, hitResult)
					: block.method_9574(level, pos, state);
		} else if (hitResult.method_17783() == class_239.class_240.field_1331) {
			class_1297 entity = ((class_3966) hitResult).method_17782();
			result = entity instanceof EntityPickInteractionAware aware
					? aware.getPickedStack(player, hitResult)
					: entity.method_31480();
		}

		if (result == null || result.method_7960())
			return false;

		for (ToolboxBlockEntity toolboxBlockEntity : toolboxes) {
			ToolboxInventory inventory = toolboxBlockEntity.inventory;
			try (Transaction t = Transaction.openOuter()) {
				for (int comp = 0; comp < 8; comp++) {
					class_1799 inSlot = inventory.takeFromCompartment(1, comp, t);
					if (inSlot.method_7960())
						continue;
					if (inSlot.method_7909() != result.method_7909())
						continue;
					if (!class_1799.method_7973(inSlot, result))
						continue;

					CatnipServices.NETWORK.sendToServer(
						new ToolboxEquipPacket(toolboxBlockEntity.method_11016(), comp, player.method_31548().field_7545));
					return true;
				}
			}
		}

		return false;
	}

	public static void onKeyInput(int key, boolean pressed) {
		class_310 mc = class_310.method_1551();
		if (mc.field_1761 == null || mc.field_1761.method_2920() == class_1934.field_9219)
			return;

		if (key != AllKeys.TOOLBELT.getBoundCode() || !pressed)
			return;
		if (COOLDOWN > 0)
			return;
		class_746 player = mc.field_1724;
		if (player == null)
			return;
		class_1937 level = player.method_37908();

		List<ToolboxBlockEntity> toolboxes = ToolboxHandler.getNearest(player.method_37908(), player, 8);
		toolboxes.sort(Comparator.comparing(ToolboxBlockEntity::getUniqueId));

		class_2487 compound = player.getCustomData()
			.method_10562("CreateToolboxData");

		String slotKey = String.valueOf(player.method_31548().field_7545);
		boolean equipped = compound.method_10545(slotKey);

		if (equipped) {
			class_2338 pos = NBTHelper.readBlockPos(compound.method_10562(slotKey), "Pos");
			double max = ToolboxHandler.getMaxRange(player);
			boolean canReachToolbox = ToolboxHandler.distance(player.method_19538(), pos) < max * max;

			if (canReachToolbox) {
				class_2586 blockEntity = level.method_8321(pos);
				if (blockEntity instanceof ToolboxBlockEntity) {
					RadialToolboxMenu screen = new RadialToolboxMenu(toolboxes,
						RadialToolboxMenu.State.SELECT_ITEM_UNEQUIP, (ToolboxBlockEntity) blockEntity);
					screen.prevSlot(compound.method_10562(slotKey)
						.method_10550("Slot"));
					ScreenOpener.open(screen);
					return;
				}
			}

			ScreenOpener.open(new RadialToolboxMenu(ImmutableList.of(), RadialToolboxMenu.State.DETACH, null));
			return;
		}

		if (toolboxes.isEmpty())
			return;

		if (toolboxes.size() == 1)
			ScreenOpener.open(new RadialToolboxMenu(toolboxes, RadialToolboxMenu.State.SELECT_ITEM, toolboxes.get(0)));
		else
			ScreenOpener.open(new RadialToolboxMenu(toolboxes, RadialToolboxMenu.State.SELECT_BOX, null));
	}

	public static void renderOverlay(class_332 guiGraphics, class_9779 deltaTracker) {
		int width = guiGraphics.method_51421();
		int height = guiGraphics.method_51443();
		class_310 mc = class_310.method_1551();
		if (mc.field_1690.field_1842 || mc.field_1761.method_2920() == class_1934.field_9219)
			return;

		int x = width / 2 - 90;
		int y = height - 23;
		RenderSystem.enableDepthTest();

		class_1657 player = mc.field_1724;
		if (player == null)
			return;
		class_2487 persistentData = player.getCustomData();
		if (!persistentData.method_10545("CreateToolboxData"))
			return;

		class_2487 compound = player.getCustomData()
			.method_10562("CreateToolboxData");

		if (compound.method_33133())
			return;

		class_4587 poseStack = guiGraphics.method_51448();
		poseStack.method_22903();
		for (int slot = 0; slot < 9; slot++) {
			String key = String.valueOf(slot);
			if (!compound.method_10545(key))
				continue;
			class_2338 pos = NBTHelper.readBlockPos(compound.method_10562(key), "Pos");
			double max = ToolboxHandler.getMaxRange(player);
			boolean selected = player.method_31548().field_7545 == slot;
			int offset = selected ? 1 : 0;
			AllGuiTextures texture = ToolboxHandler.distance(player.method_19538(), pos) < max * max
				? selected ? TOOLBELT_SELECTED_ON : TOOLBELT_HOTBAR_ON
				: selected ? TOOLBELT_SELECTED_OFF : TOOLBELT_HOTBAR_OFF;
			texture.render(guiGraphics, x + 20 * slot - offset, y + offset);
		}
		poseStack.method_22909();
	}

}
