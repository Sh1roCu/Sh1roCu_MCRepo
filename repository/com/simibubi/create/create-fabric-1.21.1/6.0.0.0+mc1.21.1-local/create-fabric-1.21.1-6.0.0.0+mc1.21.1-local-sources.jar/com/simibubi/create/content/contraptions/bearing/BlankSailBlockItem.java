package com.simibubi.create.content.contraptions.bearing;

import java.util.Map;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import com.simibubi.create.AllBlocks;
import com.tterrag.registrate.util.entry.BlockEntry;

public class BlankSailBlockItem extends class_1747 {
	public BlankSailBlockItem(class_2248 block, class_1793 properties) {
		super(block, properties);
	}

	@Override
	public void method_7713(Map<class_2248, class_1792> blockToItemMap, class_1792 item) {
		super.method_7713(blockToItemMap, item);
		for (BlockEntry<SailBlock> entry : AllBlocks.DYED_SAILS) {
			blockToItemMap.put(entry.get(), item);
		}
	}
}
