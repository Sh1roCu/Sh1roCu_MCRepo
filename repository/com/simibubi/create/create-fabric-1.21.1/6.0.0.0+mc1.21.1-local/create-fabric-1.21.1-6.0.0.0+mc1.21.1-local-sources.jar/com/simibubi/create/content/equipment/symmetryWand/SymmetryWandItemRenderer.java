package com.simibubi.create.content.equipment.symmetryWand;

import com.simibubi.create.Create;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModel;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModelRenderer;
import com.simibubi.create.foundation.item.render.PartialItemModelRenderer;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.minecraft.class_1799;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;

public class SymmetryWandItemRenderer extends CustomRenderedItemModelRenderer {

	protected static final PartialModel BITS = PartialModel.of(Create.asResource("item/wand_of_symmetry/bits"));
	protected static final PartialModel CORE = PartialModel.of(Create.asResource("item/wand_of_symmetry/core"));
	protected static final PartialModel CORE_GLOW = PartialModel.of(Create.asResource("item/wand_of_symmetry/core_glow"));

	@Override
	protected void render(class_1799 stack, CustomRenderedItemModel model, PartialItemModelRenderer renderer, class_811 transformType,
		class_4587 ms, class_4597 buffer, int light, int overlay) {
		float worldTime = AnimationTickHolder.getRenderTime() / 20;
		int maxLight = class_765.field_32767;

		renderer.render(model.getOriginalModel(), light);
		renderer.renderSolidGlowing(CORE.get(), maxLight);
		renderer.renderGlowing(CORE_GLOW.get(), maxLight);

		float floating = class_3532.method_15374(worldTime) * .05f;
		float angle = worldTime * -10 % 360;

		ms.method_46416(0, floating, 0);
		ms.method_22907(class_7833.field_40716.rotationDegrees(angle));

		renderer.renderGlowing(BITS.get(), maxLight);
	}

}
