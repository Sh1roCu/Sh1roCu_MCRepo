package com.simibubi.create.content.decoration;

import com.simibubi.create.content.decoration.slidingDoor.SlidingDoorBlock;
import com.simibubi.create.content.equipment.wrench.IWrenchable;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_2760;
import net.minecraft.class_3612;
import net.minecraft.class_3965;

public class TrainTrapdoorBlock extends class_2533 implements IWrenchable {

	public TrainTrapdoorBlock(class_2251 properties) {
		super(SlidingDoorBlock.TRAIN_SET_TYPE.get(), properties);
	}

	@Override
	protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
		state = state.method_28493(field_11631);
		level.method_8652(pos, state, 2);
		if (state.method_11654(field_11626))
			level.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(level));
		method_10740(player, level, pos, state.method_11654(field_11631));
		return class_1269.method_29236(level.field_9236);
	}

	@Override
	public boolean method_9522(class_2680 state, class_2680 other, class_2350 pDirection) {
		return state.method_27852(this) == other.method_27852(this) && isConnected(state, other, pDirection);
	}

	public static boolean isConnected(class_2680 state, class_2680 other, class_2350 pDirection) {
		state = state.method_11657(field_11626, false)
			.method_11657(field_11629, false);
		other = other.method_11657(field_11626, false)
			.method_11657(field_11629, false);

		boolean open = state.method_11654(field_11631);
		class_2760 half = state.method_11654(field_11625);
		class_2350 facing = state.method_11654(field_11177);

		if (open != other.method_11654(field_11631))
			return false;
		if (!open && half == other.method_11654(field_11625))
			return pDirection.method_10166() != class_2351.field_11052;
		if (!open && half != other.method_11654(field_11625) && pDirection.method_10166() == class_2351.field_11052)
			return true;
		if (open && facing.method_10153() == other.method_11654(field_11177) && pDirection.method_10166() == facing.method_10166())
			return true;
		if ((open ? state.method_11657(field_11625, class_2760.field_12619) : state) != (open ? other.method_11657(field_11625, class_2760.field_12619) : other))
			return false;

		return pDirection.method_10166() != facing.method_10166();
	}

}
