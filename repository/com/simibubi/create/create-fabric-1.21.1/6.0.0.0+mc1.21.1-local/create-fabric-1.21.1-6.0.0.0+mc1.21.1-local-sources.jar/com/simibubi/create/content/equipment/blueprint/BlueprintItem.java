package com.simibubi.create.content.equipment.blueprint;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1530;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1856;
import net.minecraft.class_1856.class_1857;
import net.minecraft.class_1856.class_1858;
import net.minecraft.class_1856.class_1859;
import net.minecraft.class_1860;
import net.minecraft.class_1869;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import com.simibubi.create.AllDataComponents;
import com.simibubi.create.AllItems;
import com.simibubi.create.content.logistics.filter.AttributeFilterWhitelistMode;
import com.simibubi.create.content.logistics.filter.FilterItem;
import com.simibubi.create.content.logistics.item.filter.attribute.ItemAttribute;
import com.simibubi.create.content.logistics.item.filter.attribute.ItemAttribute.ItemAttributeEntry;
import com.simibubi.create.content.logistics.item.filter.attribute.attributes.InTagAttribute;
import com.simibubi.create.foundation.item.ItemHelper;
import com.simibubi.create.infrastructure.fabric.transfer.item.ItemStackHandler;

public class BlueprintItem extends class_1792 {

	public BlueprintItem(class_1793 properties) {
		super(properties);
	}

	@Override
	public class_1269 method_7884(class_1838 ctx) {
		class_2350 face = ctx.method_8038();
		class_1657 player = ctx.method_8036();
		class_1799 stack = ctx.method_8041();
		class_2338 pos = ctx.method_8037()
			.method_10093(face);

		if (player != null && !player.method_7343(pos, face, stack))
			return class_1269.field_5814;

		class_1937 world = ctx.method_8045();
		class_1530 hangingentity = new BlueprintEntity(world, pos, face, face.method_10166()
			.method_10179() ? class_2350.field_11033 : ctx.method_8042());
		class_9279 customData = stack.method_57824(class_9334.field_49628);

		if (customData != null)
			class_1299.method_5881(world, player, hangingentity, customData);
		if (!hangingentity.method_6888())
			return class_1269.field_21466;
		if (!world.field_9236) {
			hangingentity.method_6894();
			world.method_8649(hangingentity);
		}

		stack.method_7934(1);
		return class_1269.method_29236(world.field_9236);
	}

	public static void assignCompleteRecipe(class_1937 level, ItemStackHandler inv, class_1860<?> recipe) {
		class_2371<class_1856> ingredients = recipe.method_8117();

		for (int i = 0; i < 9; i++)
			inv.setStackInSlot(i, class_1799.field_8037);
		inv.setStackInSlot(9, recipe.method_8110(level.method_30349()));

		if (recipe instanceof class_1869 shapedRecipe) {
			for (int row = 0; row < shapedRecipe.method_8158(); row++)
				for (int col = 0; col < shapedRecipe.method_8150(); col++)
					inv.setStackInSlot(row * 3 + col,
						convertIngredientToFilter(ingredients.get(row * shapedRecipe.method_8150() + col)));
		} else {
			for (int i = 0; i < ingredients.size(); i++)
				inv.setStackInSlot(i, convertIngredientToFilter(ingredients.get(i)));
		}
	}

	private static class_1799 convertIngredientToFilter(class_1856 ingredient) {
		boolean isCompoundIngredient = false;
		class_1856.class_1859[] acceptedItems = ingredient.field_9019;
		if (acceptedItems == null || acceptedItems.length > 18)
			return class_1799.field_8037;
		if (acceptedItems.length == 0)
			return class_1799.field_8037;
		if (acceptedItems.length == 1)
			return convertIItemListToFilter(acceptedItems[0], isCompoundIngredient);

		class_1799 result = AllItems.FILTER.asStack();
		ItemStackHandler filterItems = FilterItem.getFilterItems(result);
		for (int i = 0; i < acceptedItems.length; i++)
			filterItems.setStackInSlot(i, convertIItemListToFilter(acceptedItems[i], isCompoundIngredient));
		result.method_57379(AllDataComponents.FILTER_ITEMS, ItemHelper.containerContentsFromHandler(filterItems));
		return result;
	}

	private static class_1799 convertIItemListToFilter(class_1859 itemList, boolean isCompoundIngredient) {
		Collection<class_1799> stacks = itemList.method_8108();
		if (itemList instanceof class_1857) {
			for (class_1799 itemStack : stacks)
				return itemStack;
		}

		if (itemList instanceof class_1858 tagValue) {
			class_1799 filterItem = AllItems.ATTRIBUTE_FILTER.asStack();
			filterItem.method_57379(AllDataComponents.ATTRIBUTE_FILTER_WHITELIST_MODE, AttributeFilterWhitelistMode.WHITELIST_DISJ);
			List<ItemAttributeEntry> attributes = new ArrayList<>();
			ItemAttribute at = new InTagAttribute(tagValue.comp_1931());
			attributes.add(new ItemAttribute.ItemAttributeEntry(at, false));
			filterItem.method_57379(AllDataComponents.ATTRIBUTE_FILTER_MATCHED_ATTRIBUTES, attributes);
			return filterItem;
		}

		if (isCompoundIngredient) {
			class_1799 result = AllItems.FILTER.asStack();
			ItemStackHandler filterItems = FilterItem.getFilterItems(result);
			int i = 0;
			for (class_1799 itemStack : stacks) {
				if (i >= 18)
					break;
				filterItems.setStackInSlot(i++, itemStack);
			}
			result.method_57379(AllDataComponents.FILTER_ITEMS, ItemHelper.containerContentsFromHandler(filterItems));
			result.method_57379(AllDataComponents.FILTER_ITEMS_RESPECT_NBT, true);
			return result;
		}

		return class_1799.field_8037;
	}

}
