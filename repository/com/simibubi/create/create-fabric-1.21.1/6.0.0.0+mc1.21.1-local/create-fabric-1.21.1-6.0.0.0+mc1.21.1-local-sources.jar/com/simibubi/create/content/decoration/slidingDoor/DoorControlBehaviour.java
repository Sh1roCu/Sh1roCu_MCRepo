package com.simibubi.create.content.decoration.slidingDoor;

import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BehaviourType;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

import net.createmod.catnip.nbt.NBTHelper;
import net.minecraft.class_2487;
import net.minecraft.class_7225;

public class DoorControlBehaviour extends BlockEntityBehaviour {

	public static final BehaviourType<DoorControlBehaviour> TYPE = new BehaviourType<>();

	public DoorControl mode;

	public DoorControlBehaviour(SmartBlockEntity be) {
		super(be);
		mode = DoorControl.ALL;
	}

	public void set(DoorControl mode) {
		if (this.mode == mode)
			return;
		this.mode = mode;
		blockEntity.notifyUpdate();
	}

	@Override
	public void write(class_2487 nbt, class_7225.class_7874 registries, boolean clientPacket) {
		NBTHelper.writeEnum(nbt, "DoorControl", mode);
		super.write(nbt, registries, clientPacket);
	}

	@Override
	public void read(class_2487 nbt, class_7225.class_7874 registries, boolean clientPacket) {
		mode = NBTHelper.readEnum(nbt, "DoorControl", DoorControl.class);
		super.read(nbt, registries, clientPacket);
	}

	@Override
	public BehaviourType<?> getType() {
		return TYPE;
	}

}
