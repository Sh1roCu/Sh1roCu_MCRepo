package com.simibubi.create.api.event;

import org.jetbrains.annotations.Nullable;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3611;

/**
 * This Event is fired when two fluids meet in a pipe ({@link Flow})<br>
 * or when a fluid in a pipe meets with a fluid in the world
 * ({@link Spill}).<br>
 * <br>
 * If it is not null, the event's BlockState will be placed in world after
 * firing.
 */
public class PipeCollisionEvent {

	public static final Event<FlowCallback> FLOW = EventFactory.createArrayBacked(FlowCallback.class, callbacks -> event -> {
		for (FlowCallback callback : callbacks)
			callback.handleFlow(event);
	});

	public static final Event<SpillCallback> SPILL = EventFactory.createArrayBacked(SpillCallback.class, callbacks -> event -> {
		for (SpillCallback callback : callbacks)
			callback.handleSpill(event);
	});

	protected final class_3611 firstFluid, secondFluid;
	private final class_1937 level;
	private final class_2338 pos;
	@Nullable
	private class_2680 state;

	protected PipeCollisionEvent(class_1937 level, class_2338 pos, class_3611 firstFluid, class_3611 secondFluid,
								 @Nullable class_2680 defaultState) {
		this.level = level;
		this.pos = pos;
		this.firstFluid = firstFluid;
		this.secondFluid = secondFluid;
		this.state = defaultState;
	}

	public class_1937 getLevel() {
		return level;
	}

	public class_2338 getPos() {
		return pos;
	}

	@Nullable
	public class_2680 getState() {
		return state;
	}

	public void setState(@Nullable class_2680 state) {
		this.state = state;
	}

	public static class Flow extends PipeCollisionEvent {

		public Flow(class_1937 level, class_2338 pos, class_3611 firstFluid, class_3611 secondFluid, @Nullable class_2680 defaultState) {
			super(level, pos, firstFluid, secondFluid, defaultState);
		}

		public class_3611 getFirstFluid() {
			return firstFluid;
		}

		public class_3611 getSecondFluid() {
			return secondFluid;
		}
	}

	public static class Spill extends PipeCollisionEvent {

		public Spill(class_1937 level, class_2338 pos, class_3611 worldFluid, class_3611 pipeFluid, @Nullable class_2680 defaultState) {
			super(level, pos, worldFluid, pipeFluid, defaultState);
		}

		public class_3611 getWorldFluid() {
			return firstFluid;
		}

		public class_3611 getPipeFluid() {
			return secondFluid;
		}
	}

	@FunctionalInterface
	public interface FlowCallback {
		void handleFlow(Flow event);
	}

	@FunctionalInterface
	public interface SpillCallback {
		void handleSpill(Spill event);
	}
}
