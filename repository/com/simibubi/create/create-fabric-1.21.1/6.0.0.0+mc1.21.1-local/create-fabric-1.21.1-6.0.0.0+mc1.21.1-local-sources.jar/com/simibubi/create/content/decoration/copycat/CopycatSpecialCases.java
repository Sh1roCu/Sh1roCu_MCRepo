package com.simibubi.create.content.decoration.copycat;

import com.simibubi.create.content.decoration.palettes.GlassPaneBlock;
import net.minecraft.class_2246;
import net.minecraft.class_2389;
import net.minecraft.class_2504;
import net.minecraft.class_2533;
import net.minecraft.class_2680;

public class CopycatSpecialCases {

	public static boolean isBarsMaterial(class_2680 material) {
		return material.method_26204() instanceof class_2389 && !(material.method_26204() instanceof GlassPaneBlock)
			&& !(material.method_26204() instanceof class_2504) && material.method_26204() != class_2246.field_10285;
	}

	public static boolean isTrapdoorMaterial(class_2680 material) {
		return material.method_26204() instanceof class_2533 && material.method_28498(class_2533.field_11625)
			&& material.method_28498(class_2533.field_11631) && material.method_28498(class_2533.field_11177);
	}

}
