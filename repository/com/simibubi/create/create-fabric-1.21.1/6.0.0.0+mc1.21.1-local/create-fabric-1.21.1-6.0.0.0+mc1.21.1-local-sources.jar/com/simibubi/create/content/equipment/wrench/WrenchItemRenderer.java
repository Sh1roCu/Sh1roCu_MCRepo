package com.simibubi.create.content.equipment.wrench;

import com.simibubi.create.Create;
import com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.ScrollValueHandler;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModel;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModelRenderer;
import com.simibubi.create.foundation.item.render.PartialItemModelRenderer;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;

public class WrenchItemRenderer extends CustomRenderedItemModelRenderer {

	protected static final PartialModel GEAR = PartialModel.of(Create.asResource("item/wrench/gear"));

	@Override
	protected void render(class_1799 stack, CustomRenderedItemModel model, PartialItemModelRenderer renderer, class_811 transformType,
		class_4587 ms, class_4597 buffer, int light, int overlay) {
		renderer.render(model.getOriginalModel(), light);

		float xOffset = -1/16f;
		ms.method_46416(-xOffset, 0, 0);
		ms.method_22907(class_7833.field_40716.rotationDegrees(ScrollValueHandler.getScroll(AnimationTickHolder.getPartialTicks())));
		ms.method_46416(xOffset, 0, 0);

		renderer.render(GEAR.get(), light);
	}

}
