package com.simibubi.create.content.contraptions.actors.plough;

import com.simibubi.create.content.contraptions.actors.plough.PloughBlock.PloughFakePlayer;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.kinetics.base.BlockBreakingMovementBehaviour;
import com.simibubi.create.content.trains.track.FakeTrackBlock;
import com.simibubi.create.content.trains.track.ITrackBlock;
import com.simibubi.create.foundation.advancement.AllAdvancements;

import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1540;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_181;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2199;
import net.minecraft.class_2246;
import net.minecraft.class_2258;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_238;
import net.minecraft.class_239.class_240;
import net.minecraft.class_2404;
import net.minecraft.class_2423;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3959;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import net.minecraft.class_3965;
import net.minecraft.class_8567;

public class PloughMovementBehaviour extends BlockBreakingMovementBehaviour {

	@Override
	public boolean isActive(MovementContext context) {
		return super.isActive(context)
			&& !VecHelper.isVecPointingTowards(context.relativeMotion, context.state.method_11654(PloughBlock.field_11177)
			.method_10153());
	}

	@Override
	public void visitNewPosition(MovementContext context, class_2338 pos) {
		super.visitNewPosition(context, pos);
		class_1937 world = context.world;
		if (world.field_9236)
			return;
		class_2338 below = pos.method_10074();
		if (!world.method_8477(below))
			return;

		class_243 vec = VecHelper.getCenterOf(pos);
		PloughFakePlayer player = getPlayer(context);

		if (player == null)
			return;

		class_3965 ray = world.method_17742(new class_3959(vec, vec.method_1031(0, -1, 0), class_3960.field_17559, class_242.field_1348, player));
		if (ray.method_17783() != class_240.field_1332)
			return;

		class_1838 ctx = new class_1838(player, class_1268.field_5808, ray);
		new class_1799(class_1802.field_8527).method_7981(ctx);
	}

	@Override
	protected void throwEntity(MovementContext context, class_1297 entity) {
		super.throwEntity(context, entity);
		if (!(entity instanceof class_1540 fbe))
			return;
		if (!(fbe.method_6962()
			.method_26204() instanceof class_2199))
			return;
		if (entity.method_18798()
			.method_1033() < 0.25f)
			return;
		entity.method_37908().method_18467(class_1657.class, new class_238(entity.method_24515()).method_1014(32))
			.forEach(AllAdvancements.ANVIL_PLOUGH::awardTo);
	}

	@Override
	public class_243 getActiveAreaOffset(MovementContext context) {
		return class_243.method_24954(context.state.method_11654(PloughBlock.field_11177)
				.method_10163())
			.method_1021(.45);
	}

	@Override
	protected boolean throwsEntities(class_1937 level) {
		return true;
	}

	@Override
	public boolean canBreak(class_1937 world, class_2338 breakingPos, class_2680 state) {
		if (state.method_26215())
			return false;
		if (world.method_8320(breakingPos.method_10074())
			.method_26204() instanceof class_2344)
			return false;
		if (state.method_26204() instanceof class_2404)
			return false;
		if (state.method_26204() instanceof class_2258)
			return false;
		if (state.method_26204() instanceof class_2423)
			return false;
		if (state.method_26204() instanceof ITrackBlock)
			return true;
		if (state.method_26204() instanceof FakeTrackBlock)
			return false;
		return state.method_26220(world, breakingPos)
			.method_1110();
	}

	@Override
	protected void onBlockBroken(MovementContext context, class_2338 pos, class_2680 brokenState) {
		super.onBlockBroken(context, pos, brokenState);

		if (brokenState.method_26204() == class_2246.field_10477 && context.world instanceof class_3218 world) {
			brokenState.method_26189(new class_8567.class_8568(world).method_51874(class_181.field_1224, brokenState)
					.method_51874(class_181.field_24424, class_243.method_24953(pos))
					.method_51874(class_181.field_1226, getPlayer(context))
					.method_51874(class_181.field_1229, new class_1799(class_1802.field_8699)))
				.forEach(s -> dropItem(context, s));
		}
	}

	@Override
	public void stopMoving(MovementContext context) {
		super.stopMoving(context);
		if (context.temporaryData instanceof PloughFakePlayer)
			((PloughFakePlayer) context.temporaryData).method_31472();
	}

	private PloughFakePlayer getPlayer(MovementContext context) {
		if (!(context.temporaryData instanceof PloughFakePlayer) && context.world != null) {
			PloughFakePlayer player = new PloughFakePlayer((class_3218) context.world);
			player.method_6122(class_1268.field_5808, new class_1799(class_1802.field_8527));
			context.temporaryData = player;
		}
		return (PloughFakePlayer) context.temporaryData;
	}

}
