package com.simibubi.create.content.equipment.bell;

import java.util.List;

import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import net.createmod.catnip.nbt.NBTHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

public abstract class AbstractBellBlockEntity extends SmartBlockEntity {

	public static final int RING_DURATION = 74;

	public boolean isRinging;
	public int ringingTicks;
	public class_2350 ringDirection;

	public AbstractBellBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) { }

	public boolean ring(class_1937 world, class_2338 pos, class_2350 direction) {
		isRinging = true;
		ringingTicks = 0;
		ringDirection = direction;
		sendData();
		return true;
	};

	@Override
	public void tick() {
		super.tick();

		if (isRinging) {
			++ringingTicks;
		}

		if (ringingTicks >= RING_DURATION) {
			isRinging = false;
			ringingTicks = 0;
		}
	}

	@Override
	protected void write(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		super.write(tag, registries, clientPacket);
		if (!clientPacket || ringingTicks != 0 || !isRinging)
			return;
		NBTHelper.writeEnum(tag, "Ringing", ringDirection);
	}

	@Override
	protected void read(class_2487 tag, class_7225.class_7874 registries, boolean clientPacket) {
		super.read(tag, registries, clientPacket);
		if (!clientPacket || !tag.method_10545("Ringing"))
			return;
		ringDirection = NBTHelper.readEnum(tag, "Ringing", class_2350.class);
		ringingTicks = 0;
		isRinging = true;
	}

	@Environment(EnvType.CLIENT)
	public abstract PartialModel getBellModel();

}
