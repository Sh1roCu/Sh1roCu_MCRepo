package com.simibubi.create.content.equipment.bell;

import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.simibubi.create.AllBlocks;
import net.createmod.catnip.platform.CatnipServices;
import net.createmod.catnip.data.IntAttached;
import net.createmod.catnip.platform.CatnipServices;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class HauntedBellPulser {

	public static final int DISTANCE = 3;
	public static final int RECHARGE_TICKS = 8;
	public static final int WARMUP_TICKS = 10;

	public static final Cache<UUID, IntAttached<class_1297>> WARMUP = CacheBuilder.newBuilder()
		.expireAfterAccess(250, TimeUnit.MILLISECONDS)
		.build();

	public static void hauntedBellCreatesPulse(class_1657 player) {

		if (player.method_37908().method_8608())
			return;

		if (player.method_7325())
			return;
		if (!player.method_24520(AllBlocks.HAUNTED_BELL::isIn))
			return;

		boolean firstPulse = false;

		try {
			IntAttached<class_1297> ticker = WARMUP.get(player.method_5667(), () -> IntAttached.with(WARMUP_TICKS, player));
			firstPulse = ticker.getFirst() == 1;
			ticker.decrement();
			if (!ticker.isOrBelowZero())
				return;
		} catch (ExecutionException ignored) {}

		long gameTime = player.method_37908().method_8510();
		if ((firstPulse || gameTime % RECHARGE_TICKS != 0) && player.method_37908() instanceof class_3218 serverLevel)
			sendPulse(serverLevel, player.method_24515(), DISTANCE, false);
	}

	public static void sendPulse(class_3218 world, class_2338 pos, int distance, boolean canOverlap) {
		class_1923 chunk = world.method_8500(pos).method_12004();
		CatnipServices.NETWORK.sendToClientsTrackingChunk(world, chunk, new SoulPulseEffectPacket(pos, distance, canOverlap));
	}

}
