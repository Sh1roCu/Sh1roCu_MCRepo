package com.simibubi.create.content.equipment.symmetryWand.mirror;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.google.common.collect.ImmutableList;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.simibubi.create.foundation.utility.CreateLang;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import io.netty.buffer.ByteBuf;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecs;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_243;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2769;
import net.minecraft.class_3542;
import net.minecraft.class_4587;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public abstract class SymmetryMirror {
	public static final String EMPTY = "empty";
	public static final String PLANE = "plane";
	public static final String CROSS_PLANE = "cross_plane";
	public static final String TRIPLE_PLANE = "triple_plane";

	public static final Codec<SymmetryMirror> CODEC = RecordCodecBuilder.create(i -> i.group(
		Codec.INT.fieldOf("orientation_index").forGetter(SymmetryMirror::getOrientationIndex),
			class_243.field_38277.fieldOf("position").forGetter(SymmetryMirror::getPosition),
			Codec.STRING.fieldOf("type").forGetter(SymmetryMirror::typeName),
			Codec.BOOL.fieldOf("enable").forGetter(m -> m.enable)
	).apply(i, SymmetryMirror::create));

	public static final class_9139<ByteBuf, SymmetryMirror> STREAM_CODEC = class_9139.method_56905(
			class_9135.field_49675, SymmetryMirror::getOrientationIndex,
			CatnipStreamCodecs.VEC3, SymmetryMirror::getPosition,
			class_9135.field_48554, SymmetryMirror::typeName,
			class_9135.field_48547, m -> m.enable,
			SymmetryMirror::create
	);

	protected class_243 position;
	protected class_3542 orientation;
	protected int orientationIndex;
	public boolean enable;

	public SymmetryMirror(class_243 pos) {
		position = pos;
		enable = true;
		orientationIndex = 0;
	}

	public static List<class_2561> getMirrors() {
		return ImmutableList.of(CreateLang.translateDirect("symmetry.mirror.plane"), CreateLang.translateDirect("symmetry.mirror.doublePlane"),
			CreateLang.translateDirect("symmetry.mirror.triplePlane"));
	}

	private static SymmetryMirror create(Integer orientationIndex, class_243 position, String type, Boolean enable) {
		SymmetryMirror element = switch (type) {
			case PLANE -> new PlaneMirror(position);
			case CROSS_PLANE -> new CrossPlaneMirror(position);
			case TRIPLE_PLANE -> new TriplePlaneMirror(position);
			default -> new EmptyMirror(position);
		};

		element.setOrientation(orientationIndex);
		element.enable = enable;

		return element;
	}

	public class_3542 getOrientation() {
		return orientation;
	}

	public class_243 getPosition() {
		return position;
	}

	public int getOrientationIndex() {
		return orientationIndex;
	}

	public void rotate(boolean forward) {
		orientationIndex += forward ? 1 : -1;
		setOrientation();
	}

	public void process(Map<class_2338, class_2680> blocks) {
		Map<class_2338, class_2680> result = new HashMap<>();
		for (class_2338 pos : blocks.keySet()) {
			result.putAll(process(pos, blocks.get(pos)));
		}
		blocks.putAll(result);
	}

	public abstract Map<class_2338, class_2680> process(class_2338 position, class_2680 block);

	protected abstract void setOrientation();

	public abstract void setOrientation(int index);

	public abstract String typeName();

	@Environment(EnvType.CLIENT)
	public abstract PartialModel getModel();

	public void applyModelTransform(class_4587 ms) {}

	protected class_243 getDiff(class_2338 position) {
		return this.position.method_1021(-1)
			.method_1031(position.method_10263(), position.method_10264(), position.method_10260());
	}

	protected class_2338 getIDiff(class_2338 position) {
		class_243 diff = getDiff(position);
		return new class_2338((int) diff.field_1352, (int) diff.field_1351, (int) diff.field_1350);
	}

	protected class_2680 flipX(class_2680 in) {
		return in.method_26185(class_2415.field_11301);
	}

	protected class_2680 flipY(class_2680 in) {
		for (class_2769<?> property : in.method_28501()) {

			if (property == class_2741.field_12518)
				return in.method_28493(property);
			// Directional Blocks
			if (property instanceof class_2753) {
				if (in.method_11654(property) == class_2350.field_11033) {
					return in.method_11657((class_2753) property, class_2350.field_11036);
				} else if (in.method_11654(property) == class_2350.field_11036) {
					return in.method_11657((class_2753) property, class_2350.field_11033);
				}
			}
		}
		return in;
	}

	protected class_2680 flipZ(class_2680 in) {
		return in.method_26185(class_2415.field_11300);
	}

	@SuppressWarnings("deprecation")
	protected class_2680 flipD1(class_2680 in) {
		return in.method_26186(class_2470.field_11465)
			.method_26185(class_2415.field_11301);
	}

	@SuppressWarnings("deprecation")
	protected class_2680 flipD2(class_2680 in) {
		return in.method_26186(class_2470.field_11465)
			.method_26185(class_2415.field_11300);
	}

	protected class_2338 flipX(class_2338 position) {
		class_2338 diff = getIDiff(position);
		return new class_2338(position.method_10263() - 2 * diff.method_10263(), position.method_10264(), position.method_10260());
	}

	protected class_2338 flipY(class_2338 position) {
		class_2338 diff = getIDiff(position);
		return new class_2338(position.method_10263(), position.method_10264() - 2 * diff.method_10264(), position.method_10260());
	}

	protected class_2338 flipZ(class_2338 position) {
		class_2338 diff = getIDiff(position);
		return new class_2338(position.method_10263(), position.method_10264(), position.method_10260() - 2 * diff.method_10260());
	}

	protected class_2338 flipD2(class_2338 position) {
		class_2338 diff = getIDiff(position);
		return new class_2338(position.method_10263() - diff.method_10263() + diff.method_10260(), position.method_10264(),
			position.method_10260() - diff.method_10260() + diff.method_10263());
	}

	protected class_2338 flipD1(class_2338 position) {
		class_2338 diff = getIDiff(position);
		return new class_2338(position.method_10263() - diff.method_10263() - diff.method_10260(), position.method_10264(),
			position.method_10260() - diff.method_10260() - diff.method_10263());
	}

	public void setPosition(class_243 pos3d) {
		this.position = pos3d;
	}

	public abstract List<class_2561> getAlignToolTips();

	@Override
	public final boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof SymmetryMirror that)) return false;

		return getOrientationIndex() == that.getOrientationIndex() && enable == that.enable && Objects.equals(getPosition(), that.getPosition()) && Objects.equals(getOrientation(), that.getOrientation());
	}

	@Override
	public int hashCode() {
		int result = Objects.hashCode(getPosition());
		result = 31 * result + Objects.hashCode(getOrientation());
		result = 31 * result + getOrientationIndex();
		result = 31 * result + Boolean.hashCode(enable);
		return result;
	}
}
