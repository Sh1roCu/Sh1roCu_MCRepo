package com.simibubi.create.content.equipment.zapper.terrainzapper;

import com.simibubi.create.AllPackets;
import com.simibubi.create.content.equipment.zapper.ConfigureZapperPacket;
import com.simibubi.create.content.equipment.zapper.PlacementPatterns;

import net.createmod.catnip.codecs.stream.CatnipLargerStreamCodecs;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecs;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import io.netty.buffer.ByteBuf;

public class ConfigureWorldshaperPacket extends ConfigureZapperPacket {
	public static final class_9139<ByteBuf, ConfigureWorldshaperPacket> STREAM_CODEC = CatnipLargerStreamCodecs.composite(
			CatnipStreamCodecs.HAND, packet -> packet.hand,
			PlacementPatterns.STREAM_CODEC, packet -> packet.pattern,
			TerrainBrushes.STREAM_CODEC, packet -> packet.brush,
			class_9135.field_48550, packet -> packet.brushParamX,
			class_9135.field_48550, packet -> packet.brushParamY,
			class_9135.field_48550, packet -> packet.brushParamZ,
			TerrainTools.STREAM_CODEC, packet -> packet.tool,
			PlacementOptions.STREAM_CODEC, packet -> packet.placement,
			ConfigureWorldshaperPacket::new
	);

	private final TerrainBrushes brush;
	private final int brushParamX;
	private final int brushParamY;
	private final int brushParamZ;
	private final TerrainTools tool;
	private final PlacementOptions placement;

	public ConfigureWorldshaperPacket(class_1268 hand, PlacementPatterns pattern, TerrainBrushes brush,
									  int brushParamX, int brushParamY, int brushParamZ,
									  TerrainTools tool, PlacementOptions placement) {
		super(hand, pattern);
		this.brush = brush;
		this.brushParamX = brushParamX;
		this.brushParamY = brushParamY;
		this.brushParamZ = brushParamZ;
		this.tool = tool;
		this.placement = placement;
	}

	@Override
	public void configureZapper(class_1799 stack) {
		WorldshaperItem.configureSettings(stack, pattern, brush, brushParamX, brushParamY, brushParamZ, tool, placement);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CONFIGURE_WORLDSHAPER;
	}
}
