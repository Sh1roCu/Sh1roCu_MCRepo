package com.simibubi.create.content.decoration;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2741;
import net.minecraft.class_2769;

public class CardboardBlock extends class_2248 {

	public static final class_2769<class_2351> HORIZONTAL_AXIS = class_2741.field_12529;

	public CardboardBlock(class_2251 pProperties) {
		super(pProperties);
	}

	@Override
	public class_2680 method_9605(class_1750 pContext) {
		return this.method_9564()
			.method_11657(HORIZONTAL_AXIS, pContext.method_8042()
				.method_10166());
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> builder) {
		super.method_9515(builder.method_11667(HORIZONTAL_AXIS));
	}

	@Override
	public class_2680 method_9598(class_2680 state, class_2470 rot) {
		return state.method_11657(HORIZONTAL_AXIS,
			rot.method_10503(class_2350.method_10156(class_2352.field_11056, state.method_11654(HORIZONTAL_AXIS)))
				.method_10166());
	}

	@Override
	public class_2680 method_9569(class_2680 state, class_2415 mirrorIn) {
		return state;
	}

}
