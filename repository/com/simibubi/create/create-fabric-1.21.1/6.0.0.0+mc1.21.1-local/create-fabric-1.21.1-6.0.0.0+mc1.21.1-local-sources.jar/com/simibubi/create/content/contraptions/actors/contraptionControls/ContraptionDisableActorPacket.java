package com.simibubi.create.content.contraptions.actors.contraptionControls;

import java.util.List;

import com.simibubi.create.AllPackets;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.Contraption;
import net.createmod.catnip.net.base.ClientboundPacketPayload;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_746;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ContraptionDisableActorPacket(int entityId, class_1799 filter, boolean enable) implements ClientboundPacketPayload {
	public static final class_9139<class_9129, com.simibubi.create.content.contraptions.actors.contraptionControls.ContraptionDisableActorPacket> STREAM_CODEC = class_9139.method_56436(
			class_9135.field_49675, com.simibubi.create.content.contraptions.actors.contraptionControls.ContraptionDisableActorPacket::entityId,
			class_1799.field_49268, com.simibubi.create.content.contraptions.actors.contraptionControls.ContraptionDisableActorPacket::filter,
			class_9135.field_48547, com.simibubi.create.content.contraptions.actors.contraptionControls.ContraptionDisableActorPacket::enable,
	        com.simibubi.create.content.contraptions.actors.contraptionControls.ContraptionDisableActorPacket::new
	);

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		class_1297 entityByID = player.field_17892.method_8469(entityId);
		if (!(entityByID instanceof AbstractContraptionEntity ace))
			return;

		Contraption contraption = ace.getContraption();
		List<class_1799> disabledActors = contraption.getDisabledActors();
		if (filter.method_7960())
			disabledActors.clear();

		if (!enable) {
			disabledActors.add(filter);
			contraption.setActorsActive(filter, false);
			return;
		}

		disabledActors.removeIf(next -> ContraptionControlsMovement.isSameFilter(next, filter) || next.method_7960());

		contraption.setActorsActive(filter, true);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CONTRAPTION_ACTOR_TOGGLE;
	}
}
