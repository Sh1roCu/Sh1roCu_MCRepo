package com.simibubi.create.content.decoration.palettes;

import static com.simibubi.create.content.decoration.palettes.PaletteBlockPartial.ALL_PARTIALS;
import static com.simibubi.create.content.decoration.palettes.PaletteBlockPartial.FOR_POLISHED;
import static com.simibubi.create.content.decoration.palettes.PaletteBlockPattern.PatternNameType.PREFIX;
import static com.simibubi.create.content.decoration.palettes.PaletteBlockPattern.PatternNameType.SUFFIX;
import static com.simibubi.create.content.decoration.palettes.PaletteBlockPattern.PatternNameType.WRAP;

import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;

import com.simibubi.create.Create;
import com.simibubi.create.foundation.block.connected.AllCTTypes;
import com.simibubi.create.foundation.block.connected.CTSpriteShiftEntry;
import com.simibubi.create.foundation.block.connected.CTSpriteShifter;
import com.simibubi.create.foundation.block.connected.CTType;
import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;
import com.simibubi.create.foundation.block.connected.HorizontalCTBehaviour;
import com.simibubi.create.foundation.block.connected.RotatedPillarCTBehaviour;
import com.tterrag.registrate.providers.DataGenContext;
import com.tterrag.registrate.providers.RegistrateBlockstateProvider;
import com.tterrag.registrate.providers.RegistrateRecipeProvider;
import com.tterrag.registrate.util.nullness.NonNullBiConsumer;
import com.tterrag.registrate.util.nullness.NonNullFunction;
import com.tterrag.registrate.util.nullness.NonNullSupplier;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_4970.class_2251;
import net.minecraft.class_6862;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import io.github.fabricators_of_create.porting_lib.models.generators.ConfiguredModel;

public class PaletteBlockPattern {

	public static final PaletteBlockPattern

	CUT =
		create("cut", PREFIX, ALL_PARTIALS),

		BRICKS = create("cut_bricks", WRAP, ALL_PARTIALS).textures("brick"),

		SMALL_BRICKS = create("small_bricks", WRAP, ALL_PARTIALS).textures("small_brick"),

		POLISHED = create("polished_cut", PREFIX, FOR_POLISHED).textures("polished", "slab"),

		LAYERED = create("layered", PREFIX).blockStateFactory(p -> p::cubeColumn)
			.textures("layered", "cap")
			.connectedTextures(v -> new HorizontalCTBehaviour(ct(v, CTs.LAYERED), ct(v, CTs.CAP))),

		PILLAR = create("pillar", SUFFIX).blockStateFactory(p -> p::pillar)
			.block(ConnectedPillarBlock::new)
			.textures("pillar", "cap")
			.connectedTextures(v -> new RotatedPillarCTBehaviour(ct(v, CTs.PILLAR), ct(v, CTs.CAP)))

	;

	public static final PaletteBlockPattern[] VANILLA_RANGE = { CUT, POLISHED, BRICKS, SMALL_BRICKS, LAYERED, PILLAR };

	public static final PaletteBlockPattern[] STANDARD_RANGE = { CUT, POLISHED, BRICKS, SMALL_BRICKS, LAYERED, PILLAR };

	static final String TEXTURE_LOCATION = "block/palettes/stone_types/%s/%s";

	private PatternNameType nameType;
	private String[] textures;
	private String id;
	private boolean isTranslucent;
	private class_6862<class_2248>[] blockTags;
	private class_6862<class_1792>[] itemTags;
	private Optional<Function<String, ConnectedTextureBehaviour>> ctFactory;

	private IPatternBlockStateGenerator blockStateGenerator;
	private NonNullFunction<class_2251, ? extends class_2248> blockFactory;
	private NonNullFunction<NonNullSupplier<class_2248>, NonNullBiConsumer<DataGenContext<class_2248, ? extends class_2248>, RegistrateRecipeProvider>> additionalRecipes;
	private PaletteBlockPartial<? extends class_2248>[] partials;

	@Environment(EnvType.CLIENT)
	private class_1921 renderType;

	private static PaletteBlockPattern create(String name, PatternNameType nameType,
		PaletteBlockPartial<?>... partials) {
		PaletteBlockPattern pattern = new PaletteBlockPattern();
		pattern.id = name;
		pattern.ctFactory = Optional.empty();
		pattern.nameType = nameType;
		pattern.partials = partials;
		pattern.additionalRecipes = $ -> NonNullBiConsumer.noop();
		pattern.isTranslucent = false;
		pattern.blockFactory = class_2248::new;
		pattern.textures = new String[] { name };
		pattern.blockStateGenerator = p -> p::cubeAll;
		return pattern;
	}

	public IPatternBlockStateGenerator getBlockStateGenerator() {
		return blockStateGenerator;
	}

	public boolean isTranslucent() {
		return isTranslucent;
	}

	public class_6862<class_2248>[] getBlockTags() {
		return blockTags;
	}

	public class_6862<class_1792>[] getItemTags() {
		return itemTags;
	}

	public NonNullFunction<class_2251, ? extends class_2248> getBlockFactory() {
		return blockFactory;
	}

	public PaletteBlockPartial<? extends class_2248>[] getPartials() {
		return partials;
	}

	public String getTexture(int index) {
		return textures[index];
	}

	public void addRecipes(NonNullSupplier<class_2248> baseBlock, DataGenContext<class_2248, ? extends class_2248> c,
		RegistrateRecipeProvider p) {
		additionalRecipes.apply(baseBlock)
			.accept(c, p);
	}

	public Optional<Supplier<ConnectedTextureBehaviour>> createCTBehaviour(String variant) {
		return ctFactory.map(d -> () -> d.apply(variant));
	}

	// Builder

	private PaletteBlockPattern blockStateFactory(IPatternBlockStateGenerator factory) {
		blockStateGenerator = factory;
		return this;
	}

	private PaletteBlockPattern textures(String... textures) {
		this.textures = textures;
		return this;
	}

	private PaletteBlockPattern block(NonNullFunction<class_2251, ? extends class_2248> blockFactory) {
		this.blockFactory = blockFactory;
		return this;
	}

	private PaletteBlockPattern connectedTextures(Function<String, ConnectedTextureBehaviour> factory) {
		this.ctFactory = Optional.of(factory);
		return this;
	}

	// Model generators

	public IBlockStateProvider cubeAll(String variant) {
		class_2960 all = toLocation(variant, textures[0]);
		return (ctx, prov) -> prov.simpleBlock(ctx.get(), prov.models()
			.cubeAll(createName(variant), all));
	}

	public IBlockStateProvider cubeBottomTop(String variant) {
		class_2960 side = toLocation(variant, textures[0]);
		class_2960 bottom = toLocation(variant, textures[1]);
		class_2960 top = toLocation(variant, textures[2]);
		return (ctx, prov) -> prov.simpleBlock(ctx.get(), prov.models()
			.cubeBottomTop(createName(variant), side, bottom, top));
	}

	public IBlockStateProvider pillar(String variant) {
		class_2960 side = toLocation(variant, textures[0]);
		class_2960 end = toLocation(variant, textures[1]);

		return (ctx, prov) -> prov.getVariantBuilder(ctx.getEntry())
			.forAllStatesExcept(state -> {
				class_2351 axis = state.method_11654(class_2741.field_12496);
				if (axis == class_2351.field_11052)
					return ConfiguredModel.builder()
						.modelFile(prov.models()
							.cubeColumn(createName(variant), side, end))
						.uvLock(false)
						.build();
				return ConfiguredModel.builder()
					.modelFile(prov.models()
						.cubeColumnHorizontal(createName(variant) + "_horizontal", side, end))
					.uvLock(false)
					.rotationX(90)
					.rotationY(axis == class_2351.field_11048 ? 90 : 0)
					.build();
			}, class_2741.field_12508, ConnectedPillarBlock.NORTH, ConnectedPillarBlock.SOUTH,
				ConnectedPillarBlock.EAST, ConnectedPillarBlock.WEST);
	}

	public IBlockStateProvider cubeColumn(String variant) {
		class_2960 side = toLocation(variant, textures[0]);
		class_2960 end = toLocation(variant, textures[1]);
		return (ctx, prov) -> prov.simpleBlock(ctx.get(), prov.models()
			.cubeColumn(createName(variant), side, end));
	}

	// Utility

	public String createName(String variant) {
		if (nameType == WRAP) {
			String[] split = id.split("_");
			if (split.length == 2) {
				String formatString = "%s_%s_%s";
				return String.format(formatString, split[0], variant, split[1]);
			}
		}
		String formatString = "%s_%s";
		return nameType == SUFFIX ? String.format(formatString, variant, id) : String.format(formatString, id, variant);
	}

	public static class_2960 toLocation(String variant, String texture) {
		return Create.asResource(
			String.format(TEXTURE_LOCATION, texture, variant + (texture.equals("cut") ? "_" : "_cut_") + texture));
	}

	protected static CTSpriteShiftEntry ct(String variant, CTs texture) {
		class_2960 resLoc = texture.srcFactory.apply(variant);
		class_2960 resLocTarget = texture.targetFactory.apply(variant);
		return CTSpriteShifter.getCT(texture.type, resLoc,
			class_2960.method_60655(resLocTarget.method_12836(), resLocTarget.method_12832() + "_connected"));
	}

	@FunctionalInterface
	static interface IPatternBlockStateGenerator
		extends Function<PaletteBlockPattern, Function<String, IBlockStateProvider>> {
	}

	@FunctionalInterface
	static interface IBlockStateProvider
		extends NonNullBiConsumer<DataGenContext<class_2248, ? extends class_2248>, RegistrateBlockstateProvider> {
	}

	enum PatternNameType {
		PREFIX, SUFFIX, WRAP
	}

	// Textures with connectability, used by Spriteshifter

	public enum CTs {

		PILLAR(AllCTTypes.RECTANGLE, s -> toLocation(s, "pillar")),
		CAP(AllCTTypes.OMNIDIRECTIONAL, s -> toLocation(s, "cap")),
		LAYERED(AllCTTypes.HORIZONTAL_KRYPPERS, s -> toLocation(s, "layered"))

		;

		public CTType type;
		private Function<String, class_2960> srcFactory;
		private Function<String, class_2960> targetFactory;

		private CTs(CTType type, Function<String, class_2960> factory) {
			this(type, factory, factory);
		}

		private CTs(CTType type, Function<String, class_2960> srcFactory,
			Function<String, class_2960> targetFactory) {
			this.type = type;
			this.srcFactory = srcFactory;
			this.targetFactory = targetFactory;
		}

	}

}
