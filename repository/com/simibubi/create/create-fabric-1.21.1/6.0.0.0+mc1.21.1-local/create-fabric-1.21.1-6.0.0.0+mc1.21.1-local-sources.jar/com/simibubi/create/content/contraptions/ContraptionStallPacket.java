package com.simibubi.create.content.contraptions;

import com.simibubi.create.AllPackets;
import net.createmod.catnip.net.base.ClientboundPacketPayload;

import io.netty.buffer.ByteBuf;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_746;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ContraptionStallPacket(int entityId, double x, double y, double z, float angle) implements ClientboundPacketPayload {
	public static final class_9139<ByteBuf, ContraptionStallPacket> STREAM_CODEC = class_9139.method_56906(
			class_9135.field_49675, ContraptionStallPacket::entityId,
			class_9135.field_48553, ContraptionStallPacket::x,
			class_9135.field_48553, ContraptionStallPacket::y,
			class_9135.field_48553, ContraptionStallPacket::z,
			class_9135.field_48552, ContraptionStallPacket::angle,
			ContraptionStallPacket::new
	);

	@Override
	@Environment(EnvType.CLIENT)
	public void handle(class_746 player) {
		AbstractContraptionEntity.handleStallPacket(this);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CONTRAPTION_STALL;
	}
}
