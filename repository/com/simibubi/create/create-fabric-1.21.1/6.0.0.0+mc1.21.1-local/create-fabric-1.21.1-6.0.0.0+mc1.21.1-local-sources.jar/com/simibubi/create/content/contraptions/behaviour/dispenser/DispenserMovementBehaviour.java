package com.simibubi.create.content.contraptions.behaviour.dispenser;

import com.simibubi.create.api.contraption.dispenser.DefaultMountedDispenseBehavior;
import com.simibubi.create.api.contraption.dispenser.MountedDispenseBehavior;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import net.minecraft.class_1799;
import net.minecraft.class_2338;

public class DispenserMovementBehaviour extends DropperMovementBehaviour {
	@Override
	protected MountedDispenseBehavior getDispenseBehavior(MovementContext context, class_2338 pos, class_1799 stack) {
		MountedDispenseBehavior behavior = MountedDispenseBehavior.REGISTRY.get(stack.method_7909());
		return behavior != null ? behavior : DefaultMountedDispenseBehavior.INSTANCE;
	}
}
