package com.simibubi.create.content.decoration.palettes;

import static com.simibubi.create.foundation.data.WindowGen.customWindowBlock;
import static com.simibubi.create.foundation.data.WindowGen.customWindowPane;
import static com.simibubi.create.foundation.data.WindowGen.framedGlass;
import static com.simibubi.create.foundation.data.WindowGen.framedGlassPane;
import static com.simibubi.create.foundation.data.WindowGen.woodenWindowBlock;
import static com.simibubi.create.foundation.data.WindowGen.woodenWindowPane;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllCreativeModeTabs;
import com.simibubi.create.AllSpriteShifts;
import com.simibubi.create.Create;
import com.simibubi.create.foundation.block.connected.HorizontalCTBehaviour;
import com.simibubi.create.foundation.block.connected.SimpleCTBehaviour;
import com.simibubi.create.foundation.data.BlockStateGen;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.simibubi.create.foundation.data.WindowGen;
import com.tterrag.registrate.util.DataIngredient;
import com.tterrag.registrate.util.entry.BlockEntry;
import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_3620;
import net.minecraft.class_4719;
import net.minecraft.class_7800;
import net.minecraft.class_8923;

public class AllPaletteBlocks {
	private static final CreateRegistrate REGISTRATE = Create.registrate();

	static {
		REGISTRATE.setCreativeTab(AllCreativeModeTabs.PALETTES_CREATIVE_TAB.key());
	}

	// Windows and Glass

	public static final BlockEntry<class_8923> TILED_GLASS = REGISTRATE.block("tiled_glass", class_8923::new)
		.initialProperties(() -> class_2246.field_10033)
		.addLayer(() -> class_1921::method_23581)
		.recipe((c, p) -> p.stonecutting(DataIngredient.tag(Tags.Items.GLASS_BLOCKS_COLORLESS), class_7800.field_40634, c))
		.blockstate((c, p) -> BlockStateGen.cubeAll(c, p, "palettes/"))
		.loot((t, g) -> t.method_46024(g))
		.tag(Tags.Blocks.GLASS_BLOCKS_COLORLESS, class_3481.field_15490)
		.item()
		.tag(Tags.Items.GLASS_BLOCKS_COLORLESS)
		.build()
		.register();

	public static final BlockEntry<ConnectedGlassBlock> FRAMED_GLASS =
		framedGlass("framed_glass", () -> new SimpleCTBehaviour(AllSpriteShifts.FRAMED_GLASS)),
		HORIZONTAL_FRAMED_GLASS = framedGlass("horizontal_framed_glass",
			() -> new HorizontalCTBehaviour(AllSpriteShifts.HORIZONTAL_FRAMED_GLASS, AllSpriteShifts.FRAMED_GLASS)),
		VERTICAL_FRAMED_GLASS = framedGlass("vertical_framed_glass",
			() -> new HorizontalCTBehaviour(AllSpriteShifts.VERTICAL_FRAMED_GLASS));

	public static final BlockEntry<GlassPaneBlock> TILED_GLASS_PANE =
		WindowGen.standardGlassPane("tiled_glass", TILED_GLASS, Create.asResource("block/palettes/tiled_glass"),
			class_2960.method_60656("block/glass_pane_top"), () -> class_1921::method_23579);

	public static final BlockEntry<ConnectedGlassPaneBlock> FRAMED_GLASS_PANE =
		framedGlassPane("framed_glass", FRAMED_GLASS, () -> AllSpriteShifts.FRAMED_GLASS),
		HORIZONTAL_FRAMED_GLASS_PANE = framedGlassPane("horizontal_framed_glass", HORIZONTAL_FRAMED_GLASS,
			() -> AllSpriteShifts.HORIZONTAL_FRAMED_GLASS),
		VERTICAL_FRAMED_GLASS_PANE = framedGlassPane("vertical_framed_glass", VERTICAL_FRAMED_GLASS,
			() -> AllSpriteShifts.VERTICAL_FRAMED_GLASS);

	public static final BlockEntry<WindowBlock> OAK_WINDOW = woodenWindowBlock(class_4719.field_21676, class_2246.field_10161),
		SPRUCE_WINDOW = woodenWindowBlock(class_4719.field_21677, class_2246.field_9975),
		BIRCH_WINDOW = woodenWindowBlock(class_4719.field_21678, class_2246.field_10148, () -> class_1921::method_23583, true),
		JUNGLE_WINDOW = woodenWindowBlock(class_4719.field_21680, class_2246.field_10334),
		ACACIA_WINDOW = woodenWindowBlock(class_4719.field_21679, class_2246.field_10218),
		DARK_OAK_WINDOW = woodenWindowBlock(class_4719.field_21681, class_2246.field_10075),
		MANGROVE_WINDOW = woodenWindowBlock(class_4719.field_37657, class_2246.field_37577),
		CRIMSON_WINDOW = woodenWindowBlock(class_4719.field_22183, class_2246.field_22126),
		WARPED_WINDOW = woodenWindowBlock(class_4719.field_22184, class_2246.field_22127),
		CHERRY_WINDOW = woodenWindowBlock(class_4719.field_42837, class_2246.field_42751),
		BAMBOO_WINDOW = woodenWindowBlock(class_4719.field_40350, class_2246.field_40294),
		ORNATE_IRON_WINDOW =
			customWindowBlock("ornate_iron_window", () -> class_1802.field_8675, () -> AllSpriteShifts.ORNATE_IRON_WINDOW,
				() -> class_1921::method_23581, false, () -> class_3620.field_15988),
		INDUSTRIAL_IRON_WINDOW = customWindowBlock("industrial_iron_window", AllBlocks.INDUSTRIAL_IRON_BLOCK,
			() -> AllSpriteShifts.INDUSTRIAL_IRON_WINDOW, () -> class_1921::method_23581, false, () -> class_3620.field_15978),
		WEATHERED_IRON_WINDOW = WindowGen
			.randomisedWindowBlock("weathered_iron_window", AllBlocks.WEATHERED_IRON_BLOCK,
				() -> class_1921::method_23583, true, () -> class_3620.field_15988)
			.onRegister(CreateRegistrate.connectedTextures(() -> new WeatheredIronWindowCTBehaviour()))
			.register();

	public static final BlockEntry<ConnectedGlassPaneBlock> OAK_WINDOW_PANE =
		woodenWindowPane(class_4719.field_21676, OAK_WINDOW),
		SPRUCE_WINDOW_PANE = woodenWindowPane(class_4719.field_21677, SPRUCE_WINDOW),
		BIRCH_WINDOW_PANE = woodenWindowPane(class_4719.field_21678, BIRCH_WINDOW, () -> class_1921::method_23583),
		JUNGLE_WINDOW_PANE = woodenWindowPane(class_4719.field_21680, JUNGLE_WINDOW),
		ACACIA_WINDOW_PANE = woodenWindowPane(class_4719.field_21679, ACACIA_WINDOW),
		DARK_OAK_WINDOW_PANE = woodenWindowPane(class_4719.field_21681, DARK_OAK_WINDOW),
		MANGROVE_WINDOW_PANE = woodenWindowPane(class_4719.field_37657, MANGROVE_WINDOW),
		CRIMSON_WINDOW_PANE = woodenWindowPane(class_4719.field_22183, CRIMSON_WINDOW),
		WARPED_WINDOW_PANE = woodenWindowPane(class_4719.field_22184, WARPED_WINDOW),
		CHERRY_WINDOW_PANE = woodenWindowPane(class_4719.field_42837, CHERRY_WINDOW),
		BAMBOO_WINDOW_PANE = woodenWindowPane(class_4719.field_40350, BAMBOO_WINDOW),
		ORNATE_IRON_WINDOW_PANE = customWindowPane("ornate_iron_window", ORNATE_IRON_WINDOW,
			() -> AllSpriteShifts.ORNATE_IRON_WINDOW, () -> class_1921::method_23579).register(),
		INDUSTRIAL_IRON_WINDOW_PANE = customWindowPane("industrial_iron_window", INDUSTRIAL_IRON_WINDOW,
			() -> AllSpriteShifts.INDUSTRIAL_IRON_WINDOW, () -> class_1921::method_23579).register(),
		WEATHERED_IRON_WINDOW_PANE =
			customWindowPane("weathered_iron_window", WEATHERED_IRON_WINDOW, null, () -> class_1921::method_23583)
				.onRegister(CreateRegistrate.connectedTextures(() -> new WeatheredIronWindowPaneCTBehaviour()))
				.register();

	static {
		AllPaletteStoneTypes.register(REGISTRATE);
	}

	public static void register() {
	}

}
