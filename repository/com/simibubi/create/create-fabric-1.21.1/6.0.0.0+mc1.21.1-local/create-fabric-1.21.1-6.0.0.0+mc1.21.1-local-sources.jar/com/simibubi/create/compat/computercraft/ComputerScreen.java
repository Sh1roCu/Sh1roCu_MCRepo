package com.simibubi.create.compat.computercraft;

import java.util.function.Supplier;

import javax.annotation.Nullable;

import com.simibubi.create.compat.Mods;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import com.simibubi.create.foundation.gui.AllIcons;
import com.simibubi.create.foundation.gui.widget.IconButton;
import com.simibubi.create.foundation.utility.CreateLang;

import net.createmod.catnip.gui.AbstractSimiScreen;
import net.createmod.catnip.gui.element.GuiGameElement;
import net.createmod.catnip.gui.widget.AbstractSimiWidget;
import net.createmod.catnip.gui.widget.ElementWidget;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class ComputerScreen extends AbstractSimiScreen {

	private final AllGuiTextures background = AllGuiTextures.COMPUTER;

	private final Supplier<class_2561> displayTitle;
	private final RenderWindowFunction additional;
	private final class_437 previousScreen;
	private final Supplier<Boolean> hasAttachedComputer;

	private AbstractSimiWidget computerWidget;
	private IconButton confirmButton;

	public ComputerScreen(class_2561 title, @Nullable RenderWindowFunction additional, class_437 previousScreen, Supplier<Boolean> hasAttachedComputer) {
		this(title, () -> title, additional, previousScreen, hasAttachedComputer);
	}

	public ComputerScreen(class_2561 title, Supplier<class_2561> displayTitle, @Nullable RenderWindowFunction additional, class_437 previousScreen, Supplier<Boolean> hasAttachedComputer) {
		super(title);
		this.displayTitle = displayTitle;
		this.additional = additional;
		this.previousScreen = previousScreen;
		this.hasAttachedComputer = hasAttachedComputer;
	}

	@Override
	public void method_25393() {
		if (!hasAttachedComputer.get())
			field_22787.method_1507(previousScreen);

		super.method_25393();
	}

	@Override
	protected void method_25426() {
		setWindowSize(background.getWidth(), background.getHeight());
		super.method_25426();

		int x = guiLeft;
		int y = guiTop;

		Mods.COMPUTERCRAFT.executeIfInstalled(() -> () -> {
			computerWidget = new ElementWidget(x + 33, y + 38)
					.showingElement(GuiGameElement.of(Mods.COMPUTERCRAFT.getBlock("computer_advanced")));
			computerWidget.getToolTip().add(CreateLang.translate("gui.attached_computer.hint").component());
			method_37063(computerWidget);
		});

		confirmButton = new IconButton(x + background.getWidth() - 33, y + background.getHeight() - 24, AllIcons.I_CONFIRM);
		confirmButton.withCallback(this::method_25419);
		method_37063(confirmButton);
	}



	@Override
	protected void renderWindow(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		int x = guiLeft;
		int y = guiTop;

		background.render(graphics, x, y);

		graphics.method_51439(field_22793, displayTitle.get(),
			Math.round(x + background.getWidth() / 2.0F - field_22793.method_27525(displayTitle.get()) / 2.0F), y + 4, 0x442000, false);
		graphics.method_51440(field_22793, CreateLang.translate("gui.attached_computer.controlled")
			.component(), x + 55, y + 32, 111, 0x7A7A7A);

		if (additional != null)
			additional.render(graphics, mouseX, mouseY, partialTicks, x, y, background);
	}

	@FunctionalInterface
	public interface RenderWindowFunction {

		void render(class_332 graphics, int mouseX, int mouseY, float partialTicks, int guiLeft, int guiTop, AllGuiTextures background);

	}

}
