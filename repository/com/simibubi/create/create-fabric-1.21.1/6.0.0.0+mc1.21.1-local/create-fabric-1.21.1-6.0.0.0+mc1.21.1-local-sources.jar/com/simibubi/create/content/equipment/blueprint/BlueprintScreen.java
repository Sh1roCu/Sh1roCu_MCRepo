package com.simibubi.create.content.equipment.blueprint;

import static com.simibubi.create.foundation.gui.AllGuiTextures.PLAYER_INVENTORY;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import com.google.common.collect.ImmutableList;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.logistics.filter.FilterScreenPacket;
import com.simibubi.create.content.logistics.filter.FilterScreenPacket.Option;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import com.simibubi.create.foundation.gui.AllIcons;
import com.simibubi.create.foundation.gui.menu.AbstractSimiContainerScreen;
import com.simibubi.create.foundation.gui.widget.IconButton;
import com.simibubi.create.foundation.utility.CreateLang;

import net.createmod.catnip.gui.element.GuiGameElement;
import net.createmod.catnip.platform.CatnipServices;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_768;
import io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor.PlayerAccessor;
import io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor.SlotAccessor;

public class BlueprintScreen extends AbstractSimiContainerScreen<BlueprintMenu> {

	protected AllGuiTextures background;
	private List<class_768> extraAreas = Collections.emptyList();

	private IconButton resetButton;
	private IconButton confirmButton;

	public BlueprintScreen(BlueprintMenu menu, class_1661 inv, class_2561 title) {
		super(menu, inv, title);
		this.background = AllGuiTextures.BLUEPRINT;
	}

	@Override
	protected void method_25426() {
		setWindowSize(background.getWidth(), background.getHeight() + 4 + PLAYER_INVENTORY.getHeight());
		setWindowOffset(1, 0);
		super.method_25426();

		int x = field_2776;
		int y = field_2800;

		resetButton = new IconButton(x + background.getWidth() - 62, y + background.getHeight() - 24, AllIcons.I_TRASH);
		resetButton.withCallback(() -> {
			field_2797.clearContents();
			contentsCleared();
			field_2797.sendClearPacket();
		});
		confirmButton = new IconButton(x + background.getWidth() - 33, y + background.getHeight() - 24, AllIcons.I_CONFIRM);
		confirmButton.withCallback(() -> {
			field_22787.field_1724.method_7346();
		});

		method_37063(resetButton);
		method_37063(confirmButton);

		extraAreas = ImmutableList.of(new class_768(x + background.getWidth(), y + background.getHeight() - 36, 56, 44));
	}

	@Override
	protected void method_2389(class_332 graphics, float partialTicks, int mouseX, int mouseY) {
		int invX = getLeftOfCentered(PLAYER_INVENTORY.getWidth());
		int invY = field_2800 + background.getHeight() + 4;
		renderPlayerInventory(graphics, invX, invY);

		int x = field_2776;
		int y = field_2800;

		background.render(graphics, x, y);
		graphics.method_51439(field_22793, field_22785, x + 15, y + 4, 0xFFFFFF, false);

		GuiGameElement.of(AllPartialModels.CRAFTING_BLUEPRINT_1x1).<GuiGameElement
			.GuiRenderBuilder>at(x + background.getWidth() + 20, y + background.getHeight() - 32, 0)
			.rotate(45, -45, 22.5f)
			.scale(40)
			.render(graphics);
	}

	@Override
	protected void method_2380(class_332 graphics, int x, int y) {
		if (!field_2797.method_34255()
			.method_7960() || this.field_2787 == null || field_2787.field_7871 == field_2797.playerInventory) {
			super.method_2380(graphics, x, y);
			return;
		}

		List<class_2561> list = new LinkedList<>();
		if (field_2787.method_7681())
			list = method_51454(field_2787.method_7677());

		graphics.method_51434(field_22793, addToTooltip(list, ((SlotAccessor) field_2787).port_lib$getSlotIndex(), true), x, y);
	}

	private List<class_2561> addToTooltip(List<class_2561> list, int slot, boolean isEmptySlot) {
		if (slot < 0 || slot > 10)
			return list;

		if (slot < 9) {
			list.add(CreateLang.translateDirect("crafting_blueprint.crafting_slot")
				.method_27692(class_124.field_1065));
			if (isEmptySlot)
				list.add(CreateLang.translateDirect("crafting_blueprint.filter_items_viable")
					.method_27692(class_124.field_1080));

		} else if (slot == 9) {
			list.add(CreateLang.translateDirect("crafting_blueprint.display_slot")
				.method_27692(class_124.field_1065));
			if (!isEmptySlot)
				list.add(CreateLang
					.translateDirect(
						"crafting_blueprint." + (field_2797.contentHolder.inferredIcon ? "inferred" : "manually_assigned"))
					.method_27692(class_124.field_1080));

		} else if (slot == 10) {
			list.add(CreateLang.translateDirect("crafting_blueprint.secondary_display_slot")
				.method_27692(class_124.field_1065));
			if (isEmptySlot)
				list.add(CreateLang.translateDirect("crafting_blueprint.optional")
					.method_27692(class_124.field_1080));
		}

		return list;
	}

	@Override
	protected void method_37432() {
		if (!field_2797.contentHolder.isEntityAlive())
			((PlayerAccessor) field_2797.player).port_lib$closeScreen();

		super.method_37432();

//		handleTooltips();
	}

//	protected void handleTooltips() {
//		List<IconButton> tooltipButtons = getTooltipButtons();
//
//		for (IconButton button : tooltipButtons) {
//			if (!button.getToolTip()
//				.isEmpty()) {
//				button.setToolTip(button.getToolTip()
//					.get(0));
//				button.getToolTip()
//					.add(TooltipHelper.holdShift(Palette.Yellow, hasShiftDown()));
//			}
//		}
//
//		if (hasShiftDown()) {
//			List<IFormattableTextComponent> tooltipDescriptions = getTooltipDescriptions();
//			for (int i = 0; i < tooltipButtons.size(); i++)
//				fillToolTip(tooltipButtons.get(i), tooltipDescriptions.get(i));
//		}
//	}

	protected void contentsCleared() {}

	protected void sendOptionUpdate(Option option) {
		CatnipServices.NETWORK.sendToServer(new FilterScreenPacket(option));
	}

	@Override
	public List<class_768> getExtraAreas() {
		return extraAreas;
	}

}
