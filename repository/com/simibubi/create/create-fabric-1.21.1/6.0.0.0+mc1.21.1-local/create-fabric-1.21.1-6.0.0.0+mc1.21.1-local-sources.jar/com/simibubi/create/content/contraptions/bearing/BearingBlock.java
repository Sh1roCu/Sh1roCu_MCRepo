package com.simibubi.create.content.contraptions.bearing;

import com.simibubi.create.content.kinetics.base.DirectionalKineticBlock;
import net.minecraft.class_1269;
import net.minecraft.class_1838;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_4538;

public abstract class BearingBlock extends DirectionalKineticBlock {

	public BearingBlock(class_2251 properties) {
		super(properties);
	}

	@Override
	public boolean hasShaftTowards(class_4538 world, class_2338 pos, class_2680 state, class_2350 face) {
		return face == state.method_11654(FACING).method_10153();
	}
	
	@Override
	public class_2351 getRotationAxis(class_2680 state) {
		return state.method_11654(FACING).method_10166();
	}

	@Override
	public boolean showCapacityWithAnnotation() {
		return true;
	}

	@Override
	public class_1269 onWrenched(class_2680 state, class_1838 context) {
		class_1269 resultType = super.onWrenched(state, context);
		if (!context.method_8045().field_9236 && resultType.method_23665()) {
			class_2586 be = context.method_8045().method_8321(context.method_8037());
			if (be instanceof MechanicalBearingBlockEntity) {
				((MechanicalBearingBlockEntity) be).disassemble();
			}
		}
		return resultType;
	}
}
