package com.simibubi.create.content.contraptions.pulley;

import com.simibubi.create.AllContraptionTypes;
import com.simibubi.create.api.contraption.ContraptionType;
import com.simibubi.create.content.contraptions.AssemblyException;
import com.simibubi.create.content.contraptions.TranslatingContraption;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_7225;

public class PulleyContraption extends TranslatingContraption {

	int initialOffset;

	@Override
	public ContraptionType getType() {
		return AllContraptionTypes.PULLEY.comp_349();
	}

	public PulleyContraption() {}

	public PulleyContraption(int initialOffset) {
		this.initialOffset = initialOffset;
	}

	@Override
	public boolean assemble(class_1937 world, class_2338 pos) throws AssemblyException {
		if (!searchMovedStructure(world, pos, null))
			return false;
		startMoving(world);
		return true;
	}

	@Override
	protected boolean isAnchoringBlockAt(class_2338 pos) {
		if (pos.method_10263() != anchor.method_10263() || pos.method_10260() != anchor.method_10260())
			return false;
		int y = pos.method_10264();
		if (y <= anchor.method_10264() || y > anchor.method_10264() + initialOffset + 1)
			return false;
		return true;
	}

	@Override
	public class_2487 writeNBT(class_7225.class_7874 registries, boolean spawnPacket) {
		class_2487 tag = super.writeNBT(registries, spawnPacket);
		tag.method_10569("InitialOffset", initialOffset);
		return tag;
	}

	@Override
	public void readNBT(class_1937 world, class_2487 nbt, boolean spawnData) {
		initialOffset = nbt.method_10550("InitialOffset");
		super.readNBT(world, nbt, spawnData);
	}

    public int getInitialOffset() {
		return initialOffset;
	}
}
