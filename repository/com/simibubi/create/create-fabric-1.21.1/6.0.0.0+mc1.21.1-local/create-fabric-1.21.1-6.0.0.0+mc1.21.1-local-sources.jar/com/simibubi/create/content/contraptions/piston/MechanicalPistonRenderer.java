package com.simibubi.create.content.contraptions.piston;

import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;
import net.minecraft.class_2680;
import net.minecraft.class_5614;

public class MechanicalPistonRenderer extends KineticBlockEntityRenderer<MechanicalPistonBlockEntity> {

	public MechanicalPistonRenderer(class_5614.class_5615 context) {
		super(context);
	}

	@Override
	protected class_2680 getRenderedBlockState(MechanicalPistonBlockEntity be) {
		return shaft(getRotationAxisOf(be));
	}

}
