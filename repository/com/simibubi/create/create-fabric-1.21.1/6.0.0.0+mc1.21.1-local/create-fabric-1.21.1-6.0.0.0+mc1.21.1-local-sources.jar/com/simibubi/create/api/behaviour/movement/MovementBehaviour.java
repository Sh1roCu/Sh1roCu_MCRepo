package com.simibubi.create.api.behaviour.movement;

import javax.annotation.Nullable;

import com.simibubi.create.api.registry.SimpleRegistry;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.contraptions.render.ActorVisual;
import com.simibubi.create.content.contraptions.render.ContraptionMatrices;
import com.simibubi.create.foundation.virtualWorld.VirtualRenderWorld;
import com.simibubi.create.infrastructure.config.AllConfigs;
import com.tterrag.registrate.util.nullness.NonNullConsumer;

import dev.engine_room.flywheel.api.visualization.VisualizationContext;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4597;
import com.simibubi.create.infrastructure.fabric.transfer.TransferUtil;

/**
 * MovementBehaviors, also known as Actors, provide behavior to blocks mounted on contraptions.
 * Blocks may be associated with a behavior through {@link #REGISTRY}.
 */
public interface MovementBehaviour {
	SimpleRegistry<class_2248, MovementBehaviour> REGISTRY = SimpleRegistry.create();

	/**
	 * Creates a consumer that will register a behavior to a block. Useful for Registrate.
	 */
	static <B extends class_2248> NonNullConsumer<? super B> movementBehaviour(MovementBehaviour behaviour) {
		return b -> REGISTRY.register(b, behaviour);
	}

	default boolean isActive(MovementContext context) {
		return !context.disabled;
	}

	default void tick(MovementContext context) {}

	default void startMoving(MovementContext context) {}

	default void visitNewPosition(MovementContext context, class_2338 pos) {}

	default class_243 getActiveAreaOffset(MovementContext context) {
		return class_243.field_1353;
	}

	@Nullable
	default class_1799 canBeDisabledVia(MovementContext context) {
		class_2248 block = context.state.method_26204();
		if (block == null)
			return null;
		return new class_1799(block);
	}

	default void onDisabledByControls(MovementContext context) {
		cancelStall(context);
	}

	default boolean mustTickWhileDisabled() {
		return false;
	}

	default void dropItem(MovementContext context, class_1799 stack) {
		class_1799 remainder;
		if (AllConfigs.server().kinetics.moveItemsToStorage.get()) {
			try (Transaction t = Transaction.openOuter()) {
				long inserted = context.contraption.getStorage().getAllItems().insert(ItemVariant.of(stack), stack.method_7947(), t);
				remainder = stack.method_7972();
				remainder.method_7934((int) inserted);
				t.commit();
			}
		}
		else
			remainder = stack;
		if (remainder.method_7960())
			return;

		// Actors might void items if their positions is undefined
		class_243 vec = context.position;
		if (vec == null)
			return;

		class_1542 itemEntity = new class_1542(context.world, vec.field_1352, vec.field_1351, vec.field_1350, remainder);
		itemEntity.method_18799(context.motion.method_1031(0, 0.5f, 0)
			.method_1021(context.world.field_9229.method_43057() * .3f));
		context.world.method_8649(itemEntity);
	}

	default void onSpeedChanged(MovementContext context, class_243 oldMotion, class_243 motion) {}

	default void stopMoving(MovementContext context) {}

	default void cancelStall(MovementContext context) {
		context.stall = false;
	}

	default void writeExtraData(MovementContext context) {}

	default boolean disableBlockEntityRendering() {
		return false;
	}

	@Environment(EnvType.CLIENT)
	default void renderInContraption(MovementContext context, VirtualRenderWorld renderWorld,
		ContraptionMatrices matrices, class_4597 buffer) {}

	@Environment(EnvType.CLIENT)
	@Nullable
	default ActorVisual createVisual(VisualizationContext visualizationContext, VirtualRenderWorld simulationWorld,
		MovementContext movementContext) {
		return null;
	}
}
