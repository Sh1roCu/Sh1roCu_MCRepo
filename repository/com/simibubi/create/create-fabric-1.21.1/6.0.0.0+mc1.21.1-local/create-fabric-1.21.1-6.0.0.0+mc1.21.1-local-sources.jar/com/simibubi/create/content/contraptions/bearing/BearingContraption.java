package com.simibubi.create.content.contraptions.bearing;

import org.apache.commons.lang3.tuple.Pair;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllContraptionTypes;
import com.simibubi.create.AllTags.AllBlockTags;
import com.simibubi.create.api.contraption.ContraptionType;
import com.simibubi.create.content.contraptions.AssemblyException;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.decoration.copycat.CopycatBlockEntity;
import com.simibubi.create.infrastructure.config.AllConfigs;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3499.class_3501;
import net.minecraft.class_7225;

public class BearingContraption extends Contraption {

	protected int sailBlocks;
	protected class_2350 facing;

	private boolean isWindmill;

	public BearingContraption() {}

	public BearingContraption(boolean isWindmill, class_2350 facing) {
		this.isWindmill = isWindmill;
		this.facing = facing;
	}

	@Override
	public boolean assemble(class_1937 world, class_2338 pos) throws AssemblyException {
		class_2338 offset = pos.method_10093(facing);
		if (!searchMovedStructure(world, offset, null))
			return false;
		startMoving(world);
		expandBoundsAroundAxis(facing.method_10166());
		if (isWindmill && sailBlocks < AllConfigs.server().kinetics.minimumWindmillSails.get())
			throw AssemblyException.notEnoughSails(sailBlocks);
		if (blocks.isEmpty())
			return false;
		return true;
	}

	@Override
	public ContraptionType getType() {
		return AllContraptionTypes.BEARING.comp_349();
	}

	@Override
	protected boolean isAnchoringBlockAt(class_2338 pos) {
		return pos.equals(anchor.method_10093(facing.method_10153()));
	}

	@Override
	public void addBlock(class_1937 level, class_2338 pos, Pair<class_3501, class_2586> capture) {
		class_2338 localPos = pos.method_10059(anchor);
		if (!getBlocks().containsKey(localPos) && AllBlockTags.WINDMILL_SAILS.matches(getSailBlock(capture)))
			sailBlocks++;
		super.addBlock(level, pos, capture);
	}

	private class_2680 getSailBlock(Pair<class_3501, class_2586> capture) {
		class_2680 state = capture.getKey().comp_1342();
		if (AllBlocks.COPYCAT_PANEL.has(state) && capture.getRight() instanceof CopycatBlockEntity cbe)
			return cbe.getMaterial();
		return state;
	}

	@Override
	public class_2487 writeNBT(class_7225.class_7874 registries, boolean spawnPacket) {
		class_2487 tag = super.writeNBT(registries, spawnPacket);
		tag.method_10569("Sails", sailBlocks);
		tag.method_10569("Facing", facing.method_10146());
		return tag;
	}

	@Override
	public void readNBT(class_1937 world, class_2487 tag, boolean spawnData) {
		sailBlocks = tag.method_10550("Sails");
		facing = class_2350.method_10143(tag.method_10550("Facing"));
		super.readNBT(world, tag, spawnData);
	}

	public int getSailBlocks() {
		return sailBlocks;
	}

	public class_2350 getFacing() {
		return facing;
	}

	@Override
	public boolean canBeStabilized(class_2350 facing, class_2338 localPos) {
		if (facing.method_10153() == this.facing && class_2338.field_10980.equals(localPos))
			return false;
		return facing.method_10166() == this.facing.method_10166();
	}

}
