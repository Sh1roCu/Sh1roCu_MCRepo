package com.simibubi.create.content.equipment.sandPaper;

import com.simibubi.create.AllDataComponents;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModel;
import com.simibubi.create.foundation.item.render.CustomRenderedItemModelRenderer;
import com.simibubi.create.foundation.item.render.PartialItemModelRenderer;

import net.createmod.catnip.animation.AnimationTickHolder;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_746;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_918;

public class SandPaperItemRenderer extends CustomRenderedItemModelRenderer {

	@Override
	protected void render(class_1799 stack, CustomRenderedItemModel model, PartialItemModelRenderer renderer,
		class_811 transformType, class_4587 ms, class_4597 buffer, int light, int overlay) {
		class_310 mc = class_310.method_1551();
		class_918 itemRenderer = mc.method_1480();
		class_746 player = mc.field_1724;
		class_1937 level = mc.field_1687;
		float partialTicks = AnimationTickHolder.getPartialTicks();

		boolean leftHand = transformType == class_811.field_4321;
		boolean firstPerson = leftHand || transformType == class_811.field_4322;

		boolean jeiMode = stack.method_57826(AllDataComponents.SAND_PAPER_JEI);

		ms.method_22903();

		if (stack.method_57826(AllDataComponents.SAND_PAPER_POLISHING)) {
			ms.method_22903();

			if (transformType == class_811.field_4317) {
				ms.method_46416(0.0F, .2f, 1.0F);
				ms.method_22905(.75f, .75f, .75f);
			} else {
				int modifier = leftHand ? -1 : 1;
				ms.method_22907(class_7833.field_40716.rotationDegrees(modifier * 40));
			}

			// Reverse bobbing
			float time = (float) (!jeiMode ? player.method_6014()
					: (-AnimationTickHolder.getTicks()) % stack.method_7935(player)) - partialTicks + 1.0F;
			if (time / (float) stack.method_7935(player) < 0.8F) {
				float bobbing = -class_3532.method_15379(class_3532.method_15362(time / 4.0F * (float) Math.PI) * 0.1F);

				if (transformType == class_811.field_4317)
					ms.method_46416(bobbing, bobbing, 0.0F);
				else
					ms.method_46416(0.0f, bobbing, 0.0F);
			}

			class_1799 toPolish = stack.method_57824(AllDataComponents.SAND_PAPER_POLISHING);
			//noinspection DataFlowIssue - We call .has, toPolish won't be null
			itemRenderer.method_23178(toPolish, class_811.field_4315, light, overlay, ms, buffer, player.method_37908(), 0);

			ms.method_22909();
		}

		if (firstPerson) {
			int itemInUseCount = player.method_6014();
			if (itemInUseCount > 0) {
				int modifier = leftHand ? -1 : 1;
				ms.method_46416(modifier * .5f, 0, -.25f);
				ms.method_22907(class_7833.field_40718.rotationDegrees(modifier * 40));
				ms.method_22907(class_7833.field_40714.rotationDegrees(modifier * 10));
				ms.method_22907(class_7833.field_40716.rotationDegrees(modifier * 90));
			}
		}

		itemRenderer.method_23179(stack, class_811.field_4315, false, ms, buffer, light, overlay, model.getOriginalModel());

		ms.method_22909();
	}

}
