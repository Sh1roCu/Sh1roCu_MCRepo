package com.simibubi.create.content.contraptions.gantry;

import java.util.HashMap;
import java.util.Map;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllEntityTypes;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.ContraptionCollider;
import com.simibubi.create.content.contraptions.StructureTransform;
import com.simibubi.create.content.kinetics.gantry.GantryShaftBlock;
import com.simibubi.create.content.kinetics.gantry.GantryShaftBlockEntity;
import com.simibubi.create.foundation.utility.ServerSpeedProvider;

import net.createmod.catnip.platform.CatnipServices;
import net.createmod.catnip.math.VecHelper;
import net.createmod.catnip.nbt.NBTHelper;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7225;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

public class GantryContraptionEntity extends AbstractContraptionEntity {
	private static final Map<Integer, GantryContraptionUpdatePacket> PENDING_UPDATES = new HashMap<>();

	class_2350 movementAxis;
	double clientOffsetDiff;
	double axisMotion;
	private boolean hasPendingCoord;
	private double pendingCoord;

	public double sequencedOffsetLimit;

	public GantryContraptionEntity(class_1299<?> entityTypeIn, class_1937 worldIn) {
		super(entityTypeIn, worldIn);
		sequencedOffsetLimit = -1;
	}

	public static GantryContraptionEntity create(class_1937 world, Contraption contraption, class_2350 movementAxis) {
		GantryContraptionEntity entity = new GantryContraptionEntity(AllEntityTypes.GANTRY_CONTRAPTION.get(), world);
		entity.setContraption(contraption);
		entity.movementAxis = movementAxis;
		return entity;
	}

	public void limitMovement(double maxOffset) {
		sequencedOffsetLimit = maxOffset;
	}

	@Override
	protected void tickContraption() {
		if (!(contraption instanceof GantryContraption))
			return;

		double prevAxisMotion = axisMotion;
		if (method_37908().field_9236) {
			consumePendingUpdate();
			clientOffsetDiff *= .75f;
			updateClientMotion();
		}

		checkPinionShaft();
		tickActors();
		class_243 movementVec = method_18798();

		if (ContraptionCollider.collideBlocks(this)) {
			if (!method_37908().field_9236)
				disassemble();
			return;
		}

		if (!isStalled() && field_6012 > 2) {
			if (sequencedOffsetLimit >= 0)
				movementVec = VecHelper.clampComponentWise(movementVec, (float) sequencedOffsetLimit);
			move(movementVec.field_1352, movementVec.field_1351, movementVec.field_1350);
			if (sequencedOffsetLimit > 0)
				sequencedOffsetLimit = Math.max(0, sequencedOffsetLimit - movementVec.method_1033());
		}

		if (Math.signum(prevAxisMotion) != Math.signum(axisMotion) && prevAxisMotion != 0)
			contraption.stop(method_37908());
		if (!method_37908().field_9236 && (prevAxisMotion != axisMotion || field_6012 % 3 == 0))
			sendPacket();
	}

	@Override
	public void disassemble() {
		sequencedOffsetLimit = -1;
		super.disassemble();
	}

	protected void checkPinionShaft() {
		class_243 movementVec;
		class_2350 facing = ((GantryContraption) contraption).getFacing();
		class_243 currentPosition = getAnchorVec().method_1031(.5, .5, .5);
		class_2338 gantryShaftPos = class_2338.method_49638(currentPosition).method_10093(facing.method_10153());

		class_2586 be = method_37908().method_8321(gantryShaftPos);
		if (!(be instanceof GantryShaftBlockEntity gantryShaftBlockEntity) || !AllBlocks.GANTRY_SHAFT.has(be.method_11010())) {
			if (!method_37908().field_9236) {
				setContraptionMotion(class_243.field_1353);
				disassemble();
			}
			return;
		}

		class_2680 blockState = be.method_11010();
		class_2350 direction = blockState.method_11654(GantryShaftBlock.FACING);

		float pinionMovementSpeed = gantryShaftBlockEntity.getPinionMovementSpeed();
		if (blockState.method_11654(GantryShaftBlock.POWERED) || pinionMovementSpeed == 0) {
			setContraptionMotion(class_243.field_1353);
			if (!method_37908().field_9236)
				disassemble();
			return;
		}

		if (sequencedOffsetLimit >= 0)
			pinionMovementSpeed = (float) class_3532.method_15350(pinionMovementSpeed, -sequencedOffsetLimit, sequencedOffsetLimit);
		movementVec = class_243.method_24954(direction.method_10163())
			.method_1021(pinionMovementSpeed);

		class_243 nextPosition = currentPosition.method_1019(movementVec);
		double currentCoord = direction.method_10166()
			.method_10172(currentPosition.field_1352, currentPosition.field_1351, currentPosition.field_1350);
		double nextCoord = direction.method_10166()
			.method_10172(nextPosition.field_1352, nextPosition.field_1351, nextPosition.field_1350);

		if ((class_3532.method_15357(currentCoord) + .5f < nextCoord != (pinionMovementSpeed * direction.method_10171()
			.method_10181() < 0)))
			if (!gantryShaftBlockEntity.canAssembleOn()) {
				setContraptionMotion(class_243.field_1353);
				if (!method_37908().field_9236)
					disassemble();
				return;
			}

		if (method_37908().field_9236)
			return;

		axisMotion = pinionMovementSpeed;
		setContraptionMotion(movementVec);
	}

	@Override
	protected void writeAdditional(class_2487 compound, class_7225.class_7874 registries, boolean spawnPacket) {
		NBTHelper.writeEnum(compound, "GantryAxis", movementAxis);
		if (sequencedOffsetLimit >= 0)
			compound.method_10549("SequencedOffsetLimit", sequencedOffsetLimit);
		super.writeAdditional(compound, registries, spawnPacket);
	}

	@Override
	protected void readAdditional(class_2487 compound, boolean spawnData) {
		movementAxis = NBTHelper.readEnum(compound, "GantryAxis", class_2350.class);
		sequencedOffsetLimit =
			compound.method_10545("SequencedOffsetLimit") ? compound.method_10574("SequencedOffsetLimit") : -1;
		super.readAdditional(compound, spawnData);

		if (hasPendingCoord && movementAxis != null) {
			clientOffsetDiff = pendingCoord - getAxisCoord();
			hasPendingCoord = false;
		}
		if (method_37908().field_9236) {
			consumePendingUpdate();
		}
	}

	@Override
	public class_243 applyRotation(class_243 localPos, float partialTicks) {
		return localPos;
	}

	@Override
	public class_243 reverseRotation(class_243 localPos, float partialTicks) {
		return localPos;
	}

	@Override
	protected StructureTransform makeStructureTransform() {
		return new StructureTransform(class_2338.method_49638(getAnchorVec().method_1031(.5, .5, .5)), 0, 0, 0);
	}

	@Override
	protected float getStalledAngle() {
		return 0;
	}

	@Override
	public void method_5859(double p_70634_1_, double p_70634_3_, double p_70634_5_) {
		if (method_37908().field_9236) {
			method_23327(p_70634_1_, p_70634_3_, p_70634_5_);
			clientOffsetDiff = 0;
			return;
		}
		super.method_5859(p_70634_1_, p_70634_3_, p_70634_5_);
	}

	@Override
	@Environment(EnvType.CLIENT)
	public void method_5759(double pX, double pY, double pZ, float pYRot, float pXRot, int pSteps) {
		if (movementAxis == null) {
			method_23327(pX, pY, pZ);
			return;
		}
		double trackedCoord = movementAxis.method_10166()
			.method_10172(pX, pY, pZ);
		clientOffsetDiff = trackedCoord - getAxisCoord();
	}

	@Override
	protected void handleStallInformation(double x, double y, double z, float angle) {
		method_23327(x, y, z);
		clientOffsetDiff = 0;
	}

	@Override
	public ContraptionRotationState getRotationState() {
		return ContraptionRotationState.NONE;
	}

	@Override
	@Environment(EnvType.CLIENT)
	public void applyLocalTransforms(class_4587 matrixStack, float partialTicks) {
	}

	public void updateClientMotion() {
		float modifier = movementAxis.method_10171()
			.method_10181();
		class_243 motion = class_243.method_24954(movementAxis.method_10163())
			.method_1021((axisMotion + clientOffsetDiff * modifier / 2f) * ServerSpeedProvider.get());
		if (sequencedOffsetLimit >= 0)
			motion = VecHelper.clampComponentWise(motion, (float) sequencedOffsetLimit);
		setContraptionMotion(motion);
	}

	public double getAxisCoord() {
		class_243 anchorVec = getAnchorVec();
		return movementAxis.method_10166()
			.method_10172(anchorVec.field_1352, anchorVec.field_1351, anchorVec.field_1350);
	}

	public void sendPacket() {
		CatnipServices.NETWORK.sendToClientsTrackingEntity(this,
				new GantryContraptionUpdatePacket(method_5628(), getAxisCoord(), axisMotion, sequencedOffsetLimit));
	}

	@Environment(EnvType.CLIENT)
	private void consumePendingUpdate() {
		GantryContraptionUpdatePacket pending = PENDING_UPDATES.remove(method_5628());
		if (pending != null)
			applyPacket(pending);
	}

	@Environment(EnvType.CLIENT)
	private void applyPacket(GantryContraptionUpdatePacket packet) {
		axisMotion = packet.motion();
		sequencedOffsetLimit = packet.sequenceLimit();
		if (movementAxis == null) {
			pendingCoord = packet.coord();
			hasPendingCoord = true;
			return;
		}
		clientOffsetDiff = packet.coord() - getAxisCoord();
	}

	@Environment(EnvType.CLIENT)
	public static void handlePacket(GantryContraptionUpdatePacket packet) {
		if (class_310.method_1551().field_1687 == null)
			return;
		class_1297 entity = class_310.method_1551().field_1687.method_8469(packet.entityID());
		if (!(entity instanceof GantryContraptionEntity ce)) {
			PENDING_UPDATES.put(packet.entityID(), packet);
			return;
		}
		ce.applyPacket(packet);
	}

}
