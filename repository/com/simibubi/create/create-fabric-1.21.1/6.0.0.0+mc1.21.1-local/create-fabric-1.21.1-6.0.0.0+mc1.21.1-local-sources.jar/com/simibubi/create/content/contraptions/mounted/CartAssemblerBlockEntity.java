package com.simibubi.create.content.contraptions.mounted;

import java.util.List;
import java.util.UUID;

import com.simibubi.create.AllAttachmentTypes;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.contraptions.AssemblyException;
import com.simibubi.create.content.contraptions.IDisplayAssemblyExceptions;
import com.simibubi.create.content.contraptions.OrientedContraptionEntity;
import com.simibubi.create.content.contraptions.minecart.CouplingHandler;
import com.simibubi.create.content.contraptions.minecart.capability.MinecartController;
import com.simibubi.create.content.redstone.rail.ControllerRailBlock;
import com.simibubi.create.foundation.advancement.AllAdvancements;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.CenteredSideValueBoxTransform;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueBoxTransform;
import com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.INamedIconOptions;
import com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.ScrollOptionBehaviour;
import com.simibubi.create.foundation.gui.AllIcons;
import com.simibubi.create.foundation.utility.CreateLang;

import net.createmod.catnip.data.Couple;
import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.lang.Lang;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1688;
import net.minecraft.class_1696;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2768;
import net.minecraft.class_3532;
import net.minecraft.class_7225;



public class CartAssemblerBlockEntity extends SmartBlockEntity implements IDisplayAssemblyExceptions {
	private static final int assemblyCooldown = 8;

	protected ScrollOptionBehaviour<CartMovementMode> movementMode;
	private int ticksSinceMinecartUpdate;
	protected AssemblyException lastException;
	protected class_1688 cartToAssemble;

	public CartAssemblerBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		ticksSinceMinecartUpdate = assemblyCooldown;
	}

	@Override
	public void tick() {
		super.tick();
		if (ticksSinceMinecartUpdate < assemblyCooldown) {
			ticksSinceMinecartUpdate++;
		}

		tryAssemble(cartToAssemble);
		cartToAssemble = null;
	}

	public void tryAssemble(class_1688 cart) {
		if (cart == null)
			return;

		if (!isMinecartUpdateValid())
			return;
		resetTicksSinceMinecartUpdate();

		class_2680 state = field_11863.method_8320(field_11867);
		if (!AllBlocks.CART_ASSEMBLER.has(state))
			return;
		CartAssemblerBlock block = (CartAssemblerBlock) state.method_26204();

		CartAssemblerBlock.CartAssemblerAction action = CartAssemblerBlock.getActionForCart(state, cart);
		if (action.shouldAssemble())
			assemble(field_11863, field_11867, cart);
		if (action.shouldDisassemble())
			disassemble(field_11863, field_11867, cart);
		if (action == CartAssemblerBlock.CartAssemblerAction.ASSEMBLE_ACCELERATE) {
			if (cart.method_18798()
				.method_1033() > 1 / 128f) {
				class_2350 facing = cart.method_5755();
				class_2768 railShape = state.method_11654(CartAssemblerBlock.RAIL_SHAPE);
				for (class_2350 d : Iterate.directionsInAxis(railShape == class_2768.field_12674 ? class_2351.field_11048 : class_2351.field_11051))
					if (field_11863.method_8320(field_11867.method_10093(d))
						.method_26212(field_11863, field_11867.method_10093(d)))
						facing = d.method_10153();

				float speed = 0.4f;//block.getRailMaxSpeed(state, level, worldPosition, cart);
				cart.method_18800(facing.method_10148() * speed, facing.method_10164() * speed, facing.method_10165() * speed);
			}
		}
		if (action == CartAssemblerBlock.CartAssemblerAction.ASSEMBLE_ACCELERATE_DIRECTIONAL) {
			class_2382 accelerationVector =
				ControllerRailBlock.getAccelerationVector(AllBlocks.CONTROLLER_RAIL.getDefaultState()
					.method_11657(ControllerRailBlock.SHAPE, state.method_11654(CartAssemblerBlock.RAIL_SHAPE))
					.method_11657(ControllerRailBlock.BACKWARDS, state.method_11654(CartAssemblerBlock.BACKWARDS)));
			float speed = 0.4f;//block.getRailMaxSpeed(state, level, worldPosition, cart);
			cart.method_18799(class_243.method_24954(accelerationVector)
				.method_1021(speed));
		}
		if (action == CartAssemblerBlock.CartAssemblerAction.DISASSEMBLE_BRAKE) {
			class_243 diff = VecHelper.getCenterOf(field_11867)
				.method_1020(cart.method_19538());
			cart.method_18800(diff.field_1352 / 16f, 0, diff.field_1350 / 16f);
		}
	}

	protected void assemble(class_1937 world, class_2338 pos, class_1688 cart) {
		if (!cart.method_5685().isEmpty())
			return;

		if (cart.create$getController()
			.isCoupledThroughContraption())
			return;

		CartMovementMode mode = CartMovementMode.values()[movementMode.value];

		MountedContraption contraption = new MountedContraption(mode);
		try {
			if (!contraption.assemble(world, pos))
				return;

			lastException = null;
			sendData();
		} catch (AssemblyException e) {
			lastException = e;
			sendData();
			return;
		}

		boolean couplingFound = contraption.connectedCart != null;
		class_2350 initialOrientation = CartAssemblerBlock.getHorizontalDirection(method_11010());

		if (couplingFound) {
			cart.method_5814(pos.method_10263() + .5f, pos.method_10264(), pos.method_10260() + .5f);
			if (!CouplingHandler.tryToCoupleCarts(null, world, cart.method_5628(),
				contraption.connectedCart.method_5628()))
				return;
		}

		contraption.removeBlocksFromWorld(world, class_2338.field_10980);
		contraption.startMoving(world);
		contraption.expandBoundsAroundAxis(class_2351.field_11052);

		if (couplingFound) {
			class_243 diff = contraption.connectedCart.method_19538()
				.method_1020(cart.method_19538());
			initialOrientation = class_2350.method_10150(class_3532.method_15349(diff.field_1350, diff.field_1352) * 180 / Math.PI);
		}

		OrientedContraptionEntity entity = OrientedContraptionEntity.create(world, contraption, initialOrientation);
		if (couplingFound)
			entity.setCouplingId(cart.method_5667());
		entity.method_5814(pos.method_10263() + .5, pos.method_10264(), pos.method_10260() + .5);
		world.method_8649(entity);
		entity.method_5804(cart);

		if (cart instanceof class_1696) {
			class_2487 nbt = new class_2487();
			if (cart.method_5662(nbt)) {
				nbt.method_10549("PushZ", 0);
				nbt.method_10549("PushX", 0);
				cart.method_5651(nbt);
			}
		}

		if (contraption.containsBlockBreakers())
			award(AllAdvancements.CONTRAPTION_ACTORS);
	}

	protected void disassemble(class_1937 world, class_2338 pos, class_1688 cart) {
		if (cart.method_5685()
			.isEmpty())
			return;
		class_1297 entity = cart.method_5685()
			.get(0);
		if (!(entity instanceof OrientedContraptionEntity contraption))
			return;
		UUID couplingId = contraption.getCouplingId();

		if (couplingId == null) {
			contraption.yaw = CartAssemblerBlock.getHorizontalDirection(method_11010())
				.method_10144();
			disassembleCart(cart);
			return;
		}

		Couple<MinecartController> coupledCarts = contraption.getCoupledCartsIfPresent();
		if (coupledCarts == null)
			return;

		// Make sure connected cart is present and being disassembled
		for (boolean current : Iterate.trueAndFalse) {
			MinecartController minecartController = coupledCarts.get(current);
			if (minecartController.cart() == cart)
				continue;
			class_2338 otherPos = minecartController.cart()
				.method_24515();
			class_2680 blockState = world.method_8320(otherPos);
			if (!AllBlocks.CART_ASSEMBLER.has(blockState))
				return;
			if (!CartAssemblerBlock.getActionForCart(blockState, minecartController.cart())
				.shouldDisassemble())
				return;
		}

		for (boolean current : Iterate.trueAndFalse)
			coupledCarts.get(current)
				.removeConnection(current);
		disassembleCart(cart);
	}

	protected void disassembleCart(class_1688 cart) {
		cart.method_5772();
		if (cart instanceof class_1696) {
			class_2487 nbt = new class_2487();
			cart.method_5786(nbt);
			nbt.method_10549("PushZ", cart.method_18798().field_1352);
			nbt.method_10549("PushX", cart.method_18798().field_1350);
			cart.method_5651(nbt);
		}
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
		movementMode = new ScrollOptionBehaviour<>(CartMovementMode.class,
			CreateLang.translateDirect("contraptions.cart_movement_mode"), this, getMovementModeSlot());
		behaviours.add(movementMode);
		registerAwardables(behaviours, AllAdvancements.CONTRAPTION_ACTORS);
	}

	@Override
	public void write(class_2487 compound, class_7225.class_7874 registries, boolean clientPacket) {
		AssemblyException.write(compound, registries, lastException);
		super.write(compound, registries, clientPacket);
	}

	@Override
	protected void read(class_2487 compound, class_7225.class_7874 registries, boolean clientPacket) {
		lastException = AssemblyException.read(compound, registries);
		super.read(compound, registries, clientPacket);
	}

	@Override
	public AssemblyException getLastAssemblyException() {
		return lastException;
	}

	protected ValueBoxTransform getMovementModeSlot() {
		return new CartAssemblerValueBoxTransform();
	}

	private class CartAssemblerValueBoxTransform extends CenteredSideValueBoxTransform {

		public CartAssemblerValueBoxTransform() {
			super((state, d) -> {
				if (d.method_10166()
					.method_10178())
					return false;
				if (!state.method_28498(CartAssemblerBlock.RAIL_SHAPE))
					return false;
				class_2768 railShape = state.method_11654(CartAssemblerBlock.RAIL_SHAPE);
				return (d.method_10166() == class_2351.field_11048) == (railShape == class_2768.field_12665);
			});
		}

		@Override
		protected class_243 getSouthLocation() {
			return VecHelper.voxelSpace(8, 7, 17.5);
		}

	}

	public enum CartMovementMode implements INamedIconOptions {

		ROTATE(AllIcons.I_CART_ROTATE),
		ROTATE_PAUSED(AllIcons.I_CART_ROTATE_PAUSED),
		ROTATION_LOCKED(AllIcons.I_CART_ROTATE_LOCKED),

		;

		private String translationKey;
		private AllIcons icon;

		CartMovementMode(AllIcons icon) {
			this.icon = icon;
			translationKey = "contraptions.cart_movement_mode." + Lang.asId(name());
		}

		@Override
		public AllIcons getIcon() {
			return icon;
		}

		@Override
		public String getTranslationKey() {
			return translationKey;
		}
	}

	public void resetTicksSinceMinecartUpdate() {
		ticksSinceMinecartUpdate = 0;
	}

	public void assembleNextTick(class_1688 cart) {
		if (cartToAssemble == null)
			cartToAssemble = cart;
	}

	public boolean isMinecartUpdateValid() {
		return ticksSinceMinecartUpdate >= assemblyCooldown;
	}

}
