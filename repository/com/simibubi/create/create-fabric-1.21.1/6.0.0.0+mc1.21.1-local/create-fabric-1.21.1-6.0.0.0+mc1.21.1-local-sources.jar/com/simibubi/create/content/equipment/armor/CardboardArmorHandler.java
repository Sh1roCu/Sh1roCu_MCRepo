package com.simibubi.create.content.equipment.armor;

import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1405;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_4135;
import net.minecraft.class_5354;
import com.simibubi.create.AllItems;
import com.simibubi.create.foundation.advancement.AllAdvancements;
import io.github.fabricators_of_create.porting_lib.entity.events.EntityEvents;
import io.github.fabricators_of_create.porting_lib.entity.events.LivingEntityEvents;

public class CardboardArmorHandler {

	public static void playerHitboxChangesWhenHidingAsBox(EntityEvents.Size event) {
		class_1297 entity = event.getEntity();
		if (!entity.method_5805())
			return;
		if (!testForStealth(entity))
			return;

		event.setNewSize(class_4048.method_18385(0.6F, 0.8F).method_55685(0.6F));

		if (!entity.method_37908()
			.method_8608() && entity instanceof class_1657 p)
			AllAdvancements.CARDBOARD_ARMOR.awardTo(p);
	}

	public static void playersStealthWhenWearingCardboard(class_1309 entity) {
		// Visibility event hook is temporarily disabled on this port path.
	}

	public static void mobsMayLoseTargetWhenItIsWearingCardboard(class_1309 entity) {
		if (entity.field_6012 % 16 != 0)
			return;
		if (!(entity instanceof class_1308 mob))
			return;

		if (testForStealth(mob.method_5968())) {
			mob.method_5980(null);
			if (mob.field_6185 != null)
				for (class_4135 goal : mob.field_6185.method_35115()) {
					if (goal.method_19056() && goal.method_19058() instanceof class_1405 tg)
						tg.method_6270();
				}
		}

		if (entity instanceof class_5354 nMob && entity.method_37908() instanceof class_3218 sl) {
			UUID uuid = nMob.method_29508();
			if (uuid != null && testForStealth(sl.method_14190(uuid)))
				nMob.method_29922();
		}

		if (testForStealth(mob.method_6065())) {
			mob.method_6015(null);
			mob.method_29505(null);
		}
	}

	public static boolean testForStealth(class_1297 entityIn) {
		if (!(entityIn instanceof class_1309 entity))
			return false;
		if (entity.method_18376() != class_4050.field_18081)
			return false;
		if (entity instanceof class_1657 player && player.method_31549().field_7479)
			return false;
		if (!AllItems.CARDBOARD_HELMET.isIn(entity.method_6118(class_1304.field_6169)))
			return false;
		if (!AllItems.CARDBOARD_CHESTPLATE.isIn(entity.method_6118(class_1304.field_6174)))
			return false;
		if (!AllItems.CARDBOARD_LEGGINGS.isIn(entity.method_6118(class_1304.field_6172)))
			return false;
		if (!AllItems.CARDBOARD_BOOTS.isIn(entity.method_6118(class_1304.field_6166)))
			return false;
		return true;
	}

}
