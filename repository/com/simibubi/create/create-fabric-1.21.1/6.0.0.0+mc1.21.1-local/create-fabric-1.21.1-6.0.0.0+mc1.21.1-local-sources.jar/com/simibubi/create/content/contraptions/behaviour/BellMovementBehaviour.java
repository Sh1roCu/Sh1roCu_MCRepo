package com.simibubi.create.content.contraptions.behaviour;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.elevator.ElevatorContraption;
import com.simibubi.create.content.equipment.bell.AbstractBellBlock;
import com.simibubi.create.content.redstone.deskBell.DeskBellBlock;
import com.simibubi.create.content.trains.entity.CarriageContraption;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class BellMovementBehaviour implements MovementBehaviour {

	@Override
	public boolean isActive(MovementContext context) {
		return MovementBehaviour.super.isActive(context) && !(context.contraption instanceof CarriageContraption);
	}

	@Override
	public void tick(MovementContext context) {
		boolean moved = context.temporaryData instanceof Boolean b && b.booleanValue();
		Contraption contraption = context.contraption;

		if (contraption instanceof ElevatorContraption ec && !ec.arrived)
			context.temporaryData = Boolean.valueOf(true);
		else if (moved) {
			playSound(context);
			context.temporaryData = null;
		}
	}

	@Override
	public void onSpeedChanged(MovementContext context, class_243 oldMotion, class_243 motion) {
		if (context.contraption instanceof ElevatorContraption)
			return;

		double dotProduct = oldMotion.method_1026(motion);
		if (dotProduct <= 0 && (context.relativeMotion.method_1033() != 0) || context.firstMovement)
			playSound(context);
	}

	@Override
	public void stopMoving(MovementContext context) {
		if (context.position != null && isActive(context))
			playSound(context);
	}

	public static void playSound(MovementContext context) {
		class_1937 world = context.world;
		class_2338 pos = class_2338.method_49638(context.position);
		class_2248 block = context.state.method_26204();

		if (AllBlocks.DESK_BELL.has(context.state)) {
			((DeskBellBlock) block).playSound(null, world, pos);
		} else if (block instanceof AbstractBellBlock) {
			((AbstractBellBlock<?>) block).playSound(world, pos);
		} else {
			// Vanilla bell sound
			world.method_8396(null, pos, class_3417.field_17265, class_3419.field_15245, 2f, 1f);
		}
	}

}
