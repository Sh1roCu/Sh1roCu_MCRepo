package com.simibubi.create;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_2382;
import net.minecraft.class_2405;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_6880;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7923;

public class AllSoundEvents {

	public static final Map<class_2960, SoundEntry> ALL = new HashMap<>();

	public static final SoundEntry
		SCHEMATICANNON_LAUNCH_BLOCK = create("schematicannon_launch_block").subtitle("Schematicannon fires")
			.playExisting(class_3417.field_15152.comp_349(), .1f, 1.1f)
			.category(class_3419.field_15245)
			.build(),

		SCHEMATICANNON_FINISH = create("schematicannon_finish").subtitle("Schematicannon dings")
			.playExisting(class_3417.field_14793::comp_349, 1, .7f)
			.category(class_3419.field_15245)
			.build(),

		DEPOT_SLIDE = create("depot_slide").subtitle("Item slides")
			.playExisting(class_3417.field_15074, .125f, 1.5f)
			.category(class_3419.field_15245)
			.build(),

		DEPOT_PLOP = create("depot_plop").subtitle("Item lands")
			.playExisting(class_3417.field_14667, .25f, 1.25f)
			.category(class_3419.field_15245)
			.build(),

		FUNNEL_FLAP = create("funnel_flap").subtitle("Funnel flaps")
			.playExisting(class_3417.field_15038, .125f, 1.5f)
			.playExisting(class_3417.field_14983, .0425f, .75f)
			.category(class_3419.field_15245)
			.build(),

		PACKAGER = create("packager").subtitle("Packager packages")
			.playExisting(class_3417.field_15017, 0.5f, 0.75f)
			.category(class_3419.field_15245)
			.build(),

		SLIME_ADDED = create("slime_added").subtitle("Slime squishes")
			.playExisting(class_3417.field_14788)
			.category(class_3419.field_15245)
			.build(),

		MECHANICAL_PRESS_ACTIVATION = create("mechanical_press_activation").subtitle("Mechanical Press clangs")
			.playExisting(class_3417.field_14833, .125f, 1f)
			.playExisting(class_3417.field_15075, .5f, 1f)
			.category(class_3419.field_15245)
			.build(),

		MECHANICAL_PRESS_ACTIVATION_ON_BELT =
			create("mechanical_press_activation_belt").subtitle("Mechanical Press bonks")
				.playExisting(class_3417.field_14628, .75f, 1f)
				.playExisting(class_3417.field_15075, .15f, .75f)
				.category(class_3419.field_15245)
				.build(),

		MIXING = create("mixing").subtitle("Mixing noises")
			.playExisting(class_3417.field_24066, .125f, .5f)
			.playExisting(class_3417.field_21924, .125f, .5f)
			.category(class_3419.field_15245)
			.build(),

		SPOUTING = create("spout").subtitle("Spout spurts")
			.addVariant("spout_1")
			.addVariant("spout_2")
			.addVariant("spout_3")
			.category(class_3419.field_15245)
			.build(),

		CRANKING = create("cranking").subtitle("Hand Crank turns")
			.playExisting(class_3417.field_14718, .075f, .5f)
			.playExisting(class_3417.field_15105, .025f, .5f)
			.category(class_3419.field_15245)
			.build(),

		WORLDSHAPER_PLACE = create("worldshaper_place").subtitle("Worldshaper zaps")
			.playExisting(class_3417.field_15047)
			.category(class_3419.field_15248)
			.build(),

		SCROLL_VALUE = create("scroll_value").subtitle("Scroll-input clicks")
			.playExisting(class_3417.field_15204::comp_349, .124f, 1f)
			.category(class_3419.field_15248)
			.build(),

		CONFIRM = create("confirm").subtitle("Affirmative ding")
			.playExisting(class_3417.field_14793::comp_349, 0.5f, 0.8f)
			.category(class_3419.field_15248)
			.build(),

		CONFIRM_2 = create("confirm_2").subtitle("Affirmative ding")
			.category(class_3419.field_15248)
			.build(),

		DENY = create("deny").subtitle("Declining boop")
			.playExisting(class_3417.field_14624::comp_349, 1f, 0.5f)
			.category(class_3419.field_15248)
			.build(),

		COGS = create("cogs").subtitle("Cogwheels rumble")
			.category(class_3419.field_15245)
			.build(),

		FWOOMP = create("fwoomp").subtitle("Resonant fwoomp")
			.category(class_3419.field_15248)
			.build(),

		CARDBOARD_SWORD = create("cardboard_bonk").subtitle("Resonant bonk")
			.category(class_3419.field_15248)
			.build(),

		FROGPORT_OPEN = create("frogport_open").subtitle("Frogport opens")
			.playExisting(class_3417.field_38078, 1f, 2f)
			.category(class_3419.field_15245)
			.build(),

		FROGPORT_CLOSE = create("frogport_close").subtitle("Frogport shuts")
			.category(class_3419.field_15245)
			.build(),

		FROGPORT_CATCH = create("frogport_catch").subtitle("Frogport catches package")
			.addVariant("frogport_catch_1")
			.addVariant("frogport_catch_2")
			.addVariant("frogport_catch_3")
			.category(class_3419.field_15245)
			.build(),

		STOCK_LINK = create("stock_link").subtitle("Stock link reacts")
			.category(class_3419.field_15245)
			.build(),

		FROGPORT_DEPOSIT = create("frogport_deposit").subtitle("Frogport places package")
			.playExisting(class_3417.field_37320, 1f, 1f)
			.category(class_3419.field_15245)
			.build(),

		POTATO_HIT = create("potato_hit").subtitle("Vegetable impacts")
			.playExisting(class_3417.field_14585, .75f, .75f)
			.playExisting(class_3417.field_21909, .75f, 1.25f)
			.category(class_3419.field_15248)
			.build(),

		CONTRAPTION_ASSEMBLE = create("contraption_assemble").subtitle("Contraption moves")
			.playExisting(class_3417.field_14932, .5f, .5f)
			.playExisting(class_3417.field_14982, .045f, .74f)
			.category(class_3419.field_15245)
			.build(),

		CONTRAPTION_DISASSEMBLE = create("contraption_disassemble").subtitle("Contraption stops")
			.playExisting(class_3417.field_15131, .35f, .75f)
			.category(class_3419.field_15245)
			.build(),

		WRENCH_ROTATE = create("wrench_rotate").subtitle("Wrench used")
			.playExisting(class_3417.field_15080, .25f, 1.25f)
			.category(class_3419.field_15245)
			.build(),

		WRENCH_REMOVE = create("wrench_remove").subtitle("Component breaks")
			.playExisting(class_3417.field_15197, .25f, .75f)
			.playExisting(class_3417.field_21922, .25f, .75f)
			.category(class_3419.field_15245)
			.build(),

		PACKAGE_POP = create("package_pop").subtitle("Package breaks")
			.playExisting(class_3417.field_40967, .75f, 1f)
			.playExisting(class_3417.field_14983, .25f, 1.15f)
			.category(class_3419.field_15245)
			.build(),

		CRAFTER_CLICK = create("crafter_click").subtitle("Crafter clicks")
			.playExisting(class_3417.field_21922, .25f, 1)
			.playExisting(class_3417.field_14932, .125f, 1)
			.category(class_3419.field_15245)
			.build(),

		CRAFTER_CRAFT = create("crafter_craft").subtitle("Crafter crafts")
			.playExisting(class_3417.field_15075, .125f, .75f)
			.category(class_3419.field_15245)
			.build(),

		COPPER_ARMOR_EQUIP = create("copper_armor_equip").subtitle("Diving equipment clinks")
			.playExisting(class_3417.field_14761.comp_349(), 1f, 1f)
			.category(class_3419.field_15248)
			.build(),

		SANDING_SHORT = create("sanding_short").subtitle("Sanding noises")
			.addVariant("sanding_short_1")
			.category(class_3419.field_15245)
			.build(),

		SANDING_LONG = create("sanding_long").subtitle("Sanding noises")
			.category(class_3419.field_15245)
			.build(),

		CONTROLLER_CLICK = create("controller_click").subtitle("Controller clicks")
			.playExisting(class_3417.field_14667, .35f, 1f)
			.category(class_3419.field_15245)
			.build(),

		CONTROLLER_PUT = create("controller_put").subtitle("Controller thumps")
			.playExisting(class_3417.field_17482, 1f, 1f)
			.category(class_3419.field_15245)
			.build(),

		CONTROLLER_TAKE = create("controller_take").subtitle("Lectern empties")
			.playExisting(class_3417.field_14770, 1f, 1f)
			.category(class_3419.field_15245)
			.build(),

		SAW_ACTIVATE_WOOD = create("saw_activate_wood").subtitle("Mechanical Saw activates")
			.playExisting(class_3417.field_14886, .75f, 1.5f)
			.category(class_3419.field_15245)
			.build(),

		SAW_ACTIVATE_STONE = create("saw_activate_stone").subtitle("Mechanical Saw activates")
			.playExisting(class_3417.field_17710, .125f, 1.25f)
			.category(class_3419.field_15245)
			.build(),

		BLAZE_MUNCH = create("blaze_munch").subtitle("Blaze Burner munches")
			.playExisting(class_3417.field_20614, .5f, 1f)
			.category(class_3419.field_15245)
			.build(),

		ITEM_HATCH = create("item_hatch").subtitle("Item Hatch opens")
			.playExisting(class_3417.field_17604, .25f, 1.4f)
			.playExisting(class_3417.field_21921, .75f, 1.15f)
			.category(class_3419.field_15245)
			.build(),

		CRUSHING_1 = create("crushing_1").subtitle("Crushing noises")
			.playExisting(class_3417.field_21927)
			.category(class_3419.field_15245)
			.build(),

		CRUSHING_2 = create("crushing_2").noSubtitle()
			.playExisting(class_3417.field_14609)
			.category(class_3419.field_15245)
			.build(),

		CRUSHING_3 = create("crushing_3").noSubtitle()
			.playExisting(class_3417.field_21919)
			.category(class_3419.field_15245)
			.build(),

		PECULIAR_BELL_USE = create("peculiar_bell_use").subtitle("Peculiar Bell tolls")
			.playExisting(class_3417.field_17265)
			.category(class_3419.field_15245)
			.build(),

		DESK_BELL_USE = create("desk_bell").subtitle("Reception bell dings")
			.category(class_3419.field_15245)
			.attenuationDistance(64)
			.build(),

		WHISTLE_HIGH = create("whistle_high").subtitle("High whistling")
			.category(class_3419.field_15247)
			.attenuationDistance(64)
			.build(),

		WHISTLE_MEDIUM = create("whistle").subtitle("Whistling")
			.category(class_3419.field_15247)
			.attenuationDistance(64)
			.build(),

		WHISTLE_LOW = create("whistle_low").subtitle("Low whistling")
			.category(class_3419.field_15247)
			.attenuationDistance(64)
			.build(),

		STEAM = create("steam").subtitle("Steam noises")
			.category(class_3419.field_15254)
			.attenuationDistance(32)
			.build(),

		TRAIN = create("train").subtitle("Bogey wheels rumble")
			.category(class_3419.field_15254)
			.attenuationDistance(128)
			.build(),

		TRAIN2 = create("train2").noSubtitle()
			.category(class_3419.field_15254)
			.attenuationDistance(128)
			.build(),

		TRAIN3 = create("train3").subtitle("Bogey wheels rumble muffled")
			.category(class_3419.field_15254)
			.attenuationDistance(16)
			.build(),

		WHISTLE_TRAIN = create("whistle_train").subtitle("Whistling")
			.category(class_3419.field_15247)
			.build(),

		WHISTLE_TRAIN_LOW = create("whistle_train_low").subtitle("Low whistling")
			.category(class_3419.field_15247)
			.build(),

		WHISTLE_TRAIN_MANUAL = create("whistle_train_manual").subtitle("Train honks")
			.category(class_3419.field_15254)
			.attenuationDistance(64)
			.build(),

		WHISTLE_TRAIN_MANUAL_LOW = create("whistle_train_manual_low").subtitle("Train honks")
			.category(class_3419.field_15254)
			.attenuationDistance(64)
			.build(),

		WHISTLE_TRAIN_MANUAL_END = create("whistle_train_manual_end").noSubtitle()
			.category(class_3419.field_15254)
			.attenuationDistance(64)
			.build(),

		WHISTLE_TRAIN_MANUAL_LOW_END = create("whistle_train_manual_low_end").noSubtitle()
			.category(class_3419.field_15254)
			.attenuationDistance(64)
			.build(),

		WHISTLE_CHIFF = create("chiff").noSubtitle()
			.category(class_3419.field_15247)
			.build(),

		HAUNTED_BELL_CONVERT = create("haunted_bell_convert").subtitle("Haunted Bell awakens")
			.category(class_3419.field_15245)
			.build(),

		HAUNTED_BELL_USE = create("haunted_bell_use").subtitle("Haunted Bell tolls")
			.category(class_3419.field_15245)
			.build(),

		STOCK_TICKER_REQUEST = create("stock_ticker_request").subtitle("Stock ticker requests")
			.category(class_3419.field_15245)
			.build(),

		STOCK_TICKER_TRADE = create("stock_ticker_trade").subtitle("Stock ticker goes 'ka-ching!'")
			.category(class_3419.field_15245)
			.build(),

		CLIPBOARD_CHECKMARK = create("clipboard_check").noSubtitle()
			.category(class_3419.field_15245)
			.build(),

		CLIPBOARD_ERASE = create("clipboard_erase").noSubtitle()
			.category(class_3419.field_15245)
			.build();

	private static SoundEntryBuilder create(String name) {
		return create(Create.asResource(name));
	}

	public static SoundEntryBuilder create(class_2960 id) {
		return new SoundEntryBuilder(id);
	}

	public static void prepare() {
		for (SoundEntry entry : ALL.values())
			entry.prepare();
	}

	public static void register() {
		for (SoundEntry entry : ALL.values())
			entry.register();
	}

	public static void provideLang(BiConsumer<String, String> consumer) {
		for (SoundEntry entry : ALL.values())
			if (entry.hasSubtitle())
				consumer.accept(entry.getSubtitleKey(), entry.getSubtitle());
	}

	public static class_2405 provider(FabricDataOutput output) {
		return new SoundEntryProvider(output);
	}

	public static void playItemPickup(class_1657 player) {
		player.method_37908()
			.method_8396(null, player.method_24515(), class_3417.field_15197, class_3419.field_15248, .2f,
				1f + player.method_37908().field_9229.method_43057());
	}

//	@SubscribeEvent
//	public static void cancelSubtitlesOfCompoundedSounds(PlaySoundEvent event) {
//		ResourceLocation soundLocation = event.getSound().getSoundLocation();
//		if (!soundLocation.getNamespace().equals(Create.ID))
//			return;
//		if (soundLocation.getPath().contains("_compounded_")
//			event.setResultSound();
//
//	}

	public static class SoundEntryProvider implements class_2405 {

		private class_7784 output;

		public SoundEntryProvider(class_7784 output) {
			this.output = output;
		}

		@Override
		public CompletableFuture<?> method_10319(class_7403 cache) {
			return generate(output.method_45971(), cache);
		}

		@Override
		public String method_10321() {
			return "Create's Custom Sounds";
		}

		public CompletableFuture<?> generate(Path path, class_7403 cache) {
			path = path.resolve("assets/create");
			JsonObject json = new JsonObject();
			ALL.entrySet()
				.stream()
				.sorted(Map.Entry.comparingByKey())
				.forEach(entry -> {
					entry.getValue()
						.write(json);
				});
			return class_2405.method_10320(cache, json, path.resolve("sounds.json"));
		}

	}

	public record ConfiguredSoundEvent(Supplier<class_3414> event, float volume, float pitch) {}

	public static class SoundEntryBuilder {

		protected class_2960 id;
		protected String subtitle = "unregistered";
		protected class_3419 category = class_3419.field_15245;
		protected List<ConfiguredSoundEvent> wrappedEvents;
		protected List<class_2960> variants;
		protected int attenuationDistance;

		public SoundEntryBuilder(class_2960 id) {
			wrappedEvents = new ArrayList<>();
			variants = new ArrayList<>();
			this.id = id;
		}

		public SoundEntryBuilder subtitle(String subtitle) {
			this.subtitle = subtitle;
			return this;
		}

		public SoundEntryBuilder attenuationDistance(int distance) {
			this.attenuationDistance = distance;
			return this;
		}

		public SoundEntryBuilder noSubtitle() {
			this.subtitle = null;
			return this;
		}

		public SoundEntryBuilder category(class_3419 category) {
			this.category = category;
			return this;
		}

		public SoundEntryBuilder addVariant(String name) {
			return addVariant(Create.asResource(name));
		}

		public SoundEntryBuilder addVariant(class_2960 id) {
			variants.add(id);
			return this;
		}

		public SoundEntryBuilder playExisting(Supplier<class_3414> event, float volume, float pitch) {
			wrappedEvents.add(new ConfiguredSoundEvent(event, volume, pitch));
			return this;
		}

		// fabric: holders are not suppliers
		public SoundEntryBuilder playExisting(class_6880<class_3414> event, float volume, float pitch) {
			return playExisting(event::comp_349, volume, pitch);
		}

		public SoundEntryBuilder playExisting(class_3414 event, float volume, float pitch) {
			return playExisting(() -> event, volume, pitch);
		}

		public SoundEntryBuilder playExisting(class_3414 event) {
			return playExisting(event, 1, 1);
		}

		public SoundEntryBuilder playExisting(class_6880<class_3414> event) {
			return playExisting(event::comp_349, 1, 1);
		}

		public SoundEntry build() {
			SoundEntry entry =
				wrappedEvents.isEmpty() ? new CustomSoundEntry(id, variants, subtitle, category, attenuationDistance)
					: new WrappedSoundEntry(id, subtitle, wrappedEvents, category, attenuationDistance);
			ALL.put(entry.getId(), entry);
			return entry;
		}

	}

	public static abstract class SoundEntry {

		protected class_2960 id;
		protected String subtitle;
		protected class_3419 category;
		protected int attenuationDistance;

		public SoundEntry(class_2960 id, String subtitle, class_3419 category, int attenuationDistance) {
			this.id = id;
			this.subtitle = subtitle;
			this.category = category;
			this.attenuationDistance = attenuationDistance;
		}

		public abstract void prepare();

		public abstract void register();

		public abstract void write(JsonObject json);

		public abstract class_6880<class_3414> getMainEventHolder();

		public abstract class_3414 getMainEvent();

		public String getSubtitleKey() {
			return id.method_12836() + ".subtitle." + id.method_12832();
		}

		public class_2960 getId() {
			return id;
		}

		public boolean hasSubtitle() {
			return subtitle != null;
		}

		public String getSubtitle() {
			return subtitle;
		}

		public void playOnServer(class_1937 world, class_2382 pos) {
			playOnServer(world, pos, 1, 1);
		}

		public void playOnServer(class_1937 world, class_2382 pos, float volume, float pitch) {
			play(world, null, pos, volume, pitch);
		}

		public void play(class_1937 world, class_1657 entity, class_2382 pos) {
			play(world, entity, pos, 1, 1);
		}

		public void playFrom(class_1297 entity) {
			playFrom(entity, 1, 1);
		}

		public void playFrom(class_1297 entity, float volume, float pitch) {
			if (!entity.method_5701())
				play(entity.method_37908(), null, entity.method_24515(), volume, pitch);
		}

		public void play(class_1937 world, class_1657 entity, class_2382 pos, float volume, float pitch) {
			play(world, entity, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, volume, pitch);
		}

		public void play(class_1937 world, class_1657 entity, class_243 pos, float volume, float pitch) {
			play(world, entity, pos.method_10216(), pos.method_10214(), pos.method_10215(), volume, pitch);
		}

		public abstract void play(class_1937 world, class_1657 entity, double x, double y, double z, float volume, float pitch);

		public void playAt(class_1937 world, class_2382 pos, float volume, float pitch, boolean fade) {
			playAt(world, pos.method_10263() + .5, pos.method_10264() + .5, pos.method_10260() + .5, volume, pitch, fade);
		}

		public void playAt(class_1937 world, class_243 pos, float volume, float pitch, boolean fade) {
			playAt(world, pos.method_10216(), pos.method_10214(), pos.method_10215(), volume, pitch, fade);
		}

		public abstract void playAt(class_1937 world, double x, double y, double z, float volume, float pitch, boolean fade);

	}

	private static class WrappedSoundEntry extends SoundEntry {

		private List<ConfiguredSoundEvent> wrappedEvents;
		private List<CompiledSoundEvent> compiledEvents;

		public WrappedSoundEntry(class_2960 id, String subtitle,
			List<ConfiguredSoundEvent> wrappedEvents, class_3419 category, int attenuationDistance) {
			super(id, subtitle, category, attenuationDistance);
			this.wrappedEvents = wrappedEvents;
			compiledEvents = new ArrayList<>();
		}

		@Override
		public void prepare() {
			for (int i = 0; i < wrappedEvents.size(); i++) {
				ConfiguredSoundEvent wrapped = wrappedEvents.get(i);
				class_2960 location = getIdOf(i);
				class_3414 event = class_3414.method_47908(location);
				compiledEvents.add(new CompiledSoundEvent(event, wrapped.volume(), wrapped.pitch()));
			}
		}

		@Override
		public void register() {
			for (CompiledSoundEvent event : compiledEvents) {
				class_2378.method_10230(class_7923.field_41172, event.event.method_14833(), event.event);
			}
		}

		@Override
		public class_6880<class_3414> getMainEventHolder() {
			return class_6880.method_40223(compiledEvents.getFirst().event());
		}

		@Override
		public class_3414 getMainEvent() {
			return compiledEvents.getFirst().event();
		}

		protected class_2960 getIdOf(int i) {
			return class_2960.method_60655(id.method_12836(), i == 0 ? id.method_12832() : id.method_12832() + "_compounded_" + i);
		}

		@Override
		public void write(JsonObject json) {
			for (int i = 0; i < wrappedEvents.size(); i++) {
				ConfiguredSoundEvent event = wrappedEvents.get(i);
				JsonObject entry = new JsonObject();
				JsonArray list = new JsonArray();
				JsonObject s = new JsonObject();
				s.addProperty("name", event.event()
					.get()
					.method_14833()
					.toString());
				s.addProperty("type", "event");
				if (attenuationDistance != 0)
					s.addProperty("attenuation_distance", attenuationDistance);
				list.add(s);
				entry.add("sounds", list);
				if (i == 0 && hasSubtitle())
					entry.addProperty("subtitle", getSubtitleKey());
				json.add(getIdOf(i).method_12832(), entry);
			}
		}

		@Override
		public void play(class_1937 world, class_1657 entity, double x, double y, double z, float volume, float pitch) {
			for (CompiledSoundEvent event : compiledEvents) {
				world.method_43128(entity, x, y, z, event.event(), category, event.volume() * volume,
					event.pitch() * pitch);
			}
		}

		@Override
		public void playAt(class_1937 world, double x, double y, double z, float volume, float pitch, boolean fade) {
			for (CompiledSoundEvent event : compiledEvents) {
				world.method_8486(x, y, z, event.event(), category, event.volume() * volume,
					event.pitch() * pitch, fade);
			}
		}

		private record CompiledSoundEvent(class_3414 event, float volume, float pitch) {
		}

	}

	private static class CustomSoundEntry extends SoundEntry {

		protected List<class_2960> variants;
		protected class_3414 event;

		public CustomSoundEntry(class_2960 id, List<class_2960> variants, String subtitle,
			class_3419 category, int attenuationDistance) {
			super(id, subtitle, category, attenuationDistance);
			this.variants = variants;
		}

		@Override
		public void prepare() {
			 event = class_3414.method_47908(id);
		}

		@Override
		public void register() {
			class_2378.method_10230(class_7923.field_41172, event.method_14833(), event);
		}

		@Override
		public class_6880<class_3414> getMainEventHolder() {
			return class_6880.method_40223(event);
		}

		@Override
		public class_3414 getMainEvent() {
			return event;
		}

		@Override
		public void write(JsonObject json) {
			JsonObject entry = new JsonObject();
			JsonArray list = new JsonArray();

			JsonObject s = new JsonObject();
			s.addProperty("name", id.toString());
			s.addProperty("type", "file");
			if (attenuationDistance != 0)
				s.addProperty("attenuation_distance", attenuationDistance);
			list.add(s);

			for (class_2960 variant : variants) {
				s = new JsonObject();
				s.addProperty("name", variant.toString());
				s.addProperty("type", "file");
				if (attenuationDistance != 0)
					s.addProperty("attenuation_distance", attenuationDistance);
				list.add(s);
			}

			entry.add("sounds", list);
			if (hasSubtitle())
				entry.addProperty("subtitle", getSubtitleKey());
			json.add(id.method_12832(), entry);
		}

		@Override
		public void play(class_1937 world, class_1657 entity, double x, double y, double z, float volume, float pitch) {
			world.method_43128(entity, x, y, z, event, category, volume, pitch);
		}

		@Override
		public void playAt(class_1937 world, double x, double y, double z, float volume, float pitch, boolean fade) {
			world.method_8486(x, y, z, event, category, volume, pitch, fade);
		}

	}

}
