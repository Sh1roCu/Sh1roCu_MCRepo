package com.simibubi.create.content.contraptions;

import com.simibubi.create.foundation.utility.CreateLang;
import com.simibubi.create.infrastructure.config.AllConfigs;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

public class AssemblyException extends Exception {

	private static final long serialVersionUID = 1L;
	public final class_2561 component;
	private class_2338 position = null;

	public static void write(class_2487 compound, class_7225.class_7874 registries, AssemblyException exception) {
		if (exception == null)
			return;

		class_2487 nbt = new class_2487();
		nbt.method_10582("Component", class_2561.class_2562.method_10867(exception.component, registries));
		if (exception.hasPosition())
			nbt.method_10544("Position", exception.getPosition()
				.method_10063());

		compound.method_10566("LastException", nbt);
	}

	public static AssemblyException read(class_2487 compound, class_7225.class_7874 registries) {
		if (!compound.method_10545("LastException"))
			return null;

		class_2487 nbt = compound.method_10562("LastException");
		String string = nbt.method_10558("Component");
		AssemblyException exception = new AssemblyException(class_2561.class_2562.method_10877(string, registries));
		if (nbt.method_10545("Position"))
			exception.position = class_2338.method_10092(nbt.method_10537("Position"));

		return exception;
	}

	public AssemblyException(class_2561 component) {
		this.component = component;
	}

	public AssemblyException(String langKey, Object... objects) {
		this(CreateLang.translateDirect("gui.assembly.exception." + langKey, objects));
	}

	public static AssemblyException unmovableBlock(class_2338 pos, class_2680 state) {
		AssemblyException e = new AssemblyException("unmovableBlock", pos.method_10263(), pos.method_10264(), pos.method_10260(),
			state.method_26204().method_9518());
		e.position = pos;
		return e;
	}

	public static AssemblyException unloadedChunk(class_2338 pos) {
		AssemblyException e = new AssemblyException("chunkNotLoaded", pos.method_10263(), pos.method_10264(), pos.method_10260());
		e.position = pos;
		return e;
	}

	public static AssemblyException structureTooLarge() {
		return new AssemblyException("structureTooLarge", AllConfigs.server().kinetics.maxBlocksMoved.get());
	}

	public static AssemblyException tooManyPistonPoles() {
		return new AssemblyException("tooManyPistonPoles", AllConfigs.server().kinetics.maxPistonPoles.get());
	}

	public static AssemblyException noPistonPoles() {
		return new AssemblyException("noPistonPoles");
	}

	public static AssemblyException notEnoughSails(int sails) {
		return new AssemblyException("not_enough_sails", sails, AllConfigs.server().kinetics.minimumWindmillSails.get());
	}

	public boolean hasPosition() {
		return position != null;
	}

	public class_2338 getPosition() {
		return position;
	}
}
