package com.simibubi.create.content.equipment.armor;

import org.jetbrains.annotations.NotNull;

import com.simibubi.create.AllTags.AllItemTags;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_9334;

public final class NetheriteDivingHandler {
	public static final String NETHERITE_DIVING_BITS_KEY = "CreateNetheriteDivingBits";
	public static final String FIRE_IMMUNE_KEY = "CreateFireImmune";

	public static void onLivingEquipmentChange(class_1309 entity, class_1304 slot, @NotNull class_1799 from, @NotNull class_1799 to) {
		if (slot.method_5925() != class_1304.class_1305.field_6178) {
			return;
		}

		if (slot == class_1304.field_6169) {
			if (isNetheriteDivingHelmet(to)) {
				setBit(entity, slot);
			} else {
				clearBit(entity, slot);
			}
		} else if (slot == class_1304.field_6174) {
			if (isNetheriteBacktank(to) && BacktankUtil.hasAirRemaining(to)) {
				setBit(entity, slot);
			} else {
				clearBit(entity, slot);
			}
		} else if (slot == class_1304.field_6172 || slot == class_1304.field_6166) {
			if (isNetheriteArmor(to)) {
				setBit(entity, slot);
			} else {
				clearBit(entity, slot);
			}
		}
	}

	public static boolean isNetheriteDivingHelmet(class_1799 stack) {
		return stack.method_7909() instanceof DivingHelmetItem && isNetheriteArmor(stack);
	}

	public static boolean isNetheriteBacktank(class_1799 stack) {
		return stack.method_31573(AllItemTags.PRESSURIZED_AIR_SOURCES.tag) && isNetheriteArmor(stack);
	}

	public static boolean isNetheriteArmor(class_1799 stack) {
		return stack.method_7909() instanceof class_1738 && stack.method_57826(class_9334.field_50076);
	}

	public static void setBit(class_1309 entity, class_1304 slot) {
		class_2487 nbt = entity.getCustomData();
		byte bits = nbt.method_10571(NETHERITE_DIVING_BITS_KEY);
		if ((bits & 0b1111) == 0b1111) {
			return;
		}

		bits |= 1 << slot.method_5927();
		nbt.method_10567(NETHERITE_DIVING_BITS_KEY, bits);

		if ((bits & 0b1111) == 0b1111) {
			setFireImmune(entity, true);
		}
	}

	public static void clearBit(class_1309 entity, class_1304 slot) {
		class_2487 nbt = entity.getCustomData();
		if (!nbt.method_10545(NETHERITE_DIVING_BITS_KEY)) {
			return;
		}

		byte bits = nbt.method_10571(NETHERITE_DIVING_BITS_KEY);
		boolean prevFullSet = (bits & 0b1111) == 0b1111;
		bits &= ~(1 << slot.method_5927());
		nbt.method_10567(NETHERITE_DIVING_BITS_KEY, bits);

		if (prevFullSet) {
			setFireImmune(entity, false);
		}
	}

	// TODO: sync to the client
	// The feature works without syncing because health and burning are calculated server-side and synced through vanilla code.
	// This method will not be called when the entity is wearing a full diving set on creation because the NBT values are persistent.
	public static void setFireImmune(class_1309 entity, boolean fireImmune) {
		entity.getCustomData().method_10556(FIRE_IMMUNE_KEY, fireImmune);
	}
}
