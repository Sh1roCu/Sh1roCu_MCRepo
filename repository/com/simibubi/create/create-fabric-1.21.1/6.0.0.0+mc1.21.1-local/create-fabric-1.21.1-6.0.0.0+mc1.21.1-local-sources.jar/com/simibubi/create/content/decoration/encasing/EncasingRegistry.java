package com.simibubi.create.content.decoration.encasing;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_2248;
import net.minecraft.class_7924;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.util.nullness.NonNullUnaryOperator;

public class EncasingRegistry {
	private static final Map<class_2248, List<class_2248>> ENCASED_VARIANTS = new HashMap<>();

	/**
	 * <strong>This method must not be called before block registration is finished.</strong>
	 */
	public static <B extends class_2248 & EncasableBlock, E extends class_2248 & EncasedBlock, P> void addVariant(B encasable, E encased) {
		ENCASED_VARIANTS.computeIfAbsent(encasable, b -> new ArrayList<>()).add(encased);
	}

	public static List<class_2248> getVariants(class_2248 block) {
		return ENCASED_VARIANTS.getOrDefault(block, Collections.emptyList());
	}

	public static <B extends class_2248 & EncasedBlock, P, E extends class_2248 & EncasableBlock> NonNullUnaryOperator<BlockBuilder<B, P>> addVariantTo(Supplier<E> encasable) {
		return builder -> {
			builder.onRegisterAfter(class_7924.field_41254, b -> addVariant(encasable.get(), b));
			return builder;
		};
	}
}
