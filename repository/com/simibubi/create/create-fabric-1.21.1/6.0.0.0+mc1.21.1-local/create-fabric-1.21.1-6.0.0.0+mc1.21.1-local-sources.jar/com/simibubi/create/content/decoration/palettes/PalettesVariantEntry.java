package com.simibubi.create.content.decoration.palettes;

import static com.simibubi.create.foundation.data.CreateRegistrate.connectedTextures;
import static com.simibubi.create.foundation.data.TagGen.pickaxeOnly;

import com.google.common.collect.ImmutableList;
import com.simibubi.create.Create;
import com.simibubi.create.foundation.data.CreateRegistrate;
import com.tterrag.registrate.builders.BlockBuilder;
import com.tterrag.registrate.builders.ItemBuilder;
import com.tterrag.registrate.providers.ProviderType;
import com.tterrag.registrate.util.DataIngredient;
import com.tterrag.registrate.util.entry.BlockEntry;
import com.tterrag.registrate.util.nullness.NonNullSupplier;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_6862;
import net.minecraft.class_7800;

public class PalettesVariantEntry {
	private static final CreateRegistrate REGISTRATE = Create.registrate();

	public final ImmutableList<BlockEntry<? extends class_2248>> registeredBlocks;
	public final ImmutableList<BlockEntry<? extends class_2248>> registeredPartials;

	public PalettesVariantEntry(String name, AllPaletteStoneTypes paletteStoneVariants) {
		ImmutableList.Builder<BlockEntry<? extends class_2248>> registeredBlocks = ImmutableList.builder();
		ImmutableList.Builder<BlockEntry<? extends class_2248>> registeredPartials = ImmutableList.builder();
		NonNullSupplier<class_2248> baseBlock = paletteStoneVariants.baseBlock;

		for (PaletteBlockPattern pattern : paletteStoneVariants.variantTypes) {
			BlockBuilder<? extends class_2248, CreateRegistrate> builder =
				REGISTRATE.block(pattern.createName(name), pattern.getBlockFactory())
					.initialProperties(baseBlock)
					.transform(pickaxeOnly())
					.blockstate(pattern.getBlockStateGenerator()
						.apply(pattern)
						.apply(name)::accept);

			ItemBuilder<class_1747, ? extends BlockBuilder<? extends class_2248, CreateRegistrate>> itemBuilder =
				builder.item();

			class_6862<class_2248>[] blockTags = pattern.getBlockTags();
			if (blockTags != null)
				builder.tag(blockTags);
			class_6862<class_1792>[] itemTags = pattern.getItemTags();
			if (itemTags != null)
				itemBuilder.tag(itemTags);

			itemBuilder.tag(paletteStoneVariants.materialTag);

			if (pattern.isTranslucent())
				builder.addLayer(() -> class_1921::method_23583);
			pattern.createCTBehaviour(name)
				.ifPresent(b -> builder.onRegister(connectedTextures(b)));

			builder.recipe((c, p) -> {
				p.stonecutting(DataIngredient.tag(paletteStoneVariants.materialTag), class_7800.field_40634, c);
				pattern.addRecipes(baseBlock, c, p);
			});

			itemBuilder.register();
			BlockEntry<? extends class_2248> block = builder.register();
			registeredBlocks.add(block);

			for (PaletteBlockPartial<? extends class_2248> partialBlock : pattern.getPartials())
				registeredPartials.add(partialBlock.create(name, pattern, block, paletteStoneVariants)
					.register());
		}

		REGISTRATE.addDataGenerator(ProviderType.RECIPE,
			p -> p.stonecutting(DataIngredient.tag(paletteStoneVariants.materialTag), class_7800.field_40634,
				baseBlock));
		REGISTRATE.addDataGenerator(ProviderType.ITEM_TAGS, p -> p.addTag(paletteStoneVariants.materialTag)
			.add(baseBlock.get()
				.method_8389()));

		this.registeredBlocks = registeredBlocks.build();
		this.registeredPartials = registeredPartials.build();
	}

}
