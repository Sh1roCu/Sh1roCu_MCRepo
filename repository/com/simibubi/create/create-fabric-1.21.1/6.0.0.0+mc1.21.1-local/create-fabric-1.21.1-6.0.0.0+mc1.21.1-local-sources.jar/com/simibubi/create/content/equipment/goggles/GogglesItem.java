package com.simibubi.create.content.equipment.goggles;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_5151;
import com.simibubi.create.AllItems;

public class GogglesItem extends class_1792 implements class_5151 {

	private static final List<Predicate<class_1657>> IS_WEARING_PREDICATES = new ArrayList<>();
	static {
		addIsWearingPredicate(player -> AllItems.GOGGLES.isIn(player.method_6118(class_1304.field_6169)));
	}

	public GogglesItem(class_1793 properties) {
		super(properties);
		class_2315.method_10009(this, class_1738.field_7879);
	}

	// Set in properties
	public static class_1304 getEquipmentSlot(class_1799 stack) {
		return class_1304.field_6169;
	}

	@Override
	public class_1304 method_7685() {
		return class_1304.field_6169;
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 worldIn, class_1657 playerIn, class_1268 handIn) {
		return this.method_48576(this, worldIn, playerIn, handIn);
	}

	public static boolean isWearingGoggles(class_1657 player) {
		for (Predicate<class_1657> predicate : IS_WEARING_PREDICATES) {
			if (predicate.test(player)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Use this method to add custom entry points to the goggles overlay, e.g. custom
	 * armor, handheld alternatives, etc.
	 */
	public static void addIsWearingPredicate(Predicate<class_1657> predicate) {
		IS_WEARING_PREDICATES.add(predicate);
	}

}
