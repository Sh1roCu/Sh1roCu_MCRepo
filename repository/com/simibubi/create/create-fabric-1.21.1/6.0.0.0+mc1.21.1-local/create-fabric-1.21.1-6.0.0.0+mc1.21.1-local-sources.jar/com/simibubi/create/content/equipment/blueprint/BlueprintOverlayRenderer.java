package com.simibubi.create.content.equipment.blueprint;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.mojang.blaze3d.systems.RenderSystem;
import com.simibubi.create.AllDataComponents;
import com.simibubi.create.AllItems;
import com.simibubi.create.content.equipment.blueprint.BlueprintEntity.BlueprintSection;
import com.simibubi.create.content.logistics.BigItemStack;
import com.simibubi.create.content.logistics.filter.AttributeFilterWhitelistMode;
import com.simibubi.create.content.logistics.filter.FilterItem;
import com.simibubi.create.content.logistics.filter.FilterItemStack;
import com.simibubi.create.content.logistics.item.filter.attribute.ItemAttribute;
import com.simibubi.create.content.logistics.item.filter.attribute.attributes.InTagAttribute;
import com.simibubi.create.content.logistics.packager.InventorySummary;
import com.simibubi.create.content.logistics.tableCloth.BlueprintOverlayShopContext;
import com.simibubi.create.content.logistics.tableCloth.ShoppingListItem.ShoppingList;
import com.simibubi.create.content.logistics.tableCloth.TableClothBlockEntity;
import com.simibubi.create.content.trains.track.TrackPlacement.PlacementInfo;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import com.simibubi.create.foundation.item.ItemHelper;

import net.createmod.catnip.animation.AnimationTickHolder;
import net.createmod.catnip.data.Couple;
import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.data.Pair;
import net.createmod.catnip.gui.element.GuiGameElement;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.item.PlayerInventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageUtil;
import net.fabricmc.fabric.api.transfer.v1.storage.base.ResourceAmount;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1792.class_9635;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1934;
import net.minecraft.class_239;
import net.minecraft.class_239.class_240;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_3966;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_8002;
import net.minecraft.class_8786;
import net.minecraft.class_9080;
import net.minecraft.class_9694;
import net.minecraft.class_9779;
import com.simibubi.create.infrastructure.fabric.transfer.TransferUtil;
import com.simibubi.create.infrastructure.fabric.transfer.item.ItemStackHandler;

public class BlueprintOverlayRenderer {

	public static final class_9080.class_9081 OVERLAY = BlueprintOverlayRenderer::renderOverlay;

	static boolean active;
	static boolean empty;
	static boolean noOutput;
	static boolean lastSneakState;
	static BlueprintSection lastTargetedSection;
	static BlueprintOverlayShopContext shopContext;

	static Map<class_1799, class_1799[]> cachedRenderedFilters = new IdentityHashMap<>();
	static List<Pair<class_1799, Boolean>> ingredients = new ArrayList<>();
	static List<class_1799> results = new ArrayList<>();
	static boolean resultCraftable = false;

	public static void tick() {
		class_310 mc = class_310.method_1551();

		BlueprintSection last = lastTargetedSection;
		lastTargetedSection = null;
		active = false;
		noOutput = false;
		shopContext = null;

		if (mc.field_1761.method_2920() == class_1934.field_9219)
			return;

		class_239 mouseOver = mc.field_1765;
		if (mouseOver == null)
			return;
		if (mouseOver.method_17783() != class_240.field_1331)
			return;

		class_3966 entityRay = (class_3966) mouseOver;
		if (!(entityRay.method_17782() instanceof BlueprintEntity blueprintEntity))
			return;

		BlueprintSection sectionAt = blueprintEntity.getSectionAt(entityRay.method_17784()
			.method_1020(blueprintEntity.method_19538()));

		lastTargetedSection = last;
		active = true;

		boolean sneak = mc.field_1724.method_5715();
		if (sectionAt != lastTargetedSection || AnimationTickHolder.getTicks() % 10 == 0 || lastSneakState != sneak)
			rebuild(sectionAt, sneak);

		lastTargetedSection = sectionAt;
		lastSneakState = sneak;
	}

	public static void displayTrackRequirements(PlacementInfo info, class_1799 pavementItem) {
		if (active)
			return;
		prepareCustomOverlay();

		int tracks = info.requiredTracks;
		while (tracks > 0) {
			ingredients.add(
				Pair.of(new class_1799(info.trackMaterial.getBlock(), Math.min(64, tracks)), info.hasRequiredTracks));
			tracks -= 64;
		}

		int pavement = info.requiredPavement;
		while (pavement > 0) {
			ingredients.add(Pair.of(pavementItem.method_46651(Math.min(64, pavement)),
				info.hasRequiredPavement));
			pavement -= 64;
		}
	}

	public static void displayChainRequirements(class_1792 chainItem, int count, boolean fulfilled) {
		if (active)
			return;
		prepareCustomOverlay();

		int chains = count;
		while (chains > 0) {
			ingredients.add(Pair.of(new class_1799(chainItem, Math.min(64, chains)), fulfilled));
			chains -= 64;
		}
	}

	public static void displayClothShop(TableClothBlockEntity dce, int alreadyPurchased, ShoppingList list) {
		if (active)
			return;
		prepareCustomOverlay();
		noOutput = false;

		shopContext = new BlueprintOverlayShopContext(false, dce.getStockLevelForTrade(list), alreadyPurchased);

		ingredients.add(Pair.of(dce.getPaymentItem()
				.method_46651(dce.getPaymentAmount()),
			!dce.getPaymentItem()
				.method_7960() && shopContext.stockLevel() > shopContext.purchases()));
		for (BigItemStack entry : dce.requestData.encodedRequest().stacks())
			results.add(entry.stack.method_46651(entry.count));
	}

	public static void displayShoppingList(Couple<InventorySummary> bakedList) {
		if (active || bakedList == null)
			return;
		class_310 mc = class_310.method_1551();
		prepareCustomOverlay();
		noOutput = false;

		shopContext = new BlueprintOverlayShopContext(true, 1, 0);

		for (BigItemStack entry : bakedList.getSecond()
			.getStacksByCount()) {
			ingredients.add(Pair.of(entry.stack.method_46651(entry.count), canAfford(mc.field_1724, entry)));
		}

		for (BigItemStack entry : bakedList.getFirst()
			.getStacksByCount())
			results.add(entry.stack.method_46651(entry.count));
	}

	private static boolean canAfford(class_1657 player, BigItemStack entry) {
		int itemsPresent = 0;
		for (int i = 0; i < player.method_31548().field_7547.size(); i++) {
			class_1799 item = player.method_31548()
				.method_5438(i);
			if (item.method_7960() || !class_1799.method_31577(item, entry.stack))
				continue;
			itemsPresent += item.method_7947();
		}
		return itemsPresent >= entry.count;
	}

	private static void prepareCustomOverlay() {
		active = true;
		empty = false;
		noOutput = true;
		ingredients.clear();
		results.clear();
		shopContext = null;
	}

	public static void rebuild(BlueprintSection sectionAt, boolean sneak) {
		cachedRenderedFilters.clear();
		ItemStackHandler items = sectionAt.getItems();
		boolean empty = true;
		for (int i = 0; i < 9; i++) {
			if (!items.getStackInSlot(i)
				.method_7960()) {
				empty = false;
				break;
			}
		}

		BlueprintOverlayRenderer.empty = empty;
		BlueprintOverlayRenderer.results.clear();

		if (empty)
			return;

		boolean firstPass = true;
		boolean success = true;
		class_310 mc = class_310.method_1551();
		PlayerInventoryStorage playerInv = PlayerInventoryStorage.of(mc.field_1724);

		int amountCrafted = 0;
		Optional<class_8786<class_3955>> recipe = Optional.empty();
		Map<Integer, class_1799> craftingGrid = new HashMap<>();
		ingredients.clear();
		ItemStackHandler missingItems = new ItemStackHandler(64);
		ItemStackHandler availableItems = new ItemStackHandler(64);
		List<class_1799> newlyAdded = new ArrayList<>();
		List<class_1799> newlyMissing = new ArrayList<>();
		boolean invalid = false;

		try (Transaction t = Transaction.openOuter()) {
			do {
				craftingGrid.clear();
				newlyAdded.clear();
				newlyMissing.clear();

				Search:for (int i = 0; i < 9; i++) {
					FilterItemStack requestedItem = FilterItemStack.of(items.getStackInSlot(i));
					if (requestedItem.isEmpty()) {
						craftingGrid.put(i, class_1799.field_8037);
						continue;
					}

					ResourceAmount<ItemVariant> resource = StorageUtil.findExtractableContent(
							playerInv, v -> requestedItem.test(mc.field_1687, v.toStack()), t);
					if (resource != null) {
						class_1799 currentItem = resource.resource().toStack(1);
						craftingGrid.put(i, currentItem);
						newlyAdded.add(currentItem);
						continue Search;
					}

					success = false;
					newlyMissing.add(requestedItem.item());
					}

					if (success) {
						class_9694 craftingInventory = class_9694.method_59986(3, 3,
							java.util.stream.IntStream.range(0, 9)
								.mapToObj(i -> craftingGrid.getOrDefault(i, class_1799.field_8037))
								.toList());
						if (!recipe.isPresent())
							recipe = mc.field_1687.method_8433()
									.method_8132(class_3956.field_17545, craftingInventory, mc.field_1687);
						class_1799 resultFromRecipe = recipe.filter(r -> r.comp_1933().method_8115(craftingInventory, mc.field_1687))
								.map(r -> r.comp_1933().method_8116(craftingInventory, mc.field_1687.method_30349()))
								.orElse(class_1799.field_8037);

					if (resultFromRecipe.method_7960()) {
						if (!recipe.isPresent())
							invalid = true;
						success = false;
					} else if (resultFromRecipe.method_7947() + amountCrafted > 64) {
						success = false;
					} else {
						amountCrafted += resultFromRecipe.method_7947();
						if (results.isEmpty())
							results.add(resultFromRecipe.method_7972());
						else
							results.get(0).method_7933(resultFromRecipe.method_7947());
						resultCraftable = true;
						firstPass = false;
					}
				}

				if (success || firstPass) {
					newlyAdded.forEach(s -> availableItems.insert(ItemVariant.of(s), s.method_7947(), t));
					newlyMissing.forEach(s -> missingItems.insert(ItemVariant.of(s), s.method_7947(), t));
				}

				if (!success) {
					if (firstPass) {
						results.clear();
					if (!invalid)
						results.add(items.getStackInSlot(9));
						resultCraftable = false;
					}
					break;
				}

				if (!sneak)
					break;

			} while (success);
			t.commit();
		}

		for (int i = 0; i < 9; i++) {
			class_1799 available = availableItems.getStackInSlot(i);
			if (available.method_7960())
				continue;
			ingredients.add(Pair.of(available, true));
		}
		for (int i = 0; i < 9; i++) {
			class_1799 missing = missingItems.getStackInSlot(i);
			if (missing.method_7960())
				continue;
			ingredients.add(Pair.of(missing, false));
		}
	}

	public static void renderOverlay(class_332 guiGraphics, class_9779 deltaTracker) {
		class_310 mc = class_310.method_1551();
		if (mc.field_1690.field_1842 || mc.field_1755 != null)
			return;
		if (!active || empty)
			return;

		boolean invalidShop = shopContext != null && (ingredients.isEmpty() || ingredients.get(0)
			.getFirst()
			.method_7960() || shopContext.stockLevel() == 0);

		int w = 21 * ingredients.size();

		if (!noOutput) {
			w += 21 * results.size();
			w += 30;
		}

		int x = (guiGraphics.method_51421() - w) / 2;
			int y = guiGraphics.method_51443() - 100;

			if (shopContext != null) {
				class_8002.method_47946(guiGraphics, x - 2, y + 1, w + 4, 19, 0);

			AllGuiTextures.TRADE_OVERLAY.render(guiGraphics, guiGraphics.method_51421() / 2 - 48, y - 19);
			if (shopContext.purchases() > 0) {
				guiGraphics.method_51427(AllItems.SHOPPING_LIST.asStack(), guiGraphics.method_51421() / 2 + 20, y - 20);
				guiGraphics.method_51439(mc.field_1772, class_2561.method_43470("x" + shopContext.purchases()), guiGraphics.method_51421() / 2 + 20 + 16,
					y - 20 + 4, 0xff_eeeeee, true);
			}
		}

		// Ingredients
		for (Pair<class_1799, Boolean> pair : ingredients) {
			RenderSystem.enableBlend();
			(pair.getSecond() ? AllGuiTextures.HOTSLOT_ACTIVE : AllGuiTextures.HOTSLOT).render(guiGraphics, x, y);
			class_1799 itemStack = pair.getFirst();
			String count = shopContext != null && !shopContext.checkout() || pair.getSecond() ? null
				: class_124.field_1065.toString() + itemStack.method_7947();
			drawItemStack(guiGraphics, mc, x, y, itemStack, count);
			x += 21;
		}

		if (noOutput)
			return;

		// Arrow
		x += 5;
		RenderSystem.enableBlend();
		if (invalidShop)
			AllGuiTextures.HOTSLOT_ARROW_BAD.render(guiGraphics, x, y + 4);
		else
			AllGuiTextures.HOTSLOT_ARROW.render(guiGraphics, x, y + 4);
		x += 25;

		// Outputs
		if (results.isEmpty()) {
			AllGuiTextures.HOTSLOT.render(guiGraphics, x, y);
			GuiGameElement.of(class_1802.field_8077)
				.at(x + 3, y + 3)
				.render(guiGraphics);
		} else {
			for (class_1799 result : results) {
				AllGuiTextures slot = resultCraftable ? AllGuiTextures.HOTSLOT_SUPER_ACTIVE : AllGuiTextures.HOTSLOT;
				if (!invalidShop && shopContext != null && shopContext.stockLevel() > shopContext.purchases())
					slot = AllGuiTextures.HOTSLOT_ACTIVE;
				slot.render(guiGraphics, resultCraftable ? x - 1 : x, resultCraftable ? y - 1 : y);
				drawItemStack(guiGraphics, mc, x, y, result, null);
				x += 21;
			}
		}

		if (shopContext != null && !shopContext.checkout()) {
			int cycle = 0;
			for (boolean count : Iterate.trueAndFalse)
				for (int i = 0; i < results.size(); i++) {
					class_1799 result = results.get(i);
					List<class_2561> tooltipLines = result.method_7950(class_9635.method_59528(mc.field_1687), mc.field_1724, class_1836.field_41070);
					if (tooltipLines.size() <= 1)
						continue;
					if (count) {
						cycle++;
						continue;
					}
					if ((mc.field_1705.method_1738() / 40) % cycle != i)
						continue;
					guiGraphics.method_51434(mc.field_1705.method_1756(), tooltipLines, mc.method_22683()
							.method_4486(),
						mc.method_22683()
							.method_4502());
				}
		}

		RenderSystem.disableBlend();
	}

	public static void drawItemStack(class_332 graphics, class_310 mc, int x, int y, class_1799 itemStack,
									 String count) {
		if (itemStack.method_7909() instanceof FilterItem) {
			int step = AnimationTickHolder.getTicks(mc.field_1687) / 10;
			class_1799[] itemsMatchingFilter = getItemsMatchingFilter(itemStack);
			if (itemsMatchingFilter.length > 0)
				itemStack = itemsMatchingFilter[step % itemsMatchingFilter.length];
		}

		GuiGameElement.of(itemStack)
			.at(x + 3, y + 3)
			.render(graphics);
		graphics.method_51432(mc.field_1772, itemStack, x + 3, y + 3, count);
	}

	private static class_1799[] getItemsMatchingFilter(class_1799 filter) {
		return cachedRenderedFilters.computeIfAbsent(filter, itemStack -> {
			if (AllItems.FILTER.isIn(itemStack) && !itemStack.method_57825(AllDataComponents.FILTER_ITEMS_BLACKLIST, false)) {
				ItemStackHandler filterItems = FilterItem.getFilterItems(itemStack);
				return ItemHelper.getNonEmptyStacks(filterItems).toArray(class_1799[]::new);
			}

			if (AllItems.ATTRIBUTE_FILTER.isIn(itemStack)) {
				AttributeFilterWhitelistMode whitelistMode = itemStack.method_57824(AllDataComponents.ATTRIBUTE_FILTER_WHITELIST_MODE);
				List<ItemAttribute.ItemAttributeEntry> attributes = itemStack.method_57824(AllDataComponents.ATTRIBUTE_FILTER_MATCHED_ATTRIBUTES);
				//noinspection DataFlowIssue
				if (whitelistMode == AttributeFilterWhitelistMode.WHITELIST_DISJ && attributes.size() == 1) {
					ItemAttribute attribute = attributes.getFirst().attribute();
					if (attribute instanceof InTagAttribute inTag) {
						List<class_1799> stacks = new ArrayList<>();
						for (class_6880<class_1792> holder : class_7923.field_41178.method_40286(inTag.tag())) {
							stacks.add(new class_1799(holder.comp_349()));
						}
						return stacks.toArray(class_1799[]::new);
					}
				}
			}

			return new class_1799[0];
		});
	}

}
