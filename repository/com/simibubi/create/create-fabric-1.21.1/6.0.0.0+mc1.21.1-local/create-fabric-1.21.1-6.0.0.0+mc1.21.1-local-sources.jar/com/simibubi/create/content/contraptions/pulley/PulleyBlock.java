package com.simibubi.create.content.contraptions.pulley;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllShapes;
import com.simibubi.create.content.kinetics.base.HorizontalAxisKineticBlock;
import com.simibubi.create.foundation.block.IBE;
import net.fabricmc.fabric.api.block.BlockPickInteractionAware;
import net.minecraft.class_10;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2741;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_9062;

public class PulleyBlock extends HorizontalAxisKineticBlock implements IBE<PulleyBlockEntity> {

	public PulleyBlock(class_2251 properties) {
		super(properties);
	}

	private static void onRopeBroken(class_1937 world, class_2338 pulleyPos) {
		class_2586 be = world.method_8321(pulleyPos);
		if (be instanceof PulleyBlockEntity pulley) {
			pulley.initialOffset = 0;
			pulley.onLengthBroken();
		}
	}

	@Override
	public void method_9536(class_2680 state, class_1937 worldIn, class_2338 pos, class_2680 newState, boolean isMoving) {
		super.method_9536(state, worldIn, pos, newState, isMoving);
		if (state.method_27852(newState.method_26204()))
			return;
		if (worldIn.field_9236)
			return;
		class_2680 below = worldIn.method_8320(pos.method_10074());
		if (below.method_26204() instanceof RopeBlockBase)
			worldIn.method_22352(pos.method_10074(), true);
	}

	@Override
	protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
		if (!player.method_7294())
			return class_9062.field_47731;
		if (player.method_5715())
			return class_9062.field_47731;
		if (stack.method_7960()) {
            withBlockEntityDo(level, pos, be -> be.assembleNextTick = true);
			return class_9062.field_47728;
		}
		return class_9062.field_47731;
	}

	@Override
	public Class<PulleyBlockEntity> getBlockEntityClass() {
		return PulleyBlockEntity.class;
	}

	@Override
	public class_2591<? extends PulleyBlockEntity> getBlockEntityType() {
		return AllBlockEntityTypes.ROPE_PULLEY.get();
	}

	private static class RopeBlockBase extends class_2248 implements class_3737, BlockPickInteractionAware {

		public RopeBlockBase(class_2251 properties) {
			super(properties);
			method_9590(super.method_9564().method_11657(class_2741.field_12508, false));
		}

		@Override
		protected boolean method_9516(class_2680 state, class_10 pathComputationType) {
			return false;
		}

		@Override
		public class_1799 getPickedStack(class_2680 state, class_1922 view, class_2338 pos, @Nullable class_1657 player, @Nullable class_239 result) {
			return AllBlocks.ROPE_PULLEY.asStack();
		}

		@Override
		public void method_9536(class_2680 state, class_1937 worldIn, class_2338 pos, class_2680 newState, boolean isMoving) {
			if (!isMoving && (!state.method_28498(class_2741.field_12508) || !newState.method_28498(class_2741.field_12508) || state.method_11654(class_2741.field_12508) == newState.method_11654(class_2741.field_12508))) {
				onRopeBroken(worldIn, pos.method_10084());
				if (!worldIn.field_9236) {
					class_2680 above = worldIn.method_8320(pos.method_10084());
					class_2680 below = worldIn.method_8320(pos.method_10074());
					if (above.method_26204() instanceof RopeBlockBase)
						worldIn.method_22352(pos.method_10084(), true);
					if (below.method_26204() instanceof RopeBlockBase)
						worldIn.method_22352(pos.method_10074(), true);
				}
			}
			if (state.method_31709() && state.method_26204() != newState.method_26204()) {
				worldIn.method_8544(pos);
			}
		}


		@Override
		public class_3610 method_9545(class_2680 state) {
			return state.method_11654(class_2741.field_12508) ? class_3612.field_15910.method_15729(false) : class_3612.field_15906.method_15785();
		}

		@Override
		protected void method_9515(class_2690<class_2248, class_2680> builder) {
			builder.method_11667(class_2741.field_12508);
			super.method_9515(builder);
		}

		@Override
		public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighbourState,
									  class_1936 world, class_2338 pos, class_2338 neighbourPos) {
			if (state.method_11654(class_2741.field_12508))
				world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
			return state;
		}

		@Override
		public class_2680 method_9605(class_1750 context) {
			class_3610 FluidState = context.method_8045().method_8316(context.method_8037());
			return super.method_9605(context).method_11657(class_2741.field_12508, Boolean.valueOf(FluidState.method_15772() == class_3612.field_15910));
		}

	}

	public static class MagnetBlock extends RopeBlockBase {

		public MagnetBlock(class_2251 properties) {
			super(properties);
		}

		@Override
		public class_265 method_9530(class_2680 state, class_1922 worldIn, class_2338 pos, class_3726 context) {
			return AllShapes.PULLEY_MAGNET;
		}

	}

	public static class RopeBlock extends RopeBlockBase {

		public RopeBlock(class_2251 properties) {
			super(properties);
		}

		@Override
		public class_265 method_9530(class_2680 state, class_1922 worldIn, class_2338 pos, class_3726 context) {
			return AllShapes.FOUR_VOXEL_POLE.get(class_2350.field_11036);
		}
	}

}
