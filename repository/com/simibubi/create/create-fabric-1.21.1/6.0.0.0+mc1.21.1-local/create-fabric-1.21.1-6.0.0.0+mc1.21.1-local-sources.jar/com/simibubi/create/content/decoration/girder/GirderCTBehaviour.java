package com.simibubi.create.content.decoration.girder;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllSpriteShifts;
import com.simibubi.create.foundation.block.connected.CTSpriteShiftEntry;
import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;
import net.minecraft.class_1058;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2680;

public class GirderCTBehaviour extends ConnectedTextureBehaviour.Base {

	@Override
	public CTSpriteShiftEntry getShift(class_2680 state, class_2350 direction, @Nullable class_1058 sprite) {
		if (!state.method_28498(GirderBlock.X))
			return null;
		return !state.method_11654(GirderBlock.X) && !state.method_11654(GirderBlock.Z) && direction.method_10166() != class_2351.field_11052
			? AllSpriteShifts.GIRDER_POLE
			: null;
	}

	@Override
	public boolean connectsTo(class_2680 state, class_2680 other, class_1920 reader, class_2338 pos,
		class_2338 otherPos, class_2350 face) {
		if (other.method_26204() != state.method_26204())
			return false;
		return !other.method_11654(GirderBlock.X) && !other.method_11654(GirderBlock.Z);
	}

}
