package com.simibubi.create.content.contraptions.actors.trainControls;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

import com.simibubi.create.AllPackets;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecBuilders;
import io.netty.buffer.ByteBuf;

public record ControlsInputPacket(List<Integer> activatedButtons, boolean press, int contraptionEntityId,
								  class_2338 controlsPos, boolean stopControlling) implements ServerboundPacketPayload {

	public static final class_9139<ByteBuf, ControlsInputPacket> STREAM_CODEC = class_9139.method_56906(
			CatnipStreamCodecBuilders.list(class_9135.field_48550), ControlsInputPacket::activatedButtons,
			class_9135.field_48547, ControlsInputPacket::press,
			class_9135.field_49675, ControlsInputPacket::contraptionEntityId,
			class_2338.field_48404, ControlsInputPacket::controlsPos,
			class_9135.field_48547, ControlsInputPacket::stopControlling,
	        ControlsInputPacket::new
	);

	public ControlsInputPacket(Collection<Integer> activatedButtons, boolean press, int contraptionEntityId, class_2338 controlsPos, boolean stopControlling) {
		// given list is reused, copy it
		this(List.copyOf(activatedButtons), press, contraptionEntityId, controlsPos, stopControlling);
	}

	@Override
	public void handle(class_3222 player) {
		class_1937 world = player.method_5770();
		UUID uniqueID = player.method_5667();

		if (player.method_7325() && press)
			return;

		class_1297 entity = world.method_8469(contraptionEntityId);
		if (!(entity instanceof AbstractContraptionEntity ace))
			return;
		if (stopControlling) {
			ace.stopControlling(controlsPos);
			return;
		}

		boolean controllingThisContraption = ace.getControllingPlayer()
			.filter(uniqueID::equals)
			.isPresent();
		if (controllingThisContraption || ace.toGlobalVector(class_243.method_24953(controlsPos), 0)
			.method_24802(player.method_19538(), 32))
			ControlsServerHandler.receivePressed(world, ace, controlsPos, uniqueID, activatedButtons, press);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CONTROLS_INPUT;
	}
}
