package com.simibubi.create.content.equipment.blueprint;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import javax.annotation.Nullable;

import com.simibubi.create.AllEntityTypes;
import com.simibubi.create.AllItems;
import com.simibubi.create.Create;
import com.simibubi.create.api.schematic.requirement.SpecialEntityItemRequirement;
import com.simibubi.create.content.logistics.filter.FilterItemStack;
import com.simibubi.create.content.schematics.requirement.ItemRequirement;
import com.simibubi.create.content.schematics.requirement.ItemRequirement.ItemUseType;
import com.simibubi.create.foundation.networking.ISyncPersistentData;
import com.simibubi.create.foundation.utility.IInteractionChecker;
import com.simibubi.create.foundation.utility.PersistentDataHelper;
import io.netty.buffer.Unpooled;

import net.createmod.catnip.data.Couple;
import net.createmod.catnip.math.VecHelper;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.item.PlayerInventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageUtil;
import net.fabricmc.fabric.api.transfer.v1.storage.base.ResourceAmount;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1530;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1715;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2312;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2371;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2945;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_3908;
import net.minecraft.class_3955;
import net.minecraft.class_3956;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import net.minecraft.class_5134;
import net.minecraft.class_8786;
import net.minecraft.class_9129;
import net.minecraft.class_9694;
import io.github.fabricators_of_create.porting_lib.entity.IEntityWithComplexSpawn;

import com.simibubi.create.infrastructure.fabric.transfer.item.ItemStackHandler;

public class BlueprintEntity extends class_1530
	implements IEntityWithComplexSpawn, SpecialEntityItemRequirement, ISyncPersistentData, IInteractionChecker {

	protected int size;
	protected class_2350 verticalOrientation;

	@SuppressWarnings("unchecked")
	public BlueprintEntity(class_1299<?> p_i50221_1_, class_1937 p_i50221_2_) {
		super((class_1299<? extends class_1530>) p_i50221_1_, p_i50221_2_);
		size = 1;
	}

	public BlueprintEntity(class_1937 world, class_2338 pos, class_2350 facing, class_2350 verticalOrientation) {
		super(AllEntityTypes.CRAFTING_BLUEPRINT.get(), world, pos);

		for (int size = 3; size > 0; size--) {
			this.size = size;
			this.updateFacingWithBoundingBox(facing, verticalOrientation);
			if (this.method_6888())
				break;
		}
	}

	public static FabricEntityTypeBuilder<?> build(FabricEntityTypeBuilder<?> builder) {
//		@SuppressWarnings("unchecked")
//		EntityType.Builder<BlueprintEntity> entityBuilder = (EntityType.Builder<BlueprintEntity>) builder;
		return builder;
	}

	@Override
	protected void method_5693(class_2945.class_9222 builder) {}

	@Override
	public void method_5652(class_2487 p_213281_1_) {
		p_213281_1_.method_10567("Facing", (byte) this.field_7099.method_10146());
		p_213281_1_.method_10567("Orientation", (byte) this.verticalOrientation.method_10146());
		p_213281_1_.method_10569("Size", size);
		super.method_5652(p_213281_1_);
	}

	@Override
	public void method_5749(class_2487 p_70037_1_) {
		if (p_70037_1_.method_10573("Facing", class_2520.field_33263)) {
			this.field_7099 = class_2350.method_10143(p_70037_1_.method_10571("Facing"));
			this.verticalOrientation = class_2350.method_10143(p_70037_1_.method_10571("Orientation"));
			this.size = p_70037_1_.method_10550("Size");
		} else {
			this.field_7099 = class_2350.field_11035;
			this.verticalOrientation = class_2350.field_11033;
			this.size = 1;
		}
		super.method_5749(p_70037_1_);
		this.updateFacingWithBoundingBox(this.field_7099, this.verticalOrientation);
	}

	protected void updateFacingWithBoundingBox(class_2350 facing, class_2350 verticalOrientation) {
		Objects.requireNonNull(facing);
		this.field_7099 = facing;
		this.verticalOrientation = verticalOrientation;
		if (facing.method_10166()
			.method_10179()) {
			method_36457(0.0F);
			method_36456(this.field_7099.method_10161() * 90);
		} else {
			method_36457(-90 * facing.method_10171()
				.method_10181());
			method_36456(verticalOrientation.method_10166()
				.method_10179() ? 180 + verticalOrientation.method_10144() : 0);
		}

		this.field_6004 = method_36455();
		this.field_5982 = method_36454();
			this.updateBoundingBox();
	}

	@Override
	public class_4048 method_18377(class_4050 pose) {
		return super.method_18377(pose).method_55685(0);
	}

	@Override
	protected class_238 method_59943(class_2338 blockPos, class_2350 direction) {
		class_243 pos = class_243.method_24954(method_59940())
				.method_1031(.5, .5, .5)
				.method_1020(class_243.method_24954(direction.method_10163())
						.method_1021(0.46875));
		double d1 = pos.field_1352;
		double d2 = pos.field_1351;
		double d3 = pos.field_1350;
		this.method_23327(d1, d2, d3);

		class_2351 axis = direction.method_10166();
		if (size == 2)
			pos = pos.method_1019(class_243.method_24954(axis.method_10179() ? direction.method_10160()
									.method_10163()
									: verticalOrientation.method_10170()
									.method_10163())
							.method_1021(0.5))
					.method_1019(class_243
							.method_24954(axis.method_10179() ? class_2350.field_11036.method_10163()
									: direction == class_2350.field_11036 ? verticalOrientation.method_10163()
									: verticalOrientation.method_10153()
									.method_10163())
							.method_1021(0.5));

		d1 = pos.field_1352;
		d2 = pos.field_1351;
		d3 = pos.field_1350;

		double d4 = (double) this.getWidth();
		double d5 = (double) this.getHeight();
		double d6 = (double) this.getWidth();
		class_2350.class_2351 direction$axis = this.field_7099.method_10166();
		switch (direction$axis) {
			case field_11048:
				d4 = 1.0D;
				break;
			case field_11052:
				d5 = 1.0D;
				break;
			case field_11051:
				d6 = 1.0D;
		}

		d4 = d4 / 32.0D;
		d5 = d5 / 32.0D;
		d6 = d6 / 32.0D;

		return new class_238(d1 - d4, d2 - d5, d3 - d6, d1 + d4, d2 + d5, d3 + d6);
	}

	private void updateBoundingBox() {
		if (this.field_7099 != null && this.verticalOrientation != null) {
			method_5857(method_59943(field_51589, field_7099));
		}
	}
	@Override
	public void method_5814(double pX, double pY, double pZ) {
		method_23327(pX, pY, pZ);
		super.method_5814(pX, pY, pZ);
	}

	@Override
	public boolean method_6888() {
		if (!method_37908().method_17892(this))
			return false;

		int i = Math.max(1, this.getWidth() / 16);
		int j = Math.max(1, this.getHeight() / 16);
		class_2338 blockpos = this.field_51589.method_10093(this.field_7099.method_10153());
		class_2350 upDirection = field_7099.method_10166()
			.method_10179() ? class_2350.field_11036
			: field_7099 == class_2350.field_11036 ? verticalOrientation : verticalOrientation.method_10153();
		class_2350 newDirection = field_7099.method_10166()
			.method_10178() ? verticalOrientation.method_10170() : field_7099.method_10160();
		class_2338.class_2339 blockpos$mutable = new class_2338.class_2339();

		for (int k = 0; k < i; ++k) {
			for (int l = 0; l < j; ++l) {
				int i1 = (i - 1) / -2;
				int j1 = (j - 1) / -2;
				blockpos$mutable.method_10101(blockpos)
					.method_10104(newDirection, k + i1)
					.method_10104(upDirection, l + j1);
				class_2680 blockstate = this.method_37908().method_8320(blockpos$mutable);
				if (class_2248.method_20044(this.method_37908(), blockpos$mutable, this.field_7099))
					continue;
				if (!blockstate.method_51367() && !class_2312.method_9999(blockstate)) {
					return false;
				}
			}
		}

		return this.method_37908().method_8333(this, this.method_5829(), field_7098)
			.isEmpty();
	}

	public int getWidth() {
		return 16 * size;
	}

	public int getHeight() {
		return 16 * size;
	}

	@Override
	public boolean method_5698(class_1297 source) {
		if (!(source instanceof class_1657 player) || method_37908().field_9236)
			return super.method_5698(source);

		double attrib = player.method_45325(class_5134.field_47758) + (player.method_7337() ? 0 : -0.5F);

		class_243 eyePos = source.method_5836(1);
		class_243 look = source.method_5828(1);
		class_243 target = eyePos.method_1019(look.method_1021(attrib));

		Optional<class_243> rayTrace = method_5829().method_992(eyePos, target);
		if (!rayTrace.isPresent())
			return super.method_5698(source);

		class_243 hitVec = rayTrace.get();
		BlueprintSection sectionAt = getSectionAt(hitVec.method_1020(method_19538()));
		ItemStackHandler items = sectionAt.getItems();

		if (items.getStackInSlot(9)
			.method_7960())
			return super.method_5698(source);
		for (int i = 0; i < items.getSlotCount(); i++)
			items.setStackInSlot(i, class_1799.field_8037);
		sectionAt.save(items);
		return true;
	}

	@Override
	public void method_6889(@Nullable class_1297 p_110128_1_) {
		if (!method_37908().method_8450()
			.method_8355(class_1928.field_19393))
			return;

		method_5783(class_3417.field_14809, 1.0F, 1.0F);
		if (p_110128_1_ instanceof class_1657 playerentity) {
			if (playerentity.method_31549().field_7477)
				return;
		}

		method_5775(AllItems.CRAFTING_BLUEPRINT.asStack());
	}

	@Nullable
	@Override
	public class_1799 method_31480() {
		return AllItems.CRAFTING_BLUEPRINT.asStack();
	}

	@Override
	public ItemRequirement getRequiredItems() {
		return new ItemRequirement(ItemUseType.CONSUME, AllItems.CRAFTING_BLUEPRINT.get());
	}

	@Override
	public void method_6894() {
		this.method_5783(class_3417.field_14875, 1.0F, 1.0F);
	}

	@Override
	public void method_5808(double p_70012_1_, double p_70012_3_, double p_70012_5_, float p_70012_7_, float p_70012_8_) {
		this.method_5814(p_70012_1_, p_70012_3_, p_70012_5_);
	}

	@Override
	@Environment(EnvType.CLIENT)
	public void method_5759(double pX, double pY, double pZ, float pYRot, float pXRot, int pSteps) {
		class_2338 blockpos =
				this.field_51589.method_10081(class_2338.method_49637(pX - this.method_23317(), pY - this.method_23318(), pZ - this.method_23321()));
		this.method_5814(blockpos.method_10263(), blockpos.method_10264(), blockpos.method_10260());
	}

	@Override
	public void writeSpawnData(class_9129 registryFriendlyByteBuf) {
		class_2487 compound = new class_2487();
		method_5652(compound);
		registryFriendlyByteBuf.method_10794(compound);
		registryFriendlyByteBuf.method_10794(PersistentDataHelper.get(this));
	}

	@Override
	public void readSpawnData(class_9129 registryFriendlyByteBuf) {
		method_5749(registryFriendlyByteBuf.method_10798());
		PersistentDataHelper.get(this).method_10543(registryFriendlyByteBuf.method_10798());
	}

	@Override
	public class_1269 method_5664(class_1657 player, class_243 vec, class_1268 hand) {
		if (player instanceof FakePlayer)
			return class_1269.field_5811;

		boolean holdingWrench = AllItems.WRENCH.isIn(player.method_5998(hand));
		BlueprintSection section = getSectionAt(vec);
		ItemStackHandler items = section.getItems();

		if (!holdingWrench && !method_37908().field_9236 && !items.getStackInSlot(9)
			.method_7960()) {


				PlayerInventoryStorage playerInv = PlayerInventoryStorage.of(player);
				boolean firstPass = true;
				int amountCrafted = 0;
				Optional<class_8786<class_3955>> recipe = Optional.empty();

			do {
				try (Transaction t = Transaction.openOuter()) {
					Map<Integer, class_1799> craftingGrid = new HashMap<>();
					boolean success = true;

					Search:
				for (int i = 0; i < 9; i++) {
						FilterItemStack requestedItem = FilterItemStack.of(items.getStackInSlot(i));
						if (requestedItem.isEmpty()) {
							craftingGrid.put(i, class_1799.field_8037);
							continue;
						}

						ResourceAmount<ItemVariant> resource = StorageUtil.findExtractableContent(
								playerInv, v -> requestedItem.test(method_37908(), v.toStack()), t);
						if (resource != null) {
							playerInv.extract(resource.resource(), 1, t);
							craftingGrid.put(i, resource.resource().toStack());
							continue Search;
						}

						success = false;
						break;
						}

						if (success) {
							class_9694 craftingInventory = class_9694.method_59986(3, 3,
								java.util.stream.IntStream.range(0, 9)
									.mapToObj(i -> craftingGrid.getOrDefault(i, class_1799.field_8037))
									.toList());

							if (!recipe.isPresent())
								recipe = method_37908().method_8433()
										.method_8132(class_3956.field_17545, craftingInventory, method_37908());
							class_1799 result = recipe.filter(r -> r.comp_1933().method_8115(craftingInventory, method_37908()))
									.map(r -> r.comp_1933().method_8116(craftingInventory, method_37908().method_30349()))
									.orElse(class_1799.field_8037);

						if (result.method_7960()) {
							success = false;
						} else if (result.method_7947() + amountCrafted > 64) {
							success = false;
						} else {
							amountCrafted += result.method_7947();
							result.method_7982(player.method_37908(), player, 1);
//						ForgeEventFactory.firePlayerCraftingEvent(player, result, craftingInventory);
								class_2371<class_1799> nonnulllist = method_37908().method_8433()
										.method_8128(class_3956.field_17545, craftingInventory, method_37908());

							if (firstPass)
								method_37908().method_8396(null, player.method_24515(), class_3417.field_15197, class_3419.field_15248,
										.2f, 1f + Create.RANDOM.nextFloat());
							player.method_31548()
									.method_7398(result);
							for (class_1799 itemStack : nonnulllist)
								player.method_31548()
										.method_7398(itemStack);
							firstPass = false;
						}
					}

					if (!success) {
						t.abort();
						break;
					} else t.commit();
				}
			} while (player.method_5715());

//			ForgeHooks.setCraftingPlayer(null);
			return class_1269.field_5812;
		}

		if (!method_37908().field_9236 && player instanceof class_3222) {
			((class_3222) player).method_17355(section);
		}

		return class_1269.field_5812;
	}

	public BlueprintSection getSectionAt(class_243 vec) {
		int index = 0;
		if (size > 1) {
			vec = VecHelper.rotate(vec, method_36454(), class_2351.field_11052);
			vec = VecHelper.rotate(vec, -method_36455(), class_2351.field_11048);
			vec = vec.method_1031(0.5, 0.5, 0);
			if (size == 3)
				vec = vec.method_1031(1, 1, 0);
			int x = class_3532.method_15340(class_3532.method_15357(vec.field_1352), 0, size - 1);
			int y = class_3532.method_15340(class_3532.method_15357(vec.field_1351), 0, size - 1);
			index = x + y * size;
		}

		BlueprintSection section = getSection(index);
		return section;
	}

	static class BlueprintCraftingInventory extends class_1715 {

		private static final class_1703 dummyContainer = new class_1703(null, -1) {
			public boolean method_7597(class_1657 playerIn) {
				return false;
			}

			@Override
			public class_1799 method_7601(class_1657 p_38941_, int p_38942_) {
				return class_1799.field_8037;
			}
		};

		public BlueprintCraftingInventory(Map<Integer, class_1799> items) {
			super(dummyContainer, 3, 3);
			for (int y = 0; y < 3; y++) {
				for (int x = 0; x < 3; x++) {
					class_1799 stack = items.get(y * 3 + x);
					method_5447(y * 3 + x, stack == null ? class_1799.field_8037 : stack.method_7972());
				}
			}
		}

	}

	public class_2487 getOrCreateRecipeCompound() {
		class_2487 persistentData = getCustomData();
		if (!persistentData.method_10545("Recipes"))
			persistentData.method_10566("Recipes", new class_2487());
		return persistentData.method_10562("Recipes");
	}

	private Map<Integer, BlueprintSection> sectionCache = new HashMap<>();

	public BlueprintSection getSection(int index) {
		return sectionCache.computeIfAbsent(index, i -> new BlueprintSection(i));
	}

	class BlueprintSection implements class_3908, IInteractionChecker, ExtendedScreenHandlerFactory<class_9129> {
		int index;
		Couple<class_1799> cachedDisplayItems;
		public boolean inferredIcon = false;

		public BlueprintSection(int index) {
			this.index = index;
		}

		public Couple<class_1799> getDisplayItems() {
			if (cachedDisplayItems != null)
				return cachedDisplayItems;
			ItemStackHandler items = getItems();
			return cachedDisplayItems = Couple.create(items.getStackInSlot(9), items.getStackInSlot(10));
		}

		public ItemStackHandler getItems() {
			ItemStackHandler newInv = new ItemStackHandler(11);
			class_2487 list = getOrCreateRecipeCompound();
			class_2487 invNBT = list.method_10562(index + "");
			inferredIcon = list.method_10577("InferredIcon");
			if (!invNBT.method_33133())
				newInv.deserializeNBT(method_56673(), invNBT);
			return newInv;
		}

		public void save(ItemStackHandler inventory) {
			class_2487 list = getOrCreateRecipeCompound();
			list.method_10566(index + "", inventory.serializeNBT(method_56673()));
			list.method_10556("InferredIcon", inferredIcon);
			cachedDisplayItems = null;
			if (!method_37908().field_9236)
				syncPersistentDataWithTracking(BlueprintEntity.this);
		}

		public boolean isEntityAlive() {
			return method_5805();
		}

		public class_1937 getBlueprintWorld() {
			return method_37908();
		}

		@Override
		public class_1703 createMenu(int id, class_1661 inv, class_1657 player) {
			return BlueprintMenu.create(id, inv, this);
		}

		@Override
		public class_2561 method_5476() {
			return AllItems.CRAFTING_BLUEPRINT.get()
				.method_7848();
		}

		@Override
		public boolean canPlayerUse(class_1657 player) {
			return BlueprintEntity.this.canPlayerUse(player);
		}

		@Override
		public class_9129 getScreenOpeningData(class_3222 player) {
			class_9129 buffer = new class_9129(Unpooled.buffer(), player.method_56673());
			buffer.method_10804(BlueprintEntity.this.method_5628());
			buffer.method_10804(index);
			return buffer;
		}

	}

	@Override
	public void onPersistentDataUpdated() {
		sectionCache.clear();
	}

	@Override
	public boolean canPlayerUse(class_1657 player) {
		class_238 box = method_5829();

		double dx = 0;
		if (box.field_1323 > player.method_23317()) {
			dx = box.field_1323 - player.method_23317();
		} else if (player.method_23317() > box.field_1320) {
			dx = player.method_23317() - box.field_1320;
		}

		double dy = 0;
		if (box.field_1322 > player.method_23318()) {
			dy = box.field_1322 - player.method_23318();
		} else if (player.method_23318() > box.field_1325) {
			dy = player.method_23318() - box.field_1325;
		}

		double dz = 0;
		if (box.field_1321 > player.method_23321()) {
			dz = box.field_1321 - player.method_23321();
		} else if (player.method_23321() > box.field_1324) {
			dz = player.method_23321() - box.field_1324;
		}

		return (dx * dx + dy * dy + dz * dz) <= 64.0D;
	}

}
