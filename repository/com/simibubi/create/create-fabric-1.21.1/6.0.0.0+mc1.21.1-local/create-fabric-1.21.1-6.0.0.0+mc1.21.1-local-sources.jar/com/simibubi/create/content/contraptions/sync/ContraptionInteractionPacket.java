package com.simibubi.create.content.contraptions.sync;

import com.simibubi.create.AllPackets;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import net.createmod.catnip.net.base.ServerboundPacketPayload;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecBuilders;
import net.createmod.catnip.codecs.stream.CatnipStreamCodecs;
import io.netty.buffer.ByteBuf;

public record ContraptionInteractionPacket(class_1268 hand, int target, class_2338 localPos, class_2350 face) implements ServerboundPacketPayload {
	public static final class_9139<ByteBuf, ContraptionInteractionPacket> STREAM_CODEC = class_9139.method_56905(
			CatnipStreamCodecBuilders.nullable(CatnipStreamCodecs.HAND), ContraptionInteractionPacket::hand,
			class_9135.field_49675, ContraptionInteractionPacket::target,
			class_2338.field_48404, ContraptionInteractionPacket::localPos,
			class_2350.field_48450, ContraptionInteractionPacket::face,
			ContraptionInteractionPacket::new
	);

	public ContraptionInteractionPacket(AbstractContraptionEntity target, class_1268 hand, class_2338 localPos, class_2350 side) {
		this(hand, target.method_5628(), localPos, side);
	}

	@Override
	public PacketTypeProvider getTypeProvider() {
		return AllPackets.CONTRAPTION_INTERACT;
	}

	@Override
	public void handle(class_3222 sender) {
		if (sender == null)
			return;
		class_1297 entityByID = sender.method_37908().method_8469(target);
		if (!(entityByID instanceof AbstractContraptionEntity contraptionEntity))
			return;
		class_238 bb = contraptionEntity.method_5829();
		double boundsExtra = Math.max(bb.method_17939(), bb.method_17940());
		double d = sender.method_45325(class_5134.field_47758) + 10 + boundsExtra;
		if (!sender.method_6057(entityByID))
			d -= 3;
		d *= d;
		if (sender.method_5858(entityByID) > d)
			return;
		if (contraptionEntity.handlePlayerInteraction(sender, localPos, face, hand))
			sender.method_23667(hand, true);
	}
}
