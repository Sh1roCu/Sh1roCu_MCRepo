package com.simibubi.create.content.equipment.toolbox;

import static net.minecraft.class_2741.field_12508;

import java.util.Optional;

import org.jetbrains.annotations.NotNull;

import com.mojang.serialization.MapCodec;
import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllDataComponents;
import com.simibubi.create.AllShapes;
import com.simibubi.create.foundation.block.IBE;
import com.simibubi.create.foundation.item.ItemHelper;
import com.simibubi.create.foundation.utility.BlockHelper;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2383;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_3737;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_9062;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import io.github.fabricators_of_create.porting_lib.util.TagUtil;

public class ToolboxBlock extends class_2383 implements class_3737, IBE<ToolboxBlockEntity> {

	protected final class_1767 color;

	public static final MapCodec<ToolboxBlock> field_46280 = method_54094(p -> new ToolboxBlock(p, class_1767.field_7952));

	public ToolboxBlock(class_2251 properties, class_1767 color) {
		super(properties);
		this.color = color;
		method_9590(method_9564().method_11657(class_2741.field_12508, false));
	}

	@Override
	public class_3610 method_9545(class_2680 state) {
		return state.method_11654(field_12508) ? class_3612.field_15910.method_15729(false) : class_3612.field_15906.method_15785();
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> builder) {
		super.method_9515(builder.method_11667(field_12508)
			.method_11667(field_11177));
	}

	@Override
	public void method_9567(class_1937 worldIn, class_2338 pos, class_2680 state, class_1309 placer, class_1799 stack) {
		super.method_9567(worldIn, pos, state, placer, stack);
		if (worldIn.field_9236)
			return;
		if (stack == null)
			return;
		withBlockEntityDo(worldIn, pos, be -> {
			be.readInventory(stack.method_57825(AllDataComponents.TOOLBOX_INVENTORY, class_9288.field_49334));
			if (stack.method_57826(AllDataComponents.TOOLBOX_UUID))
				be.setUniqueId(stack.method_57824(AllDataComponents.TOOLBOX_UUID));
			if (stack.method_57826(class_9334.field_49631))
				be.setCustomName(stack.method_7964());
		});
	}

	@Override
	public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moving) {
		if (state.method_31709() && (!newState.method_31709() || !(newState.method_26204() instanceof ToolboxBlock)))
			world.method_8544(pos);
	}

	@Override
	public void method_9606(class_2680 state, class_1937 world, class_2338 pos, class_1657 player) {
		if (player instanceof FakePlayer)
			return;
		if (world.field_9236)
			return;
		withBlockEntityDo(world, pos, ToolboxBlockEntity::unequipTracked);
		if (world instanceof class_3218) {
			class_1799 cloneItemStack = method_9574(world, pos, state);
			world.method_22352(pos, false);
			if (world.method_8320(pos) != state)
				player.method_31548().method_7398(cloneItemStack);
		}
	}

	@Override
	public class_1799 method_9574(class_4538 level, class_2338 pos, class_2680 state) {
		class_1799 item = new class_1799(this);
		Optional<ToolboxBlockEntity> blockEntityOptional = getBlockEntityOptional(level, pos);

		class_2371<class_1799> stacks = class_2371.method_10211();
		blockEntityOptional.ifPresent(tb -> {
			for (int i = 0; i < tb.inventory.getSlotCount(); i++) {
				stacks.add(tb.inventory.getStackInSlot(i));
			}
		});
		item.method_57379(AllDataComponents.TOOLBOX_INVENTORY, class_9288.method_57493(stacks));

		blockEntityOptional.map(ToolboxBlockEntity::getUniqueId)
			.ifPresent(uid -> item.method_57379(AllDataComponents.TOOLBOX_UUID, uid));
		blockEntityOptional.map(ToolboxBlockEntity::method_5797)
			.ifPresent(name -> item.method_57379(class_9334.field_49631, name));
		return item;
	}

	@Override
	public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighbourState, class_1936 world,
								  class_2338 pos, class_2338 neighbourPos) {
		if (state.method_11654(field_12508))
			world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
		return state;
	}

	@Override
	public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
		return AllShapes.TOOLBOX.get(state.method_11654(field_11177));
	}

	@Override
	protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
		if (player == null || player.method_18276())
			return class_9062.field_47731;

		class_1767 color = TagUtil.getColorFromStack(stack);
		if (color != null && color != this.color) {
			if (level.field_9236)
				return class_9062.field_47728;
			class_2680 newState = BlockHelper.copyProperties(state, AllBlocks.TOOLBOXES.get(color)
				.getDefaultState());
			level.method_8501(pos, newState);
			return class_9062.field_47728;
		}

		if (player instanceof FakePlayer)
			return class_9062.field_47731;
		if (level.field_9236)
			return class_9062.field_47728;

		if (player instanceof class_3222 sp) {
			withBlockEntityDo(level, pos,
				toolbox -> sp.method_17355(toolbox));
		}
		return class_9062.field_47728;
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		class_3610 ifluidstate = context.method_8045()
			.method_8316(context.method_8037());
		return super.method_9605(context).method_11657(field_11177, context.method_8042()
				.method_10153())
			.method_11657(field_12508, Boolean.valueOf(ifluidstate.method_15772() == class_3612.field_15910));
	}

	@Override
	public Class<ToolboxBlockEntity> getBlockEntityClass() {
		return ToolboxBlockEntity.class;
	}

	@Override
	public class_2591<? extends ToolboxBlockEntity> getBlockEntityType() {
		return AllBlockEntityTypes.TOOLBOX.get();
	}

	public class_1767 getColor() {
		return color;
	}

	@Override
	public boolean method_9498(class_2680 pState) {
		return true;
	}

	@Override
	public int method_9572(class_2680 pState, class_1937 pLevel, class_2338 pPos) {
		return ItemHelper.calcRedstoneFromBlockEntity(this, pLevel, pPos);
	}

	@Override
	protected @NotNull MapCodec<? extends class_2383> method_53969() {
		return field_46280;
	}
}
