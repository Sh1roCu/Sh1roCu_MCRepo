package com.simibubi.create.api.unpacking;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

import com.simibubi.create.content.logistics.stockTicker.PackageOrder;

/**
 * An {@link UnpackingHandler} that voids inserted items.
 */
public enum VoidingUnpackingHandler implements UnpackingHandler {
	INSTANCE;

	@Override
	public boolean unpack(class_1937 level, class_2338 pos, class_2680 state, class_2350 side, List<class_1799> items, @Nullable PackageOrder order, boolean simulate) {
		return true;
	}
}
