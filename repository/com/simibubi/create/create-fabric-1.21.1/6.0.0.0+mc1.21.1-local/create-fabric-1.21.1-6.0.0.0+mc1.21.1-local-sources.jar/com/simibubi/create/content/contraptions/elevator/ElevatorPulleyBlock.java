package com.simibubi.create.content.contraptions.elevator;

import com.simibubi.create.AllBlockEntityTypes;
import com.simibubi.create.AllShapes;
import com.simibubi.create.content.kinetics.base.HorizontalKineticBlock;
import com.simibubi.create.foundation.block.IBE;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_9062;

public class ElevatorPulleyBlock extends HorizontalKineticBlock implements IBE<ElevatorPulleyBlockEntity> {

	public ElevatorPulleyBlock(class_2251 properties) {
		super(properties);
	}

	@Override
	protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hitResult) {
		if (!player.method_7294())
			return class_9062.field_47733;
		if (player.method_5715())
			return class_9062.field_47733;
		if (!stack.method_7960())
			return class_9062.field_47731;
		if (level.field_9236)
			return class_9062.field_47728;
		return onBlockEntityUseItemOn(level, pos, be -> {
			be.clicked();
			return class_9062.field_47728;
		});
	}

	@Override
	public class_2591<? extends ElevatorPulleyBlockEntity> getBlockEntityType() {
		return AllBlockEntityTypes.ELEVATOR_PULLEY.get();
	}

	@Override
	public class_2351 getRotationAxis(class_2680 state) {
		return state.method_11654(HORIZONTAL_FACING)
			.method_10170()
			.method_10166();
	}

	@Override
	public class_265 method_9530(class_2680 state, class_1922 worldIn, class_2338 pos, class_3726 context) {
		return AllShapes.ELEVATOR_PULLEY.get(state.method_11654(HORIZONTAL_FACING));
	}

	@Override
	public boolean hasShaftTowards(class_4538 world, class_2338 pos, class_2680 state, class_2350 face) {
		return getRotationAxis(state) == face.method_10166();
	}

	@Override
	public Class<ElevatorPulleyBlockEntity> getBlockEntityClass() {
		return ElevatorPulleyBlockEntity.class;
	}

}
