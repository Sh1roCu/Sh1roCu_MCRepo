package com.simibubi.create.content.equipment.armor;

import java.util.UUID;
import java.util.concurrent.ExecutionException;

import com.google.common.cache.Cache;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.logistics.box.PackageRenderer;
import com.simibubi.create.foundation.utility.TickBasedCache;

import dev.engine_room.flywheel.lib.model.baked.PartialModel;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.minecraft.class_1007;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5498;

public class CardboardArmorHandlerClient {

	private static final Cache<UUID, Integer> BOXES_PLAYERS_ARE_HIDING_AS = new TickBasedCache<>(20, true);

	public static void keepCacheAliveDesignDespiteNotRendering(class_1657 player) {
		if (!CardboardArmorHandler.testForStealth(player))
			return;
		try {
			getCurrentBoxIndex(player);
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
	}

	public static boolean playerRendersAsBoxWhenSneaking(class_1657 player, class_1007 renderer, float partialTick, class_4587 ms, class_4597 buffer, int packedLight) {
		if (!CardboardArmorHandler.testForStealth(player))
			return false;

		if (player == class_310.method_1551().field_1724
			&& class_310.method_1551().field_1690.method_31044() == class_5498.field_26664)
			return true;

		ms.method_22903();
		ms.method_46416(0, 2 / 16f, 0);

		float movement = (float) player.method_19538()
			.method_1023(player.field_6014, player.field_6036, player.field_5969)
			.method_1033();

		if (player.method_24828())
			ms.method_46416(0,
				Math.min(Math.abs(class_3532.method_15362((AnimationTickHolder.getRenderTime() % 256) / 2.0f)) * 2 / 16f, movement * 5),
				0);

		float interpolatedYaw = class_3532.method_16439(partialTick, player.field_5982, player.method_36454());

		try {
			PartialModel model = AllPartialModels.PACKAGES_TO_HIDE_AS.get(getCurrentBoxIndex(player));
			PackageRenderer.renderBox(player, interpolatedYaw, ms, buffer,
				packedLight, model);
		} catch (ExecutionException e) {
			e.printStackTrace();
		}

		ms.method_22909();

		return true;
	}

	private static Integer getCurrentBoxIndex(class_1657 player) throws ExecutionException {
		return BOXES_PLAYERS_ARE_HIDING_AS.get(player.method_5667(),
			() -> player.method_37908().field_9229.method_43048(AllPartialModels.PACKAGES_TO_HIDE_AS.size()));
	}

}
