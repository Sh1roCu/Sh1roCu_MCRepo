package com.simibubi.create.content.decoration.copycat;

import java.util.function.Supplier;

import com.simibubi.create.foundation.model.BakedModelHelper;

import net.createmod.catnip.data.Iterate;

import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.model.SpriteFinder;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.class_1087;
import net.minecraft.class_1723;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2760;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.model.SpriteFinder;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;

public class CopycatStepModel extends CopycatModel {

	protected static final class_243 VEC_Y_3 = new class_243(0, .75, 0);
	protected static final class_243 VEC_Y_2 = new class_243(0, .5, 0);
	protected static final class_243 VEC_Y_N2 = new class_243(0, -.5, 0);
	protected static final class_238 CUBE_AABB = new class_238(class_2338.field_10980);

	public CopycatStepModel(class_1087 originalModel) {
		super(originalModel);
	}

	@Override
	protected void emitBlockQuadsInner(class_1920 blockView, class_2680 state, class_2338 pos, Supplier<class_5819> randomSupplier, RenderContext context, class_2680 material, CullFaceRemovalData cullFaceRemovalData, OcclusionData occlusionData) {
		class_2350 facing = state.method_28500(CopycatStepBlock.FACING)
			.orElse(class_2350.field_11035);
		boolean upperHalf = state.method_28500(CopycatStepBlock.HALF)
			.orElse(class_2760.field_12617) == class_2760.field_12619;

		class_1087 model = getModelOf(material);

		class_243 normal = class_243.method_24954(facing.method_10163());
		class_243 normalScaled2 = normal.method_1021(.5);
		class_243 normalScaledN3 = normal.method_1021(-.75);
		class_238 bb = CUBE_AABB.method_1002(-normal.field_1352 * .75, .75, -normal.field_1350 * .75);

		SpriteFinder spriteFinder = SpriteFinder.get(class_310.method_1551().method_1554().method_24153(class_1723.field_21668));

		// Use a mesh to defer quad emission since quads cannot be emitted inside a transform
		MeshBuilder meshBuilder = RendererAccess.INSTANCE.getRenderer().meshBuilder();
		QuadEmitter emitter = meshBuilder.getEmitter();
		context.pushTransform(quad -> {
			if (cullFaceRemovalData.shouldRemove(quad.cullFace())) {
				quad.cullFace(null);
			} else if (occlusionData.isOccluded(quad.cullFace())) {
				// Add quad to mesh and do not render original quad to preserve quad render order
				// copyTo does not copy the material
				RenderMaterial quadMaterial = quad.material();
				quad.copyTo(emitter);
				emitter.material(quadMaterial);
				emitter.emit();
				return false;
			}

			// 4 Pieces
			for (boolean top : Iterate.trueAndFalse) {
				for (boolean front : Iterate.trueAndFalse) {

					class_238 bb1 = bb;
					if (front)
						bb1 = bb1.method_997(normalScaledN3);
					if (top)
						bb1 = bb1.method_997(VEC_Y_3);

					class_243 offset = class_243.field_1353;
					if (front)
						offset = offset.method_1019(normalScaled2);
					if (top != upperHalf)
						offset = offset.method_1019(upperHalf ? VEC_Y_2 : VEC_Y_N2);

					class_2350 direction = quad.lightFace();

					if (front && direction == facing)
						continue;
					if (!front && direction == facing.method_10153())
						continue;
					if (!top && direction == class_2350.field_11036)
						continue;
					if (top && direction == class_2350.field_11033)
						continue;

					// copyTo does not copy the material
					RenderMaterial quadMaterial = quad.material();
					quad.copyTo(emitter);
					emitter.material(quadMaterial);
					BakedModelHelper.cropAndMove(emitter, spriteFinder.find(emitter, 0), bb1, offset);
					emitter.emit();
				}
			}

			return false;
		});
		((FabricBakedModel) model).emitBlockQuads(blockView, material, pos, randomSupplier, context);
		context.popTransform();
		context.meshConsumer().accept(meshBuilder.build());
	}

}
