package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.util.forge.EventHooks;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1311;
import net.minecraft.class_1948;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2794;
import net.minecraft.class_3218;
import net.minecraft.class_5138;
import net.minecraft.class_5483;
import net.minecraft.class_6012;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1948.class)
public class NaturalSpawnerMixin {
    @ModifyReturnValue(method = "mobsAt", at = @At("RETURN"))
    private static class_6012<class_5483.class_1964> tlm$mobsAt(
            class_6012<class_5483.class_1964> original,
            class_3218 level,
            class_5138 structureManager,
            class_2794 generator,
            class_1311 category,
            class_2338 pos,
            class_6880<class_1959> biome
    ) {
        return EventHooks.getPotentialSpawns(level, category, pos, original);
    }
}
