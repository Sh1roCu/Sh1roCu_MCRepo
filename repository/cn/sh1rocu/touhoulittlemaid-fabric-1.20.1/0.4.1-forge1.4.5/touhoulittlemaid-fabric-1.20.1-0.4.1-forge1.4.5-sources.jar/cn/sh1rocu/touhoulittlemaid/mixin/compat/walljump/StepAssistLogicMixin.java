package cn.sh1rocu.touhoulittlemaid.mixin.compat.walljump;

import com.github.tartaricacid.touhoulittlemaid.entity.item.EntityBroom;
import com.jahirtrap.walljump.logic.StepAssistLogic;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(StepAssistLogic.class)
public class StepAssistLogicMixin {
    @Inject(remap = false, method = "doStepAssist", at = @At("HEAD"), cancellable = true)
    private static void tlm$compatBroom(class_746 player, CallbackInfo ci) {
        if (player.method_5854() instanceof EntityBroom) {
            ci.cancel();
        }
    }
}
