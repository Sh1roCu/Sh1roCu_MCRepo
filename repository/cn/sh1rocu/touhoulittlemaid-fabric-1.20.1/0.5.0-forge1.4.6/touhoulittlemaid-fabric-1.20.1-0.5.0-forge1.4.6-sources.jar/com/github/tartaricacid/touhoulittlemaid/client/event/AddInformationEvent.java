package com.github.tartaricacid.touhoulittlemaid.client.event;

import com.github.tartaricacid.touhoulittlemaid.entity.backpack.BackpackManager;
import com.github.tartaricacid.touhoulittlemaid.item.bauble.BaubleManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import java.util.List;

@Environment(EnvType.CLIENT)
public final class AddInformationEvent {
    public static void onRenderTooltips(class_1799 stack, class_1836 type, List<class_2561> lines) {
        if (stack.method_7960()) {
            return;
        }
        if (BaubleManager.getBauble(stack) != null) {
            lines.add(class_2561.method_43470(" "));
            lines.add(class_2561.method_43471("tooltips.touhou_little_maid.bauble.desc"));
            lines.add(class_2561.method_43471("tooltips.touhou_little_maid.bauble.usage").method_27692(class_124.field_1080));
        }
        if (BackpackManager.findBackpack(stack).isPresent()) {
            lines.add(class_2561.method_43470(" "));
            lines.add(class_2561.method_43471("tooltips.touhou_little_maid.backpack.desc"));
            lines.add(class_2561.method_43471("tooltips.touhou_little_maid.backpack.usage").method_27692(class_124.field_1080));
        }
    }
}
