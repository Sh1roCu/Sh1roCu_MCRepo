package com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button;

import com.github.tartaricacid.touhoulittlemaid.TouhouLittleMaid;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_5481;

public class MaidAIChatConfigButton extends class_4185 {
    private static final class_2960 ICON = new class_2960(TouhouLittleMaid.MOD_ID, "textures/gui/maid_ai_chat_config.png");
    private final OnPress leftPress;
    private final OnPress rightPress;
    private boolean leftClicked = false;
    private class_2561 value;

    public MaidAIChatConfigButton(int x, int y, class_2561 title, class_2561 value, OnPress onLeftPressIn, OnPress onRightPressIn) {
//        super(Button.builder(title, b -> {
//        }).pos(x, y).size(164, 13));
        super(x, y, 164, 13, title, b -> {
        }, class_4185.field_40754);
        this.leftPress = onLeftPressIn;
        this.rightPress = onRightPressIn;
        this.value = value;
    }

    public MaidAIChatConfigButton(int x, int y, class_2561 title, class_2561 value, OnPress onPress) {
        this(x, y, title, value, onPress, onPress);
    }

    @Override
    protected void method_48579(class_332 graphics, int pMouseX, int pMouseY, float pPartialTick) {
        class_310 mc = class_310.method_1551();
        RenderSystem.enableDepthTest();
        if (this.field_22762) {
            graphics.method_25290(ICON, this.method_46426(), this.method_46427(), 6, 150, this.field_22758, this.field_22759, 256, 256);
        } else {
            graphics.method_25290(ICON, this.method_46426(), this.method_46427(), 6, 137, this.field_22758, this.field_22759, 256, 256);
        }
        drawButtonText(graphics, mc.field_1772);
    }

    public void setValue(class_2561 value) {
        this.value = value;
    }

    @Override
    protected boolean method_25361(double mouseX, double mouseY) {
        if (!this.field_22763 || !this.field_22764) {
            return false;
        }
        boolean leftClickX = (this.method_46426() + 62) <= mouseX && mouseX <= (this.method_46426() + 72);
        boolean rightClickX = (this.method_46426() + 154) <= mouseX && mouseX <= (this.method_46426() + 164);
        boolean clickY = this.method_46427() <= mouseY && mouseY <= (this.method_46427() + this.method_25364());
        if (leftClickX && clickY) {
            leftClicked = true;
            return true;
        }
        if (rightClickX && clickY) {
            leftClicked = false;
            return true;
        }
        return false;
    }

    @Override
    public void method_25306() {
        if (leftClicked) {
            leftPress.onPress(this);
        } else {
            rightPress.onPress(this);
        }
    }

    public void drawButtonText(class_332 graphics, class_327 font) {
        float scale = 0.75f;

        class_5481 leftText = this.method_25369().method_30937();
        class_5481 rightText = this.value.method_30937();

        float leftTextX = (this.method_46426() + 5) / scale;
        float leftTextY = (this.method_46427() + 4) / scale;
        float rightTextX = (this.method_46426() + 113 - font.method_30880(rightText) * scale / 2f) / scale;
        float rightTextY = (this.method_46427() + 4) / scale;

        graphics.method_51448().method_22903();
        graphics.method_51448().method_22905(scale, scale, 1);
        graphics.method_51430(font, leftText, (int) leftTextX, (int) leftTextY, 0x444444, false);
        graphics.method_51430(font, rightText, (int) rightTextX, (int) rightTextY, 0x55ff55, false);
        graphics.method_51448().method_22909();
    }

    @Environment(EnvType.CLIENT)
    public interface OnPress {
        void onPress(MaidAIChatConfigButton button);
    }
}