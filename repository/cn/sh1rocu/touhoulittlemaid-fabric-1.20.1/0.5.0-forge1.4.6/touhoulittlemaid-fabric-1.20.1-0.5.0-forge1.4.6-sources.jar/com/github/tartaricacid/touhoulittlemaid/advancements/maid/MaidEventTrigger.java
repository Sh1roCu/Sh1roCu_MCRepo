package com.github.tartaricacid.touhoulittlemaid.advancements.maid;

import com.github.tartaricacid.touhoulittlemaid.TouhouLittleMaid;
import com.google.gson.JsonObject;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_195;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3518;
import net.minecraft.class_4558;
import net.minecraft.class_5257;
import net.minecraft.class_5258;
import net.minecraft.class_5267;

public class MaidEventTrigger extends class_4558<MaidEventTrigger.Instance> {
    public static final class_2960 ID = new class_2960(TouhouLittleMaid.MOD_ID, "maid/tamed_maid");

    public static MaidEventTrigger.Instance create(String eventName) {
        return new MaidEventTrigger.Instance(eventName);
    }

    @Override
    protected MaidEventTrigger.Instance method_27854(JsonObject json, class_5258 entityPredicate, class_5257 conditionsParser) {
        String eventName = class_3518.method_15265(json, "event");
        return new MaidEventTrigger.Instance(eventName);
    }

    @Override
    public class_2960 method_794() {
        return ID;
    }

    public void trigger(class_3222 serverPlayer, String eventName) {
        super.method_22510(serverPlayer, instance -> instance.matches(eventName));
    }

    public static class Instance extends class_195 {
        private final String eventName;

        public Instance(String eventName) {
            super(ID, class_5258.field_24388);
            this.eventName = eventName;
        }

        public boolean matches(String eventNameIn) {
            return this.eventName.equals(eventNameIn);
        }

        @Override
        public JsonObject method_807(class_5267 context) {
            JsonObject jsonObject = super.method_807(context);
            jsonObject.addProperty("event", this.eventName);
            return jsonObject;
        }
    }
}
