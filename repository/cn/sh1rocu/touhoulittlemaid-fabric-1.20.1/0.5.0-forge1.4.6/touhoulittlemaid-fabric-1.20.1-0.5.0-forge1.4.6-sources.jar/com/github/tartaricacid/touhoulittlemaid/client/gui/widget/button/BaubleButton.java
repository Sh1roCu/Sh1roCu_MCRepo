package com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button;

import com.github.tartaricacid.touhoulittlemaid.TouhouLittleMaid;
import com.github.tartaricacid.touhoulittlemaid.api.client.gui.ITooltipButton;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public class BaubleButton extends class_4185 implements ITooltipButton {
    private static final class_2960 BAUBLE_BUTTON = new class_2960(TouhouLittleMaid.MOD_ID, "textures/gui/bauble_button.png");
    private final int vStart;
    private final class_2561 tooltip;

    public BaubleButton(int x, int y, boolean isOpen, class_4241 onPress) {
        super(x + 85, y + 97, 54, 63, class_2561.method_43473(), onPress, field_40754);
        this.vStart = isOpen ? this.method_25364() : 0;
        if (isOpen) {
            this.tooltip = class_2561.method_43471("gui.touhou_little_maid.bauble_button.close.desc");
        } else {
            this.tooltip = class_2561.method_43471("gui.touhou_little_maid.bauble_button.open.desc");
        }
    }

    @Override
    public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        this.method_48588(guiGraphics, BAUBLE_BUTTON, this.method_46426(), this.method_46427(),
                0, this.vStart, 0, this.method_25368(), this.method_25364(),
                256, 256);
    }

    @Override
    public boolean isTooltipHovered() {
        return this.method_49606();
    }

    @Override
    public void renderTooltip(class_332 graphics, class_310 mc, int mouseX, int mouseY) {
        graphics.method_51438(mc.field_1772, this.tooltip, mouseX, mouseY);
    }
}
