package com.github.tartaricacid.touhoulittlemaid.client.animation.special;

import cn.sh1rocu.touhoulittlemaid.mixin.accessor.MinecraftAccessor;
import com.github.tartaricacid.simplebedrockmodel.client.bedrock.model.BedrockPart;
import com.github.tartaricacid.touhoulittlemaid.api.animation.ICustomAnimation;
import com.github.tartaricacid.touhoulittlemaid.api.animation.IModelRenderer;
import java.util.HashMap;
import net.minecraft.class_1268;
import net.minecraft.class_1308;
import net.minecraft.class_1835;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class TridentAnimation implements ICustomAnimation<class_1308> {
    @Override
    public void setRotationAngles(class_1308 mob, HashMap<String, ? extends IModelRenderer> models,
                                  float limbSwing, float limbSwingAmount, float ageInTicks,
                                  float netHeadYaw, float headPitch) {
        if (!mob.method_6113() && mob.method_6115() && mob.method_6058() == class_1268.field_5808
                && mob.method_6047().method_7909() instanceof class_1835) {
            int tick = mob.method_6048();
            BedrockPart armRight = ICustomAnimation.getPartOrNull(models, "armRight");
            if (armRight != null) {
                class_310 minecraft = class_310.method_1551();
                float partialTick = minecraft.method_1493() ? ((MinecraftAccessor) minecraft).tlm$getPausePartialTick() : minecraft.method_1488();
                float rot = (tick + partialTick) / 10f;
                armRight.xRot = (armRight.getInitRotX() - 80) - Math.min(rot, class_3532.field_29844 / 2) - 10;
                armRight.zRot = -Math.min(rot, class_3532.field_29844 / 6);
            }
        }
    }
}
