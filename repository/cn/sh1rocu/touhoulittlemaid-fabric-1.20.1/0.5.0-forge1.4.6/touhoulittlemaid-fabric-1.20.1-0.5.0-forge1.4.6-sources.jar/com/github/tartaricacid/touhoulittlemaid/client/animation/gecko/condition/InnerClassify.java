package com.github.tartaricacid.touhoulittlemaid.client.animation.gecko.condition;

import com.github.tartaricacid.touhoulittlemaid.api.entity.IMaid;
import com.github.tartaricacid.touhoulittlemaid.item.ItemHakureiGohei;
import net.minecraft.class_1268;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1819;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_4537;
import net.minecraft.world.item.*;

public class InnerClassify {
    private static final String EMPTY = "";

    public static String doClassifyTest(String extraPre, IMaid maid, class_1268 hand) {
        class_1799 itemInHand = maid.asEntity().method_5998(hand);
        class_1792 item = itemInHand.method_7909();
        if (item instanceof ItemHakureiGohei) {
            return extraPre + "gohei";
        }
        if (item instanceof class_1829) {
            return extraPre + "sword";
        }
        if (item instanceof class_1743) {
            return extraPre + "axe";
        }
        if (item instanceof class_1810) {
            return extraPre + "pickaxe";
        }
        if (item instanceof class_1821) {
            return extraPre + "shovel";
        }
        if (item instanceof class_1794) {
            return extraPre + "hoe";
        }
        if (item instanceof class_1819) {
            return extraPre + "shield";
        }
        if (item instanceof class_4537) {
            return extraPre + "throwable_potion";
        }
        return EMPTY;
    }
}
