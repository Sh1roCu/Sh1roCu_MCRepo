package com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button;

import com.github.tartaricacid.touhoulittlemaid.TouhouLittleMaid;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5250;

public class ModelDetailsButton extends TouhouStateSwitchButton {
    private static final class_2960 BUTTON_TEXTURE = new class_2960(TouhouLittleMaid.MOD_ID, "textures/gui/skin_detail.png");
    private final Consumer<Boolean> onClick;
    private final class_5250 name;

    public ModelDetailsButton(int xIn, int yIn, String langKey, Consumer<Boolean> onClick) {
        super(xIn, yIn, 128, 12, false);
        this.name = class_2561.method_43471(langKey);
        this.onClick = onClick;
        this.initTextureValues(0, 0, 128, 12, BUTTON_TEXTURE);
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
        super.method_48579(graphics, mouseX, mouseY, partialTicks);
        graphics.method_51439(class_310.method_1551().field_1772, name, this.method_46426() + 14, this.method_46427() + 2, 0xffffffff, false);
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        this.isStateTriggered = !this.isStateTriggered;
        onClick.accept(this.isStateTriggered);
    }
}
