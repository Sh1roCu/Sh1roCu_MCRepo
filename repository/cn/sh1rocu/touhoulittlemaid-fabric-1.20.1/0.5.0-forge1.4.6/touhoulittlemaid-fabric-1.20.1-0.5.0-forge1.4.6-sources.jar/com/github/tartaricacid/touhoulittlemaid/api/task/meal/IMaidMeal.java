package com.github.tartaricacid.touhoulittlemaid.api.task.meal;

import com.github.tartaricacid.touhoulittlemaid.datagen.tag.TagItem;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public interface IMaidMeal {
    static boolean isBlockList(class_1799 food, List<String> blockList) {
        // 先过 tag 黑名单
        if (food.method_31573(TagItem.MAID_EAT_BLOCKLIST_ITEM)) {
            return true;
        }
        class_2960 key = class_7923.field_41178.method_10221(food.method_7909());
        return key == class_7923.field_41178.method_10137()|| blockList.contains(key.toString());
    }

    /**
     * 女仆能否吃下这个物品
     */
    boolean canMaidEat(EntityMaid maid, class_1799 stack, class_1268 hand);

    /**
     * 女仆吃物品时的行为
     */
    void onMaidEat(EntityMaid maid, class_1799 stack, class_1268 hand);
}
