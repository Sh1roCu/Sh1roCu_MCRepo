package com.github.tartaricacid.touhoulittlemaid.advancements.altar;

import com.github.tartaricacid.touhoulittlemaid.TouhouLittleMaid;
import com.google.gson.JsonObject;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_195;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3518;
import net.minecraft.class_4558;
import net.minecraft.class_5257;
import net.minecraft.class_5258;
import net.minecraft.class_5267;

public class AltarCraftTrigger extends class_4558<AltarCraftTrigger.Instance> {
    public static final class_2960 ID = new class_2960(TouhouLittleMaid.MOD_ID, "altar/altar_craft");

    @Override
    protected AltarCraftTrigger.Instance method_27854(JsonObject json, class_5258 entityPredicate, class_5257 conditionsParser) {
        class_2960 recipeId = new class_2960(class_3518.method_15265(json, "recipe_id"));
        return new AltarCraftTrigger.Instance(entityPredicate, recipeId);
    }

    @Override
    public class_2960 method_794() {
        return ID;
    }

    public void trigger(class_3222 serverPlayer, class_2960 recipeId) {
        super.method_22510(serverPlayer, instance -> instance.matches(recipeId));
    }

    public static class Instance extends class_195 {
        private final class_2960 recipeId;

        public Instance(class_5258 player, class_2960 recipeId) {
            super(ID, player);
            this.recipeId = recipeId;
        }

        public static AltarCraftTrigger.Instance recipe(class_2960 recipeId) {
            return new AltarCraftTrigger.Instance(class_5258.field_24388, recipeId);
        }

        public boolean matches(class_2960 recipeIdIn) {
            return this.recipeId.equals(recipeIdIn);
        }

        @Override
        public JsonObject method_807(class_5267 context) {
            JsonObject jsonObject = super.method_807(context);
            jsonObject.addProperty("recipe_id", this.recipeId.toString());
            return jsonObject;
        }
    }
}
