package com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_344;

@Environment(EnvType.CLIENT)
public class ImageButtonWithId extends class_344 {
    private final int index;

    public ImageButtonWithId(int index, int xIn, int yIn, int widthIn, int heightIn, int xTexStartIn, int yTexStartIn, int yDiffTextIn, class_2960 resourceLocationIn, class_4241 onPressIn) {
        this(index, xIn, yIn, widthIn, heightIn, xTexStartIn, yTexStartIn, yDiffTextIn, resourceLocationIn, 256, 256, onPressIn);
    }

    public ImageButtonWithId(int index, int xIn, int yIn, int widthIn, int heightIn, int xTexStartIn, int yTexStartIn, int yDiffTextIn, class_2960 resourceLocationIn, int textureWidth, int textureHeight, class_4241 onPressIn) {
        this(index, xIn, yIn, widthIn, heightIn, xTexStartIn, yTexStartIn, yDiffTextIn, resourceLocationIn, textureWidth, textureHeight, onPressIn, class_2561.method_43473());
    }

    public ImageButtonWithId(int index, int x, int y, int width, int height, int xTexStart, int yTexStart, int yDiffText, class_2960 resourceLocation, int textureWidth, int textureHeight, class_4241 onPress, class_2561 title) {
        super(x, y, width, height, xTexStart, yTexStart, yDiffText, resourceLocation, textureWidth, textureHeight, onPress, title);
        this.index = index;
    }

    public int getIndex() {
        return index;
    }
}
