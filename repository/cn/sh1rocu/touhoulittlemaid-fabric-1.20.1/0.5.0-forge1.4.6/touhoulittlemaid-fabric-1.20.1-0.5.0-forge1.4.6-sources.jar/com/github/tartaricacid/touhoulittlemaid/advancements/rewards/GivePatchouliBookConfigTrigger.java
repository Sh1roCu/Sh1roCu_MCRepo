package com.github.tartaricacid.touhoulittlemaid.advancements.rewards;

import com.github.tartaricacid.touhoulittlemaid.TouhouLittleMaid;
import com.github.tartaricacid.touhoulittlemaid.config.subconfig.MiscConfig;
import com.google.gson.JsonObject;
import net.minecraft.class_195;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5257;
import net.minecraft.class_5258;

public class GivePatchouliBookConfigTrigger extends class_4558<GivePatchouliBookConfigTrigger.Instance> {
    public static final class_2960 ID = new class_2960(TouhouLittleMaid.MOD_ID, "give_patchouli_book_config");

    @Override
    protected GivePatchouliBookConfigTrigger.Instance method_27854(JsonObject json, class_5258 entityPredicate, class_5257 conditionsParser) {
        return new GivePatchouliBookConfigTrigger.Instance(entityPredicate);
    }

    @Override
    public class_2960 method_794() {
        return ID;
    }


    public void trigger(class_3222 serverPlayer) {
        super.method_22510(serverPlayer, instance -> MiscConfig.GIVE_PATCHOULI_BOOK.get());
    }

    public static class Instance extends class_195 {
        public Instance(class_5258 player) {
            super(ID, player);
        }
    }
}
