package com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.config;

import com.github.tartaricacid.touhoulittlemaid.TouhouLittleMaid;
import com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.AbstractMaidContainerGui;
import com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button.MaidConfigButton;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.MaidConfigManager;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.PickType;
import com.github.tartaricacid.touhoulittlemaid.inventory.container.config.MaidConfigContainer;
import com.github.tartaricacid.touhoulittlemaid.network.message.MaidSubConfigMessage;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import org.anti_ad.mc.ipn.api.IPNButton;
import org.anti_ad.mc.ipn.api.IPNGuiHint;
import org.anti_ad.mc.ipn.api.IPNPlayerSideOnly;

@IPNPlayerSideOnly
@IPNGuiHint(button = IPNButton.SORT, horizontalOffset = -36, bottom = -12)
@IPNGuiHint(button = IPNButton.SORT_COLUMNS, horizontalOffset = -24, bottom = -24)
@IPNGuiHint(button = IPNButton.SORT_ROWS, horizontalOffset = -12, bottom = -36)
@IPNGuiHint(button = IPNButton.SHOW_EDITOR, horizontalOffset = -5)
@IPNGuiHint(button = IPNButton.SETTINGS, horizontalOffset = -5)
public class MaidConfigContainerGui extends AbstractMaidContainerGui<MaidConfigContainer> {
    private static final class_2960 ICON = new class_2960(TouhouLittleMaid.MOD_ID, "textures/gui/maid_gui_config.png");
    private final MaidConfigManager.SyncNetwork syncNetwork;

    public MaidConfigContainerGui(MaidConfigContainer screenContainer, class_1661 inv, class_2561 titleIn) {
        super(screenContainer, inv, titleIn);
        this.syncNetwork = getMaid().getConfigManager().getSyncNetwork();
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTicks, int x, int y) {
        super.method_2389(graphics, partialTicks, x, y);
        graphics.method_25302(ICON, field_2776 + 80, field_2800 + 28, 0, 0, field_2792, field_2779);
    }

    @Override
    protected void initAdditionWidgets() {
        int buttonLeft = field_2776 + 86;
        int buttonTop = field_2800 + 52;

        this.method_37063(new MaidConfigButton(buttonLeft, buttonTop,
                class_2561.method_43471("gui.touhou_little_maid.maid_config.show_backpack"),
                class_2561.method_43471("gui.touhou_little_maid.maid_config.value." + this.syncNetwork.showBackpack()),
                button -> {
                    this.syncNetwork.setShowBackpack(!this.syncNetwork.showBackpack());
                    button.setValue(class_2561.method_43471("gui.touhou_little_maid.maid_config.value." + this.syncNetwork.showBackpack()));
                    ClientPlayNetworking.send(MaidSubConfigMessage.ID, MaidSubConfigMessage.encode(this.maid.method_5628(), this.syncNetwork));
                }
        ));
        buttonTop += 13;

        this.method_37063(new MaidConfigButton(buttonLeft, buttonTop,
                class_2561.method_43471("gui.touhou_little_maid.maid_config.show_back_item"),
                class_2561.method_43471("gui.touhou_little_maid.maid_config.value." + this.syncNetwork.showBackItem()),
                button -> {
                    this.syncNetwork.setShowBackItem(!this.syncNetwork.showBackItem());
                    button.setValue(class_2561.method_43471("gui.touhou_little_maid.maid_config.value." + this.syncNetwork.showBackItem()));
                    ClientPlayNetworking.send(MaidSubConfigMessage.ID, MaidSubConfigMessage.encode(this.maid.method_5628(), this.syncNetwork));
                }
        ));
        buttonTop += 13;

        this.method_37063(new MaidConfigButton(buttonLeft, buttonTop,
                class_2561.method_43471("gui.touhou_little_maid.maid_config.show_chat_bubble"),
                class_2561.method_43471("gui.touhou_little_maid.maid_config.value." + this.syncNetwork.showChatBubble()),
                button -> {
                    this.syncNetwork.setShowChatBubble(!this.syncNetwork.showChatBubble());
                    button.setValue(class_2561.method_43471("gui.touhou_little_maid.maid_config.value." + this.syncNetwork.showChatBubble()));
                    ClientPlayNetworking.send(MaidSubConfigMessage.ID, MaidSubConfigMessage.encode(this.maid.method_5628(), this.syncNetwork));
                }
        ));
        buttonTop += 13;


        this.method_37063(new MaidConfigButton(buttonLeft, buttonTop,
                class_2561.method_43471("gui.touhou_little_maid.maid_config.sound_frequency"),
                class_2561.method_43470(Math.round(this.syncNetwork.soundFreq() * 100) + "%").method_27692(class_124.field_1054),
                button -> {
                    this.syncNetwork.setSoundFreq(this.syncNetwork.soundFreq() - 0.1f);
                    button.setValue(class_2561.method_43470(Math.round(this.syncNetwork.soundFreq() * 100) + "%").method_27692(class_124.field_1054));
                    ClientPlayNetworking.send(MaidSubConfigMessage.ID, MaidSubConfigMessage.encode(this.maid.method_5628(), this.syncNetwork));
                },
                button -> {
                    this.syncNetwork.setSoundFreq(this.syncNetwork.soundFreq() + 0.1f);
                    button.setValue(class_2561.method_43470(Math.round(this.syncNetwork.soundFreq() * 100) + "%").method_27692(class_124.field_1054));
                    ClientPlayNetworking.send(MaidSubConfigMessage.ID, MaidSubConfigMessage.encode(this.maid.method_5628(), this.syncNetwork));
                }
        ));
        buttonTop += 13;

        this.method_37063(new MaidConfigButton(buttonLeft, buttonTop,
                class_2561.method_43471("gui.touhou_little_maid.maid_config.pick_type"),
                class_2561.method_43471(PickType.getTransKey(this.syncNetwork.pickType())).method_27692(class_124.field_1079),
                button -> {
                    this.syncNetwork.setPickType(PickType.getPreviousPickType(this.syncNetwork.pickType()));
                    button.setValue(class_2561.method_43471(PickType.getTransKey(this.syncNetwork.pickType())).method_27692(class_124.field_1079));
                    ClientPlayNetworking.send(MaidSubConfigMessage.ID, MaidSubConfigMessage.encode(this.maid.method_5628(), this.syncNetwork));
                },
                button -> {
                    this.syncNetwork.setPickType(PickType.getNextPickType(this.syncNetwork.pickType()));
                    button.setValue(class_2561.method_43471(PickType.getTransKey(this.syncNetwork.pickType())).method_27692(class_124.field_1079));
                    ClientPlayNetworking.send(MaidSubConfigMessage.ID, MaidSubConfigMessage.encode(this.maid.method_5628(), this.syncNetwork));
                }
        ));
        buttonTop += 13;

        this.method_37063(new MaidConfigButton(buttonLeft, buttonTop,
                class_2561.method_43471("gui.touhou_little_maid.maid_config.open_door"),
                class_2561.method_43471("gui.touhou_little_maid.maid_config.value." + this.syncNetwork.openDoor()),
                button -> {
                    this.syncNetwork.setOpenDoor(!this.syncNetwork.openDoor());
                    button.setValue(class_2561.method_43471("gui.touhou_little_maid.maid_config.value." + this.syncNetwork.openDoor()));
                    ClientPlayNetworking.send(MaidSubConfigMessage.ID, MaidSubConfigMessage.encode(this.maid.method_5628(), this.syncNetwork));
                }
        ));
        buttonTop += 13;

        this.method_37063(new MaidConfigButton(buttonLeft, buttonTop,
                class_2561.method_43471("gui.touhou_little_maid.maid_config.open_fence_gate"),
                class_2561.method_43471("gui.touhou_little_maid.maid_config.value." + this.syncNetwork.openFenceGate()),
                button -> {
                    this.syncNetwork.setOpenFenceGate(!this.syncNetwork.openFenceGate());
                    button.setValue(class_2561.method_43471("gui.touhou_little_maid.maid_config.value." + this.syncNetwork.openFenceGate()));
                    ClientPlayNetworking.send(MaidSubConfigMessage.ID, MaidSubConfigMessage.encode(this.maid.method_5628(), this.syncNetwork));
                }
        ));
        buttonTop += 13;

        this.method_37063(new MaidConfigButton(buttonLeft, buttonTop,
                class_2561.method_43471("gui.touhou_little_maid.maid_config.active_climbing"),
                class_2561.method_43471("gui.touhou_little_maid.maid_config.value." + this.syncNetwork.activeClimbing()),
                button -> {
                    this.syncNetwork.setActiveClimbing(!this.syncNetwork.activeClimbing());
                    button.setValue(class_2561.method_43471("gui.touhou_little_maid.maid_config.value." + this.syncNetwork.activeClimbing()));
                    ClientPlayNetworking.send(MaidSubConfigMessage.ID, MaidSubConfigMessage.encode(this.maid.method_5628(), this.syncNetwork));
                }
        ));
    }

    @Override
    protected void renderAddition(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
        graphics.method_27534(field_22793, class_2561.method_43471("gui.touhou_little_maid.button.maid_config"), field_2776 + 167, field_2800 + 41, 0xFFFFFF);
    }
}