package com.github.tartaricacid.touhoulittlemaid.block;

import com.github.tartaricacid.touhoulittlemaid.entity.favorability.Type;
import com.github.tartaricacid.touhoulittlemaid.tileentity.TileEntityKeyboard;
import javax.annotation.Nullable;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;

public class BlockKeyboard extends BlockJoy {
    public static final class_265 SHAPE = class_2248.method_9541(4, 0, 4, 12, 10, 12);

    @Override
    protected class_243 sitPosition() {
        return new class_243(0.5, 0.625, 0.5);
    }

    @Override
    protected int sitYRot() {
        return 0;
    }

    @Override
    protected String getTypeName() {
        return Type.KEYBOARD.getTypeName();
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pPos, class_2680 pState) {
        return new TileEntityKeyboard(pPos, pState);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 worldIn, class_2338 pos, class_3726 context) {
        return SHAPE;
    }
}
