package com.github.tartaricacid.touhoulittlemaid.client.gui.mod;

import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_407;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5489;
import org.apache.commons.lang3.StringUtils;

public class ClothConfigScreen extends class_437 {
    private final String clothConfigUrl = "https://www.curseforge.com/minecraft/mc-mods/cloth-config";
    private final class_437 lastScreen;
    private class_5489 message = class_5489.field_26528;

    protected ClothConfigScreen(class_437 lastScreen) {
        super(class_2561.method_43470("Cloth Config API"));
        this.lastScreen = lastScreen;
    }

    public static void open() {
        class_310.method_1551().method_1507(new ClothConfigScreen(class_310.method_1551().field_1755));
    }

    @Override
    protected void method_25426() {
        int posX = (this.field_22789 - 200) / 2;
        int posY = this.field_22790 / 2;
        this.message = class_5489.method_30890(this.field_22793, class_2561.method_43471("gui.touhou_little_maid.cloth_config_warning.tips"), 300);
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.touhou_little_maid.cloth_config_warning.download"), b -> openUrl(clothConfigUrl)).method_46434(posX, posY - 15, 200, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_5244.field_24339, (pressed) -> class_310.method_1551().method_1507(this.lastScreen)).method_46434(posX, posY + 50, 200, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 graphics, int pMouseX, int pMouseY, float pPartialTick) {
        method_25420(graphics);
        this.message.method_30888(graphics, this.field_22789 / 2, 80);
        super.method_25394(graphics, pMouseX, pMouseY, pPartialTick);
    }

    private void openUrl(String url) {
        if (StringUtils.isNotBlank(url) && field_22787 != null) {
            field_22787.method_1507(new class_407(yes -> {
                if (yes) {
                    class_156.method_668().method_670(url);
                }
                field_22787.method_1507(this);
            }, url, true));
        }
    }

//    public static void registerNoClothConfigPage() {
//        if (!FabricLoader.getInstance().isModLoaded(CompatRegistry.CLOTH_CONFIG)) {
//            ModLoadingContext.get().registerExtensionPoint(ConfigScreenHandler.ConfigScreenFactory.class, () ->
//                    new ConfigScreenHandler.ConfigScreenFactory((client, parent) -> new ClothConfigScreen(parent)));
//        }
//    }
}
