package com.github.tartaricacid.touhoulittlemaid.block;

import com.github.tartaricacid.touhoulittlemaid.config.subconfig.MiscConfig;
import com.github.tartaricacid.touhoulittlemaid.util.VoxelShapeUtils;
import net.minecraft.class_124;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2756;
import net.minecraft.class_3612;
import net.minecraft.class_3726;
import net.minecraft.class_6088;
import net.minecraft.world.level.block.*;
import javax.annotation.Nullable;
import java.util.List;

public class BlockScarecrow extends class_2383 {
    public static final class_2754<class_2756> HALF = class_2741.field_12533;
    protected static final class_265 LOWER_AABB = class_259.method_17786(
            class_2248.method_9541(1, 0, 1, 15, 4, 15),
            class_2248.method_9541(2, 4, 2, 14, 8, 14),
            class_2248.method_9541(4.5, 8, 4.5, 11.5, 16, 11.5)
    );
    protected static final class_265 UPPER_AABB_NORTH = class_2248.method_9541(4, 0, 7.5, 12, 7.5, 13.5);
    protected static final class_265 UPPER_AABB_SOUTH = VoxelShapeUtils.rotateHorizontal(UPPER_AABB_NORTH, class_2350.field_11035);
    protected static final class_265 UPPER_AABB_EAST = VoxelShapeUtils.rotateHorizontal(UPPER_AABB_NORTH, class_2350.field_11034);
    protected static final class_265 UPPER_AABB_WEST = VoxelShapeUtils.rotateHorizontal(UPPER_AABB_NORTH, class_2350.field_11039);


    public BlockScarecrow() {
        super(class_2251.method_9637().method_9626(class_2498.field_11535).method_9626(class_2498.field_11535).method_9632(0.2F).method_22488());
        this.method_9590(this.field_10647.method_11664().method_11657(HALF, class_2756.field_12607).method_11657(field_11177, class_2350.field_11043));
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 currentPos, class_2338 neighborPos) {
        class_2756 currentHalf = state.method_11654(HALF);
        boolean isLower = currentHalf == class_2756.field_12607 && direction == class_2350.field_11036;
        boolean isUpper = currentHalf == class_2756.field_12609 && direction == class_2350.field_11033;
        if (isLower || isUpper) {
            if (neighborState.method_27852(this) && neighborState.method_11654(HALF) != currentHalf) {
                return state.method_11657(field_11177, neighborState.method_11654(field_11177));
            }
            return class_2246.field_10124.method_9564();
        }
        return super.method_9559(state, direction, neighborState, level, currentPos, neighborPos);
    }

    @Override
    public void method_9576(class_1937 level, class_2338 pos, class_2680 state, class_1657 player) {
        // 阻止创造模式破坏掉落双份物品
        if (!level.field_9236 && player.method_7337()) {
            class_2756 half = state.method_11654(HALF);
            if (half == class_2756.field_12609) {
                class_2338 belowPos = pos.method_10074();
                class_2680 belowState = level.method_8320(belowPos);
                if (belowState.method_27852(state.method_26204()) && belowState.method_11654(HALF) == class_2756.field_12607) {
                    class_2680 empty = belowState.method_26227().method_39360(class_3612.field_15910) ? class_2246.field_10382.method_9564() : class_2246.field_10124.method_9564();
                    level.method_8652(belowPos, empty, class_2248.field_31036 | class_2248.field_31032);
                    level.method_8444(player, class_6088.field_31144, belowPos, class_2248.method_9507(belowState));
                }
            }
        }
        super.method_9576(level, pos, state, player);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2338 clickedPos = context.method_8037();
        class_1937 level = context.method_8045();
        class_2338 abovePos = clickedPos.method_10084();
        if (clickedPos.method_10264() < level.method_31600() - 1 && level.method_8320(abovePos).method_26166(context)) {
            class_2350 horizontalDirection = context.method_8042();
            return this.method_9564().method_11657(field_11177, horizontalDirection).method_11657(HALF, class_2756.field_12607);
        }
        return null;
    }

    @Override
    public void method_9567(class_1937 level, class_2338 pos, class_2680 state, class_1309 placer, class_1799 stack) {
        level.method_8652(pos.method_10084(), state.method_11657(HALF, class_2756.field_12609), class_2248.field_31036);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(HALF, field_11177);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 worldIn, class_2338 pos, class_3726 context) {
        class_2756 blockHalf = state.method_11654(HALF);
        if (blockHalf == class_2756.field_12607) {
            return LOWER_AABB;
        }
        class_2350 direction = state.method_11654(field_11177);
        switch (direction) {
            case field_11035 -> {
                return UPPER_AABB_SOUTH;
            }
            case field_11034 -> {
                return UPPER_AABB_EAST;
            }
            case field_11039 -> {
                return UPPER_AABB_WEST;
            }
            default -> {
                return UPPER_AABB_NORTH;
            }
        }
    }

    @Override
    public void method_9568(class_1799 stack, @Nullable class_1922 level, List<class_2561> tooltip, class_1836 flag) {
        int range = MiscConfig.SCARECROW_RANGE.get();
        tooltip.add(class_2561.method_43469("tooltips.touhou_little_maid.scarecrow.desc", range, range).method_27692(class_124.field_1080));
    }
}
