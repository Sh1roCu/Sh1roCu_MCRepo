package com.github.tartaricacid.touhoulittlemaid.client.gui.mod;

import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_407;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_5489;
import org.apache.commons.lang3.StringUtils;

/**
 * Refer: https://github.com/TeamTwilight/twilightforest/blob/1.20.x/src/main/java/twilightforest/client/OptifineWarningScreen.java
 */
public class OptifineScreen extends class_437 {
    public final class_437 lastScreen;
    private final class_5250 text = class_2561.method_43471("gui.touhou_little_maid.optifine_warning.text");
    private final String embeddiumUrl = "https://www.curseforge.com/minecraft/mc-mods/embeddium";
    private final String oculusUrl = "https://www.curseforge.com/minecraft/mc-mods/oculus";
    private class_4185 exitButton;
    private int ticksUntilEnable = 20 * 10;
    private class_5489 message = class_5489.field_26528;

    public OptifineScreen(class_437 lastScreen) {
        super(class_2561.method_43471("gui.touhou_little_maid.optifine_warning.title").method_27692(class_124.field_1079).method_27692(class_124.field_1073));
        this.lastScreen = lastScreen;
    }

    @Override
    public class_2561 method_25435() {
        return class_5244.method_37111(super.method_25435(), text);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.touhou_little_maid.optifine_warning.embeddium"), b -> openUrl(embeddiumUrl)).method_46434(this.field_22789 / 2 - 155, this.field_22790 * 3 / 4 - 15, 150, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.touhou_little_maid.optifine_warning.oculus"), b -> openUrl(oculusUrl)).method_46434(this.field_22789 / 2 + 5, this.field_22790 * 3 / 4 - 15, 150, 20).method_46431());
        this.exitButton = this.method_37063(class_4185.method_46430(class_5244.field_24338, (pressed) -> class_310.method_1551().method_1507(this.lastScreen)).method_46434(this.field_22789 / 2 - 75, this.field_22790 * 3 / 4 + 25, 150, 20).method_46431());
        this.exitButton.field_22763 = false;
        this.message = class_5489.method_30890(this.field_22793, text, this.field_22789 - 50);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
        this.method_25420(graphics);
        graphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 30, 16777215);
        this.message.method_30888(graphics, this.field_22789 / 2, 70);
        super.method_25394(graphics, mouseX, mouseY, partialTicks);
    }

    @Override
    public void method_25393() {
        super.method_25393();
        if (--this.ticksUntilEnable <= 0) {
            this.exitButton.field_22763 = true;
        }
    }

    @Override
    public boolean method_25422() {
        return this.ticksUntilEnable <= 0;
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(this.lastScreen);
    }

    private void openUrl(String url) {
        if (StringUtils.isNotBlank(url) && field_22787 != null) {
            field_22787.method_1507(new class_407(yes -> {
                if (yes) {
                    class_156.method_668().method_670(url);
                }
                field_22787.method_1507(this);
            }, url, true));
        }
    }
}
