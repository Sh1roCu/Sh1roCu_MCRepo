package cn.sh1rocu.touhoulittlemaid.mixin.client;

import cn.sh1rocu.touhoulittlemaid.api.extension.IBlock;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_638;
import net.minecraft.class_702;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin(class_702.class)
public class ParticleEngineMixin {
    @Shadow
    protected class_638 level;

    @ModifyExpressionValue(
            method = "destroy",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/state/BlockState;shouldSpawnParticlesOnBreak()Z"
            )
    )
    private boolean tlm$addDestroyEffects(boolean original, class_2338 blockPos, class_2680 blockState) {
        if (blockState.method_26204() instanceof IBlock block) {
            if (block.tlm$addDestroyEffects(blockState, this.level, blockPos, (class_702) (Object) this)) {
                return false;
            }
        }
        return original;
    }
}