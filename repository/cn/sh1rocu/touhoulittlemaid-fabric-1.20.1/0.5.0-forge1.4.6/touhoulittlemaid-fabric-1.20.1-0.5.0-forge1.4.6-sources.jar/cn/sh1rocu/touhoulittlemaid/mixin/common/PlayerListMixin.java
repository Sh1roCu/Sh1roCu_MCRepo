package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.api.event.PlayerLoggedInEvent;
import net.minecraft.class_2535;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3324.class)
public abstract class PlayerListMixin {
    @Inject(method = "placeNewPlayer", at = @At("TAIL"))
    private void tlm$playerLoggedIn(class_2535 netManager, class_3222 player, CallbackInfo ci) {
        PlayerLoggedInEvent event = new PlayerLoggedInEvent(player);
        PlayerLoggedInEvent.CALLBACK.invoker().post(event);
    }
}