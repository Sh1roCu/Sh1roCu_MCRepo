package cn.sh1rocu.touhoulittlemaid.api.extension;

import com.github.tartaricacid.touhoulittlemaid.TouhouLittleMaid;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;
import net.minecraft.class_2960;
import net.minecraft.class_8042;
import java.util.List;

// Porting_Lib
public interface IEntityAdditionalSpawnData {
    class_2960 EXTRA_DATA_PACKET = new class_2960(TouhouLittleMaid.MOD_ID, "extra_entity_spawn_data");

    void readSpawnData(class_2540 buf);

    void writeSpawnData(class_2540 buf);

    static class_2596<class_2602> getEntitySpawningPacket(class_1297 entity) {
        return getEntitySpawningPacket(entity, new class_2604(entity));
    }

    static class_2596<class_2602> getEntitySpawningPacket(class_1297 entity, class_2596<class_2602> base) {
        if (entity instanceof IEntityAdditionalSpawnData extra) {
            class_2540 buf = PacketByteBufs.create();
            buf.method_10804(entity.method_5628());
            extra.writeSpawnData(buf);
            class_2596<class_2602> extraPacket = ServerPlayNetworking.createS2CPacket(IEntityAdditionalSpawnData.EXTRA_DATA_PACKET, buf);
            return new class_8042(List.of(base, extraPacket));
        }
        return base;
    }
}