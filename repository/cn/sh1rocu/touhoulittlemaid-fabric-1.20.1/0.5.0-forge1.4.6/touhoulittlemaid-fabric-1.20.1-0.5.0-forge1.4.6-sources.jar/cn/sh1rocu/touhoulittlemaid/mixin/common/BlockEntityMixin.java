package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.api.extension.IBlockEntityPersistentData;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2586.class)
public abstract class BlockEntityMixin implements IBlockEntityPersistentData {
    @Unique
    private class_2487 tlm$persistentData = null;

    @Inject(method = "load", at = @At("RETURN"))
    private void tlm$loadAdditional(class_2487 tag, CallbackInfo ci) {
        if (tag.method_10573(PERSISTENT_DATA, class_2520.field_33260)) {
            tlm$persistentData = tag.method_10562(PERSISTENT_DATA);
        }
    }

    @Inject(method = "saveAdditional", at = @At("RETURN"))
    private void tlm$saveAdditional(class_2487 tag, CallbackInfo ci) {
        if (tlm$persistentData != null) {
            tag.method_10566(PERSISTENT_DATA, tlm$persistentData);
        }
    }

    @Override
    public class_2487 tlm$getPersistentData() {
        if (tlm$persistentData == null) {
            tlm$persistentData = new class_2487();
        }
        return tlm$persistentData;
    }
}