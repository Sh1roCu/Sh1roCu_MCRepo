package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.util.forge.CraftingHelper;
import com.google.gson.JsonObject;
import net.minecraft.class_1799;
import net.minecraft.class_1869;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1869.class)
public class ShapedRecipeMixin {
    @Inject(method = "itemStackFromJson", at = @At("HEAD"), cancellable = true)
    private static void tlm$$itemStackFromJson(JsonObject json, CallbackInfoReturnable<class_1799> cir) {
        if (json.has("nbt")) {
            cir.setReturnValue(CraftingHelper.getItemStack(json, true, true));
        }
    }
}