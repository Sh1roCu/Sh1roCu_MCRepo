package cn.sh1rocu.touhoulittlemaid.mixin.common;


import cn.sh1rocu.touhoulittlemaid.util.forge.EventHooks;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import net.minecraft.class_1536;
import net.minecraft.class_239;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1536.class)
public class FishingHookMixin {
    @WrapWithCondition(method = "checkCollision", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/projectile/FishingHook;onHit(Lnet/minecraft/world/phys/HitResult;)V"))
    private boolean tlm$onImpact(class_1536 projectile, class_239 result) {
        if (result.method_17783() == class_239.class_240.field_1333)
            return true;
        return !EventHooks.onProjectileImpact(projectile, result);
    }
}