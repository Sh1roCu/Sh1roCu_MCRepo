package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.api.extension.IEntity;
import cn.sh1rocu.touhoulittlemaid.util.forge.EventHooks;
import net.minecraft.class_1297;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public class EntityMixin {
    @Shadow
    @Nullable
    private class_1297 vehicle;

    @Inject(method = "setPosRaw", at = @At("TAIL"))
    private void tlm$setPosRaw(double x, double y, double z, CallbackInfo ci) {
        class_1297 self = (class_1297) (Object) this;
        if (self instanceof IEntity entity && entity.isAddedToWorld() && !self.field_6002.field_9236 && !self.method_31481())
            //强加载区块
            self.field_6002.method_8497((int) Math.floor(x) >> 4, (int) Math.floor(z) >> 4);
    }

    @Inject(
            method = "startRiding(Lnet/minecraft/world/entity/Entity;Z)Z",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/Entity;canRide(Lnet/minecraft/world/entity/Entity;)Z",
                    shift = At.Shift.BEFORE
            ),
            cancellable = true
    )
    public void tlm$startRiding(class_1297 entity, boolean bl, CallbackInfoReturnable<Boolean> cir) {
        if (!EventHooks.canMountEntity((class_1297) (Object) this, entity, true))
            cir.setReturnValue(false);
    }

    @Inject(method = "removeVehicle", at = @At(value = "CONSTANT", args = "nullValue=true"), cancellable = true)
    public void tlm$removeRidingEntity(CallbackInfo ci) {
        if (!EventHooks.canMountEntity((class_1297) (Object) this, this.vehicle, false))
            ci.cancel();
    }
}
