package cn.sh1rocu.touhoulittlemaid.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.Map;
import net.minecraft.class_1263;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_2960;
import net.minecraft.class_3956;

@Mixin(class_1863.class)
public interface RecipeManagerAccessor {
    @Invoker("byType")
    <C extends class_1263, T extends class_1860<C>> Map<class_2960, T> tlm$byType(class_3956<T> recipeType);
}
