package cn.sh1rocu.touhoulittlemaid.util.itemhandler;

import net.minecraft.class_2520;

public interface INBTSerializable<T extends class_2520> {
    T serializeNBT();

    void deserializeNBT(T var1);
}
