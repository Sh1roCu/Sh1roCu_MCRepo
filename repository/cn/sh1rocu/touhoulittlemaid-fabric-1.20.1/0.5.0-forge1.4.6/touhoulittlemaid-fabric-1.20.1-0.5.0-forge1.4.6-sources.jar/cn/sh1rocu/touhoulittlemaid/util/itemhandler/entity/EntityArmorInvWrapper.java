package cn.sh1rocu.touhoulittlemaid.util.itemhandler.entity;

import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

public class EntityArmorInvWrapper extends EntityEquipmentInvWrapper {
    public EntityArmorInvWrapper(final class_1309 entity) {
        super(entity, class_1304.class_1305.field_6178);
    }

    public void readFromNbt(class_2487 tag) {
        if (tag.method_10545(TAG_INVENTORY)) {
            this.deserializeNBT(tag.method_10562(TAG_INVENTORY));
        }
    }

    @Override
    public void writeToNbt(class_2487 tag) {
        tag.method_10566(TAG_INVENTORY, this.serializeNBT());
    }

    public class_2487 serializeNBT() {
        class_2499 nbtTagList = new class_2499();
        for (int i = 0; i < getSlots(); i++) {
            if (!getStackInSlot(i).method_7960()) {
                class_2487 itemTag = new class_2487();
                itemTag.method_10569("Slot", i);
                nbtTagList.add(getStackInSlot(i).method_7953(itemTag));
            }
        }
        class_2487 nbt = new class_2487();
        nbt.method_10566("Items", nbtTagList);
        nbt.method_10569("Size", getSlots());
        return nbt;
    }

    public void deserializeNBT(class_2487 nbt) {
        int size = nbt.method_10573("Size", class_2520.field_33253) ? nbt.method_10550("Size") : getSlots();
        class_2499 tagList = nbt.method_10554("Items", class_2520.field_33260);
        for (int i = 0; i < tagList.size(); i++) {
            class_2487 itemTags = tagList.method_10602(i);
            int slot = itemTags.method_10550("Slot");

            if (slot >= 0 && slot < size) {
                setStackInSlot(slot, class_1799.method_7915(itemTags));
            }
        }
    }
}