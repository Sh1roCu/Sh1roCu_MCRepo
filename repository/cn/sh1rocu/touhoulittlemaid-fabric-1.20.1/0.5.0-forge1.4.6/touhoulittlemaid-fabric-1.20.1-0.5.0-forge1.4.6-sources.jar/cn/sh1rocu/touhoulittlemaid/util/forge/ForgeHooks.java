package cn.sh1rocu.touhoulittlemaid.util.forge;

import cn.sh1rocu.touhoulittlemaid.api.event.FarmlandTrampleEvent;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_4538;

/**
 * From Forge
 */
public class ForgeHooks {
    public static Optional<class_2338> isLivingOnLadder(@NotNull class_2680 state, @NotNull class_1937 level, @NotNull class_2338 pos, @NotNull class_1309 entity) {
        boolean isSpectator = (entity instanceof class_1657 && entity.method_7325());
        if (isSpectator) return Optional.empty();
//        if (!ForgeConfig.SERVER.fullBoundingBoxLadders.get()) {
//            return state.isLadder(level, pos, entity) ? Optional.of(pos) : Optional.empty();
//        } else {
//            AABB bb = entity.getBoundingBox();
//            int mX = Mth.floor(bb.minX);
//            int mY = Mth.floor(bb.minY);
//            int mZ = Mth.floor(bb.minZ);
//            for (int y2 = mY; y2 < bb.maxY; y2++) {
//                for (int x2 = mX; x2 < bb.maxX; x2++) {
//                    for (int z2 = mZ; z2 < bb.maxZ; z2++) {
//                        BlockPos tmp = new BlockPos(x2, y2, z2);
//                        state = level.getBlockState(tmp);
//                        if (state.isLadder(level, tmp, entity)) {
//                            return Optional.of(tmp);
//                        }
//                    }
//                }
//            }
//            return Optional.empty();
//        }
        return isLadder(state, level, pos, entity) ? Optional.of(pos) : Optional.empty();
    }

    public static boolean isLadder(class_2680 state, class_4538 level, class_2338 pos, class_1309 entity) {
        return state.method_26164(class_3481.field_22414);
    }

    public static boolean onFarmlandTrample(class_1937 level, class_2338 pos, class_2680 state, float fallDistance, class_1297 entity) {
        FarmlandTrampleEvent event = new FarmlandTrampleEvent(level, pos, state, fallDistance, entity);
        FarmlandTrampleEvent.CALLBACK.invoker().post(event);
        return !event.isCanceled();
    }
}
