package cn.sh1rocu.touhoulittlemaid.mixin.accessor;

import net.minecraft.class_1391;
import net.minecraft.class_1856;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1391.class)
public interface TempGoalAccessor {
    @Accessor("items")
    class_1856 tlm$getItems();
}
