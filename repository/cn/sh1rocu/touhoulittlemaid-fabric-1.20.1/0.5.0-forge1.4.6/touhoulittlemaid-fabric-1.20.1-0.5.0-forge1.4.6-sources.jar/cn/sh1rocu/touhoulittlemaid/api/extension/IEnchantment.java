package cn.sh1rocu.touhoulittlemaid.api.extension;

import net.minecraft.class_1799;
import net.minecraft.class_1887;

public interface IEnchantment {
    default boolean tlm$canApplyAtEnchantingTable(class_1799 stack, class_1887 enchantment) {
        return enchantment.field_9083.method_8177(stack.method_7909());
    }
}