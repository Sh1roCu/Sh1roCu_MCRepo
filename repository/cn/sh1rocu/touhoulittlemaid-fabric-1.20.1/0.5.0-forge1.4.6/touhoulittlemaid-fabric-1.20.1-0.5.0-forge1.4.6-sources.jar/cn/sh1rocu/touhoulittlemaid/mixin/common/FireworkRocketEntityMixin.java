package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.api.event.ProjectileImpactEvent;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import net.minecraft.class_1671;
import net.minecraft.class_239;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1671.class)
public class FireworkRocketEntityMixin {
    @WrapWithCondition(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/projectile/FireworkRocketEntity;onHit(Lnet/minecraft/world/phys/HitResult;)V"))
    private boolean tlm$onImpact(class_1671 projectile, class_239 result) {
        if (result.method_17783() == class_239.class_240.field_1333)
            return true;
        ProjectileImpactEvent event = new ProjectileImpactEvent(projectile, result);
        ProjectileImpactEvent.CALLBACK.invoker().post(event);
        return !event.isCanceled();
    }
}