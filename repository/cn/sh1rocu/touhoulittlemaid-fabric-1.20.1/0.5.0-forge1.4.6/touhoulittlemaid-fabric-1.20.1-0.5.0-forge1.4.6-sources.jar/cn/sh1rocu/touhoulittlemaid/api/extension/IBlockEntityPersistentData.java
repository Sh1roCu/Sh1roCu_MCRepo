package cn.sh1rocu.touhoulittlemaid.api.extension;

import net.minecraft.class_2487;

public interface IBlockEntityPersistentData {
    String PERSISTENT_DATA = "ForgeData";

    default class_2487 tlm$getPersistentData() {
        throw new RuntimeException();
    }
}