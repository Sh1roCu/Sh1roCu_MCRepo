package cn.sh1rocu.touhoulittlemaid.util.enchant;

import net.minecraft.class_1799;
import net.minecraft.class_1887;

public class EnchantmentUtil {
    public static boolean canEnchant(class_1799 stack, class_1887 enchantment) {
        return enchantment != null && enchantment.method_8192(stack);
    }
}
