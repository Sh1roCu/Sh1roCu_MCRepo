package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.api.extension.IEnchantment;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1887.class)
public class EnchantmentMixin {
    @Inject(method = "canEnchant", at = @At("HEAD"), cancellable = true)
    private void tlm$canApplyAtEnchantingTable(class_1799 itemStack, CallbackInfoReturnable<Boolean> cir) {
        class_1887 self = (class_1887) (Object) this;
        if (itemStack.method_7909() instanceof IEnchantment item) {
            cir.setReturnValue(item.tlm$canApplyAtEnchantingTable(itemStack, self));
        }
    }
}
