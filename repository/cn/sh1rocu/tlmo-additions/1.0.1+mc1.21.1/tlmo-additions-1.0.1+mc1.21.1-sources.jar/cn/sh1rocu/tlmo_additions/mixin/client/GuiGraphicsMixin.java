package cn.sh1rocu.tlmo_additions.mixin.client;

import cn.sh1rocu.tlmo_additions.api.extension.gui.GuiGraphicsExtension;
import cn.sh1rocu.tlmo_additions.api.extension.gui.util.GuiHooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5348;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import net.minecraft.class_7923;
import net.minecraft.class_8000;
import net.minecraft.class_8001;

// From PortingLib
@Mixin(class_332.class)
public abstract class GuiGraphicsMixin implements GuiGraphicsExtension {

    @Shadow
    public abstract int guiWidth();

    @Shadow
    public abstract int guiHeight();

    @Shadow
    protected abstract void renderTooltipInternal(class_327 font, List<class_5684> list, int i, int j, class_8000 clientTooltipPositioner);

    @Unique
    private class_1799 tlmoa$tooltipStack = class_1799.field_8037;

    @Unique
    @Override
    public void tlmoa$renderComponentTooltip(class_327 font, List<? extends class_5348> tooltips, int mouseX, int mouseY, class_1799 stack) {
        this.tlmoa$tooltipStack = stack;
        List<class_5684> components = GuiHooks.gatherTooltipComponents(stack, tooltips, mouseX, guiWidth(), guiHeight(), font);
        this.renderTooltipInternal(font, components, mouseX, mouseY, class_8001.field_41687);
        this.tlmoa$tooltipStack = class_1799.field_8037;
    }

    @ModifyArgs(method = "renderTooltip(Lnet/minecraft/client/gui/Font;Ljava/util/List;Ljava/util/Optional;II)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;renderTooltipInternal(Lnet/minecraft/client/gui/Font;Ljava/util/List;IILnet/minecraft/client/gui/screens/inventory/tooltip/ClientTooltipPositioner;)V"))
    private void tlmoa$wrapTooltip(Args args, class_327 font, List<class_2561> lines, Optional<class_5632> data, int x, int y) {
        if (GuiHooks.MODS_TO_WRAP.contains(class_7923.field_41178.method_10221(tlmoa$tooltipStack.method_7909()).method_12836())) {
            args.set(1, GuiHooks.gatherTooltipComponents(tlmoa$tooltipStack, lines, data, x, guiWidth(), guiHeight(), font));
        }
    }

    @ModifyArgs(method = "renderComponentTooltip", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;renderTooltip(Lnet/minecraft/client/gui/Font;Ljava/util/List;II)V"))
    private void tlmoa$wrapTooltipComponent(Args args, class_327 font, List<class_2561> lines, int x, int y) {
        if (GuiHooks.MODS_TO_WRAP.contains(class_7923.field_41178.method_10221(tlmoa$tooltipStack.method_7909()).method_12836())) {
            args.set(1, GuiHooks.gatherTooltipComponents(tlmoa$tooltipStack, lines, Optional.empty(), x, guiWidth(), guiHeight(), font));
        }
    }
}
