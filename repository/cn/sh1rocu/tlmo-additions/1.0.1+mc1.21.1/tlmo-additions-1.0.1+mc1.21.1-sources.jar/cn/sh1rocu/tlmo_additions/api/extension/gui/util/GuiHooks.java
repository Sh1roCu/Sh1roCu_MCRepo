package cn.sh1rocu.tlmo_additions.api.extension.gui.util;

import cn.sh1rocu.tlmo_additions.api.event.GatherComponentsEvent;
import com.mojang.datafixers.util.Either;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1799;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_5348;
import net.minecraft.class_5632;
import net.minecraft.class_5684;

// From PortingLib
public class GuiHooks {
    public static List<class_5684> gatherTooltipComponents(class_1799 stack, List<? extends class_5348> textElements, int mouseX, int screenWidth, int screenHeight, class_327 fallbackFont) {
        return gatherTooltipComponents(stack, textElements, Optional.empty(), mouseX, screenWidth, screenHeight, fallbackFont);
    }

    public static List<class_5684> gatherTooltipComponents(class_1799 stack, List<? extends class_5348> textElements, Optional<class_5632> itemComponent, int mouseX, int screenWidth, int screenHeight, class_327 fallbackFont) {
        class_327 font = fallbackFont;//getTooltipFont(stack, fallbackFont);
        List<Either<class_5348, class_5632>> elements = textElements.stream()
                .map((Function<class_5348, Either<class_5348, class_5632>>) Either::left)
                .collect(Collectors.toCollection(ArrayList::new));
        itemComponent.ifPresent(c -> elements.add(1, Either.right(c)));

        var event = new GatherComponentsEvent(stack, screenWidth, screenHeight, elements, -1);
        event.sendEvent();
        if (event.isCanceled()) return List.of();

        // text wrapping
        int tooltipTextWidth = event.getTooltipElements().stream()
                .mapToInt(either -> either.map(font::method_27525, component -> 0))
                .max()
                .orElse(0);

        boolean needsWrap = false;

        int tooltipX = mouseX + 12;
        if (tooltipX + tooltipTextWidth + 4 > screenWidth) {
            tooltipX = mouseX - 16 - tooltipTextWidth;
            if (tooltipX < 4) // if the tooltip doesn't fit on the screen
            {
                if (mouseX > screenWidth / 2)
                    tooltipTextWidth = mouseX - 12 - 8;
                else
                    tooltipTextWidth = screenWidth - 16 - mouseX;
                needsWrap = true;
            }
        }

        if (event.getMaxWidth() > 0 && tooltipTextWidth > event.getMaxWidth()) {
            tooltipTextWidth = event.getMaxWidth();
            needsWrap = true;
        }

        int tooltipTextWidthF = tooltipTextWidth;
        if (needsWrap) {
            return event.getTooltipElements().stream()
                    .flatMap(either -> either.map(
                            text -> splitLine(text, font, tooltipTextWidthF),
                            component -> Stream.of(class_5684.method_32663(component))
                    ))
                    .toList();
        }
        return event.getTooltipElements().stream()
                .map(either -> either.map(
                        text -> class_5684.method_32662(text instanceof class_2561 ? ((class_2561) text).method_30937() : class_2477.method_10517().method_30934(text)),
                        class_5684::method_32663
                ))
                .toList();
    }

    private static Stream<class_5684> splitLine(class_5348 text, class_327 font, int maxWidth) {
        if (text instanceof class_2561 component && component.getString().isEmpty()) {
            return Stream.of(component.method_30937()).map(class_5684::method_32662);
        }
        return font.method_1728(text, maxWidth).stream().map(class_5684::method_32662);
    }

    public static final List<String> MODS_TO_WRAP = new ArrayList<>();

    public static void wrapModTooltips(String modid) {
        MODS_TO_WRAP.add(modid);
    }
}
