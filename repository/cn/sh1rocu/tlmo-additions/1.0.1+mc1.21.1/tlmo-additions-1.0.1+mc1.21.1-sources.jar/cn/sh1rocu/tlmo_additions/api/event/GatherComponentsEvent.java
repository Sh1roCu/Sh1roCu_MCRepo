package cn.sh1rocu.tlmo_additions.api.event;

import cn.sh1rocu.touhoulittlemaid.api.event.CancellableEvent;
import com.mojang.datafixers.util.Either;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1799;
import net.minecraft.class_5348;
import net.minecraft.class_5632;
import org.jetbrains.annotations.ApiStatus;

import java.util.List;

// From PortingLib
public class GatherComponentsEvent extends CancellableEvent {
    public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback c : callbacks)
            c.onGatherComponents(event);
    });
    private final class_1799 itemStack;
    private final int screenWidth;
    private final int screenHeight;
    private final List<Either<class_5348, class_5632>> tooltipElements;
    private int maxWidth;

    @ApiStatus.Internal
    public GatherComponentsEvent(class_1799 itemStack, int screenWidth, int screenHeight, List<Either<class_5348, class_5632>> tooltipElements, int maxWidth) {
        this.itemStack = itemStack;
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.tooltipElements = tooltipElements;
        this.maxWidth = maxWidth;
    }

    /**
     * {@return the item stack which the tooltip is being rendered for, or an {@linkplain class_1799#method_7960() empty
     * item stack} if there is no associated item stack}
     */
    public class_1799 getItemStack() {
        return itemStack;
    }

    /**
     * {@return the width of the screen}.
     * The lines of text within the tooltip are wrapped to be within the screen width, and the tooltip box itself
     * is moved to be within the screen width.
     */
    public int getScreenWidth() {
        return screenWidth;
    }

    /**
     * {@return the height of the screen}
     * The tooltip box is moved to be within the screen height.
     */
    public int getScreenHeight() {
        return screenHeight;
    }

    /**
     * {@return the modifiable list of elements to be rendered on the tooltip} These elements can be either
     * formatted text or custom tooltip components.
     */
    public List<Either<class_5348, class_5632>> getTooltipElements() {
        return tooltipElements;
    }

    /**
     * {@return the maximum width of the tooltip when being rendered}
     *
     * <p>A value of {@code -1} means an unlimited maximum width. However, an unlimited maximum width will still
     * be wrapped to be within the screen bounds.</p>
     */
    public int getMaxWidth() {
        return maxWidth;
    }

    /**
     * Sets the maximum width of the tooltip. Use {@code -1} for unlimited maximum width.
     *
     * @param maxWidth the new maximum width
     */
    public void setMaxWidth(int maxWidth) {
        this.maxWidth = maxWidth;
    }

    public void sendEvent() {
        EVENT.invoker().onGatherComponents(this);
    }

    public interface Callback {
        void onGatherComponents(GatherComponentsEvent event);
    }
}
