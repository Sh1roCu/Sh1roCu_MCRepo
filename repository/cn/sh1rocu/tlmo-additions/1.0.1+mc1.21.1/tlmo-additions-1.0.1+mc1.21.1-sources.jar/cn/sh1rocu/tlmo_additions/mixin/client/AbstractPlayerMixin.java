package cn.sh1rocu.tlmo_additions.mixin.client;

import cn.sh1rocu.tlmo_additions.api.event.ComputeFovModifierEvent;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.authlib.GameProfile;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_742.class)
public abstract class AbstractPlayerMixin extends class_1657 {
    public AbstractPlayerMixin(class_1937 level, class_2338 pos, float yRot, GameProfile gameProfile) {
        super(level, pos, yRot, gameProfile);
    }

    @WrapOperation(method = "getFieldOfViewModifier", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/Mth;lerp(FFF)F"))
    private float tlmoa$getForgeFovModifier(float delta, float start, float end, Operation<Float> original) {
        ComputeFovModifierEvent fovModifierEvent = new ComputeFovModifierEvent(this, end);
        ComputeFovModifierEvent.EVENT.invoker().post(fovModifierEvent);
        return fovModifierEvent.getNewFovModifier();
    }
}
