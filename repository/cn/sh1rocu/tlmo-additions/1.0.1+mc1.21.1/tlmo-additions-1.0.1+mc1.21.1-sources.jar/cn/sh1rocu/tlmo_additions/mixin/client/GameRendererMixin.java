package cn.sh1rocu.tlmo_additions.mixin.client;

import cn.sh1rocu.tlmo_additions.api.event.ViewportEvent;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_4184;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_757.class)
public class GameRendererMixin {
    @ModifyReturnValue(method = "getFov", at = @At(value = "RETURN", ordinal = 1))
    private double tlmoa$viewportFovEvent(double original, @Local(argsOnly = true) class_4184 camera, @Local(argsOnly = true) float partialTicks, @Local(argsOnly = true) boolean useConfigured) {
        var event = new ViewportEvent.ComputeFov((class_757) (Object) this, camera, partialTicks, original, useConfigured);
        ViewportEvent.FOV.invoker().post(event);
        return event.getFOV();
    }
}
