package cn.sh1rocu.tlmo_additions.api.extension.gui;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_5348;

// From PortingLib
public interface GuiGraphicsExtension {
    default void tlmoa$renderComponentTooltip(class_327 font, List<? extends class_5348> tooltips, int mouseX, int mouseY, class_1799 stack) {
        throw new RuntimeException("Mixin failed!");
    }
}