package cn.sh1rocu.tlmo_additions.api.event;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public class ComputeFovModifierEvent {
    private final class_1657 player;
    private final float fovModifier;
    private float newFovModifier;

    public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.post(event);
        }
    });

    public interface Callback {
        void post(ComputeFovModifierEvent event);
    }

    public ComputeFovModifierEvent(class_1657 player, float fovModifier) {
        this.player = player;
        this.fovModifier = fovModifier;
        this.setNewFovModifier((float) class_3532.method_16436(class_310.method_1551().field_1690.method_42454().method_41753(), 1.0F, fovModifier));
    }

    public class_1657 getPlayer() {
        return player;
    }

    public float getFovModifier() {
        return fovModifier;
    }

    public float getNewFovModifier() {
        return newFovModifier;
    }

    public void setNewFovModifier(float newFovModifier) {
        this.newFovModifier = newFovModifier;
    }
}
