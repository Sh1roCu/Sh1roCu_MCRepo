package studio.fantasyit.maid_useful_task.task;

import com.github.tartaricacid.touhoulittlemaid.api.task.IMaidTask;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.maid_useful_task.Config;
import studio.fantasyit.maid_useful_task.MaidUsefulTask;
import studio.fantasyit.maid_useful_task.api.ItemLocateEvent;
import studio.fantasyit.maid_useful_task.behavior.common.FindTargetMoveBehavior;
import studio.fantasyit.maid_useful_task.behavior.common.FindTargetWaitBehavior;
import studio.fantasyit.maid_useful_task.compat.CompatEntry;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1759;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1806;
import net.minecraft.class_21;
import net.minecraft.class_22;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3489;
import net.minecraft.class_4208;
import net.minecraft.class_7045;
import net.minecraft.class_7893;
import net.minecraft.class_9291;
import net.minecraft.class_9292;
import net.minecraft.class_9334;

public class MaidLocateTask implements IMaidTask, IMaidFindTargetTask {
    public static final class_2960 UID = class_2960.method_60655(MaidUsefulTask.MODID, "locate");

    @Override
    public class_2960 getUid() {
        return UID;
    }

    @Override
    public class_1799 getIcon() {
        return class_1802.field_8449.method_7854();
    }

    @Nullable
    @Override
    public class_3414 getAmbientSound(EntityMaid entityMaid) {
        return null;
    }

    @Override
    public List<Pair<Integer, class_7893<? super EntityMaid>>> createBrainTasks(EntityMaid entityMaid) {
        List<Pair<Integer, class_7893<? super EntityMaid>>> list = new ArrayList<>();
        list.add(Pair.of(1, new FindTargetMoveBehavior()));
        list.add(Pair.of(2, new FindTargetWaitBehavior()));
        return list;
    }

    @Override
    public boolean enableLookAndRandomWalk(EntityMaid maid) {
        return false;
    }

    @Override
    public boolean isEnable(EntityMaid maid) {
        return Config.enableLocateTask;
    }

    @Override
    public @Nullable class_2338 findTarget(class_3218 level, EntityMaid maid) {
        class_2338 target = null;
        class_1799 itemStack = maid.method_6047();
        class_1799 last = MemoryUtil.getLocateItem(maid);
        if (!last.method_7960() && !itemStack.method_7960() && class_1799.method_31577(last, itemStack)) {
            MemoryUtil.setLocateItem(maid, itemStack);
            MemoryUtil.clearCommonBlockCache(maid);
        }
        ItemLocateEvent event = new ItemLocateEvent(itemStack, maid, MemoryUtil.getCommonBlockCache(maid));
        ItemLocateEvent.EVENT.invoker().onItemLocate(event);
        if (event.isCanceled()) {
            target = event.getTarget();
        } else if (maid.method_6047().method_31574(class_1802.field_8449)) {
            target = MemoryUtil.getCommonBlockCache(maid);
            if (target == null) {
                class_2338 blockpos = level.method_8487(class_7045.field_37040, maid.method_24515(), 100, false);
                if (blockpos != null) {
                    MemoryUtil.setCommonBlockCache(maid, blockpos);
                    target = blockpos;
                }
            }
        } else if (maid.method_6047().method_31574(class_1802.field_8251)) {
            target = MemoryUtil.getCommonBlockCache(maid);
            if (target == null) {
                class_4208 globalPos;
                class_9291 lodeData = itemStack.method_57824(class_9334.field_49614);
                if (lodeData != null && lodeData.comp_2402().isPresent()) {
                    globalPos = lodeData.comp_2402().get();
                } else {
                    globalPos = class_1759.method_43123(level);
                }
                if (globalPos != null && level.method_27983().equals(globalPos.comp_2207())) {
                    MemoryUtil.setCommonBlockCache(maid, globalPos.comp_2208());
                    target = globalPos.comp_2208();
                }
            }
        } else if (maid.method_6047().method_31573(class_3489.field_16444)) {
            target = MemoryUtil.getCommonBlockCache(maid);
            if (target == null) {
                class_1309 owner = maid.method_35057();
                if (owner instanceof class_3222 player) {
                    if (player.method_26281().equals(level.method_27983())) {
                        target = player.method_26280();
                        if (target == null) {
                            class_4208 globalRespawn = class_1759.method_43123(level);
                            if (globalRespawn != null && level.method_27983().equals(globalRespawn.comp_2207())) {
                                target = globalRespawn.comp_2208();
                            }
                        }
                    }
                    if (target == null) {
                        MemoryUtil.setCommonBlockCache(maid, target);
                    }
                }
            }
        } else if (maid.method_6047().method_31574(class_1802.field_8204)) {
            target = MemoryUtil.getCommonBlockCache(maid);
            if (target == null) {
                class_22 savedData = class_1806.method_8001(itemStack, maid.method_37908());
                if (savedData != null) {
                    class_2338.class_2339 tmpTarget = new class_2338.class_2339(savedData.field_116, level.method_8615(), savedData.field_115);

                    savedData.method_35503()
                            .stream()
                            .findFirst()
                            .ifPresent(t -> {
                                tmpTarget.method_10101(t.comp_2312().method_10062());
                            });
                    class_9292 decoList = itemStack.method_57824(class_9334.field_49647);
                    if (decoList != null)
                        decoList.comp_2404().entrySet().stream()
                                .filter(t -> t.getValue().comp_2405() == class_21.field_110)
                                .findFirst()
                                .ifPresent(t -> {
                                    tmpTarget.method_33097((int) t.getValue().comp_2406());
                                    tmpTarget.method_33099((int) t.getValue().comp_2407());
                                });

                    target = tmpTarget.method_10062();
                    MemoryUtil.setCommonBlockCache(maid, target);
                }
            }
        } else {
            target = CompatEntry.getLocateTarget(maid, maid.method_6047());
            if (target != null) {
                MemoryUtil.setCommonBlockCache(maid, target);
                return target;
            }
            MemoryUtil.clearCommonBlockCache(maid);
        }
        return target;
    }

    @Override
    public void clearCache(EntityMaid maid) {
        MemoryUtil.clearCommonBlockCache(maid);
    }
}