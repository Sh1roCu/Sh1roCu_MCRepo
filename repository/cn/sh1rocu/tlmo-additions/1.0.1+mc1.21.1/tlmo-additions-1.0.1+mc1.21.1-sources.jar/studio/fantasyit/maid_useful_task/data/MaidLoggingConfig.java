package studio.fantasyit.maid_useful_task.data;

import com.github.tartaricacid.touhoulittlemaid.api.entity.data.TaskDataKey;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import studio.fantasyit.maid_useful_task.MaidUsefulTask;

public class MaidLoggingConfig implements TaskDataKey<MaidLoggingConfig.Data> {


    public static Data get(EntityMaid maid) {
        return maid.getOrCreateData(KEY, Data.getDefault());
    }

    public static final class Data implements IConfigSetter {
        private boolean plant;
        private boolean blockUp;
        private boolean skipNonNature;

        public Data(boolean plant, boolean blockUp, boolean skipNonNature) {
            this.plant = plant;
            this.blockUp = blockUp;
            this.skipNonNature = skipNonNature;
        }

        public static Data getDefault() {
            return new Data(true, true, true);
        }

        public boolean plant() {
            return plant;
        }

        public void plant(boolean plant) {
            this.plant = plant;
        }

        public boolean blockUp() {
            return blockUp;
        }

        public void blockUp(boolean blockUp) {
            this.blockUp = blockUp;
        }

        public boolean skipNonNature() {
            return skipNonNature;
        }

        public void skipNonNature(boolean skipNonNature) {
            this.skipNonNature = skipNonNature;
        }

        @Override
        public void setConfigValue(String name, String value) {
            switch (name) {
                case "plant":
                    plant = Boolean.parseBoolean(value);
                    break;
                case "blockUp":
                    blockUp = Boolean.parseBoolean(value);
                    break;
                case "skipNonNature":
                    skipNonNature = Boolean.parseBoolean(value);
                    break;
            }
        }
    }

    public static TaskDataKey<Data> KEY = null;
    public static final class_2960 LOCATION = class_2960.method_60655(MaidUsefulTask.MODID, "logging");

    @Override
    public class_2960 getKey() {
        return LOCATION;
    }

    @Override
    public class_2487 writeSaveData(Data data) {
        class_2487 tag = new class_2487();
        tag.method_10556("plant", data.plant);
        tag.method_10556("blockUp", data.blockUp);
        tag.method_10556("skipNonNature", data.skipNonNature);
        return tag;
    }

    @Override
    public Data readSaveData(class_2487 compound) {
        boolean plant = compound.method_10577("plant");
        boolean blockUp = compound.method_10577("blockUp");
        boolean skipNonNature = compound.method_10577("skipNonNature");
        return new Data(plant, blockUp, skipNonNature);
    }
}
