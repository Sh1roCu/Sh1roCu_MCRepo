package studio.fantasyit.maid_useful_task.vehicle.broom;

import com.github.tartaricacid.touhoulittlemaid.api.entity.IBroomControl;
import com.github.tartaricacid.touhoulittlemaid.entity.item.EntityBroom;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_5134;
import studio.fantasyit.maid_useful_task.vehicle.MaidVehicleControlType;

public class BroomController implements IBroomControl {
    private final EntityBroom broom;

    public BroomController(EntityBroom broom) {
        this.broom = broom;
    }

    @Override
    public int getPriority() {
        return 10;
    }

    @Override
    public boolean inControl(class_1657 player, EntityMaid entityMaid) {
        return BroomControlParamStore.getControlParam(entityMaid).type() != MaidVehicleControlType.NONE;
    }

    @Override
    public void travel(class_1657 player, EntityMaid entityMaid) {
        BroomControlParamStore.BroomControlParam param = BroomControlParamStore.getControlParam(entityMaid);

        float forward = 0;
        float strafe = 0;
        float vertical = param.vertical();
        if (param.type() == MaidVehicleControlType.FULL) {
            forward = param.forward() / 15.0f;
        } else {
            boolean keyForward = player.field_6250 > 0;
            boolean keyBack = player.field_6250 < 0;
            boolean keyLeft = player.field_6212 > 0;
            boolean keyRight = player.field_6212 < 0;

            if (keyForward || keyBack || keyLeft || keyRight) {
                strafe = keyLeft ? 0.2f : (keyRight ? -0.2f : 0);
                forward = keyForward ? 0.375f : (keyBack ? -0.2f : 0);
            } else {
                vertical = 0;
            }
        }
        //来自PlayerBroomControl
        double playerSpeed = player.method_45325(class_5134.field_23719);
        double speed = Math.max(playerSpeed - 0.1, 0) * 2.5 + 0.1;
        class_243 targetMotion = new class_243(strafe, vertical, forward).method_1021(speed * 20);
        targetMotion = targetMotion.method_1024((float) (-broom.method_36454() * Math.PI / 180.0));

        // 插值到目标速度，而不是直接累加
        class_243 currentMotion = broom.method_18798();
        class_243 newMotion = currentMotion.method_35590(targetMotion, 0.25f);
        broom.method_18799(newMotion);
    }


    @Override
    public void tickRot(class_1657 player, EntityMaid entityMaid) {
        BroomControlParamStore.BroomControlParam param = BroomControlParamStore.getControlParam(entityMaid);

        broom.field_5982 = broom.field_6283 = broom.field_6241 = broom.method_36454();
        broom.method_5710(param.yRot(), param.xRot());
    }
}
