package studio.fantasyit.maid_useful_task.vehicle.broom;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import studio.fantasyit.maid_useful_task.vehicle.MaidVehicleControlType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2487;

public class BroomControlParamStore {
    public record BroomControlParam(float xRot, float yRot, float vertical, float forward,
                                    MaidVehicleControlType type) {
        public static BroomControlParam fromNbt(class_2487 tag) {
            return new BroomControlParam(
                    tag.method_10583("xRot"),
                    tag.method_10583("yRot"),
                    tag.method_10583("vertical"),
                    tag.method_10583("forward"),
                    MaidVehicleControlType.valueOf(tag.method_10558("type"))
            );
        }

        public class_2487 toNbt() {
            class_2487 tag = new class_2487();
            tag.method_10548("xRot", xRot);
            tag.method_10548("yRot", yRot);
            tag.method_10548("vertical", vertical);
            tag.method_10548("forward", forward);
            tag.method_10582("type", type.name());
            return tag;
        }
    }

    private static final BroomControlParam NONE = new BroomControlParam(0, 0, 0, 0, MaidVehicleControlType.NONE);

    private static final Map<UUID, BroomControlParam> store = new HashMap<>();

    public static void setControlParam(EntityMaid maid, BroomControlParam param) {
        store.put(maid.method_5667(), param);
    }

    public static BroomControlParam getControlParam(EntityMaid maid) {
        if (!store.containsKey(maid.method_5667()))
            return NONE;
        return store.get(maid.method_5667());
    }

    public static void removeControlParam(EntityMaid maid) {
        store.remove(maid.method_5667());
    }
}