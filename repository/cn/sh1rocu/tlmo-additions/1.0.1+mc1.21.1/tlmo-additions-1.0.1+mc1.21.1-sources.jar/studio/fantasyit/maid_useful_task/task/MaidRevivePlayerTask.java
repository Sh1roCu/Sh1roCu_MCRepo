package studio.fantasyit.maid_useful_task.task;

import com.github.tartaricacid.touhoulittlemaid.api.task.IMaidTask;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3908;
import net.minecraft.class_7893;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.maid_useful_task.Config;
import studio.fantasyit.maid_useful_task.MaidUsefulTask;
import studio.fantasyit.maid_useful_task.behavior.PlayerReviveBehavior;
import studio.fantasyit.maid_useful_task.compat.PlayerRevive;
import studio.fantasyit.maid_useful_task.menu.MaidReviveConfigGui;

import java.util.ArrayList;
import java.util.List;

public class MaidRevivePlayerTask implements IMaidTask {
    public static final class_2960 UID = class_2960.method_60655(MaidUsefulTask.MODID, "revive_player");

    @Override
    public class_2960 getUid() {
        return UID;
    }

    @Override
    public class_1799 getIcon() {
        return class_1802.field_8367.method_7854();
    }

    @Nullable
    @Override
    public class_3414 getAmbientSound(EntityMaid entityMaid) {
        return null;
    }

    @Override
    public boolean isEnable(EntityMaid maid) {
        return PlayerRevive.isEnable() && Config.enableReviveTask;
    }

    @Override
    public boolean enableLookAndRandomWalk(EntityMaid maid) {
        return false;
    }

    @Override
    public boolean enablePanic(EntityMaid maid) {
        return false;
    }

    @Override
    public List<Pair<Integer, class_7893<? super EntityMaid>>> createBrainTasks(EntityMaid entityMaid) {
        ArrayList<Pair<Integer, class_7893<? super EntityMaid>>> ret = new ArrayList<>();
        ret.add(Pair.of(1, new PlayerReviveBehavior()));
        return ret;
    }

    @Override
    public class_3908 getTaskConfigGuiProvider(EntityMaid maid) {
        return new ExtendedScreenHandlerFactory<Integer>() {
            @Override
            public Integer getScreenOpeningData(class_3222 serverPlayer) {
                return maid.method_5628();
            }

            @Override
            public boolean shouldCloseCurrentScreen() {
                return false;
            }

            @Override
            public class_2561 method_5476() {
                return class_2561.method_43470("");
            }

            @Override
            public class_1703 createMenu(int index, class_1661 playerInventory, class_1657 player) {
                return new MaidReviveConfigGui.Container(index, playerInventory, maid.method_5628());
            }
        };
    }

}
