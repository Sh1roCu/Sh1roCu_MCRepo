package studio.fantasyit.maid_useful_task.client;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import studio.fantasyit.maid_useful_task.network.MaidAllowHandleVehicle;

import static studio.fantasyit.maid_useful_task.client.KeyMapping.KEY_SWITCH_VEHICLE_CONTROL;

@Environment(EnvType.CLIENT)
public class KeyEvents {
    public static void keyInput(int key, int scanCode, int action, int mods) {
        while (KEY_SWITCH_VEHICLE_CONTROL.method_1436()) {
            class_1657 player = class_310.method_1551().field_1724;
            if (player == null || !player.method_5765()) return;
            EntityMaid maid = player
                    .method_5854()
                    .method_5685()
                    .stream()
                    .filter(entity -> entity instanceof EntityMaid)
                    .map(entity -> (EntityMaid) entity)
                    .findAny()
                    .orElse(null);
            if (maid == null) return;
            ClientPlayNetworking.send(new MaidAllowHandleVehicle(maid.method_5628()));
        }
    }
}
