package studio.fantasyit.maid_useful_task.task;

import cn.sh1rocu.touhoulittlemaid.util.itemhandler.CombinedInvWrapper;
import com.github.tartaricacid.touhoulittlemaid.api.task.IMaidTask;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2397;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_3908;
import net.minecraft.class_7893;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.maid_useful_task.Config;
import studio.fantasyit.maid_useful_task.MaidUsefulTask;
import studio.fantasyit.maid_useful_task.behavior.common.*;
import studio.fantasyit.maid_useful_task.data.MaidLoggingConfig;
import studio.fantasyit.maid_useful_task.memory.BlockValidationMemory;
import studio.fantasyit.maid_useful_task.menu.MaidLoggingConfigGui;
import studio.fantasyit.maid_useful_task.util.MaidUtils;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;
import studio.fantasyit.maid_useful_task.util.WrappedMaidFakePlayer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MaidTreeTask implements IMaidTask, IMaidBlockPlaceTask, IMaidBlockDestroyTask, IMaidBlockUpTask {
    public static final class_2960 UID = class_2960.method_60655(MaidUsefulTask.MODID, "maid_tree");

    @Override
    public class_2960 getUid() {
        return UID;
    }

    @Override
    public class_1799 getIcon() {
        return class_1802.field_17535.method_7854();
    }

    @Override
    public boolean enableLookAndRandomWalk(EntityMaid maid) {
        return true;
    }

    @Nullable
    @Override
    public class_3414 getAmbientSound(EntityMaid entityMaid) {
        return null;
    }

    @Override
    public boolean isEnable(EntityMaid maid) {
        return Config.enableLoggingTask;
    }

    @Override
    public class_3908 getTaskConfigGuiProvider(EntityMaid maid) {
        return new ExtendedScreenHandlerFactory<Integer>() {
            @Override
            public Integer getScreenOpeningData(class_3222 serverPlayer) {
                return maid.method_5628();
            }

            @Override
            public boolean shouldCloseCurrentScreen() {
                return false;
            }

            @Override
            public class_2561 method_5476() {
                return class_2561.method_43470("");
            }

            @Override
            public class_1703 createMenu(int index, class_1661 playerInventory, class_1657 player) {
                return new MaidLoggingConfigGui.Container(index, playerInventory, maid.method_5628());
            }
        };
    }

    @Override
    public boolean shouldDestroyBlock(EntityMaid maid, class_2338 pos) {
        if (MemoryUtil.getBlockUpContext(maid).hasTarget()) {
            if (pos.method_10264() < maid.method_31478() && pos.method_10263() == maid.method_31477() && pos.method_10260() == maid.method_31479()) {
                return false;
            }
        }
        class_2680 blockState = maid.method_37908().method_8320(pos);
        if (blockState.method_26164(class_3481.field_15475)) {
            return !MaidLoggingConfig.get(maid).skipNonNature() || isValidNatureTree(maid, pos);
        }
        return false;
    }

    @Override
    public boolean mayDestroy(EntityMaid maid, class_2338 pos) {
        if (MemoryUtil.getBlockUpContext(maid).hasTarget()) {
            if (pos.method_10264() < maid.method_31478() && pos.method_10263() == maid.method_31477() && pos.method_10260() == maid.method_31479()) {
                return false;
            }
        }
        class_2680 blockState = maid.method_37908().method_8320(pos);
        if (blockState.method_26164(class_3481.field_15503)) {
            return true;
        }
        return blockState.method_26164(class_3481.field_15475);
    }

    @Override
    public boolean shouldPlaceItemStack(EntityMaid maid, class_1799 itemStack) {
        if (!maid.getOrCreateData(MaidLoggingConfig.KEY, MaidLoggingConfig.Data.getDefault()).plant()) return false;
        return itemStack.method_31573(class_3489.field_15528);
    }

    @Override
    public boolean shouldPlacePos(EntityMaid maid, class_1799 itemStack, class_2338 pos) {
        class_3218 level = (class_3218) maid.method_37908();
        if (!level.method_8320(pos.method_10074()).method_26164(class_3481.field_29822)) return false;
        if (!level.method_8320(pos).method_45474()) return false;
        final int[] dv = {0, 1, -1, 2, -2};
        for (int dx : dv) {
            for (int dy = 0; dy < 4; dy++) {
                for (int dz : dv) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    if (!level.method_8320(pos.method_10069(dx, dy, dz)).method_45474())
                        return false;
                }
            }
        }
        return true;
    }

    @Override
    public void tryTakeOutTool(EntityMaid maid) {
        CombinedInvWrapper inv = maid.getAvailableInv(true);
        for (int i = 0; i < inv.getSlots(); i++) {
            if (inv.getStackInSlot(i).method_31573(class_3489.field_42612)) {
                @NotNull class_1799 tmp = inv.getStackInSlot(i);
                inv.setStackInSlot(i, maid.method_6047());
                maid.method_6122(class_1268.field_5808, tmp);
                return;
            }
        }
    }

    public void swapShearsOrNone(EntityMaid maid) {
        CombinedInvWrapper inv = maid.getAvailableInv(true);
        int target = -1;
        for (int i = 0; i < inv.getSlots(); i++) {
            if (inv.getStackInSlot(i).method_31574(class_1802.field_8868) || inv.getStackInSlot(i).method_31573(class_3489.field_42613)) {
                target = i;
                break;
            }
            if (!inv.getStackInSlot(i).method_7963()) {
                target = i;
            }
        }
        if (target != -1) {
            @NotNull class_1799 tmp = inv.getStackInSlot(target);
            inv.setStackInSlot(target, maid.method_6047());
            maid.method_6122(class_1268.field_5808, tmp);
        }
    }

    @Override
    public void tryTakeOutToolForTarget(EntityMaid maid, class_2338 pos) {
        if (maid.method_37908().method_8320(pos).method_26164(class_3481.field_15503)) {
            swapShearsOrNone(maid);
        } else {
            tryTakeOutTool(maid);
        }
    }

    @Override
    public boolean availableToGetDrop(EntityMaid maid, WrappedMaidFakePlayer fakePlayer, class_2338 pos, class_2680 targetBlockState) {
        if (targetBlockState.method_26164(class_3481.field_15503))
            return true;
        return IMaidBlockDestroyTask.super.availableToGetDrop(maid, fakePlayer, pos, targetBlockState);
    }


    protected boolean isValidNatureTree(EntityMaid maid, class_2338 startPos) {
        HashSet<class_2338> vis = new HashSet<>();
        BlockValidationMemory validationMemory = MemoryUtil.getBlockValidationMemory(maid);
        boolean validNatureTree = isValidNatureTree(maid, startPos, vis, 0, validationMemory);
        for (class_2338 pos : vis) {
            class_2680 blockState = maid.method_37908().method_8320(pos);
            if (!blockState.method_26164(class_3481.field_15503) && !blockState.method_26164(class_3481.field_15475))
                continue;
            if (validNatureTree)
                validationMemory.setValid(pos);
            else
                validationMemory.setInvalid(pos);
        }
        return validNatureTree;
    }

    protected boolean isValidNatureTree(EntityMaid maid, class_2338 startPos, Set<class_2338> visited, int depth, BlockValidationMemory validationMemory) {
        if (validationMemory.hasRecord(startPos))
            return validationMemory.isValid(startPos, false);
        if (visited.contains(startPos))
            return false;
        if (depth > 100) return false;
        visited.add(startPos);
        boolean valid = false;
        final int[] dv = {0, 1, -1};
        for (int dx : dv) {
            for (int dz : dv) {
                for (int dy : dv) {
                    class_2338 offset = startPos.method_10069(dx, dy, dz);
                    class_2680 blockState = maid.method_37908().method_8320(offset);
                    if (blockState.method_26164(class_3481.field_15503) && blockState.method_28498(class_2397.field_11200) && !blockState.method_11654(class_2397.field_11200)) {
                        valid = true;
                    }
                    if (blockState.method_26164(class_3481.field_15475) && isValidNatureTree(maid, offset, visited, depth + 1, validationMemory)) {
                        valid = true;
                    }
                }
            }
        }
        if (valid)
            validationMemory.setValid(startPos);
        else
            validationMemory.setInvalid(startPos);
        return valid;
    }

    @Override
    public List<Pair<Integer, class_7893<? super EntityMaid>>> createBrainTasks(EntityMaid entityMaid) {
        ArrayList<Pair<Integer, class_7893<? super EntityMaid>>> list = new ArrayList<>();
        list.add(Pair.of(0, new MaidSelfRescueBehavior()));

        list.add(Pair.of(1, new DestoryBlockBehavior()));
        list.add(Pair.of(1, new DestoryBlockMoveBehavior()));

        list.add(Pair.of(2, new BlockUpScheduleBehavior()));
        list.add(Pair.of(2, new BlockUpPlaceBehavior()));
        list.add(Pair.of(2, new BlockUpDestroyBehavior()));

        list.add(Pair.of(3, new PlaceBlockBehavior()));
        list.add(Pair.of(3, new PlaceBlockMoveBehavior()));

        list.add(Pair.of(4, new UpdateValidationMemoryBehavior()));

        return list;
    }

    @Override
    public boolean isValidItemStack(EntityMaid maid, class_1799 stack) {
        return stack.method_31573(class_3489.field_15539);
    }

    @Override
    public boolean isDestroyTool(EntityMaid maid, class_1799 stack) {
        return stack.method_31573(class_3489.field_42612);
    }

    @Override
    public boolean isFindingBlock(EntityMaid maid, class_2338 target, class_2338 standPos) {
        if (target.method_10262(standPos) > touchLimit() * touchLimit())
            return false;
        if (maid.method_37908().method_8320(target).method_26164(class_3481.field_15475)) {
            return !MaidLoggingConfig.get(maid).skipNonNature() || isValidNatureTree(maid, target);
        }
        return false;
    }

    @Override
    public boolean tryDestroyBlockUp(EntityMaid maid, class_2338 targetPos) {
        return tryDestroyBlock(maid, targetPos);
    }

    @Override
    public boolean tryPlaceBlock(EntityMaid maid, class_2338 pos) {
        if (IMaidBlockPlaceTask.super.tryPlaceBlock(maid, pos)) {
            MemoryUtil.getBlockValidationMemory(maid).setValid(pos);
            return true;
        }
        return false;
    }

    @Override
    public boolean tryDestroyBlock(EntityMaid maid, class_2338 blockPos) {
        if (MaidUtils.destroyBlock(maid, blockPos)) {
            MemoryUtil.getBlockValidationMemory(maid).remove(blockPos);
            return true;
        }
        return false;
    }

    /**
     * 此处判断当home模式未开启时，不允许上搭。
     *
     * @param maid
     * @param center
     * @param maxUp
     * @return
     */
    @Override
    public oshi.util.tuples.Pair<class_2338, class_2338> findTargetPosBlockUp(EntityMaid maid, class_2338 center, int maxUp) {
        if (maid.isHomeModeEnable() && MaidLoggingConfig.get(maid).blockUp() && !Config.disableLoggingBlockUp)
            return IMaidBlockUpTask.super.findTargetPosBlockUp(maid, center, maxUp);
        return null;
    }
}