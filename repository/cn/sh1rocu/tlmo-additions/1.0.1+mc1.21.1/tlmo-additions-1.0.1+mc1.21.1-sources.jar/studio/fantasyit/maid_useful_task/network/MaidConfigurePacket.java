package studio.fantasyit.maid_useful_task.network;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.maid_useful_task.MaidUsefulTask;
import studio.fantasyit.maid_useful_task.data.IConfigSetter;
import studio.fantasyit.maid_useful_task.data.MaidConfigKeys;

public class MaidConfigurePacket implements class_8710 {
    final public int maidId;
    final public String name;
    final public String value;
    final public class_2960 key;
    public static final class_8710.class_9154<MaidConfigurePacket> TYPE = new class_8710.class_9154<>(
            class_2960.method_60655(
                    MaidUsefulTask.MODID, "maid_config"
            )
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public MaidConfigurePacket(int maidId, class_2960 key, String name, String value) {
        this.maidId = maidId;
        this.key = key;
        this.name = name;
        this.value = value;
    }

    public static Codec<MaidConfigurePacket> CODEC = RecordCodecBuilder.create(instance ->
            instance.group(
                    Codec.INT.fieldOf("maidId").forGetter(packet -> packet.maidId),
                    class_2960.field_25139.fieldOf("key").forGetter(packet -> packet.key),
                    Codec.STRING.fieldOf("name").forGetter(packet -> packet.name),
                    Codec.STRING.fieldOf("value").forGetter(packet -> packet.value)
            ).apply(instance, MaidConfigurePacket::new)
    );
    public static class_9139<ByteBuf, MaidConfigurePacket> STREAM_CODEC = class_9139.method_56905(
            class_9135.field_49675,
            t -> t.maidId,
            class_2960.field_48267,
            t -> t.key,
            class_9135.field_48554,
            t -> t.name,
            class_9135.field_48554,
            t -> t.value,
            MaidConfigurePacket::new
    );

    @Environment(EnvType.CLIENT)
    public static void send(EntityMaid maid, class_2960 key, String name, String value) {
        ClientPlayNetworking.send(new MaidConfigurePacket(maid.method_5628(), key, name, value));
    }


    public static void handle(MaidConfigurePacket msg, ServerPlayNetworking.Context context) {
        context.server().execute(() -> {
            @Nullable class_3222 sender = context.player();
            if (sender.method_37908().method_8469(msg.maidId) instanceof EntityMaid entityMaid) {
                if (MaidConfigKeys.getValue(entityMaid, msg.key) instanceof IConfigSetter ics) {
                    ics.setConfigValue(msg.name, msg.value);
                }
            }
        });
    }
}