package studio.fantasyit.maid_useful_task.data;

import com.github.tartaricacid.touhoulittlemaid.api.entity.data.TaskDataKey;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import studio.fantasyit.maid_useful_task.MaidUsefulTask;

public class MaidReviveConfig implements TaskDataKey<MaidReviveConfig.Data> {
    public static final class Data implements IConfigSetter {
        private boolean ownerOnly;

        public Data(boolean ownerOnly) {
            this.ownerOnly = ownerOnly;
        }

        public static Data getDefault() {
            return new Data(false);
        }

        public boolean ownerOnly() {
            return ownerOnly;
        }

        public void ownerOnly(boolean ownerOnly) {
            this.ownerOnly = ownerOnly;
        }

        @Override
        public void setConfigValue(String name, String value) {
            switch (name) {
                case "ownerOnly":
                    ownerOnly = Boolean.parseBoolean(value);
                    break;
            }
        }
    }

    public static TaskDataKey<Data> KEY = null;
    public static final class_2960 LOCATION = class_2960.method_60655(MaidUsefulTask.MODID, "revive");

    @Override
    public class_2960 getKey() {
        return LOCATION;
    }

    @Override
    public class_2487 writeSaveData(Data data) {
        class_2487 tag = new class_2487();
        tag.method_10556("ownerOnly", data.ownerOnly);
        return tag;
    }

    @Override
    public Data readSaveData(class_2487 compound) {
        boolean plant = compound.method_10577("ownerOnly");
        return new Data(plant);
    }
}
