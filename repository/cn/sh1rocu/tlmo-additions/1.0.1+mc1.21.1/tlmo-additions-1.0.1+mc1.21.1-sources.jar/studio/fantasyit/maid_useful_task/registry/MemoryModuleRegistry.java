package studio.fantasyit.maid_useful_task.registry;

import studio.fantasyit.maid_useful_task.MaidUsefulTask;
import studio.fantasyit.maid_useful_task.memory.BlockTargetMemory;
import studio.fantasyit.maid_useful_task.memory.BlockUpContext;
import studio.fantasyit.maid_useful_task.memory.BlockValidationMemory;
import studio.fantasyit.maid_useful_task.memory.CurrentWork;
import studio.fantasyit.maid_useful_task.vehicle.MaidVehicleControlType;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4140;
import net.minecraft.class_7923;

public class MemoryModuleRegistry {
    public static final class_4140<BlockTargetMemory> DESTROY_TARGET
            = register("block_targets", new class_4140<>(Optional.of(BlockTargetMemory.CODEC)));
    public static final class_4140<class_2338> PLACE_TARGET
            = register("place_target", new class_4140<>(Optional.empty()));
    public static final class_4140<BlockUpContext> BLOCK_UP_TARGET
            = register("block_up", new class_4140<>(Optional.of(BlockUpContext.CODEC)));
    public static final class_4140<BlockValidationMemory> BLOCK_VALIDATION
            = register("block_validation", new class_4140<>(Optional.of(BlockValidationMemory.CODEC)));
    public static final class_4140<class_2338> COMMON_BLOCK_CACHE
            = register("common_block_cache", new class_4140<>(Optional.empty()));
    public static final class_4140<UUID> REVIVING_PLAYER
            = register("reviving_player", new class_4140<>(Optional.empty()));
    public static final class_4140<class_1799> LOCATE_ITEM = register("locate_item", new class_4140<>(Optional.empty()));
    public static final class_4140<CurrentWork> CURRENT_WORK = register("current_work", new class_4140<>(Optional.empty()));
    public static final class_4140<MaidVehicleControlType> IS_ALLOW_HANDLE_VEHICLE = register("is_allow_handle_vehicle", new class_4140<>(Optional.empty()));

    private static <T> class_4140<T> register(String name, class_4140<T> type) {
        return class_2378.method_10230(class_7923.field_41129, class_2960.method_60655(MaidUsefulTask.MODID, name), type);
    }

    public static void init() {

    }
}
