package studio.fantasyit.maid_useful_task.network;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import studio.fantasyit.maid_useful_task.Config;
import studio.fantasyit.maid_useful_task.MaidUsefulTask;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;
import studio.fantasyit.maid_useful_task.vehicle.MaidVehicleControlType;

public class MaidAllowHandleVehicle implements class_8710 {
    public static final class_8710.class_9154<MaidAllowHandleVehicle> TYPE = new class_8710.class_9154<>(
            class_2960.method_60655(
                    MaidUsefulTask.MODID, "allow_handle_vehicle"
            )
    );

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    final int maidId;

    public MaidAllowHandleVehicle(EntityMaid maid) {
        this.maidId = maid.method_5628();
    }

    public MaidAllowHandleVehicle(int maidId) {
        this.maidId = maidId;
    }


    public static Codec<MaidAllowHandleVehicle> CODEC = RecordCodecBuilder.create(instance ->
            instance.group(
                    Codec.INT.fieldOf("maidId").forGetter(packet -> packet.maidId)
            ).apply(instance, MaidAllowHandleVehicle::new)
    );
    public static class_9139<ByteBuf, MaidAllowHandleVehicle> STREAM_CODEC = class_9139.method_56434(
            class_9135.field_49675,
            t -> t.maidId,
            MaidAllowHandleVehicle::new
    );

    public static void handle(MaidAllowHandleVehicle msg, ServerPlayNetworking.Context context) {
        context.server().execute(() -> {
            class_3222 sender = context.player();
            class_1297 entity = sender.method_37908().method_8469(msg.maidId);
            if (entity instanceof EntityMaid maid) {
                MaidVehicleControlType[] values = MaidVehicleControlType.values();
                MaidVehicleControlType allowMode = values[(MemoryUtil.getAllowHandleVehicle(maid).ordinal() + 1) % values.length];
                while ((allowMode == MaidVehicleControlType.FULL && !Config.enableVehicleControlFull)
                        || (allowMode == MaidVehicleControlType.ROT_ONLY && !Config.enableVehicleControlRotate)) {
                    allowMode = values[(allowMode.ordinal() + 1) % values.length];
                }
                MemoryUtil.setAllowHandleVehicle(maid, allowMode);
                class_2561 component = switch (allowMode) {
                    case NONE -> class_2561.method_43471("maid_useful_task.allow_handle_vehicle.none");
                    case ROT_ONLY -> class_2561.method_43471("maid_useful_task.allow_handle_vehicle.rot_only");
                    case FULL -> class_2561.method_43471("maid_useful_task.allow_handle_vehicle.full");
                };
                sender.method_43496(component);
            }
        });
    }
}