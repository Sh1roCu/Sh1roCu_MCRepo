package studio.fantasyit.maid_useful_task.network;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import studio.fantasyit.maid_useful_task.MaidUsefulTask;
import studio.fantasyit.maid_useful_task.vehicle.MaidVehicleManager;

public class MaidSyncVehiclePacket implements class_8710 {

    public static final class_8710.class_9154<MaidSyncVehiclePacket> TYPE = new class_8710.class_9154<>(
            class_2960.method_60655(
                    MaidUsefulTask.MODID, "sync_vehicle"
            )
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    final class_2487 tag;
    final int maidId;

    public MaidSyncVehiclePacket(int maidId, class_2487 tag) {
        this.maidId = maidId;
        this.tag = tag;
    }

    public static Codec<MaidSyncVehiclePacket> CODEC = RecordCodecBuilder.create(instance ->
            instance.group(
                    Codec.INT.fieldOf("maidId").forGetter(packet -> packet.maidId),
                    class_2487.field_25128.fieldOf("tag").forGetter(packet -> packet.tag)
            ).apply(instance, MaidSyncVehiclePacket::new)
    );
    public static class_9139<class_9129, MaidSyncVehiclePacket> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_49675,
            t -> t.maidId,
            class_9135.field_48556,
            t -> t.tag,
            MaidSyncVehiclePacket::new
    );


    @Environment(EnvType.CLIENT)
    public static void handle(MaidSyncVehiclePacket msg, ClientPlayNetworking.Context context) {
        context.client().execute(() -> {
            class_1297 entity = context.player().method_37908().method_8469(msg.maidId);
            if (entity instanceof EntityMaid maid) {
                MaidVehicleManager.getControllableVehicle(maid).ifPresent(vehicle -> {
                    vehicle.syncVehicleParameter(maid, msg.tag);
                });
            }
        });
    }
}