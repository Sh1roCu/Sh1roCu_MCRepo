package com.sch246.muhc.create;

import com.sch246.muhc.MaidUseHandCrank;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PointOfInterestHelper;
import net.minecraft.class_2960;
import net.minecraft.class_4158;

public class InitPoi {
    // TODO: wait official Create-Fabric-1.21
    // public static final PoiType HAND_CRANK = register("hand_crank", PoiManager.getCrankPoiType());

    private static class_4158 register(String name, class_4158 poiType) {
        return PointOfInterestHelper.register(class_2960.method_60655(MaidUseHandCrank.MODID, name),
                poiType.comp_816(), poiType.comp_817(), poiType.comp_815());
    }

    public static void init() {

    }
}