package com.sch246.muhc.config;

import com.sch246.muhc.Config;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.neoforged.neoforge.common.ModConfigSpec;

import java.util.List;

public final class ClothConfigScreen {
    private ClothConfigScreen() {
    }

    /**
     * Forge 模组菜单入口专用：创建完整的 Screen
     */
    public static class_437 create(class_437 parent) {
        // 1. 创建 Builder
        ConfigBuilder root = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(class_2561.method_43471("muhc.configuration.title"));

        // 设置全局样式
        root.setGlobalized(true);
        root.setGlobalizedExpanded(false);

        // 2. 调用共用的填充逻辑
        init(root, root.entryBuilder());

        return root.build();
    }

    @SuppressWarnings("unchecked")
    public static void init(ConfigBuilder root, ConfigEntryBuilder entryBuilder) {
        var main = root.getOrCreateCategory(class_2561.method_43471("muhc.configuration.title"));
        for (Config.Category cat : Config.getCategories()) {
            // 类别标题键：muhc.configuration.<category>
            var cc = entryBuilder.startSubCategory(class_2561.method_43471(cat.labelKey)).setExpanded(true);
            for (Config.Entry<?> e : cat.entries) {
                switch (e.type) {
                    case INT -> {
                        ModConfigSpec.IntValue h = (ModConfigSpec.IntValue) e.valueHandle;
                        int cur = h.get();
                        var r = (Config.NumericRange<Integer>) e.range;
                        var ent = entryBuilder.startIntField(class_2561.method_43471(e.labelKey), cur)
                                .setDefaultValue((Integer) e.defaultValue)
                                .setMin(r.min)
                                .setMax(r.max)
                                .setTooltip(class_2561.method_43471(e.tooltipKey))
                                .setSaveConsumer(h::set)
                                .build();
                        cc.add(ent);
                    }
                    case BOOLEAN -> {
                        ModConfigSpec.BooleanValue h = (ModConfigSpec.BooleanValue) e.valueHandle;
                        boolean cur = h.get();
                        var ent = entryBuilder.startBooleanToggle(class_2561.method_43471(e.labelKey), cur)
                                .setDefaultValue((Boolean) e.defaultValue)
                                .setTooltip(class_2561.method_43471(e.tooltipKey))
                                .setSaveConsumer(h::set)
                                .build();
                        cc.add(ent);
                    }
                    case DOUBLE -> {
                        ModConfigSpec.DoubleValue h = (ModConfigSpec.DoubleValue) e.valueHandle;
                        double cur = h.get();
                        var r = (Config.NumericRange<Double>) e.range;
                        var ent = entryBuilder.startDoubleField(class_2561.method_43471(e.labelKey), cur)
                                .setDefaultValue((Double) e.defaultValue)
                                .setMin(r.min)
                                .setMax(r.max)
                                .setTooltip(class_2561.method_43471(e.tooltipKey))
                                .setSaveConsumer(h::set)
                                .build();
                        cc.add(ent);
                    }
                    case STRING_LIST -> {
                        ModConfigSpec.ConfigValue<List<String>> h = (ModConfigSpec.ConfigValue<List<String>>) e.valueHandle;
                        List<String> cur = h.get();
                        var ent = entryBuilder.startStrList(class_2561.method_43471(e.labelKey), cur)
                                .setDefaultValue((List<String>) e.defaultValue)
                                .setTooltip(class_2561.method_43471(e.tooltipKey))
                                .setSaveConsumer(h::set)
                                .build();
                        cc.add(ent);
                    }
                }
            }

            main.addEntry(cc.build());
        }
    }
}