package com.github.touhoumaidaffection;

import com.github.touhoumaidaffection.effect.MaidsPrayerEffect;
import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModEffects {
    public static final class_1291 MAIDS_PRAYER = class_2378.method_10230(class_7923.field_41174,
            class_2960.method_60655(TouhouMaidAffection.MOD_ID, "maids_prayer"),
            new MaidsPrayerEffect());

    public static void init() {

    }
}
