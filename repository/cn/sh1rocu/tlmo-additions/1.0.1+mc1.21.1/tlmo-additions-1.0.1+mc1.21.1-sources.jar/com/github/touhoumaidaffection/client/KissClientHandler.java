package com.github.touhoumaidaffection.client;

import com.github.touhoumaidaffection.ModConfig;
import com.github.touhoumaidaffection.network.KissMaidPayload;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_638;

@Environment(EnvType.CLIENT)
public class KissClientHandler {
    public static void handle(KissMaidPayload payload, ClientPlayNetworking.Context context) {
        context.client().execute(() -> {
            class_638 level = class_310.method_1551().field_1687;
            if (level == null) return;

            class_1297 maid = level.method_8469(payload.maidEntityId());
            class_1297 player = level.method_8469(payload.playerEntityId());
            if (maid == null || player == null) return;

            // Trigger FOV zoom if this is the local player
            if (player == class_310.method_1551().field_1724 && ModConfig.FOV_ZOOM_ENABLED.get()) {
                boolean carriedKiss = maid.method_5854() == player;
                KissFovHandler.trigger(maid.method_5628(), carriedKiss);
            }

            KissParticleEffectManager.queueKissEffect(maid, player);
        });
    }
}
