package com.github.touhoumaidaffection.network;

import com.github.touhoumaidaffection.TouhouMaidAffection;
import com.github.touhoumaidaffection.handler.KissMaidHandler;
import io.netty.buffer.ByteBuf;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public class KissCarryRequestPayload implements class_8710 {
    public static final class_8710.class_9154<KissCarryRequestPayload> TYPE =
            new class_8710.class_9154<>(class_2960.method_60655(TouhouMaidAffection.MOD_ID, "kiss_carry_request"));

    public static final KissCarryRequestPayload DUMMY = new KissCarryRequestPayload();

    public static final class_9139<ByteBuf, KissCarryRequestPayload> STREAM_CODEC = class_9139.method_56431(DUMMY);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public static void handle(KissCarryRequestPayload payload, ServerPlayNetworking.Context context) {
        context.server().execute(() -> {
            KissMaidHandler.tryKissCarriedMaid(context.player());
        });
    }
}