package com.github.touhoumaidaffection;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class ModSounds {
    public static final class_3414 KISS = class_2378.method_10230(class_7923.field_41172, class_2960.method_60655(TouhouMaidAffection.MOD_ID, "kiss"),
            class_3414.method_47908(
                    class_2960.method_60655(TouhouMaidAffection.MOD_ID, "touhou_maid_affection.kiss")
            ));

    public static void init() {

    }
}
