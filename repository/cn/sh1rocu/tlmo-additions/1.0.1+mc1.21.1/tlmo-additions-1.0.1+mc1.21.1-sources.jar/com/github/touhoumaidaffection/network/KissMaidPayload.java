package com.github.touhoumaidaffection.network;

import com.github.touhoumaidaffection.TouhouMaidAffection;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record KissMaidPayload(int maidEntityId, int playerEntityId) implements class_8710 {

    public static final class_8710.class_9154<KissMaidPayload> TYPE =
            new class_8710.class_9154<>(class_2960.method_60655(TouhouMaidAffection.MOD_ID, "kiss_maid"));

    public static final class_9139<ByteBuf, KissMaidPayload> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48550, KissMaidPayload::maidEntityId,
            class_9135.field_48550, KissMaidPayload::playerEntityId,
            KissMaidPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}