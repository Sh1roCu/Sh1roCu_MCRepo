package com.mastermarisa.maidbeacon.client.gui;

import com.mastermarisa.maidbeacon.client.gui.base.ImageData;
import java.awt.*;
import net.minecraft.class_2960;

public interface UIConst {
    ImageData buttonImg = new ImageData(
            class_2960.method_60654("minecraft:textures/gui/sprites/container/beacon/button.png"),
            new Rectangle(0, 0, 22, 22),
            22, 22,
            22, 22
    );

    ImageData disabledImg = new ImageData(
            class_2960.method_60654("minecraft:textures/gui/sprites/container/beacon/button_disabled.png"),
            new Rectangle(0, 0, 22, 22),
            22, 22,
            22, 22
    );
}
