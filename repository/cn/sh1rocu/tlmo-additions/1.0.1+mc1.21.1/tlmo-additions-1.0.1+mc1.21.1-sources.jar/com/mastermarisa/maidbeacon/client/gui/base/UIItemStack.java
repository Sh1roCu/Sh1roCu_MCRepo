package com.mastermarisa.maidbeacon.client.gui.base;

import java.awt.*;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_2561;
import net.minecraft.class_332;

public class UIItemStack extends UIElement {
    public static final int size = 16;
    public class_1799 itemStack;
    public boolean renderTooltip = true;

    public UIItemStack(class_1799 itemStack) {
        super(new Rectangle(16, 16));
        this.itemStack = itemStack;
    }

    public UIItemStack(class_1856 ingredient) {
        super(new Rectangle(16, 16));
        this.itemStack = new class_1799(ingredient.method_8105()[0].method_7909());
    }

    protected void render(class_332 graphics, int mouseX, int mouseY) {
        super.render(graphics, mouseX, mouseY);
        graphics.method_51427(this.itemStack, this.frame.x + (this.frame.width - 16) / 2, this.frame.y + (this.frame.height - 16) / 2);
    }

    public boolean hasTooltip() {
        return true;
    }

    @Override
    protected void tryRenderTooltip(class_332 graphics, int mouseX, int mouseY) {
        boolean hover = frame.contains(mouseX, mouseY);
        if (hover && renderTooltip) {
            if (!tooltip.isEmpty()) {
                this.renderTooltip(graphics, this.itemStack, tooltip, mouseX, mouseY);
            } else {
                List<class_2561> lines = this.itemStack.method_7950(class_1792.class_9635.method_59528(mc.field_1687), mc.field_1724, mc.field_1690.field_1827 ? class_1836.class_1837.field_41071 : class_1836.class_1837.field_41070);
                this.renderTooltip(graphics, this.itemStack, lines, mouseX, mouseY);
            }
        }
    }
}
