package com.mastermarisa.maidbeacon.network;

import com.mastermarisa.maidbeacon.MaidBeacon;
import com.mastermarisa.maidbeacon.config.Config;
import com.mastermarisa.maidbeacon.data.MobileBeaconData;
import com.mastermarisa.maidbeacon.init.ModDataComponents;
import com.mastermarisa.maidbeacon.init.ModItems;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public record OperateEffectPayload(int actionCode, int index, int hand, UUID uuid) implements class_8710 {
    public static final class_8710.class_9154<OperateEffectPayload> TYPE =
            new class_8710.class_9154<>(MaidBeacon.resourceLocation("change_aura_state"));

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public static final class_9139<class_2540, OperateEffectPayload> STREAM_CODEC =
            class_9139.method_56905(
                    class_9135.field_49675,
                    OperateEffectPayload::actionCode,
                    class_9135.field_49675,
                    OperateEffectPayload::index,
                    class_9135.field_49675,
                    OperateEffectPayload::hand,
                    class_4844.field_48453,
                    OperateEffectPayload::uuid,
                    OperateEffectPayload::new
            );

    public static void handle(OperateEffectPayload payload, ServerPlayNetworking.Context context) {
        context.server().execute(() -> {
            class_3218 level = context.player().method_51469();
            class_3222 player = (class_3222) level.method_18470(payload.uuid());
            if (player != null) {
                class_1799 itemInHand = player.method_5998(payload.hand == 0 ? class_1268.field_5808 : class_1268.field_5810);
                if (itemInHand.method_31574(ModItems.MOBILE_BEACON)) {
                    MobileBeaconData mobileBeaconData = itemInHand.method_57825(ModDataComponents.MOBILE_BEACON_DATA, new MobileBeaconData());
                    switch (payload.actionCode) {
                        case 0 -> {
                            mobileBeaconData.activated.remove(payload.index());
                        }
                        case 1 -> {
                            if (mobileBeaconData.getUsedCost() + Config.EFFECT_AURAS().get(payload.index).cost <= Config.getCost(mobileBeaconData.getLevel())) {
                                mobileBeaconData.activated.add(payload.index());
                            }
                        }
                    }
                    itemInHand.method_57379(ModDataComponents.MOBILE_BEACON_DATA, mobileBeaconData);
                }
            }
        });
    }
}