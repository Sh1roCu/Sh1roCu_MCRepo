package com.mastermarisa.maidbeacon.client.render;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5253;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;

public class BeaconRenderer {
    public static final class_2960 BEAM_LOCATION = class_2960.method_60655("minecraft", "textures/entity/beacon_beam.png");

    public static void renderBeaconBeam(class_4587 poseStack, class_4597 bufferSource, float partialTick, float textureScale, long gameTime,
                                        int yOffset, int height, int color, float beamRadius, float glowRadius, @Nullable Quaternionf quaternion, EntityMaid maid) {
        int i = yOffset + height;
        poseStack.method_22903();
        double offset = 0.28D;
        if (maid.isMaidInSittingPose()) offset -= 0.6D;
        poseStack.method_22904(0, offset, 0);
        if (quaternion != null) poseStack.method_22907(quaternion);
        float f = (float) Math.floorMod(gameTime, 40) + partialTick;
        float f1 = height < 0 ? f : -f;
        float f2 = class_3532.method_22450(f1 * 0.2F - (float) class_3532.method_15375(f1 * 0.1F));
        poseStack.method_22903();
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(f * 2.25F - 45.0F));
        float f3;
        float f5;
        float f6 = -beamRadius;
        float f9 = -beamRadius;
        float f12 = -1.0F + f2;
        float f13 = (float) height * textureScale * (0.5F / beamRadius) + f12;
        net.minecraft.class_822.method_22741(poseStack, bufferSource.getBuffer(class_1921.method_23592(BEAM_LOCATION, false)), color, yOffset, i, 0.0F, beamRadius, beamRadius, 0.0F, f6, 0.0F, 0.0F, f9, 0.0F, 1.0F, f13, f12);
        poseStack.method_22909();
        f3 = -glowRadius;
        float f4 = -glowRadius;
        f5 = -glowRadius;
        f6 = -glowRadius;
        f12 = -1.0F + f2;
        f13 = (float) height * textureScale + f12;
        net.minecraft.class_822.method_22741(poseStack, bufferSource.getBuffer(class_1921.method_23592(BEAM_LOCATION, true)), class_5253.class_5254.method_58144(32, color), yOffset, i, f3, f4, glowRadius, f5, f6, glowRadius, glowRadius, glowRadius, 0.0F, 1.0F, f13, f12);
        poseStack.method_22909();
    }

    public static void renderBeaconModel(class_4587 poseStack, class_4597 bufferSource, int packedLight, EntityMaid entity, float partialTick) {
        poseStack.method_22903();
        poseStack.method_22904(0.0F, (double) entity.method_17682() + (entity.isMaidInSittingPose() ? -0.1 : 0.4) - 1, 0.0F);
        long gameTime = entity.method_37908().method_8510();
        float rotation = ((float) gameTime + partialTick) * 3.0F;
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(rotation));
        poseStack.method_22905(1.0F, 1.0F, 1.0F);
        class_310.method_1551().method_1480().method_23178(new class_1799(class_1802.field_8668), class_811.field_4318, packedLight, class_4608.field_21444, poseStack, bufferSource, entity.method_37908(), entity.method_5628());
        poseStack.method_22909();
    }
}
