package com.mastermarisa.maidbeacon.entity;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mastermarisa.maidbeacon.MaidBeacon;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import org.jetbrains.annotations.Nullable;

public class ExtraRenderingEntity extends class_1297 {
    public static final class_1299<ExtraRenderingEntity> TYPE;

    private static final class_2940<Integer> DATA_OWNER_ID = class_2945
            .method_12791(ExtraRenderingEntity.class, class_2943.field_13327);

    public ExtraRenderingEntity(class_1299<?> type, class_1937 level) {
        super(type, level);
        this.field_5985 = true;
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        builder.method_56912(DATA_OWNER_ID, -1);
    }

    public void setOwnerID(Integer id) {
        this.field_6011.method_12778(DATA_OWNER_ID, id);
    }

    public Integer getOwnerID() {
        return this.field_6011.method_12789(DATA_OWNER_ID);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!method_37908().field_9236) {
            EntityMaid maid = getMaid();
            if (maid != null) {
                if (!this.method_5765()) this.method_5804(maid);
            } else {
                this.method_31472();
            }
        }
    }

    public @Nullable EntityMaid getMaid() {
        return method_37908().method_8469(getOwnerID()) instanceof EntityMaid maid ? maid : null;
    }

    @Override
    protected void method_5749(class_2487 tag) {
        if (tag.method_10545("maid")) setOwnerID(tag.method_10550("maid"));
    }

    @Override
    protected void method_5652(class_2487 tag) {
        int id = getOwnerID();
        if (id != -1) tag.method_10569("maid", id);
    }

    static {
        TYPE = class_1299.class_1300.method_5903(ExtraRenderingEntity::new, class_1311.field_17715).
                method_17687(0.1F, 0.1F)
                .method_27299(256)
                .method_20815()
                .method_5904().method_5901().method_19947()
                .method_5905(MaidBeacon.resourceLocation("extra_rendering_entity").toString());
    }
}