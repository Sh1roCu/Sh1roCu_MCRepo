package com.mastermarisa.maidbeacon.network;

import cn.sh1rocu.tlmo_additions.util.itemhandler.PlayerInvWrapper;
import cn.sh1rocu.touhoulittlemaid.util.itemhandler.IItemHandler;
import com.mastermarisa.maidbeacon.MaidBeacon;
import com.mastermarisa.maidbeacon.config.Config;
import com.mastermarisa.maidbeacon.data.MobileBeaconData;
import com.mastermarisa.maidbeacon.init.ModDataComponents;
import com.mastermarisa.maidbeacon.init.ModItems;
import com.mastermarisa.maidbeacon.utils.MaidUtils;
import com.mastermarisa.maidbeacon.utils.StackPredicate;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

import java.lang.ref.WeakReference;
import java.util.List;
import java.util.UUID;

public record UpgradeBeaconPayload(int index, UUID uuid, int hand) implements class_8710 {
    public static final class_8710.class_9154<UpgradeBeaconPayload> TYPE =
            new class_8710.class_9154<>(MaidBeacon.resourceLocation("upgrade_beacon"));

    @Override
    public @NotNull class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public static final class_9139<class_2540, UpgradeBeaconPayload> STREAM_CODEC =
            class_9139.method_56436(
                    class_9135.field_49675,
                    UpgradeBeaconPayload::index,
                    class_4844.field_48453,
                    UpgradeBeaconPayload::uuid,
                    class_9135.field_49675,
                    UpgradeBeaconPayload::hand,
                    UpgradeBeaconPayload::new
            );

    public static void handle(UpgradeBeaconPayload payload, ServerPlayNetworking.Context context) {
        context.server().execute(() -> {
            class_3218 level = (class_3218) context.player().method_37908();
            class_3222 player = (class_3222) level.method_18470(payload.uuid());
            if (player != null) {
                class_1799 itemInHand = player.method_5998(payload.hand == 0 ? class_1268.field_5808 : class_1268.field_5810);
                if (itemInHand.method_31574(ModItems.MOBILE_BEACON)) {
                    MobileBeaconData mobileBeaconData = itemInHand.method_57825(ModDataComponents.MOBILE_BEACON_DATA, new MobileBeaconData());
                    if (mobileBeaconData.getLevel() == payload.index) {
                        class_1799 required = Config.ITEMSTACK_TO_UPGRADE_BEACON_LEVEL().get(payload.index);
                        IItemHandler itemHandler = new PlayerInvWrapper(player.field_7514);
                        WeakReference<IItemHandler> ref = new WeakReference<>(itemHandler);
                        List<class_1799> itemStackList = MaidUtils.tryExtract(ref.get(), required.method_7947(), StackPredicate.of(required.method_7909()), true);
                        if (!itemStackList.isEmpty()) {
                            mobileBeaconData.setLevel(mobileBeaconData.getLevel() + 1);
                        }
                        itemHandler = null;
                    }
                    itemInHand.method_57379(ModDataComponents.MOBILE_BEACON_DATA, mobileBeaconData);
                }
            }
        });
    }
}
