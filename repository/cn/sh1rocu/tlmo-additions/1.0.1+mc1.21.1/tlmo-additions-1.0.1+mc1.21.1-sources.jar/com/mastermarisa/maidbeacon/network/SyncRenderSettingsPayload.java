package com.mastermarisa.maidbeacon.network;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mastermarisa.maidbeacon.MaidBeacon;
import com.mastermarisa.maidbeacon.data.ExtraRenderSettings;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_3218;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public record SyncRenderSettingsPayload(UUID uuid, class_2487 compoundTag) implements class_8710 {
    public static final class_8710.class_9154<SyncRenderSettingsPayload> TYPE =
            new class_8710.class_9154<>(MaidBeacon.resourceLocation("sync_render_settings"));

    @Override
    public @NotNull class_8710.class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }

    public static final class_9139<class_2540, SyncRenderSettingsPayload> STREAM_CODEC =
            class_9139.method_56435(
                    class_4844.field_48453,
                    SyncRenderSettingsPayload::uuid,
                    class_9135.field_48556,
                    SyncRenderSettingsPayload::compoundTag,
                    SyncRenderSettingsPayload::new
            );

    @SuppressWarnings("UnstableApiUsage")
    public static void handle(SyncRenderSettingsPayload payload, ServerPlayNetworking.Context context) {
        context.server().execute(() -> {
            class_3218 level = context.player().method_51469();
            if (level.method_14190(payload.uuid()) instanceof EntityMaid maid) {
                ExtraRenderSettings settings = new ExtraRenderSettings();
                settings.deserializeNBT(level.method_30349(), payload.compoundTag());
                maid.setAttached(ExtraRenderSettings.TYPE, settings);
            }
        });
    }
}