package com.mastermarisa.maidbeacon.data;

import com.mastermarisa.maidbeacon.MaidBeacon;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.Pair;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class ExtraRenderSettings {
    public boolean enableRendering = true;
    public boolean enableBeaconBeam = true;
    public boolean enableBeaconModel = true;
    public boolean enableHeadHalo = false;
    public boolean enableSkyHalo = true;
    public byte headHaloStyle = 0;
    public byte skyHaloStyle = 0;

    public static final Codec<ExtraRenderSettings> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.BOOL.fieldOf("enable_rendering").forGetter(e -> e.enableRendering),
            Codec.BOOL.fieldOf("enable_beacon_beam").forGetter(e -> e.enableBeaconBeam),
            Codec.BOOL.fieldOf("enable_beacon_model").forGetter(e -> e.enableBeaconModel),
            Codec.BOOL.fieldOf("enable_head_halo").forGetter(e -> e.enableHeadHalo),
            Codec.BOOL.fieldOf("enable_sky_halo").forGetter(e -> e.enableSkyHalo),
            Codec.BYTE.fieldOf("head_halo_style").forGetter(e -> e.headHaloStyle),
            Codec.BYTE.fieldOf("sky_halo_style").forGetter(e -> e.skyHaloStyle)
    ).apply(instance, ExtraRenderSettings::new));

    public ExtraRenderSettings() {
        this(true, true, true, false, true, (byte) 0, (byte) 0);
    }

    public ExtraRenderSettings(boolean enableRendering, boolean enableBeaconBeam, boolean enableBeaconModel, boolean enableHeadHalo, boolean enableSkyHalo, byte headHaloStyle, byte skyHaloStyle) {
        this.enableRendering = enableRendering;
        this.enableBeaconBeam = enableBeaconBeam;
        this.enableBeaconModel = enableBeaconModel;
        this.enableHeadHalo = enableHeadHalo;
        this.enableSkyHalo = enableSkyHalo;
        this.headHaloStyle = headHaloStyle;
        this.skyHaloStyle = skyHaloStyle;
    }

    public class_2487 serializeNBT(@Nullable class_7225.class_7874 provider) {
        class_2487 tag = new class_2487();
        tag.method_10556("enable_rendering", enableRendering);
        tag.method_10556("enable_beacon_beam", enableBeaconBeam);
        tag.method_10556("enable_beacon_model", enableBeaconModel);
        tag.method_10556("enable_head_halo", enableHeadHalo);
        tag.method_10556("enable_sky_halo", enableSkyHalo);
        tag.method_10567("head_halo_style", headHaloStyle);
        tag.method_10567("sky_halo_style", skyHaloStyle);
        return tag;
    }

    public void deserializeNBT(class_7225.class_7874 provider, class_2487 tag) {
        if (tag.method_10545("enable_rendering")) {
            enableRendering = tag.method_10577("enable_rendering");
            enableBeaconBeam = tag.method_10577("enable_beacon_beam");
            enableBeaconModel = tag.method_10577("enable_beacon_model");
            enableHeadHalo = tag.method_10577("enable_head_halo");
            enableSkyHalo = tag.method_10577("enable_sky_halo");
            headHaloStyle = tag.method_10571("head_halo_style");
            skyHaloStyle = tag.method_10571("sky_halo_style");
        }
    }

    public List<Pair<String, String>> getDisplayPairs() {
        return List.of(
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.enable_rendering").getString(), String.valueOf(enableRendering)),
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.enable_beacon_beam").getString(), String.valueOf(enableBeaconBeam)),
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.enable_beacon_model").getString(), String.valueOf(enableBeaconModel)),
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.enable_head_halo").getString(), String.valueOf(enableHeadHalo)),
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.enable_sky_halo").getString(), String.valueOf(enableSkyHalo)),
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.head_halo_style").getString(), String.valueOf(headHaloStyle)),
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.sky_halo_style").getString(), String.valueOf(skyHaloStyle))
        );
    }

    public static class Syncer implements class_9139<class_9129, ExtraRenderSettings> {
        @Override
        public void encode(class_9129 registryFriendlyByteBuf, ExtraRenderSettings extraRenderSettings) {
            registryFriendlyByteBuf.method_52964(extraRenderSettings.enableRendering);
            registryFriendlyByteBuf.method_52964(extraRenderSettings.enableBeaconBeam);
            registryFriendlyByteBuf.method_52964(extraRenderSettings.enableBeaconModel);
            registryFriendlyByteBuf.method_52964(extraRenderSettings.enableHeadHalo);
            registryFriendlyByteBuf.method_52964(extraRenderSettings.enableSkyHalo);
            registryFriendlyByteBuf.method_52997(extraRenderSettings.headHaloStyle);
            registryFriendlyByteBuf.method_52997(extraRenderSettings.skyHaloStyle);
        }

        @Override
        public ExtraRenderSettings decode(class_9129 registryFriendlyByteBuf) {
            ExtraRenderSettings extraRenderSettings = new ExtraRenderSettings();
            extraRenderSettings.enableRendering = registryFriendlyByteBuf.readBoolean();
            extraRenderSettings.enableBeaconBeam = registryFriendlyByteBuf.readBoolean();
            extraRenderSettings.enableBeaconModel = registryFriendlyByteBuf.readBoolean();
            extraRenderSettings.enableHeadHalo = registryFriendlyByteBuf.readBoolean();
            extraRenderSettings.enableSkyHalo = registryFriendlyByteBuf.readBoolean();
            extraRenderSettings.headHaloStyle = registryFriendlyByteBuf.readByte();
            extraRenderSettings.skyHaloStyle = registryFriendlyByteBuf.readByte();
            return extraRenderSettings;
        }
    }

    @SuppressWarnings("UnstableApiUsage")
    public static final AttachmentType<ExtraRenderSettings> TYPE = AttachmentRegistry.create(class_2960.method_60655(MaidBeacon.MOD_ID, "extra_render_settings"),
            builder -> builder
                    .initializer(ExtraRenderSettings::new)
                    .persistent(CODEC)
                    .syncWith(new Syncer(), AttachmentSyncPredicate.all())
    );
}