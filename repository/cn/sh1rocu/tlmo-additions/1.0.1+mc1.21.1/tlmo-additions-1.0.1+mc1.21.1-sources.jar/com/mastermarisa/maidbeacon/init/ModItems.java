package com.mastermarisa.maidbeacon.init;

import com.mastermarisa.maidbeacon.MaidBeacon;
import com.mastermarisa.maidbeacon.item.MobileBeaconItem;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItems {
    public static final class_1792 MOBILE_BEACON;

    public static void init() {

    }

    static {
        MOBILE_BEACON = registerItem("mobile_beacon", new MobileBeaconItem());
    }

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(MaidBeacon.MOD_ID, name), item);
    }
}
