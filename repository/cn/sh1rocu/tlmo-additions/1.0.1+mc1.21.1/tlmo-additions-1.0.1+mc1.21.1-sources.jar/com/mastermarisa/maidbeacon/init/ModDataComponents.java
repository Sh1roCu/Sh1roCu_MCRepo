package com.mastermarisa.maidbeacon.init;

import com.mastermarisa.maidbeacon.MaidBeacon;
import com.mastermarisa.maidbeacon.data.MobileBeaconData;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9331;

public class ModDataComponents {
    public static final class_9331<MobileBeaconData> MOBILE_BEACON_DATA;

    public static void init() {

    }

    static {
        MOBILE_BEACON_DATA = class_2378.method_10230(class_7923.field_49658,
                class_2960.method_60655(MaidBeacon.MOD_ID, "mobile_beacon_data"),
                class_9331.<MobileBeaconData>method_57873().method_57881(MobileBeaconData.CODEC).method_57882(MobileBeaconData.STREAM_CODEC).method_57880());
    }
}