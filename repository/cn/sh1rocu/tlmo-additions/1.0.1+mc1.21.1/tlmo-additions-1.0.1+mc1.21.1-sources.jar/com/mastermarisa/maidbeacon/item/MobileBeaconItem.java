package com.mastermarisa.maidbeacon.item;

import com.mastermarisa.maidbeacon.client.gui.screen.beacon.BeaconScreen;
import com.mastermarisa.maidbeacon.data.MobileBeaconData;
import com.mastermarisa.maidbeacon.init.ModDataComponents;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class MobileBeaconItem extends class_1792 {
    public MobileBeaconItem() {
        super((new class_1792.class_1793()).method_7889(1));
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 usedHand) {
        class_1799 itemInHand = player.method_5998(usedHand);
        if (level.method_8608()) BeaconScreen.open(player, usedHand, itemInHand);
        return class_1271.method_22427(itemInHand);
    }

    public void method_7851(class_1799 itemStack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 tooltipFlag) {
        MobileBeaconData beaconData = itemStack.method_57825(ModDataComponents.MOBILE_BEACON_DATA, new MobileBeaconData());
        tooltip.add(class_2561.method_43470("信标等级: " + beaconData.getLevel()).method_27692(class_124.field_1075));
    }
}