package com.mastermarisa.maidbeacon.client.gui.screen.beacon.elements;

import cn.sh1rocu.tlmo_additions.util.itemhandler.PlayerInvWrapper;
import cn.sh1rocu.touhoulittlemaid.util.itemhandler.IItemHandler;
import com.mastermarisa.maidbeacon.client.gui.base.*;
import com.mastermarisa.maidbeacon.client.gui.screen.beacon.BeaconScreen;
import com.mastermarisa.maidbeacon.config.Config;
import com.mastermarisa.maidbeacon.data.MobileBeaconData;
import com.mastermarisa.maidbeacon.init.ModDataComponents;
import com.mastermarisa.maidbeacon.init.ModItems;
import com.mastermarisa.maidbeacon.network.UpgradeBeaconPayload;
import com.mastermarisa.maidbeacon.utils.MaidUtils;
import com.mastermarisa.maidbeacon.utils.StackPredicate;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import java.awt.*;

public class UIUpgradeButton extends UIButton {
    private static final Color COMMON = new Color(1, 1, 1, 0.2F);
    private static final Color HIGHLIGHT = new Color(1, 1, 1, 0.8F);
    private final UIBorderBox borderBox = new UIBorderBox(new Rectangle(21, 21), COMMON);
    private final UIBox bg = new UIBox(new Rectangle(22, 22), COMMON);
    private final UIItemStack icon;
    private final class_1657 player;
    private final IItemHandler playerItemHandler;
    private final class_1268 hand;
    private final int index;

    public UIUpgradeButton(int index, class_1657 player, class_1268 hand, BeaconScreen screen) {
        super(
                new Rectangle(22, 22),
                (btn) -> ((UIUpgradeButton) btn).trigger(screen),
                0
        );

        this.index = index;
        this.player = player;
        this.playerItemHandler = new PlayerInvWrapper(player.field_7514);
        this.hand = hand;
        class_1799 itemStack = index == -1 ? new class_1799(ModItems.MOBILE_BEACON) : Config.ITEMSTACK_TO_UPGRADE_BEACON_LEVEL().get(index).method_7972();
        icon = new UIItemStack(itemStack);
        icon.renderTooltip = false;
    }

    @Override
    protected void render(class_332 graphics, int mouseX, int mouseY) {
        icon.setMinX(getMinX() + 3);
        icon.setMinY(getMinY() + 3);
        borderBox.setMinX(getMinX());
        borderBox.setMinY(getMinY());
        if (unlocked()) {
            borderBox.color = HIGHLIGHT;
            bg.setMinX(getMinX());
            bg.setMinY(getMinY());
            UIElement.render(graphics, bg, mouseX, mouseY);
        } else {
            borderBox.color = COMMON;
        }
        UIElement.render(graphics, borderBox, mouseX, mouseY);
        UIElement.render(graphics, icon, mouseX, mouseY);

        super.render(graphics, mouseX, mouseY);
    }

    private boolean unlocked() {
        class_1799 itemInHand = player.method_5998(hand);
        boolean result = index == -1 || (itemInHand.method_31574(ModItems.MOBILE_BEACON)
                && itemInHand.method_57825(ModDataComponents.MOBILE_BEACON_DATA, new MobileBeaconData()).getLevel() > index);

        tooltip.clear();
        if (result) {
            tooltip.add(class_2561.method_43469("jade.maidbeacon.tooltip.beacon_level", index + 1).method_27692(class_124.field_1075));
        } else {
            tooltip.add(class_2561.method_43469("jade.maidbeacon.tooltip.beacon_level", index + 1).method_27692(class_124.field_1080));
            class_1799 required = Config.ITEMSTACK_TO_UPGRADE_BEACON_LEVEL().get(index);
            tooltip.add(class_2561.method_43469("gui.maidbeacon.tooltip.locked", required.method_7964().getString() + " x" + required.method_7947()).method_27692(class_124.field_1080));
        }

        return result;
    }

    public void trigger(BeaconScreen screen) {
        if (unlocked()) return;
        class_1799 itemStack = Config.ITEMSTACK_TO_UPGRADE_BEACON_LEVEL().get(index).method_7972();
        if (MaidUtils.count(playerItemHandler, StackPredicate.of(itemStack.method_7909())) >= itemStack.method_7947()) {
            UpgradeBeaconPayload payload = new UpgradeBeaconPayload(index, player.method_5667(), hand == class_1268.field_5808 ? 0 : 1);
            ClientPlayNetworking.send(payload);
            class_1799 itemInHand = player.method_5998(hand);
            MobileBeaconData mobileBeaconData = itemInHand.method_57825(ModDataComponents.MOBILE_BEACON_DATA, new MobileBeaconData());
            mobileBeaconData.setLevel(mobileBeaconData.getLevel() + 1);
            itemInHand.method_57379(ModDataComponents.MOBILE_BEACON_DATA, mobileBeaconData);
            screen.initUI();
        }
    }
}
