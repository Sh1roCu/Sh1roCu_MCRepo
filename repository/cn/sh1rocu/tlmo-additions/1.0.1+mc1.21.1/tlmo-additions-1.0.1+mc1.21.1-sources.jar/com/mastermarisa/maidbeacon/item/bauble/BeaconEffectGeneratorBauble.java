package com.mastermarisa.maidbeacon.item.bauble;

import com.github.tartaricacid.touhoulittlemaid.api.bauble.IMaidBauble;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.inventory.handler.BaubleItemHandler;
import com.mastermarisa.maidbeacon.config.Config;
import com.mastermarisa.maidbeacon.data.EffectAura;
import com.mastermarisa.maidbeacon.data.MobileBeaconData;
import com.mastermarisa.maidbeacon.init.ModDataComponents;
import com.mastermarisa.maidbeacon.utils.EntityFilter;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class BeaconEffectGeneratorBauble implements IMaidBauble {
    @Override
    public void onTick(EntityMaid maid, class_1799 baubleItem) {
        class_1937 level = maid.method_37908();
        if (level.method_8608() || level.method_8510() % Config.CHECK_INTERVAL() != 0) return;
        MobileBeaconData beaconData = baubleItem.method_57825(ModDataComponents.MOBILE_BEACON_DATA, new MobileBeaconData());
        ConcurrentHashMap<Float, List<EffectAura>> batched = beaconData.batched();
        for (float range : batched.keySet()) {
            List<class_1309> targets = level.method_18467(class_1309.class, maid.method_5829().method_1014(range));
            targets.stream().filter(e -> EntityFilter.filter(e.method_5864()) && e.method_5858(maid) <= Math.pow(range, 2.0D)).forEach(e -> {
                for (EffectAura aura : batched.get(range)) {
                    e.method_6092(new class_1293(
                            aura.getHolder(),
                            Math.min(Config.CHECK_INTERVAL() + 10, 60),
                            aura.effectLevel,
                            false,
                            true
                    ));
                }
            });
        }
    }

    @Override
    public void onPutOn(EntityMaid maid, class_1799 baubleItem) {
        BaubleItemHandler handler = maid.getMaidBauble();
        for (int i = 0; i < handler.getSlots(); i++) {
            if (handler.getBaubleInSlot(i) instanceof BeaconEffectGeneratorBauble && !handler.getStackInSlot(i).equals(baubleItem)) {
                class_1799 toDrop = handler.extractItem(i, 1, false);
                class_1542 entity = new class_1542(maid.method_37908(), maid.method_23317(), maid.method_23318(), maid.method_23321(), toDrop);
                entity.method_6988();
                maid.method_37908().method_8649(entity);
            }
        }
    }

    @Override
    public boolean syncClient(EntityMaid maid, class_1799 baubleItem) {
        return true;
    }
}