package studio.fantasyit.maid_useful_task.task;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;
import studio.fantasyit.maid_useful_task.vehicle.MaidVehicleControlType;
import studio.fantasyit.maid_useful_task.vehicle.MaidVehicleManager;

public interface IMaidVehicleControlTask {
    class_2338 findTarget(class_3218 level, EntityMaid maid);

    default void tick(class_3218 level, EntityMaid maid) {
        MaidVehicleControlType allowHandleVehicle = MemoryUtil.getAllowHandleVehicle(maid);
        class_2338 targetPos = findTarget(level, maid);
        MaidVehicleManager.getControllableVehicle(maid).ifPresent(vehicle -> {
            if (targetPos == null) {
                vehicle.maidStopControlVehicle(maid);
            } else {
                vehicle.maidControlVehicle(maid, allowHandleVehicle, targetPos);
            }
        });
    }
}
