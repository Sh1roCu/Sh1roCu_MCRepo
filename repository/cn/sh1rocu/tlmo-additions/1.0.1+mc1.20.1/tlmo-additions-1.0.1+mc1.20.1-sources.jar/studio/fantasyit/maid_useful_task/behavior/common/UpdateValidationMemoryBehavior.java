package studio.fantasyit.maid_useful_task.behavior.common;

import com.github.tartaricacid.touhoulittlemaid.entity.ai.brain.task.MaidCheckRateTask;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import studio.fantasyit.maid_useful_task.registry.MemoryModuleRegistry;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;

import java.util.Map;
import net.minecraft.class_3218;
import net.minecraft.class_4141;

public class UpdateValidationMemoryBehavior extends MaidCheckRateTask {
    public UpdateValidationMemoryBehavior() {
        super(Map.of(MemoryModuleRegistry.BLOCK_VALIDATION, class_4141.field_18456));
        this.setMaxCheckRate(600);
    }

    @Override
    protected void start(class_3218 p_22540_, EntityMaid p_22541_, long p_22542_) {
        //Hardcoded range?
        MemoryUtil.getBlockValidationMemory(p_22541_).clearFaraway(p_22541_.method_24515(), 72);
        MemoryUtil.getBlockValidationMemory(p_22541_).clearIf(pos -> p_22540_.method_8320(pos).method_26215());
    }
}
