package studio.fantasyit.maid_useful_task.task;

import cn.sh1rocu.touhoulittlemaid.util.itemhandler.CombinedInvWrapper;
import com.github.tartaricacid.touhoulittlemaid.api.task.IMaidTask;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.MaidPathFindingBFS;
import com.github.tartaricacid.touhoulittlemaid.util.CenterOffsetBlockPosSet;
import oshi.util.tuples.Pair;
import studio.fantasyit.maid_useful_task.util.MaidUtils;
import studio.fantasyit.maid_useful_task.util.PosUtils;

import java.util.function.Function;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public interface IMaidBlockUpTask {
    default boolean isFindingBlock(EntityMaid maid, class_2338 target, class_2338 standPos) {
        if (target.method_10262(standPos) > touchLimit() * touchLimit())
            return false;
        IMaidTask task = maid.getTask();
        if (task instanceof IMaidBlockDestroyTask destroyTask) {
            return destroyTask.shouldDestroyBlock(maid, target);
        }
        return false;
    }

    default boolean stillValid(EntityMaid maid, class_2338 startPos) {
        for (int dx = 0; dx < touchLimit(); dx = dx <= 0 ? 1 - dx : -dx) {
            for (int dz = 0; dz < touchLimit(); dz = dz <= 0 ? 1 - dz : -dz) {
                for (int dy = 0; dy < verticalDistance(); dy++) {
                    class_2338 targetPos = startPos.method_10069(dx, dy, dz);
                    if (isFindingBlock(maid, targetPos, startPos)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    default Pair<class_2338, class_2338> findTargetPosBlockUp(EntityMaid maid, class_2338 center, int maxUp) {
        class_3218 level = (class_3218) maid.method_37908();
        int maxHeight = verticalOffset() + verticalDistance();
        boolean hasRestriction = maid.method_18410();
        class_2338 restrictCenter = maid.method_18412();
        float restrictRadius = maid.method_18413();
        int scanRange = scanRange(maid);
        Function<class_2338, Boolean> withinRestriction = (class_2338 pos) -> {
            if (hasRestriction) {
                return restrictCenter.method_10262(pos) < (double) (restrictRadius * restrictRadius);
            } else {
                return true;
            }
        };
        CenterOffsetBlockPosSet notAvailable = new CenterOffsetBlockPosSet(scanRange, scanRange + maxHeight / 2 + 1, scanRange, center.method_10263(), center.method_10264() + maxHeight / 2, center.method_10260());
        MaidPathFindingBFS pathFindingBFS = new MaidPathFindingBFS(maid.method_5942().method_6342(), level, maid, 7, scanRange + 2);
        for (int dx = 0; dx < scanRange; dx = dx <= 0 ? 1 - dx : -dx) {
            for (int dz = 0; dz < scanRange; dz = dz <= 0 ? 1 - dz : -dz) {
                //计算地面的位置
                class_2338.class_2339 ground = center.method_10069(dx, 0, dz).method_25503();
                while (level.method_8320(ground).method_45474()) ground.method_10100(0, -1, 0);
                while (!level.method_8320(ground).method_45474()) ground.method_10100(0, 1, 0);
                if (notAvailable.isVis(ground)) continue;
                //地面基本判断
                if (!PosUtils.isSafePos(level, ground)) continue;
                if (!PosUtils.isFourSideAir(level, ground.method_10062())) continue;
                if (!pathFindingBFS.canPathReach(ground)) continue;
                boolean valid = true;
                for (int dy = 0; dy < verticalOffset(); dy++) {
                    class_2338 targetPos = ground.method_10086(dy);
                    if (!level.method_8320(targetPos).method_45474()) {
                        valid = false;
                        break;
                    }
                }
                for (int dy = verticalOffset(); dy < verticalOffset() + 2; dy++) {
                    class_2338 targetPos = ground.method_10086(dy);
                    if (!level.method_8320(targetPos).method_26215()) {
                        valid = false;
                        break;
                    }
                }
                if (!valid) {
                    notAvailable.markVis(ground.method_10062());
                    continue;
                }
                //竖直方向触及
                for (int sdx = 0; sdx < 2; sdx = sdx <= 0 ? 1 - sdx : -sdx)
                    for (int sdz = 0; sdz < 2; sdz = sdz <= 0 ? 1 - sdz : -sdz) {
                        int touchLimit = touchLimit() + 1;
                        boolean continuous = true;
                        class_2338 standPos = ground.method_10086(verticalOffset()).method_10069(sdx, 0, sdz);
                        if (standPos.method_10264() - ground.method_10264() > maxUp)
                            continue;
                        for (int dy = verticalOffset(); dy < verticalDistance() + verticalOffset(); dy++) {
                            class_2338 targetPos = ground.method_34592(sdx, dy, sdz);
                            if (targetPos.method_10262(standPos) > touchLimit * touchLimit) break;
                            if (hasRestriction && !withinRestriction.apply(standPos)) break;
                            if (isFindingBlock(maid, targetPos, standPos)) {
                                return new Pair<>(ground.method_10062(), standPos);
                            }
                            //头顶一格是不是空气，不是：不连续空间（不能继续垫了，那么需要计算触及范围
                            if (continuous) {
                                if (!level.method_8320(standPos.method_10084().method_10084()).method_26215()) {
                                    continuous = false;
                                } else if (hasRestriction && !withinRestriction.apply((standPos.method_10084().method_10084()))) {
                                    continuous = false;
                                }
                            }

                            if (!continuous) {
                                touchLimit--;
                            } else {
                                standPos = standPos.method_10084();
                                if (standPos.method_10264() - ground.method_10264() > maxUp)
                                    break;
                            }
                            if (touchLimit <= 0)
                                break;
                        }
                    }
            }
        }
        return null;
    }

    default int countMaxUsableBlockItems(EntityMaid maid) {
        CombinedInvWrapper inv = maid.getAvailableInv(true);
        int count = 0;
        for (int i = 0; i < inv.getSlots(); i++) {
            class_1799 stack = inv.getStackInSlot(i);
            if (isValidItemStack(maid, stack)) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    default boolean swapValidItemToHand(EntityMaid maid) {
        CombinedInvWrapper inv = maid.getAvailableInv(true);
        for (int i = 0; i < inv.getSlots(); i++) {
            class_1799 stack = inv.getStackInSlot(i);
            if (isValidItemStack(maid, stack)) {
                inv.setStackInSlot(i, maid.method_6047());
                maid.method_6122(class_1268.field_5808, stack);
                return true;
            }
        }
        return false;
    }

    default boolean swapValidToolToHand(EntityMaid maid) {
        CombinedInvWrapper inv = maid.getAvailableInv(true);
        for (int i = 0; i < inv.getSlots(); i++) {
            class_1799 stack = inv.getStackInSlot(i);
            if (isDestroyTool(maid, stack)) {
                inv.setStackInSlot(i, maid.method_6047());
                maid.method_6122(class_1268.field_5808, stack);
                return true;
            }
        }
        return false;
    }

    boolean isValidItemStack(EntityMaid maid, class_1799 stack);

    boolean isDestroyTool(EntityMaid maid, class_1799 stack);

    default int verticalOffset() {
        return 2;
    }

    default int verticalDistance() {
        return 15;
    }

    default int scanRange(EntityMaid maid) {
        return maid.method_18410() ? (int) maid.method_18413() : 15;
    }

    default int touchLimit() {
        return 7;
    }

    default boolean tryPlaceBlockUp(EntityMaid maid, class_2338 targetPos) {
        return MaidUtils.placeBlock(maid, targetPos);
    }

    default boolean tryDestroyBlockUp(EntityMaid maid, class_2338 targetPos) {
        return MaidUtils.destroyBlock(maid, targetPos);
    }
}
