package studio.fantasyit.maid_useful_task.network;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_1297;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import studio.fantasyit.maid_useful_task.Config;
import studio.fantasyit.maid_useful_task.MaidUsefulTask;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;
import studio.fantasyit.maid_useful_task.vehicle.MaidVehicleControlType;

public class MaidAllowHandleVehicle {
    public static final class_2960 ID = new class_2960(MaidUsefulTask.MODID, "allow_handle_vehicle");

    public static class_2540 toBytes(int maidId) {
        class_2540 buffer = PacketByteBufs.create();
        buffer.writeInt(maidId);
        return buffer;
    }

    public static void handle(MinecraftServer server, class_3222 player, class_3244 handler, class_2540 buf, PacketSender responseSender) {
        server.execute(() -> {
            int maidId = buf.readInt();
            class_1297 entity = player.method_37908().method_8469(maidId);
            if (entity instanceof EntityMaid maid) {
                MaidVehicleControlType[] values = MaidVehicleControlType.values();
                MaidVehicleControlType allowMode = values[(MemoryUtil.getAllowHandleVehicle(maid).ordinal() + 1) % values.length];
                while ((allowMode == MaidVehicleControlType.FULL && !Config.enableVehicleControlFull)
                        || (allowMode == MaidVehicleControlType.ROT_ONLY && !Config.enableVehicleControlRotate)) {
                    allowMode = values[(allowMode.ordinal() + 1) % values.length];
                }
                MemoryUtil.setAllowHandleVehicle(maid, allowMode);
                class_2561 component = switch (allowMode) {
                    case NONE -> class_2561.method_43471("maid_useful_task.allow_handle_vehicle.none");
                    case ROT_ONLY -> class_2561.method_43471("maid_useful_task.allow_handle_vehicle.rot_only");
                    case FULL -> class_2561.method_43471("maid_useful_task.allow_handle_vehicle.full");
                };
                player.method_43496(component);
            }
        });
    }
}
