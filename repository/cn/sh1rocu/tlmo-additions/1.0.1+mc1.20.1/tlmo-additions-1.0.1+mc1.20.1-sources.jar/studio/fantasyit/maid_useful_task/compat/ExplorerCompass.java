package studio.fantasyit.maid_useful_task.compat;

import com.chaosthedude.explorerscompass.ExplorersCompass;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_1799;
import net.minecraft.class_2338;

public class ExplorerCompass {
    public static class_2338 getCompassTarget(EntityMaid maid, class_1799 itemStack) {
        if (itemStack.method_31574(ExplorersCompass.EXPLORERS_COMPASS_ITEM)) {
            return new class_2338(
                    ExplorersCompass.EXPLORERS_COMPASS_ITEM.getFoundStructureX(itemStack),
                    maid.method_37908().method_8615(),
                    ExplorersCompass.EXPLORERS_COMPASS_ITEM.getFoundStructureZ(itemStack)
            );
        }
        return null;
    }

}
