package studio.fantasyit.maid_useful_task.behavior.common;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.init.InitEntities;
import studio.fantasyit.maid_useful_task.memory.CurrentWork;
import studio.fantasyit.maid_useful_task.registry.MemoryModuleRegistry;
import studio.fantasyit.maid_useful_task.task.IMaidBlockPlaceTask;
import studio.fantasyit.maid_useful_task.util.Conditions;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;

import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_4097;
import net.minecraft.class_4141;

public class PlaceBlockBehavior extends class_4097<EntityMaid> {
    private class_2338 target;

    public PlaceBlockBehavior() {
        super(Map.of(MemoryModuleRegistry.PLACE_TARGET, class_4141.field_18456,
                InitEntities.TARGET_POS, class_4141.field_18456
        ));
    }

    @Override
    protected boolean checkExtraStartConditions(class_3218 p_22538_, EntityMaid maid) {
        MemoryUtil.setCurrent(maid, CurrentWork.PLACE);
        return Conditions.hasReachedValidTargetOrReset(maid);
    }

    @Override
    protected boolean canStillUse(class_3218 p_22545_, EntityMaid p_22546_, long p_22547_) {
        return target != null;
    }

    @Override
    protected void start(class_3218 p_22540_, EntityMaid maid, long p_22542_) {
        super.method_18920(p_22540_, maid, p_22542_);
        target = MemoryUtil.getPlaceTarget(maid);
        if (target == null)
            return;
        MemoryUtil.setLookAt(maid, target);
        maid.method_5942().method_6340();
    }

    @Override
    protected void tick(class_3218 p_22551_, EntityMaid maid, long p_22553_) {
        if (!Conditions.stopAndCheckStopped(maid)) return;
        IMaidBlockPlaceTask task = (IMaidBlockPlaceTask) maid.getTask();
        if (task.shouldPlacePos(maid, maid.method_6047(), target)) {
            maid.method_6104(class_1268.field_5808);
            task.tryPlaceBlock(maid, target);
        }
        target = null;
    }

    @Override
    protected void stop(class_3218 p_22548_, EntityMaid p_22549_, long p_22550_) {
        super.method_18926(p_22548_, p_22549_, p_22550_);
        MemoryUtil.clearPlaceTarget(p_22549_);
        MemoryUtil.clearTarget(p_22549_);
        MemoryUtil.setCurrent(p_22549_, CurrentWork.IDLE);
    }
}
