package studio.fantasyit.maid_useful_task.behavior.common;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.init.InitEntities;
import org.jetbrains.annotations.NotNull;
import studio.fantasyit.maid_useful_task.memory.BlockTargetMemory;
import studio.fantasyit.maid_useful_task.memory.CurrentWork;
import studio.fantasyit.maid_useful_task.registry.MemoryModuleRegistry;
import studio.fantasyit.maid_useful_task.task.IMaidBlockDestroyTask;
import studio.fantasyit.maid_useful_task.util.Conditions;
import studio.fantasyit.maid_useful_task.util.MaidUtils;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;
import studio.fantasyit.maid_useful_task.util.WrappedMaidFakePlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4097;
import net.minecraft.class_4141;

public class DestoryBlockBehavior extends class_4097<EntityMaid> {
    private IMaidBlockDestroyTask task;

    public DestoryBlockBehavior() {
        super(Map.of(
                InitEntities.TARGET_POS, class_4141.field_18456,
                MemoryModuleRegistry.DESTROY_TARGET, class_4141.field_18456
        ));
    }

    @Override
    protected boolean checkExtraStartConditions(@NotNull class_3218 worldIn, @NotNull EntityMaid maid) {
        if (!Conditions.isCurrent(maid, CurrentWork.DESTROY) && !Conditions.isCurrent(maid, CurrentWork.BLOCKUP_DESTROY))
            return false;
        return Conditions.hasReachedValidTargetOrReset(maid, 1);
    }


    List<class_2338> blockPosSet = null;
    int index = 0;
    float destroyProgress = 0f;
    class_2338 targetPos;
    class_2680 targetBlockState;
    WrappedMaidFakePlayer fakePlayer;

    @Override
    protected void start(class_3218 p_22540_, @NotNull EntityMaid maid, long p_22542_) {
        super.method_18920(p_22540_, maid, p_22542_);
        BlockTargetMemory blockTargetMemory = MemoryUtil.getDestroyTargetMemory(maid);
        if (blockTargetMemory != null) {
            blockPosSet = new ArrayList<>(blockTargetMemory.getBlockPosSet());
            blockPosSet.sort((o1, o2) -> (int) (o1.method_10262(maid.method_24515().method_10084()) - o2.method_10262(maid.method_24515().method_10084())));
        }
        index = 0;
        task = (IMaidBlockDestroyTask) maid.getTask();
        fakePlayer = WrappedMaidFakePlayer.get(maid);
        targetPos = null;
        targetBlockState = null;
        maid.method_5942().method_6340();
    }

    @Override
    protected boolean canStillUse(class_3218 p_22545_, EntityMaid p_22546_, long p_22547_) {
        if (MemoryUtil.getCurrent(p_22546_) != CurrentWork.DESTROY && MemoryUtil.getCurrent(p_22546_) != CurrentWork.BLOCKUP_DESTROY)
            return false;
        return (blockPosSet != null && index < blockPosSet.size()) || targetPos != null;
    }

    @Override
    protected void tick(@NotNull class_3218 level, @NotNull EntityMaid maid, long p_22553_) {
        if (!Conditions.stopAndCheckStopped(maid)) return;
        if (targetPos != null) {
            tickDestroyProgress(maid);
            return;
        }
        while (index < blockPosSet.size()) {
            targetPos = blockPosSet.get(index++);
            targetBlockState = level.method_8320(targetPos);
            if (!targetBlockState.method_26215()) {
                task.tryTakeOutToolForTarget(maid, targetPos);
                if (task.canDestroyBlock(maid, targetPos)) {
                    destroyProgress = 0f;
                    return;
                }
            }
            targetPos = null;
            targetBlockState = null;
        }
    }

    private void tickDestroyProgress(EntityMaid maid) {
        float speed = MaidUtils.getDestroyProgressDelta(maid, targetPos);
        MemoryUtil.setLookAt(maid, targetPos);
        if (speed != 0.0f && task.availableToGetDrop(maid, fakePlayer, targetPos, targetBlockState)) {
            maid.method_6104(class_1268.field_5808);
            destroyProgress += speed;
            if (destroyProgress >= 1f) {
                task.tryDestroyBlock(maid, targetPos);
                destroyProgress = 0f;
                targetPos = null;
                targetBlockState = null;
            }
        } else {
            targetPos = null;
            targetBlockState = null;
        }
    }

    @Override
    protected void stop(class_3218 p_22548_, EntityMaid p_22549_, long p_22550_) {
        super.method_18926(p_22548_, p_22549_, p_22550_);
        MemoryUtil.clearDestroyTargetMemory(p_22549_);
        MemoryUtil.clearTarget(p_22549_);
        MemoryUtil.setCurrent(p_22549_, CurrentWork.IDLE);
    }

    @Override
    protected boolean method_18915(long p_22537_) {
        return false;
    }
}
