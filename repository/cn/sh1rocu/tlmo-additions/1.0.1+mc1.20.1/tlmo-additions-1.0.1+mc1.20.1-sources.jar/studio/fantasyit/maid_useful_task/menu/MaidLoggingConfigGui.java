package studio.fantasyit.maid_useful_task.menu;

import com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.task.MaidTaskConfigGui;
import com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button.MaidConfigButton;
import com.github.tartaricacid.touhoulittlemaid.inventory.container.task.TaskConfigContainer;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import studio.fantasyit.maid_useful_task.Config;
import studio.fantasyit.maid_useful_task.data.MaidLoggingConfig;
import studio.fantasyit.maid_useful_task.network.MaidConfigurePacket;
import studio.fantasyit.maid_useful_task.registry.GuiRegistry;
import studio.fantasyit.maid_useful_task.util.TranslateUtil;

public class MaidLoggingConfigGui extends MaidTaskConfigGui<MaidLoggingConfigGui.Container> {
    private MaidLoggingConfig.Data currentData;

    public MaidLoggingConfigGui(Container screenContainer, class_1661 inv, class_2561 titleIn) {
        super(screenContainer, inv, titleIn);
    }

    public static class Container extends TaskConfigContainer {
        public Container(int id, class_1661 inventory, int entityId) {
            super(GuiRegistry.MAID_LOGGING_CONFIG_GUI, id, inventory, entityId);
        }
    }

    @Override
    protected void initAdditionData() {
        this.currentData = this.maid.getOrCreateData(MaidLoggingConfig.KEY, MaidLoggingConfig.Data.getDefault());
    }

    @Override
    protected void initAdditionWidgets() {
        super.initAdditionWidgets();

        int startLeft = field_2776 + 87;
        int startTop = field_2800 + 36;
        this.method_37063(new MaidConfigButton(startLeft, startTop,
                class_2561.method_43471("gui.maid_useful_task.logging.plant"),
                TranslateUtil.getBooleanTranslate(this.currentData.plant()),
                button -> {
                    this.currentData.plant(false);
                    button.setValue(TranslateUtil.getBooleanTranslate(false));
                    MaidConfigurePacket.send(this.maid, MaidLoggingConfig.LOCATION, "plant", "false");
                },
                button -> {
                    this.currentData.plant(true);
                    button.setValue(TranslateUtil.getBooleanTranslate(true));
                    MaidConfigurePacket.send(this.maid, MaidLoggingConfig.LOCATION, "plant", "true");
                }
        ));
        if (!Config.disableLoggingBlockUp) {
            startTop += 13;
            this.method_37063(new MaidConfigButton(startLeft, startTop,
                    class_2561.method_43471("gui.maid_useful_task.logging.block_up"),
                    TranslateUtil.getBooleanTranslate(this.currentData.blockUp()),
                    button -> {
                        this.currentData.blockUp(false);
                        button.setValue(TranslateUtil.getBooleanTranslate(false));
                        MaidConfigurePacket.send(this.maid, MaidLoggingConfig.LOCATION, "blockUp", "false");
                    },
                    button -> {
                        this.currentData.blockUp(true);
                        button.setValue(TranslateUtil.getBooleanTranslate(true));
                        MaidConfigurePacket.send(this.maid, MaidLoggingConfig.LOCATION, "blockUp", "true");
                    }
            ));
        }
        startTop += 13;
        this.method_37063(new MaidConfigButton(startLeft, startTop,
                class_2561.method_43471("gui.maid_useful_task.logging.skip_non_nature"),
                TranslateUtil.getBooleanTranslate(this.currentData.skipNonNature()),
                button -> {
                    this.currentData.skipNonNature(false);
                    button.setValue(TranslateUtil.getBooleanTranslate(false));
                    MaidConfigurePacket.send(this.maid, MaidLoggingConfig.LOCATION, "skipNonNature", "false");
                },
                button -> {
                    this.currentData.skipNonNature(true);
                    button.setValue(TranslateUtil.getBooleanTranslate(true));
                    MaidConfigurePacket.send(this.maid, MaidLoggingConfig.LOCATION, "skipNonNature", "true");
                }
        ));
    }
}
