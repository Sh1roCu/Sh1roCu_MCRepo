package studio.fantasyit.maid_useful_task.task;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.NotNull;
import studio.fantasyit.maid_useful_task.behavior.common.DestoryBlockBehavior;
import studio.fantasyit.maid_useful_task.behavior.common.DestoryBlockMoveBehavior;
import studio.fantasyit.maid_useful_task.util.MaidUtils;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_7893;

public interface IMaidBlockPlaceTask {
    boolean shouldPlaceItemStack(EntityMaid maid, class_1799 itemStack);

    boolean shouldPlacePos(EntityMaid maid, class_1799 itemStack, class_2338 pos);

    default boolean tryPlaceBlock(EntityMaid maid, class_2338 pos) {
        return MaidUtils.placeBlock(maid, pos);
    }

    default @NotNull List<Pair<Integer, class_7893<? super EntityMaid>>> createBrainTasks(@NotNull EntityMaid entityMaid) {
        return List.of(
                Pair.of(5, new DestoryBlockBehavior()),
                Pair.of(4, new DestoryBlockMoveBehavior())
        );
    }
}
