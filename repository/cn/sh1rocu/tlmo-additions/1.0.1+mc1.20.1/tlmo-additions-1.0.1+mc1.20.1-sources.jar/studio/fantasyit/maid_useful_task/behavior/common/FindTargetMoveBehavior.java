package studio.fantasyit.maid_useful_task.behavior.common;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.init.InitEntities;
import com.google.common.collect.ImmutableMap;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_4097;
import net.minecraft.class_4140;
import net.minecraft.class_4141;
import studio.fantasyit.maid_useful_task.task.IMaidFindTargetTask;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;

public class FindTargetMoveBehavior extends class_4097<EntityMaid> {

    public FindTargetMoveBehavior() {
        super(ImmutableMap.of(
                class_4140.field_18445, class_4141.field_18457,
                InitEntities.TARGET_POS, class_4141.field_18457
        ));
    }

    @Override
    protected boolean checkExtraStartConditions(class_3218 p_22538_, EntityMaid maid) {
        IMaidFindTargetTask task = (IMaidFindTargetTask) maid.getTask();
        if (task.findTarget(p_22538_, maid) == null) return false;
        if (maid.method_18410()) return false;
        class_1309 owner = maid.method_35057();
        return (owner != null && maid.method_5739(owner) < task.minReScheduleDistance());
    }

    @Override
    protected void start(class_3218 serverlevel, EntityMaid maid, long p_22542_) {
        IMaidFindTargetTask task = (IMaidFindTargetTask) maid.getTask();
        class_1309 owner = maid.method_35057();
        if (owner == null) return;
        class_2338 target = task.findTarget(serverlevel, maid);
        if (target != null) {
            if (maid.method_5707(target.method_46558()) < 9) {
                maid.method_5993().method_6233();
                return;
            }
            class_2338 finalTarget = target;
            class_2338 ownerPos = owner.method_24515();
            class_2338 maidPos = maid.method_24515();
            if (finalTarget.method_10262(ownerPos) > task.maxOutDistance() * task.maxOutDistance()) {
                class_243 dVec = target.method_46558().method_1020(owner.method_19538());
                dVec = dVec.method_1029().method_1021(task.maxOutDistance() - (double) (task.maxOutDistance() - task.minReScheduleDistance()) / 2);
                class_2338 fTarget = maidPos.method_10069((int) dVec.field_1352, (int) dVec.field_1351, (int) dVec.field_1350);

                for (int x = 0; x < 3; x = x <= 0 ? 1 - x : -x) {
                    for (int z = 0; z < 3; z = z <= 0 ? 1 - z : -z) {
                        int y = 0;
                        while (!serverlevel.method_8320(fTarget.method_10069(x, y, z)).method_26215()) y++;
                        while (!serverlevel.method_8320(fTarget.method_10069(x, y, z)).method_26215()) y--;

                        if (fTarget.method_10069(x, y, z).method_10262(ownerPos) < task.maxOutDistance() * task.maxOutDistance()) {
                            finalTarget = fTarget.method_10069(x, y, z);
                        }
                    }
                }
            }
            if (finalTarget.method_10262(maidPos) < task.maxOutDistance() * task.maxOutDistance()) {
                double distanceToOwner = maidPos.method_10262(ownerPos);
                double speed = 0.4;
                if (distanceToOwner < 4 * 4) {
                    speed = 0.5;
                }
                if (distanceToOwner < 3 * 3) {
                    speed = 0.64;
                }
                MemoryUtil.setTarget(maid, finalTarget, (float) speed);
            }
        }
    }
}
