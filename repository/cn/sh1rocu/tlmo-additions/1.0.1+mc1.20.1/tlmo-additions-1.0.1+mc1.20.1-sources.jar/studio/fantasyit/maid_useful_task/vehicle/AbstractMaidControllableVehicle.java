package studio.fantasyit.maid_useful_task.vehicle;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import org.jetbrains.annotations.Nullable;

abstract public class AbstractMaidControllableVehicle {
    abstract public boolean isMaidOnThisVehicle(EntityMaid maid);

    abstract public void maidStopControlVehicle(EntityMaid maid);

    abstract public void maidControlVehicle(EntityMaid maid, MaidVehicleControlType type, class_2338 target);

    public void syncVehicleParameter(EntityMaid maid, class_2487 tag) {
        if (maid.method_5854() instanceof IVirtualControl vehicle) {
            vehicle.maid_useful_tasks$setControlParam(tag);
        }
    }

    public @Nullable class_2487 getSyncVehicleParameter(EntityMaid maid) {
        if (maid.method_5854() instanceof IVirtualControl vehicle) {
            return vehicle.maid_useful_tasks$getControlParam();
        }
        return null;
    }
}
