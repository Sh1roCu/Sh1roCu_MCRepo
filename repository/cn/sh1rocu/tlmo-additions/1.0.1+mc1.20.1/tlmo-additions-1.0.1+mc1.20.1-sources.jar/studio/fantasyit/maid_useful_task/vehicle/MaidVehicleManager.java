package studio.fantasyit.maid_useful_task.vehicle;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.network.NetworkHandler;
import studio.fantasyit.maid_useful_task.network.MaidSyncVehiclePacket;
import studio.fantasyit.maid_useful_task.vehicle.broom.VehicleBroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2487;

public class MaidVehicleManager {
    public static List<AbstractMaidControllableVehicle> controllableVehicles = new ArrayList<>();

    public static void register() {
        controllableVehicles.add(new VehicleBroom());
    }

    public static void addControllableVehicle(AbstractMaidControllableVehicle vehicle) {
        controllableVehicles.add(vehicle);
    }

    public static Optional<AbstractMaidControllableVehicle> getControllableVehicle(EntityMaid maid) {
        for (AbstractMaidControllableVehicle vehicle : controllableVehicles) {
            if (vehicle.isMaidOnThisVehicle(maid)) return Optional.of(vehicle);
        }
        return Optional.empty();
    }

    public static void syncVehicleParameter(EntityMaid maid) {
        getControllableVehicle(maid).ifPresent(vehicle -> {
            class_2487 syncVehicleParameter = vehicle.getSyncVehicleParameter(maid);
            if (syncVehicleParameter != null) {
                NetworkHandler.sendToTrackingEntity(maid, MaidSyncVehiclePacket.ID,
                        MaidSyncVehiclePacket.toBytes(maid.method_5628(), syncVehicleParameter));
            }
        });
    }

    public static void stopControlling(EntityMaid maid) {
        MaidVehicleManager.getControllableVehicle(maid).ifPresent(vehicle -> vehicle.maidStopControlVehicle(maid));
    }
}
