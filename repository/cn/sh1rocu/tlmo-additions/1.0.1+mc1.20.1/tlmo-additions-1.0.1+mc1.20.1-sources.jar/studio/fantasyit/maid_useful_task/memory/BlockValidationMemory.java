package studio.fantasyit.maid_useful_task.memory;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.class_2338;

public class BlockValidationMemory {
    public static final Codec<BlockValidationMemory> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                    Codec.list(class_2338.field_25064).fieldOf("validList").forGetter(BlockValidationMemory::getValidList),
                    Codec.list(class_2338.field_25064).fieldOf("invalidList").forGetter(BlockValidationMemory::getInvalidList)
            ).apply(instance, BlockValidationMemory::new)
    );

    private final Set<class_2338> validSet = new HashSet<>();
    private final Set<class_2338> invalidSet = new HashSet<>();

    public BlockValidationMemory() {
    }

    public BlockValidationMemory(List<class_2338> validList, List<class_2338> invalidList) {
        validSet.addAll(validList);
        invalidSet.addAll(invalidList);
    }

    public List<class_2338> getValidList() {
        return List.copyOf(validSet);
    }

    public List<class_2338> getInvalidList() {
        return List.copyOf(invalidSet);
    }

    public void setValid(class_2338 blockPos) {
        validSet.add(blockPos);
        invalidSet.remove(blockPos);
    }

    public void setInvalid(class_2338 blockPos) {
        invalidSet.add(blockPos);
        validSet.remove(blockPos);
    }

    public void remove(class_2338 blockPos) {
        validSet.remove(blockPos);
        invalidSet.remove(blockPos);
    }

    public boolean isValid(class_2338 blockPos, boolean defaultValue) {
        if (validSet.contains(blockPos)) {
            return true;
        }
        if (invalidSet.contains(blockPos)) {
            return false;
        }
        return defaultValue;
    }

    public boolean hasRecord(class_2338 blockPos) {
        return validSet.contains(blockPos) || invalidSet.contains(blockPos);
    }

    public void clearFaraway(class_2338 blockPos, int range) {
        clearIf(pos -> pos.method_10262(blockPos) > range * range);
    }

    public void clearIf(Predicate<class_2338> o) {
        validSet.removeIf(o);
        invalidSet.removeIf(o);
    }
}
