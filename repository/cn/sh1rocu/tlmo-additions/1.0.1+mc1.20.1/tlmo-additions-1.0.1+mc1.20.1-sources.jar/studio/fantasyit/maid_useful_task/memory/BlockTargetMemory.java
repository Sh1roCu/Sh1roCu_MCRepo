package studio.fantasyit.maid_useful_task.memory;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.class_2338;

public class BlockTargetMemory {
    public static final Codec<BlockTargetMemory> CODEC = RecordCodecBuilder.create(instance ->
            instance.group(
                    class_2338
                            .field_25064
                            .listOf()
                            .fieldOf("blockPosSet")
                            .forGetter(BlockTargetMemory::getBlockPosSet)
            ).apply(instance, BlockTargetMemory::new)
    );

    List<class_2338> blockPosSet;

    public BlockTargetMemory(List<class_2338> blockPosSet) {
        this.blockPosSet = blockPosSet;
    }

    public List<class_2338> getBlockPosSet() {
        return blockPosSet;
    }

    public void setBlockPosSet(List<class_2338> blockPosSet) {
        this.blockPosSet = blockPosSet;
    }
}