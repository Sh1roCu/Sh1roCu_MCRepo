package studio.fantasyit.maid_useful_task.compat;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1799;
import net.minecraft.class_2338;

public class CompatEntry {
    public static class_2338 getLocateTarget(EntityMaid maid, class_1799 itemStack) {
        class_2338 tmp = null;
        if (tmp == null && FabricLoader.getInstance().isModLoaded("naturescompass")) {
            tmp = NatureCompass.getCompassTarget(maid, itemStack);
        }
        if (tmp == null && FabricLoader.getInstance().isModLoaded("explorerscompass")) {
            tmp = ExplorerCompass.getCompassTarget(maid, itemStack);
        }

        return tmp;
    }
}
