package studio.fantasyit.maid_useful_task.util;

import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3726;

public class PosUtils {
    public static boolean isFourSideAir(class_1922 level, class_2338 pos) {
        return level.method_8320(pos).method_26215() &&
                level.method_8320(pos.method_10095()).method_26215() &&
                level.method_8320(pos.method_10072()).method_26215() &&
                level.method_8320(pos.method_10078()).method_26215() &&
                level.method_8320(pos.method_10067()).method_26215();
    }

    static protected boolean isEmptyBlockPos(class_1937 level, class_2338 pos) {
        return level.method_8320(pos).method_26215() || level.method_8320(pos).method_26194(
                level,
                pos,
                class_3726.method_16194()
        ).method_1110();
    }

    static public boolean isSafePos(class_1937 level, class_2338 pos) {
        return isEmptyBlockPos(level, pos)
                && isEmptyBlockPos(level, pos.method_10084())
                && !isEmptyBlockPos(level, pos.method_10074());
    }
}
