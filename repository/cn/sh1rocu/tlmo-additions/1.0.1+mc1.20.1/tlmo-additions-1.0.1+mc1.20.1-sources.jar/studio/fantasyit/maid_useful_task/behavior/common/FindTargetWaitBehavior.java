package studio.fantasyit.maid_useful_task.behavior.common;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.init.InitEntities;
import com.google.common.collect.ImmutableMap;
import net.minecraft.class_1309;
import net.minecraft.class_3218;
import net.minecraft.class_4097;
import net.minecraft.class_4141;
import org.jetbrains.annotations.NotNull;
import studio.fantasyit.maid_useful_task.task.IMaidFindTargetTask;
import studio.fantasyit.maid_useful_task.util.Conditions;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;

public class FindTargetWaitBehavior extends class_4097<EntityMaid> {

    public FindTargetWaitBehavior() {
        super(ImmutableMap.of(InitEntities.TARGET_POS, class_4141.field_18456));
    }

    @Override
    protected boolean checkExtraStartConditions(class_3218 serverLevel, EntityMaid maid) {
        IMaidFindTargetTask task = (IMaidFindTargetTask) maid.getTask();
        if (task.findTarget(serverLevel, maid) == null) return true;
        if (maid.method_18410()) return false;
        class_1309 owner = maid.method_35057();
        if (owner != null && maid.method_5739(owner) > task.maxOutDistance()) {
            return true;
        }
        return Conditions.hasReachedValidTargetOrReset(maid, 4);
    }

    @Override
    protected void start(@NotNull class_3218 serverLevel, EntityMaid maid, long p_22542_) {
        IMaidFindTargetTask task = (IMaidFindTargetTask) maid.getTask();
        if (task.findTarget(serverLevel, maid) == null) {
            task.clearCache(maid);
        }
        MemoryUtil.clearTarget(maid);
    }
}
