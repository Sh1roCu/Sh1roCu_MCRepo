package studio.fantasyit.maid_useful_task.util;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.init.InitEntities;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.maid_useful_task.memory.BlockTargetMemory;
import studio.fantasyit.maid_useful_task.memory.BlockUpContext;
import studio.fantasyit.maid_useful_task.memory.BlockValidationMemory;
import studio.fantasyit.maid_useful_task.memory.CurrentWork;
import studio.fantasyit.maid_useful_task.registry.MemoryModuleRegistry;
import studio.fantasyit.maid_useful_task.vehicle.MaidVehicleControlType;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_4095;
import net.minecraft.class_4099;
import net.minecraft.class_4102;
import net.minecraft.class_4115;
import net.minecraft.class_4140;
import net.minecraft.class_4215;

public class MemoryUtil {
    public static @Nullable BlockTargetMemory getDestroyTargetMemory(EntityMaid maid) {
        Optional<BlockTargetMemory> memory = maid.method_18868().method_18904(MemoryModuleRegistry.DESTROY_TARGET);
        return memory.orElse(null);
    }

    public static void setDestroyTargetMemory(EntityMaid maid, List<class_2338> blockPosSet) {
        maid.method_18868().method_18878(MemoryModuleRegistry.DESTROY_TARGET, new BlockTargetMemory(blockPosSet));
    }

    public static void clearDestroyTargetMemory(EntityMaid maid) {
        maid.method_18868().method_18875(MemoryModuleRegistry.DESTROY_TARGET);
    }

    public static void clearTarget(EntityMaid maid) {
        maid.method_18868().method_18875(InitEntities.TARGET_POS);
        maid.method_18868().method_18875(class_4140.field_18445);
    }

    public static @Nullable class_2338 getTargetPos(EntityMaid maid) {
        Optional<class_4115> memory = maid.method_18868().method_18904(InitEntities.TARGET_POS);
        return memory.map(class_4115::method_18989).orElse(null);
    }

    public static @Nullable class_2338 getPlaceTarget(EntityMaid maid) {
        Optional<class_2338> memory = maid.method_18868().method_18904(MemoryModuleRegistry.PLACE_TARGET);
        return memory.orElse(null);
    }

    public static void setPlaceTarget(EntityMaid maid, class_2338 blockPos) {
        maid.method_18868().method_18878(MemoryModuleRegistry.PLACE_TARGET, blockPos);
    }

    public static void clearPlaceTarget(EntityMaid maid) {
        maid.method_18868().method_18875(MemoryModuleRegistry.PLACE_TARGET);
    }

    public static void setLookAt(EntityMaid maid, class_2338 pos) {
        maid.method_18868().method_18878(class_4140.field_18446, new class_4099(pos));
    }

    public static BlockUpContext getBlockUpContext(EntityMaid maid) {
        class_4095<EntityMaid> brain = maid.method_18868();
        if (!brain.method_18896(MemoryModuleRegistry.BLOCK_UP_TARGET)) {
            brain.method_18878(MemoryModuleRegistry.BLOCK_UP_TARGET, new BlockUpContext());
        }
        return brain.method_18904(MemoryModuleRegistry.BLOCK_UP_TARGET).get();
    }

    public static BlockValidationMemory getBlockValidationMemory(EntityMaid maid) {
        class_4095<EntityMaid> brain = maid.method_18868();
        if (!brain.method_18896(MemoryModuleRegistry.BLOCK_VALIDATION)) {
            brain.method_18878(MemoryModuleRegistry.BLOCK_VALIDATION, new BlockValidationMemory());
        }
        return brain.method_18904(MemoryModuleRegistry.BLOCK_VALIDATION).get();
    }

    public static void setTargetEntity(EntityMaid maid, class_1297 target, float speed) {
        maid.method_18868().method_18878(InitEntities.TARGET_POS, new class_4102(target, false));
        class_4215.method_24557(maid, target, speed, 0);
    }

    public static void setTarget(EntityMaid maid, class_2338 targetPos, float speed) {
        maid.method_18868().method_18878(InitEntities.TARGET_POS, new class_4099(targetPos));
        class_4215.method_24561(maid, targetPos, speed, 0);
    }

    public static CurrentWork getCurrent(EntityMaid maid) {
        return maid.method_18868().method_18904(MemoryModuleRegistry.CURRENT_WORK).orElse(CurrentWork.IDLE);
    }

    public static void setCurrent(EntityMaid maid, CurrentWork currentWork) {
        maid.method_18868().method_18878(MemoryModuleRegistry.CURRENT_WORK, currentWork);
    }

    public static void setCommonBlockCache(EntityMaid maid, class_2338 pos) {
        maid.method_18868().method_18878(MemoryModuleRegistry.COMMON_BLOCK_CACHE, pos);
    }

    public static class_2338 getCommonBlockCache(EntityMaid maid) {
        return maid.method_18868().method_18904(MemoryModuleRegistry.COMMON_BLOCK_CACHE).orElse(null);
    }

    public static void setAllowHandleVehicle(EntityMaid maid, MaidVehicleControlType allow) {
        maid.method_18868().method_18878(MemoryModuleRegistry.IS_ALLOW_HANDLE_VEHICLE, allow);
    }

    public static MaidVehicleControlType getAllowHandleVehicle(EntityMaid maid) {
        return maid.method_18868().method_18904(MemoryModuleRegistry.IS_ALLOW_HANDLE_VEHICLE).orElse(MaidVehicleControlType.NONE);
    }

    public static void clearCommonBlockCache(EntityMaid maid) {
        maid.method_18868().method_18875(MemoryModuleRegistry.COMMON_BLOCK_CACHE);
    }

    public static void setLocateItem(EntityMaid maid, class_1799 item) {
        maid.method_18868().method_18878(MemoryModuleRegistry.LOCATE_ITEM, item);
    }

    public static class_1799 getLocateItem(EntityMaid maid) {
        return maid.method_18868().method_18904(MemoryModuleRegistry.LOCATE_ITEM).orElse(class_1799.field_8037);
    }
}
