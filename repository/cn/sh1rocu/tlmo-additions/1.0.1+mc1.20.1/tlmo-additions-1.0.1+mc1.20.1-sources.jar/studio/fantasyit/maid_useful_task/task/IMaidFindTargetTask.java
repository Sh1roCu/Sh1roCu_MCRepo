package studio.fantasyit.maid_useful_task.task;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import org.jetbrains.annotations.Nullable;

public interface IMaidFindTargetTask extends IMaidVehicleControlTask {
    @Nullable class_2338 findTarget(class_3218 level, EntityMaid maid);

    void clearCache(EntityMaid maid);

    default int maxOutDistance() {
        return 10;
    }

    default int minReScheduleDistance() {
        return 3;
    }

    default int moveDistance() {
        return 10;
    }
}
