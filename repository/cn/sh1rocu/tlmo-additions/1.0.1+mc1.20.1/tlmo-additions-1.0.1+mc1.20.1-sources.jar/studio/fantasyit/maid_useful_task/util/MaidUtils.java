package studio.fantasyit.maid_useful_task.util;

import cn.sh1rocu.touhoulittlemaid.util.itemhandler.RangedWrapper;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4770;
import net.minecraft.class_5712;

public class MaidUtils {
    public static void swapToHand(EntityMaid maid, Predicate<class_1799> isSuitable) {
        RangedWrapper availableBackpackInv = maid.getAvailableBackpackInv();
        for (int i = 0; i < availableBackpackInv.getSlots(); i++) {
            class_1799 itemStack = availableBackpackInv.getStackInSlot(i);
            if (isSuitable.test(itemStack)) {
                class_1799 tmp = availableBackpackInv.getStackInSlot(i);
                availableBackpackInv.setStackInSlot(i, maid.method_6047());
                maid.method_6122(class_1268.field_5808, tmp);
                return;
            }
        }
    }

    public static float getDestroyProgressDelta(EntityMaid maid, class_2338 blockPos) {
        WrappedMaidFakePlayer fakePlayer = WrappedMaidFakePlayer.get(maid);
        class_2680 blockState = maid.method_37908().method_8320(blockPos);
        return blockState.method_26165(fakePlayer, maid.method_37908(), blockPos);
    }

    public static class_2338 getMaidRestrictCenter(EntityMaid maid) {
        if (MemoryUtil.getBlockUpContext(maid).hasTarget()) {
            return MemoryUtil.getBlockUpContext(maid).getTargetPos();
        }
        if (maid.method_18410())
            return maid.method_18412();
        return maid.method_24515();
    }

    public static boolean destroyBlock(EntityMaid maid, class_2338 blockPos) {
        WrappedMaidFakePlayer fakePlayer = WrappedMaidFakePlayer.get(maid);
        maid.method_6047().method_7956(1, fakePlayer, (p_186374_) -> {
            p_186374_.method_20236(class_1268.field_5808);
        });
        class_3218 level = (class_3218) maid.method_37908();
        class_2680 blockState = level.method_8320(blockPos);
        if (blockState.method_26215()) {
            return false;
        } else {
            class_3610 fluidState = level.method_8316(blockPos);
            if (!(blockState.method_26204() instanceof class_4770)) {
                level.method_20290(2001, blockPos, class_2248.method_9507(blockState));
            }

            class_2586 blockEntity = blockState.method_31709() ? level.method_8321(blockPos) : null;
            //改用MainHandItem来roll loot
            maid.dropResourcesToMaidInv(blockState, level, blockPos, blockEntity, maid, maid.method_6047());

            boolean setResult = level.method_8652(blockPos, fluidState.method_15759(), 3);
            if (setResult) {
                level.method_43276(class_5712.field_28165, blockPos, class_5712.class_7397.method_43286(maid, blockState));
            }

            return setResult;
        }
    }

    public static boolean placeBlock(EntityMaid maid, class_2338 pos) {
        WrappedMaidFakePlayer fakePlayer = WrappedMaidFakePlayer.get(maid);
        class_3965 result = null;
        class_3959 rayTraceContext = new class_3959(maid.method_30950(0).method_1031(0, maid.method_5751(), 0),
                pos.method_46558(),
                class_3959.class_3960.field_17559,
                class_3959.class_242.field_1348,
                fakePlayer);
        result = maid.method_37908().method_17742(rayTraceContext);
        class_1838 useContext = new class_1838(fakePlayer, class_1268.field_5808, result);
        class_1269 actionresult = fakePlayer.method_6047().method_7981(useContext);
        if (actionresult == class_1269.field_5811) {
            class_1269 interactionResult = fakePlayer.method_6047().method_7981(useContext);
            return interactionResult.method_23665();
        }
        return false;
    }
}
