package studio.fantasyit.maid_useful_task.behavior.common;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import studio.fantasyit.maid_useful_task.memory.BlockUpContext;
import studio.fantasyit.maid_useful_task.memory.CurrentWork;
import studio.fantasyit.maid_useful_task.task.IMaidBlockUpTask;
import studio.fantasyit.maid_useful_task.util.Conditions;
import studio.fantasyit.maid_useful_task.util.MaidUtils;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;
import studio.fantasyit.maid_useful_task.util.WrappedMaidFakePlayer;

import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_4097;
import net.minecraft.class_4140;
import net.minecraft.class_4141;

public class BlockUpDestroyBehavior extends class_4097<EntityMaid> {
    private BlockUpContext context;
    private IMaidBlockUpTask task;

    WrappedMaidFakePlayer fakePlayer;

    public BlockUpDestroyBehavior(Map<class_4140<?>, class_4141> p_22528_) {
        super(p_22528_);
    }

    public BlockUpDestroyBehavior() {
        super(Map.of(), 500);
    }

    @Override
    protected boolean checkExtraStartConditions(class_3218 p_22538_, EntityMaid p_22539_) {
        if (!Conditions.isCurrent(p_22539_, CurrentWork.BLOCKUP_DOWN)) return false;
        if (!MemoryUtil.getBlockUpContext(p_22539_).hasTarget()) return false;
        return MemoryUtil.getBlockUpContext(p_22539_).getStatus() == BlockUpContext.STATUS.DOWN;
    }

    @Override
    protected boolean canStillUse(class_3218 p_22545_, EntityMaid maid, long p_22547_) {
        if (MemoryUtil.getBlockUpContext(maid).getStatus() != BlockUpContext.STATUS.DOWN) return false;
        return MemoryUtil.getBlockUpContext(maid).isOnLine(maid.method_24515()) && !maid.method_24515().equals(context.getStartPos());
    }


    @Override
    protected void start(class_3218 p_22540_, EntityMaid maid, long p_22542_) {
        context = MemoryUtil.getBlockUpContext(maid);
        task = (IMaidBlockUpTask) maid.getTask();
        fakePlayer = WrappedMaidFakePlayer.get(maid);
    }

    float progress = 0;

    @Override
    protected void tick(class_3218 level, EntityMaid maid, long p_22553_) {
        if (!maid.method_24828()) {
            progress = 0;
        } else {
            task.swapValidToolToHand(maid);
            class_2338 targetPos = maid.method_24515().method_10074();
            maid.method_6104(class_1268.field_5808);
            MemoryUtil.setLookAt(maid, targetPos);
            float speed = MaidUtils.getDestroyProgressDelta(maid, targetPos);
            progress += speed;
            if (progress >= 1f) {
                MaidUtils.destroyBlock(maid, targetPos);
                progress = 0;
            }
        }
    }

    @Override
    protected void stop(class_3218 p_22548_, EntityMaid maid, long p_22550_) {
        super.method_18926(p_22548_, maid, p_22550_);
        context.clearStartTarget();
        MemoryUtil.clearTarget(maid);
        MemoryUtil.setCurrent(maid, CurrentWork.IDLE);
    }
}
