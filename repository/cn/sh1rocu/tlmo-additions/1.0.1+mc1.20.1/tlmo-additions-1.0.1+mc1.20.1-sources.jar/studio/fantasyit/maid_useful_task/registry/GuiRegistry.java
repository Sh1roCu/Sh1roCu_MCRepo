package studio.fantasyit.maid_useful_task.registry;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1703;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;
import studio.fantasyit.maid_useful_task.MaidUsefulTask;
import studio.fantasyit.maid_useful_task.menu.MaidLoggingConfigGui;
import studio.fantasyit.maid_useful_task.menu.MaidReviveConfigGui;

public class GuiRegistry {
    public static final class_3917<MaidLoggingConfigGui.Container> MAID_LOGGING_CONFIG_GUI = register("maid_logging_config_gui",
            new ExtendedScreenHandlerType<>((windowId, inv, data) -> new MaidLoggingConfigGui.Container(windowId, inv, data.readInt())));
    public static final class_3917<MaidReviveConfigGui.Container> MAID_REVIVE_CONFIG_GUI = register("maid_revive_config_gui",
            new ExtendedScreenHandlerType<>((windowId, inv, data) -> new MaidReviveConfigGui.Container(windowId, inv, data.readInt())));

    private static <T extends class_1703> class_3917<T> register(String name, class_3917<T> menuType) {
        return class_2378.method_10230(class_7923.field_41187, new class_2960(MaidUsefulTask.MODID, name), menuType);
    }

    public static void init() {

    }
}