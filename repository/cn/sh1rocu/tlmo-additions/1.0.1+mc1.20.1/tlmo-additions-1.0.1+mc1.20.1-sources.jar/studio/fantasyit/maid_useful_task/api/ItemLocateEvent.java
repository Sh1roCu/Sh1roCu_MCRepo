package studio.fantasyit.maid_useful_task.api;

import cn.sh1rocu.touhoulittlemaid.api.event.CancellableEvent;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1799;
import net.minecraft.class_2338;

public class ItemLocateEvent extends CancellableEvent {
    public final class_1799 itemStack;
    public final EntityMaid maid;
    public final class_2338 cache;
    public class_2338 target = null;

    public static Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.onItemLocate(event);
        }
    });

    public interface Callback {
        void onItemLocate(ItemLocateEvent event);
    }

    public ItemLocateEvent(class_1799 itemStack, EntityMaid maid, class_2338 cache) {
        this.itemStack = itemStack;
        this.maid = maid;
        this.cache = cache;
    }

    public class_2338 getTarget() {
        return target;
    }

    public void setTarget(class_2338 target) {
        this.target = target;
    }
}