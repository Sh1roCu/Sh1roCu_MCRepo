package studio.fantasyit.maid_useful_task.util;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mojang.authlib.GameProfile;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2709;
import net.minecraft.class_3218;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class WrappedMaidFakePlayer extends FakePlayer {
    public static class WrappedMaidInventory extends class_1661 {
        private final EntityMaid maid;

        public WrappedMaidInventory(EntityMaid p_35983_, WrappedMaidFakePlayer fakePlayer) {
            super(fakePlayer);
            this.maid = p_35983_;
        }

        @Override
        public @NotNull class_1799 method_7391() {
            return maid.method_6047();
        }

        @Override
        public float method_7370(class_2680 p_36021_) {
            return maid.method_6047().method_7924(p_36021_);
        }
    }

    private static final ConcurrentHashMap<UUID, WrappedMaidFakePlayer> cache = new ConcurrentHashMap<>();
    private final EntityMaid maid;

    public static WrappedMaidFakePlayer get(EntityMaid maid) {
        if (cache.containsKey(maid.method_5667())) {
            WrappedMaidFakePlayer wrappedMaidFakePlayer = cache.get(maid.method_5667());
            if (!wrappedMaidFakePlayer.maid.method_5805()) {
                cache.remove(maid.method_5667());
            } else {
                return wrappedMaidFakePlayer;
            }
        }
        WrappedMaidFakePlayer fakePlayer = new WrappedMaidFakePlayer(maid);
        cache.put(maid.method_5667(), fakePlayer);
        return fakePlayer;

    }

    private WrappedMaidFakePlayer(EntityMaid maid) {
        super((class_3218) maid.method_37908(), new GameProfile(UUID.randomUUID(), maid.method_5477().getString()));
        this.maid = maid;
        this.field_7514 = new WrappedMaidInventory(maid, this);
    }

    @Override
    public boolean method_6016(class_1291 p_21196_) {
        if (maid == null) return false;
        return maid.method_6016(p_21196_);
    }

    @Nullable
    @Override
    public class_1293 method_6111(@Nullable class_1291 p_21164_) {
        if (maid == null) return super.method_6111(p_21164_);
        return maid.method_6111(p_21164_);
    }

    @Override
    public boolean method_6012() {
        if (maid == null) return false;
        return maid.method_6012();
    }

    @Override
    public boolean method_37222(class_1293 p_147208_, @Nullable class_1297 p_147209_) {
        if (maid == null) return super.method_37222(p_147208_, p_147209_);
        return maid.method_37222(p_147208_, p_147209_);
    }

    @Override
    public boolean method_6049(class_1293 p_21197_) {
        if (maid == null) return super.method_6049(p_21197_);
        return maid.method_6049(p_21197_);
    }

    @Override
    public void method_26082(class_1293 p_147216_, @Nullable class_1297 p_147217_) {
        maid.method_26082(p_147216_, p_147217_);
    }

    @Nullable
    @Override
    public class_1293 method_6112(class_1291 p_21125_) {
        if (maid == null) return super.method_6112(p_21125_);
        return maid.method_6112(p_21125_);
    }

    @Override
    public Collection<class_1293> method_6026() {
        if (maid == null) return super.method_6026();
        return maid.method_6026();
    }

    @Override
    public Map<class_1291, class_1293> method_6088() {
        if (maid == null) return super.method_6088();
        return maid.method_6088();
    }

    @Override
    public boolean method_6059(class_1291 p_21024_) {
        if (maid == null) return super.method_6059(p_21024_);
        return maid.method_6059(p_21024_);
    }

    @Override
    public class_1799 method_6047() {
        if (maid == null) return class_1799.field_8037;
        return maid.method_6047();
    }

    @Override
    public class_1799 method_5998(class_1268 p_21121_) {
        if (maid == null) return super.method_5998(p_21121_);
        return maid.method_5998(p_21121_);
    }

    @Override
    public void method_6122(class_1268 p_21009_, class_1799 p_21010_) {
        if (maid == null) return;
        maid.method_6122(p_21009_, p_21010_);
    }

    @Override
    public void method_5673(class_1304 p_36161_, class_1799 p_36162_) {
        if (maid == null) return;
        maid.method_5673(p_36161_, p_36162_);
    }

    @Override
    public class_1799 method_6118(class_1304 p_36257_) {
        if (maid == null) return class_1799.field_8037;
        return maid.method_6118(p_36257_);
    }

    @Override
    public boolean method_5777(class_6862<class_3611> p_204030_) {
        if (maid == null) return false;
        return maid.method_5777(p_204030_);
    }

    @Override
    public boolean method_24828() {
        if (maid == null) return false;
        return maid.method_24828();
    }

    @Override
    public class_1937 method_37908() {
        if (maid == null) return super.method_37908();
        return maid.method_37908();
    }

    @Override
    public class_3218 method_51469() {
        if (maid == null) return super.method_51469();
        return (class_3218) maid.method_37908();
    }

    @Override
    public class_2338 method_24515() {
        if (maid == null) return class_2338.field_10980;
        return maid.method_24515();
    }

    @Override
    public class_243 method_19538() {
        if (maid == null) return class_243.field_1353;
        return maid.method_19538();
    }

    @Override
    public float method_5739(class_1297 p_20271_) {
        if (maid == null) return super.method_5739(p_20271_);
        return maid.method_5739(p_20271_);
    }

    @Override
    public double method_5649(double p_20276_, double p_20277_, double p_20278_) {
        if (maid == null) return super.method_5649(p_20276_, p_20277_, p_20278_);
        return maid.method_5649(p_20276_, p_20277_, p_20278_);
    }

    @Override
    public double method_5707(class_243 p_20239_) {
        if (maid == null) return super.method_5707(p_20239_);
        return maid.method_5707(p_20239_);
    }

    @Override
    public void method_5859(double p_8969_, double p_8970_, double p_8971_) {
        if (maid == null) return;
        maid.method_5859(p_8969_, p_8970_, p_8971_);
    }

    @Override
    public boolean method_48105(class_3218 p_265564_, double p_265424_, double p_265680_, double p_265312_, Set<class_2709> p_265192_, float p_265059_, float p_265266_) {
        if (maid == null) return false;
        return maid.method_48105(p_265564_, p_265424_, p_265680_, p_265312_, p_265192_, p_265059_, p_265266_);
    }

    @Override
    public void method_45166(double p_251611_, double p_248861_, double p_252266_) {
        if (maid == null) return;
        maid.method_45166(p_251611_, p_248861_, p_252266_);
    }

    @Override
    public void method_24203(double p_9171_, double p_9172_, double p_9173_) {
        if (maid == null) return;
        maid.method_24203(p_9171_, p_9172_, p_9173_);
    }

    @Override
    public class_1923 method_31476() {
        if (maid == null) return new class_1923(0, 0);
        return maid.method_31476();
    }
}
