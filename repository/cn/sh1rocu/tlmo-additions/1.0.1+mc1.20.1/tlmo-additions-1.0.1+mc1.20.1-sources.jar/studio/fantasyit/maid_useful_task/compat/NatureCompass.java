package studio.fantasyit.maid_useful_task.compat;

import com.chaosthedude.naturescompass.NaturesCompass;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_1799;
import net.minecraft.class_2338;

public class NatureCompass {
    public static class_2338 getCompassTarget(EntityMaid maid, class_1799 itemStack) {
        if (itemStack.method_31574(NaturesCompass.NATURES_COMPASS_ITEM)) {
            return new class_2338(
                    NaturesCompass.NATURES_COMPASS_ITEM.getFoundBiomeX(itemStack),
                    maid.method_37908().method_8615(),
                    NaturesCompass.NATURES_COMPASS_ITEM.getFoundBiomeZ(itemStack)
            );
        }
        return null;
    }

}
