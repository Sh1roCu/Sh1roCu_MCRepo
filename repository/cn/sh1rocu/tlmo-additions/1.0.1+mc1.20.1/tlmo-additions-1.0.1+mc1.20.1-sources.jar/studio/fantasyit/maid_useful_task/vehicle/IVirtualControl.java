package studio.fantasyit.maid_useful_task.vehicle;

import net.minecraft.class_2487;

public interface IVirtualControl {
    void maid_useful_tasks$setControlParam(float xRot, float yRot, float speed, MaidVehicleControlType type);

    void maid_useful_tasks$stopControl();

    class_2487 maid_useful_tasks$getControlParam();

    void maid_useful_tasks$setControlParam(class_2487 target);
}
