package studio.fantasyit.maid_useful_task.util;

import net.minecraft.class_243;
import net.minecraft.class_3532;

public class RotUtil {
    public static float getXRot(class_243 from, class_243 to) {
        double d0 = to.method_10216() - from.method_10216();
        double d1 = to.method_10214() - from.method_10214();
        double d2 = to.method_10215() - from.method_10215();
        double d3 = Math.sqrt(d0 * d0 + d2 * d2);
        return class_3532.method_15393((float) (-(class_3532.method_15349(d1, d3) * (double) (180F / (float) Math.PI))));
    }

    public static float getYRot(class_243 from, class_243 to) {
        double d0 = to.method_10216() - from.method_10216();
        double d1 = to.method_10214() - from.method_10214();
        double d2 = to.method_10215() - from.method_10215();
        double d3 = Math.sqrt(d0 * d0 + d2 * d2);
        return class_3532.method_15393((float) (-(class_3532.method_15349(d0, d2) * (double) (180F / (float) Math.PI))));
    }
}
