package studio.fantasyit.maid_useful_task.util;

import net.minecraft.class_2561;

public class TranslateUtil {
    public static class_2561 getBooleanTranslate(boolean b) {
        return (b ? class_2561.method_43471("gui.maid_useful_task.yes") : class_2561.method_43471("gui.maid_useful_task.no"));
    }
}
