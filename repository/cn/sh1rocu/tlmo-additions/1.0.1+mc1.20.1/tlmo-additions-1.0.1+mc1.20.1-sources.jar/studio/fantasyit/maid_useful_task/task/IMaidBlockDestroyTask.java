package studio.fantasyit.maid_useful_task.task;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.maid_useful_task.behavior.common.DestoryBlockBehavior;
import studio.fantasyit.maid_useful_task.behavior.common.DestoryBlockMoveBehavior;
import studio.fantasyit.maid_useful_task.util.MaidUtils;
import studio.fantasyit.maid_useful_task.util.WrappedMaidFakePlayer;

import java.util.*;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_7893;

public interface IMaidBlockDestroyTask {
    default @Nullable List<class_2338> toDestroyFromStanding(EntityMaid maid, class_2338 targetPos, class_2338 standPos) {
        List<class_2338> list = new ArrayList<>();
        class_243 eyePos = standPos.method_46558().method_1031(0, maid.method_5751() - 0.5, 0);
        Boolean available = class_1922.method_17744(eyePos, targetPos.method_46558(), maid.method_37908(), (level, pos) -> {
            if (pos.method_10262(standPos) > reachDistance() * reachDistance()) {
                return false;
            }
            class_2680 state = level.method_8320(pos);
            if (state.method_26215()) {
                return null;
            }
            if (mayDestroy(maid, pos)) {
                list.add(pos.method_10062());
                return null;
            } else return false;
        }, (a) -> true);
        if (available) {
            return list;
        }
        return null;
    }

    /**
     * 获取尝试破坏的方块列表。不包含起点列表
     *
     * @param startPos 开始位置
     * @param maid     执行操作的女仆
     * @return 相连的所有方块
     */
    default List<class_2338> getTryDestroyBlockListBesidesStart(class_2338 startPos, class_2338 standPos, EntityMaid maid) {
        Set<class_2338> marked = new HashSet<>();
        Queue<class_2338> queue = new LinkedList<>();
        List<class_2338> result = new ArrayList<>();
        final int[] dv = {0, 1, -1};
        final int maxDXZ = 2;
        queue.add(startPos);
        marked.add(startPos);
        // C(9), O(N)
        while (!queue.isEmpty()) {
            class_2338 pos = queue.poll();
            for (int dx : dv) {
                for (int dy : dv) {
                    for (int dz : dv) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        class_2338 target = pos.method_10069(dx, dy, dz);
//                        if (Math.abs(target.getX() - standPos.getX()) > maxDXZ || Math.abs(target.getZ() - standPos.getZ()) > maxDXZ)
//                            continue;
                        //上代码不明所以，删除待查
                        if (target.method_10262(standPos) > reachDistance() * reachDistance()) continue;
                        if (marked.contains(target)) continue;
                        if (!shouldDestroyBlock(maid, target)) continue;
                        List<class_2338> targetList = toDestroyFromStanding(maid, target, standPos);
                        if (targetList == null) continue;
                        marked.add(target);
                        result.addAll(targetList);
                        queue.add(target);
                    }
                }
            }
        }
        return result;
    }

    /**
     * 女仆是否想要破坏这个方块，需要判断工具符合等，将用于寻路判断
     *
     * @param maid 女仆
     * @param pos  目标位置
     * @return 是否想要破坏
     */
    boolean shouldDestroyBlock(EntityMaid maid, class_2338 pos);

    /**
     * 女仆是否可以破坏这个方块，光线投射确定女仆的挖掘地点
     *
     * @param maid
     * @param pos
     * @return
     */
    boolean mayDestroy(EntityMaid maid, class_2338 pos);

    /**
     * 女仆是否可以破坏这个方块，用于进行破坏前检查
     *
     * @param maid 女仆
     * @param pos  位置
     * @return 是否可以破坏
     */
    default boolean canDestroyBlock(EntityMaid maid, class_2338 pos) {
        //女仆可能少走一格，所以判断时给予补偿
        return !(maid.method_5707(pos.method_46558()) > Math.pow(reachDistance() + 1, 2));
    }

    /**
     * 尝试破坏方块
     *
     * @param maid     女仆
     * @param blockPos 位置
     * @return
     */
    default boolean tryDestroyBlock(EntityMaid maid, class_2338 blockPos) {
        return MaidUtils.destroyBlock(maid, blockPos);
    }

    /**
     * 尝试拿取工具。如果没有工具什么都不需要操作，后续交给canDestroy和shouldDestroy判断
     *
     * @param maid
     */
    default void tryTakeOutTool(EntityMaid maid) {
    }

    default void tryTakeOutToolForTarget(EntityMaid maid, class_2338 pos) {
        tryTakeOutTool(maid);
    }

    default boolean availableToGetDrop(EntityMaid maid, WrappedMaidFakePlayer fakePlayer, class_2338 pos, class_2680 targetBlockState) {
        return fakePlayer.method_6047().method_7951(targetBlockState);
    }

    default int reachDistance() {
        return 7;
    }

    default @NotNull List<Pair<Integer, class_7893<? super EntityMaid>>> createBrainTasks(@NotNull EntityMaid entityMaid) {
        return List.of(
                Pair.of(5, new DestoryBlockBehavior()),
                Pair.of(4, new DestoryBlockMoveBehavior())
        );
    }
}