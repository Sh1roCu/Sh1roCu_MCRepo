package studio.fantasyit.maid_useful_task.util;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.init.InitEntities;
import studio.fantasyit.maid_useful_task.memory.CurrentWork;

import java.util.Optional;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4095;
import net.minecraft.class_4140;
import net.minecraft.class_4142;

public class Conditions {
    public static boolean hasReachedValidTargetOrReset(EntityMaid maid) {
        return hasReachedValidTargetOrReset(maid, 2.5f);
    }

    public static boolean hasReachedValidTargetOrReset(EntityMaid maid, float closeEnough) {
        class_4095<EntityMaid> brain = maid.method_18868();
        return brain.method_18904(InitEntities.TARGET_POS).map(targetPos -> {
            class_243 targetV3d = targetPos.method_18991();
            if (maid.method_5707(targetV3d) > Math.pow(closeEnough, 2)) {
                Optional<class_4142> walkTarget = brain.method_18904(class_4140.field_18445);
                if (walkTarget.isEmpty() || !walkTarget.get().method_19094().method_18991().equals(targetV3d)) {
                    brain.method_18875(InitEntities.TARGET_POS);
                    MemoryUtil.setCurrent(maid, CurrentWork.IDLE);
                }
                return false;
            }
            return true;
        }).orElse(false);
    }

    public static boolean stopAndCheckStopped(EntityMaid maid) {
        if (!maid.method_5942().method_6357()) {
            maid.method_5942().method_6340();
            return false;
        }
        return maid.method_18798().method_1033() < 0.2;
    }

    public static boolean isGlobalValidTarget(EntityMaid maid, class_2338 pos, class_2338 targetPos) {
        if (MemoryUtil.getBlockUpContext(maid).hasTarget()) {
            return pos.equals(maid.method_24515());
        }
        return true;
    }

    public static boolean isCurrent(EntityMaid maid, CurrentWork currentWork) {
        return MemoryUtil.getCurrent(maid) == currentWork;
    }
}
