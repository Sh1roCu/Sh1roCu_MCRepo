package studio.fantasyit.maid_useful_task.behavior.common;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import studio.fantasyit.maid_useful_task.memory.BlockUpContext;
import studio.fantasyit.maid_useful_task.memory.CurrentWork;
import studio.fantasyit.maid_useful_task.task.IMaidBlockUpTask;
import studio.fantasyit.maid_useful_task.util.Conditions;
import studio.fantasyit.maid_useful_task.util.MaidUtils;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;

import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_4097;
import net.minecraft.class_4140;
import net.minecraft.class_4141;

public class BlockUpPlaceBehavior extends class_4097<EntityMaid> {
    private BlockUpContext context;
    private IMaidBlockUpTask task;
    private int tickCount;


    public BlockUpPlaceBehavior(Map<class_4140<?>, class_4141> p_22528_) {
        super(p_22528_);
    }

    public BlockUpPlaceBehavior() {
        super(Map.of(), 200);
    }

    @Override
    protected boolean checkExtraStartConditions(class_3218 p_22538_, EntityMaid p_22539_) {
        if (!Conditions.isCurrent(p_22539_, CurrentWork.BLOCKUP_UP)) return false;
        if (!MemoryUtil.getBlockUpContext(p_22539_).hasTarget()) return false;
        if (MemoryUtil.getBlockUpContext(p_22539_).getStatus() != BlockUpContext.STATUS.UP) return false;
        return Conditions.hasReachedValidTargetOrReset(p_22539_, 0.8f);
    }

    @Override
    protected boolean canStillUse(class_3218 p_22545_, EntityMaid maid, long p_22547_) {
        if (MemoryUtil.getBlockUpContext(maid).getStatus() != BlockUpContext.STATUS.UP) return false;
        if (maid.method_24828() && !p_22545_.method_8320(maid.method_24515().method_10084().method_10084()).method_26215()) return false;
        if (maid.method_23318() > context.getTargetPos().method_10264() + 2) return false;
        return !(maid.method_24515().equals(context.getTargetPos()) && maid.method_24828());
    }


    @Override
    protected void start(class_3218 p_22540_, EntityMaid maid, long p_22542_) {
        context = MemoryUtil.getBlockUpContext(maid);
        task = (IMaidBlockUpTask) maid.getTask();
        tickCount = 0;
    }

    protected boolean alignOrTryMove(class_3218 level, EntityMaid maid) {
        class_238 boundingBox = maid.method_5829();
        class_2338 startPos = context.getStartPos();
        class_243 move = maid.method_18798();
        if (boundingBox.field_1320 <= startPos.method_10263() + 1 && boundingBox.field_1324 <= startPos.method_10260() + 1 && boundingBox.field_1323 >= startPos.method_10263() && boundingBox.field_1321 >= startPos.method_10260()) {
            maid.method_18800(0, move.field_1351, 0);
            return true;
        }

        class_243 dv = startPos.method_46558().method_1020(boundingBox.method_1005()).method_1029().method_1021(0.02);
        maid.method_18800(dv.field_1352, move.field_1351, dv.field_1350);
        return false;
    }

    @Override
    protected void tick(class_3218 level, EntityMaid maid, long p_22553_) {
        if (!alignOrTryMove(level, maid)) return;
        tickCount += 1;
        if (!maid.method_24828()) {
            task.swapValidItemToHand(maid);
            class_2338 pos = maid.method_24515();
            class_2338 below = pos.method_10074();
            if (context.isOnLine(pos)) if (below.equals(context.getTargetPos())) return;
            if (level.method_8320(below).method_45474() && level.method_8320(pos).method_45474()) {
                maid.method_6104(class_1268.field_5808);
                MaidUtils.placeBlock(maid, below);
            }
        } else {
            maid.method_5993().method_6233();
        }
    }

    @Override
    protected boolean method_18915(long p_22537_) {
        return tickCount > 240;
    }

    @Override
    protected void stop(class_3218 p_22548_, EntityMaid maid, long p_22550_) {
        super.method_18926(p_22548_, maid, p_22550_);
        context.setStatus(BlockUpContext.STATUS.IDLE);
        if (context.hasTarget()) {
            if (!maid.method_24515().equals(context.getTargetPos())) {
                class_2338 startPos = context.getStartPos();
                class_2338 blockPos = maid.method_24515();
                context.setStartTarget(new class_2338(blockPos.method_10263(), startPos.method_10264(), blockPos.method_10260()), blockPos);
            }

            MemoryUtil.setCurrent(maid, CurrentWork.BLOCKUP_DESTROY);
        }
        MemoryUtil.clearTarget(maid);
    }
}
