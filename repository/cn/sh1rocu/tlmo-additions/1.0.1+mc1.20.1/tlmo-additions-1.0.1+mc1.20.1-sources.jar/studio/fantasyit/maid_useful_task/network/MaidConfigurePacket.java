package studio.fantasyit.maid_useful_task.network;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import studio.fantasyit.maid_useful_task.MaidUsefulTask;
import studio.fantasyit.maid_useful_task.data.IConfigSetter;
import studio.fantasyit.maid_useful_task.data.MaidConfigKeys;

public class MaidConfigurePacket {
    public static final class_2960 ID = new class_2960(MaidUsefulTask.MODID, "configure");

    public static class_2540 toBytes(int maidId, class_2960 key, String name, String value) {
        class_2540 buffer = PacketByteBufs.create();
        buffer.writeInt(maidId);
        buffer.method_10814(key.toString());
        buffer.method_10814(name);
        buffer.method_10814(value);
        return buffer;
    }

    public static void handle(MinecraftServer server, class_3222 player, class_3244 handler, class_2540 buf, PacketSender responseSender) {
        int maidId = buf.readInt();
        class_2960 key = class_2960.method_12829(buf.method_19772());
        String name = buf.method_19772();
        String value = buf.method_19772();
        server.execute(() -> {
            if (player != null) {
                if (player.method_37908().method_8469(maidId) instanceof EntityMaid entityMaid) {
                    if (MaidConfigKeys.getValue(entityMaid, key) instanceof IConfigSetter ics) {
                        ics.setConfigValue(name, value);
                    }
                }
            }
        });
    }

    @Environment(EnvType.CLIENT)
    public static void send(EntityMaid maid, class_2960 key, String name, String value) {
        ClientPlayNetworking.send(ID, toBytes(maid.method_5628(), key, name, value));
    }
}
