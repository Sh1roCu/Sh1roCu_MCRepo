package studio.fantasyit.maid_useful_task.behavior.common;

import cn.sh1rocu.touhoulittlemaid.util.itemhandler.CombinedInvWrapper;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.MaidPathFindingBFS;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.maid_useful_task.memory.CurrentWork;
import studio.fantasyit.maid_useful_task.task.IMaidBlockPlaceTask;
import studio.fantasyit.maid_useful_task.util.Conditions;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class PlaceBlockMoveBehavior extends MaidCenterMoveToBlockTask {
    private IMaidBlockPlaceTask task;
    private MaidPathFindingBFS pathfindingBFS;
    private class_2338 targetPos;
    private class_1799 targetItem;

    public PlaceBlockMoveBehavior() {
        super(0.5f, 4);
    }


    @Override
    protected boolean checkExtraStartConditions(class_3218 p_22538_, EntityMaid maid) {
        if (!Conditions.isCurrent(maid, CurrentWork.IDLE)) return false;
        return super.method_18919(p_22538_, maid);
    }

    @Override
    protected void start(class_3218 p_22540_, EntityMaid maid, long p_22542_) {
        super.method_18920(p_22540_, maid, p_22542_);
        if (maid.method_18410())
            this.setSearchRange((int) maid.method_18413());
        task = (IMaidBlockPlaceTask) maid.getTask();
        CombinedInvWrapper inv = maid.getAvailableInv(true);
        List<class_1799> markedVis = new ArrayList<>();
        for (int i = 0; i < inv.getSlots(); i++) {
            if (!task.shouldPlaceItemStack(maid, inv.getStackInSlot(i))) continue;
            int finalI = i;
            if (markedVis.stream().anyMatch(t -> class_1799.method_7984(t, inv.getStackInSlot(finalI)))) continue;
            targetItem = inv.getStackInSlot(i);
            searchForDestination(p_22540_, maid);
            @Nullable class_2338 target = MemoryUtil.getTargetPos(maid);
            if (target != null) {
                MemoryUtil.setPlaceTarget(maid, targetPos);
                MemoryUtil.setCurrent(maid, CurrentWork.PLACE);
                inv.setStackInSlot(finalI, maid.method_6047());
                maid.method_6122(class_1268.field_5808, targetItem);
                return;
            }
            markedVis.add(targetItem);
        }
    }

    @Override
    protected boolean shouldMoveTo(class_3218 serverLevel, EntityMaid entityMaid, class_2338 blockPos) {
        if (!task.shouldPlacePos(entityMaid, targetItem, blockPos.method_10062())) return false;
        if (!entityMaid.method_18407(blockPos)) return false;
        targetPos = blockPos.method_10062();
        if (blockPos instanceof class_2338.class_2339 mb) {
            final int[] dv = {0, 1, -1};
            for (int dx : dv) {
                for (int dy : dv) {
                    for (int dz : dv) {
                        class_2338 pos = mb.method_34592(dx, dy, dz);
                        if (!Conditions.isGlobalValidTarget(entityMaid, pos, targetPos)) continue;
                        if (entityMaid.method_18407(pos) && pathfindingBFS.canPathReach(pos)) {
                            mb.method_10101(pos);
                            return true;
                        }
                    }
                }
            }
        }
        targetPos = null;
        return false;
    }


    @Override
    protected @NotNull MaidPathFindingBFS getOrCreateArrivalMap(@NotNull class_3218 worldIn, @NotNull EntityMaid maid) {
        if (this.pathfindingBFS == null)
            if (maid.method_18410())
                this.pathfindingBFS = new MaidPathFindingBFS(maid.method_5942().method_6342(), worldIn, maid, (int) maid.method_18413(), 9);
            else
                this.pathfindingBFS = new MaidPathFindingBFS(maid.method_5942().method_6342(), worldIn, maid, 7, 9);
        return this.pathfindingBFS;
    }

    @Override
    protected void clearCurrentArrivalMap(MaidPathFindingBFS pathFinding) {
        super.clearCurrentArrivalMap(pathFinding);
        this.pathfindingBFS = null;
    }
}