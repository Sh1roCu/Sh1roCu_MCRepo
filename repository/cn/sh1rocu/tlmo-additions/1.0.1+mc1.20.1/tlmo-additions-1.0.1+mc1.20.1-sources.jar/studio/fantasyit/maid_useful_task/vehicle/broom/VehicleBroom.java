package studio.fantasyit.maid_useful_task.vehicle.broom;

import com.github.tartaricacid.touhoulittlemaid.entity.item.EntityBroom;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.maid_useful_task.util.RotUtil;
import studio.fantasyit.maid_useful_task.vehicle.AbstractMaidControllableVehicle;
import studio.fantasyit.maid_useful_task.vehicle.MaidVehicleControlType;

public class VehicleBroom extends AbstractMaidControllableVehicle {
    @Override
    public boolean isMaidOnThisVehicle(EntityMaid maid) {
        return maid.method_5854() instanceof EntityBroom;
    }

    @Override
    public void maidControlVehicle(EntityMaid maid, MaidVehicleControlType type, class_2338 target) {
        if (maid.method_37908().field_9236) return;
        if (maid.method_5854() instanceof EntityBroom vehicle) {
            if (type == MaidVehicleControlType.NONE) {
                BroomControlParamStore.removeControlParam(maid);
                return;
            }
            double xzDistance = maid.method_5649(target.method_10263(), maid.method_23318(), target.method_10260());
            double finalXRot = vehicle.method_36455();
            double finalYRot = vehicle.method_36454();
            double finalVertical = 0;
            double finalForward;
            if (vehicle.method_5799()) {
                finalXRot = 0;
                finalVertical = 0.1;
            } else if (xzDistance < Math.pow(maid.method_23318() - maid.method_37908().method_8615(), 2)) {
                finalXRot = 0;
                if (maid.method_23318() - maid.method_37908().method_8615() < 50 || vehicle.method_24828()) {
                    finalXRot = 5;
                    finalVertical = -0.2;
                } else {
                    finalXRot = 50;
                    finalVertical = -0.35;
                }
            } else if (maid.method_23318() < 100) {
                finalXRot = -50;
                finalVertical = 0.2;
            } else if (maid.method_23318() > 160) {
                finalXRot = 0;
                finalVertical = -0.1;
            } else {
                finalXRot = 0;
                finalVertical = 0.05;
            }

            finalYRot = RotUtil.getYRot(maid.method_19538(), target.method_46558());

            finalForward = type == MaidVehicleControlType.FULL ? 3.0 : 0;
            if (xzDistance < 5 * 5)
                finalForward = 0;

            BroomControlParamStore.setControlParam(maid, new BroomControlParamStore.BroomControlParam((float) finalXRot, (float) finalYRot, (float) finalVertical, (float) finalForward, type));
        }
    }

    @Override
    public void maidStopControlVehicle(EntityMaid maid) {
        BroomControlParamStore.removeControlParam(maid);
    }

    @Override
    public void syncVehicleParameter(EntityMaid maid, class_2487 tag) {
        BroomControlParamStore.BroomControlParam broomControlParam = BroomControlParamStore.BroomControlParam.fromNbt(tag);
        BroomControlParamStore.setControlParam(maid, broomControlParam);
    }

    @Override
    public @Nullable class_2487 getSyncVehicleParameter(EntityMaid maid) {
        return BroomControlParamStore.getControlParam(maid).toNbt();
    }
}
