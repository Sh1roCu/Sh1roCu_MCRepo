package studio.fantasyit.maid_useful_task.event;

import net.minecraft.class_3218;
import studio.fantasyit.maid_useful_task.task.IMaidVehicleControlTask;
import studio.fantasyit.maid_useful_task.vehicle.MaidVehicleManager;

public class MaidTickEvent {
    public static void onTick(com.github.tartaricacid.touhoulittlemaid.api.event.MaidTickEvent event) {
        if (event.getMaid().method_37908() instanceof class_3218 sl)
            if (event.getMaid().getTask() instanceof IMaidVehicleControlTask imvc && event.getMaid().method_5854() != null) {
                imvc.tick(sl, event.getMaid());
                MaidVehicleManager.syncVehicleParameter(event.getMaid());
            } else if (event.getMaid().method_5854() != null) {
                MaidVehicleManager.stopControlling(event.getMaid());
            }
    }
}