package studio.fantasyit.maid_useful_task.util;

import cn.sh1rocu.touhoulittlemaid.util.itemhandler.IItemHandler;
import java.util.function.Predicate;
import net.minecraft.class_1799;

public class InvUtil {
    public static class_1799 tryExtractOneMatches(IItemHandler inv, Predicate<class_1799> predicate) {
        return tryExtractOneMatches(inv, predicate, false);
    }

    public static class_1799 tryExtractOneMatches(IItemHandler inv, Predicate<class_1799> predicate, boolean simulate) {
        int count = 0;
        for (int i = 0; i < inv.getSlots(); i++) {
            class_1799 stackInSlot = inv.getStackInSlot(i);
            if (stackInSlot.method_7960()) continue;
            if (predicate.test(stackInSlot)) {
                class_1799 get = inv.extractItem(i, 1, simulate);
                if (!get.method_7960()) {
                    return get;
                }
            }
        }
        return class_1799.field_8037;
    }
}
