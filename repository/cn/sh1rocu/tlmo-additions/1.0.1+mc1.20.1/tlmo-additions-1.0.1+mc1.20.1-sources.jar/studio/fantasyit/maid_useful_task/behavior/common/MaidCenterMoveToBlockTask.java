package studio.fantasyit.maid_useful_task.behavior.common;


import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.MaidPathFindingBFS;
import com.github.tartaricacid.touhoulittlemaid.init.InitEntities;
import com.google.common.collect.ImmutableMap;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_4097;
import net.minecraft.class_4099;
import net.minecraft.class_4140;
import net.minecraft.class_4141;
import net.minecraft.class_4215;
import studio.fantasyit.maid_useful_task.util.MaidUtils;

/**
 * From https://github.com/TartaricAcid/TouhouLittleMaid
 * 为了重载getWorkSearchPos而写的
 */
abstract public class MaidCenterMoveToBlockTask extends class_4097<EntityMaid> {

    private static final int MAX_DELAY_TIME = 120;
    private final float movementSpeed;
    private final int verticalSearchRange;
    private int searchRange;
    protected int verticalSearchStart;

    public MaidCenterMoveToBlockTask(float movementSpeed) {
        this(movementSpeed, 1);
    }

    public MaidCenterMoveToBlockTask(float movementSpeed, int verticalSearchRange) {
        this(movementSpeed, verticalSearchRange, 7);
    }

    public MaidCenterMoveToBlockTask(float movementSpeed, int verticalSearchRange, int defaultSearchRange) {
        super(ImmutableMap.of(class_4140.field_18445, class_4141.field_18457, InitEntities.TARGET_POS, class_4141.field_18457));
        this.movementSpeed = movementSpeed;
        this.verticalSearchRange = verticalSearchRange;
        this.searchRange = defaultSearchRange;
    }

    public void setSearchRange(int searchRange) {
        this.searchRange = searchRange;
    }

    protected final void searchForDestination(class_3218 worldIn, EntityMaid maid) {
        MaidPathFindingBFS pathFinding = this.getOrCreateArrivalMap(worldIn, maid);
        class_2338 centrePos = this.getWorkSearchPos(maid);
        class_2338.class_2339 mutableBlockPos = new class_2338.class_2339();

        for (int y = this.verticalSearchStart; y <= this.verticalSearchRange; y = y > 0 ? -y : 1 - y) {
            for (int i = 0; i < searchRange; ++i) {
                for (int x = 0; x <= i; x = x > 0 ? -x : 1 - x) {
                    for (int z = x < i && x > -i ? i : 0; z <= i; z = z > 0 ? -z : 1 - z) {
                        mutableBlockPos.method_25504(centrePos, x, y - 1, z);
                        if (this.shouldMoveTo(worldIn, maid, mutableBlockPos) && this.checkPathReach(maid, pathFinding, mutableBlockPos) && this.checkOwnerPos(maid, mutableBlockPos)) {
                            class_4215.method_24561(maid, mutableBlockPos, this.movementSpeed, 0);
                            maid.method_18868().method_18878((class_4140) InitEntities.TARGET_POS, new class_4099(mutableBlockPos));
                            this.clearCurrentArrivalMap(pathFinding);
                            return;
                        }
                    }
                }
            }
        }

        this.clearCurrentArrivalMap(pathFinding);
    }

    protected void clearCurrentArrivalMap(MaidPathFindingBFS pathFinding) {
        pathFinding.finish();
    }

    protected MaidPathFindingBFS getOrCreateArrivalMap(class_3218 worldIn, EntityMaid maid) {
        return new MaidPathFindingBFS(maid.method_5942().method_6342(), worldIn, maid, maid.searchRadius(), 9);
    }

    private class_2338 getWorkSearchPos(EntityMaid maid) {
        return MaidUtils.getMaidRestrictCenter(maid);
    }

    private boolean checkOwnerPos(EntityMaid maid, class_2338 mutableBlockPos) {
        if (maid.isHomeModeEnable()) {
            return true;
        } else {
            return maid.method_35057() != null && mutableBlockPos.method_19769(maid.method_35057().method_19538(), 8.0);
        }
    }

    protected abstract boolean shouldMoveTo(class_3218 var1, EntityMaid var2, class_2338 var3);

    /**
     * @deprecated
     */
    @Deprecated(
            forRemoval = true
    )
    protected boolean checkPathReach(EntityMaid maid, class_2338 pos) {
        return maid.canPathReach(pos);
    }

    protected boolean checkPathReach(EntityMaid maid, MaidPathFindingBFS pathFinding, class_2338 pos) {
        return pathFinding.canPathReach(pos);
    }
}
