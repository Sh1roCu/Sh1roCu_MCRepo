package studio.fantasyit.maid_useful_task.registry;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3929;
import studio.fantasyit.maid_useful_task.menu.MaidLoggingConfigGui;
import studio.fantasyit.maid_useful_task.menu.MaidReviveConfigGui;

@Environment(EnvType.CLIENT)
public class ClientGuiRegistry {
    public static void init() {
        class_3929.method_17542(GuiRegistry.MAID_LOGGING_CONFIG_GUI, MaidLoggingConfigGui::new);
        class_3929.method_17542(GuiRegistry.MAID_REVIVE_CONFIG_GUI, MaidReviveConfigGui::new);
    }
}
