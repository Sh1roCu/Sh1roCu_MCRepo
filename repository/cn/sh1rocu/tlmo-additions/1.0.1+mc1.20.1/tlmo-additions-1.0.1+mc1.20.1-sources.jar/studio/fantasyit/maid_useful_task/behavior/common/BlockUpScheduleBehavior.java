package studio.fantasyit.maid_useful_task.behavior.common;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.init.InitEntities;
import com.google.common.collect.ImmutableMap;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_4097;
import net.minecraft.class_4099;
import net.minecraft.class_4140;
import net.minecraft.class_4141;
import net.minecraft.class_4215;
import oshi.util.tuples.Pair;
import studio.fantasyit.maid_useful_task.memory.BlockUpContext;
import studio.fantasyit.maid_useful_task.memory.CurrentWork;
import studio.fantasyit.maid_useful_task.task.IMaidBlockUpTask;
import studio.fantasyit.maid_useful_task.util.MaidUtils;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;

public class BlockUpScheduleBehavior extends class_4097<EntityMaid> {
    public BlockUpScheduleBehavior() {
        super(ImmutableMap.of(class_4140.field_18445, class_4141.field_18457, InitEntities.TARGET_POS, class_4141.field_18457));
    }

    @Override
    protected boolean checkExtraStartConditions(class_3218 p_22538_, EntityMaid p_22539_) {
        if (!switch (MemoryUtil.getCurrent(p_22539_)) {
            case BLOCKUP_UP, BLOCKUP_DOWN, BLOCKUP_DESTROY, IDLE -> true;
            default -> false;
        }) {
            return false;
        }
        return super.method_18919(p_22538_, p_22539_);
    }

    @Override
    protected void start(class_3218 p_22540_, EntityMaid maid, long p_22542_) {
        BlockUpContext context = MemoryUtil.getBlockUpContext(maid);
        IMaidBlockUpTask task = (IMaidBlockUpTask) maid.getTask();
        if (context.hasTarget()) {
            if (context.getStatus() != BlockUpContext.STATUS.UP && !context.isOnLine(maid.method_24515())) {
                context.clearStartTarget();
                MemoryUtil.setCurrent(maid, CurrentWork.IDLE);
            } else if (context.getStatus() != BlockUpContext.STATUS.IDLE && MemoryUtil.getTargetPos(maid) == null) {
                if (context.getStatus() == BlockUpContext.STATUS.DOWN) {
                    MemoryUtil.setTarget(maid, context.getTargetPos(), 0.5f);
                    MemoryUtil.setCurrent(maid, CurrentWork.BLOCKUP_DOWN);
                } else if (maid.canPathReach(context.getStartPos())) {
                    MemoryUtil.setTarget(maid, context.getStartPos(), 0.5f);
                    MemoryUtil.setCurrent(maid, CurrentWork.BLOCKUP_UP);
                } else {
                    context.clearStartTarget();
                }
            } else if (!context.isOnLine(maid.method_24515()) || context.getStartPos().equals(context.getTargetPos())) {
                context.clearStartTarget();
                MemoryUtil.setCurrent(maid, CurrentWork.IDLE);
            } else if (context.getStatus() == BlockUpContext.STATUS.IDLE && !task.stillValid(maid, maid.method_24515())) {
                maid.method_18868().method_18878(InitEntities.TARGET_POS, new class_4099(context.getTargetPos()));
                context.setStatus(BlockUpContext.STATUS.DOWN);
                MemoryUtil.setCurrent(maid, CurrentWork.BLOCKUP_DOWN);
            }
        } else {
            Pair<class_2338, class_2338> targetPosBlockUp = task.findTargetPosBlockUp(maid, MaidUtils.getMaidRestrictCenter(maid), task.countMaxUsableBlockItems(maid));
            if (targetPosBlockUp != null) {
                context.setStartTarget(targetPosBlockUp.getA(), targetPosBlockUp.getB());
                maid.method_18868().method_18878(InitEntities.TARGET_POS, new class_4099(targetPosBlockUp.getA()));
                class_4215.method_24561(maid, targetPosBlockUp.getA(), 0.5f, 0);
                context.setStatus(BlockUpContext.STATUS.UP);
                MemoryUtil.setCurrent(maid, CurrentWork.BLOCKUP_UP);
            }
        }
    }
}
