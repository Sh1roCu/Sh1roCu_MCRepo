package studio.fantasyit.maid_useful_task.network;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_634;
import studio.fantasyit.maid_useful_task.MaidUsefulTask;
import studio.fantasyit.maid_useful_task.vehicle.MaidVehicleManager;

public class MaidSyncVehiclePacket {
    public static final class_2960 ID = new class_2960(MaidUsefulTask.MODID, "sync_vehicle");

    public static class_2540 toBytes(int maidId, class_2487 tag) {
        class_2540 buffer = PacketByteBufs.create();
        buffer.writeInt(maidId);
        buffer.method_10794(tag);
        return buffer;
    }

    @Environment(EnvType.CLIENT)
    public static void handle(class_310 client, class_634 handler, class_2540 buf, PacketSender responseSender) {
        int maidId = buf.readInt();
        class_2487 tag = buf.method_10798();
        client.execute(() -> {
            class_1297 entity = Network.getLocalPlayer().method_37908().method_8469(maidId);
            if (entity instanceof EntityMaid maid) {
                MaidVehicleManager.getControllableVehicle(maid).ifPresent(vehicle -> {
                    vehicle.syncVehicleParameter(maid, tag);
                });
            }
        });
    }
}
