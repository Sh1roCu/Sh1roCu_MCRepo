package studio.fantasyit.maid_useful_task.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class KeyMapping {

    public static final net.minecraft.class_304 KEY_SWITCH_VEHICLE_CONTROL = registerKeyMapping(new net.minecraft.class_304(
            "key.maid_useful_tasks.switch_vehicle_control",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_V,
            "key.maid_useful_tasks.categories.main"
    ));

    private static net.minecraft.class_304 registerKeyMapping(net.minecraft.class_304 key) {
        return KeyBindingHelper.registerKeyBinding(key);
    }

    public static void init() {

    }
}
