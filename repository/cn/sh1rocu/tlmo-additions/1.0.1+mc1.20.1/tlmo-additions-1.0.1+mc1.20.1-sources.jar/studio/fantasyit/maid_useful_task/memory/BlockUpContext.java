package studio.fantasyit.maid_useful_task.memory;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.class_2338;

public class BlockUpContext {
    public static final Codec<BlockUpContext> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                            class_2338.field_25064.optionalFieldOf("startPos").forGetter(BlockUpContext::getOptionalStartPos),
                            class_2338.field_25064.optionalFieldOf("targetPos").forGetter(BlockUpContext::getOptionalTargetPos)
                    )
                    .apply(instance, BlockUpContext::new)
    );

    public enum STATUS {
        IDLE,
        DOWN,
        UP
    }

    boolean isGoingDown = false;
    /**
     * 结束位置（女仆所在位置，实际方块为target-1）
     */
    class_2338 targetPos;
    class_2338 startPos;

    public BlockUpContext() {
        this(Optional.empty(), Optional.empty());
    }

    public BlockUpContext(class_2338 startPos, class_2338 targetPos) {
        this.startPos = startPos;
        this.targetPos = targetPos;
    }

    public BlockUpContext(Optional<class_2338> startPos, Optional<class_2338> targetPos) {
        this.startPos = startPos.orElse(null);
        this.targetPos = targetPos.orElse(null);
    }

    public class_2338 getStartPos() {
        return startPos;
    }

    public class_2338 getTargetPos() {
        return targetPos;
    }

    public Optional<class_2338> getOptionalStartPos() {
        return Optional.ofNullable(startPos);
    }

    public Optional<class_2338> getOptionalTargetPos() {
        return Optional.ofNullable(targetPos);
    }


    public boolean isOnLine(class_2338 pos) {
        return pos.method_10263() == startPos.method_10263() && pos.method_10260() == startPos.method_10260() && pos.method_10264() >= startPos.method_10264() && pos.method_10264() <= targetPos.method_10264();
    }

    public void setStartTarget(class_2338 startPos, class_2338 targetPos) {
        this.startPos = startPos;
        this.targetPos = targetPos;
        setStatus(STATUS.IDLE);
    }

    public void clearStartTarget() {
        this.startPos = null;
        this.targetPos = null;
        setStatus(STATUS.IDLE);
    }

    public boolean hasTarget() {
        return startPos != null && targetPos != null;
    }

    public boolean isTarget(class_2338 pos) {
        return pos.equals(targetPos);
    }

    private STATUS status = STATUS.IDLE;

    public STATUS getStatus() {
        return status;
    }

    public void setStatus(STATUS status) {
        this.status = status;
    }
}
