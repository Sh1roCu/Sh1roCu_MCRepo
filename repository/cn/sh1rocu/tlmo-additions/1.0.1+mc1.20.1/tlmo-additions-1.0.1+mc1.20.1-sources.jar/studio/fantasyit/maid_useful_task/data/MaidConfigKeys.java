package studio.fantasyit.maid_useful_task.data;

import com.github.tartaricacid.touhoulittlemaid.api.entity.data.TaskDataKey;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_2960;

public class MaidConfigKeys {
    record keyAndDefSupp<T>(TaskDataKey<T> key, Supplier<T> defaultValue) {
    }

    public static Map<class_2960, keyAndDefSupp<?>> keys = new HashMap<>();

    public static <T> void addKey(class_2960 key, TaskDataKey<T> dataKey, Supplier<T> defaultValue) {
        keys.put(key, new keyAndDefSupp<>(dataKey, defaultValue));
    }

    public static <T> T getValue(EntityMaid maid, class_2960 key) {
        keyAndDefSupp<T> pair = (keyAndDefSupp<T>) keys.get(key);
        return maid.getOrCreateData(pair.key, pair.defaultValue.get());
    }
}
