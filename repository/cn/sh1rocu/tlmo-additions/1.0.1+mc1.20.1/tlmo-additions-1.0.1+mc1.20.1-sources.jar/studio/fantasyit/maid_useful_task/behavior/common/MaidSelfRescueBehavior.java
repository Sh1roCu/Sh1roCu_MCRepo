package studio.fantasyit.maid_useful_task.behavior.common;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import studio.fantasyit.maid_useful_task.Config;
import studio.fantasyit.maid_useful_task.memory.CurrentWork;
import studio.fantasyit.maid_useful_task.task.IMaidBlockDestroyTask;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4097;

public class MaidSelfRescueBehavior extends class_4097<EntityMaid> {
    public MaidSelfRescueBehavior() {
        super(Map.of(), 600);
    }

    boolean started = false;

    private static boolean isNotSafeAndCanTryToDestroy(class_3218 level, EntityMaid maid, class_2338 pos, IMaidBlockDestroyTask task) {
        class_2680 bs = level.method_8320(pos);
        if (bs.method_26215()) return false;
        class_265 collision = bs.method_26220(level, pos);
        if (collision.method_1110()) return false;
        return maid.method_5829().method_994(collision.method_1107().method_996(pos)) && bs.method_26228(level, pos) && task.mayDestroy(maid, pos);
    }

    @Override
    protected boolean checkExtraStartConditions(class_3218 level, EntityMaid maid) {
        if (!Config.enableSelfRescue) return false;
        if (!(maid.getTask() instanceof IMaidBlockDestroyTask ibdt)) return false;
        return isNotSafeAndCanTryToDestroy(level, maid, maid.method_24515(), ibdt) || isNotSafeAndCanTryToDestroy(level, maid, maid.method_24515().method_10084(), ibdt);
    }

    @Override
    protected boolean canStillUse(class_3218 p_22545_, EntityMaid p_22546_, long p_22547_) {
        return started && checkExtraStartConditions(p_22545_, p_22546_);
    }

    @Override
    protected void start(class_3218 p_22540_, EntityMaid maid, long p_22542_) {
        started = false;
        if (MemoryUtil.getCurrent(maid) == CurrentWork.DESTROY) {
            //如果执行中破坏任务，则立刻停止。用以清空相关状态
            MemoryUtil.setCurrent(maid, CurrentWork.IDLE);
            return;
        }
        //等待上一个任务结束
        if (MemoryUtil.getDestroyTargetMemory(maid) != null)
            return;
        if (!(maid.getTask() instanceof IMaidBlockDestroyTask task))
            return;

        started = true;

        List<class_2338> list = new ArrayList<>();
        if (isNotSafeAndCanTryToDestroy(p_22540_, maid, maid.method_24515(), task)) {
            list.add(maid.method_24515());
        }
        if (isNotSafeAndCanTryToDestroy(p_22540_, maid, maid.method_24515().method_10084(), task)) {
            list.add(maid.method_24515().method_10084());
        }
        MemoryUtil.setDestroyTargetMemory(maid, list);
        MemoryUtil.setTarget(maid, maid.method_24515(), 0.5f);
        MemoryUtil.setCurrent(maid, CurrentWork.DESTROY);
    }

    @Override
    protected void stop(class_3218 p_22548_, EntityMaid p_22549_, long p_22550_) {
        MemoryUtil.clearTarget(p_22549_);
        MemoryUtil.setCurrent(p_22549_, CurrentWork.IDLE);
    }
}
