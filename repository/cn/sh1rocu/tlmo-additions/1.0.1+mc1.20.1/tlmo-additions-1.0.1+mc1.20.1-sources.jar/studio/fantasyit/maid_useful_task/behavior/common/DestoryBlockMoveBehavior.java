package studio.fantasyit.maid_useful_task.behavior.common;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.MaidPathFindingBFS;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.maid_useful_task.memory.CurrentWork;
import studio.fantasyit.maid_useful_task.task.IMaidBlockDestroyTask;
import studio.fantasyit.maid_useful_task.util.Conditions;
import studio.fantasyit.maid_useful_task.util.MemoryUtil;
import studio.fantasyit.maid_useful_task.util.PosUtils;

import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class DestoryBlockMoveBehavior extends MaidCenterMoveToBlockTask {
    private IMaidBlockDestroyTask task;
    private MaidPathFindingBFS pathfindingBFS;
    private class_2338 targetPos;
    List<class_2338> blockPosSet;

    public DestoryBlockMoveBehavior() {
        super(0.5f, 7, 8);
    }


    @Override
    protected boolean checkExtraStartConditions(class_3218 p_22538_, EntityMaid maid) {
        if (!Conditions.isCurrent(maid, CurrentWork.IDLE) && !Conditions.isCurrent(maid, CurrentWork.BLOCKUP_DESTROY))
            return false;
        return super.method_18919(p_22538_, maid);
    }

    @Override
    protected void start(@NotNull class_3218 p_22540_, @NotNull EntityMaid maid, long p_22542_) {
        super.method_18920(p_22540_, maid, p_22542_);
        if (maid.method_18410())
            this.setSearchRange((int) maid.method_18413());
        task = (IMaidBlockDestroyTask) maid.getTask();
        task.tryTakeOutTool(maid);
        searchForDestination(p_22540_, maid);
        @Nullable class_2338 target = MemoryUtil.getTargetPos(maid);
        if (target != null && blockPosSet != null) {
            blockPosSet.addAll(task.getTryDestroyBlockListBesidesStart(targetPos, target, maid));
            MemoryUtil.setDestroyTargetMemory(maid, blockPosSet);
            if (Conditions.isCurrent(maid, CurrentWork.IDLE))
                MemoryUtil.setCurrent(maid, CurrentWork.DESTROY);
        }
    }

    @Override
    protected boolean shouldMoveTo(@NotNull class_3218 serverLevel, @NotNull EntityMaid entityMaid, @NotNull class_2338 blockPos) {
        if (!task.shouldDestroyBlock(entityMaid, blockPos.method_10062())) return false;
        targetPos = blockPos.method_10062();
        class_2338 startPos = entityMaid.method_24515();
        if (blockPos instanceof class_2338.class_2339 mb) {
            for (int dx = 0; dx < task.reachDistance(); dx = dx <= 0 ? 1 - dx : -dx) {
                for (int dy = 0; dy < task.reachDistance(); dy = dy <= 0 ? 1 - dy : -dy) {
                    for (int dz = 0; dz < task.reachDistance(); dz = dz <= 0 ? 1 - dz : -dz) {
                        class_2338 pos = mb.method_34592(dx, dy, dz);
                        if (!PosUtils.isSafePos(serverLevel, pos)) continue;
                        if (!Conditions.isGlobalValidTarget(entityMaid, pos, targetPos)) continue;
                        if (pos.method_10262(targetPos) > task.reachDistance() * task.reachDistance()) continue;
                        if (Math.abs(startPos.method_10264() - pos.method_10264()) >= task.reachDistance()) continue;
                        if (Math.abs(startPos.method_10263() - pos.method_10263()) >= task.reachDistance()) continue;
                        if (Math.abs(startPos.method_10260() - pos.method_10260()) >= task.reachDistance()) continue;
                        if (pos.equals(entityMaid.method_24515()) || (entityMaid.method_18407(pos) && pathfindingBFS.canPathReach(pos))) {
                            blockPosSet = task.toDestroyFromStanding(entityMaid, targetPos, pos);
                            if (blockPosSet != null) {
                                mb.method_10101(pos);
                                return true;
                            }
                        }
                    }
                }
            }
        }
        targetPos = null;
        return false;
    }


    @Override
    protected @NotNull MaidPathFindingBFS getOrCreateArrivalMap(@NotNull class_3218 worldIn, @NotNull EntityMaid maid) {
        if (this.pathfindingBFS == null)
            if (maid.method_18410())
                this.pathfindingBFS = new MaidPathFindingBFS(maid.method_5942().method_6342(), worldIn, maid, (int) maid.method_18413() + 1, task.reachDistance() + 2);
            else
                this.pathfindingBFS = new MaidPathFindingBFS(maid.method_5942().method_6342(), worldIn, maid, task.reachDistance() + 1, task.reachDistance() + 2);
        return this.pathfindingBFS;
    }

    @Override
    protected void clearCurrentArrivalMap(MaidPathFindingBFS pathFinding) {
        super.clearCurrentArrivalMap(pathFinding);
        this.pathfindingBFS = null;
    }
}