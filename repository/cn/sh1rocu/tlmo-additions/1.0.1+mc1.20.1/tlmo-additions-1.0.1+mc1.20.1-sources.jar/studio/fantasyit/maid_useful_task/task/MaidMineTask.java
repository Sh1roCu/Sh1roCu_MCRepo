package studio.fantasyit.maid_useful_task.task;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_2338;

public class MaidMineTask implements IMaidBlockDestroyTask {
    @Override
    public boolean shouldDestroyBlock(EntityMaid maid, class_2338 pos) {
        return false;
    }

    @Override
    public boolean mayDestroy(EntityMaid maid, class_2338 pos) {
        return false;
    }

}
