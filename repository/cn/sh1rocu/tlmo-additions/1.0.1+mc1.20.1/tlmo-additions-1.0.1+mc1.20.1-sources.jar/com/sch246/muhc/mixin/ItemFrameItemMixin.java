package com.sch246.muhc.mixin;

import com.sch246.muhc.Config;
import net.minecraft.class_1657;
import net.minecraft.class_1795;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1795.class)
public class ItemFrameItemMixin {
    @Inject(method = "mayPlace", at = @At("HEAD"), cancellable = true)
    private void allowPlaceOverCrank(class_1657 player, class_2350 direction,
                                     class_1799 itemStack, class_2338 pos,
                                     CallbackInfoReturnable<Boolean> cir) {
        if (Config.ITEM_FRAME_INTERACTION.get()) {
            cir.setReturnValue(true);
        }
    }
}