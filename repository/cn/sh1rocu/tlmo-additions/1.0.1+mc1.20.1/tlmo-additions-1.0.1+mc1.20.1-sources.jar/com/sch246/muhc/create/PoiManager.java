package com.sch246.muhc.create;

import com.google.common.collect.ImmutableSet;
import com.simibubi.create.AllBlocks;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2680;
import net.minecraft.class_4158;
import java.util.Set;
import java.util.stream.Stream;

public final class PoiManager {
    private static final Set<class_2680> ALL_CRANK_STATES;

    public PoiManager() {
    }

    public static class_4158 getCrankPoiType() {
        return new class_4158(ALL_CRANK_STATES, 1, 1);
    }

    static {
        Stream<class_2680> handCrankStates = AllBlocks.HAND_CRANK.get()
                .method_9595()
                .method_11662()
                .stream();

        // create_connected 的方块
        Stream<class_2680> crankWheelStates = Stream.empty();
        Stream<class_2680> largeCrankWheelStates = Stream.empty();

        // 直接引用，如果mod未安装，下面代码不会被调用（但编译仍需依赖，需加 optional 依赖）
        if (isCreateConnectedLoaded()) {
            // TODO: wait for Fabric port
//            crankWheelStates = CCBlocks.CRANK_WHEEL.get()
//                    .getStateDefinition()
//                    .getPossibleStates()
//                    .stream();
//            largeCrankWheelStates = CCBlocks.LARGE_CRANK_WHEEL.get()
//                    .getStateDefinition()
//                    .getPossibleStates()
//                    .stream();
        }

        // 合并所有，收集成 Set
        ALL_CRANK_STATES = Stream.of(handCrankStates, crankWheelStates, largeCrankWheelStates)
                .flatMap(s -> s)
                .collect(ImmutableSet.toImmutableSet());
    }

    private static boolean isCreateConnectedLoaded() {
        return FabricLoader.getInstance().isModLoaded("create_connected");
    }
}