package com.sch246.muhc.maid.task;

import com.github.tartaricacid.touhoulittlemaid.entity.ai.brain.task.MaidCheckRateTask;
import com.github.tartaricacid.touhoulittlemaid.entity.chatbubble.implement.TextChatBubbleData;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.init.InitEntities;
import com.google.common.collect.ImmutableMap;
import com.sch246.muhc.Config;
import com.sch246.muhc.MaidUseHandCrank;
import com.sch246.muhc.create.InitPoi;
import com.sch246.muhc.util.DynamicLangKeys;
import com.sch246.muhc.util.IMaidHandCrank;
import com.sch246.muhc.util.IUniPosOwner;
import com.simibubi.create.content.kinetics.crank.HandCrankBlock;
import com.simibubi.create.content.kinetics.crank.HandCrankBlockEntity;
import javax.annotation.Nonnull;
import net.minecraft.class_1268;
import net.minecraft.class_1533;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4140;
import net.minecraft.class_4141;
import net.minecraft.class_4153;
import net.minecraft.class_4156;
import net.minecraft.class_4168;
import net.minecraft.class_4215;
import net.minecraft.class_5819;
import java.util.Comparator;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class UseHandCrank extends MaidCheckRateTask implements IUniPosOwner {
    private static final int MAX_DELAY_TIME = 60;

    private final float speed;
    private int operationTimer = 0;
    private int bubbleTimer = 0;
    private final class_5819 random = class_5819.method_43047();
    private class_2338 crankPos;
    private boolean offHand = false;

    public UseHandCrank(float speed) {
        super(ImmutableMap.of(
                class_4140.field_18445, class_4141.field_18457,
                InitEntities.TARGET_POS, class_4141.field_18457));
        this.speed = speed;
        this.setMaxCheckRate(MAX_DELAY_TIME);
        this.bubbleTimer = getRandomBubbleTimer();
    }

    protected boolean outOfReachRange(EntityMaid maid, class_2338 pos) {
        int reachRadius = Config.REACH_RADIUS.get();
        return pos.method_19770(maid.method_19538()) > reachRadius * reachRadius;
    }

    @Override
    protected boolean checkExtraStartConditions(@Nonnull class_3218 level, @Nonnull EntityMaid maid) {
        // 这段必定在start前检查
        if (!super.checkExtraStartConditions(level, maid)) {
            return false;
        }

        // 女仆无法移动不会导致任务无法启动，坐着开始很正常
        // if (!maid.canBrainMoving()) {
        // MaidUseHandCrank.LOGGER.info("女仆无法移动，任务无法启动");
        // return false;
        // }

        // 每次运行都会重新检查最近的手摇曲柄
        class_2338 pos = findCrankHandle(maid, level);
        if (pos == null) {
            if (crankPos != null) {
                // 存储的pos不可达，释放
                unLock(level, crankPos);
                crankPos = null;
            }
            return false;
        }
        MaidUseHandCrank.LOGGER.debug("寻找到的手摇曲柄位置: {}", pos);

        // 若方块不是自己独占的
        if (crankPos != pos && !pos.equals(crankPos)) {
            if (crankPos != null) {
                // 确保只持有一个锁
                unLock(level, crankPos);
            }
            crankPos = pos;
            if (Config.CLAIMS_BEFOREHAND.get()) {
                MaidUseHandCrank.LOGGER.debug("尝试独占方块");
                if (!tryLock(level, crankPos)) {
                    MaidUseHandCrank.LOGGER.debug("独占方块失败");
                    crankPos = null;
                    return false;
                }
                MaidUseHandCrank.LOGGER.debug("独占方块成功");
            }
        } else {
            MaidUseHandCrank.LOGGER.debug("方块本是独占的");
        }

        if (outOfReachRange(maid, crankPos)) {
            MaidUseHandCrank.LOGGER.debug("发现手摇曲柄，但距离太远，开始移动...");
            class_4215.method_24561(maid, getFrontPos(level, crankPos), speed, 0);
//            BehaviorUtils.setWalkAndLookTargetMemories(maid, crankPos, speed, Config.REACH_RADIUS.get());
            this.setNextCheckTickCount(5);
            return false;
        }

        MaidUseHandCrank.LOGGER.debug("找到并锁定了手摇曲柄，任务准备启动");
        return true;
    }

    @Override
    protected void start(@Nonnull class_3218 level, @Nonnull EntityMaid maid, long gameTime) {
        MaidUseHandCrank.LOGGER.debug("手摇曲柄任务：开始执行");
        if (crankPos == null) {
            MaidUseHandCrank.LOGGER.debug("start:坐标不存在");
            return;
        }
        // 让女仆面向曲柄
        MaidUseHandCrank.LOGGER.debug("改变女仆的朝向...");
        maid.method_5988().method_19615(crankPos.method_46558());
    }

    /**
     * 根据手摇曲柄的当前状态，计算其前方方块的坐标
     *
     * @param level 输入的维度
     * @param pos   输入的坐标
     * @return frontPos 手摇曲柄前方的坐标，若当前不是手摇曲柄，返回原坐标
     */
    private class_2338 getFrontPos(@Nonnull class_3218 level, class_2338 pos) {
        class_2680 blockState = level.method_8320(pos);
        if (blockState.method_26204() instanceof HandCrankBlock) {
            return pos.method_10093(blockState.method_11654(HandCrankBlock.FACING));
        }
        return pos;
    }

    @Override
    protected boolean canStillUse(@Nonnull class_3218 level, @Nonnull EntityMaid maid, long gameTime) {
        // 这段必定在tick前检查
        // MaidUseHandCrank.LOGGER.debug("女仆已在操作状态，重新验证目标...");

        // 女仆无法移动不会导致任务结束，坐下开始任务不是很正常吗
        // if (!maid.canBrainMoving()) {
        // MaidUseHandCrank.LOGGER.info("女仆无法移动，任务结束");
        // return false;
        // }

        // 下班！
        if (maid.getScheduleDetail() != class_4168.field_18596) {
            return false;
        }

        if (crankPos == null) {
            MaidUseHandCrank.LOGGER.debug("位置已丢失，停止操作");
            return false;
        }

        if (!(level.method_8321(crankPos) instanceof HandCrankBlockEntity)) {
            MaidUseHandCrank.LOGGER.debug("方块验证失败，停止操作");
            return false;
        }

        if (outOfReachRange(maid, crankPos)) {
            MaidUseHandCrank.LOGGER.debug("距离太远，停止操作");
            return false;
        }

        return true;
    }

    @Override
    protected boolean method_18915(long gameTime) {
        return false;
    }

    @Override
    protected void tick(@Nonnull class_3218 level, @Nonnull EntityMaid maid, long gameTime) {
        // MaidUseHandCrank.LOGGER.debug("手摇曲柄任务 tick - 处于操作状态");
        if (crankPos == null) {
            MaidUseHandCrank.LOGGER.debug("tick:坐标不存在");
            return;
        }

        // 持续续租
        refreshLock(level, crankPos);

        // 开始操作状态
        int maxOperationTime = Config.OPERATION_INTERVAL.get();
        maid.method_5988().method_19615(crankPos.method_46558());
        if (operationTimer == 0) {
            // MaidUseHandCrank.LOGGER.debug("执行一次曲柄操作");

            // 尝试重新锁定最近的曲柄
            refreshLockToNearestAvailable(level, maid);

            operateReachableFreeCrankHandle(level, maid);

        } else if (Config.TWO_HANDED_OPERATION.get()
                && operationTimer == maxOperationTime / 2
                && maid.getFavorability() == 384) {
            // 满级好感速度*2
            offHand = !offHand;
            operateReachableFreeCrankHandle(level, maid);
            offHand = !offHand;
        }

        operationTimer = (operationTimer + 1) % maxOperationTime;

        handleChatBubbles(maid);
    }

    private void refreshLockToNearestAvailable(@Nonnull class_3218 level, @Nonnull EntityMaid maid) {
        class_2338 pos = getNearestReachableCrankPosition(maid, level,
                p -> level.method_8321(p) instanceof HandCrankBlockEntity
                        && canLock(level, p));
        if (pos != null && crankPos != pos && !pos.equals(crankPos) && tryLock(level, pos)) {
            if (crankPos != null) {
                // 确保只持有一个锁
                unLock(level, crankPos);
            }
            crankPos = pos;
        }
    }

//    private boolean shouldOperate(int favorability, int maxOperationTime) {
//        if (favorability >= 64 && favorability < 192) {
//            return operationTimer == maxOperationTime / 2;
//        } else if (favorability >= 192 && favorability < 384) {
//            int third = maxOperationTime / 3;
//            return (operationTimer == third || operationTimer == 2 * third);
//        } else if (favorability == 384) {
//            int quarter = maxOperationTime / 4;
//            return (operationTimer == quarter || operationTimer == 2 * quarter || operationTimer == 3 * quarter);
//        }
//        return false;
//    }

    private void operateReachableFreeCrankHandle(@Nonnull class_3218 level, @Nonnull EntityMaid maid) {
        int halfTime = Config.OPERATION_DURATION.get() / 2;
        class_2338 pos = getNearestReachableCrankPosition(maid, level,
                p -> level.method_8321(p) instanceof HandCrankBlockEntity handCrank
                        && handCrank.inUse <= halfTime);
        if (pos != null) {
            operateCrankHandle(level, maid, pos);
        }
    }

    private void handleChatBubbles(@Nonnull EntityMaid maid) {
        if (Config.RANDOM_WALK.get() && maid.canBrainMoving()) {
            return; // 允许到处走且能移动时不显示气泡
        }

        if (--bubbleTimer <= 0) {
            bubbleTimer = getRandomBubbleTimer();
            String[] chatBubbles = DynamicLangKeys.getChatBubbles();
            if (chatBubbles == null || chatBubbles.length == 0) return;
            class_2561 component = getComponent(maid, chatBubbles[random.method_43048(chatBubbles.length)]);
            maid.getChatBubbleManager().addChatBubble(TextChatBubbleData.type2(component));
        }
    }

    private int getRandomBubbleTimer() {
        int r = Config.BUBBLE_INTERVAL.get();
        if (r <= 0) return Integer.MAX_VALUE; // 设置0也许应该不触发
        return (r / 2) + random.method_43048(r);
    }

    private static @Nonnull class_2561 getComponent(EntityMaid maid, String messageKey) {
        class_2561 component;
        class_2561 ownerName = (maid.method_35057() != null)
                ? maid.method_35057().method_5477()
                : class_2561.method_43470("Master");

        if (messageKey.contains(".master2.")) {
            component = class_2561.method_43469(messageKey, ownerName, ownerName);
        } else if (messageKey.contains(".master.")) {
            component = class_2561.method_43469(messageKey, ownerName);
        } else {
            component = class_2561.method_43471(messageKey);
        }
        return component;
    }

    @Override
    protected void stop(@Nonnull class_3218 level, @Nonnull EntityMaid maid, long gameTime) {
        MaidUseHandCrank.LOGGER.debug("手摇曲柄任务停止，清除相关记忆");
        operationTimer = 0;
        // 释放已声明的位置，释放失败也问题不大，因为任务是弱引用
        if (crankPos != null) {
            unLock(level, crankPos);
            crankPos = null;
        }
        maid.method_18868().method_18875(InitEntities.TARGET_POS);
        maid.method_18868().method_18875(class_4140.field_18446);
        maid.method_18868().method_18875(class_4140.field_18445);
    }

    @javax.annotation.Nullable
    private class_2338 findCrankHandle(EntityMaid maid, class_3218 level) {

        int centerRadius = Config.CENTER_SEARCH_RADIUS.get();
        if (centerRadius == 0) {
            // 车万女仆的实际跟随距离就是比设置距离小，这可能是原 mod 的 bug
            centerRadius = maid.isHomeModeEnable()
                    ? (int) maid.method_18413() - 1
                    : (int) maid.method_18413() - 2;
        }
        class_243 centerPos = maid.method_18410()
                ? maid.method_18412().method_46558()
                : Optional.ofNullable(maid.method_35057())
                .map(e -> new class_243(e.method_23317(), e.method_23318(), e.method_23321()))
                .orElse(maid.method_19538());

        int maidRadius = Config.MAID_SEARCH_RADIUS.get();
        if (maidRadius == 0) {
            maidRadius = Config.REACH_RADIUS.get();
        }
        class_243 maidPos = maid.method_19538();

        MaidUseHandCrank.LOGGER.debug("default: 开始在 {} 周围 {} 格，以及 {} 周围 {} 格内搜索手摇曲柄POI...", centerPos, centerRadius, maidPos, maidRadius);
        class_2338 result = getCrankInDoubleCircleUnion(level, centerPos, centerRadius, maidPos, maidRadius)
                .map(class_4156::method_19141)
                .filter(pos -> level.method_8321(pos) instanceof HandCrankBlockEntity handCrank
                        && handCrank.inUse == 0
                        && canLock(level, pos))
                .min(Comparator.comparingDouble(pos -> pos.method_10262(maid.method_24515())))
                .orElse(null);

        MaidUseHandCrank.LOGGER.debug("手摇曲柄搜索完成，结果: {}", result);
        return result;
    }

    public Stream<class_4156> getCrankInDoubleCircleUnion(class_3218 level,
                                                         class_243 centerPos, int centerRadius,
                                                         class_243 maidPos, int maidRadius) {
        // 计算包含两个圆的最小方形区域
        int minX = Math.min((int) centerPos.method_10216() - centerRadius, (int) maidPos.method_10216() - maidRadius);
        int maxX = Math.max((int) centerPos.method_10216() + centerRadius, (int) maidPos.method_10216() + maidRadius);
        int minZ = Math.min((int) centerPos.method_10215() - centerRadius, (int) maidPos.method_10215() - maidRadius);
        int maxZ = Math.max((int) centerPos.method_10215() + centerRadius, (int) maidPos.method_10215() + maidRadius);

        // 计算需要检查的区块范围
        int minChunkX = Math.floorDiv(minX, 16);
        int maxChunkX = Math.floorDiv(maxX, 16);
        int minChunkZ = Math.floorDiv(minZ, 16);
        int maxChunkZ = Math.floorDiv(maxZ, 16);

        // 预计算距离平方以避免重复计算
        int centerRadiusSqr = centerRadius * centerRadius;
        int maidRadiusSqr = maidRadius * maidRadius;

        class_4153 poiManager = level.method_19494();

        return class_1923.method_19281(new class_1923(minChunkX, minChunkZ), new class_1923(maxChunkX, maxChunkZ))
                .flatMap(chunkPos -> poiManager.method_19123(
                        type -> type.comp_349().equals(InitPoi.HAND_CRANK),
                        chunkPos, class_4153.class_4155.field_18489))
                .filter(poiRecord -> {
                    class_2338 pos = poiRecord.method_19141();
                    // 需要能走到正前方，要么能直接碰到
                    return getFrontPos(level, pos).method_19770(centerPos) <= centerRadiusSqr ||
                            pos.method_19770(maidPos) <= maidRadiusSqr;
                });
    }

    @javax.annotation.Nullable
    private class_2338 getNearestReachableCrankPosition(EntityMaid maid, class_3218 level, Predicate<class_2338> blockPredicate) {
        // 使用注册的POI类型查找手摇曲柄
        return level.method_19494()
                .method_19125(
                        type -> type.comp_349().equals(InitPoi.HAND_CRANK),
                        maid.method_24515(),
                        Config.REACH_RADIUS.get(),
                        class_4153.class_4155.field_18489
                )
                .map(class_4156::method_19141)
                .filter(blockPredicate)
                .min(Comparator.comparingDouble(pos -> pos.method_10262(maid.method_24515())))
                .orElse(null);
    }

    private float lastStress = -1;

    private void operateCrankHandle(class_3218 level, EntityMaid maid, @Nonnull class_2338 pos) {
        // MaidUseHandCrank.LOGGER.debug("女仆 {} 正在操作位于 {} 的手摇曲柄",
        // maid.getName().getString(), pos);

        if (!(level.method_8321(pos) instanceof HandCrankBlockEntity handCrank)) {
            MaidUseHandCrank.LOGGER.debug("未找到手摇曲柄的方块实体");
            return;
        }

        // ------------ 是否反转 ------------

        // 若位置有物品展示框则反转
        boolean back = false;
        if (Config.ITEM_FRAME_INTERACTION.get()) {
            back = !level.method_18467(class_1533.class, new class_238(pos)).isEmpty();
        }

        if (handCrank.getSpeed() != 0.0F) {
            // 如果检测到旋转，那么会更新旋转方向
            back = handCrank.method_11010()
                    .method_11654(HandCrankBlock.FACING).method_10171() == class_2350.class_2352.field_11056
                    ? handCrank.getSpeed() < 0
                    : handCrank.getSpeed() > 0;
        }

        MaidUseHandCrank.LOGGER.debug("{} 当前方向 {}", maid.method_5477().getString(), back ? "逆向" : "正向");

        // ------------ 好感度加成 ------------

        int favorability = maid.getFavorability();

        // 好感度加应力
        float speed = 32;
        float baseStress = ((float) Config.BASE_STRESS.get()) / speed;
        float extraStress = ((float) Config.STRESS_PER_FAVORABILITY.get()) / speed;
        float stress = (baseStress + favorability * extraStress);

        // 好感度增加应力时间
        int tick = Config.OPERATION_DURATION.get();
        if (Config.ENDURANCE_OPERATION.get() && favorability >= 192) {
            tick *= 2;
        }

        if (handCrank instanceof IMaidHandCrank maidHandCrank) {
            maidHandCrank.muhc$setStress(stress, tick);
        }

        // ------------ 原版turn ------------

        boolean update = handCrank.getGeneratedSpeed() == 0.0F
                || back != handCrank.backwards
                || lastStress != stress;
        lastStress = stress;

        handCrank.inUse = tick;
        handCrank.backwards = back;
        if (update && !level.field_9236) {
            handCrank.updateGeneratedRotation();
        }

        // ------------ 女仆动画 ------------

        maid.method_6104(offHand ? class_1268.field_5810 : class_1268.field_5808);
    }

}