package com.sch246.muhc.mixin;

import com.sch246.muhc.util.IMaidHandCrank;
import com.simibubi.create.content.kinetics.base.GeneratingKineticBlockEntity;
import com.simibubi.create.content.kinetics.crank.HandCrankBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HandCrankBlockEntity.class)
public abstract class HandCrankBlockEntityMixin extends GeneratingKineticBlockEntity implements IMaidHandCrank {

    @Unique
    private float muhc$stress = 0;

    @Unique
    private int muhc$tick = 0;

    @Unique
    @Override
    public float muhc$getStress() {
        return muhc$stress;
    }

    @Unique
    @Override
    public int muhc$getTick() {
        return muhc$tick;
    }

    public HandCrankBlockEntityMixin(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    @Unique
    public void muhc$setStress(float stress, int tick) {
        muhc$stress = stress;
        muhc$tick = tick;
        this.sendData(); // 发送数据包到客户端
    }

    @Inject(method = "write", at = @At("TAIL"), remap = false)
    private void onWrite(class_2487 compound, boolean clientPacket, CallbackInfo ci) {
        compound.method_10548("muhc_stress", muhc$stress);
        compound.method_10569("muhc_tick", muhc$tick);
    }

    @Inject(method = "read", at = @At("TAIL"), remap = false)
    private void onRead(class_2487 compound, boolean clientPacket, CallbackInfo ci) {
        muhc$stress = compound.method_10583("muhc_stress");
        muhc$tick = compound.method_10550("muhc_tick");
    }

    @Inject(method = "tick", at = @At("TAIL"), remap = false)
    private void onTick(CallbackInfo ci) {
        if (muhc$tick > 0) {
            --muhc$tick;
            if (muhc$tick == 0) {
                muhc$stress = 0;
            }
        }
    }
}