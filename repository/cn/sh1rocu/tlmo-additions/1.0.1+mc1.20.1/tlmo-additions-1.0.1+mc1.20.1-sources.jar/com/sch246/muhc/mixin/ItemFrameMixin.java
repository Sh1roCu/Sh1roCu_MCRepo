package com.sch246.muhc.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.simibubi.create.content.kinetics.crank.HandCrankBlockEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1533.class)
public class ItemFrameMixin {
    @WrapOperation(method = "survives",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/world/level/Level;noCollision(Lnet/minecraft/world/entity/Entity;)Z"))
    private boolean allowCollisionWithCrank(class_1937 level, class_1297 entity, Operation<Boolean> original) {
        // 如果与手摇曲柄碰撞，直接返回 true
        if (level.method_8321(entity.method_24515()) instanceof HandCrankBlockEntity) {
            return true;
        }
        // 否则使用原版逻辑
        return original.call(level, entity);
    }

}
