package com.github.touhoumaidaffection.network;

import com.github.touhoumaidaffection.TouhouMaidAffection;
import com.github.touhoumaidaffection.handler.KissMaidHandler;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;

public class KissCarryRequestMessage {
    public static final class_2960 ID = new class_2960(TouhouMaidAffection.MOD_ID, "kiss_carry_request");
    public static final class_2540 DUMMY = PacketByteBufs.empty();

    public static void handle(MinecraftServer server, class_3222 sender, class_3244 handler, class_2540 buf, PacketSender responseSender) {
        server.execute(() -> {
            if (sender != null) {
                KissMaidHandler.tryKissCarriedMaid(sender);
            }
        });
    }
}
