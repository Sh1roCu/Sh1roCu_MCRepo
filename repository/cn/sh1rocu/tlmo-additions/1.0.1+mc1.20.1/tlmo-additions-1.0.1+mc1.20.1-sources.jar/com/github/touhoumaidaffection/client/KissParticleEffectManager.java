package com.github.touhoumaidaffection.client;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.touhoumaidaffection.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_638;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Environment(EnvType.CLIENT)
public class KissParticleEffectManager {
    private static final List<KissParticleEffectInstance> ACTIVE_EFFECTS = new ArrayList<>();
    private static final double TAU = Math.PI * 2.0;

    public static void queueKissEffect(class_1297 maid, class_1297 player) {
        class_310 mc = class_310.method_1551();
        class_638 level = mc.field_1687;
        if (level == null) {
            return;
        }

        int favorabilityLevel = 0;
        if (maid instanceof EntityMaid entityMaid) {
            favorabilityLevel = entityMaid.getFavorabilityManager().getLevel();
        }

        int totalLogicalParticles = ModConfig.PARTICLE_COUNT_MIN.get() + level.field_9229.method_43048(ModConfig.PARTICLE_COUNT_EXTRA.get() + 1);
        ACTIVE_EFFECTS.add(new KissParticleEffectInstance(level.method_8510(), maid.method_5628(), player.method_5628(), totalLogicalParticles, favorabilityLevel));
    }

    public static void onClientTick(class_310 client) {
        class_310 mc = class_310.method_1551();
        class_638 level = mc.field_1687;
        if (level == null) {
            ACTIVE_EFFECTS.clear();
            return;
        }

        long currentTick = level.method_8510();
        Iterator<KissParticleEffectInstance> iterator = ACTIVE_EFFECTS.iterator();
        while (iterator.hasNext()) {
            KissParticleEffectInstance effect = iterator.next();
            if (effect.isFinished(currentTick)) {
                iterator.remove();
                continue;
            }
            if (!effect.emitPendingBursts(level, currentTick)) {
                iterator.remove();
            }
        }
    }

    private static final class KissParticleEffectInstance {
        private final long startTick;
        private final int maidEntityId;
        private final int playerEntityId;
        private final int[] burstCounts;
        private final int phaseBursts;
        private final int phaseIntervalTicks;
        private final int favorabilityLevel;
        private final ModConfig.ParticleShapeMode shapeMode;
        private final ModConfig.ParticlePhaseRamp phaseRamp;
        private final ModConfig.ParticleAccentType accentType;
        private final ModConfig.ParticleAccentColorMode accentColorMode;
        private final double offsetY;
        private final double spreadRadius;
        private final double forwardOffset;
        private final double avoidViewStrength;
        private final double upwardSpeed;
        private final double radialSpeed;
        private final double swirlSpeed;
        private final int clusterCopies;
        private final double clusterJitter;
        private final boolean accentEnabled;
        private final double accentChance;
        private final boolean favorabilityColorAccent;
        private final Rgba solidAccent;
        private final Rgba gradientStartAccent;
        private final Rgba gradientEndAccent;
        private int nextBurstIndex;

        private KissParticleEffectInstance(long startTick, int maidEntityId, int playerEntityId, int logicalTotalCount, int favorabilityLevel) {
            this.startTick = startTick;
            this.maidEntityId = maidEntityId;
            this.playerEntityId = playerEntityId;
            this.phaseBursts = ModConfig.PARTICLE_PHASE_BURSTS.get();
            this.phaseIntervalTicks = ModConfig.PARTICLE_PHASE_INTERVAL_TICKS.get();
            this.favorabilityLevel = favorabilityLevel;
            this.shapeMode = ModConfig.getParticleShapeMode();
            this.phaseRamp = ModConfig.getParticlePhaseRamp();
            this.accentType = ModConfig.getParticleAccentType();
            this.accentColorMode = ModConfig.getParticleAccentColorMode();
            this.offsetY = ModConfig.PARTICLE_OFFSET_Y.get();
            this.spreadRadius = ModConfig.PARTICLE_SPREAD_RADIUS.get();
            this.forwardOffset = ModConfig.PARTICLE_FORWARD_OFFSET.get();
            this.avoidViewStrength = ModConfig.PARTICLE_AVOID_VIEW_STRENGTH.get();
            this.upwardSpeed = ModConfig.PARTICLE_UPWARD_SPEED.get();
            this.radialSpeed = ModConfig.PARTICLE_RADIAL_SPEED.get();
            this.swirlSpeed = ModConfig.PARTICLE_SWIRL_SPEED.get();
            this.clusterCopies = ModConfig.PARTICLE_CLUSTER_COPIES.get();
            this.clusterJitter = ModConfig.PARTICLE_CLUSTER_JITTER.get();
            this.accentEnabled = ModConfig.PARTICLE_ACCENT_ENABLED.get();
            this.accentChance = ModConfig.PARTICLE_ACCENT_CHANCE.get();
            this.favorabilityColorAccent = ModConfig.PARTICLE_FAVORABILITY_COLOR_ACCENT.get();
            this.solidAccent = new Rgba(
                    ModConfig.PARTICLE_ACCENT_SOLID_R.get(),
                    ModConfig.PARTICLE_ACCENT_SOLID_G.get(),
                    ModConfig.PARTICLE_ACCENT_SOLID_B.get(),
                    ModConfig.PARTICLE_ACCENT_SOLID_A.get()
            );
            this.gradientStartAccent = new Rgba(
                    ModConfig.PARTICLE_ACCENT_GRADIENT_START_R.get(),
                    ModConfig.PARTICLE_ACCENT_GRADIENT_START_G.get(),
                    ModConfig.PARTICLE_ACCENT_GRADIENT_START_B.get(),
                    ModConfig.PARTICLE_ACCENT_GRADIENT_START_A.get()
            );
            this.gradientEndAccent = new Rgba(
                    ModConfig.PARTICLE_ACCENT_GRADIENT_END_R.get(),
                    ModConfig.PARTICLE_ACCENT_GRADIENT_END_G.get(),
                    ModConfig.PARTICLE_ACCENT_GRADIENT_END_B.get(),
                    ModConfig.PARTICLE_ACCENT_GRADIENT_END_A.get()
            );
            this.burstCounts = distributeToBursts(logicalTotalCount, phaseBursts, phaseRamp);
            this.nextBurstIndex = 0;
        }

        private boolean emitPendingBursts(class_638 level, long currentTick) {
            class_1297 maid = level.method_8469(maidEntityId);
            class_1297 player = level.method_8469(playerEntityId);
            if (maid == null || player == null) {
                return false;
            }

            long elapsed = Math.max(0, currentTick - startTick);
            while (nextBurstIndex < phaseBursts && elapsed >= (long) nextBurstIndex * phaseIntervalTicks) {
                emitSingleBurst(level, maid, player, nextBurstIndex, burstCounts[nextBurstIndex]);
                nextBurstIndex++;
            }
            return true;
        }

        private boolean isFinished(long currentTick) {
            if (nextBurstIndex < phaseBursts) {
                return false;
            }
            long elapsed = Math.max(0, currentTick - startTick);
            return elapsed > (long) phaseBursts * phaseIntervalTicks + 6L;
        }

        private void emitSingleBurst(class_638 level, class_1297 maid, class_1297 player, int burstIndex, int logicalCount) {
            if (logicalCount <= 0) {
                return;
            }

            class_243 playerEye = player.method_33571();
            class_243 maidEye = maid.method_33571();
            class_243 axisForward = getHorizontalForward(playerEye, maidEye, player.method_5720());
            class_243 axisRight = new class_243(-axisForward.field_1350, 0.0, axisForward.field_1352);

            double sideSign = Math.signum(maidEye.method_1020(playerEye).method_1026(axisRight));
            if (sideSign == 0) {
                sideSign = 1.0;
            }

            class_243 anchor = playerEye.method_1019(maidEye).method_1021(0.5)
                    .method_1031(0.0, offsetY + avoidViewStrength * 0.15, 0.0)
                    .method_1019(axisForward.method_1021(forwardOffset))
                    .method_1019(axisRight.method_1021(sideSign * avoidViewStrength * spreadRadius * 0.5));

            double phaseProgress = phaseBursts <= 1 ? 1.0 : (double) burstIndex / (double) (phaseBursts - 1);

            for (int i = 0; i < logicalCount; i++) {
                double angle = level.field_9229.method_43058() * TAU;
                double radius = sampleRadius(level, phaseProgress);
                if (shapeMode == ModConfig.ParticleShapeMode.SPIRAL) {
                    angle += phaseProgress * TAU * 0.75;
                }

                class_243 radialDir = axisRight.method_1021(Math.cos(angle)).method_1019(axisForward.method_1021(Math.sin(angle)));
                class_243 tangentDir = axisRight.method_1021(-Math.sin(angle)).method_1019(axisForward.method_1021(Math.cos(angle)));

                class_243 spawnPos = anchor
                        .method_1019(radialDir.method_1021(radius))
                        .method_1031(0.0, level.field_9229.method_43058() * 0.1, 0.0);

                double up = upwardSpeed * (0.8 + level.field_9229.method_43058() * 0.4);
                double radial = radialSpeed * (0.8 + level.field_9229.method_43058() * 0.4);
                double swirl = swirlSpeed * 0.02 * (0.8 + level.field_9229.method_43058() * 0.4);
                class_243 velocity = radialDir.method_1021(radial).method_1019(tangentDir.method_1021(swirl)).method_1031(0.0, up, 0.0);

                spawnHeartCluster(level, spawnPos, velocity);
                spawnAccent(level, spawnPos, velocity.method_1021(0.75), phaseProgress);
            }
        }

        private double sampleRadius(class_638 level, double phaseProgress) {
            return switch (shapeMode) {
                case RING -> spreadRadius * (0.85 + level.field_9229.method_43058() * 0.3);
                case SPIRAL ->
                        spreadRadius * class_3532.method_15350(0.15 + phaseProgress * 0.75 + level.field_9229.method_43058() * 0.15, 0.0, 1.2);
                case HALO -> spreadRadius * Math.sqrt(level.field_9229.method_43058());
            };
        }

        private void spawnHeartCluster(class_638 level, class_243 pos, class_243 velocity) {
            int copies = Math.max(0, clusterCopies);
            for (int i = 0; i <= copies; i++) {
                class_243 jitter = randomJitter(level, clusterJitter);
                level.method_8406(
                        class_2398.field_11201,
                        pos.field_1352 + jitter.field_1352,
                        pos.field_1351 + jitter.field_1351,
                        pos.field_1350 + jitter.field_1350,
                        velocity.field_1352,
                        velocity.field_1351,
                        velocity.field_1350
                );
            }
        }

        private void spawnAccent(class_638 level, class_243 pos, class_243 velocity, double phaseProgress) {
            Rgba accentRgba = getAccentRgba(phaseProgress);
            double alphaFactor = accentRgba.alpha01();
            if (!accentEnabled || accentType == ModConfig.ParticleAccentType.NONE || level.field_9229.method_43058() > (accentChance * alphaFactor)) {
                return;
            }

            class_2394 accent = switch (accentType) {
                case GLOW -> class_2398.field_28479;
                case DUST -> new class_2390(accentRgba.toVec3f(), accentRgba.toDustScale());
                case NONE -> null;
            };
            if (accent == null) {
                return;
            }
            level.method_8406(accent, pos.field_1352, pos.field_1351, pos.field_1350, velocity.field_1352 * 0.6, velocity.field_1351 * 0.8, velocity.field_1350 * 0.6);
        }

        private Rgba getAccentRgba(double phaseProgress) {
            if (accentColorMode == ModConfig.ParticleAccentColorMode.SOLID) {
                return solidAccent;
            }
            if (accentColorMode == ModConfig.ParticleAccentColorMode.GRADIENT) {
                return gradientStartAccent.lerp(gradientEndAccent, phaseProgress);
            }
            if (!favorabilityColorAccent) {
                return new Rgba(255, 166, 191, 220);
            }
            return switch (class_3532.method_15340(favorabilityLevel, 0, 3)) {
                case 0 -> new Rgba(255, 191, 214, 210);
                case 1 -> new Rgba(255, 168, 204, 220);
                case 2 -> new Rgba(255, 143, 184, 230);
                default -> new Rgba(255, 108, 160, 240);
            };
        }
    }

    private record Rgba(int r, int g, int b, int a) {
        private Rgba {
            r = class_3532.method_15340(r, 0, 255);
            g = class_3532.method_15340(g, 0, 255);
            b = class_3532.method_15340(b, 0, 255);
            a = class_3532.method_15340(a, 0, 255);
        }

        private Vector3f toVec3f() {
            float alpha = (float) alpha01();
            float boost = 0.65f + 0.35f * alpha;
            return new Vector3f(
                    (r / 255.0f) * boost,
                    (g / 255.0f) * boost,
                    (b / 255.0f) * boost
            );
        }

        private float toDustScale() {
            // Dust supports RGB + size, no direct alpha; map alpha to size for visual "opacity" feeling.
            return 0.65f + (float) alpha01() * 0.55f;
        }

        private double alpha01() {
            return a / 255.0;
        }

        private Rgba lerp(Rgba other, double t) {
            t = class_3532.method_15350(t, 0.0, 1.0);
            int nr = (int) Math.round(class_3532.method_16436(t, r, other.r));
            int ng = (int) Math.round(class_3532.method_16436(t, g, other.g));
            int nb = (int) Math.round(class_3532.method_16436(t, b, other.b));
            int na = (int) Math.round(class_3532.method_16436(t, a, other.a));
            return new Rgba(nr, ng, nb, na);
        }
    }

    private static class_243 getHorizontalForward(class_243 playerEye, class_243 maidEye, class_243 fallbackLook) {
        class_243 axis = maidEye.method_1020(playerEye);
        axis = new class_243(axis.field_1352, 0.0, axis.field_1350);
        if (axis.method_1027() < 1.0E-6) {
            axis = new class_243(fallbackLook.field_1352, 0.0, fallbackLook.field_1350);
        }
        if (axis.method_1027() < 1.0E-6) {
            return new class_243(0.0, 0.0, 1.0);
        }
        return axis.method_1029();
    }

    private static class_243 randomJitter(class_638 level, double maxRadius) {
        if (maxRadius <= 0.0) {
            return class_243.field_1353;
        }
        return new class_243(
                (level.field_9229.method_43058() - 0.5) * 2.0 * maxRadius,
                (level.field_9229.method_43058() - 0.5) * 2.0 * maxRadius,
                (level.field_9229.method_43058() - 0.5) * 2.0 * maxRadius
        );
    }

    private static int[] distributeToBursts(int total, int bursts, ModConfig.ParticlePhaseRamp ramp) {
        int[] result = new int[Math.max(1, bursts)];
        if (total <= 0) {
            return result;
        }

        double[] weights = new double[result.length];
        double sum = 0.0;
        for (int i = 0; i < result.length; i++) {
            double w = ramp == ModConfig.ParticlePhaseRamp.UNIFORM ? 1.0 : (i + 1);
            weights[i] = w;
            sum += w;
        }

        int assigned = 0;
        for (int i = 0; i < result.length; i++) {
            result[i] = (int) Math.floor(total * (weights[i] / sum));
            assigned += result[i];
        }

        int rest = total - assigned;
        for (int i = result.length - 1; i >= 0 && rest > 0; i--) {
            result[i]++;
            rest--;
        }
        return result;
    }
}
