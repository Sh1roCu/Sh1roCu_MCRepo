package com.github.touhoumaidaffection.client;

import com.github.touhoumaidaffection.network.KissCarryRequestMessage;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public class KissKeyInputHandler {
    public static void onClientTick(class_310 client) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1493()) {
            return;
        }

        while (KissKeyMappings.KISS_CARRIED.method_1436()) {
            ClientPlayNetworking.send(KissCarryRequestMessage.ID, KissCarryRequestMessage.DUMMY);
        }
    }
}
