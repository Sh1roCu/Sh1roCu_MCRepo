package com.github.touhoumaidaffection.client;

import com.github.touhoumaidaffection.TouhouMaidAffection;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class KissKeyMappings {
    public static final String CATEGORY = "key.categories." + TouhouMaidAffection.MOD_ID;
    public static final class_304 KISS_CARRIED = new class_304(
            "key." + TouhouMaidAffection.MOD_ID + ".kiss_carried",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_V,
            CATEGORY
    );

    private KissKeyMappings() {
    }
}
