package com.github.touhoumaidaffection.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_4081;

public class MaidsPrayerEffect extends class_1291 {
    public MaidsPrayerEffect() {
        super(class_4081.field_18271, 0xFF69B4);
    }

    @Override
    public void method_5572(class_1309 entity, int amplifier) {
        if (entity.method_6032() < entity.method_6063()) {
            entity.method_6025(1.0F);
        }
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        int interval = 50 >> amplifier;
        return interval <= 0 || duration % interval == 0;
    }
}
