package com.github.touhoumaidaffection.mixin;

import com.github.tartaricacid.touhoulittlemaid.entity.ai.brain.ride.MaidRideBegTask;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MaidRideBegTask.class)
public class MaidRideBegTaskMixin {
    private static final Logger TMA_LOGGER = LoggerFactory.getLogger("touhou_maid_affection/mixin");
    private static final double BEG_RANGE = 6.0D;

    @Inject(method = "checkExtraStartConditions", at = @At("RETURN"), cancellable = true, remap = false)
    private void onCheckExtraStartConditions(class_3218 level, EntityMaid owner, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue()) {
            return;
        }

        boolean offhandMatched = owner.method_37908().method_8390(class_1657.class, owner.method_5829().method_1014(BEG_RANGE),
                        player -> owner.method_6057(player) && owner.getTemptationItem().method_8093(player.method_6079()))
                .stream()
                .findAny()
                .isPresent();

        if (offhandMatched) {
            TMA_LOGGER.info("Offhand temptation fallback matched for MaidRideBegTask; enabling beg behavior.");
            cir.setReturnValue(true);
        }
    }
}
