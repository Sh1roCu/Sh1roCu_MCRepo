package com.github.touhoumaidaffection.network;

import com.github.touhoumaidaffection.TouhouMaidAffection;
import com.github.touhoumaidaffection.client.KissClientHandler;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_634;

public class KissMaidPayload {
    public static final class_2960 ID = new class_2960(TouhouMaidAffection.MOD_ID, "kiss_maid");

    private final int maidEntityId;
    private final int playerEntityId;
    private final boolean carriedKiss;

    public KissMaidPayload(int maidEntityId, int playerEntityId, boolean carriedKiss) {
        this.maidEntityId = maidEntityId;
        this.playerEntityId = playerEntityId;
        this.carriedKiss = carriedKiss;
    }

    public int maidEntityId() {
        return maidEntityId;
    }

    public int playerEntityId() {
        return playerEntityId;
    }

    public boolean carriedKiss() {
        return carriedKiss;
    }

    public static class_2540 encode(KissMaidPayload message) {
        class_2540 buf = PacketByteBufs.create();
        buf.method_10804(message.maidEntityId);
        buf.method_10804(message.playerEntityId);
        buf.writeBoolean(message.carriedKiss);
        return buf;
    }

    public static KissMaidPayload decode(class_2540 buf) {
        return new KissMaidPayload(buf.method_10816(), buf.method_10816(), buf.readBoolean());
    }

    @Environment(EnvType.CLIENT)
    public static void handle(class_310 client, class_634 handler, class_2540 buf, PacketSender responseSender) {
        var message = decode(buf);
        client.execute(() -> KissClientHandler.handle(message));
    }
}
