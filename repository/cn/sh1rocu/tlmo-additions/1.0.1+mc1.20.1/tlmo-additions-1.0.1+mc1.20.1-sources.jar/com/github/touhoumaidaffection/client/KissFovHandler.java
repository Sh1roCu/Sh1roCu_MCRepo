package com.github.touhoumaidaffection.client;

import com.github.touhoumaidaffection.ModConfig;
import io.github.fabricators_of_create.porting_lib.event.client.CameraSetupCallback;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_742;

@Environment(EnvType.CLIENT)
public class KissFovHandler {

    private static long zoomStartTime = -1;
    private static int zoomInTicks;
    private static int holdTicks;
    private static int zoomOutTicks;
    private static float zoomStrength;

    // Camera angle forcing
    private static int targetMaidId = -1;
    private static float startYaw;
    private static float startPitch;
    private static float targetYaw;
    private static float targetPitch;
    private static boolean carriedKiss;

    /**
     * Trigger a zero-distance FOV zoom + camera snap to maid's face.
     */
    public static void trigger(int maidEntityId, boolean isCarriedKiss) {
        zoomStartTime = System.currentTimeMillis();
        zoomInTicks = ModConfig.FOV_ZOOM_IN_TICKS.get();
        holdTicks = ModConfig.FOV_HOLD_TICKS.get();
        zoomOutTicks = ModConfig.FOV_ZOOM_OUT_TICKS.get();
        zoomStrength = ModConfig.FOV_ZOOM_STRENGTH.get().floatValue();
        targetMaidId = maidEntityId;
        carriedKiss = isCarriedKiss;

        // Capture current camera angles and calculate target
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && mc.field_1687 != null) {
            startYaw = mc.field_1724.method_36454();
            startPitch = mc.field_1724.method_36455();

            class_1297 maid = mc.field_1687.method_8469(maidEntityId);
            if (maid != null) {
                class_243 eyePos = mc.field_1724.method_33571();
                class_243 targetPos = getTargetPositionForMode(mc, maid);
                class_243 diff = targetPos.method_1020(eyePos);
                double dist = diff.method_37267();
                targetYaw = (float) (class_3532.method_15349(diff.field_1350, diff.field_1352) * class_3532.field_29848) - 90.0F;
                targetPitch = (float) -(class_3532.method_15349(diff.field_1351, dist) * class_3532.field_29848);
            } else {
                targetYaw = startYaw;
                targetPitch = startPitch;
            }
        }
    }

    /**
     * Calculate the current animation progress factor (0 to 1 to 0).
     * Returns -1 if animation is not active.
     */
    private static float getAnimFactor() {
        if (zoomStartTime < 0) {
            return -1f;
        }

        long elapsed = System.currentTimeMillis() - zoomStartTime;
        float inMs = zoomInTicks * 50f;
        float holdMs = holdTicks * 50f;
        float outMs = zoomOutTicks * 50f;

        if (elapsed > inMs + holdMs + outMs) {
            zoomStartTime = -1;
            targetMaidId = -1;
            carriedKiss = false;
            return -1f;
        }

        if (elapsed < inMs) {
            return smoothstep(elapsed / inMs);
        } else if (elapsed < inMs + holdMs) {
            return 1.0f;
        } else {
            return 1.0f - smoothstep((elapsed - inMs - holdMs) / outMs);
        }
    }

    public static float onComputeFovModifier(class_742 player, float fov) {
        float factor = getAnimFactor();
        if (factor < 0) {
            return fov;
        }

        float modifier = 1.0f - zoomStrength * factor;
        return fov * modifier;
    }

    public static boolean onCameraAngles(CameraSetupCallback.CameraInfo info) {
        float factor = getAnimFactor();
        if (factor < 0 || targetMaidId < 0) {
            return false;
        }

        // Smoothly interpolate camera angles toward the maid's face
        float lerpedYaw = class_3532.method_17821(factor, startYaw, targetYaw);
        float lerpedPitch = class_3532.method_16439(factor, startPitch, targetPitch);

        info.yaw = lerpedYaw;
        info.pitch = lerpedPitch;
        return false;
    }

    private static float smoothstep(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return t * t * (3f - 2f * t);
    }

    private static class_243 getTargetPositionForMode(class_310 mc, class_1297 maid) {
        class_243 maidEye = maid.method_33571();
        if (!carriedKiss || mc.field_1724 == null) {
            return maidEye;
        }

        class_243 forward = class_243.method_1030(0.0F, mc.field_1724.method_36454()).method_1029();
        class_243 right = new class_243(-forward.field_1350, 0.0, forward.field_1352);

        double sideOffset = ModConfig.CARRIED_SIDE_OFFSET.get();
        double forwardOffset = ModConfig.CARRIED_FORWARD_OFFSET.get();
        double verticalOffset = ModConfig.CARRIED_VERTICAL_OFFSET.get();

        return maidEye
                .method_1019(right.method_1021(sideOffset))
                .method_1019(forward.method_1021(forwardOffset))
                .method_1031(0.0, verticalOffset, 0.0);
    }
}
