package com.github.touhoumaidaffection.handler;

import cn.sh1rocu.tlmo_additions.api.event.PlayerLoggedOutEvent;
import com.github.tartaricacid.touhoulittlemaid.api.event.InteractMaidEvent;
import com.github.tartaricacid.touhoulittlemaid.entity.favorability.Type;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.network.NetworkHandler;
import com.github.touhoumaidaffection.ModConfig;
import com.github.touhoumaidaffection.ModEffects;
import com.github.touhoumaidaffection.ModSounds;
import com.github.touhoumaidaffection.TouhouMaidAffection;
import com.github.touhoumaidaffection.network.KissMaidPayload;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3419;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class KissMaidHandler {

    private static final Map<MinecraftServer, SessionState> SESSION = new IdentityHashMap<>();

    private static Boolean carryOnLoaded = null;

    private static final class SessionState {
        private final Map<UUID, Long> cooldowns = new HashMap<>();
        private final Map<UUID, List<Long>> kissTimestamps = new HashMap<>();
    }

    private static boolean isCarryOnLoaded() {
        if (carryOnLoaded == null) {
            carryOnLoaded = FabricLoader.getInstance().isModLoaded("carryon");
        }
        return carryOnLoaded;
    }

    private static long getCooldownForLevel(int level) {
        return switch (level) {
            case 1 -> ModConfig.COOLDOWN_LEVEL_1.get();
            case 2 -> ModConfig.COOLDOWN_LEVEL_2.get();
            case 3 -> ModConfig.COOLDOWN_LEVEL_3.get();
            default -> ModConfig.COOLDOWN_LEVEL_0.get();
        };
    }

    public static void onInteractMaid(InteractMaidEvent event) {
        class_1657 player = event.getPlayer();
        EntityMaid maid = event.getMaid();

        // Only trigger when sneaking with empty main hand
        if (!player.method_5715() || !event.getStack().method_7960()) {
            return;
        }

        // CarryOn compatibility: when CarryOn is loaded, it uses sneak + both hands empty
        // to pick up entities. Only trigger kiss when offhand is NOT empty to avoid conflict.
        if (isCarryOnLoaded() && player.method_6079().method_7960()) {
            return;
        }

        // Only on server side
        if (player.method_37908().field_9236) {
            event.setCanceled(true);
            return;
        }

        // Cancel to prevent opening the maid GUI
        event.setCanceled(true);

        executeKiss(player, maid);
    }

    public static void tryKissCarriedMaid(class_1657 player) {
        if (player == null || player.method_37908().field_9236) {
            return;
        }

        for (class_1297 passenger : player.method_5685()) {
            if (passenger instanceof EntityMaid maid) {
                executeKiss(player, maid, true);
                return;
            }
        }
    }

    public static void executeKiss(class_1657 player, EntityMaid maid) {
        executeKiss(player, maid, false);
    }

    private static void executeKiss(class_1657 player, EntityMaid maid, boolean carriedKiss) {
        MinecraftServer server = player.method_5682();
        if (server == null) {
            return;
        }

        SessionState session = SESSION.computeIfAbsent(server, s -> new SessionState());
        UUID playerId = player.method_5667();

        // Tiered cooldown check based on maid's favorability level
        long currentTick = server.method_3780();
        int favLevel = maid.getFavorabilityManager().getLevel();
        long cooldown = getCooldownForLevel(favLevel);

        Long lastKiss = session.cooldowns.get(playerId);
        if (lastKiss != null) {
            long delta = currentTick - lastKiss;
            if (delta < 0) {
                session.cooldowns.remove(playerId);
                session.kissTimestamps.remove(playerId);
                TouhouMaidAffection.LOGGER.debug("Detected negative kiss cooldown delta, resetting state for player {}", playerId);
            } else if (cooldown > 0 && delta < cooldown) {
                return;
            }
        }

        // Record cooldown
        session.cooldowns.put(playerId, currentTick);

        // Apply favorability (dynamic Type with configured values)
        int favPoints = ModConfig.FAVORABILITY_POINTS.get();
        int favCooldown = ModConfig.FAVORABILITY_COOLDOWN.get();
        Type kissType = new Type("Kiss", favPoints, favCooldown);
        maid.getFavorabilityManager().apply(kissType);

        // Make the maid look at the player
        maid.method_5988().method_6226(player, 30.0F, 30.0F);

        // Play kiss sound at the midpoint between player and maid
        double midX = (player.method_23317() + maid.method_23317()) / 2.0;
        double midY = (player.method_23320() + maid.method_23320()) / 2.0;
        double midZ = (player.method_23321() + maid.method_23321()) / 2.0;
        player.method_37908().method_43128(null, midX, midY, midZ,
                ModSounds.KISS, class_3419.field_15248,
                1.0F, 1.0F);

        // Broadcast particle packet to all tracking clients
        KissMaidPayload payload = new KissMaidPayload(maid.method_5628(), player.method_5628(), carriedKiss);
        NetworkHandler.sendToTrackingEntity(maid, KissMaidPayload.ID, KissMaidPayload.encode(payload));
        // Buff system: track kiss timestamps and check threshold
        if (ModConfig.BUFF_ENABLED.get()) {
            handleBuffTrigger(session, player, maid, currentTick, favLevel);
        }
    }

    private static int getAmplifierForLevel(int level) {
        return switch (level) {
            case 1 -> ModConfig.BUFF_AMPLIFIER_LEVEL_1.get();
            case 2 -> ModConfig.BUFF_AMPLIFIER_LEVEL_2.get();
            case 3 -> ModConfig.BUFF_AMPLIFIER_LEVEL_3.get();
            default -> ModConfig.BUFF_AMPLIFIER_LEVEL_0.get();
        };
    }

    private static void handleBuffTrigger(SessionState session, class_1657 player, EntityMaid maid, long currentTick, int favLevel) {
        UUID playerId = player.method_5667();
        int threshold = ModConfig.BUFF_KISS_THRESHOLD.get();
        long window = ModConfig.BUFF_KISS_WINDOW.get();

        List<Long> timestamps = session.kissTimestamps.computeIfAbsent(playerId, k -> new ArrayList<>());
        timestamps.add(currentTick);

        // Remove timestamps outside the window
        timestamps.removeIf(t -> (currentTick - t) > window);

        if (timestamps.size() >= threshold) {
            // Clear timestamps to reset counter
            timestamps.clear();

            int duration = ModConfig.BUFF_DURATION.get();
            int amplifier = getAmplifierForLevel(favLevel);

            // Apply Maid's Prayer (custom effect with built-in regeneration) to both
            player.method_6092(new class_1293(
                    ModEffects.MAIDS_PRAYER, duration, amplifier, false, true, true));
            maid.method_6092(new class_1293(
                    ModEffects.MAIDS_PRAYER, duration, amplifier, false, true, true));
        }
    }

    public static void onPlayerLoggedOut(PlayerLoggedOutEvent event) {
        MinecraftServer server = event.getEntity().method_5682();
        if (server == null) {
            return;
        }

        SessionState session = SESSION.get(server);
        if (session == null) {
            return;
        }

        UUID playerId = event.getEntity().method_5667();
        session.cooldowns.remove(playerId);
        session.kissTimestamps.remove(playerId);
    }

    public static void onServerStopped(MinecraftServer server) {
        SESSION.remove(server);
    }
}
