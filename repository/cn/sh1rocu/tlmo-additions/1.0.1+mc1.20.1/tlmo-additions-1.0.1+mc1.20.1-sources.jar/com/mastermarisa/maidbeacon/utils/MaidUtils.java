package com.mastermarisa.maidbeacon.utils;

import cn.sh1rocu.touhoulittlemaid.util.itemhandler.IItemHandler;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.inventory.handler.BaubleItemHandler;
import com.mastermarisa.maidbeacon.init.ModItems;
import com.mastermarisa.maidbeacon.item.bauble.BeaconEffectGeneratorBauble;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;

public class MaidUtils {
    public static class_1799 getEquippedMobileBeacon(EntityMaid maid) {
        BaubleItemHandler handler = maid.getMaidBauble();
        for (int i = 0; i < handler.getSlots(); i++) {
            if (handler.getBaubleInSlot(i) instanceof BeaconEffectGeneratorBauble)
                return handler.getStackInSlot(i);
        }

        return class_1799.field_8037;
    }

    public static boolean mobileBeaconEquipped(EntityMaid maid) {
        return maid.getMaidBauble().containsItem(ModItems.MOBILE_BEACON);
    }

    public static List<class_1799> tryExtract(IItemHandler handler, int count, StackPredicate filter, boolean strict) {
        List<Integer> slots = findStackSlots(handler, filter);
        List<class_1799> stacks = new ArrayList<>();
        int c = count(handler, filter);
        if (!strict || c >= count) {
            c = 0;
            for (int i : slots) {
                if (c >= count) break;
                class_1799 stack = handler.getStackInSlot(i);
                if (count - c >= stack.method_7947()) {
                    c += stack.method_7947();
                    stacks.add(handler.extractItem(i, stack.method_7947(), false));
                } else {
                    stacks.add(handler.extractItem(i, count - c, false));
                    c = count;
                }
            }
            return stacks;
        }

        return new ArrayList<>();
    }

    public static List<Integer> findStackSlots(IItemHandler handler, StackPredicate filter) {
        IntList slots = new IntArrayList();

        for (int i = 0; i < handler.getSlots(); ++i) {
            class_1799 stack = handler.getStackInSlot(i);
            if (filter.test(stack)) {
                slots.add(i);
            }
        }

        return slots;
    }

    public static int count(IItemHandler handler, StackPredicate predicate) {
        int count = 0;
        for (int i = 0; i < handler.getSlots(); i++) {
            class_1799 stack = handler.getStackInSlot(i);
            if (predicate.test(stack)) count += stack.method_7947();
        }

        return count;
    }
}
