package com.mastermarisa.maidbeacon.client.render;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.awt.*;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_811;

public class BeaconRenderHelper {
    public static final class_2960 BEAM_LOCATION = new class_2960("minecraft", "textures/entity/beacon_beam.png");

    public static void renderBeaconBeam(class_4587 poseStack, class_4597 bufferSource, float partialTick, float textureScale, long gameTime, int yOffset, int height, Color color, float beamRadius, float glowRadius, EntityMaid maid) {
        BeaconRenderHelper.renderBeaconBeam(poseStack, bufferSource, BEAM_LOCATION, partialTick, textureScale, gameTime, yOffset, height, color.getRGBColorComponents(new float[3]), beamRadius, glowRadius, maid);
    }

    private static void renderBeaconBeam(class_4587 poseStack, class_4597 bufferSource, class_2960 location, float partialTick, float textureScale, long gameTime, int yOffset, int height, float[] colors, float beamRadius, float glowRadius, EntityMaid maid) {
        int i = yOffset + height;
        poseStack.method_22903();
        double offset = -0.72;
        if (maid.isMaidInSittingPose()) {
            offset -= 0.6;
        }
        poseStack.method_22904(0.0, offset, 0.0);
        float f = Math.floorMod(gameTime, 40) + partialTick;
        float f1 = height < 0 ? f : -f;
        float f2 = class_3532.method_22450(f1 * 0.2f - class_3532.method_15375(f1 * 0.1f));
        float f3 = colors[0];
        float f4 = colors[1];
        float f5 = colors[2];
        poseStack.method_22903();
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(f * 2.25f - 45.0f));
        float f9 = -beamRadius;
        float f12 = -beamRadius;
        float f15 = -1.0f + f2;
        float f16 = height * textureScale * (0.5f / beamRadius) + f15;
        BeaconRenderHelper.renderPart(poseStack, bufferSource.getBuffer(class_1921.method_23592(location, false)), f3, f4, f5, 1.0f, yOffset, i, 0.0f, beamRadius, beamRadius, 0.0f, f9, 0.0f, 0.0f, f12, 0.0f, 1.0f, f16, f15);
        poseStack.method_22909();
        float f6 = -glowRadius;
        float f7 = -glowRadius;
        float f8 = -glowRadius;
        f9 = -glowRadius;
        f15 = -1.0f + f2;
        f16 = height * textureScale + f15;
        BeaconRenderHelper.renderPart(poseStack, bufferSource.getBuffer(class_1921.method_23592(location, true)), f3, f4, f5, 0.125f, yOffset, i, f6, f7, glowRadius, f8, f9, glowRadius, glowRadius, glowRadius, 0.0f, 1.0f, f16, f15);
        poseStack.method_22909();
    }

    private static void renderPart(class_4587 poseStack, class_4588 consumer, float red, float green, float blue, float alpha, int minY, int maxY, float x0, float z0, float x1, float z1, float x2, float z2, float x3, float z3, float minU, float maxU, float minV, float maxV) {
        class_4587.class_4665 pose = poseStack.method_23760();
        Matrix4f matrix4f = pose.method_23761();
        Matrix3f matrix3f = pose.method_23762();
        renderQuad(matrix4f, matrix3f, consumer, red, green, blue, alpha, minY, maxY, x0, z0, x1, z1, minU, maxU, minV, maxV);
        renderQuad(matrix4f, matrix3f, consumer, red, green, blue, alpha, minY, maxY, x3, z3, x2, z2, minU, maxU, minV, maxV);
        renderQuad(matrix4f, matrix3f, consumer, red, green, blue, alpha, minY, maxY, x1, z1, x3, z3, minU, maxU, minV, maxV);
        renderQuad(matrix4f, matrix3f, consumer, red, green, blue, alpha, minY, maxY, x2, z2, x0, z0, minU, maxU, minV, maxV);
    }

    private static void renderQuad(Matrix4f pose, Matrix3f normal, class_4588 consumer, float red, float green, float blue, float alpha, int minY, int maxY, float minX, float minZ, float maxX, float maxZ, float minU, float maxU, float minV, float maxV) {
        addVertex(pose, normal, consumer, red, green, blue, alpha, maxY, minX, minZ, maxU, minV);
        addVertex(pose, normal, consumer, red, green, blue, alpha, minY, minX, minZ, maxU, maxV);
        addVertex(pose, normal, consumer, red, green, blue, alpha, minY, maxX, maxZ, minU, maxV);
        addVertex(pose, normal, consumer, red, green, blue, alpha, maxY, maxX, maxZ, minU, minV);
    }

    private static void addVertex(Matrix4f pose, Matrix3f normal, class_4588 consumer, float red, float green, float blue, float alpha, int y, float x, float z, float u, float v) {
        consumer.method_22918(pose, x, (float) y, z).method_22915(red, green, blue, alpha).method_22913(u, v).method_22922(class_4608.field_21444).method_22916(0xF000F0).method_23763(normal, 0.0F, 1.0F, 0.0F).method_1344();
    }

    public static void renderBeaconModel(class_4587 poseStack, class_4597 bufferSource, int packedLight, EntityMaid entity, float partialTick) {
        poseStack.method_22903();
        poseStack.method_22904(0.0, entity.method_17682() + (entity.isMaidInSittingPose() ? -0.1 : 0.4) - 1.0, 0.0);
        long gameTime = entity.method_37908().method_8510();
        float rotation = (gameTime + partialTick) * 3.0f;
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(rotation));
        poseStack.method_22905(1.0f, 1.0f, 1.0f);
        class_310.method_1551().method_1480().method_23178(new class_1799(class_1802.field_8668), class_811.field_4318, packedLight, class_4608.field_21444, poseStack, bufferSource, entity.method_37908(), entity.method_5628());
        poseStack.method_22909();
    }
}
