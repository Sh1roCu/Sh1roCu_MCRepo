package com.mastermarisa.maidbeacon.utils;

import java.util.function.Predicate;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_6862;

public class StackPredicate {
    private final Predicate<class_1799> predicate;

    public StackPredicate(Predicate<class_1799> predicate) {
        this.predicate = predicate;
    }

    public StackPredicate(class_1792 item) {
        this.predicate = (stack) -> stack.method_31574(item);
    }

    public StackPredicate(class_1799 itemStack) {
        this.predicate = (stack) -> class_1799.method_31577(stack, itemStack);
    }

    public StackPredicate(class_1856 ingredient) {
        this.predicate = ingredient;
    }

    public StackPredicate(class_6862<class_1792> key) {
        this.predicate = (s) -> s.method_31573(key);
    }

    public static StackPredicate of(Predicate<class_1799> predicate) {
        return new StackPredicate(predicate);
    }

    public static StackPredicate of(class_1792 item) {
        return new StackPredicate(item);
    }

    public static StackPredicate of(class_1799 itemStack) {
        return new StackPredicate(itemStack);
    }

    public static StackPredicate of(class_1856 ingredient) {
        return new StackPredicate(ingredient);
    }

    public static StackPredicate of(class_6862<class_1792> key) {
        return new StackPredicate(key);
    }

    public StackPredicate copy() {
        return new StackPredicate(predicate);
    }

    public boolean test(class_1799 stack) {
        return predicate.test(stack);
    }
}
