package com.mastermarisa.maidbeacon.client.gui.screen.beacon;

import com.mastermarisa.maidbeacon.client.gui.base.UIContainerHorizontal;
import com.mastermarisa.maidbeacon.client.gui.base.UIContainerVertical;
import com.mastermarisa.maidbeacon.client.gui.base.UIElement;
import com.mastermarisa.maidbeacon.client.gui.screen.beacon.elements.UIEffectButton;
import com.mastermarisa.maidbeacon.client.gui.screen.beacon.elements.UIUpgradeButton;
import com.mastermarisa.maidbeacon.config.Config;
import com.mastermarisa.maidbeacon.data.MobileBeaconData;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;
import javax.annotation.ParametersAreNonnullByDefault;
import java.util.ArrayList;
import java.util.List;


@ParametersAreNonnullByDefault
@Environment(EnvType.CLIENT)
public class BeaconScreen extends class_437 {
    private static final class_310 mc;
    private static final class_327 font;

    private final class_1657 player;
    private final class_1268 hand;
    private final class_1799 itemStack;
    private double YOffset;

    private List<List<UIElement>> lines;
    private UIContainerVertical container;

    private BeaconScreen(class_1657 player, class_1268 hand, class_1799 itemStack) {
        super(class_2561.method_43473());
        this.player = player;
        this.hand = hand;
        this.itemStack = itemStack;
        initUI();
    }

    public static void open(class_1657 player, class_1268 hand, class_1799 itemStack) {
        class_310.method_1551().method_1507(new BeaconScreen(player, hand, itemStack));
    }

    public void initUI() {
        MobileBeaconData mobileBeaconData = MobileBeaconData.getOrDefault(itemStack);
        lines = new ArrayList<>();
        List<UIElement> parts = new ArrayList<>();
        lines.add(List.of(new UIUpgradeButton(-1, player, hand, this)));
        parts.add(UIContainerHorizontal.wrap(lines.get(lines.size() - 1), 16, 0, UIContainerHorizontal.ElementAlignment.CENTER));
        for (int i = 0; i < Math.min(mobileBeaconData.getLevel(), Config.MAX_LEVEL()) + 1; i++) {
            List<UIElement> elements = new ArrayList<>();
            for (var aura : Config.BY_LEVEL(i)) {
                elements.add(new UIEffectButton(
                        mobileBeaconData,
                        aura,
                        player.method_5667(),
                        hand
                ));
            }
            lines.add(elements);
            parts.add(UIContainerHorizontal.wrap(elements, 16, 0, UIContainerHorizontal.ElementAlignment.CENTER));
            if (i < Config.ITEMSTACK_TO_UPGRADE_BEACON_LEVEL().size()) {
                lines.add(List.of(new UIUpgradeButton(i, player, hand, this)));
                parts.add(UIContainerHorizontal.wrap(lines.get(lines.size() - 1), 16, 0, UIContainerHorizontal.ElementAlignment.CENTER));
            }
        }
        container = UIContainerVertical.wrap(parts, 16, 0, UIContainerVertical.ElementAlignment.UP);
        resize();
        container.order();
    }

    @Override
    public void method_25393() {
        super.method_25393();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        UIElement.render(graphics, container, mouseX, mouseY);
        UIElement.renderToolTip(graphics, container, mouseX, mouseY);
    }

    @Override
    public void method_25410(class_310 minecraft, int width, int height) {
        super.method_25410(minecraft, width, height);
        resize();
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        UIElement.onMouseClicked(container, mouseX, mouseY, button);
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollY) {
        if (scrollY != 0.0) {
            this.YOffset += scrollY * 10.0;
            if (this.YOffset > 0.0) {
                this.YOffset = 0.0;
            }
            this.resize();
        }
        return super.method_25401(mouseX, mouseY, scrollY);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private void resize() {
        container.setCenterX(getScreenCenterX());
        container.setMinY((int) (50 + YOffset));
    }

    public boolean stillValid() {
        return player.method_5998(hand).equals(itemStack);
    }

    public static int getScreenCenterX() {
        return mc.method_22683().method_4486() / 2;
    }

    public static int getScreenCenterY() {
        return mc.method_22683().method_4502() / 2;
    }

    public static void close() {
        mc.method_1507(null);
    }

    static {
        mc = class_310.method_1551();
        field_22793 = mc.field_1772;
    }
}
