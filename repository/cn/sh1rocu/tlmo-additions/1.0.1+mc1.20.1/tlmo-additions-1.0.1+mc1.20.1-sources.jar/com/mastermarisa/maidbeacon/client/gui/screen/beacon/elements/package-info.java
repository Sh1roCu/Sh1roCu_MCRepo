@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.mastermarisa.maidbeacon.client.gui.screen.beacon.elements;

import javax.annotation.ParametersAreNonnullByDefault;