package com.mastermarisa.maidbeacon.network.message;

import com.mastermarisa.maidbeacon.MaidBeacon;
import com.mastermarisa.maidbeacon.config.Config;
import com.mastermarisa.maidbeacon.data.MobileBeaconData;
import com.mastermarisa.maidbeacon.init.ModItems;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

public record OperateEffectMessage(int actionCode, int index, int hand, UUID uuid) {
    public static final class_2960 ID = MaidBeacon.resourceLocation("change_aura_state");

    public static class_2540 encode(OperateEffectMessage message) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeInt(message.actionCode);
        buf.writeInt(message.index);
        buf.writeInt(message.hand);
        buf.method_10797(message.uuid);
        return buf;
    }

    public static OperateEffectMessage decode(class_2540 buf) {
        return new OperateEffectMessage(buf.readInt(), buf.readInt(), buf.readInt(), buf.method_10790());
    }

    public static void handle(MinecraftServer server, class_3222 player, class_3244 handler, class_2540 buf, PacketSender responseSender) {
        var message = decode(buf);
        server.execute(() -> {
            if (player == null) {
                return;
            }
            class_3218 level = player.method_51469();
            if (level.method_18470(message.uuid()) instanceof class_3222 serverPlayer) {
                class_1799 itemInHand = serverPlayer.method_5998(message.hand == 0 ? class_1268.field_5808 : class_1268.field_5810);
                if (itemInHand.method_31574(ModItems.MOBILE_BEACON)) {
                    MobileBeaconData mobileBeaconData = MobileBeaconData.getOrDefault(itemInHand);
                    switch (message.actionCode) {
                        case 0 -> {
                            mobileBeaconData.activated.remove(message.index());
                        }
                        case 1 -> {
                            if (mobileBeaconData.getUsedCost() + Config.EFFECT_AURAS().get(message.index).cost <= Config.getCost(mobileBeaconData.getLevel())) {
                                mobileBeaconData.activated.add(message.index());
                            }
                        }
                    }
                    MobileBeaconData.setData(itemInHand, mobileBeaconData);
                }
            }
        });
    }
}