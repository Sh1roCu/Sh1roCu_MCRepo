package com.mastermarisa.maidbeacon.client.gui.screen.rendering;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mastermarisa.maidbeacon.client.gui.base.UIContainerHorizontal;
import com.mastermarisa.maidbeacon.client.gui.base.UIContainerVertical;
import com.mastermarisa.maidbeacon.client.gui.base.UIElement;
import com.mastermarisa.maidbeacon.client.gui.screen.rendering.elements.ModifyValueButton;
import com.mastermarisa.maidbeacon.client.gui.screen.rendering.elements.ValueLine;
import com.mastermarisa.maidbeacon.data.ExtraRenderSettings;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class RenderSettingsScreen extends class_437 {
    private static final class_310 mc;
    private static final class_327 field_22793;
    private final List<ModifyValueButton> buttons;
    public final ExtraRenderSettings settings;
    public final EntityMaid maid;
    public UIContainerVertical container;

    public RenderSettingsScreen(EntityMaid maid) {
        super(class_2561.method_43473());
        this.maid = maid;
        this.settings = ExtraRenderSettings.getOrCreate(maid);
        this.buttons = new ArrayList<>();
        initUI();
    }

    public static void open(EntityMaid maid) {
        mc.method_1507(new RenderSettingsScreen(maid));
    }

    private void initUI() {
        List<UIElement> lines = new ArrayList<>();
        for (var pair : settings.getDisplayPairs()) {
            lines.add(new ValueLine(pair.first(), pair.second()));
        }
        buttons.add(new ModifyValueButton(
                new Rectangle(30, 20),
                (extra) -> {
                    extra.enableRendering = !extra.enableRendering;
                },
                this
        ));
        buttons.add(new ModifyValueButton(
                new Rectangle(30, 20),
                (extra) -> {
                    extra.enableBeaconBeam = !extra.enableBeaconBeam;
                },
                this
        ));
        buttons.add(new ModifyValueButton(
                new Rectangle(30, 20),
                (extra) -> {
                    extra.enableBeaconModel = !extra.enableBeaconModel;
                },
                this
        ));
        buttons.add(new ModifyValueButton(
                new Rectangle(30, 20),
                (extra) -> {
                    extra.enableHeadHalo = !extra.enableHeadHalo;
                },
                this
        ));
        buttons.add(new ModifyValueButton(
                new Rectangle(30, 20),
                (extra) -> {
                    extra.enableSkyHalo = !extra.enableSkyHalo;
                },
                this
        ));
        buttons.add(new ModifyValueButton(
                new Rectangle(30, 20),
                (extra) -> {

                },
                this
        ));
        buttons.add(new ModifyValueButton(
                new Rectangle(30, 20),
                (extra) -> {

                },
                this
        ));

        List<UIElement> parts = new ArrayList<>();
        for (int i = 0; i < buttons.size(); i++) {
            parts.add(UIContainerHorizontal.wrap(List.of(lines.get(i), buttons.get(i)), 0, 0, UIContainerHorizontal.ElementAlignment.LEFT));
        }
        container = UIContainerVertical.wrap(parts, 10, 0, UIContainerVertical.ElementAlignment.UP);
        resize();
    }

    public void refresh() {
        List<UIElement> lines = new ArrayList<>();
        for (var pair : settings.getDisplayPairs()) {
            lines.add(new ValueLine(pair.first(), pair.second()));
        }
        List<UIElement> parts = new ArrayList<>();
        for (int i = 0; i < buttons.size(); i++) {
            parts.add(UIContainerHorizontal.wrap(List.of(lines.get(i), buttons.get(i)), 0, 0, UIContainerHorizontal.ElementAlignment.LEFT));
        }
        container = UIContainerVertical.wrap(parts, 10, 0, UIContainerVertical.ElementAlignment.UP);
        resize();
    }

    @Override
    public void method_25393() {
        super.method_25393();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        UIElement.render(graphics, container, mouseX, mouseY);
    }

    @Override
    public void method_25410(class_310 minecraft, int width, int height) {
        super.method_25410(minecraft, width, height);
        resize();
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        UIElement.onMouseClicked(container, mouseX, mouseY, button);
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollY) {
        return super.method_25401(mouseX, mouseY, scrollY);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private void resize() {
        container.setCenterX(getScreenCenterX());
        container.setMinY(20);
    }

    public boolean stillValid() {
        return true;
    }

    public static int getScreenCenterX() {
        return mc.method_22683().method_4486() / 2;
    }

    public static int getScreenCenterY() {
        return mc.method_22683().method_4502() / 2;
    }

    public static void close() {
        mc.method_1507(null);
    }

    static {
        mc = class_310.method_1551();
        field_22793 = mc.field_1772;
    }
}
