package com.mastermarisa.maidbeacon.data;

import com.github.tartaricacid.touhoulittlemaid.api.entity.data.TaskDataKey;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mastermarisa.maidbeacon.MaidBeacon;
import com.mastermarisa.maidbeacon.init.ModTaskDataKeys;
import it.unimi.dsi.fastutil.Pair;
import java.util.List;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public class ExtraRenderSettings {
    public boolean enableRendering = true;
    public boolean enableBeaconBeam = true;
    public boolean enableBeaconModel = true;
    public boolean enableHeadHalo = false;
    public boolean enableSkyHalo = true;
    public byte headHaloStyle = 0;
    public byte skyHaloStyle = 0;

    public class_2487 serializeNBT() {
        class_2487 tag = new class_2487();
        tag.method_10556("enable_rendering", this.enableRendering);
        tag.method_10556("enable_beacon_beam", this.enableBeaconBeam);
        tag.method_10556("enable_beacon_model", this.enableBeaconModel);
        tag.method_10556("enable_head_halo", this.enableHeadHalo);
        tag.method_10556("enable_sky_halo", this.enableSkyHalo);
        tag.method_10567("head_halo_style", this.headHaloStyle);
        tag.method_10567("sky_halo_style", this.skyHaloStyle);
        return tag;
    }

    public void deserializeNBT(class_2487 tag) {
        if (tag.method_10545("enable_rendering")) {
            this.enableRendering = tag.method_10577("enable_rendering");
            this.enableBeaconBeam = tag.method_10577("enable_beacon_beam");
            this.enableBeaconModel = tag.method_10577("enable_beacon_model");
            this.enableHeadHalo = tag.method_10577("enable_head_halo");
            this.enableSkyHalo = tag.method_10577("enable_sky_halo");
            this.headHaloStyle = tag.method_10571("head_halo_style");
            this.skyHaloStyle = tag.method_10571("sky_halo_style");
        }
    }

    public List<Pair<String, String>> getDisplayPairs() {
        return List.of(
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.enable_rendering").getString(), String.valueOf(enableRendering)),
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.enable_beacon_beam").getString(), String.valueOf(enableBeaconBeam)),
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.enable_beacon_model").getString(), String.valueOf(enableBeaconModel)),
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.enable_head_halo").getString(), String.valueOf(enableHeadHalo)),
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.enable_sky_halo").getString(), String.valueOf(enableSkyHalo)),
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.head_halo_style").getString(), String.valueOf(headHaloStyle)),
                Pair.of(class_2561.method_43471("gui.maidbeacon.render_setting.sky_halo_style").getString(), String.valueOf(skyHaloStyle))
        );
    }

    public static ExtraRenderSettings getOrCreate(EntityMaid maid) {
        ExtraRenderSettings settings = maid.getData(ModTaskDataKeys.EXTRA_RENDER_SETTINGS);
        if (settings == null) {
            settings = new ExtraRenderSettings();
            maid.setAndSyncData(ModTaskDataKeys.EXTRA_RENDER_SETTINGS, settings);
        }
        return settings;
    }

    public static class DATA_KEY implements TaskDataKey<ExtraRenderSettings> {
        private static final class_2960 KEY = MaidBeacon.resourceLocation("extra_render_settings");

        @Override
        public class_2960 getKey() {
            return KEY;
        }

        @Override
        public class_2487 writeSaveData(ExtraRenderSettings extraRenderSettings) {
            return extraRenderSettings.serializeNBT();
        }

        @Override
        public ExtraRenderSettings readSaveData(class_2487 compoundTag) {
            ExtraRenderSettings settings = new ExtraRenderSettings();
            settings.deserializeNBT(compoundTag);
            return settings;
        }
    }
}
