package com.mastermarisa.maidbeacon.init;

import com.mastermarisa.maidbeacon.MaidBeacon;
import com.mastermarisa.maidbeacon.entity.ExtraRenderingEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModEntities {
    public static final class_1299<ExtraRenderingEntity> EXTRA_RENDERING_ENTITY = register("extra_rendering_entity", ExtraRenderingEntity.TYPE);

    private static <T extends class_1297> class_1299<T> register(String name, class_1299<T> type) {
        return class_2378.method_10230(class_7923.field_41177, new class_2960(MaidBeacon.MOD_ID, name), type);
    }

    public static void init() {

    }
}
