package com.mastermarisa.maidbeacon.network.message;

import cn.sh1rocu.tlmo_additions.util.itemhandler.PlayerInvWrapper;
import cn.sh1rocu.touhoulittlemaid.util.itemhandler.IItemHandler;
import com.mastermarisa.maidbeacon.MaidBeacon;
import com.mastermarisa.maidbeacon.config.Config;
import com.mastermarisa.maidbeacon.data.MobileBeaconData;
import com.mastermarisa.maidbeacon.init.ModItems;
import com.mastermarisa.maidbeacon.utils.MaidUtils;
import com.mastermarisa.maidbeacon.utils.StackPredicate;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.UUID;

public record UpgradeBeaconMessage(int index, int hand, UUID uuid) {
    public static final class_2960 ID = MaidBeacon.resourceLocation("upgrade_beacon");

    public static class_2540 encode(UpgradeBeaconMessage message) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeInt(message.index);
        buf.writeInt(message.hand);
        buf.method_10797(message.uuid);
        return buf;
    }

    public static UpgradeBeaconMessage decode(class_2540 buf) {
        return new UpgradeBeaconMessage(buf.readInt(), buf.readInt(), buf.method_10790());
    }

    public static void handle(MinecraftServer server, class_3222 player, class_3244 handler, class_2540 buf, PacketSender responseSender) {
        var message = decode(buf);
        server.execute(() -> {
            if (player == null) {
                return;
            }
            class_3218 level = player.method_51469();
            if (level.method_18470(message.uuid) instanceof class_3222 serverPlayer) {
                class_1799 itemInHand = serverPlayer.method_5998(message.hand == 0 ? class_1268.field_5808 : class_1268.field_5810);
                if (itemInHand.method_31574(ModItems.MOBILE_BEACON)) {
                    MobileBeaconData mobileBeaconData = MobileBeaconData.getOrDefault(itemInHand);
                    if (mobileBeaconData.getLevel() == message.index) {
                        class_1799 required = Config.ITEMSTACK_TO_UPGRADE_BEACON_LEVEL().get(message.index);
                        IItemHandler itemHandler = new PlayerInvWrapper(serverPlayer.field_7514);
                        WeakReference<IItemHandler> ref = new WeakReference<>(itemHandler);
                        List<class_1799> itemStackList = MaidUtils.tryExtract(ref.get(), required.method_7947(), StackPredicate.of(required.method_7909()), true);
                        if (!itemStackList.isEmpty()) {
                            mobileBeaconData.setLevel(mobileBeaconData.getLevel() + 1);
                        }
                        itemHandler = null;
                    }
                    MobileBeaconData.setData(itemInHand, mobileBeaconData);
                }
            }
        });
    }
}
