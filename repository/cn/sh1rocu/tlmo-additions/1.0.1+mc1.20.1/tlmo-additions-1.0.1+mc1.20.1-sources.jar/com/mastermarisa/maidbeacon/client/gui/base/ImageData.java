package com.mastermarisa.maidbeacon.client.gui.base;

import java.awt.*;
import net.minecraft.class_2960;

public final class ImageData {
    public final class_2960 textureLocation;
    public final Rectangle partOfTexture;
    public int visualWidth;
    public int visualHeight;
    public int textureWidth;
    public int textureHeight;

    public ImageData(class_2960 textureLocation, Rectangle partOfTexture, int visualWidth, int visualHeight, int textureWidth, int textureHeight) {
        this.textureLocation = textureLocation;
        this.partOfTexture = partOfTexture;
        this.visualWidth = visualWidth;
        this.visualHeight = visualHeight;
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;
    }
}
