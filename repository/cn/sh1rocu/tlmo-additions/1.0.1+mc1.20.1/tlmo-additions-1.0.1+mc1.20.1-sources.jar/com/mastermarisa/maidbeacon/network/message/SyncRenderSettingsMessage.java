package com.mastermarisa.maidbeacon.network.message;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mastermarisa.maidbeacon.MaidBeacon;
import com.mastermarisa.maidbeacon.data.ExtraRenderSettings;
import com.mastermarisa.maidbeacon.init.ModTaskDataKeys;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

public record SyncRenderSettingsMessage(UUID uuid, class_2487 compoundTag) {
    public static final class_2960 ID = MaidBeacon.resourceLocation("sync_render_settings");

    public static class_2540 encode(SyncRenderSettingsMessage message) {
        class_2540 buf = PacketByteBufs.create();
        buf.method_10797(message.uuid);
        buf.method_10794(message.compoundTag);
        return buf;
    }

    public static SyncRenderSettingsMessage decode(class_2540 buf) {
        return new SyncRenderSettingsMessage(buf.method_10790(), buf.method_10798());
    }


    public static void handle(MinecraftServer server, class_3222 player, class_3244 handler, class_2540 buf, PacketSender responseSender) {
        var message = decode(buf);
        server.execute(() -> {
            if (player == null) {
                return;
            }
            class_3218 level = player.method_51469();
            if (level.method_14190(message.uuid()) instanceof EntityMaid maid) {
                ExtraRenderSettings settings = new ExtraRenderSettings();
                settings.deserializeNBT(message.compoundTag);
                maid.setAndSyncData(ModTaskDataKeys.EXTRA_RENDER_SETTINGS, settings);
            }
        });
    }
}
