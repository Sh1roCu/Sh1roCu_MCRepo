package com.mastermarisa.maidbeacon.client.gui.base;

import java.awt.*;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;


public class UIEditBox extends UIElement {
    private final class_342 editBox;
    private final UIBox bg;

    public UIEditBox(Rectangle frame, Color color, int maxLength, Consumer<String> responder, Color textColor) {
        super(frame);

        this.editBox = new class_342(font,
                (int) frame.getMinX(),
                (int) frame.getMinY(),
                frame.width,
                frame.height,
                class_2561.method_43470("")
        );

        this.editBox.method_1880(maxLength);
        this.editBox.method_1858(false);
        this.editBox.method_1862(true);
        this.editBox.method_1856(true);
        this.editBox.method_25365(false);
        this.editBox.method_1863(responder);
        this.editBox.method_1868(textColor.getRGB());

        this.bg = new UIBox(new Rectangle(frame.width + 6, frame.height), color);
        this.children = List.of(bg);
    }

    @Override
    protected void render(class_332 graphics, int mouseX, int mouseY) {
        resize();
        super.render(graphics, mouseX, mouseY);
    }

    public void resize() {
        bg.setCenterX(getCenterX());
        bg.setCenterY(getCenterY() - 3);
        editBox.method_46421(getMinX());
        editBox.method_46419(getMinY());
    }

    public class_342 getEditBox() {
        return editBox;
    }
}
