package com.mastermarisa.maidbeacon.event;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mastermarisa.maidbeacon.client.gui.screen.rendering.RenderSettingsScreen;
import com.mastermarisa.maidbeacon.init.ModItems;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3966;
import org.jetbrains.annotations.Nullable;

public class OnInteractMaid {
    public static class_1269 onPlayerInteractMaidEvent(class_1657 player, class_1937 world, class_1268 hand, class_1297 entity, @Nullable class_3966 hitResult) {
        if (entity instanceof EntityMaid maid) {
            class_1799 itemStack = player.method_5998(hand);
            if (itemStack.method_31574(ModItems.MOBILE_BEACON)) {
                if (world.method_8608())
                    RenderSettingsScreen.open(maid);
                return class_1269.field_5812;
            }
        }
        return class_1269.field_5811;
    }
}
