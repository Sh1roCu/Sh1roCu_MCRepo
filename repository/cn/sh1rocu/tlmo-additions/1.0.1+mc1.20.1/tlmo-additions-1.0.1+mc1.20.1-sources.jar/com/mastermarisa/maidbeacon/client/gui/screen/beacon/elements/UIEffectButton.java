package com.mastermarisa.maidbeacon.client.gui.screen.beacon.elements;

import com.mastermarisa.maidbeacon.client.gui.base.*;
import com.mastermarisa.maidbeacon.config.Config;
import com.mastermarisa.maidbeacon.data.EffectAura;
import com.mastermarisa.maidbeacon.data.MobileBeaconData;
import com.mastermarisa.maidbeacon.network.message.OperateEffectMessage;
import com.mastermarisa.maidbeacon.utils.EncodeUtils;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import java.awt.*;
import java.util.UUID;

public class UIEffectButton extends UIButton {
    private static final Color COMMON = new Color(1, 1, 1, 0.2F);
    private static final Color HIGHLIGHT = new Color(1, 1, 1, 0.8F);
    private final UIBorderBox borderBox = new UIBorderBox(new Rectangle(21, 21), COMMON);
    private final UIBox bg = new UIBox(new Rectangle(22, 22), COMMON);
    private final UIImage icon;
    private final MobileBeaconData mobileBeaconData;
    private final EffectAura effectAura;
    private final int index;
    private boolean toggled;

    public UIEffectButton(MobileBeaconData mobileBeaconData, EffectAura effectAura, UUID uuid, class_1268 hand) {
        super(
                new Rectangle(22, 22),
                (btn) -> ((UIEffectButton) btn).trigger(uuid, hand),
                0
        );

        this.mobileBeaconData = mobileBeaconData;
        this.effectAura = effectAura;
        this.index = Config.EFFECT_AURAS().indexOf(effectAura);
        this.toggled = mobileBeaconData.activated.contains(index);

        this.icon = new UIImage(new ImageData(
                effectAura.getIcon(),
                new Rectangle(0, 0, 18, 18),
                18,
                18,
                18,
                18
        ));

        tooltip.add(effectAura.getEffect().method_5560().method_27661().method_10852(class_2561.method_43470(" " + EncodeUtils.toRoman(effectAura.effectLevel + 1))));
        tooltip.add(class_2561.method_43470("Cost: " + effectAura.cost));
        tooltip.add(class_2561.method_43469("gui.maidbeacon.tooltip.range", effectAura.range));
    }

    @Override
    protected void render(class_332 graphics, int mouseX, int mouseY) {
        renderButton(graphics, mouseX, mouseY);
        renderIcon(graphics, mouseX, mouseY);
        super.render(graphics, mouseX, mouseY);
    }

    private void renderButton(class_332 graphics, int mouseX, int mouseY) {
        borderBox.setMinX(getMinX());
        borderBox.setMinY(getMinY());
        if (toggled) {
            borderBox.color = HIGHLIGHT;
            bg.setMinX(getMinX());
            bg.setMinY(getMinY());
            UIElement.render(graphics, bg, mouseX, mouseY);
        } else {
            borderBox.color = COMMON;
        }
        UIElement.render(graphics, borderBox, mouseX, mouseY);
    }

    private void renderIcon(class_332 graphics, int mouseX, int mouseY) {
        icon.setMinX(getMinX() + 2);
        icon.setMinY(getMinY() + 2);
        UIElement.render(graphics, icon, mouseX, mouseY);
    }

    public void trigger(UUID uuid, class_1268 hand) {
        if (toggled) {
            OperateEffectMessage message = new OperateEffectMessage(0, index, hand == class_1268.field_5808 ? 0 : 1, uuid);
            ClientPlayNetworking.send(OperateEffectMessage.ID, OperateEffectMessage.encode(message));
            mobileBeaconData.activated.remove(index);
            toggled = false;
        } else if (mobileBeaconData.getUsedCost() + effectAura.cost <= Config.getCost(mobileBeaconData.getLevel())) {
            OperateEffectMessage message = new OperateEffectMessage(1, index, hand == class_1268.field_5808 ? 0 : 1, uuid);
            ClientPlayNetworking.send(OperateEffectMessage.ID, OperateEffectMessage.encode(message));
            mobileBeaconData.activated.add(index);
            toggled = true;
        }
    }
}
