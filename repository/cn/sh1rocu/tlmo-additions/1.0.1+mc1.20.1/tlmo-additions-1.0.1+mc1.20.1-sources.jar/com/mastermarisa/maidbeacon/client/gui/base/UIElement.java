package com.mastermarisa.maidbeacon.client.gui.base;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5348;

public abstract class UIElement {
    protected static final class_310 mc;
    protected static final class_327 font;

    public Rectangle frame;
    public List<class_2561> tooltip = new ArrayList<>();
    public List<UIElement> children = new ArrayList<>();

    public UIElement(Rectangle frame) {
        this.frame = frame;
    }

    protected void render(class_332 graphics, int mouseX, int mouseY) {
        this.children.forEach((child) -> child.render(graphics, mouseX, mouseY));
    }

    public static void render(class_332 graphics, UIElement element, int mouseX, int mouseY) {
        render(graphics, Collections.singletonList(element), mouseX, mouseY);
    }

    public static void render(class_332 graphics, List<? extends UIElement> elements, int mouseX, int mouseY) {
        elements.forEach((element) -> element.render(graphics, mouseX, mouseY));
        elements.stream().flatMap(UIElement::getRecursiveChildren).forEach((element) -> element.tryRenderTooltip(graphics, mouseX, mouseY));
    }

    public static void renderToolTip(class_332 graphics, UIElement element, int mouseX, int mouseY) {
        element.getRecursiveChildren().forEach((e) -> e.tryRenderTooltip(graphics, mouseX, mouseY));
    }

    public static boolean onMouseClicked(UIElement element, double mouseX, double mouseY, int button) {
        return onMouseClicked(List.of(element), mouseX, mouseY, button);
    }

    public static boolean onMouseClicked(List<? extends UIElement> elements, double mouseX, double mouseY, int button) {
        return elements.stream().anyMatch(e -> e.onMouseClicked(mouseX, mouseY, button));
    }

    public static boolean onMouseScrolled(UIElement element, double mouseX, double mouseY, double scrollX, double scrollY) {
        return onMouseScrolled(List.of(element), mouseX, mouseY, scrollX, scrollY);
    }

    public static boolean onMouseScrolled(List<? extends UIElement> elements, double mouseX, double mouseY, double scrollX, double scrollY) {
        return elements.stream().anyMatch(e -> e.onMouseScrolled(mouseX, mouseY, scrollX, scrollY));
    }

    protected boolean onMouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        return this.children.stream().anyMatch(c -> c.onMouseScrolled(mouseX, mouseY, scrollX, scrollY));
    }

    protected boolean onMouseClicked(double mouseX, double mouseY, int button) {
        return this.children.stream().anyMatch(c -> c.onMouseClicked(mouseX, mouseY, button));
    }

    protected void tryRenderTooltip(class_332 graphics, int mouseX, int mouseY) {
        boolean hover = hasTooltip() && frame.contains(mouseX, mouseY);
        if (hover) {
            renderTooltip(graphics, class_1799.field_8037, tooltip, mouseX, mouseY);
        }
    }

    protected void tryRenderTooltip(class_332 graphics, class_1799 itemStack, int mouseX, int mouseY) {
        boolean hover = hasTooltip() && frame.contains(mouseX, mouseY);
        if (hover) {
            renderTooltip(graphics, itemStack, tooltip, mouseX, mouseY);
        }
    }

    protected final void renderTooltip(class_332 graphics, class_1799 itemStack, List<? extends class_5348> tooltip, int mouseX, int mouseY) {
        graphics.renderComponentTooltip(font, tooltip, mouseX, mouseY, itemStack);
    }

    public void addChild(UIElement element) {
        children.add(element);
    }

    public void removeChild(UIElement element) {
        children.remove(element);
    }

    protected Stream<UIElement> getRecursiveChildren() {
        return Stream.concat(Stream.of(this), this.children.stream().flatMap(UIElement::getRecursiveChildren));
    }

    public boolean hasTooltip() {
        return !this.tooltip.isEmpty();
    }

    public final int getCenterX() {
        return this.frame.x + this.frame.width / 2;
    }

    public final void setCenterX(int centerX) {
        this.frame.setLocation(centerX - this.frame.width / 2, this.frame.y);
    }

    public final int getCenterY() {
        return this.frame.y + this.frame.height / 2;
    }

    public final void setCenterY(int centerY) {
        this.frame.setLocation(this.frame.x, centerY - this.frame.height / 2);
    }

    public final void setCenter(int centerX, int centerY) {
        this.setCenterX(centerX);
        this.setCenterY(centerY);
    }

    public final int getMinX() {
        return this.frame.x;
    }

    public final void setMinX(int minX) {
        this.frame.setLocation(minX, this.frame.y);
    }

    public final int getMinY() {
        return this.frame.y;
    }

    public final void setMinY(int minY) {
        this.frame.setLocation(this.frame.x, minY);
    }

    public final int getMaxX() {
        return this.frame.x + this.frame.width;
    }

    public final void setMaxX(int maxX) {
        this.frame.setLocation(maxX - this.frame.width, this.frame.y);
    }

    public final int getMaxY() {
        return this.frame.y + this.frame.height;
    }

    public final void setMaxY(int maxY) {
        this.frame.setLocation(this.frame.x, maxY - this.frame.height);
    }

    public final int getWidth() {
        return this.frame.width;
    }

    public final void setWidth(int width) {
        this.frame.width = width;
    }

    public final int getHeight() {
        return this.frame.height;
    }

    public final void setHeight(int height) {
        this.frame.height = height;
    }

    public final void setSize(int width, int height) {
        this.setWidth(width);
        this.setHeight(height);
    }

    public static <T extends UIElement> UIElement toUIElement(T element) {
        return element;
    }

    static {
        mc = class_310.method_1551();
        font = mc.field_1772;
    }
}
