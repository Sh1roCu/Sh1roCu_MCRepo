package com.mastermarisa.maidbeacon.event;

import cn.sh1rocu.tlmo_additions.api.event.EntityLeaveLevelEvent;
import cn.sh1rocu.touhoulittlemaid.api.event.EntityJoinLevelEvent;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mastermarisa.maidbeacon.entity.ExtraRenderingEntity;
import net.minecraft.class_3218;

public class MaidTracker {
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (!event.getLevel().method_8608() && event.getEntity().method_5864() == EntityMaid.TYPE) {
            EntityMaid maid = (EntityMaid) event.getEntity();
            ExtraRenderingEntity extraRendering = new ExtraRenderingEntity(ExtraRenderingEntity.TYPE, event.getLevel());
            extraRendering.setOwnerID(maid.method_5628());
            extraRendering.method_33574(maid.method_19538());
            event.getLevel().method_8649(extraRendering);
        }
    }

    public static void onEntityLeave(EntityLeaveLevelEvent event) {
        if (!event.getLevel().method_8608() && event.getEntity().method_5864() == EntityMaid.TYPE) {
            EntityMaid maid = (EntityMaid) event.getEntity();
            class_3218 level = (class_3218) event.getLevel();
            level.method_31592().method_31803().forEach(e -> {
                if (e instanceof ExtraRenderingEntity extraRendering && extraRendering.getOwnerID() == maid.method_5628()) {
                    extraRendering.method_31472();
                }
            });
        }
    }
}
