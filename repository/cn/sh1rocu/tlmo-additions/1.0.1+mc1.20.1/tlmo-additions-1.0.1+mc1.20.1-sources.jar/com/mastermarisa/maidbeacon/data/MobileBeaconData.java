package com.mastermarisa.maidbeacon.data;

import com.mastermarisa.maidbeacon.config.Config;
import it.unimi.dsi.fastutil.ints.IntArraySet;
import it.unimi.dsi.fastutil.ints.IntSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.IntStream;
import net.minecraft.class_1799;
import net.minecraft.class_2487;

public class MobileBeaconData {
    private int level;
    public IntSet activated;

    public MobileBeaconData() {
        this.level = 0;
        this.activated = new IntArraySet();
    }

    public MobileBeaconData(int level, IntStream stream) {
        this.level = level;
        this.activated = new IntArraySet(stream.toArray());
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getLevel() {
        return level;
    }

    public IntStream toStream() {
        return activated.intStream();
    }

    public int getUsedCost() {
        int total = 0;
        for (Integer i : activated) {
            if (i >= Config.EFFECT_AURAS().size()) continue;
            total += Config.EFFECT_AURAS().get(i).cost;
        }
        return total;
    }

    public ConcurrentHashMap<Float, List<EffectAura>> batched() {
        ConcurrentHashMap<Float, List<EffectAura>> map = new ConcurrentHashMap<>();
        for (int i : activated) {
            if (i >= Config.EFFECT_AURAS().size()) continue;
            EffectAura aura = Config.EFFECT_AURAS().get(i);
            map.computeIfAbsent(aura.range, (f) -> new ArrayList<>(2));
            map.get(aura.range).add(aura);
        }
        return map;
    }

    public class_2487 serializeNBT() {
        class_2487 tag = new class_2487();
        tag.method_10569("level", this.level);
        tag.method_10539("activated", this.activated.toIntArray());
        return tag;
    }

    public void deserializeNBT(class_2487 tag) {
        if (!tag.method_10545("level")) {
            return;
        }
        this.level = tag.method_10550("level");
        this.activated = new IntArraySet(tag.method_10561("activated"));
    }

    public static MobileBeaconData getOrDefault(class_1799 itemStack) {
        class_2487 tag = itemStack.method_7948();
        MobileBeaconData mobileBeaconData = new MobileBeaconData();
        if (tag.method_10545("mobile_beacon_data")) {
            mobileBeaconData.deserializeNBT(tag.method_10562("mobile_beacon_data"));
        }
        return mobileBeaconData;
    }

    public static void setData(class_1799 itemStack, MobileBeaconData mobileBeaconData) {
        itemStack.method_7948().method_10566("mobile_beacon_data", mobileBeaconData.serializeNBT());
    }

}
