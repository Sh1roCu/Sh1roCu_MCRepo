package com.mastermarisa.maidbeacon.utils;

import com.mastermarisa.maidbeacon.config.Config;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1299;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class EntityFilter {
    private static final List<class_1299<?>> whitelist;
    private static final List<class_6862<class_1299<?>>> tagWhitelist;

    public static boolean filter(class_1299<?> type) {
        return whitelist.contains(type) || tagWhitelist.stream().anyMatch(type::method_20210);
    }

    private static void init() {
        for (String str : Config.WHITELIST()) {
            if (isTagLocation(str)) {
                class_2960 location = class_2960.method_12829(str.substring(1));
                if (location == null) continue;
                tagWhitelist.add(class_6862.method_40092(class_7924.field_41266, location));
            } else {
                class_2960 location = class_2960.method_12829(str);
                if (location == null) continue;
                whitelist.add(class_7923.field_41177.method_10223(location));
            }
        }
    }

    private static boolean isTagLocation(String location) {
        return location.startsWith("#");
    }

    static {
        whitelist = new ArrayList<>();
        tagWhitelist = new ArrayList<>();
        init();
    }
}
