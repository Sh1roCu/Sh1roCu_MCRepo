package com.mastermarisa.maidbeacon.data;

import java.util.Objects;
import net.minecraft.class_1291;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class EffectAura {
    public String effect;
    public int effectLevel;
    public int beaconLevel;
    public int cost;
    public float range;

    public EffectAura(String effect, int effectLevel, int beaconLevel, int cost, float range) {
        this.effect = effect;
        this.effectLevel = effectLevel;
        this.beaconLevel = beaconLevel;
        this.cost = cost;
        this.range = range;
    }

    public class_1291 getEffect() {
        return Objects.requireNonNull(class_7923.field_41174.method_10223(class_2960.method_12829(effect)));
    }

    public class_2960 getIcon() {
        class_2960 effectId = class_7923.field_41174.method_10221(getEffect());
        return new class_2960(effectId.method_12836(), "textures/mob_effect/" + effectId.method_12832() + ".png");
    }
}
