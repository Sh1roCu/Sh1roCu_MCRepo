package com.mastermarisa.maidbeacon.init.registry;

import com.github.tartaricacid.touhoulittlemaid.init.InitCreativeTabs;
import com.mastermarisa.maidbeacon.init.ModItems;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroupEntries;
import net.minecraft.class_1761;

public final class CommonRegistry {
    public static void addItemsToCreativeTab(class_1761 group, FabricItemGroupEntries entries) {
        if (group == InitCreativeTabs.MAIN_TAB) {
            entries.method_45421(ModItems.MOBILE_BEACON);
        }
    }
}
