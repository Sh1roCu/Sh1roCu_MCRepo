package cn.sh1rocu.tlmo_additions.util.itemhandler;

import cn.sh1rocu.touhoulittlemaid.util.itemhandler.InvWrapper;
import cn.sh1rocu.touhoulittlemaid.util.itemhandler.RangedWrapper;
import net.minecraft.class_1661;

public class PlayerOffhandInvWrapper extends RangedWrapper {
    public PlayerOffhandInvWrapper(class_1661 inv) {
        super(new InvWrapper(inv), inv.field_7547.size() + inv.field_7548.size(), inv.field_7547.size() + inv.field_7548.size() + inv.field_7544.size());
    }
}