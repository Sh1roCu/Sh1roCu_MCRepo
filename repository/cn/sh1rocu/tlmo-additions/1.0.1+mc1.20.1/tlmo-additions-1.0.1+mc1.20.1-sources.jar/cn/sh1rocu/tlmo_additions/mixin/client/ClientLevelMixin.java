package cn.sh1rocu.tlmo_additions.mixin.client;

import cn.sh1rocu.tlmo_additions.api.event.EntityLeaveLevelEvent;
import net.minecraft.class_1297;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_638.class)
public class ClientLevelMixin {

    @Mixin(targets = "net.minecraft.client.multiplayer.ClientLevel$EntityCallbacks")
    public abstract static class EntityCallbacksMixin {
        @Shadow
        @Final
        class_638 field_27735;

        @Inject(method = "onTrackingEnd(Lnet/minecraft/world/entity/Entity;)V", at = @At("TAIL"))
        private void tlmoa$entityLeaveLevelEvent(class_1297 entity, CallbackInfo ci) {
            EntityLeaveLevelEvent event = new EntityLeaveLevelEvent(entity, this.field_27735);
            EntityLeaveLevelEvent.EVENT.invoker().post(event);
        }
    }
}
