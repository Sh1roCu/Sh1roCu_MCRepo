package cn.sh1rocu.tlmo_additions.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1657;

public class PlayerLoggedOutEvent {
    private final class_1657 player;

    public PlayerLoggedOutEvent(class_1657 player) {
        this.player = player;
    }

    public class_1657 getEntity() {
        return player;
    }

    public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (final Callback callback : callbacks)
            callback.post(event);
    });

    public interface Callback {
        void post(PlayerLoggedOutEvent event);
    }
}
