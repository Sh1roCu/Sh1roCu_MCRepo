package cn.sh1rocu.tlmo_additions.util.itemhandler;

import cn.sh1rocu.touhoulittlemaid.util.itemhandler.CombinedInvWrapper;
import cn.sh1rocu.touhoulittlemaid.util.itemhandler.PlayerMainInvWrapper;
import net.minecraft.class_1661;

public class PlayerInvWrapper extends CombinedInvWrapper {
    public PlayerInvWrapper(class_1661 inv) {
        super(new PlayerMainInvWrapper(inv), new PlayerArmorInvWrapper(inv), new PlayerOffhandInvWrapper(inv));
    }
}