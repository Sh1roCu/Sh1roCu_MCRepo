package cn.sh1rocu.tlmo_additions.mixin.common;

import cn.sh1rocu.tlmo_additions.api.event.PlayerLoggedOutEvent;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3324.class)
public abstract class PlayerListMixin {
    @Inject(method = "remove", at = @At("HEAD"))
    private void tlmoa$playerLoggedOut(class_3222 player, CallbackInfo ci) {
        PlayerLoggedOutEvent event = new PlayerLoggedOutEvent(player);
        PlayerLoggedOutEvent.EVENT.invoker().post(event);
    }
}