package cn.sh1rocu.tlmo_additions.util.itemhandler;

import cn.sh1rocu.touhoulittlemaid.util.itemhandler.InvWrapper;
import cn.sh1rocu.touhoulittlemaid.util.itemhandler.RangedWrapper;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import org.jetbrains.annotations.NotNull;

public class PlayerArmorInvWrapper extends RangedWrapper {
    private final class_1661 inventoryPlayer;

    public PlayerArmorInvWrapper(class_1661 inv) {
        super(new InvWrapper(inv), inv.field_7547.size(), inv.field_7547.size() + inv.field_7548.size());
        this.inventoryPlayer = inv;
    }

    @NotNull
    public class_1799 insertItem(int slot, @NotNull class_1799 stack, boolean simulate) {
        class_1304 equ = null;

        for (class_1304 s : class_1304.values()) {
            if (s.method_5925() == class_1304.class_1305.field_6178 && s.method_5927() == slot) {
                equ = s;
                break;
            }
        }

        return equ != null && slot < 4 && !stack.method_7960() && canEquip(stack, equ) ? super.insertItem(slot, stack, simulate) : stack;
    }


    private boolean canEquip(class_1799 stack, class_1304 armorType) {
        return class_1309.method_32326(stack) == armorType;
    }

    public class_1661 getInventoryPlayer() {
        return this.inventoryPlayer;
    }
}
