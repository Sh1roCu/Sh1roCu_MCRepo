package cn.sh1rocu.tlmo_additions.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_1937;

public class EntityLeaveLevelEvent {
    private final class_1297 entity;
    private final class_1937 level;

    public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (final Callback callback : callbacks)
            callback.post(event);
    });

    public EntityLeaveLevelEvent(class_1297 entity, class_1937 level) {
        this.entity = entity;
        this.level = level;
    }

    public class_1297 getEntity() {
        return entity;
    }

    public class_1937 getLevel() {
        return level;
    }

    public interface Callback {
        void post(EntityLeaveLevelEvent event);
    }
}
