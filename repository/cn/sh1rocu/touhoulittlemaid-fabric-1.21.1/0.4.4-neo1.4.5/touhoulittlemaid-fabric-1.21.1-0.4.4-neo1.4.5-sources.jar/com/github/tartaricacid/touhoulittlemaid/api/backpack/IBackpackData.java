package com.github.tartaricacid.touhoulittlemaid.api.backpack;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_2487;
import net.minecraft.class_3913;

public interface IBackpackData {
    class_3913 getDataAccess();

    void load(class_2487 tag, EntityMaid maid);

    void save(class_2487 tag, EntityMaid maid);

    void serverTick(EntityMaid maid);
}
