package com.github.tartaricacid.touhoulittlemaid.client.event;

import com.github.tartaricacid.touhoulittlemaid.client.gui.mod.OptifineScreen;
import com.github.tartaricacid.touhoulittlemaid.config.subconfig.MiscConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;

@Environment(EnvType.CLIENT)
public final class ShowOptifineScreen {
    private static boolean optifinePresent = false;
    private static boolean firstTitleScreenShown = false;

    public static void showOptifineWarning(class_310 client, class_437 screen, int scaledWidth, int scaledHeight) {
        if (firstTitleScreenShown || !(screen instanceof class_442)) {
            return;
        }
        if (!MiscConfig.CLOSE_OPTIFINE_WARNING.get() && optifinePresent) {
            class_310.method_1551().method_1507(new OptifineScreen(screen));
        }
        firstTitleScreenShown = true;
    }

    public static void checkOptifineIsLoaded() {
        try {
            Class.forName("net.optifine.Config");
            optifinePresent = true;
        } catch (ClassNotFoundException e) {
            optifinePresent = false;
        }
    }
}
