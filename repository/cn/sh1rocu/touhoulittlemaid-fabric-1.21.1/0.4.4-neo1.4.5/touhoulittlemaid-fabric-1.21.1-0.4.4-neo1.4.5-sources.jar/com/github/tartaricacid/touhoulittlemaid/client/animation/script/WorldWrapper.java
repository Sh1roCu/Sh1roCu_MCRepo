package com.github.tartaricacid.touhoulittlemaid.client.animation.script;

import com.github.tartaricacid.touhoulittlemaid.api.animation.IWorldData;
import net.minecraft.class_1937;

public final class WorldWrapper implements IWorldData {
    private class_1937 world;

    public void setData(class_1937 world) {
        this.world = world;
    }

    public void clearData() {
        this.world = null;
    }

    @Override
    public long getWorldTime() {
        return world.method_8532();
    }

    @Override
    public boolean isDay() {
        return world.method_8532() < 13000;
    }

    @Override
    public boolean isNight() {
        return world.method_8532() >= 13000;
    }

    @Override
    public boolean isRaining() {
        return world.method_8419();
    }

    @Override
    public boolean isThundering() {
        return world.method_8546();
    }
}
