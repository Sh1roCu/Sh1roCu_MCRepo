package com.github.tartaricacid.touhoulittlemaid.ai.service.function.implement;

import cn.sh1rocu.touhoulittlemaid.util.itemhandler.RangedWrapper;
import com.github.tartaricacid.touhoulittlemaid.TouhouLittleMaid;
import com.github.tartaricacid.touhoulittlemaid.ai.service.function.IFunctionCall;
import com.github.tartaricacid.touhoulittlemaid.ai.service.function.response.ToolResponse;
import com.github.tartaricacid.touhoulittlemaid.ai.service.function.schema.parameter.ObjectParameter;
import com.github.tartaricacid.touhoulittlemaid.ai.service.function.schema.parameter.Parameter;
import com.github.tartaricacid.touhoulittlemaid.ai.service.function.schema.parameter.StringParameter;
import com.github.tartaricacid.touhoulittlemaid.api.task.IAttackTask;
import com.github.tartaricacid.touhoulittlemaid.api.task.IMaidTask;
import com.github.tartaricacid.touhoulittlemaid.compat.gun.common.GunCommonUtil;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.entity.task.TaskManager;
import com.github.tartaricacid.touhoulittlemaid.util.ItemsUtil;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2960;

public class SwitchAttackTaskFunction implements IFunctionCall<SwitchAttackTaskFunction.Result> {
    private static final String FUNCTION_ID = "switch_maid_attack_task";
    private static final String FUNCTION_DESC = """
            Use this function to change the maid's current combat or behavior task.
            Especially when the user asks to alter her fighting style, prepare for a battle, or stand down""";
    private static final String TASK_ID_PARAMETER_ID = "task_id";
    private static final String TASK_ID_PARAMETER_DESC = """
            task_id (string, required): The specific ID of the task you want the maid to switch to. Available tasks include:
            idle (Stands idle), attack (Melee combat), ranged_attack (Bow combat)
            crossbow_attack (Crossbow combat), danmaku_attack (Danmaku combat), trident_attack (Trident combat)""";
    private static final String GUN_TASK_ID_PARAMETER_DESC = "gun_attack (Gun combat)";
    private static final String SUCCESS = "Successfully switched to %s task";
    private static final String MISSING = "Successfully switched to %s task, but the corresponding weapon is missing";
    private static final String FAIL = "Switch failed and there is no task named %s";
    private static final String NO_CHANGE = "You're currently in %s task and don't need to switch";

    @Override
    public String getId() {
        return FUNCTION_ID;
    }

    @Override
    public String getDescription(EntityMaid maid) {
        return FUNCTION_DESC;
    }

    @Override
    public Parameter addParameters(ObjectParameter root, EntityMaid maid) {
        Parameter taskId = StringParameter.create()
                .setDescription(TASK_ID_PARAMETER_DESC)
                .addEnumValues("idle", "attack", "ranged_attack",
                        "crossbow_attack", "danmaku_attack", "trident_attack");
        if (GunCommonUtil.isInstalled()) {
            taskId.setDescription(TASK_ID_PARAMETER_DESC + "\n" + GUN_TASK_ID_PARAMETER_DESC);
            taskId.addEnumValues("gun_attack");
        }
        root.addProperties(TASK_ID_PARAMETER_ID, taskId);
        return root;
    }

    @Override
    public Codec<Result> codec() {
        return RecordCodecBuilder.create(instance ->
                instance.group(Codec.STRING.fieldOf(TASK_ID_PARAMETER_ID)
                                .forGetter(Result::id))
                        .apply(instance, Result::new));
    }

    @Override
    public ToolResponse onToolCall(Result result, EntityMaid maid) {
        String id = result.id;
        class_2960 taskId = class_2960.method_60655(TouhouLittleMaid.MOD_ID, id);
        Optional<IMaidTask> optional = TaskManager.findTask(taskId);
        if (optional.isEmpty()) {
            return new ToolResponse(FAIL.formatted(id));
        }

        // 空闲模式额外判断
        IMaidTask task = optional.get();
        RangedWrapper backpack = maid.getAvailableBackpackInv();
        if (task == TaskManager.getIdleTask()) {
            putItemBack(maid, backpack);
            maid.setTask(task);
            return new ToolResponse(SUCCESS.formatted(id));
        }

        // 攻击模式判断
        if (!(task instanceof IAttackTask attackTask)) {
            return new ToolResponse(FAIL.formatted(id));
        }
        // 如果不需要拿武器并切换模式，那么不用执行后面的逻辑
        IMaidTask currentTask = maid.getTask();
        if (attackTask == currentTask && attackTask.isWeapon(maid, maid.method_6047())) {
            return new ToolResponse(NO_CHANGE.formatted(id));
        }

        maid.setTask(task);

        // 将武器取到主手上
        int slot = ItemsUtil.findStackSlot(backpack, item -> attackTask.isWeapon(maid, item));
        if (slot >= 0) {
            int count = backpack.getStackInSlot(slot).method_7947();
            class_1799 output = backpack.extractItem(slot, count, false);
            if (!maid.method_6047().method_7960()) {
                class_1799 mainhand = maid.method_6047();
                backpack.setStackInSlot(slot, mainhand);
            }
            maid.method_6122(class_1268.field_5808, output);
            return new ToolResponse(SUCCESS.formatted(id));
        }
        return new ToolResponse(MISSING.formatted(id));
    }

    private void putItemBack(EntityMaid maid, RangedWrapper backpack) {
        if (maid.method_6047().method_7960()) {
            return;
        }
        class_1799 mainHandItem = maid.method_6047();
        for (int i = 0; i < backpack.getSlots(); i++) {
            class_1799 stackInSlot = backpack.getStackInSlot(i);
            if (stackInSlot.method_7960()) {
                backpack.setStackInSlot(i, mainHandItem);
                maid.method_6122(class_1268.field_5808, class_1799.field_8037);
                return;
            }
        }
    }

    public record Result(String id) {
    }
}