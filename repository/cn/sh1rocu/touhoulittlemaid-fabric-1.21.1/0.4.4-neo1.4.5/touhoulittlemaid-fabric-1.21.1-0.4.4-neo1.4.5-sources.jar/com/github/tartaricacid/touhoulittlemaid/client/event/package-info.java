@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.tartaricacid.touhoulittlemaid.client.event;

import javax.annotation.ParametersAreNonnullByDefault;