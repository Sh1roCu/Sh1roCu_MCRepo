package com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button;

import com.github.tartaricacid.touhoulittlemaid.client.download.pojo.DownloadInfo;
import com.github.tartaricacid.touhoulittlemaid.client.download.pojo.DownloadStatus;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_5250;

public class GuiDownloadButton extends class_4185 {
    private final DownloadInfo info;

    public GuiDownloadButton(int pX, int pY, int pWidth, int pHeight, DownloadInfo info, class_4241 pOnPress) {
        super(pX, pY, pWidth, pHeight, class_2561.method_43473(), pOnPress, class_4185.field_40754);
        this.info = info;
        if (!DownloadStatus.canDownload(info.getStatus())) {
            this.field_22763 = false;
        }
    }

    @Override
    public class_2561 method_25369() {
        class_5250 text;
        if (info == null) {
            return class_2561.method_43471("selectWorld.futureworld.error.title");
        }
        switch (info.getStatus()) {
            case DOWNLOADED -> text = class_2561.method_43471("gui.touhou_little_maid.resources_download.downloaded");
            case DOWNLOADING -> text = class_2561.method_43471("gui.touhou_little_maid.resources_download.downloading");
            case NEED_UPDATE -> text = class_2561.method_43471("gui.touhou_little_maid.resources_download.need_update");
            default -> text = class_2561.method_43471("gui.touhou_little_maid.resources_download.not_download");
        }
        return text;
    }
}
