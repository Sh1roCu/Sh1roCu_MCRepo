@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.tartaricacid.touhoulittlemaid.client.gui.item;

import javax.annotation.ParametersAreNonnullByDefault;