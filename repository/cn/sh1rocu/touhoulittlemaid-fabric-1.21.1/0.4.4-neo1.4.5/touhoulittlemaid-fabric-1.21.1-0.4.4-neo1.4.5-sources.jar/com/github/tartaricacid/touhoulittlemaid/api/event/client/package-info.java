@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.tartaricacid.touhoulittlemaid.api.event.client;

import javax.annotation.ParametersAreNonnullByDefault;