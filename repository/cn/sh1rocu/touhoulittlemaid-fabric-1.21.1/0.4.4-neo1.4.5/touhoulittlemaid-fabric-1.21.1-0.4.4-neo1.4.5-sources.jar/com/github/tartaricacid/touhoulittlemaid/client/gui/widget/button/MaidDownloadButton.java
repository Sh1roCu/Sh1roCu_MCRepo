package com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button;

import com.github.tartaricacid.touhoulittlemaid.client.download.InfoGetManager;
import com.github.tartaricacid.touhoulittlemaid.client.gui.entity.ModelDownloadGui;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.util.TipsHelper;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5250;

public class MaidDownloadButton extends TouhouImageButton {
    public MaidDownloadButton(int pX, int pY, class_2960 texture, EntityMaid maid) {
        super(pX, pY, 41, 20, 0, 86, 20, texture, (b) -> {
            InfoGetManager.STATUE = InfoGetManager.Statue.NOT_UPDATE;
            class_310.method_1551().method_1507(new ModelDownloadGui(maid));
        });
    }

    public void renderExtraTips(class_332 graphics) {
        TipsHelper.renderTips(graphics, this, getText());
    }

    private class_5250 getText() {
        if (InfoGetManager.STATUE == InfoGetManager.Statue.FIRST) {
            return class_2561.method_43471("gui.touhou_little_maid.button.model_download.statue.first");
        }
        if (InfoGetManager.STATUE == InfoGetManager.Statue.UPDATE) {
            return class_2561.method_43471("gui.touhou_little_maid.button.model_download.statue.update");
        }
        return class_2561.method_43473();
    }
}