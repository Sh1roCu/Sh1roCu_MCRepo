@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button;

import javax.annotation.ParametersAreNonnullByDefault;