@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.tartaricacid.touhoulittlemaid.client.gui.block;

import javax.annotation.ParametersAreNonnullByDefault;