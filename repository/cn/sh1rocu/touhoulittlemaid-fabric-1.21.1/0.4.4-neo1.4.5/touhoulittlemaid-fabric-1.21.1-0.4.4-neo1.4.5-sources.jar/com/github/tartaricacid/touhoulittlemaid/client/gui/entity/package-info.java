@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.tartaricacid.touhoulittlemaid.client.gui.entity;

import javax.annotation.ParametersAreNonnullByDefault;