package com.github.tartaricacid.touhoulittlemaid.client.gui.item;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.network.message.ServantBellSetPackage;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.apache.commons.lang3.StringUtils;

import java.util.UUID;

public class ServantBellSetScreen extends class_437 {
    private final int maidId;
    private final UUID maidUuid;
    private class_342 textField;

    public ServantBellSetScreen(EntityMaid maid) {
        super(class_2561.method_43473());
        this.maidId = maid.method_5628();
        this.maidUuid = maid.method_5667();
    }

    @Override
    protected void method_25426() {
        this.method_37067();
        int middleX = this.field_22789 / 2;
        int middleY = this.field_22790 / 2;
        textField = new class_342(Screens.getTextRenderer(this), middleX - 99, middleY - 26, 200, 20,
                class_2561.method_43471("gui.touhou_little_maid.servant_bell.edit_box"));
        this.method_25429(this.textField);
        this.method_48265(this.textField);
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"), this::sendDoneMessage)
                .method_46433(middleX - 100, middleY + 10).method_46437(98, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), b -> method_25419())
                .method_46433(middleX + 4, middleY + 10).method_46437(98, 20).method_46431());
    }

    @Override
    public void method_25410(class_310 minecraft, int width, int height) {
        String value = this.textField.method_1882();
        super.method_25410(minecraft, width, height);
        this.textField.method_1852(value);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
        int middleX = this.field_22789 / 2;
        int middleY = this.field_22790 / 2;
        super.method_25394(graphics, mouseX, mouseY, partialTicks);
        textField.method_25394(graphics, mouseX, mouseY, partialTicks);
        if (textField.method_1882().isEmpty()) {
            graphics.method_51439(field_22793, class_2561.method_43471("gui.touhou_little_maid.servant_bell.edit_box").method_27692(class_124.field_1056), middleX - 94, middleY - 20, class_124.field_1063.method_532(), false);
        }
        graphics.method_27534(field_22793, class_2561.method_43469("tooltips.touhou_little_maid.servant_bell.uuid", this.maidUuid.toString()), middleX, middleY - 50, 0xFFFFFF);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (this.textField.method_25402(mouseX, mouseY, button)) {
            this.method_25395(this.textField);
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    protected void method_25415(String text, boolean overwrite) {
        if (overwrite) {
            this.textField.method_1852(text);
        } else {
            this.textField.method_1867(text);
        }
    }

    private void sendDoneMessage(class_4185 button) {
        if (StringUtils.isNotBlank(textField.method_1882())) {
            ClientPlayNetworking.send(new ServantBellSetPackage(this.maidId, textField.method_1882()));
        }
        this.method_25419();
    }
}
