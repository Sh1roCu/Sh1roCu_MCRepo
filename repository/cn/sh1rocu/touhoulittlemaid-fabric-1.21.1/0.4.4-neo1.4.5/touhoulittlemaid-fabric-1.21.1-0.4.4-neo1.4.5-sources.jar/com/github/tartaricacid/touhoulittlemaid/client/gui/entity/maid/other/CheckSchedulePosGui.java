package com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.other;

import cn.sh1rocu.touhoulittlemaid.mixin.accessor.ScreenAccessor;
import com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.AbstractMaidContainerGui;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import java.util.List;

public class CheckSchedulePosGui extends class_437 {
    private final AbstractMaidContainerGui<?> parent;
    private final class_2561 tips;
    private int middleX;
    private int middleY;

    public CheckSchedulePosGui(AbstractMaidContainerGui<?> parent, class_2561 tips) {
        super(class_2561.method_43470("Check Schedule Pos Screen"));
        this.parent = parent;
        this.tips = tips;
    }

    @Override
    protected void method_25426() {
        this.middleX = this.field_22789 / 2;
        this.middleY = this.field_22790 / 2;
        class_4185 returnButton = class_4185.method_46430(class_2561.method_43471("button.touhou_little_maid.maid.return"), (b) -> Screens.getClient(this).method_1507(this.parent))
                .method_46433(middleX - 100, middleY + 10).method_46437(200, 20).method_46431();
        this.method_37063(returnButton);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
        method_25420(graphics, mouseX, mouseY, partialTicks);
        List<class_5481> split = field_22793.method_1728(tips, 300);
        int startY = middleY - 10 - split.size() * (field_22793.field_2000 + 3);
        for (class_5481 text : split) {
            graphics.method_35719(field_22793, text, middleX, startY, 0xFFFFFF);
            startY += field_22793.field_2000 + 3;
        }
        for (class_4068 renderable : ((ScreenAccessor) this).tlm$getRenderables()) {
            renderable.method_25394(graphics, mouseX, mouseY, partialTicks);
        }
    }
}
