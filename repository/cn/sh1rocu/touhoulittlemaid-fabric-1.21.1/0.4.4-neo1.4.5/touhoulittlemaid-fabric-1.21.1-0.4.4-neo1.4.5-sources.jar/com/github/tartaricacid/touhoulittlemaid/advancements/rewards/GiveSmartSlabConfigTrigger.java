package com.github.tartaricacid.touhoulittlemaid.advancements.rewards;

import com.github.tartaricacid.touhoulittlemaid.config.subconfig.MiscConfig;
import com.github.tartaricacid.touhoulittlemaid.init.InitTrigger;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.class_175;
import net.minecraft.class_2048;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;

public class GiveSmartSlabConfigTrigger extends class_4558<GiveSmartSlabConfigTrigger.Instance> {
    public void trigger(class_3222 serverPlayer) {
        super.method_22510(serverPlayer, instance -> MiscConfig.GIVE_SMART_SLAB.get());
    }

    @Override
    public Codec<Instance> method_54937() {
        return Instance.CODEC;
    }

    public record Instance(Optional<class_5258> player) implements SimpleInstance {
        public static final Codec<Instance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                        class_2048.field_47250.optionalFieldOf("player").forGetter(Instance::player))
                .apply(instance, Instance::new));

        public static class_175<Instance> instance() {
            return InitTrigger.GIVE_SMART_SLAB_CONFIG.method_53699(new Instance(Optional.empty()));
        }
    }
}
