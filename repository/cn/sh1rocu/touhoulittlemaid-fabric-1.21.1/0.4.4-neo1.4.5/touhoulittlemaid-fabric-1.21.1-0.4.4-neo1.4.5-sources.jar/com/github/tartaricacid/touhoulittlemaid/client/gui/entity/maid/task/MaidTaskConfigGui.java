package com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.task;

import com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.AbstractMaidContainerGui;
import com.github.tartaricacid.touhoulittlemaid.inventory.container.task.TaskConfigContainer;
import com.github.tartaricacid.touhoulittlemaid.network.message.RefreshMaidBrainPackage;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1661;
import net.minecraft.class_2561;

public abstract class MaidTaskConfigGui<T extends TaskConfigContainer> extends AbstractMaidContainerGui<T> {
    public MaidTaskConfigGui(T screenContainer, class_1661 inv, class_2561 titleIn) {
        super(screenContainer, inv, titleIn);
    }

    @Override
    public void method_25419() {
        // 重置女仆 Brain，让女仆重新读取任务相关数据
        if (this.maid != null) {
            ClientPlayNetworking.send(new RefreshMaidBrainPackage(maid.method_5628()));
        }
        super.method_25419();
    }
}