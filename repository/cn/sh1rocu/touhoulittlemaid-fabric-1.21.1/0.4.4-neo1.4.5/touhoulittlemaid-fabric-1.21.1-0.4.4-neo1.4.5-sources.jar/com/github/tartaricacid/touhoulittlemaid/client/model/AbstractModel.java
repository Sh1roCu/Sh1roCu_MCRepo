package com.github.tartaricacid.touhoulittlemaid.client.model;

import org.jetbrains.annotations.NotNull;

import java.util.function.Function;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_583;

public abstract class AbstractModel<E extends class_1297> extends class_583<E> {
    public AbstractModel(Function<class_2960, class_1921> pRenderType) {
        super(pRenderType);
    }

    protected AbstractModel() {
        this(class_1921::method_23578);
    }

    public void renderToBuffer(@NotNull class_4587 poseStack, @NotNull class_4588 buffer, int light, int overlay, float r, float g, float b, float a) {
        this.method_60879(poseStack, buffer, light, overlay);
    }
}
