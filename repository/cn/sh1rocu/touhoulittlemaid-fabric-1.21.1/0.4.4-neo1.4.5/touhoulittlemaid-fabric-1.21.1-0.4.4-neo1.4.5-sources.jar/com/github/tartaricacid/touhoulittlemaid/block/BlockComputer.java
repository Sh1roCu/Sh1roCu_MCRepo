package com.github.tartaricacid.touhoulittlemaid.block;

import com.github.tartaricacid.touhoulittlemaid.entity.favorability.Type;
import com.github.tartaricacid.touhoulittlemaid.tileentity.TileEntityComputer;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_10;
import net.minecraft.class_1922;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

public class BlockComputer extends BlockJoy {
    public static final class_265 SHAPE = class_259.method_17786(class_2248.method_9541(0, 0, 0, 16, 3, 16),
            class_2248.method_9541(6, 3, 6, 10, 9, 10),
            class_2248.method_9541(1, 9, 1, 15, 12, 15),
            class_2248.method_9541(0, 12, 0, 16, 14, 16));

    @Override
    protected class_243 sitPosition() {
        return new class_243(0.5, 1, 0.5);
    }

    @Override
    protected int sitYRot() {
        return 180;
    }

    @Override
    protected String getTypeName() {
        return Type.COMPUTER.getTypeName();
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pPos, class_2680 pState) {
        return new TileEntityComputer(pPos, pState);
    }

    @Override
    public boolean method_9516(class_2680 state, class_10 type) {
        return false;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 worldIn, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return method_54094((properties) -> new BlockComputer());
    }
}
