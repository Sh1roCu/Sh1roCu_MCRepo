@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.tartaricacid.touhoulittlemaid.client.animation;

import javax.annotation.ParametersAreNonnullByDefault;