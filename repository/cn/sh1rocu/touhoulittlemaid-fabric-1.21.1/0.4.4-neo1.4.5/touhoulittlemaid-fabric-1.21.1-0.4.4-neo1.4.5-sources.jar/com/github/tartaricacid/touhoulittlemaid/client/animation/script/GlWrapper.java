package com.github.tartaricacid.touhoulittlemaid.client.animation.script;


import net.minecraft.class_3532;
import net.minecraft.class_4587;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class GlWrapper {
    private static class_4587 poseStack;

    public static void setPoseStack(class_4587 poseStackIn) {
        poseStack = poseStackIn;
    }

    public static void clearPoseStack() {
        poseStack = null;
    }

    public static void translate(double x, double y, double z) {
        poseStack.method_22904(x, y, z);
    }

    public static void rotate(double angle, double x, double y, double z) {
        Vector3f vector3f = new Vector3f(normalize(x), normalize(y), normalize(z));
        poseStack.method_22907(new Quaternionf().rotateAxis((float) angle * class_3532.field_29847, vector3f));
    }

    public static void scale(double x, double y, double z) {
        poseStack.method_22905((float) x, (float) y, (float) z);
    }

    public static void pushMatrix() {
        poseStack.method_22903();
    }

    public static void popMatrix() {
        poseStack.method_22909();
    }

    private static float normalize(double value) {
        if (value >= 1.0E-5) {
            return 1.0f;
        } else if (value <= -1.0E-5) {
            return -1.0f;
        } else {
            return 0;
        }
    }
}
