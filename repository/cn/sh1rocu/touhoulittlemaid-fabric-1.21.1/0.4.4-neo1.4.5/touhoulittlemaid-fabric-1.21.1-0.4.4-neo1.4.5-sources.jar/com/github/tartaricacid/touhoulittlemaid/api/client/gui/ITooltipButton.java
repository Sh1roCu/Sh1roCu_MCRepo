package com.github.tartaricacid.touhoulittlemaid.api.client.gui;

import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * 女仆主界面用，按钮用于渲染文本提示
 */
public interface ITooltipButton {
    /**
     * 鼠标是否悬浮其上
     */
    boolean isTooltipHovered();

    /**
     * 渲染文本提示
     */
    void renderTooltip(class_332 graphics, class_310 mc, int mouseX, int mouseY);
}
