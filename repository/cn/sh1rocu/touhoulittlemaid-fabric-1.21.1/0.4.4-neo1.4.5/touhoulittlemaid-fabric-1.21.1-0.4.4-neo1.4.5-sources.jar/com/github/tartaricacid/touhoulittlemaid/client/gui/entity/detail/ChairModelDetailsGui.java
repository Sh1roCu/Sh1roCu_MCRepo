package com.github.tartaricacid.touhoulittlemaid.client.gui.entity.detail;

import com.github.tartaricacid.touhoulittlemaid.client.gui.entity.cache.CacheIconManager;
import com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button.ModelDetailsButton;
import com.github.tartaricacid.touhoulittlemaid.client.resource.pojo.ChairModelInfo;
import com.github.tartaricacid.touhoulittlemaid.entity.item.EntityChair;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.init.InitEntities;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_898;

public class ChairModelDetailsGui extends AbstractModelDetailsGui<EntityChair, ChairModelInfo> {
    private EntityMaid maid;
    private boolean showPassenger = false;

    public ChairModelDetailsGui(EntityChair sourceEntity, ChairModelInfo modelInfo) {
        super(sourceEntity, InitEntities.CHAIR.method_5883(sourceEntity.method_37908()), modelInfo);
        guiEntity.setModelId(modelInfo.getModelId().toString());
        if (class_310.method_1551().field_1687 != null) {
            this.maid = InitEntities.MAID.method_5883(class_310.method_1551().field_1687);
            if (this.maid != null) {
                this.maid.setModelId("authors_and_credits:wine_fox_maid");
            }
        }
    }

    @Override
    protected void applyReturnButtonLogic() {
        CacheIconManager.openChairModelGui(sourceEntity);
    }

    @Override
    protected void initSideButton() {
        ModelDetailsButton showPassengerButton = new ModelDetailsButton(2, 17, "gui.touhou_little_maid.skin_details.show_passenger",
                this::applyShowPassengerLogic);
        this.method_37063(showPassengerButton);
    }

    @Override
    public void method_25393() {
        guiEntity.field_6012++;
        if (maid != null) {
            maid.field_6012++;
        }
    }

    @Override
    protected void renderExtraEntity(class_898 manager, class_4587 matrix, class_4597.class_4598 bufferIn) {
        if (showPassenger) {
            manager.method_3954(maid, 0, -0.375 + modelInfo.getMountedYOffset(), 0, 0, 1, matrix, bufferIn, 0xf000f0);
        }
    }

    private void applyShowPassengerLogic(boolean isStateTriggered) {
        this.showPassenger = isStateTriggered;
        if (isStateTriggered && maid != null) {
            maid.method_5873(guiEntity, true);
        } else {
            guiEntity.method_5772();
        }
    }
}
