package com.github.tartaricacid.touhoulittlemaid.block;

import com.github.tartaricacid.touhoulittlemaid.entity.favorability.Type;
import com.github.tartaricacid.touhoulittlemaid.tileentity.TileEntityBookshelf;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1922;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

public class BlockBookshelf extends BlockJoy {
    public static final class_265 SHAPE = class_2248.method_9541(1, 0, 1, 15, 5, 15);

    @Override
    protected class_243 sitPosition() {
        return new class_243(0.5, 0.375, 0.5);
    }

    @Override
    protected int sitYRot() {
        return -90;
    }

    @Override
    protected String getTypeName() {
        return Type.BOOKSHELF.getTypeName();
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pPos, class_2680 pState) {
        return new TileEntityBookshelf(pPos, pState);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 worldIn, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return method_54094((properties) -> new BlockBookshelf());
    }
}
