package com.github.tartaricacid.touhoulittlemaid.client.event;

import cn.sh1rocu.touhoulittlemaid.api.event.PlaySoundSourceEvent;
import com.github.tartaricacid.touhoulittlemaid.api.client.sound.ICustomSoundBuffer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4231;

@Environment(EnvType.CLIENT)
public class PlayMaidSoundEvent {
    public static void onPlaySoundSource(PlaySoundSourceEvent event) {
        if (event.getSound() instanceof ICustomSoundBuffer custom) {
            class_4231 soundBuffer = custom.getSoundBuffer();
            if (soundBuffer != null) {
                event.getChannel().method_19642(soundBuffer);
                event.getChannel().method_19650();
            }
        }
    }
}
