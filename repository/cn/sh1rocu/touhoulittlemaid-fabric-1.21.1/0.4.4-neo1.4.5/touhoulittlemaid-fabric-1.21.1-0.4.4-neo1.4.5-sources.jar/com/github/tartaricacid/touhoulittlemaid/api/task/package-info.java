@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.tartaricacid.touhoulittlemaid.api.task;

import javax.annotation.ParametersAreNonnullByDefault;