package com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button;

import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_4185;

public class DirectButton extends class_4185 {
    private class_2350 direction = class_2350.field_11035;

    public DirectButton(int pX, int pY, int pWidth, int pHeight, class_2350 direction, class_4241 pOnPress) {
        //super(Button.builder(Component.empty(), pOnPress).pos(pX, pY).size(pWidth, pHeight));
        super(pX, pY, pWidth, pHeight, class_2561.method_43473(), pOnPress, class_4185.field_40754);
        this.direction = direction;
    }


    public class_2350 getDirection() {
        return direction;
    }

    @Override
    public void method_25306() {
        this.direction = class_2350.method_10139((direction.method_10161() + 1) % 4);
        this.field_22767.onPress(this);
    }

    @Override
    public class_2561 method_25369() {
        switch (direction) {
            case field_11034:
                return class_2561.method_43471("gui.touhou_little_maid.model_switcher.direction.east");
            case field_11039:
                return class_2561.method_43471("gui.touhou_little_maid.model_switcher.direction.west");
            case field_11035:
                return class_2561.method_43471("gui.touhou_little_maid.model_switcher.direction.south");
            default:
            case field_11043:
                return class_2561.method_43471("gui.touhou_little_maid.model_switcher.direction.north");
        }
    }
}
