package com.github.tartaricacid.simplebedrockmodel.client.bedrock.pojo;

import com.google.gson.annotations.SerializedName;
import javax.annotation.Nullable;
import net.minecraft.class_2350;

public class FaceUVsItem {
    @SerializedName("down")
    private FaceItem down;
    @SerializedName("east")
    private FaceItem east;
    @SerializedName("north")
    private FaceItem north;
    @SerializedName("south")
    private FaceItem south;
    @SerializedName("up")
    private FaceItem up;
    @SerializedName("west")
    private FaceItem west;

    public FaceUVsItem(FaceItem down, FaceItem east, FaceItem north, FaceItem south, FaceItem up, FaceItem west) {
        this.down = down;
        this.east = east;
        this.north = north;
        this.south = south;
        this.up = up;
        this.west = west;
    }

    @Nullable
    public FaceItem getFace(class_2350 direction) {
        return switch (direction) {
            case field_11034 -> west;
            case field_11039 -> east;
            case field_11043 -> north;
            case field_11035 -> south;
            case field_11036 -> down;
            default -> up;
        };
    }
}
