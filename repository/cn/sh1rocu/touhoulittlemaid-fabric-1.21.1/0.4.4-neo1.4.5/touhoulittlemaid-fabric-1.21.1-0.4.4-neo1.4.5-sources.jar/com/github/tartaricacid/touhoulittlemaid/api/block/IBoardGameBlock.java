package com.github.tartaricacid.touhoulittlemaid.api.block;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface IBoardGameBlock {
    /**
     * 女仆尝试游玩坐在棋盘旁边
     */
    void startMaidSit(EntityMaid maid, class_2680 state, class_1937 worldIn, class_2338 pos);
}