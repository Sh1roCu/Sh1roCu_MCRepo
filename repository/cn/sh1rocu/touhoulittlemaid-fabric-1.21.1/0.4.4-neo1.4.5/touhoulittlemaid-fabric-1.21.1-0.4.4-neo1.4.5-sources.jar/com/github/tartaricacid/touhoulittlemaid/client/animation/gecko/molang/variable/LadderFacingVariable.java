package com.github.tartaricacid.touhoulittlemaid.client.animation.gecko.molang.variable;

import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.molang.context.IContext;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.molang.variable.IValueEvaluator;
import java.util.Optional;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2680;

public class LadderFacingVariable implements IValueEvaluator<Integer, IContext<class_1309>> {
    @Override
    public Integer eval(IContext<class_1309> ctx) {
        Optional<class_2338> climbablePos = ctx.entity().method_24832();
        if (climbablePos.isPresent()) {
            class_2680 blockState = ctx.entity().method_37908().method_8320(climbablePos.get());
            Optional<class_2350> optionalValue = blockState.method_28500(class_2383.field_11177);
            if (optionalValue.isPresent()) {
                // 输出数字 0-3，分别对应：南-西-北-东
                return optionalValue.get().method_10161();
            }
        }
        return 0;
    }
}
