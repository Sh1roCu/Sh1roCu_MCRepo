package com.github.tartaricacid.touhoulittlemaid.client.animation.special;

import com.github.tartaricacid.touhoulittlemaid.api.animation.ICustomAnimation;
import net.minecraft.class_1308;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

public class SwimAnimation implements ICustomAnimation<class_1308> {
    @Override
    public void setupRotations(class_1308 mob, class_4587 poseStack, float ageInTicks, float rotationYaw, float partialTicks) {
        // TODO
        //boolean inSwimFluidType = mob.isInFluidType((type, height) -> mob.canSwimInFluidType(type));
        //boolean inSwim = mob.isInWater() || inSwimFluidType;
        boolean inSwim = mob.method_5799() || mob.method_5681();
        float xRot = 90 + (inSwim ? mob.method_36455() : 0);
        float xRotLerp = class_3532.method_16439(mob.method_6024(partialTicks), 0, -xRot);
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(xRotLerp));
        if (mob.method_20232()) {
            poseStack.method_46416(0F, -1F, 0.3F);
        }
    }
}
