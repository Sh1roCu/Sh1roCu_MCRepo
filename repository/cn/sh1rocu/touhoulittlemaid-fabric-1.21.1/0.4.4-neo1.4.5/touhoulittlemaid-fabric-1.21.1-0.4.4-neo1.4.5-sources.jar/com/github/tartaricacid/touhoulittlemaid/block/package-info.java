@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.tartaricacid.touhoulittlemaid.block;

import javax.annotation.ParametersAreNonnullByDefault;