package com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button;

import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_4185;

public class ButtonWithId extends class_4185 {
    private final Consumer<Integer> onClick;
    private final int id;

    public ButtonWithId(int id, int x, int y, int width, int height, class_2561 title, Consumer<Integer> onClick) {
/*        super(Button.builder(title, (b) -> {
        }).pos(x, y).size(width, height));*/
        super(x, y, width, height, title, b -> {
        }, class_4185.field_40754);
        this.id = id;
        this.onClick = onClick;
    }

    @Override
    public void method_25306() {
        super.method_25306();
        this.onClick.accept(this.id);
    }
}
