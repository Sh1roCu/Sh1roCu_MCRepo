/*
 * https://github.com/anlingyi/xechat-idea
 *
 *        Apache License
 *   Version 2.0, January 2004
 * http://www.apache.org/licenses/
 */
package com.github.tartaricacid.touhoulittlemaid.api.game.gomoku;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2487;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * 棋子点位
 *
 * @author anlingyi
 * @date 2021/11/7 5:59 下午
 */
public class Point {
    public static final int EMPTY = 0;
    public static final int BLACK = 1;
    public static final int WHITE = 2;
    public static final Point NULL = new Point(-1, -1, 0);
    public static final class_9139<ByteBuf, Point> POINT_STREAM_CODEC = class_9139.method_56436(
            class_9135.field_49675, Point::getX,
            class_9135.field_49675, Point::getY,
            class_9135.field_49675, Point::getType,
            Point::new
    );
    /**
     * 横坐标
     */
    public final int x;
    /**
     * 纵坐标
     */
    public final int y;
    /**
     * 棋子类型 1.黑 2.白
     */
    public int type;
    /**
     * 得分
     */
    public int score;

    public Point(int x, int y, int type) {
        this.x = x;
        this.y = y;
        this.type = type;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getType() {
        return type;
    }

    public static class_2487 toTag(Point point) {
        class_2487 tag = new class_2487();
        tag.method_10569("x", point.x);
        tag.method_10569("y", point.y);
        tag.method_10569("type", point.type);
        return tag;
    }

    public static Point fromTag(class_2487 tag) {
        int x = tag.method_10550("x");
        int y = tag.method_10550("y");
        int type = tag.method_10550("type");
        return new Point(x, y, type);
    }

    @Override
    public boolean equals(Object other) {
        if (other == null) {
            return false;
        } else if (this == other) {
            return true;
        } else if (other instanceof Point otherPoint) {
            return otherPoint.x == this.x && otherPoint.y == this.y && otherPoint.type == this.type;
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        return (type == 1 ? "Black" : "White") + "[" + x + "," + y + ']';
    }
}
