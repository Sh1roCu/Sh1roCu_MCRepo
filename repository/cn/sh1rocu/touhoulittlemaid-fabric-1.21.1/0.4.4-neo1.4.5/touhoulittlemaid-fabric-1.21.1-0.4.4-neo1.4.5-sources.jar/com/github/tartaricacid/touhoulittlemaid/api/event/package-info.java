@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.tartaricacid.touhoulittlemaid.api.event;

import javax.annotation.ParametersAreNonnullByDefault;