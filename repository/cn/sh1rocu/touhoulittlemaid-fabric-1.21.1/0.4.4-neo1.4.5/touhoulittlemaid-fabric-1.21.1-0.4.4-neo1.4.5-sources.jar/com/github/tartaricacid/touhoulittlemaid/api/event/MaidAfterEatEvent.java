package com.github.tartaricacid.touhoulittlemaid.api.event;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1799;

public class MaidAfterEatEvent {
    private final EntityMaid maid;
    private final class_1799 foodAfterEat;

    public MaidAfterEatEvent(EntityMaid maid, class_1799 foodAfterEat) {
        this.maid = maid;
        this.foodAfterEat = foodAfterEat;
    }

    public EntityMaid getMaid() {
        return maid;
    }

    public class_1799 getFoodAfterEat() {
        return foodAfterEat;
    }

    public static final Event<Callback> CALLBACK = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.post(event);
        }
    });

    public interface Callback {
        void post(MaidAfterEatEvent event);
    }
}
