@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.tartaricacid.touhoulittlemaid.advancements.maid;

import javax.annotation.ParametersAreNonnullByDefault;