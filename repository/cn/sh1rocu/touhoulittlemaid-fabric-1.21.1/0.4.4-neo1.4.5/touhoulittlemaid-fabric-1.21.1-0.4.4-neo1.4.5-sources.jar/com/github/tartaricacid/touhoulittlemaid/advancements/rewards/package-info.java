@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.tartaricacid.touhoulittlemaid.advancements.rewards;

import javax.annotation.ParametersAreNonnullByDefault;