@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package com.github.tartaricacid.touhoulittlemaid.advancements.altar;

import javax.annotation.ParametersAreNonnullByDefault;