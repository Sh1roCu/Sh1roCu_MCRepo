package com.github.tartaricacid.touhoulittlemaid.block.properties;

import org.jetbrains.annotations.NotNull;

import java.util.Locale;
import net.minecraft.class_3542;

public enum PicnicMatPart implements class_3542 {
    CENTER,
    SIDE;

    @Override
    public @NotNull String method_15434() {
        return this.name().toLowerCase(Locale.US);
    }

    public boolean isCenter() {
        return this == CENTER;
    }
}
