package com.github.tartaricacid.touhoulittlemaid.client.event;

import com.github.tartaricacid.touhoulittlemaid.init.InitItems;
import com.github.tartaricacid.touhoulittlemaid.item.ItemWirelessIO;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4588;
import net.minecraft.class_761;

@Environment(EnvType.CLIENT)
public final class WirelessIORenderEvent {
    // after block entities
    public static void onRender(WorldRenderContext context) {
        //if (event.getStage() == RenderLevelStageEvent.Stage.AFTER_BLOCK_ENTITIES) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) {
            return;
        }
        class_1799 mainStack = mc.field_1724.method_6047();
        if (mainStack.method_7909() != InitItems.WIRELESS_IO) {
            return;
        }
        class_2338 pos = ItemWirelessIO.getBindingPos(mainStack);
        if (pos == null) {
            return;
        }
        class_243 position = context.camera().method_19326().method_22882();
        class_238 aabb = new class_238(pos).method_997(position);
        class_4588 buffer = mc.method_22940().method_23000().getBuffer(class_1921.field_21695);
        class_761.method_22982(context.matrixStack(), buffer, aabb, 1.0F, 0, 0, 1.0F);
        //}
    }
}
