package com.github.tartaricacid.touhoulittlemaid.api.entity.fishing;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.entity.projectile.MaidFishingHook;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3486;

public interface IFishingType {
    /**
     * 是否持有合适的鱼竿
     */
    boolean isFishingRod(class_1799 itemStack);

    /**
     * 检查该方块是否适合放置钓鱼钩
     */
    default boolean suitableFishingHook(EntityMaid maid, class_1937 worldIn, class_1799 rod, class_2338 blockPos) {
        return worldIn.method_8316(blockPos).method_15767(class_3486.field_15517);
    }

    /**
     * 获取鱼钩实体
     */
    MaidFishingHook getFishingHook(EntityMaid maid, class_1937 level, class_1799 itemStack, class_243 pos);
}
