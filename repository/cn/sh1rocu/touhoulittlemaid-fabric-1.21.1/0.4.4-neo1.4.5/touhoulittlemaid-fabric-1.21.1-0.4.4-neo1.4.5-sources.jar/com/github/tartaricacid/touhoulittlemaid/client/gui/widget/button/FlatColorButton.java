package com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button;

import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.Collections;
import java.util.List;


public class FlatColorButton extends class_4185 {
    private List<class_2561> tooltips;
    protected boolean isSelect = false;

    public FlatColorButton(int pX, int pY, int pWidth, int pHeight, class_2561 pMessage, class_4241 pOnPress) {
        super(pX, pY, pWidth, pHeight, pMessage, pOnPress, field_40754);
    }

    public FlatColorButton setTooltips(String key) {
        tooltips = Collections.singletonList(class_2561.method_43471(key));
        return this;
    }

    public FlatColorButton setTooltips(List<class_2561> tooltips) {
        this.tooltips = tooltips;
        return this;
    }

    public void renderToolTip(class_332 graphics, class_437 screen, int pMouseX, int pMouseY) {
        if (this.field_22762 && tooltips != null) {
            graphics.method_51434(Screens.getClient(screen).field_1772, tooltips, pMouseX, pMouseY);
        }
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float pPartialTick) {
        class_310 minecraft = class_310.method_1551();
        if (isSelect) {
            graphics.method_25296(this.method_46426(), this.method_46427(), this.method_46426() + this.field_22758, this.method_46427() + this.field_22759, 0xff_1E90FF, 0xff_1E90FF);
        } else {
            graphics.method_25296(this.method_46426(), this.method_46427(), this.method_46426() + this.field_22758, this.method_46427() + this.field_22759, 0xff_434242, 0xff_434242);
        }
        if (this.method_25367()) {
            graphics.method_25296(this.method_46426(), this.method_46427() + 1, this.method_46426() + 1, this.method_46427() + this.field_22759 - 1, 0xff_F3EFE0, 0xff_F3EFE0);
            graphics.method_25296(this.method_46426(), this.method_46427(), this.method_46426() + this.field_22758, this.method_46427() + 1, 0xff_F3EFE0, 0xff_F3EFE0);
            graphics.method_25296(this.method_46426() + this.field_22758 - 1, this.method_46427() + 1, this.method_46426() + this.field_22758, this.method_46427() + this.field_22759 - 1, 0xff_F3EFE0, 0xff_F3EFE0);
            graphics.method_25296(this.method_46426(), this.method_46427() + this.field_22759 - 1, this.method_46426() + this.field_22758, this.method_46427() + this.field_22759, 0xff_F3EFE0, 0xff_F3EFE0);
        }
        //int i = getFGColor();
        int i = this.field_22763 ? 16777215 : 10526880;
        this.method_48589(graphics, minecraft.field_1772, i | class_3532.method_15386(this.field_22765 * 255.0F) << 24);
    }

    @Override
    public void method_48589(class_332 graphics, class_327 font, int pColor) {
        graphics.method_27534(font, this.method_25369(), this.method_46426() + this.field_22758 / 2, this.method_46427() + (this.field_22759 - 8) / 2, 0xF3EFE0);
    }

    public void setSelect(boolean select) {
        isSelect = select;
    }
}
