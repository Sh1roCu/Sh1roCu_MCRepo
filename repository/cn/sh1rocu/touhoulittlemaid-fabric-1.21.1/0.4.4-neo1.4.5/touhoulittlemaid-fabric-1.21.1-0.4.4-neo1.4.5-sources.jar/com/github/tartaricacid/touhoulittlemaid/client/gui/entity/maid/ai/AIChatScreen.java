package com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.ai;

import cn.sh1rocu.touhoulittlemaid.mixin.accessor.ScreenAccessor;
import com.github.tartaricacid.touhoulittlemaid.ai.manager.entity.ChatClientInfo;
import com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button.FlatColorButton;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.network.message.SendUserChatPackage;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import net.minecraft.class_746;
import org.apache.commons.lang3.StringUtils;
import org.lwjgl.glfw.GLFW;

public class AIChatScreen extends class_437 {
    private final EntityMaid maid;
    private class_342 input;
    private FlatColorButton configButton;
    private int tickCounter = 0;

    public AIChatScreen(EntityMaid maid) {
        super(class_2561.method_43470("Maid AI Chat Screen"));
        this.maid = maid;
    }

    @Override
    protected void method_25426() {
        this.method_37067();

        int posX = this.field_22789 / 2;
        int posY = this.field_22790 / 2;

        this.input = new class_342(Screens.getClient(this).field_39924, posX - 165, posY + 64,
                300, 20, class_2561.method_43471("chat.editBox"));
        this.input.method_1880(128);
        this.input.method_1858(false);
        this.input.method_1852("");
        this.input.method_1856(false);
        this.method_25429(this.input);
        this.method_48265(this.input);

        this.configButton = new FlatColorButton(posX + 142, posY + 58, 20, 20, class_2561.method_43470("✎"),
                b -> {
                    class_746 player = Screens.getClient(this).field_1724;
                    if (player != null) {
                        player.method_43496(class_2561.method_43471("ai.touhou_little_maid.chat.config.tip.under_construction"));
                    }
                }).setTooltips("ai.touhou_little_maid.chat.config.tip");
        this.method_37063(this.configButton);
    }

    @Override
    public void method_25410(class_310 mc, int pWidth, int pHeight) {
        String chatText = this.input.method_1882();
        super.method_25410(mc, pWidth, pHeight);
        this.input.method_1852(chatText);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
        int xOffset = 5;
        int yOffset = 6;
        graphics.method_25294(input.method_46426() - xOffset,
                input.method_46427() - yOffset,
                input.method_46426() + input.method_1859() + xOffset,
                input.method_46427() + input.method_25364() - yOffset,
                0x9f_000000);
        input.method_25394(graphics, mouseX, mouseY, partialTicks);

        if (StringUtils.isEmpty(input.method_1882())) {
            class_5250 text = class_2561.method_43471("ai.touhou_little_maid.chat.input.tip").method_27695(class_124.field_1080, class_124.field_1056);
            int xPos = input.method_46426() + input.method_1859() / 2 - xOffset;
            graphics.method_27534(field_22793, text, xPos, input.method_46427(), 0xFFFFFF);
        }

        for (class_4068 renderable : ((ScreenAccessor) this).tlm$getRenderables()) {
            renderable.method_25394(graphics, mouseX, mouseY, partialTicks);
        }
        this.configButton.renderToolTip(graphics, this, mouseX, mouseY);
    }

    @Override
    public void method_25393() {
        tickCounter++;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (this.input.method_25402(mouseX, mouseY, button)) {
            this.method_25395(this.input);
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25400(char pCodePoint, int pModifiers) {
        // GUI 刚打开的 5 tick 内，不允许输入，否则会把按键录入
        if (tickCounter < 5) {
            return false;
        }
        return super.method_25400(pCodePoint, pModifiers);
    }

    @Override
    protected void method_25415(String text, boolean overwrite) {
        if (overwrite) {
            this.input.method_1852(text);
        } else {
            this.input.method_1867(text);
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER) {
            sendDoneMessage();
            return true;
        } else {
            return super.method_25404(keyCode, scanCode, modifiers);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private void sendDoneMessage() {
        String value = input.method_1882();
        class_746 player = Screens.getClient(this).field_1724;
        if (StringUtils.isNotBlank(value) && player != null) {
            ChatClientInfo clientInfo = ChatClientInfo.fromMaid(this.maid);
            ClientPlayNetworking.send(new SendUserChatPackage(this.maid.method_5628(), value, clientInfo));
            String name = player.method_5820();
            String format = String.format("<%s> %s", name, value);
            player.method_43496(class_2561.method_43470(format).method_27692(class_124.field_1080));
        }
        this.method_25419();
    }
}
