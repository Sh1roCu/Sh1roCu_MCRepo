package com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button;

import com.github.tartaricacid.touhoulittlemaid.TouhouLittleMaid;
import com.github.tartaricacid.touhoulittlemaid.api.client.gui.ITooltipButton;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;

/**
 * 女仆界面侧边栏按钮
 */
public class MaidSideTabButton extends class_4185 implements ITooltipButton {
    private static final class_2960 SIDE = class_2960.method_60655(TouhouLittleMaid.MOD_ID, "textures/gui/maid_gui_side.png");
    private static final int V_OFFSET = 107;
    private final List<class_2561> tooltips;
    private final int top;

    public MaidSideTabButton(int x, int y, int top, class_4241 onPressIn, List<class_2561> tooltips) {
        //super(Button.builder(Component.empty(), onPressIn).pos(x, y).size(26, 24));
        super(x, y, 26, 24, class_2561.method_43473(), onPressIn, class_4185.field_40754);
        this.top = V_OFFSET + top;
        this.tooltips = tooltips;
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
        RenderSystem.enableDepthTest();
        if (!this.field_22763) {
            graphics.method_25290(SIDE, this.method_46426() + 2, this.method_46427(), 209, top, this.field_22758, this.field_22759, 256, 256);
        }
        // 193, 111
        graphics.method_25290(SIDE, this.method_46426() + 6, this.method_46427() + 4, 193, top + 4, 16, 16, 256, 256);
    }

    @Override
    public boolean isTooltipHovered() {
        return this.method_49606();
    }

    @Override
    public void renderTooltip(class_332 graphics, class_310 mc, int mouseX, int mouseY) {
        graphics.method_51434(mc.field_1772, this.tooltips, mouseX, mouseY);
    }
}