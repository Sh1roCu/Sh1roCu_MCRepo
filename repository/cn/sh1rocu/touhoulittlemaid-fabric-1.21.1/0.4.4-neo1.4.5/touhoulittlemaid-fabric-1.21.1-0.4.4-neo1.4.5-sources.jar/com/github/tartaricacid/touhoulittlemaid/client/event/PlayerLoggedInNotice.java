package com.github.tartaricacid.touhoulittlemaid.client.event;

import cn.sh1rocu.touhoulittlemaid.api.event.PlayerLoggedInEvent;
import com.github.tartaricacid.touhoulittlemaid.init.registry.CompatRegistry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.network.chat.*;

@Environment(EnvType.CLIENT)
public class PlayerLoggedInNotice {
    private static boolean notFirst = false;

    public static void onEnterGame(PlayerLoggedInEvent event) {
        boolean missingPatchouli = !FabricLoader.getInstance().isModLoaded(CompatRegistry.PATCHOULI);
        if (notFirst) {
            return;
        }
        if (missingPatchouli) {
            class_5250 title = class_2561.method_43471("message.touhou_little_maid.missing_patchouli.title")
                    .method_27694(style -> style.method_10977(class_124.field_1060).method_10982(true));
            class_2558 clickEvent = new class_2558(class_2558.class_2559.field_11749, class_1074.method_4662("message.touhou_little_maid.missing_patchouli.url"));
            class_2568 hoverEvent = new class_2568(class_2568.class_5247.field_24342, class_2561.method_43471("message.touhou_little_maid.missing_patchouli.url"));
            class_5250 base = class_2561.method_43471("message.touhou_little_maid.missing_patchouli.click_here")
                    .method_27694(style -> style.method_10977(class_124.field_1065).method_10982(false).method_30938(true).method_10958(clickEvent).method_10949(hoverEvent));
            event.getEntity().method_43496(title.method_10852(class_5244.field_41874).method_10852(base));
        }
        notFirst = true;
    }
}
