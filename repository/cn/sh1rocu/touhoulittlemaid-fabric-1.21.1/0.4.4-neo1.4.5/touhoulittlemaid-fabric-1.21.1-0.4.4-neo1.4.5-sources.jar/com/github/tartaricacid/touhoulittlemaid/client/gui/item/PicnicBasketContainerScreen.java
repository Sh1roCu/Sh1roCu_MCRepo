package com.github.tartaricacid.touhoulittlemaid.client.gui.item;

import com.github.tartaricacid.touhoulittlemaid.inventory.container.other.PicnicBasketContainer;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;

public class PicnicBasketContainerScreen extends class_465<PicnicBasketContainer> {
    private static final class_2960 CONTAINER_BACKGROUND = class_2960.method_60656("textures/gui/container/generic_54.png");

    public PicnicBasketContainerScreen(PicnicBasketContainer container, class_1661 inv, class_2561 titleIn) {
        super(container, inv, titleIn);
        this.field_2779 = 132;
        this.field_25270 = this.field_2779 - 94;
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        this.method_2380(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        int middleX = (this.field_22789 - this.field_2792) / 2;
        int middleY = (this.field_22790 - this.field_2779) / 2;
        guiGraphics.method_25302(CONTAINER_BACKGROUND, middleX, middleY, 0, 0, this.field_2792, 35);
        guiGraphics.method_25302(CONTAINER_BACKGROUND, middleX, middleY + 35, 0, 126, this.field_2792, 96);
    }
}
