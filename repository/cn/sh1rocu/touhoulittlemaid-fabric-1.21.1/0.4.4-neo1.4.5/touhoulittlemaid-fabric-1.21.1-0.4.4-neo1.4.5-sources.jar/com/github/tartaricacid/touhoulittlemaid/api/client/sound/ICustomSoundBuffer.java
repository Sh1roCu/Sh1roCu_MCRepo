package com.github.tartaricacid.touhoulittlemaid.api.client.sound;

import javax.annotation.Nullable;
import net.minecraft.class_4231;

/**
 * 用来标记女仆模组拥有自定义 Sound Buffer 的音频
 */
public interface ICustomSoundBuffer {
    /**
     * 获取 Sound Buffer
     *
     * @return 可能为 null，当为 null 时，不进行音频播放
     */
    @Nullable
    class_4231 getSoundBuffer();
}