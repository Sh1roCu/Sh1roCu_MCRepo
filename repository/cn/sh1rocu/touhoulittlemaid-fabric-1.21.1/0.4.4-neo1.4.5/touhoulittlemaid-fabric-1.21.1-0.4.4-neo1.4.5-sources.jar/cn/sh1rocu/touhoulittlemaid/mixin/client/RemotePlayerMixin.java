package cn.sh1rocu.touhoulittlemaid.mixin.client;

import cn.sh1rocu.touhoulittlemaid.api.event.LivingAttackEvent;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_745;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_745.class)
public abstract class RemotePlayerMixin {
    @Inject(method = "hurt", at = @At("HEAD"))
    public void tlm$attackEvent(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        LivingAttackEvent event = new LivingAttackEvent((class_1309) (Object) this, source, amount);
        LivingAttackEvent.CALLBACK.invoker().onLivingAttack(event);
    }
}