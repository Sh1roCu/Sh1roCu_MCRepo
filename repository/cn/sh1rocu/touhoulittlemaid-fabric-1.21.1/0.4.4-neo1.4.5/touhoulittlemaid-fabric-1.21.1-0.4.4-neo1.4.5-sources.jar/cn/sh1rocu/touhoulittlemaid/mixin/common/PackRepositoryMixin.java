package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.api.mixin.PackRepositoryExtension;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;

import java.util.LinkedHashSet;
import java.util.Set;
import net.minecraft.class_3283;
import net.minecraft.class_3285;

@Mixin(class_3283.class)
public class PackRepositoryMixin implements PackRepositoryExtension {
    @Mutable
    @Shadow
    @Final
    private Set<class_3285> sources;

    @Override
    public synchronized void tlm$addPackFinder(class_3285 packFinder) {
        if (!(this.sources instanceof LinkedHashSet)) {
            this.sources = new LinkedHashSet<>(this.sources);
        }
        this.sources.add(packFinder);
    }
}