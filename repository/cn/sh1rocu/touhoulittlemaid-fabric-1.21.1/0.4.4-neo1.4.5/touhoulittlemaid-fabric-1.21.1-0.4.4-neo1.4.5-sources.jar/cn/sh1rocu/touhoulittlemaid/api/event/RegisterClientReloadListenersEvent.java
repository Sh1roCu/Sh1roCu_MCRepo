package cn.sh1rocu.touhoulittlemaid.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_3302;
import net.minecraft.class_3304;

// 用于SimpleBedrockModel
public class RegisterClientReloadListenersEvent {
    private final class_3304 resourceManager;

    public static final Event<Callback> CALLBACK = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.post(event);
        }
    });

    public interface Callback {
        void post(RegisterClientReloadListenersEvent event);
    }

    public RegisterClientReloadListenersEvent(class_3304 resourceManager) {
        this.resourceManager = resourceManager;
    }

    public void registerReloadListener(class_3302 reloadListener) {
        resourceManager.method_14477(reloadListener);
    }
}
