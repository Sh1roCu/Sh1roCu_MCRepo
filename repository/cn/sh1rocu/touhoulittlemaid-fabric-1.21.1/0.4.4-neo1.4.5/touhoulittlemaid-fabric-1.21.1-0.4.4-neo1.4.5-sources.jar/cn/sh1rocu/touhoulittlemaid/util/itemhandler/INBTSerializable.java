package cn.sh1rocu.touhoulittlemaid.util.itemhandler;

import net.minecraft.class_2520;
import net.minecraft.class_7225;
import org.jetbrains.annotations.UnknownNullability;

public interface INBTSerializable<T extends class_2520> {
    @UnknownNullability
    T serializeNBT(class_7225.class_7874 provider);

    void deserializeNBT(class_7225.class_7874 provider, T nbt);
}
