package cn.sh1rocu.touhoulittlemaid.api.event;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;

@Environment(EnvType.CLIENT)
public class RenderHandEvent extends CancellableEvent {
    private final class_742 player;
    private final class_1268 hand;
    private final class_1799 stack;
    private final class_4587 matrices;
    private final class_4597 vertexConsumers;
    private final float tickDelta;
    private final float pitch;
    private final float swingProgress;
    private final float equipProgress;
    private final int light;

    public static final Event<Callback> CALLBACK = EventFactory.createArrayBacked(Callback.class, callbacks -> (handEvent) -> {
        for (Callback callback : callbacks) {
            callback.post(handEvent);
        }
    });

    public RenderHandEvent(class_742 player, class_1268 hand, class_1799 stack, class_4587 matrices, class_4597 vertexConsumers, float tickDelta, float pitch, float swingProgress, float equipProgress, int light) {
        this.player = player;
        this.hand = hand;
        this.stack = stack;
        this.matrices = matrices;
        this.vertexConsumers = vertexConsumers;
        this.tickDelta = tickDelta;
        this.pitch = pitch;
        this.swingProgress = swingProgress;
        this.equipProgress = equipProgress;
        this.light = light;
    }

    public class_742 getPlayer() {
        return player;
    }

    public class_1799 getItemStack() {
        return stack;
    }

    public class_4587 getPoseStack() {
        return matrices;
    }

    public class_4597 getMultiBufferSource() {
        return vertexConsumers;
    }

    public int getPackedLight() {
        return light;
    }

    public float getPartialTicks() {
        return tickDelta;
    }

    public class_1268 getHand() {
        return hand;
    }

    public float getPitch() {
        return pitch;
    }

    public float getEquipProgress() {
        return equipProgress;
    }

    public float getSwingProgress() {
        return swingProgress;
    }

    public interface Callback {
        void post(RenderHandEvent event);
    }
}