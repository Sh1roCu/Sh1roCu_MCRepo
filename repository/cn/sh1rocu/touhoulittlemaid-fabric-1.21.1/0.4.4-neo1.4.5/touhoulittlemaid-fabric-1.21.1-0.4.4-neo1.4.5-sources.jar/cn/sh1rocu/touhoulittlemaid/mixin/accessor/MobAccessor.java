package cn.sh1rocu.touhoulittlemaid.mixin.accessor;

import net.minecraft.class_1308;
import net.minecraft.class_1355;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1308.class)
public interface MobAccessor {
    @Accessor("goalSelector")
    class_1355 tlm$goalSelector();
}
