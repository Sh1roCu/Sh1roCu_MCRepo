package cn.sh1rocu.touhoulittlemaid.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

public class LivingEntityUseItemFinishEvent {
    private final class_1309 entity;
    private final class_1799 item;
    private int duration;
    private class_1799 result;

    public class_1309 getEntity() {
        return entity;
    }

    public class_1799 getItem() {
        return item;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public class_1799 getResultStack() {
        return result;
    }

    public void setResultStack(class_1799 result) {
        this.result = result;
    }

    public static final Event<Callback> CALLBACK = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks)
            callback.post(event);
    });


    public LivingEntityUseItemFinishEvent(class_1309 entity, class_1799 item, int duration, class_1799 result) {
        this.entity = entity;
        this.item = item;
        this.duration = duration;
        this.setResultStack(result);
    }

    public interface Callback {
        void post(LivingEntityUseItemFinishEvent event);
    }
}