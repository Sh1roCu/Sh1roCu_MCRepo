package cn.sh1rocu.touhoulittlemaid.util.enchant;

import net.fabricmc.fabric.api.item.v1.EnchantingContext;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_7924;

public class EnchantmentUtil {
    public static boolean canEnchant(class_1799 stack, class_5321<class_1887> key, class_5455 registryAccess) {
        class_2378<class_1887> registry = registryAccess.method_30530(class_7924.field_41265);
        class_1887 enchantment = registry.method_29107(key);
        return (enchantment != null && enchantment.method_8192(stack)) ||
                stack.canBeEnchantedWith(registry.method_40264(key).orElseThrow(), EnchantingContext.ACCEPTABLE);
    }
}
