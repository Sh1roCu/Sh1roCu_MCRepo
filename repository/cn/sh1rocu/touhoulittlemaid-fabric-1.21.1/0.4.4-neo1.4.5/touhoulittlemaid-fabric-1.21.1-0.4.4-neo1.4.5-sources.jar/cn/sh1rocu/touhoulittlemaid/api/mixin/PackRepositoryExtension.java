package cn.sh1rocu.touhoulittlemaid.api.mixin;

import net.minecraft.class_3285;

public interface PackRepositoryExtension {
    default void tlm$addPackFinder(class_3285 packFinder) {
        throw new RuntimeException("PackRepository implementation does not support adding sources!");
    }
}