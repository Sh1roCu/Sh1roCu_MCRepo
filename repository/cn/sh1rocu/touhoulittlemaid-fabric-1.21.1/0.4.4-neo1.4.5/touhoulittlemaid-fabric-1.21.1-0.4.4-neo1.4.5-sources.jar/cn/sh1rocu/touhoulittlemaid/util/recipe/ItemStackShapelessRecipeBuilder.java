package cn.sh1rocu.touhoulittlemaid.util.recipe;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_161;
import net.minecraft.class_170;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1867;
import net.minecraft.class_1935;
import net.minecraft.class_2119;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_5797;
import net.minecraft.class_6862;
import net.minecraft.class_7800;
import net.minecraft.class_8782;
import net.minecraft.class_8790;

public class ItemStackShapelessRecipeBuilder implements class_5797 {
    private final class_7800 category;
    private final class_1799 resultStack;
    private final class_2371<class_1856> ingredients = class_2371.method_10211();
    private final Map<String, class_175<?>> criteria = new LinkedHashMap<>();
    @Nullable
    private String group;

    public ItemStackShapelessRecipeBuilder(class_7800 category, class_1799 resultStack) {
        this.category = category;
        this.resultStack = resultStack;
    }

    public static ItemStackShapelessRecipeBuilder shapeless(class_7800 category, class_1799 resultStack) {
        return new ItemStackShapelessRecipeBuilder(category, resultStack);
    }

    public ItemStackShapelessRecipeBuilder requires(class_6862<class_1792> tag) {
        return this.requires(class_1856.method_8106(tag));
    }

    public ItemStackShapelessRecipeBuilder requires(class_1935 item) {
        return this.requires(item, 1);
    }

    public ItemStackShapelessRecipeBuilder requires(class_1935 item, int quantity) {
        for (int i = 0; i < quantity; ++i) {
            this.requires(class_1856.method_8091(item));
        }

        return this;
    }

    public ItemStackShapelessRecipeBuilder requires(class_1856 ingredient) {
        return this.requires(ingredient, 1);
    }

    public ItemStackShapelessRecipeBuilder requires(class_1856 ingredient, int quantity) {
        for (int i = 0; i < quantity; ++i) {
            this.ingredients.add(ingredient);
        }

        return this;
    }

    public @NotNull ItemStackShapelessRecipeBuilder method_33530(@NotNull String name, @NotNull class_175<?> criterion) {
        this.criteria.put(name, criterion);
        return this;
    }

    public @NotNull ItemStackShapelessRecipeBuilder method_33529(@Nullable String groupName) {
        this.group = groupName;
        return this;
    }

    @Override
    public @NotNull class_1792 method_36441() {
        return resultStack.method_7909();
    }

    @Override
    public void method_17972(class_8790 recipeOutput, @NotNull class_2960 id) {
        this.ensureValid(id);
        class_161.class_162 builder = recipeOutput.method_53818()
                .method_705("has_the_recipe", class_2119.method_27847(id))
                .method_703(class_170.class_171.method_753(id))
                .method_704(class_8782.class_8797.field_1257);
        this.criteria.forEach(builder::method_705);
        class_1867 shapelessrecipe = new class_1867(
                Objects.requireNonNullElse(this.group, ""),
                class_5797.method_55308(this.category),
                this.resultStack,
                this.ingredients
        );
        recipeOutput.method_53819(id, shapelessrecipe, builder.method_695(id.method_45138("recipes/" + this.category.method_46203() + "/")));
    }

    private void ensureValid(class_2960 id) {
        if (this.criteria.isEmpty()) {
            throw new IllegalStateException("No way of obtaining recipe " + id);
        }
    }
}
