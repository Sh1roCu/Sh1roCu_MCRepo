package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.api.event.AddPackFindersEvent;
import cn.sh1rocu.touhoulittlemaid.api.mixin.PackRepositoryExtension;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.nio.file.Path;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_3286;
import net.minecraft.class_8580;

@Mixin(class_3286.class)
public class ServerPacksSourceMixin {
    @Inject(method = "createPackRepository(Ljava/nio/file/Path;Lnet/minecraft/world/level/validation/DirectoryValidator;)Lnet/minecraft/server/packs/repository/PackRepository;", at = @At("RETURN"))
    private static void tlm$addPacks(Path folder, class_8580 validator, CallbackInfoReturnable<class_3283> cir) {
        AddPackFindersEvent event = new AddPackFindersEvent(class_3264.field_14190, ((PackRepositoryExtension) cir.getReturnValue())::tlm$addPackFinder, false);
        AddPackFindersEvent.CALLBACK.invoker().onAddPackFinders(event);
    }

    @Inject(method = "createVanillaTrustedRepository", at = @At("RETURN"))
    private static void tlm$addPacks(CallbackInfoReturnable<class_3283> cir) {
        AddPackFindersEvent event = new AddPackFindersEvent(class_3264.field_14190, ((PackRepositoryExtension) cir.getReturnValue())::tlm$addPackFinder, false);
        AddPackFindersEvent.CALLBACK.invoker().onAddPackFinders(event);
    }
}
