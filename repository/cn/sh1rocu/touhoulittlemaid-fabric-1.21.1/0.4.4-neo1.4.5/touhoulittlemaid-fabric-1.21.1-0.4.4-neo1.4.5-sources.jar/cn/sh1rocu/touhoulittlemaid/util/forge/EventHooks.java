package cn.sh1rocu.touhoulittlemaid.util.forge;

import cn.sh1rocu.touhoulittlemaid.api.event.*;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1311;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_5483;
import net.minecraft.class_6012;

public class EventHooks {
    private static final class_6012<class_5483.class_1964> NO_SPAWNS = class_6012.method_34990();

    public static class_6012<class_5483.class_1964> getPotentialSpawns(class_1936 level, class_1311 category, class_2338 pos, class_6012<class_5483.class_1964> oldList) {
        PotentialSpawnsEvent event = new PotentialSpawnsEvent(level, category, pos, oldList);
        PotentialSpawnsEvent.CALLBACK.invoker().post(event);
        if (event.isCanceled())
            return NO_SPAWNS;
        else if (event.getSpawnerDataList() == oldList.method_34994())
            return oldList;
        return class_6012.method_34988(event.getSpawnerDataList());
    }

    public static boolean canMountEntity(class_1297 entityMounting, class_1297 entityBeingMounted, boolean isMounting) {
        EntityMountEvent event = new EntityMountEvent(entityMounting, entityBeingMounted, entityMounting.method_37908(), isMounting);
        EntityMountEvent.CALLBACK.invoker().post(event);
        if (event.isCanceled()) {
            entityMounting.method_5641(entityMounting.method_23317(), entityMounting.method_23318(), entityMounting.method_23321(), entityMounting.field_5982, entityMounting.field_6004);
            return false;
        } else
            return true;
    }

    public static class_1799 onItemUseFinish(class_1309 entity, class_1799 item, int duration, class_1799 result) {
        LivingEntityUseItemFinishEvent event = new LivingEntityUseItemFinishEvent(entity, item, duration, result);
        LivingEntityUseItemFinishEvent.CALLBACK.invoker().post(event);
        return event.getResultStack();
    }

    public static void firePlayerTickPre(class_1657 player) {
        PlayerTickEvent.START.invoker().onStart(new PlayerTickEvent.Pre(player));
    }

    public static void firePlayerTickPost(class_1657 player) {
        PlayerTickEvent.END.invoker().onEnd(new PlayerTickEvent.Post(player));
    }

    public static boolean onProjectileImpact(class_1676 projectile, class_239 ray) {
        ProjectileImpactEvent event = new ProjectileImpactEvent(projectile, ray);
        ProjectileImpactEvent.CALLBACK.invoker().post(event);
        return event.isCanceled();
    }
}
