package cn.sh1rocu.touhoulittlemaid.api.extension;

import net.minecraft.class_1799;
import net.minecraft.class_239;

public interface IPickedResult {
    class_1799 getPickedResult(class_239 target);
}
