package cn.sh1rocu.touhoulittlemaid.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.io.File;
import net.minecraft.class_26;

@Mixin(class_26.class)
public interface DimensionDataStorageAccessor {
    @Accessor("dataFolder")
    File tlm$getDataFolder();
}
