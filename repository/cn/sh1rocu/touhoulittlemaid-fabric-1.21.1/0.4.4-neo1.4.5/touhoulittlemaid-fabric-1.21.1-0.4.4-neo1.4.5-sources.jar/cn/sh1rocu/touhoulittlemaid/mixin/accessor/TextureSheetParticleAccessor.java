package cn.sh1rocu.touhoulittlemaid.mixin.accessor;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_4003;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(EnvType.CLIENT)
@Mixin(class_4003.class)
public interface TextureSheetParticleAccessor {
    @Invoker("setSprite")
    void tlm$setSprite(class_1058 sprite);
}
