package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.api.event.PlayerLoggedInEvent;
import net.minecraft.class_2535;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_8792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3324.class)
public abstract class PlayerListMixin {
    @Inject(method = "placeNewPlayer", at = @At("TAIL"))
    private void tlm$playerLoggedIn(class_2535 connection, class_3222 serverPlayer, class_8792 cookie, CallbackInfo ci) {
        PlayerLoggedInEvent event = new PlayerLoggedInEvent(serverPlayer);
        PlayerLoggedInEvent.CALLBACK.invoker().post(event);
    }
}