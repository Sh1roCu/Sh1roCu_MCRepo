package cn.sh1rocu.touhoulittlemaid.util.itemhandler;

import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

public class PlayerMainInvWrapper extends RangedWrapper {
    private final class_1661 inventoryPlayer;

    public PlayerMainInvWrapper(class_1661 inv) {
        super(new InvWrapper(inv), 0, inv.field_7547.size());
        inventoryPlayer = inv;
    }

    @Override
    public class_1799 insertItem(int slot, class_1799 stack, boolean simulate) {
        class_1799 rest = super.insertItem(slot, stack, simulate);
        if (rest.method_7947() != stack.method_7947()) {
            // the stack in the slot changed, animate it
            class_1799 inSlot = getStackInSlot(slot);
            if (!inSlot.method_7960()) {
                if (getInventoryPlayer().field_7546.method_37908().field_9236) {
                    inSlot.method_7912(5);
                } else if (getInventoryPlayer().field_7546 instanceof class_3222) {
                    getInventoryPlayer().field_7546.field_7512.method_7623();
                }
            }
        }
        return rest;
    }

    public class_1661 getInventoryPlayer() {
        return inventoryPlayer;
    }
}
