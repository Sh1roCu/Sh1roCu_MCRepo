package cn.sh1rocu.touhoulittlemaid.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_3302;
import net.minecraft.class_3304;

@Mixin(class_3304.class)
public interface ReloadableResourceManagerAccessor {
    @Accessor("listeners")
    List<class_3302> tlm$getListeners();
}
