package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.util.forge.network.IEntityExtension;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_2596;
import net.minecraft.class_2658;
import net.minecraft.class_3222;
import net.minecraft.class_3231;

@Mixin(class_3231.class)
public class ServerEntityMixin {
    @Shadow
    @Final
    private class_1297 entity;

    @Inject(method = "sendPairingData", at = @At(
            value = "INVOKE",
            target = "Ljava/util/function/Consumer;accept(Ljava/lang/Object;)V",
            shift = At.Shift.AFTER,
            ordinal = 0
    ))
    private void tlm$sendComplexSpawnData(class_3222 serverPlayer, Consumer<class_2596<?>> consumer, CallbackInfo ci) {
        if (this.entity instanceof IEntityExtension entityExtension) {
            entityExtension.tlm$sendPairingData(serverPlayer, customPacketPayload -> consumer.accept(new class_2658(customPacketPayload)));
        }
    }
}