package cn.sh1rocu.touhoulittlemaid.util.itemhandler;

import net.minecraft.class_1799;
import net.minecraft.class_2487;
import org.jetbrains.annotations.NotNull;

public class EmptyItemHandler implements IItemHandlerModifiable {
    public static final IItemHandler INSTANCE = new EmptyItemHandler();

    @Override
    public int getSlots() {
        return 0;
    }

    @Override
    public class_1799 getStackInSlot(int slot) {
        return class_1799.field_8037;
    }

    @Override
    public class_1799 insertItem(int slot, class_1799 stack, boolean simulate) {
        return stack;
    }

    @Override
    public class_1799 extractItem(int slot, int amount, boolean simulate) {
        return class_1799.field_8037;
    }

    @Override
    public void setStackInSlot(int slot, class_1799 stack) {
        // nothing to do here
    }

    @Override
    public int getSlotLimit(int slot) {
        return 0;
    }

    @Override
    public boolean isItemValid(int slot, class_1799 stack) {
        return false;
    }

    @Override
    public void readFromNbt(@NotNull class_2487 tag, class_7225.@NotNull class_7874 registryLookup) {

    }

    @Override
    public void writeToNbt(@NotNull class_2487 tag, class_7225.@NotNull class_7874 registryLookup) {

    }
}
