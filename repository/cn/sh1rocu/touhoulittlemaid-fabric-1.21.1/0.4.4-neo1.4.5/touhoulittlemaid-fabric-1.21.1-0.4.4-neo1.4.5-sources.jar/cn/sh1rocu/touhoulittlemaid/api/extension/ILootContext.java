package cn.sh1rocu.touhoulittlemaid.api.extension;

import net.minecraft.class_2960;

public interface ILootContext {
    class_2960 tlm$getQueriedLootTableId();

    void tlm$setQueriedLootTableId(class_2960 queriedLootTableId);
}
