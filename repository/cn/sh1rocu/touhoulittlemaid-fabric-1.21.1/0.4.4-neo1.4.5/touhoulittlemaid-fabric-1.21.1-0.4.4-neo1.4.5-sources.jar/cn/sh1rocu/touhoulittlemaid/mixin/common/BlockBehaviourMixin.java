package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.api.extension.IBlock;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_4970.class)
public class BlockBehaviourMixin {
    @WrapOperation(
            method = "onExplosionHit",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/block/Block;wasExploded(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/Explosion;)V"
            )
    )
    private void tlm$onBlockExploded(class_2248 instance, class_1937 level, class_2338 blockPos, class_1927 explosion, Operation<Void> original, @Local(argsOnly = true) class_2680 state) {
        if (state.method_26204() instanceof IBlock block) {
            block.tlm$onBlockExploded(state, level, blockPos, explosion);
        } else {
            original.call(instance, level, blockPos, explosion);
        }
    }

    @WrapWithCondition(
            method = "onExplosionHit",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/Level;setBlock(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;I)Z"
            )
    )
    private boolean tlm$dontJust2Air(class_1937 level, class_2338 pos, class_2680 airState, int flag, @Local(argsOnly = true) class_2680 state) {
        return !(state.method_26204() instanceof IBlock);
    }
}