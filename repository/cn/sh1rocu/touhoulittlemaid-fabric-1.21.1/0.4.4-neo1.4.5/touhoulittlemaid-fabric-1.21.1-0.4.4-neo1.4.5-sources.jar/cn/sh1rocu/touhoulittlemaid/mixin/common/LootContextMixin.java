package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.api.extension.ILootContext;
import com.github.tartaricacid.touhoulittlemaid.init.InitLootModifier;
import net.minecraft.class_2960;
import net.minecraft.class_47;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_47.class)
public abstract class LootContextMixin implements ILootContext {
    @Unique
    private class_2960 tlm$queriedLootTableId;

    @Override
    public void tlm$setQueriedLootTableId(class_2960 queriedLootTableId) {
        if (this.tlm$queriedLootTableId == null && queriedLootTableId != null)
            this.tlm$queriedLootTableId = queriedLootTableId;
    }

    @Override
    public class_2960 tlm$getQueriedLootTableId() {
        return this.tlm$queriedLootTableId == null ? InitLootModifier.UNKNOWN_LOOT_TABLE : this.tlm$queriedLootTableId;
    }
}