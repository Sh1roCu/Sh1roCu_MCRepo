package cn.sh1rocu.touhoulittlemaid.util.particle;

import cn.sh1rocu.touhoulittlemaid.mixin.accessor.TextureSheetParticleAccessor;
import javax.annotation.Nullable;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_727;

public class ParticleUtil {
    public static class_727 updateSprite(class_727 particle, class_2680 state, @Nullable class_2338 pos) {
        if (pos != null)
            ((TextureSheetParticleAccessor) particle).tlm$setSprite(class_310.method_1551().method_1541().method_3351().method_3339(state));
        return particle;
    }
}
