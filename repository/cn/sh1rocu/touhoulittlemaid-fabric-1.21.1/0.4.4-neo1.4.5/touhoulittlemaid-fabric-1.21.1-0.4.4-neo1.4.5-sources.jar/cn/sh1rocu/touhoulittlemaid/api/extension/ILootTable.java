package cn.sh1rocu.touhoulittlemaid.api.extension;

import net.minecraft.class_2960;

public interface ILootTable {
    class_2960 tlm$getLootTableId();

    void tlm$setLootTableId(class_2960 id);
}