package cn.sh1rocu.touhoulittlemaid.util.itemhandler;

import net.minecraft.class_1799;
import org.ladysnake.cca.api.v3.component.sync.AutoSyncedComponent;

public interface IItemHandler extends AutoSyncedComponent {
    String TAG_INVENTORY = "Inventory";

    int getSlots();

    class_1799 getStackInSlot(int slot);

    class_1799 insertItem(int slot, class_1799 stack, boolean simulate);

    class_1799 extractItem(int slot, int amount, boolean simulate);

    int getSlotLimit(int slot);

    boolean isItemValid(int slot, class_1799 stack);
}