package cn.sh1rocu.touhoulittlemaid.mixin.accessor;

import com.google.common.collect.BiMap;
import net.minecraft.class_173;
import net.minecraft.class_176;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_173.class)
public interface LootContextParamSetsAccessor {
    @Accessor("REGISTRY")
    static BiMap<class_2960, class_176> tlm$getRegistry() {
        throw new AssertionError();
    }
}
