package cn.sh1rocu.touhoulittlemaid.util.itemhandler;

import net.minecraft.class_1799;

public interface IItemHandlerModifiable extends IItemHandler {
    void setStackInSlot(int slot, class_1799 stack);
}