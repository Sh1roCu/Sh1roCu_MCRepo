package cn.sh1rocu.touhoulittlemaid.mixin.client;

import cn.sh1rocu.touhoulittlemaid.api.event.PlaySoundSourceEvent;
import cn.sh1rocu.touhoulittlemaid.api.mixin.ChannelAccessHandleInjection;
import cn.sh1rocu.touhoulittlemaid.util.kilt.SoundConsumerStorage;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Consumer;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_4224;
import net.minecraft.class_4225;
import net.minecraft.class_4235;

// From kilt
@Mixin(class_4235.class_4236.class)
public abstract class ChannelAccessHandleMixin implements ChannelAccessHandleInjection {
    @Shadow
    @Nullable class_4224 channel;
    @Unique
    private class_4225.class_4105 tlm$pool;
    @Unique
    private class_1140 tlm$soundEngine;
    @Unique
    private class_1113 tlm$soundInstance;

    @Override
    public void tlm$setPool(class_4225.class_4105 pool) {
        this.tlm$pool = pool;
    }

    @Override
    public void tlm$setSoundEngine(class_1140 engine) {
        this.tlm$soundEngine = engine;
    }

    @Override
    public void tlm$setSoundInstance(class_1113 instance) {
        this.tlm$soundInstance = instance;
    }

    @Inject(method = "method_19737", at = @At(value = "INVOKE", target = "Ljava/util/function/Consumer;accept(Ljava/lang/Object;)V", shift = At.Shift.AFTER))
    private void tlm$callPlaySoundEvents(Consumer<class_4224> consumer, CallbackInfo ci) {
        if (this.channel != null && tlm$soundEngine != null && tlm$soundInstance != null && SoundConsumerStorage.soundConsumerChannels.remove(consumer)) {
            if (tlm$pool == class_4225.class_4105.field_18352) {
                PlaySoundSourceEvent.CALLBACK.invoker().post(new PlaySoundSourceEvent(tlm$soundEngine, tlm$soundInstance, this.channel));
            }
            // 暂时用不到
            /* else if (tlm$pool == Library.Pool.STREAMING) {
                PlayStreamingSourceEvent.CALLBACK.invoker().post(new PlayStreamingSourceEvent(tlm$soundEngine, tlm$soundInstance, this.channel));
            }*/
        }
    }
}