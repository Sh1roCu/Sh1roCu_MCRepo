package cn.sh1rocu.touhoulittlemaid.api.extension;

import net.minecraft.class_2960;

public interface ILootTableBuilder {
    void tlm$setId(class_2960 id);
}
