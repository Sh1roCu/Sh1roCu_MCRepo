package cn.sh1rocu.touhoulittlemaid.api.extension;

import net.minecraft.class_1542;
import net.minecraft.class_1799;

public interface IItemEntity {
    default boolean tlm$onEntityItemUpdate(class_1799 stack, class_1542 entity) {
        return false;
    }
}
