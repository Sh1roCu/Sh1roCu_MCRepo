package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.util.forge.EventHooks;
import net.minecraft.class_1311;
import net.minecraft.class_1948;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2794;
import net.minecraft.class_3218;
import net.minecraft.class_5138;
import net.minecraft.class_5483;
import net.minecraft.class_6012;
import net.minecraft.class_6880;
import net.minecraft.class_7058;
import net.minecraft.class_7924;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1948.class)
public class NaturalSpawnerMixin {
    @Inject(method = "mobsAt", at = @At("HEAD"), cancellable = true)
    private static void tlm$mobsAt(
            class_3218 level,
            class_5138 structureManager,
            class_2794 generator,
            class_1311 category,
            class_2338 pos,
            class_6880<class_1959> biome,
            CallbackInfoReturnable<class_6012<class_5483.class_1964>> cir
    ) {
        if (class_1948.method_38091(pos, level, category, structureManager)) {
            var monsterSpawns = structureManager.method_41036().method_30530(class_7924.field_41246).method_31140(class_7058.field_37182).method_41615().get(class_1311.field_6302);
            if (monsterSpawns != null) {
                cir.setReturnValue(EventHooks.getPotentialSpawns(level, category, pos, monsterSpawns.comp_515()));
            }
        }
        cir.setReturnValue(EventHooks.getPotentialSpawns(level, category, pos, generator.method_12113(biome != null ? biome : level.method_23753(pos), structureManager, category, pos)));
    }
}
