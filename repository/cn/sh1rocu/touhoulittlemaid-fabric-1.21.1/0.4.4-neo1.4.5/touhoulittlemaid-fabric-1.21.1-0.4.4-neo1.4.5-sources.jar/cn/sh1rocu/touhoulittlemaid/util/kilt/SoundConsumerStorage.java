package cn.sh1rocu.touhoulittlemaid.util.kilt;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_4224;

// From Kilt
public class SoundConsumerStorage {
    // The sound engine is lambda hell, and so we have to use this storage to be able to ensure that the channel access execute inject in
    // ChannelAccessHandleMixin will actually be run in the correct places. We also can't wrap the consumer, because otherwise,
    // some other mod that tries to do the same thing will cause either us or them to fail.
    public static final Set<Consumer<class_4224>> soundConsumerChannels = Collections.synchronizedSet(new HashSet<>());
}