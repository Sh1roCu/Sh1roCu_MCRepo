package cn.sh1rocu.touhoulittlemaid.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import org.jetbrains.annotations.Nullable;

public class PlaySoundEvent {
    private final class_1140 engine;
    private final String name;
    private final class_1113 originalSound;
    @Nullable
    private class_1113 sound;

    public static final Event<Callback> CALLBACK = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.post(event);
        }
    });

    public PlaySoundEvent(class_1140 manager, class_1113 sound) {
        this.engine = manager;
        this.originalSound = sound;
        this.name = sound.method_4775().method_12832();
        this.setSound(sound);
    }

    public class_1140 getEngine() {
        return engine;
    }

    public String getName() {
        return name;
    }

    public class_1113 getOriginalSound() {
        return originalSound;
    }

    @Nullable
    public class_1113 getSound() {
        return sound;
    }

    public void setSound(@Nullable class_1113 newSound) {
        this.sound = newSound;
    }

    public interface Callback {
        void post(PlaySoundEvent event);
    }
}
