package cn.sh1rocu.touhoulittlemaid.util.block;

import net.minecraft.class_1297;
import net.minecraft.class_1510;
import net.minecraft.class_1528;
import net.minecraft.class_1687;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3481;

public class BlockUtil {
    public static boolean canEntityDestroy(class_2248 block, class_2680 state, class_1922 level, class_2338 pos, class_1297 entity) {
        if (entity instanceof class_1510) {
            return !block.method_9564().method_26164(class_3481.field_17753);
        } else if ((entity instanceof class_1528) ||
                (entity instanceof class_1687)) {
            return state.method_26215() || class_1528.method_6883(state);
        }

        return true;
    }
}
