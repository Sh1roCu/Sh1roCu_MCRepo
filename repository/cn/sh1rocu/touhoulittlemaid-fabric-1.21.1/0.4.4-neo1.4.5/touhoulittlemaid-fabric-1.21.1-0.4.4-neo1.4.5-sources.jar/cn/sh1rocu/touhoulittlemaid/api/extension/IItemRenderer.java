package cn.sh1rocu.touhoulittlemaid.api.extension;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_756;

public interface IItemRenderer {
    @Environment(EnvType.CLIENT)
    class_756 getCustomRenderer();
}
