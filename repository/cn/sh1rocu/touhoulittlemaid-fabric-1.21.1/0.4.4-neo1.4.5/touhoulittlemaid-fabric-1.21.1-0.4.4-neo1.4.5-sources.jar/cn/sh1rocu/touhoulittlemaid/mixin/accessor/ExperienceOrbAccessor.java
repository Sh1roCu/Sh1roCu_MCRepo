package cn.sh1rocu.touhoulittlemaid.mixin.accessor;

import net.minecraft.class_1303;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1303.class)
public interface ExperienceOrbAccessor {
    @Accessor("value")
    void setValue(int value);
}
