package cn.sh1rocu.touhoulittlemaid.api.extension;

import javax.annotation.Nullable;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2426;
import net.minecraft.class_2462;
import net.minecraft.class_2680;

public interface IRedstoneConnect {
    default boolean tlm$canConnectRedstone(class_2680 state, class_1922 level, class_2338 pos, @Nullable class_2350 direction) {
        if (state.method_27852(class_2246.field_10091)) {
            return true;
        } else if (state.method_27852(class_2246.field_10450)) {
            class_2350 facing = state.method_11654(class_2462.field_11177);
            return facing == direction || facing.method_10153() == direction;
        } else if (state.method_27852(class_2246.field_10282)) {
            return direction == state.method_11654(class_2426.field_10927);
        } else {
            return state.method_26219() && direction != null;
        }
    }
}
