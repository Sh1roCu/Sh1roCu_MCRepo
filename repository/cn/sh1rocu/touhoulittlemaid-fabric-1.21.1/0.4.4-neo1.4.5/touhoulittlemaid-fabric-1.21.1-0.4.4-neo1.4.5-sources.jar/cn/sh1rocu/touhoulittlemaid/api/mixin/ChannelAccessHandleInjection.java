package cn.sh1rocu.touhoulittlemaid.api.mixin;

import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_4225;

// From Kilt
public interface ChannelAccessHandleInjection {
    void tlm$setPool(class_4225.class_4105 pool);

    void tlm$setSoundInstance(class_1113 instance);

    void tlm$setSoundEngine(class_1140 engine);
}