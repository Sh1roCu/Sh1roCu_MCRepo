package cn.sh1rocu.touhoulittlemaid.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class FarmlandTrampleEvent extends CancellableEvent {
    private final class_1936 level;
    private final class_2338 pos;
    private final class_2680 state;
    private final class_1297 entity;
    private final float fallDistance;

    public static final Event<Callback> CALLBACK = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks)
            callback.post(event);
    });

    public FarmlandTrampleEvent(class_1937 level, class_2338 pos, class_2680 state, float fallDistance, class_1297 entity) {
        this.level = level;
        this.pos = pos;
        this.state = state;
        this.entity = entity;
        this.fallDistance = fallDistance;
    }

    public class_1936 getLevel() {
        return level;
    }

    public class_2338 getPos() {
        return pos;
    }

    public class_2680 getState() {
        return state;
    }

    public class_1297 getEntity() {
        return entity;
    }

    public float getFallDistance() {
        return fallDistance;
    }

    public interface Callback {
        void post(FarmlandTrampleEvent event);
    }
}
