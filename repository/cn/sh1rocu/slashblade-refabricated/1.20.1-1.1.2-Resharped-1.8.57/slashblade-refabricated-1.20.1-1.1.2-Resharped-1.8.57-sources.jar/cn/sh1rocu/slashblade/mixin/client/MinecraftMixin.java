package cn.sh1rocu.slashblade.mixin.client;

import cn.sh1rocu.slashblade.api.event.RenderTickEvent;
import cn.sh1rocu.slashblade.util.ClientHooks;
import net.minecraft.class_1268;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_317;
import net.minecraft.class_702;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftMixin {
    @Shadow
    @Final
    private class_317 timer;

    @Shadow
    @Final
    public class_315 options;

    @Shadow
    @Final
    public class_702 particleEngine;

    @Shadow
    @Nullable
    public class_746 player;

    @Inject(
            method = "runTick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/util/profiling/ProfilerFiller;popPush(Ljava/lang/String;)V",
                    ordinal = 0
            )
    )
    private void sb$onRenderStart(CallbackInfo ci) {
        RenderTickEvent.START.invoker().onStart(new RenderTickEvent.Pre(this.timer));
    }

    @Inject(
            method = "runTick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/util/profiling/ProfilerFiller;pop()V",
                    ordinal = 4
            )
    )
    private void sb$onRenderEnd(CallbackInfo ci) {
        RenderTickEvent.END.invoker().onEnd(new RenderTickEvent.Post(this.timer));
    }

    @Inject(method = "pickBlock", at = @At(value = "FIELD", target = "Lnet/minecraft/world/entity/player/Abilities;instabuild:Z", ordinal = 0), cancellable = true)
    private void sb$inputClickEvent(CallbackInfo ci) {
        if (ClientHooks.onClickInput(2, this.options.field_1871, class_1268.field_5808).isCanceled())
            ci.cancel();
    }
}