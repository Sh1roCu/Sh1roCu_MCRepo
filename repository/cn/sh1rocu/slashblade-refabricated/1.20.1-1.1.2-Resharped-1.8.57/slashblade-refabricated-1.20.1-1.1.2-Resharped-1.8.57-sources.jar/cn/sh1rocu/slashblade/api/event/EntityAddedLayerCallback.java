package cn.sh1rocu.slashblade.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_897;
import java.util.Map;

// Porting Lib
@FunctionalInterface
public interface EntityAddedLayerCallback {

    Event<EntityAddedLayerCallback> EVENT = EventFactory.createArrayBacked(EntityAddedLayerCallback.class, callbacks -> (renderers, skinMap) -> {
        for (EntityAddedLayerCallback event : callbacks) {
            event.addLayers(renderers, skinMap);
        }
    });

    void addLayers(final Map<class_1299<?>, class_897<?>> renderers, final Map<String, class_897<? extends class_1657>> skinMap);

}