package cn.sh1rocu.slashblade.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import org.jetbrains.annotations.Nullable;

public class LivingExperienceDropEvent extends LivingEvent implements ICancellableEvent {
    @Nullable
    private final class_1657 attackingPlayer;
    private final int originalExperiencePoints;
    private int droppedExperiencePoints;
    public static final Event<Callback> CALLBACK = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.onExpDrop(event);
        }
    });

    public LivingExperienceDropEvent(class_1309 entity, @Nullable class_1657 attackingPlayer, int originalExperience) {
        super(entity);

        this.attackingPlayer = attackingPlayer;
        this.originalExperiencePoints = this.droppedExperiencePoints = originalExperience;
    }

    public int getDroppedExperience() {
        return droppedExperiencePoints;
    }

    public void setDroppedExperience(int droppedExperience) {
        this.droppedExperiencePoints = droppedExperience;
    }

    @Nullable
    public class_1657 getAttackingPlayer() {
        return attackingPlayer;
    }

    public int getOriginalExperience() {
        return originalExperiencePoints;
    }

    public interface Callback {
        void onExpDrop(LivingExperienceDropEvent event);
    }
}
