package cn.sh1rocu.slashblade.mixin.common;

import cn.sh1rocu.slashblade.api.event.MobSpawnEvent;
import net.minecraft.class_1266;
import net.minecraft.class_1308;
import net.minecraft.class_1315;
import net.minecraft.class_2487;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1308.class)
public class MobMixin {
    @Inject(method = "finalizeSpawn", at = @At("HEAD"), cancellable = true)
    private void sb$onFinalizeSpawn(class_5425 serverLevelAccessor, class_1266 difficultyInstance, class_3730 mobSpawnType, class_1315 spawnGroupData, class_2487 compoundTag, CallbackInfoReturnable<class_1315> cir) {
        MobSpawnEvent.FinalizeSpawn event = new MobSpawnEvent.FinalizeSpawn(
                (class_1308) (Object) this, serverLevelAccessor, difficultyInstance, mobSpawnType, spawnGroupData, compoundTag
        );
        MobSpawnEvent.FINALIZE_SPAWN.invoker().onFinalizeSpawn(event);
        if (event.isCanceled()) {
            cir.setReturnValue(null);
        } else {
            cir.setReturnValue(event.getSpawnData());
        }
    }
}
