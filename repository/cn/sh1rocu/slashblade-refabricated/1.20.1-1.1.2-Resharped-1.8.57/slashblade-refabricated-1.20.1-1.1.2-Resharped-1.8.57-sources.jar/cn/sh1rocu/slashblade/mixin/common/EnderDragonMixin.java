package cn.sh1rocu.slashblade.mixin.common;

import cn.sh1rocu.slashblade.util.EventHooks;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1510;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// From Kilt
@Mixin(class_1510.class)
public abstract class EnderDragonMixin extends class_1308 {
    @Nullable
    @Unique
    private class_1657 sb$unlimitedLastHurtByPlayer = null;

    protected EnderDragonMixin(class_1299<? extends class_1308> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "aiStep", at = @At("HEAD"))
    private void sb$storeLastHurtByPlayer(CallbackInfo ci) {
        if (this.field_6258 != null)
            this.sb$unlimitedLastHurtByPlayer = this.field_6258;

        if (this.sb$unlimitedLastHurtByPlayer != null && this.sb$unlimitedLastHurtByPlayer.method_31481())
            this.sb$unlimitedLastHurtByPlayer = null;
    }

    @ModifyArg(method = "tickDeath", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/ExperienceOrb;award(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/phys/Vec3;I)V"))
    private int sb$useForgeModifiedExperienceDrop(int experience) {
        return EventHooks.getExperienceDrop(this, this.sb$unlimitedLastHurtByPlayer, experience);
    }
}