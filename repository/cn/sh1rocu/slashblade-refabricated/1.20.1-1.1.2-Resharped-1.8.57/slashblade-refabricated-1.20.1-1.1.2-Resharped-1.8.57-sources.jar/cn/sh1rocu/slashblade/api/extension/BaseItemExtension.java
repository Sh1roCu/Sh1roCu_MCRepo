package cn.sh1rocu.slashblade.api.extension;

import net.minecraft.class_1542;
import net.minecraft.class_1799;

public interface BaseItemExtension {
    default boolean onEntityItemUpdate(class_1799 stack, class_1542 entity){
        return false;
    }

    int getEnchantmentValue(class_1799 stack);

}
