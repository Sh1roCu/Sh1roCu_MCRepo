package cn.sh1rocu.slashblade.api.extension;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_756;
import java.util.function.Consumer;

public interface ItemSlashBladeExtension {
    default boolean onLeftClickEntity(class_1799 stack, class_1657 player, class_1297 entity) {
        return false;
    }

    default void setDamage(class_1799 stack, int damage) {
        stack.method_7948().method_10569("Damage", Math.max(0, damage));
    }

    default <T extends class_1309> int damageItem(class_1799 stack, int amount, T entity, Consumer<T> onBroken) {
        return amount;
    }

    default int getDamage(class_1799 stack) {
        return !stack.method_7985() ? 0 : stack.method_7969().method_10550("Damage");
    }

    default int getMaxDamage(class_1799 stack) {
        return ((class_1792) this).method_7841();
    }

    default boolean onEntitySwing(class_1799 stack, class_1309 entity) {
        return false;
    }

    default boolean onEntityItemUpdate(class_1799 stack, class_1542 entity) {
        return false;
    }

    @Environment(EnvType.CLIENT)
    class_756 getCustomRenderer();
}
