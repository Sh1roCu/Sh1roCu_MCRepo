package cn.sh1rocu.slashblade.util;

import cn.sh1rocu.slashblade.api.event.LivingExperienceDropEvent;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

public class EventHooks {
    public static int getExperienceDrop(class_1309 entity, class_1657 attackingPlayer, int originalExperience) {
        LivingExperienceDropEvent event = new LivingExperienceDropEvent(entity, attackingPlayer, originalExperience);
        LivingExperienceDropEvent.CALLBACK.invoker().onExpDrop(event);
        if (event.isCanceled()) {
            return 0;
        }
        return event.getDroppedExperience();
    }
}