package cn.sh1rocu.slashblade.mixin.common;

import cn.sh1rocu.slashblade.api.event.LivingJumpEvent;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1496.class)
public class AbstractHorseMixin {
    @Inject(method = "executeRidersJump", at = @At(value = "FIELD", target = "Lnet/minecraft/world/entity/animal/horse/AbstractHorse;hasImpulse:Z", shift = At.Shift.AFTER))
    private void sb$onHorseJump(float f, class_243 vec3, CallbackInfo ci) {
        LivingJumpEvent.CALLBACK.invoker().onLivingEntityJump(new LivingJumpEvent((class_1309) (Object) this));
    }
}