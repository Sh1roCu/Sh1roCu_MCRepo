package cn.sh1rocu.slashblade.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2487;

@Mixin(class_1799.class)
public interface ItemStackAccessor {
    @Invoker("<init>")
    static class_1799 sb$create(class_1935 itemLike, int count, Optional<class_2487> optional) {
        throw new AssertionError();
    }
}
