package mods.flammpfeil.slashblade.init;

import mods.flammpfeil.slashblade.SlashBlade;
import net.minecraft.class_2960;

public interface DefaultResources {
    class_2960 BaseMotionLocation = SlashBlade.prefix("combostate/old_motion.vmd");
    class_2960 ExMotionLocation = SlashBlade.prefix("combostate/motion.vmd");

    class_2960 testLocation = SlashBlade.prefix("combostate/piercing.vmd");

    class_2960 testPLLocation = SlashBlade.prefix("combostate/piercing_pl.vmd");

    class_2960 resourceDefaultModel = new class_2960("slashblade", "model/blade.obj");
    class_2960 resourceDefaultTexture = new class_2960("slashblade", "model/blade.png");

    class_2960 resourceDurabilityModel = new class_2960("slashblade",
            "model/util/durability.obj");
    class_2960 resourceDurabilityTexture = new class_2960("slashblade",
            "model/util/durability.png");
}
