package mods.flammpfeil.slashblade.event.client;

import cn.sh1rocu.slashblade.api.event.RenderPlayerEvents;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import net.minecraft.class_1007;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5498;
import net.minecraft.class_742;

public class SneakingMotionCanceller {
    private static final class SingletonHolder {
        private static final SneakingMotionCanceller instance = new SneakingMotionCanceller();
    }

    public static SneakingMotionCanceller getInstance() {
        return SingletonHolder.instance;
    }

    private SneakingMotionCanceller() {
    }

    public void register() {
        RenderPlayerEvents.PRE.register((class_1657 player, class_1007 renderer, float partialTick, class_4587 poseStack, class_4597 buffer, int packedLight) -> {
            this.onRenderPlayerEventPre(player, renderer, partialTick, poseStack, buffer, packedLight);
            return false;
        });
    }

    public void onRenderPlayerEventPre(class_1657 player, class_1007 renderer, float partialTick, class_4587 poseStack, class_4597 buffer, int packedLight) {
        class_1799 stack = player.method_6047();

        if (stack.method_7960())
            return;
        if (CapabilitySlashBlade.BLADESTATE.maybeGet(stack).isEmpty())
            return;

        if (!renderer.method_4038().field_3400)
            return;

        final class_310 instance = class_310.method_1551();
        if (instance.field_1690.method_31044() == class_5498.field_26664 && instance.field_1724 == player)
            return;

        renderer.method_4038().field_3400 = false;

        class_243 offset = renderer
                .method_23206((class_742) player, packedLight).method_1021(-1);

        poseStack.method_22904(offset.field_1352, offset.field_1351, offset.field_1350);
    }
}
