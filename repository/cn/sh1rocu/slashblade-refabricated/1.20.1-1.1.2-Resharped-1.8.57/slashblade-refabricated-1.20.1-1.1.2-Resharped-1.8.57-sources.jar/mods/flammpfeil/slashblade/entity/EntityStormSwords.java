package mods.flammpfeil.slashblade.entity;

import mods.flammpfeil.slashblade.ability.StunManager;
import mods.flammpfeil.slashblade.util.KnockBacks;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class EntityStormSwords extends EntityAbstractSummonedSword {
    private static final class_2940<Boolean> IT_FIRED = class_2945.method_12791(EntityStormSwords.class,
            class_2943.field_13323);

    public EntityStormSwords(class_1299<? extends Projectile> entityTypeIn, class_1937 worldIn) {
        super(entityTypeIn, worldIn);

        this.setPierce((byte) 1);
    }

    @Override
    protected void method_5693() {
        super.method_5693();

        this.field_6011.method_12784(IT_FIRED, false);
    }

    public void doFire() {
        this.method_5841().method_12778(IT_FIRED, true);
    }

    public boolean itFired() {
        return this.method_5841().method_12789(IT_FIRED);
    }

    @Override
    public void method_5842() {
        if (itFired()) {
            faceEntityStandby();
            class_1297 target = method_5854();
            this.method_5848();

            this.field_6012 = 0;
            class_243 dir = this.method_5828(1.0f);
            if (target != null) {
                dir = target.method_19538().method_1020(this.method_19538()).method_18805(1, 0, 1).method_1029();
            }
            this.method_7485(dir.field_1352, dir.field_1351, dir.field_1350, 3.0f, 1.0f);
            return;
        }

        // this.startRiding()
        this.method_18799(class_243.field_1353);
        // if (canUpdate())
        this.method_5670();

        faceEntityStandby();
        // this.getVehicle().positionRider(this);

        // todo: add lifetime
        if (20 <= this.field_6012)
            doFire();

        if (!method_37908().method_8608())
            hitCheck();
    }

    private void hitCheck() {
        class_243 positionVec = this.method_19538();
        class_243 dirVec = this.method_5828(1.0f);
        class_3966 raytraceresult = null;

        // todo : replace TargetSelector
        class_3966 entityraytraceresult = this.getRayTrace(positionVec, dirVec);
        if (entityraytraceresult != null) {
            raytraceresult = entityraytraceresult;
        }

        if (raytraceresult != null && raytraceresult.method_17783() == class_239.class_240.field_1331) {
            class_1297 entity = raytraceresult.method_17782();
            class_1297 entity1 = this.getShooter();
            if (entity instanceof class_1657 && entity1 instanceof class_1657
                    && !((class_1657) entity1).method_7256((class_1657) entity)) {
                raytraceresult = null;
                entityraytraceresult = null;
            }
        }

        if (raytraceresult != null && raytraceresult.method_17783() == class_239.class_240.field_1331
            /* && !net.minecraftforge.event.ForgeEventFactory.onProjectileImpact(this, raytraceresult)*/) {
            this.method_7488(raytraceresult);
            this.resetAlreadyHits();
            this.field_6007 = true;
        }
    }

    private void faceEntityStandby() {

        long cycle = 5 + this.field_6012;
        long tickOffset = 0;
        if (this.method_37908().method_8608())
            tickOffset = 1;

        // int ticks = (int)((this.level().getGameTime() + tickOffset) % cycle);
        int ticks = (int) ((this.field_6012 + tickOffset) % cycle);

        /*
         * if ((getInterval() - waitTime) < ticks) { ticks = getInterval() - waitTime; }
         */

        double rotParTick = 360.0 / (double) cycle;
        double offset = getDelay();
        double degYaw = (ticks * rotParTick + offset) % 360.0;
        double yaw = Math.toRadians(degYaw);

        class_243 dir = new class_243(0, 0, 1);

        // yaw
        dir = dir.method_1024((float) -yaw);
        dir = dir.method_1029().method_1021(4);

        if (this.method_5854() != null) {
            dir = dir.method_1019(this.method_5854().method_19538());
            dir = dir.method_1031(0, this.method_5854().method_5751() / 2.0, 0);
        }

        this.field_6004 = this.method_36455();
        this.field_5982 = this.method_36454();

        method_33574(dir);

        method_5710((float) (-degYaw) - 180, 0);

    }

    @Override
    protected void method_7454(class_3966 entityHitResult) {

        class_1297 targetEntity = entityHitResult.method_17782();
        if (targetEntity instanceof class_1309) {
            KnockBacks.toss.action.accept((class_1309) targetEntity);
            StunManager.setStun((class_1309) targetEntity);
        }

        super.method_7454(entityHitResult);
    }

    @Override
    protected void method_24920(class_3965 blockraytraceresult) {
        burst();
    }
}
