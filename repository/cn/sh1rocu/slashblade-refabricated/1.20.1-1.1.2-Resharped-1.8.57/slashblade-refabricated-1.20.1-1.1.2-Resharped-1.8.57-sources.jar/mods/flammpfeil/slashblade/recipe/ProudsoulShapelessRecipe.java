package mods.flammpfeil.slashblade.recipe;

import com.google.common.collect.Maps;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1867;
import net.minecraft.class_1869;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;
import net.minecraft.world.item.crafting.*;
import java.util.Map;

public class ProudsoulShapelessRecipe extends class_1867 {

	public ProudsoulShapelessRecipe(class_2960 p_251840_, String p_249640_, class_7710 p_249390_,
			class_1799 p_252071_, class_2371<class_1856> p_250689_) {
		super(p_251840_, p_249640_, p_249390_, p_252071_, p_250689_);
	}

	public static final class_1865<ProudsoulShapelessRecipe> SERIALIZER = new Serializer();

	@Override
	public class_1865<?> method_8119() {
		return SERIALIZER;
	}
	
	@Override
	public class_1799 method_17729(class_8566 container, class_5455 access) {
		class_1799 result = super.method_17729(container, access);
        Map<class_1887,Integer> all = Maps.newHashMap();

		for (int idx = 0; idx < container.method_5439(); idx++) {
			class_1799 stack = container.method_5438(idx);
            if(stack.method_7960()) 
            	continue;
			if (!stack.method_7942())
				continue;

            Map<class_1887,Integer> emap = class_1890.method_8222(stack);
            all.putAll(emap);
        }

        class_1890.method_8214(all,result);
		return result;
	}

	@Override
	public boolean method_17730(class_8566 container, class_1937 level) {
		boolean result = super.method_17730(container, level);

		if (result) {
			Map<class_1887, Integer> all = Maps.newHashMap();

			int soulCount = 0;

			for (int idx = 0; idx < container.method_5439(); idx++) {
				class_1799 stack = container.method_5438(idx);
				if (stack.method_7960())
					continue;
				if (!stack.method_7942())
					continue;

				soulCount++;

				Map<class_1887, Integer> emap = class_1890.method_8222(stack);

				for (Map.Entry<class_1887, Integer> entry : emap.entrySet()) {
					if (all.containsKey(entry.getKey())) {

						int value = all.get(entry.getKey()).intValue() + entry.getValue();

						all.put(entry.getKey(), value);
					} else {
						all.put(entry.getKey(), entry.getValue());
					}
				}
			}

			result = all.size() == 1 || all.size() == 0;
			if (result) {
				for (Map.Entry<class_1887, Integer> entry : all.entrySet()) {
					result = entry.getValue() == soulCount;
				}
			}
		}

		return result;
	}

	public static class Serializer implements class_1865<ProudsoulShapelessRecipe> {
		public ProudsoulShapelessRecipe method_8121(class_2960 p_44290_, JsonObject p_44291_) {
			String s = class_3518.method_15253(p_44291_, "group", "");
			@SuppressWarnings("deprecation")
			class_7710 craftingbookcategory = class_7710.field_40252
					.method_47920(class_3518.method_15253(p_44291_, "category", null), class_7710.field_40251);
			class_2371<class_1856> nonnulllist = itemsFromJson(class_3518.method_15261(p_44291_, "ingredients"));
			if (nonnulllist.isEmpty()) {
				throw new JsonParseException("No ingredients for shapeless recipe");
			} else if (nonnulllist.size() > 3 * 3) {
				throw new JsonParseException("Too many ingredients for shapeless recipe. The maximum is " + (3 * 3));
			} else {
				class_1799 itemstack = class_1869.method_35228(class_3518.method_15296(p_44291_, "result"));
				return new ProudsoulShapelessRecipe(p_44290_, s, craftingbookcategory, itemstack, nonnulllist);
			}
		}

		private static class_2371<class_1856> itemsFromJson(JsonArray p_44276_) {
			class_2371<class_1856> nonnulllist = class_2371.method_10211();

			for (int i = 0; i < p_44276_.size(); ++i) {
				class_1856 ingredient = class_1856.method_8102(p_44276_.get(i), false);
				nonnulllist.add(ingredient);
			}

			return nonnulllist;
		}

		public ProudsoulShapelessRecipe method_8122(class_2960 p_44293_, class_2540 p_44294_) {
			String s = p_44294_.method_19772();
			class_7710 craftingbookcategory = p_44294_.method_10818(class_7710.class);
			int i = p_44294_.method_10816();
			class_2371<class_1856> nonnulllist = class_2371.method_10213(i, class_1856.field_9017);

			for (int j = 0; j < nonnulllist.size(); ++j) {
				nonnulllist.set(j, class_1856.method_8086(p_44294_));
			}

			class_1799 itemstack = p_44294_.method_10819();
			return new ProudsoulShapelessRecipe(p_44293_, s, craftingbookcategory, itemstack, nonnulllist);
		}

		public void toNetwork(class_2540 p_44281_, ProudsoulShapelessRecipe p_44282_) {
			p_44281_.method_10814(p_44282_.method_8112());
			p_44281_.method_10817(p_44282_.method_45441());
			p_44281_.method_10804(p_44282_.method_8117().size());

			for (class_1856 ingredient : p_44282_.method_8117()) {
				ingredient.method_8088(p_44281_);
			}

			p_44281_.method_10793(p_44282_.method_8110(null));
		}
	}

}
