package mods.flammpfeil.slashblade.util;

import mods.flammpfeil.slashblade.SlashBlade;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public class CustomDamageSource {
    public static final class_5321<class_8110> SUMMONED_SWORD = class_5321.method_29179(class_7924.field_42534,
            new class_2960(SlashBlade.MODID, "summonedsword"));

}
