package mods.flammpfeil.slashblade.data.tag;

import mods.flammpfeil.slashblade.SlashBlade;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class SlashBladeItemTags {
    public static final class_6862<class_1792> PROUD_SOULS = class_6862.method_40092(class_7924.field_41197, new class_2960("slashblade", "proudsouls"));
    public static final class_6862<class_1792> BAMBOO = class_6862.method_40092(class_7924.field_41197, new class_2960("c", "bamboo"));

    public static final class_6862<class_1792> CAN_COPY_SA = class_6862.method_40092(class_7924.field_41197, SlashBlade.prefix("can_copy_sa"));
    public static final class_6862<class_1792> CAN_COPY_SE = class_6862.method_40092(class_7924.field_41197, SlashBlade.prefix("can_copy_se"));
    public static final class_6862<class_1792> CAN_CHANGE_SA = class_6862.method_40092(class_7924.field_41197, SlashBlade.prefix("can_change_sa"));
    public static final class_6862<class_1792> CAN_CHANGE_SE = class_6862.method_40092(class_7924.field_41197, SlashBlade.prefix("can_change_se"));
}
