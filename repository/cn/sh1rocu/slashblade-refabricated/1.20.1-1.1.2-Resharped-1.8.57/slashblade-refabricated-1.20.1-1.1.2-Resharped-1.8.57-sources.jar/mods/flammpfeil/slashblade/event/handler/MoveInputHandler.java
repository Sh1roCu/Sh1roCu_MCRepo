package mods.flammpfeil.slashblade.event.handler;

import mods.flammpfeil.slashblade.capability.inputstate.CapabilityInputState;
import mods.flammpfeil.slashblade.capability.inputstate.IInputState;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.client.SlashBladeKeyMappings;
import mods.flammpfeil.slashblade.network.MoveCommandMessage;
import mods.flammpfeil.slashblade.util.EnumSetConverter;
import mods.flammpfeil.slashblade.util.InputCommand;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.util.EnumSet;

public class MoveInputHandler {
    public static final String LAST_CHANGE_TIME = "SB_LAST_CHANGE_TIME";

    public static boolean checkFlag(int data, int flags) {
        return (data & flags) == flags;
    }

    @Environment(EnvType.CLIENT)
    public static void onPlayerPostTick(class_310 client) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null)
            return;

        if (player.method_6047().method_7960() || CapabilitySlashBlade.BLADESTATE.maybeGet(player.method_6047()).isEmpty())
            return;

        EnumSet<InputCommand> commands = EnumSet.noneOf(InputCommand.class);

        if (player.field_3913.field_3910)
            commands.add(InputCommand.FORWARD);
        if (player.field_3913.field_3909)
            commands.add(InputCommand.BACK);
        if (player.field_3913.field_3908)
            commands.add(InputCommand.LEFT);
        if (player.field_3913.field_3906)
            commands.add(InputCommand.RIGHT);

        if (player.field_3913.field_3903)
            commands.add(InputCommand.SNEAK);

        if (player.field_3913.field_3904) {
            commands.add(InputCommand.JUMP);
        }

        final class_310 minecraftInstance = class_310.method_1551();

        if (SlashBladeKeyMappings.KEY_SPECIAL_MOVE.method_1434())
            commands.add(InputCommand.SPRINT);

        if (minecraftInstance.field_1690.field_1904.method_1434())
            commands.add(InputCommand.R_DOWN);
        if (minecraftInstance.field_1690.field_1886.method_1434())
            commands.add(InputCommand.L_DOWN);

        if (SlashBladeKeyMappings.KEY_SUMMON_BLADE.method_1434())
            commands.add(InputCommand.M_DOWN);

        EnumSet<InputCommand> old = CapabilityInputState.INPUT_STATE.maybeGet(player).map(IInputState::getCommands)
                .orElseGet(() -> EnumSet.noneOf(InputCommand.class));

        class_1937 worldIn = player.method_5770();

        long currentTime = worldIn.method_8510();
        boolean doSend = !old.equals(commands);

        if (doSend) {
            CapabilityInputState.INPUT_STATE.maybeGet(player).ifPresent((state) -> {
                commands.forEach(c -> {
                    if (!old.contains(c))
                        state.getLastPressTimes().put(c, currentTime);
                });

                state.getCommands().clear();
                state.getCommands().addAll(commands);
            });
            MoveCommandMessage.send(EnumSetConverter.convertToInt(commands));
        }
    }
}