package mods.flammpfeil.slashblade.item;

import mods.flammpfeil.slashblade.capability.slashblade.SimpleSlashBladeState;
import mods.flammpfeil.slashblade.capability.slashblade.SlashBladeState;
import mods.flammpfeil.slashblade.init.DefaultResources;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import java.util.List;

public class ItemSlashBladeDetune extends ItemSlashBlade {
    private class_2960 model;
    private class_2960 texture;
    private final float baseAttack;
    private boolean isDestructable;

    public ItemSlashBladeDetune(class_1832 tier, int attackDamageIn, float attackSpeedIn, class_1793 builder) {
        super(tier, attackDamageIn, attackSpeedIn, builder);
        this.baseAttack = attackDamageIn;
        this.isDestructable = false;
        this.model = DefaultResources.resourceDefaultModel;
        this.texture = DefaultResources.resourceDefaultTexture;
    }

    public class_2960 getModel() {
        return model;
    }

    public ItemSlashBladeDetune setModel(class_2960 model) {
        this.model = model;
        return this;
    }

    public class_2960 getTexture() {
        return texture;
    }

    public ItemSlashBladeDetune setTexture(class_2960 texture) {
        this.texture = texture;
        return this;
    }

    public float getBaseAttack() {
        return baseAttack;
    }

    public boolean isDestructable() {
        return isDestructable;
    }

    public ItemSlashBladeDetune setDestructable() {
        this.isDestructable = true;
        return this;
    }

    @Override
    public boolean isDestructable(class_1799 stack) {
        return this.isDestructable;
    }

    @Override
    public void appendSwordType(class_1799 stack, class_1937 worldIn, List<class_2561> tooltip, class_1836 flagIn) {

    }

    @Override
    public SlashBladeState initCapability(class_1799 stack) {
        return new SimpleSlashBladeState(stack, this.getModel(), this.getTexture(), this.getBaseAttack(), this.method_8022().method_8025());
    }
}
