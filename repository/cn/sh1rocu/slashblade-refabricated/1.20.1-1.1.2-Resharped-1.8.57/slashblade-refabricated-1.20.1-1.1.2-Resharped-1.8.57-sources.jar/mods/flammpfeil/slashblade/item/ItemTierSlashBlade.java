package mods.flammpfeil.slashblade.item;

import mods.flammpfeil.slashblade.data.tag.SlashBladeItemTags;
import net.minecraft.class_1832;
import net.minecraft.class_1856;

public class ItemTierSlashBlade implements class_1832 {

    private final int uses;
    private final float attack;

    public ItemTierSlashBlade(int uses, float attack) {
        this.attack = attack;
        this.uses = uses;
    }

    @Override
    public int method_8025() {
        return uses;
    }

    @Override
    public float method_8027() {
        return 0;
    }

    @Override
    public float method_8028() {
        return attack;
    }

    @Override
    public int method_8024() {
        return 3;
    }

    @Override
    public int method_8026() {
        return 10;
    }

    @Override
    public class_1856 method_8023() {
        return class_1856.method_8106(SlashBladeItemTags.PROUD_SOULS);
    }
}
