package mods.flammpfeil.slashblade.network;

import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.capability.inputstate.CapabilityInputState;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.event.handler.InputCommandEvent;
import mods.flammpfeil.slashblade.util.EnumSetConverter;
import mods.flammpfeil.slashblade.util.InputCommand;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import java.util.EnumSet;

public class MoveCommandMessage {
    public static final class_2960 ID = SlashBlade.prefix("c2s_move_command");

    @Environment(EnvType.CLIENT)
    public static void send(int command) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeInt(command);
        ClientPlayNetworking.send(ID, buf);
    }

    public static void handle(MinecraftServer server, class_3222 sender, class_3244 handler, class_2540 buf, PacketSender responseSender) {
        int command = buf.readInt();
        server.execute(() -> {
            // do stuff
            class_1799 stack = sender.method_5998(class_1268.field_5808);
            if (stack.method_7960())
                return;
            if (CapabilitySlashBlade.BLADESTATE.maybeGet(stack).isEmpty())
                return;

            CapabilityInputState.INPUT_STATE.maybeGet(sender).ifPresent((state) -> {
                EnumSet<InputCommand> old = state.getCommands().clone();

                state.getCommands().clear();
                state.getCommands().addAll(EnumSetConverter.convertToEnumSet(InputCommand.class, command));

                EnumSet<InputCommand> current = state.getCommands().clone();

                long currentTime = sender.method_37908().method_8510();
                current.forEach(c -> {
                    if (!old.contains(c))
                        state.getLastPressTimes().put(c, currentTime);
                });

                InputCommandEvent.onInputChange(sender, state, old, current);

            });
        });
    }
}