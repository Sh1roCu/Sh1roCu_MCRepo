package mods.flammpfeil.slashblade.patchouli.mixin;

import mods.flammpfeil.slashblade.recipe.SlashBladeSmithingRecipe;
import net.minecraft.class_1856;
import net.minecraft.class_8059;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import vazkii.patchouli.client.book.page.PageSmithing;

@Mixin(PageSmithing.class)
public class PageSmithingMixin {
    @Inject(method = "getBase", at = @At("RETURN"), cancellable = true, remap = false)
    private void getBaseMixin(class_8059 recipe, CallbackInfoReturnable<class_1856> cir) {
        if (recipe instanceof SlashBladeSmithingRecipe slashbladeRecipe)
            cir.setReturnValue(slashbladeRecipe.getBase());
    }

    @Inject(method = "getAddition", at = @At("RETURN"), cancellable = true, remap = false)
    private void getAdditionMixin(class_8059 recipe, CallbackInfoReturnable<class_1856> cir) {
        if (recipe instanceof SlashBladeSmithingRecipe slashbladeRecipe)
            cir.setReturnValue(slashbladeRecipe.getAddition());
    }

    @Inject(method = "getTemplate", at = @At("RETURN"), cancellable = true, remap = false)
    private void getTemplateMixin(class_8059 recipe, CallbackInfoReturnable<class_1856> cir) {
        if (recipe instanceof SlashBladeSmithingRecipe slashbladeRecipe)
            cir.setReturnValue(slashbladeRecipe.getTemplate());
    }
}