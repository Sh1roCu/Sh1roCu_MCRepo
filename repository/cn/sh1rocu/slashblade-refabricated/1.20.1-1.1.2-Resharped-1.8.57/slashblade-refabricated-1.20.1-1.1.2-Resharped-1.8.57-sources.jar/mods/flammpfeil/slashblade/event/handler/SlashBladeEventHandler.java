package mods.flammpfeil.slashblade.event.handler;

import io.github.fabricators_of_create.porting_lib.entity.events.LivingAttackEvent;
import mods.flammpfeil.slashblade.event.SlashBladeRegistryEvent;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_7923;
import net.minecraft.class_8103;

public class SlashBladeEventHandler {
    public static void onLivingOnFire(LivingAttackEvent event) {
        class_1309 victim = event.getEntity();
        class_1282 source = event.getSource();

        class_1799 stack = victim.method_6047();
        if (class_1890.method_8225(class_1893.field_9095, stack) <= 0)
            return;
        if (!source.method_48789(class_8103.field_42246))
            return;

        event.setCanceled(true);
    }

    public static void onLoadingBlade(SlashBladeRegistryEvent.Pre event) {
        if (!class_7923.field_41178.method_10250(event.getSlashBladeDefinition().getItemName()))
            event.setCanceled(true);
    }
}
