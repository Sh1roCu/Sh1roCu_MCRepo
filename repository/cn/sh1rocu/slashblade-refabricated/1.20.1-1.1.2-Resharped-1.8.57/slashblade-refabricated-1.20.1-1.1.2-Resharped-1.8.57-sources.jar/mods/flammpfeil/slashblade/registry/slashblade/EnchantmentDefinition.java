package mods.flammpfeil.slashblade.registry.slashblade;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2960;

public class EnchantmentDefinition {
    public static final Codec<EnchantmentDefinition> CODEC = RecordCodecBuilder.create(instance -> instance
            .group(class_2960.field_25139.fieldOf("id").forGetter(EnchantmentDefinition::getEnchantmentID),
                    Codec.INT.optionalFieldOf("lvl", 1).forGetter(EnchantmentDefinition::getEnchantmentLevel))
            .apply(instance, EnchantmentDefinition::new));

    private final class_2960 id;
    private final int lvl;

    public EnchantmentDefinition(class_2960 enchantment, int level) {
        this.id = enchantment;
        this.lvl = level;
    }

    public class_2960 getEnchantmentID() {
        return id;
    }

    public int getEnchantmentLevel() {
        return lvl;
    }
}