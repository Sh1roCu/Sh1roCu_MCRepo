package mods.flammpfeil.slashblade;

import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.init.SBItems;
import mods.flammpfeil.slashblade.registry.SlashArtsRegistry;
import mods.flammpfeil.slashblade.registry.slashblade.SlashBladeDefinition;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class SlashBladeCreativeGroup {
    public static void init() {

    }

    private static final class_1761 SLASHBLADE = FabricItemGroup.builder()
            .method_47321(class_2561.method_43471("itemGroup.slashblade")).method_47320(() -> {
                class_1799 stack = new class_1799(SBItems.slashblade);
                CapabilitySlashBlade.BLADESTATE.maybeGet(stack).ifPresent(s -> {
                    s.setModel(new class_2960(SlashBlade.MODID, "model/named/yamato.obj"));
                    s.setTexture(new class_2960(SlashBlade.MODID, "model/named/yamato.png"));
                });
                return stack;
            }).method_47317((features, output) -> {

                output.method_45421(SBItems.proudsoul);
                output.method_45421(SBItems.proudsoul_tiny);
                output.method_45421(SBItems.proudsoul_ingot);
                output.method_45421(SBItems.proudsoul_sphere);

                output.method_45421(SBItems.proudsoul_crystal);
                output.method_45421(SBItems.proudsoul_trapezohedron);
                fillEnchantmentsSouls(output);
                fillSASpheres(output);
                output.method_45421(SBItems.bladestand_1);
                output.method_45421(SBItems.bladestand_1w);
                output.method_45421(SBItems.bladestand_2);
                output.method_45421(SBItems.bladestand_2w);
                output.method_45421(SBItems.bladestand_s);
                output.method_45421(SBItems.bladestand_v);

                output.method_45421(SBItems.slashblade_wood);
                output.method_45421(SBItems.slashblade_bamboo);
                output.method_45421(SBItems.slashblade_silverbamboo);
                output.method_45421(SBItems.slashblade_white);
                output.method_45421(SBItems.slashblade);

                // fillBlades(features, output);
            }).method_47324();

    public static final class_1761 SLASHBLADE_GROUP = class_2378.method_10230(
            class_7923.field_44687,
            SlashBlade.prefix("slashblade"),
            SLASHBLADE
    );

    @SuppressWarnings("unused")
    @Deprecated
    private static void fillBlades(class_1761.class_8128 features, class_1761.class_7704 output) {
        SlashBlade.getSlashBladeDefinitionRegistry(features.comp_1253()).method_42017()
                .sorted(SlashBladeDefinition.COMPARATOR).forEach(entry -> {
                    if (!entry.comp_349().getBlade().method_7960())
                        output.method_45420(entry.comp_349().getBlade());
                });
    }

    private static void fillEnchantmentsSouls(class_1761.class_7704 output) {
        class_7923.field_41176.forEach(enchantment -> {
            class_1799 blade = new class_1799(SBItems.slashblade);
            //if (blade.canApplyAtEnchantingTable(enchantment)) {
            if (enchantment.method_8192(blade)) {
                class_1799 soul = new class_1799(SBItems.proudsoul_tiny);
                soul.method_7978(enchantment, 1);
                output.method_45420(soul);
            }

        });
    }

    private static void fillSASpheres(class_1761.class_7704 output) {
        SlashArtsRegistry.SLASH_ARTS.forEach(slashArts -> {
            class_2960 key = SlashArtsRegistry.SLASH_ARTS.method_10221(slashArts);
            if (slashArts.equals(SlashArtsRegistry.NONE) || key == null)
                return;
            class_1799 sphere = new class_1799(SBItems.proudsoul_sphere);
            class_2487 tag = new class_2487();
            tag.method_10582("SpecialAttackType", key.toString());
            sphere.method_7980(tag);
            output.method_45420(sphere);
        });
    }
}
