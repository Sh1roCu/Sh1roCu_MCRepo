package mods.flammpfeil.slashblade.entity;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import org.jetbrains.annotations.Nullable;

public abstract class Projectile extends net.minecraft.class_1676 {
    private static final class_2940<Integer> OWNERID = class_2945.method_12791(Projectile.class,
            class_2943.field_13327);

    protected Projectile(class_1299<? extends net.minecraft.class_1676> p_37248_,
            class_1937 p_37249_) {
        super(p_37248_, p_37249_);
    }

    @Override
    protected void method_5693() {
        this.field_6011.method_12784(OWNERID, -1);
    }

    @Nullable
    @Override
    public class_1297 method_24921() {
        int id = this.field_6011.method_12789(OWNERID);

        if (0 <= id) {
            class_1297 tmp = this.method_37908().method_8469(id);
            if (super.method_24921() != tmp)
                this.method_7432(tmp);
        } else {
            this.method_7432(null);
        }

        return super.method_24921();
    }

    @Override
    public void method_7432(@Nullable class_1297 p_37263_) {
        if (p_37263_ != null)
            this.field_6011.method_12778(OWNERID, p_37263_.method_5628());
        else
            this.field_6011.method_12778(OWNERID, -1);

        super.method_7432(p_37263_);
    }

    @Override
    public boolean method_5753() {
        return true;//防火
    }
}
