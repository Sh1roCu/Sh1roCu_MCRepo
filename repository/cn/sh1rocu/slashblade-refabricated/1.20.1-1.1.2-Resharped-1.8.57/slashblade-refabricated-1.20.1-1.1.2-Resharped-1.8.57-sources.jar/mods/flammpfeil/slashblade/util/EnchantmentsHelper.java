package mods.flammpfeil.slashblade.util;

import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;

public class EnchantmentsHelper {
    //判断A是否含有B的附魔
    public static boolean hasEnchantmentsMatch(class_1799 stackA, class_1799 stackB) {
        Map<class_1887, Integer> enchantmentsB = class_1890.method_8222(stackB);

        // 如果B没有附魔要求，直接返回true
        if (enchantmentsB.isEmpty()) return true;

        Map<class_1887, Integer> enchantmentsA = class_1890.method_8222(stackA);

        for (Map.Entry<class_1887, Integer> entry : enchantmentsB.entrySet()) {
            class_1887 ench = entry.getKey();
            int requiredLevel = entry.getValue();

            // 检查A是否包含该附魔且等级足够
            if (!enchantmentsA.containsKey(ench) || enchantmentsA.get(ench) < requiredLevel) {
                return false;
            }
        }
        return true;
    }
}
