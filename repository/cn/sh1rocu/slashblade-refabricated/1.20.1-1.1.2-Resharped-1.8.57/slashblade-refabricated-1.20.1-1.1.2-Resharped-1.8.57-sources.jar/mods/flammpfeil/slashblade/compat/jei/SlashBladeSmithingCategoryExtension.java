package mods.flammpfeil.slashblade.compat.jei;

import mezz.jei.api.gui.builder.IIngredientAcceptor;
import mezz.jei.api.recipe.category.extensions.vanilla.smithing.ISmithingCategoryExtension;
import mods.flammpfeil.slashblade.recipe.SlashBladeSmithingRecipe;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_638;

public class SlashBladeSmithingCategoryExtension implements ISmithingCategoryExtension<SlashBladeSmithingRecipe> {
    @Override
    public <T extends IIngredientAcceptor<T>> void setTemplate(SlashBladeSmithingRecipe recipe, T ingredientAcceptor) {
        class_1856 ingredient = recipe.getTemplate();
        ingredientAcceptor.addIngredients(ingredient);
    }

    @Override
    public <T extends IIngredientAcceptor<T>> void setBase(SlashBladeSmithingRecipe recipe, T ingredientAcceptor) {
        class_1856 ingredient = recipe.getBase();
        ingredientAcceptor.addIngredients(ingredient);
    }

    @Override
    public <T extends IIngredientAcceptor<T>> void setAddition(SlashBladeSmithingRecipe recipe, T ingredientAcceptor) {
        class_1856 ingredient = recipe.getAddition();
        ingredientAcceptor.addIngredients(ingredient);
    }

    @Override
    public <T extends IIngredientAcceptor<T>> void setOutput(SlashBladeSmithingRecipe recipe, T ingredientAcceptor) {
        class_1856 templateIngredient = recipe.getTemplate();
        class_1856 baseIngredient = recipe.getBase();
        class_1856 additionIngredient = recipe.getAddition();

        class_1799[] additions = additionIngredient.method_8105();
        if (additions.length == 0) {
            return;
        }
        class_1799 addition = additions[0];

        for (class_1799 template : templateIngredient.method_8105()) {
            for (class_1799 base : baseIngredient.method_8105()) {
                class_1263 recipeInput = createInput(template, base, addition);
                class_1799 output = assembleResultItem(recipeInput, recipe);
                ingredientAcceptor.addItemStack(output);
            }
        }
    }

    private static <I extends class_1263> class_1799 assembleResultItem(I input, class_1860<I> recipe) {
        class_310 minecraft = class_310.method_1551();
        class_638 level = minecraft.field_1687;
        if (level == null) {
            throw new NullPointerException("level must not be null.");
        }
        class_5455 registryAccess = level.method_30349();
        return recipe.method_8116(input, registryAccess);
    }

    private static class_1263 createInput(class_1799 template, class_1799 base, class_1799 addition) {
        class_1263 container = new class_1277(3);
        container.method_5447(0, template);
        container.method_5447(1, base);
        container.method_5447(2, addition);
        return container;
    }


}