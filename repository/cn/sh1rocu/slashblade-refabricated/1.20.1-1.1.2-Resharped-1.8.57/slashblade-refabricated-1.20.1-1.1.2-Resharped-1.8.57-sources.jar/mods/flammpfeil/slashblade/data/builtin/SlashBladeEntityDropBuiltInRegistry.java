package mods.flammpfeil.slashblade.data.builtin;

import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.event.drop.EntityDropEntry;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7891;

public class SlashBladeEntityDropBuiltInRegistry {
    public static final class_5321<EntityDropEntry> ENDER_DRAGON_YAMATO = register("ender_dragon_yamato");
    public static final class_5321<EntityDropEntry> WITHER_SANGE = register("wither_sange");

    public static final class_5321<EntityDropEntry> MINOTAUR_YASHA = register("minotaur_yasha");
    public static final class_5321<EntityDropEntry> MINOSHROOM_YASHA_TRUE = register("minoshroom_yasha_true");

    public static final class_5321<EntityDropEntry> NAGA_AGITO = register("naga_agito");
    public static final class_5321<EntityDropEntry> HYDRA_OROTIAGITO = register("hydra_orotiagito");

    public static void registerAll(class_7891<EntityDropEntry> bootstrap) {
        bootstrap.method_46838(ENDER_DRAGON_YAMATO, new EntityDropEntry(new class_2960("minecraft", "ender_dragon"),
                SlashBlade.prefix("yamato_broken"), 1.0F, false, true, new class_243(0F, 60F, 0F)));

        bootstrap.method_46838(WITHER_SANGE, new EntityDropEntry(new class_2960("minecraft", "wither"),
                SlashBlade.prefix("sange"), 0.3F, true));

        bootstrap.method_46838(MINOTAUR_YASHA, new EntityDropEntry(new class_2960("twilightforest", "minotaur"),
                SlashBlade.prefix("yasha"), 0.05F, true));

        bootstrap.method_46838(MINOSHROOM_YASHA_TRUE, new EntityDropEntry(
                new class_2960("twilightforest", "minoshroom"), SlashBlade.prefix("yasha_true"), 0.2F, true));

        bootstrap.method_46838(NAGA_AGITO, new EntityDropEntry(new class_2960("twilightforest", "naga"),
                SlashBlade.prefix("agito_rust"), 0.3F, false));

        bootstrap.method_46838(HYDRA_OROTIAGITO, new EntityDropEntry(new class_2960("twilightforest", "hydra"),
                SlashBlade.prefix("orotiagito_rust"), 0.3F, false));
    }

    private static class_5321<EntityDropEntry> register(String id) {
        class_5321<EntityDropEntry> loc = class_5321.method_29179(EntityDropEntry.REGISTRY_KEY, SlashBlade.prefix(id));
        return loc;
    }
}
