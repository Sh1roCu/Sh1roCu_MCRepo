package mods.flammpfeil.slashblade.compat.emi;

import dev.emi.emi.api.stack.Comparison;
import net.minecraft.class_1799;

public class EMIUtils {

    public static Comparison SLASHBLADE_COMPARISON = Comparison.of((self, other) -> {
        class_1799 aStack = self.getItemStack();
        class_1799 bStack = other.getItemStack();
        if (aStack.method_7909() != bStack.method_7909()) return false;
        String keyA = self.getNbt().method_10562("bladeState").method_10558("translationKey");
        String keyB = other.getNbt().method_10562("bladeState").method_10558("translationKey");

        return keyB.equals(keyA);
    });
}