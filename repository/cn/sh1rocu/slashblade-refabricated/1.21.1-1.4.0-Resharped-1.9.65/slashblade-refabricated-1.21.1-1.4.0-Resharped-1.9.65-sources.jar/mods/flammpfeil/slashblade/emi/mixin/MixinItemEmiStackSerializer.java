package mods.flammpfeil.slashblade.emi.mixin;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import dev.emi.emi.EmiPort;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.ItemEmiStack;
import dev.emi.emi.api.stack.serializer.EmiIngredientSerializer;
import dev.emi.emi.api.stack.serializer.EmiStackSerializer;
import dev.emi.emi.runtime.EmiLog;
import dev.emi.emi.stack.serializer.ItemEmiStackSerializer;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2522;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_6880;
import net.minecraft.class_9326;
import org.spongepowered.asm.mixin.Mixin;

import java.util.regex.Matcher;

@Mixin(value = ItemEmiStackSerializer.class, remap = false)
public abstract class MixinItemEmiStackSerializer implements EmiStackSerializer<ItemEmiStack> {

    @Override
    public JsonElement serialize(ItemEmiStack stack) {
        if (stack.getAmount() == 1 && stack.getChance() == 1 &&
                stack.getRemainder().isEmpty() &&
                !(stack.getItemStack().method_7909() instanceof ItemSlashBlade)) {
            String s = getType() + ":" + stack.getId();
            class_9326 patch = stack.getComponentChanges();
            if (!patch.method_57848()) {
                s += class_9326.field_49589.encodeStart(class_2509.field_11560, patch).getOrThrow().method_10714();
            }
            return new JsonPrimitive(s);

        } else {
            JsonObject json = new JsonObject();
            json.addProperty("type", getType());
            json.addProperty("id", stack.getId().toString());
            class_9326 patch = stack.getComponentChanges();
            if (!patch.method_57848()) {
                json.addProperty("nbt", class_9326.field_49589.encodeStart(class_2509.field_11560, patch).getOrThrow().method_10714());
            }
            if (stack.getAmount() != 1) {
                json.addProperty("amount", stack.getAmount());
            }
            if (stack.getChance() != 1) {
                json.addProperty("chance", stack.getChance());
            }
            class_1799 itemStack = stack.getItemStack();
            if (itemStack.method_7909() instanceof ItemSlashBlade) {
                var optional = CapabilitySlashBlade.getBladeState(itemStack);
                if (optional.isPresent()) {
                    json.addProperty("sbCaps", optional.orElseThrow().getBladeState().method_10714());

                }
            }
            if (!stack.getRemainder().isEmpty()) {
                EmiStack remainder = stack.getRemainder();
                if (!remainder.getRemainder().isEmpty()) {
                    remainder = remainder.copy().setRemainder(EmiStack.EMPTY);
                }
                if (remainder.getRemainder().isEmpty()) {
                    JsonElement remainderElement = EmiIngredientSerializer.getSerialized(remainder);
                    if (remainderElement != null) {
                        json.add("remainder", remainderElement);
                    }
                }
            }
            return json;
        }
    }

    @Override
    public EmiIngredient deserialize(JsonElement element) {
        class_2960 id = null;
        String nbt = null;
        String capNBT = null;
        long amount = 1;
        float chance = 1;
        EmiStack remainder = EmiStack.EMPTY;
        if (class_3518.method_15286(element)) {
            String s = element.getAsString();
            Matcher m = STACK_REGEX.matcher(s);
            if (m.matches()) {
                id = EmiPort.id(m.group(2), m.group(3));
                nbt = m.group(4);
            }
        } else if (element.isJsonObject()) {
            JsonObject json = element.getAsJsonObject();
            id = EmiPort.id(class_3518.method_15265(json, "id"));
            nbt = class_3518.method_15253(json, "nbt", null);
            capNBT = class_3518.method_15253(json, "sbCaps", null);
            amount = class_3518.method_15280(json, "amount", 1);
            chance = class_3518.method_15277(json, "chance", 1);
            if (class_3518.method_15294(json, "remainder")) {
                EmiIngredient ing = EmiIngredientSerializer.getDeserialized(json.get("remainder"));
                if (ing instanceof EmiStack stack) {
                    remainder = stack;
                }
            }
        }
        if (id != null) {
            try {
                class_9326 nbtPatch = class_9326.field_49588;
                if (nbt != null) {
                    class_2520 tag = class_2522.method_10718(nbt);
                    nbtPatch = class_9326.field_49589.parse(class_2509.field_11560, tag).getOrThrow();
                }
                EmiStack stack;
                if (capNBT != null) {
                    var holderOpt = EmiPort.getItemRegistry().method_55841(id);
                    if (holderOpt.isEmpty()) {
                        return EmiStack.EMPTY;
                    }
                    class_6880<class_1792> holder = holderOpt.get();
                    class_2487 capTag = class_2522.method_10718(capNBT);
                    class_1799 itemStack = new class_1799(holder, (int) amount, nbtPatch);
                    CapabilitySlashBlade.getBladeState(itemStack).ifPresent(state -> state.setBladeState(capTag));
                    EmiStack emiStack = EmiStack.of(itemStack);
                    if (chance != 1) {
                        emiStack.setChance(chance);
                    }
                    if (!remainder.isEmpty()) {
                        emiStack.setRemainder(remainder);
                    }
                    stack = emiStack;
                } else {
                    stack = create(id, nbtPatch, amount);
                }
                if (chance != 1) {
                    stack.setChance(chance);
                }
                if (!remainder.isEmpty()) {
                    stack.setRemainder(remainder);
                }

                return stack;
            } catch (Exception e) {
                EmiLog.error("Error parsing NBT in deserialized stack", e);
                return EmiStack.EMPTY;
            }
        }
        return EmiStack.EMPTY;
    }
}