package cn.sh1rocu.slashblade.mixin.common;

import cn.sh1rocu.slashblade.api.event.MobSpawnEvent;
import cn.sh1rocu.slashblade.api.extension.ItemSlashBladeExtension;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_1266;
import net.minecraft.class_1308;
import net.minecraft.class_1315;
import net.minecraft.class_1799;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import net.minecraft.class_9331;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1308.class)
public class MobMixin {
    @Inject(method = "finalizeSpawn", at = @At("HEAD"), cancellable = true)
    private void sb$onFinalizeSpawn(class_5425 serverLevelAccessor, class_1266 difficultyInstance, class_3730 mobSpawnType, class_1315 spawnGroupData, CallbackInfoReturnable<class_1315> cir) {
        MobSpawnEvent.FinalizeSpawn event = new MobSpawnEvent.FinalizeSpawn(
                (class_1308) (Object) this, serverLevelAccessor, difficultyInstance, mobSpawnType, spawnGroupData
        );
        MobSpawnEvent.FINALIZE_SPAWN.invoker().onFinalizeSpawn(event);
        if (event.isCanceled()) {
            cir.setReturnValue(null);
        } else {
            cir.setReturnValue(event.getSpawnData());
        }
    }

    @WrapOperation(method = "getApproximateAttackDamageWithItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getOrDefault(Lnet/minecraft/core/component/DataComponentType;Ljava/lang/Object;)Ljava/lang/Object;"))
    private Object sb$getDefaultAttributeModifiers(class_1799 instance, class_9331 dataComponentType, Object object, Operation<Object> original) {
        if (instance.method_7909() instanceof ItemSlashBladeExtension blade) {
            return blade.getDefaultAttributeModifiers(instance);
        }
        return original.call(instance, dataComponentType, object);
    }
}
