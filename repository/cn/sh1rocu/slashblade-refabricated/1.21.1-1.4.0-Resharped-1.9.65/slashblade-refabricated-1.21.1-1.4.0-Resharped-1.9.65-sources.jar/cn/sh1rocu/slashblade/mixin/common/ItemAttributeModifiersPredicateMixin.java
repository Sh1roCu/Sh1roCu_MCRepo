package cn.sh1rocu.slashblade.mixin.common;

import cn.sh1rocu.slashblade.api.extension.ItemSlashBladeExtension;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_9285;
import net.minecraft.class_9653;

@Mixin(class_9653.class)
public abstract class ItemAttributeModifiersPredicateMixin {
    @WrapOperation(
            method = "matches(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/component/ItemAttributeModifiers;)Z",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/item/component/ItemAttributeModifiers;modifiers()Ljava/util/List;"
            )
    )
    private List<class_9285.class_9287> sb$getDefaultAttributeModifiers(class_9285 instance, Operation<List<class_9285.class_9287>> original, @Local(argsOnly = true) class_1799 stack) {
        if (stack.method_7909() instanceof ItemSlashBladeExtension blade) {
            return blade.getDefaultAttributeModifiers(stack).comp_2393();
        }
        return original.call(instance);
    }
}