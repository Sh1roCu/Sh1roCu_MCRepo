package cn.sh1rocu.slashblade.mixin.common;

import cn.sh1rocu.slashblade.api.event.MobSpawnEvent;
import cn.sh1rocu.slashblade.api.extension.ItemSlashBladeExtension;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1266;
import net.minecraft.class_1308;
import net.minecraft.class_1315;
import net.minecraft.class_1799;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1308.class)
public class MobMixin {
    @Inject(method = "finalizeSpawn", at = @At("HEAD"), cancellable = true)
    private void sb$onFinalizeSpawn(class_5425 serverLevelAccessor, class_1266 difficultyInstance, class_3730 mobSpawnType, class_1315 spawnGroupData, CallbackInfoReturnable<class_1315> cir) {
        MobSpawnEvent.FinalizeSpawn event = new MobSpawnEvent.FinalizeSpawn(
                (class_1308) (Object) this, serverLevelAccessor, difficultyInstance, mobSpawnType, spawnGroupData
        );
        MobSpawnEvent.FINALIZE_SPAWN.invoker().onFinalizeSpawn(event);
        if (event.isCanceled()) {
            cir.setReturnValue(null);
        } else {
            cir.setReturnValue(event.getSpawnData());
        }
    }

    @ModifyExpressionValue(method = "getApproximateAttackDamageWithItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getOrDefault(Lnet/minecraft/core/component/DataComponentType;Ljava/lang/Object;)Ljava/lang/Object;"))
    private Object sw$modifyItemAttributeModifiers(Object original, @Local(argsOnly = true) class_1799 stack) {
        if (stack.method_7909() instanceof ItemSlashBladeExtension item) {
            return item.getDefaultAttributeModifiers(stack);
        }
        return original;
    }
}
