package cn.sh1rocu.slashblade.mixin.common;

import cn.sh1rocu.slashblade.api.extension.ItemSlashBladeExtension;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1799;
import net.minecraft.class_9285;
import net.minecraft.class_9653;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_9653.class)
public class ItemAttributeModifiersPredicateMixin {
    @ModifyVariable(method = "matches(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/component/ItemAttributeModifiers;)Z", at = @At("HEAD"), argsOnly = true)
    private class_9285 sb$modifyItemAttributeModifier(class_9285 original, @Local(argsOnly = true) class_1799 stack) {
        if (stack.method_7909() instanceof ItemSlashBladeExtension item) {
            return item.getDefaultAttributeModifiers(stack);
        }
        return original;
    }
}
