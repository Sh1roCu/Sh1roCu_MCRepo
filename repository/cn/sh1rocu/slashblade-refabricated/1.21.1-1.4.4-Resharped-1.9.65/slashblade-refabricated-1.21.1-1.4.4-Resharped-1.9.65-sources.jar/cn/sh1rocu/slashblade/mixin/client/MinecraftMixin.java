package cn.sh1rocu.slashblade.mixin.client;

import cn.sh1rocu.slashblade.api.event.RenderFrameEvent;
import cn.sh1rocu.slashblade.util.ClientHooks;
import mods.flammpfeil.slashblade.event.handler.BlockPickCanceller;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_746;
import net.minecraft.class_9779;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.atomic.AtomicBoolean;

@Mixin(class_310.class)
public class MinecraftMixin {
    @Shadow
    @Final
    private class_9779.class_9781 timer;

    @Shadow
    @Final
    public class_315 options;

    @Shadow
    @Nullable
    public class_746 player;

    @Inject(method = "runTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GameRenderer;render(Lnet/minecraft/client/DeltaTracker;Z)V"))
    private void sb$onRenderStart(CallbackInfo ci) {
        RenderFrameEvent.START.invoker().onStart(new RenderFrameEvent.Pre(this.timer));
    }

    @Inject(method = "runTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GameRenderer;render(Lnet/minecraft/client/DeltaTracker;Z)V", shift = At.Shift.AFTER))
    private void sb$onRenderEnd(CallbackInfo ci) {
        RenderFrameEvent.END.invoker().onEnd(new RenderFrameEvent.Post(this.timer));
    }

    @Inject(method = "pickBlock", at = @At(value = "FIELD", target = "Lnet/minecraft/world/entity/player/Abilities;instabuild:Z", ordinal = 0), cancellable = true)
    private void sb$inputClickEvent(CallbackInfo ci) {
        AtomicBoolean canceled = new AtomicBoolean(false);
        BlockPickCanceller.onBlockPick(canceled);
        if (canceled.get())
            ci.cancel();
    }
}