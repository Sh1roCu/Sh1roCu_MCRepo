package mods.flammpfeil.slashblade.registry.combo;

import cn.sh1rocu.slashblade.api.extension.EntityExtension;
import com.google.common.collect.Maps;
import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.ability.ArrowReflector;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.init.DefaultResources;
import mods.flammpfeil.slashblade.registry.ComboStateRegistry;
import mods.flammpfeil.slashblade.slasharts.SlashArts;
import mods.flammpfeil.slashblade.util.AdvancementHelper;
import mods.flammpfeil.slashblade.util.TimeValueHelper;
import net.minecraft.class_1309;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nonnull;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;

public class ComboState {
    public static final class_5321<class_2378<ComboState>> REGISTRY_KEY = class_5321
            .method_29180(class_2960.method_60655(SlashBlade.MODID, "combo_state"));

    public static final TimeLineTickAction EMPTY_TICK_ACTION = TimeLineTickAction.getBuilder().build();

    private final class_2960 motionLoc;

    // frame
    private final int start;
    // frame
    private final int end;

    private final float speed;
    private final boolean loop;

    // Next input acceptance period *ms
    public int timeout;

    private final Function<class_1309, class_2960> next;
    private final Function<class_1309, class_2960> nextOfTimeout;

    private final Consumer<class_1309> holdAction;

    private final Consumer<class_1309> tickAction;

    private final BiConsumer<class_1309, class_1309> hitEffect;

    private final Consumer<class_1309> clickAction;

    private final BiFunction<class_1309, Integer, SlashArts.ArtsType> releaseAction;

    private final boolean isAerial;

    private final int priority;

    public class_2960 getMotionLoc() {
        return motionLoc;
    }

    public int getStartFrame() {
        return start;
    }

    public int getEndFrame() {
        return end;
    }

    public float getSpeed() {
        return speed;
    }

    public boolean getLoop() {
        return loop;
    }

    public int getTimeoutMS() {
        return (int) (TimeValueHelper.getMSecFromFrames(Math.abs(getEndFrame() - getStartFrame())) / getSpeed())
                + timeout;
    }

    public void holdAction(class_1309 user) {
        holdAction.accept(user);
    }

    public void tickAction(class_1309 user) {
        tickAction.accept(user);
    }

    public void hitEffect(class_1309 target, class_1309 attacker) {
        hitEffect.accept(target, attacker);
    }

    public void clickAction(class_1309 user) {
        clickAction.accept(user);
    }

    public SlashArts.ArtsType releaseAction(class_1309 user, int elapsed) {
        return this.releaseAction.apply(user, elapsed);
    }

    public static class_2960 getRegistryKey(ComboState state) {
        return ComboStateRegistry.COMBO_STATE.method_10221(state);
    }

    private ComboState(Builder builder) {
        this.start = builder.start;
        this.end = builder.end;

        this.speed = builder.speed;
        this.timeout = builder.timeout;
        this.loop = builder.loop;

        this.motionLoc = builder.motionLoc;

        this.next = builder.next;
        this.nextOfTimeout = builder.nextOfTimeout;

        this.holdAction = builder.holdAction;

        this.tickAction = builder.tickAction;

        this.hitEffect = builder.hitEffect;

        this.clickAction = builder.clickAction;

        this.releaseAction = builder.releaseAction;

        this.isAerial = builder.aerial;

        this.priority = builder.priority;
    }

    public class_2960 getNext(class_1309 living) {
        return this.next.apply(living);
    }

    public class_2960 getNextOfTimeout(class_1309 living) {
        return this.nextOfTimeout.apply(living);
    }

    @Nonnull
    public ComboState checkTimeOut(class_1309 living, float msec) {
        return this.getTimeoutMS() < msec ? ComboStateRegistry.COMBO_STATE.method_10223(this.nextOfTimeout.apply(living))
                : this;
    }

    public boolean isAerial() {
        return this.isAerial;
    }

    public int getPriority() {
        return priority;
    }

    public static SlashArts.ArtsType releaseActionQuickCharge(class_1309 user, Integer elapsed) {
        var holder = user.method_56673().method_46762(class_7924.field_41265).method_46747(class_1893.field_23071);
        int level = class_1890.method_8203(holder, user);
        if (elapsed <= 3 + level) {
            AdvancementHelper.grantedIf(class_1893.field_23071, user);
            AdvancementHelper.grantCriterion(user, AdvancementHelper.ADVANCEMENT_QUICK_CHARGE);
            return SlashArts.ArtsType.Jackpot;
        } else
            return SlashArts.ArtsType.Fail;
    }

    public static class TimeoutNext implements Function<class_1309, class_2960> {

        long timeout;
        Function<class_1309, class_2960> next;

        public static TimeoutNext buildFromFrame(int timeoutFrame, Function<class_1309, class_2960> next) {
            return new TimeoutNext((int) TimeValueHelper.getTicksFromFrames(timeoutFrame), next);
        }

        public TimeoutNext(long timeout, Function<class_1309, class_2960> next) {
            this.timeout = timeout;
            this.next = next;
        }

        @Override
        public class_2960 apply(class_1309 livingEntity) {

            long elapsed = ComboState.getElapsed(livingEntity);

            if (timeout <= elapsed) {
                return next.apply(livingEntity);
            } else {

                return CapabilitySlashBlade.getBladeState(livingEntity.method_6047())
                        .map(ISlashBladeState::getComboSeq).orElse(SlashBlade.prefix("none"));
            }
        }
    }

    public static class TimeLineTickAction implements Consumer<class_1309> {
        public static TimeLineTickActionBuilder getBuilder() {
            return new TimeLineTickActionBuilder();
        }

        public static class TimeLineTickActionBuilder {
            Map<Integer, Consumer<class_1309>> timeLine = Maps.newHashMap();

            public TimeLineTickActionBuilder put(int ticks, Consumer<class_1309> action) {
                timeLine.put(ticks, action);
                return this;
            }

            public TimeLineTickAction build() {
                return new TimeLineTickAction(timeLine);
            }
        }

        private final Map<Integer, Consumer<class_1309>> timeLine;

        public static final String LAST_PROCESSED_TICK_KEY = SlashBlade.MODID + ".lastProcessedTick";

        TimeLineTickAction(Map<Integer, Consumer<class_1309>> timeLine) {
            this.timeLine = Maps.newHashMap(timeLine);
        }

        @Override
        public void accept(class_1309 livingEntity) {
            int elapsed = (int) getElapsed(livingEntity);

            class_2487 persistentData = ((EntityExtension) livingEntity).sb$getPersistentData();

            if (persistentData.method_10550(LAST_PROCESSED_TICK_KEY) == elapsed) {
                return;
            }

            persistentData.method_10569(LAST_PROCESSED_TICK_KEY, elapsed);

            Consumer<class_1309> action = timeLine.get(elapsed);
            if (action != null) {
                action.accept(livingEntity);
            }
        }

        @Override
        public @NotNull Consumer<class_1309> andThen(@NotNull Consumer<? super class_1309> after) {
            Objects.requireNonNull(after);
            return (class_1309 livingEntity) -> {
                class_2487 persistentData = ((EntityExtension) livingEntity).sb$getPersistentData();
                int lastProcessedTick = persistentData.method_10550(LAST_PROCESSED_TICK_KEY);
                accept(livingEntity);
                persistentData.method_10569(LAST_PROCESSED_TICK_KEY, lastProcessedTick);
                after.accept(livingEntity);
            };
        }

        void defaultConsumer(class_1309 entityIn) {
        }
    }

    public static long getElapsed(class_1309 livingEntity) {
        return CapabilitySlashBlade.getBladeState(livingEntity.method_6047())
                .map((state) -> state.getElapsedTime(livingEntity)).orElse(0L);
    }

    public static class Builder {
        private int priority;
        private int start;
        private int end;
        private float speed;
        private boolean loop;
        private int timeout;
        private class_2960 motionLoc;
        private Function<class_1309, class_2960> next;
        private Function<class_1309, class_2960> nextOfTimeout;

        private boolean aerial;

        private Consumer<class_1309> holdAction;
        private Consumer<class_1309> tickAction;
        private BiConsumer<class_1309, class_1309> hitEffect;
        private Consumer<class_1309> clickAction;
        private BiFunction<class_1309, Integer, SlashArts.ArtsType> releaseAction;

        private Builder() {
            this.motionLoc = DefaultResources.ExMotionLocation;
            this.priority = 1000;
            this.timeout = 0;
            this.speed = 1.0F;
            this.loop = false;
            this.aerial = false;
            this.next = entity -> SlashBlade.prefix("none");
            this.tickAction = EMPTY_TICK_ACTION.andThen(ArrowReflector::doTicks);
            this.releaseAction = (u, e) -> SlashArts.ArtsType.Fail;
            this.holdAction = EMPTY_TICK_ACTION;
            this.hitEffect = (a, b) -> {
            };
            this.clickAction = (user) -> {
            };
        }

        public static Builder newInstance() {
            return new Builder();
        }

        public ComboState build() {
            return new ComboState(this);
        }

        public Builder startAndEnd(int start, int end) {
            this.start = start;
            this.end = end;
            return this;
        }

        public Builder priority(int priority) {
            this.priority = priority;
            return this;
        }

        public Builder speed(float speed) {
            this.speed = speed;
            return this;
        }

        public Builder loop() {
            this.loop = true;
            return this;
        }

        public Builder aerial() {
            this.aerial = true;
            return this;
        }

        public Builder timeout(int timeout) {
            this.timeout = timeout;
            return this;
        }

        public Builder motionLoc(class_2960 motionLoc) {
            this.motionLoc = motionLoc;
            return this;
        }

        public Builder next(Function<class_1309, class_2960> next) {
            this.next = next;
            return this;
        }

        public Builder nextOfTimeout(Function<class_1309, class_2960> nextOfTimeout) {
            this.nextOfTimeout = nextOfTimeout;
            return this;
        }

        public Builder addHoldAction(Consumer<class_1309> holdAction) {
            this.holdAction = this.holdAction.andThen(holdAction);
            return this;
        }

        public Builder addTickAction(Consumer<class_1309> tickAction) {
            this.tickAction = this.tickAction.andThen(tickAction);
            return this;
        }

        public Builder addHitEffect(BiConsumer<class_1309, class_1309> hitEffect) {
            this.hitEffect = this.hitEffect.andThen(hitEffect);
            return this;
        }

        public Builder clickAction(Consumer<class_1309> clickAction) {
            this.clickAction = clickAction;
            return this;
        }

        public Builder releaseAction(BiFunction<class_1309, Integer, SlashArts.ArtsType> clickAction) {
            this.releaseAction = clickAction;
            return this;
        }

    }
}
