package mods.flammpfeil.slashblade.event.handler;

import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.client.SlashBladeKeyMappings;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_310;
import net.minecraft.class_746;
import java.util.concurrent.atomic.AtomicBoolean;

@Environment(EnvType.CLIENT)
public class BlockPickCanceller {
    private static final class SingletonHolder {
        private static final BlockPickCanceller instance = new BlockPickCanceller();
    }

    public static BlockPickCanceller getInstance() {
        return SingletonHolder.instance;
    }

    public void register() {
        // InputEvent.InteractionKeyMappingTriggered.CLICK_INPUT_CALLBACK.register(this::onBlockPick);
    }

    public static void onBlockPick(AtomicBoolean canceled) {
//        if (!event.isPickBlock())
//            return;

        final class_310 instance = class_310.method_1551();
        class_746 player = instance.field_1724;
        if (player == null)
            return;
        if (KeyBindingHelper.getBoundKeyOf(SlashBladeKeyMappings.KEY_SUMMON_BLADE) != SlashBladeKeyMappings.KEY_SUMMON_BLADE.method_1429())
            return;
        if (CapabilitySlashBlade.getBladeState(player.method_6047()).isPresent()) {
            // event.setCanceled(true);
            canceled.set(true);
        }
    }
}
