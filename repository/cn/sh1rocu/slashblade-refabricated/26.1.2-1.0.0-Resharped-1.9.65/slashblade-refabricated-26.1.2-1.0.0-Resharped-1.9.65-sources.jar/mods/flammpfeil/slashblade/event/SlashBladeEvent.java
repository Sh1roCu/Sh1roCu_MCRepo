package mods.flammpfeil.slashblade.event;

import cn.sh1rocu.slashblade.api.event.BaseEvent;
import cn.sh1rocu.slashblade.api.event.ICancellableEvent;
import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.entity.BladeStandEntity;
import mods.flammpfeil.slashblade.entity.EntityAbstractSummonedSword;
import mods.flammpfeil.slashblade.slasharts.SlashArts;
import mods.flammpfeil.slashblade.util.KnockBacks;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.resources.Identifier;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public abstract class SlashBladeEvent extends BaseEvent {
    private final ItemStack blade;
    private final ISlashBladeState state;

    public static final Event<Break> BREAK = EventFactory.createArrayBacked(Break.class, callbacks -> event -> {
        for (Break callback : callbacks) {
            callback.onBreak(event);
        }
    });
    public static final Event<PowerBlade> POWER_BLADE = EventFactory.createArrayBacked(PowerBlade.class, callbacks -> event -> {
        for (PowerBlade callback : callbacks) {
            callback.onPower(event);
        }
    });
    public static final Event<NextCombo> NEXT_COMBO = EventFactory.createArrayBacked(NextCombo.class, callbacks -> event -> {
        for (NextCombo callback : callbacks) {
            callback.onNextCombo(event);
        }
    });
    public static final Event<NextOfTimeOutCombo> NEXT_OF_TIME_OUT_COMBO = EventFactory.createArrayBacked(NextOfTimeOutCombo.class, callbacks -> event -> {
        for (NextOfTimeOutCombo callback : callbacks) {
            callback.onNextOfTimeOutCombo(event);
        }
    });
    public static final Event<AddProudSoul> ADD_PROUD_SOUL = EventFactory.createArrayBacked(AddProudSoul.class, callbacks -> event -> {
        for (AddProudSoul callback : callbacks) {
            callback.onAddProudSoul(event);
        }
    });
    public static final Event<AddKillCount> ADD_KILL_COUNT = EventFactory.createArrayBacked(AddKillCount.class, callbacks -> event -> {
        for (AddKillCount callback : callbacks) {
            callback.onAddAddKillCount(event);
        }
    });
    public static final Event<UpdateAttack> UPDATE_ATTACK = EventFactory.createArrayBacked(UpdateAttack.class, callbacks -> event -> {
        for (UpdateAttack callback : callbacks) {
            callback.onUpdateAttack(event);
        }
    });
    public static final Event<BladeStandAttack> BLADE_STAND_ATTACK = EventFactory.createWithPhases(BladeStandAttack.class, callbacks -> event -> {
        for (BladeStandAttack callback : callbacks) {
            callback.onBladeStandAttack(event);
        }
    }, HIGHEST, HIGH, Event.DEFAULT_PHASE, LOW, LOWEST);
    public static final Event<BladeStandTick> BLADE_STAND_TICK = EventFactory.createArrayBacked(BladeStandTick.class, callbacks -> event -> {
        for (BladeStandTick callback : callbacks) {
            callback.onBladeStandTick(event);
        }
    });
    public static final Event<Hit> HIT = EventFactory.createArrayBacked(Hit.class, callbacks -> event -> {
        for (Hit callback : callbacks) {
            callback.onHit(event);
        }
    });
    public static final Event<Update> UPDATE = EventFactory.createArrayBacked(Update.class, callbacks -> event -> {
        for (Update callback : callbacks) {
            callback.onUpdate(event);
        }
    });
    public static final Event<DoSlash> DO_SLASH = EventFactory.createArrayBacked(DoSlash.class, callbacks -> event -> {
        for (DoSlash callback : callbacks) {
            callback.onDoSlash(event);
        }
    });
    public static final Event<PerformSlashArt> PERFORM_SLASH_ART = EventFactory.createArrayBacked(PerformSlashArt.class, callbacks -> event -> {
        for (PerformSlashArt callback : callbacks) {
            callback.onPerformSlashArt(event);
        }
    });
    public static final Event<ChargeAction> CHARGE_ACTION = EventFactory.createArrayBacked(ChargeAction.class, callbacks -> event -> {
        for (ChargeAction callback : callbacks) {
            callback.onChargeAction(event);
        }
    });
    public static final Event<SummonedSwordOnHitEntity> SUMMONEDSWORD_ONHIT_ENTITY = EventFactory.createArrayBacked(SummonedSwordOnHitEntity.class, callbacks -> event -> {
        for (SummonedSwordOnHitEntity callback : callbacks) {
            callback.onSummonedSwordOnHitEntity(event);
        }
    });

    public SlashBladeEvent(ItemStack blade, ISlashBladeState state) {
        this.blade = blade;
        this.state = state;
    }

    public ItemStack getBlade() {
        return blade;
    }

    public ISlashBladeState getSlashBladeState() {
        return state;
    }

    public static class BreakEvent extends SlashBladeEvent implements ICancellableEvent {
        public BreakEvent(ItemStack blade, ISlashBladeState state) {
            super(blade, state);
        }
    }

    public static class PowerBladeEvent extends SlashBladeEvent {
        private final LivingEntity user;
        private boolean isPowered;

        public PowerBladeEvent(ItemStack blade, ISlashBladeState state, LivingEntity user, boolean isPowered) {
            super(blade, state);
            this.user = user;
            this.setPowered(isPowered);
        }

        public boolean isPowered() {
            return isPowered;
        }

        public void setPowered(boolean isPowered) {
            this.isPowered = isPowered;
        }

        public LivingEntity getUser() {
            return user;
        }
    }

    public static class NextComboEvent extends SlashBladeEvent implements ICancellableEvent {
        private final LivingEntity user;
        private Identifier nextCombo;

        public NextComboEvent(ItemStack blade, ISlashBladeState state, LivingEntity user, Identifier combo) {
            super(blade, state);
            this.user = user;
            this.setNextCombo(combo);
        }

        public LivingEntity getUser() {
            return user;
        }

        public Identifier getNextCombo() {
            return nextCombo;
        }

        public void setNextCombo(Identifier nextCombo) {
            this.nextCombo = nextCombo;
        }

    }

    public static class NextOfTimeOutComboEvent extends SlashBladeEvent implements ICancellableEvent {
        private Identifier nextCombo;
        private final LivingEntity user;

        public NextOfTimeOutComboEvent(ItemStack blade, ISlashBladeState state, LivingEntity user, Identifier combo) {
            super(blade, state);
            this.user = user;
            this.setNextCombo(combo);
        }

        public LivingEntity getUser() {
            return user;
        }

        public Identifier getNextCombo() {
            return nextCombo;
        }

        public void setNextCombo(Identifier nextCombo) {
            this.nextCombo = nextCombo;
        }

    }

    public static class AddProudSoulEvent extends SlashBladeEvent {
        private final int originCount;
        private int newCount;

        public AddProudSoulEvent(ItemStack blade, ISlashBladeState state, int count) {
            super(blade, state);
            this.originCount = count;
            this.setNewCount(count);
        }

        public int getOriginCount() {
            return originCount;
        }

        public int getNewCount() {
            return newCount;
        }

        public void setNewCount(int newCount) {
            this.newCount = newCount;
        }
    }

    public static class AddKillCountEvent extends SlashBladeEvent {
        private final int originCount;
        private int newCount;

        public AddKillCountEvent(ItemStack blade, ISlashBladeState state, int count) {
            super(blade, state);
            this.originCount = count;
            this.setNewCount(count);
        }

        public int getOriginCount() {
            return originCount;
        }

        public int getNewCount() {
            return newCount;
        }

        public void setNewCount(int newCount) {
            this.newCount = newCount;
        }

    }

    public static class UpdateAttackEvent extends SlashBladeEvent {
        private final double originDamage;
        private double newDamage;

        public UpdateAttackEvent(ItemStack blade, ISlashBladeState state, double damage) {
            super(blade, state);
            this.originDamage = damage;
            this.newDamage = damage;
        }

        public double getNewDamage() {
            return newDamage;
        }

        public void setNewDamage(double newDamage) {
            this.newDamage = newDamage;
        }

        public double getOriginDamage() {
            return originDamage;
        }
    }

    public static class BladeStandAttackEvent extends SlashBladeEvent implements ICancellableEvent {
        private final BladeStandEntity bladeStand;
        private final DamageSource damageSource;

        public BladeStandAttackEvent(ItemStack blade, ISlashBladeState state, BladeStandEntity bladeStand, DamageSource damageSource) {
            super(blade, state);
            this.bladeStand = bladeStand;
            this.damageSource = damageSource;
        }

        public BladeStandEntity getBladeStand() {
            return bladeStand;
        }

        public DamageSource getDamageSource() {
            return damageSource;
        }

    }

    public static class BladeStandTickEvent extends SlashBladeEvent {
        private final BladeStandEntity bladeStand;

        public BladeStandTickEvent(ItemStack blade, ISlashBladeState state, BladeStandEntity bladeStand) {
            super(blade, state);
            this.bladeStand = bladeStand;
        }

        public BladeStandEntity getBladeStand() {
            return bladeStand;
        }

    }

    public static class HitEvent extends SlashBladeEvent implements ICancellableEvent {
        private final LivingEntity target;
        private final LivingEntity user;

        public HitEvent(ItemStack blade, ISlashBladeState state, LivingEntity target, LivingEntity user) {
            super(blade, state);
            this.target = target;
            this.user = user;
        }

        public LivingEntity getUser() {
            return user;
        }

        public LivingEntity getTarget() {
            return target;
        }

    }

    public static class UpdateEvent extends SlashBladeEvent implements ICancellableEvent {
        private final Level level;
        private final Entity entity;
        private final @Nullable EquipmentSlot slot;

        public UpdateEvent(ItemStack blade, ISlashBladeState state,
                           Level worldIn, Entity entityIn, @Nullable EquipmentSlot slot) {
            super(blade, state);
            this.level = worldIn;
            this.entity = entityIn;
            this.slot = slot;
        }

        public Level getLevel() {
            return level;
        }

        public Entity getEntity() {
            return entity;
        }

        public EquipmentSlot getEquipmentSlot() {
            return slot;
        }

    }

    public static class DoSlashEvent extends SlashBladeEvent implements ICancellableEvent {
        private final LivingEntity user;
        private float roll;
        private boolean critical;
        private double damage;
        private KnockBacks knockback;
        private float yRot = 0F;

        public DoSlashEvent(ItemStack blade, ISlashBladeState state, LivingEntity user,
                            float roll, boolean critical, double damage, KnockBacks knockback) {
            super(blade, state);
            this.user = user;
            this.roll = roll;
            this.critical = critical;
            this.knockback = knockback;
            this.damage = damage;
        }

        public LivingEntity getUser() {
            return user;
        }

        public float getRoll() {
            return roll;
        }

        public void setRoll(float roll) {
            this.roll = roll;
        }

        public boolean isCritical() {
            return critical;
        }

        public void setCritical(boolean critical) {
            this.critical = critical;
        }

        public double getDamage() {
            return damage;
        }

        public void setDamage(double damage) {
            this.damage = damage;
        }

        public KnockBacks getKnockback() {
            return knockback;
        }

        public void setKnockback(KnockBacks knockback) {
            this.knockback = knockback == null ? KnockBacks.cancel : knockback;
        }

        public float getYRot() {
            return yRot;
        }

        public void setYRot(float yRot) {
            this.yRot = yRot;
        }

    }


    public static class PerformSlashArtEvent extends BaseEvent implements ICancellableEvent {
        private final LivingEntity entityLiving;
        private final int elapsed;
        private final ISlashBladeState state;
        private Identifier comboState;
        private final SlashArts.ArtsType type;

        public PerformSlashArtEvent(LivingEntity entityLiving, int elapsed, ISlashBladeState state, Identifier comboState, SlashArts.ArtsType type) {
            this.entityLiving = entityLiving;
            this.elapsed = elapsed;
            this.state = state;
            this.comboState = comboState;
            this.type = type;
        }

        public LivingEntity getEntityLiving() {
            return entityLiving;
        }

        public int getElapsed() {
            return elapsed;
        }

        public ISlashBladeState getSlashBladeState() {
            return state;
        }

        public Identifier getComboState() {
            return comboState;
        }

        public void setComboState(Identifier comboState) {
            this.comboState = comboState;
        }

        public SlashArts.ArtsType getType() {
            return type;
        }
    }

    public static class ChargeActionEvent extends BaseEvent implements ICancellableEvent {
        private final LivingEntity entityLiving;
        private final int chargeTicks;
        private final ISlashBladeState state;

        public ChargeActionEvent(LivingEntity entityLiving, int chargeTicks, ISlashBladeState state) {
            this.entityLiving = entityLiving;
            this.chargeTicks = chargeTicks;
            this.state = state;
        }

        public LivingEntity getEntityLiving() {
            return entityLiving;
        }

        public int getChargeTicks() {
            return chargeTicks;
        }

        public ISlashBladeState getSlashBladeState() {
            return state;
        }

    }

    public static class SummonedSwordOnHitEntityEvent extends BaseEvent {
        private final EntityAbstractSummonedSword summonedSword;
        private final Entity target;

        public SummonedSwordOnHitEntityEvent(EntityAbstractSummonedSword summonedSword, Entity target) {
            this.summonedSword = summonedSword;
            this.target = target;
        }

        public EntityAbstractSummonedSword getSummonedSword() {
            return summonedSword;
        }

        public Entity getTarget() {
            return target;
        }
    }

    public interface Break {
        void onBreak(BreakEvent event);
    }

    public interface AddProudSoul {
        void onAddProudSoul(AddProudSoulEvent event);
    }

    public interface AddKillCount {
        void onAddAddKillCount(AddKillCountEvent event);
    }

    public interface PowerBlade {
        void onPower(PowerBladeEvent event);
    }

    public interface NextCombo {
        void onNextCombo(NextComboEvent event);
    }

    public interface NextOfTimeOutCombo {
        void onNextOfTimeOutCombo(NextOfTimeOutComboEvent event);
    }

    public interface UpdateAttack {
        void onUpdateAttack(UpdateAttackEvent event);
    }

    public interface BladeStandAttack {
        void onBladeStandAttack(BladeStandAttackEvent event);
    }

    public interface BladeStandTick {
        void onBladeStandTick(BladeStandTickEvent event);
    }

    public interface Hit {
        void onHit(HitEvent event);
    }

    public interface Update {
        void onUpdate(UpdateEvent event);
    }

    public interface DoSlash {
        void onDoSlash(DoSlashEvent event);
    }

    public interface PerformSlashArt {
        void onPerformSlashArt(PerformSlashArtEvent event);
    }

    public interface ChargeAction {
        void onChargeAction(ChargeActionEvent event);
    }

    public interface SummonedSwordOnHitEntity {
        void onSummonedSwordOnHitEntity(SummonedSwordOnHitEntityEvent event);
    }
}
