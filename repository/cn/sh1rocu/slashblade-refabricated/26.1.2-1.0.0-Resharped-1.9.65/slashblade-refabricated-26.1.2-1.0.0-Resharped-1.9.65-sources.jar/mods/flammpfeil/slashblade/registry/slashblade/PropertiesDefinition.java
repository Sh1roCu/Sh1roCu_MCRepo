package mods.flammpfeil.slashblade.registry.slashblade;

import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import mods.flammpfeil.slashblade.item.SwordType;
import mods.flammpfeil.slashblade.registry.ComboStateRegistry;
import mods.flammpfeil.slashblade.registry.SlashArtsRegistry;
import net.minecraft.resources.Identifier;

import java.util.List;

public class PropertiesDefinition {
    public static final Codec<PropertiesDefinition> CODEC = RecordCodecBuilder
            .create(instance -> instance
                    .group(Identifier.CODEC.optionalFieldOf("root_combo", ComboStateRegistry.getId(ComboStateRegistry.STANDBY))
                                    .forGetter(PropertiesDefinition::getComboRoot),
                            Identifier.CODEC.optionalFieldOf("slash_art", SlashArtsRegistry.SLASH_ARTS.getKey(SlashArtsRegistry.JUDGEMENT_CUT))
                                    .forGetter(PropertiesDefinition::getSpecialAttackType),
                            Codec.FLOAT.optionalFieldOf("attack_base", 4.0F)
                                    .forGetter(PropertiesDefinition::getBaseAttackModifier),
                            Codec.INT.optionalFieldOf("max_damage", 40).forGetter(PropertiesDefinition::getMaxDamage),
                            SwordType.CODEC.listOf().optionalFieldOf("sword_type", Lists.newArrayList())
                                    .forGetter(PropertiesDefinition::getDefaultType),
                            Identifier.CODEC.listOf().optionalFieldOf("special_effects", Lists.newArrayList())
                                    .forGetter(PropertiesDefinition::getSpecialEffects),
                            Codec.BOOL.optionalFieldOf("unbreakable", false)
                                    .forGetter(PropertiesDefinition::isUnbreakable)
                    )
                    .apply(instance, PropertiesDefinition::new));

    private final Identifier comboRoot;
    private final Identifier specialAttackType;
    private final float baseAttackModifier;
    private final int maxDamage;
    private final List<SwordType> defaultType;
    private final List<Identifier> specialEffects;
    private final boolean unbreakable;

    private PropertiesDefinition(Identifier comboRoot, Identifier specialAttackType,
                                 float baseAttackModifier, int damage, List<SwordType> defaultType, List<Identifier> specialEffects, boolean unbreakable) {
        this.comboRoot = comboRoot;
        this.specialAttackType = specialAttackType;
        this.baseAttackModifier = baseAttackModifier;
        this.maxDamage = damage;
        this.defaultType = defaultType;
        this.specialEffects = specialEffects;
        this.unbreakable = unbreakable;
    }


    public List<Identifier> getSpecialEffects() {
        return specialEffects;
    }

    public Identifier getComboRoot() {
        return comboRoot;
    }

    public Identifier getSpecialAttackType() {
        return specialAttackType;
    }

    public float getBaseAttackModifier() {
        return baseAttackModifier;
    }

    public int getMaxDamage() {
        return maxDamage;
    }

    public List<SwordType> getDefaultType() {
        return defaultType;
    }

    public boolean isUnbreakable() {
        return unbreakable;
    }

    public static class Builder {
        private Identifier comboRoot;
        private Identifier specialAttackType;
        private float baseAttackModifier;
        private int maxDamage;
        private List<SwordType> defaultType;
        private final List<Identifier> specialEffects;
        private boolean unbreakable;

        private Builder() {
            this.comboRoot = ComboStateRegistry.getId(ComboStateRegistry.STANDBY);
            this.specialAttackType = SlashArtsRegistry.SLASH_ARTS.getKey(SlashArtsRegistry.JUDGEMENT_CUT);
            this.baseAttackModifier = 4.0F;
            this.maxDamage = 40;
            this.defaultType = Lists.newArrayList();
            this.specialEffects = Lists.newArrayList();
            this.unbreakable = false;
        }

        public static Builder newInstance() {
            return new Builder();
        }

        public Builder rootComboState(Identifier comboRoot) {
            this.comboRoot = comboRoot;
            return this;
        }

        public Builder slashArtsType(Identifier specialAttackType) {
            this.specialAttackType = specialAttackType;
            return this;
        }

        public Builder baseAttackModifier(float baseAttackModifier) {
            this.baseAttackModifier = baseAttackModifier;
            return this;
        }

        public Builder maxDamage(int maxDamage) {
            this.maxDamage = maxDamage;
            return this;
        }

        public Builder defaultSwordType(List<SwordType> defaultType) {
            this.defaultType = defaultType;
            return this;
        }

        public Builder addSpecialEffect(Identifier se) {
            this.specialEffects.add(se);
            return this;
        }

        public Builder setUnbreakable(boolean unbreakable) {
            this.unbreakable = unbreakable;
            return this;
        }

        public PropertiesDefinition build() {
            return new PropertiesDefinition(comboRoot, specialAttackType, baseAttackModifier, maxDamage, defaultType, specialEffects, unbreakable);
        }
    }

}
