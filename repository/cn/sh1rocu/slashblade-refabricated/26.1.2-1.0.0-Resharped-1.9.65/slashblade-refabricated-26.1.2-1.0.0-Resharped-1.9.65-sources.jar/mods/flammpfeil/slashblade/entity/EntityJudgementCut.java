package mods.flammpfeil.slashblade.entity;

import cn.sh1rocu.slashblade.api.extension.EntityExtension;
import cn.sh1rocu.slashblade.util.PotionUtils;
import mods.flammpfeil.slashblade.init.SBEntityTypes;
import mods.flammpfeil.slashblade.util.AttackManager;
import mods.flammpfeil.slashblade.util.EnumSetConverter;
import mods.flammpfeil.slashblade.util.KnockBacks;
import mods.flammpfeil.slashblade.util.TargetSelector;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.List;

public class EntityJudgementCut extends Projectile implements IShootable {
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData
            .defineId(EntityJudgementCut.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> FLAGS = SynchedEntityData
            .defineId(EntityJudgementCut.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> RANK = SynchedEntityData.defineId(EntityJudgementCut.class,
            EntityDataSerializers.FLOAT);

    private int lifetime = 10;
    private int seed = -1;

    private double damage = 1.0D;

    private boolean cycleHit = false;

    public int getSeed() {
        return seed;
    }

    public boolean doCycleHit() {
        return cycleHit;
    }

    public void setCycleHit(boolean cycleHit) {
        this.cycleHit = cycleHit;
    }

    private final SoundEvent livingEntitySound = SoundEvents.WITHER_HURT;

    protected SoundEvent getHitEntitySound() {
        return this.livingEntitySound;
    }

    public EntityJudgementCut(EntityType<? extends Projectile> entityTypeIn, Level worldIn) {
        super(entityTypeIn, worldIn);
        this.setNoGravity(true);
        // this.setGlowing(true);

        this.seed = this.random.nextInt(360);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(COLOR, 0x3333FF);
        builder.define(FLAGS, 0);
        builder.define(RANK, 0.0f);
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);

        output.putInt("Color", this.getColor());
        output.putFloat("Rank", this.getRank());
        output.putDouble("damage", this.damage);
        output.putBoolean("crit", this.getIsCritical());
        output.putBoolean("clip", this.isNoClip());
        output.putInt("Lifetime", this.getLifetime());
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);

        this.setColor(input.getIntOr("Color", 0x3333FF));
        this.setRank(input.getFloatOr("Rank", 0));
        this.damage = input.getDoubleOr("damage", 0);
        this.setIsCritical(input.getBooleanOr("crit", false));
        this.setNoClip(input.getBooleanOr("clip", false));
        this.setLifetime(input.getIntOr("Lifetime", 0));
    }

    @Override
    public void shoot(double x, double y, double z, float velocity, float inaccuracy) {
        this.setDeltaMovement(0, 0, 0);
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        double d0 = this.getBoundingBox().getSize() * 10.0D;
        if (Double.isNaN(d0)) {
            d0 = 1.0D;
        }

        d0 = d0 * 64.0D * getViewScale();
        return distance < d0 * d0;
    }

    @Override
    public void lerpMotion(Vec3 movement) {
        this.setDeltaMovement(0, 0, 0);
    }

    enum FlagsState {
        Critical, NoClip,
    }

    EnumSet<FlagsState> flags = EnumSet.noneOf(FlagsState.class);
    int intFlags = 0;

    private void setFlags(FlagsState value) {
        this.flags.add(value);
        refreshFlags();
    }

    private void removeFlags(FlagsState value) {
        this.flags.remove(value);
        refreshFlags();
    }

    private void refreshFlags() {
        if (this.level().isClientSide()) {
            int newValue = this.entityData.get(FLAGS).intValue();
            if (intFlags != newValue) {
                intFlags = newValue;
                flags = EnumSetConverter.convertToEnumSet(FlagsState.class, intFlags);
            }
        } else {
            int newValue = EnumSetConverter.convertToInt(this.flags);
            if (this.intFlags != newValue) {
                this.entityData.set(FLAGS, newValue);
                this.intFlags = newValue;
            }
        }
    }

    public void setIsCritical(boolean value) {
        if (value)
            setFlags(FlagsState.Critical);
        else
            removeFlags(FlagsState.Critical);
    }

    public boolean getIsCritical() {
        refreshFlags();
        return flags.contains(FlagsState.Critical);
    }

    public void setNoClip(boolean value) {
        this.noPhysics = value;
        if (value)
            setFlags(FlagsState.NoClip);
        else
            removeFlags(FlagsState.NoClip);
    }

    // disallowedHitBlock
    public boolean isNoClip() {
        if (!this.level().isClientSide()) {
            return this.noPhysics;
        } else {
            refreshFlags();
            return flags.contains(FlagsState.NoClip);
        }
    }

    @Override
    public void tick() {
        super.tick();

        if (tickCount < 8 && tickCount % 2 == 0) {
            this.playSound(getHitEntitySound(), 0.2F, 0.5F + 0.25f * this.random.nextFloat());
        }

        if (this.getShooter() != null) {

            // cyclehit
            if (this.tickCount % 2 == 0) {
                KnockBacks knockBackType = getIsCritical() ? KnockBacks.toss : KnockBacks.cancel;
                AttackManager.areaAttack(this, knockBackType.action, 4.0, true, false, 0.16f, null);
            }

            final int count = 3;
            if (getIsCritical() && 0 < tickCount && tickCount <= count) {
                EntitySlashEffect jc = new EntitySlashEffect(SBEntityTypes.SLASH_EFFECT, this.level());
                jc.absSnapTo(this.getX(), this.getY(), this.getZ(), (360.0f / count) * tickCount + this.seed, 0);
                jc.setRotationRoll(30);

                jc.setOwner(this.getShooter());

                jc.setMute(false);
                jc.setIsCritical(true);

                jc.setDamage(0.1F);

                jc.setColor(this.getColor());
                jc.setBaseSize(0.5f);

                jc.setKnockBack(KnockBacks.cancel);

                jc.setIndirect(true);

                jc.setRank(this.getRank());

                this.level().addFreshEntity(jc);
            }
        }

        tryDespawn();

    }

    protected void tryDespawn() {
        if (!this.level().isClientSide()) {
            if (getLifetime() < this.tickCount) {
                this.burst();
            }
        }
    }

    /*
     * @Override
     * protected void onHitEntity(EntityRayTraceResult p_213868_1_) { Entity
     * targetEntity = p_213868_1_.getEntity(); float f =
     * (float)this.getMotion().length(); int i = MathHelper.ceil(Math.max((double)f
     * * this.damage, 0.0D));
     *
     * if (this.getIsCritical()) { i += this.rand.nextInt(i / 2 + 2); }
     *
     * Entity shooter = this.getShooter(); DamageSource damagesource; if (shooter ==
     * null) { damagesource = CustomDamageSource.causeSummonedSwordDamage(this,
     * this); } else { damagesource =
     * CustomDamageSource.causeSummonedSwordDamage(this, shooter); if (shooter
     * instanceof LivingEntity) {
     * ((LivingEntity)shooter).setLastAttackedEntity(targetEntity); } }
     *
     * int fireTime = targetEntity.getRemainingFireTicks(); if (this.isBurning() &&
     * !(targetEntity instanceof EndermanEntity)) { targetEntity.setFire(5); }
     *
     * if (targetEntity.attackEntityFrom(damagesource, (float)i)) { if (targetEntity
     * instanceof LivingEntity) { LivingEntity targetLivingEntity =
     * (LivingEntity)targetEntity;
     *
     * if (!this.world.isRemote && shooter instanceof LivingEntity) {
     * EnchantmentHelper.applyThornEnchantments(targetLivingEntity, shooter);
     * EnchantmentHelper.applyArthropodEnchantments((LivingEntity)shooter,
     * targetLivingEntity); }
     *
     * //this.arrowHit(targetLivingEntity);
     *
     * affectEntity(targetLivingEntity, getPotionEffects(), 1.0f);
     *
     * if (shooter != null && targetLivingEntity != shooter && targetLivingEntity
     * instanceof PlayerEntity && shooter instanceof ServerPlayerEntity) {
     * ((ServerPlayerEntity)
     * shooter).playNotifySound(this.getHitEntityPlayerSound(),
     * SoundCategory.PLAYERS, 0.18F, 0.45F); } }
     *
     * this.playSound(this.getHitEntitySound(), 1.0F, 1.2F / (this.rand.nextFloat()
     * * 0.2F + 0.9F)); } else { targetEntity.func_223308_g(fireTime);
     * this.setMotion(this.getMotion().scale(-0.1D)); this.rotationYaw += 180.0F;
     * this.prevRotationYaw += 180.0F; if (!this.world.isRemote &&
     * this.getMotion().lengthSquared() < 1.0E-7D) { this.burst(); } }
     *
     * }
     */

    public int getColor() {
        return this.getEntityData().get(COLOR);
    }

    public void setColor(int value) {
        this.getEntityData().set(COLOR, value);
    }

    public float getRank() {
        return this.getEntityData().get(RANK);
    }

    public void setRank(float value) {
        this.getEntityData().set(RANK, value);
    }

    public int getLifetime() {
        return Math.min(this.lifetime, 1000);
    }

    public void setLifetime(int value) {
        this.lifetime = value;
    }

    @Nullable
    @Override
    public Entity getShooter() {
        return this.getOwner();
    }

    @Override
    public void setShooter(Entity shooter) {
        setOwner(shooter);
    }

    public List<MobEffectInstance> getPotionEffects() {
        List<MobEffectInstance> effects = PotionUtils.getAllEffects(((EntityExtension) this).sb$getPersistentData());

        if (effects.isEmpty())
            effects.add(new MobEffectInstance(MobEffects.POISON, 1, 1));

        return effects;
    }

    public void burst() {
        // this.playSound(SoundEvents.BLOCK_GLASS_BREAK, 1.0F, 1.2F /
        // (this.rand.nextFloat() * 0.2F + 0.9F));

        if (!this.level().isClientSide()) {
            if (this.level() instanceof ServerLevel)
                ((ServerLevel) this.level()).sendParticles(ParticleTypes.CRIT, this.getX(), this.getY(), this.getZ(),
                        16, 0.5, 0.5, 0.5, 0.25f);

            this.burst(getPotionEffects(), null);
        }

        super.remove(RemovalReason.DISCARDED);
    }

    public void burst(List<MobEffectInstance> effects, @Nullable Entity focusEntity) {
        // AABB axisalignedbb = this.getBoundingBox().inflate(4.0D, 2.0D, 4.0D);
        List<Entity> list = TargetSelector.getTargettableEntitiesWithinAABB(this.level(), 2, this);
        // this.world.getEntitiesWithinAABB(LivingEntity.class, axisalignedbb);

        list.stream().filter(e -> e instanceof LivingEntity).map(e -> (LivingEntity) e).forEach(e -> {
            double distanceSq = TargetSelector.distanceSqrBetweenEntity(this, e);
            if (distanceSq < 9.0D) {
                double factor = 1.0D - Math.sqrt(distanceSq) / 4.0D;
                if (e == focusEntity) {
                    factor = 1.0D;
                }

                affectEntity(e, effects, factor);
            }
        });
    }

    public void affectEntity(LivingEntity focusEntity, List<MobEffectInstance> effects, double factor) {
        for (MobEffectInstance effectinstance : getPotionEffects()) {
            var holder = effectinstance.getEffect();
            MobEffect effect = holder.value();
            if (effect.isInstantenous() && this.level() instanceof ServerLevel serverLevel) {
                effect.applyInstantenousEffect(serverLevel, this, this.getShooter(), focusEntity, effectinstance.getAmplifier(),
                        factor);
            } else {
                int duration = (int) (factor * (double) effectinstance.getDuration() + 0.5D);
                if (duration > 0) {
                    focusEntity.addEffect(new MobEffectInstance(holder, duration, effectinstance.getAmplifier(),
                            effectinstance.isAmbient(), effectinstance.isVisible()));
                }
            }
        }
    }

    public void setDamage(double damageIn) {
        this.damage = damageIn;
    }

    @Override
    public double getDamage() {
        return this.damage;
    }

    @Nullable
    public EntityHitResult getRayTrace(Vec3 p_213866_1_, Vec3 p_213866_2_) {
        return ProjectileUtil.getEntityHitResult(this.level(), this, p_213866_1_, p_213866_2_,
                this.getBoundingBox().expandTowards(this.getDeltaMovement()).inflate(1.0D), (p_213871_1_) -> {
                    return !p_213871_1_.isSpectator() && p_213871_1_.isAlive() && p_213871_1_.isPickable()
                            && (p_213871_1_ != this.getShooter());
                });
    }
}
