package mods.flammpfeil.slashblade.entity;

import cn.sh1rocu.slashblade.api.extension.EntityExtension;
import cn.sh1rocu.slashblade.util.PotionUtils;
import cn.sh1rocu.slashblade.util.SoundUtil;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import mods.flammpfeil.slashblade.ability.StunManager;
import mods.flammpfeil.slashblade.event.SlashBladeEvent;
import mods.flammpfeil.slashblade.util.AttackManager;
import mods.flammpfeil.slashblade.util.EnumSetConverter;
import mods.flammpfeil.slashblade.util.TargetSelector;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.*;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;

import static mods.flammpfeil.slashblade.SlashBladeConfig.SLASHBLADE_DAMAGE_MULTIPLIER;

public class EntityAbstractSummonedSword extends Projectile implements IShootable, EntityExtension {
    private static final EntityDataAccessor<Integer> COLOR = SynchedEntityData
            .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> FLAGS = SynchedEntityData
            .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> HIT_ENTITY_ID = SynchedEntityData
            .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> OFFSET_YAW = SynchedEntityData
            .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> ROLL = SynchedEntityData
            .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Byte> PIERCE = SynchedEntityData.defineId(EntityAbstractSummonedSword.class,
            EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<String> MODEL = SynchedEntityData
            .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> DELAY = SynchedEntityData
            .defineId(EntityAbstractSummonedSword.class, EntityDataSerializers.INT);

    private int ticksInGround;
    private boolean inGround;
    private BlockState inBlockState;
    protected int ticksInAir;
    private double damage = 1.0D;

    private IntOpenHashSet alreadyHits;

    protected boolean isAlreadyHit(Entity entity) {
        return alreadyHits != null && alreadyHits.contains(entity.getId());
    }

    private Entity hitEntity = null;

    static final int ON_GROUND_LIFE_TIME_DEFAULT = 20 * 5;

    protected int getOnGroundLifeTime() {
        return ON_GROUND_LIFE_TIME_DEFAULT;
    }

    private final SoundEvent hitEntitySound = SoundEvents.TRIDENT_HIT;
    private final SoundEvent hitEntityPlayerSound = SoundEvents.TRIDENT_HIT;
    private final SoundEvent hitGroundSound = SoundEvents.TRIDENT_HIT_GROUND;

    protected SoundEvent getHitEntitySound() {
        return this.hitEntitySound;
    }

    protected SoundEvent getHitEntityPlayerSound() {
        return this.hitEntityPlayerSound;
    }

    protected SoundEvent getHitGroundSound() {
        return this.hitGroundSound;
    }

    public EntityAbstractSummonedSword(EntityType<? extends Projectile> entityTypeIn, Level worldIn) {
        super(entityTypeIn, worldIn);
        this.setNoGravity(true);
        // this.setGlowing(true);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(COLOR, 0x3333FF);
        builder.define(FLAGS, 0);
        builder.define(HIT_ENTITY_ID, -1);
        builder.define(OFFSET_YAW, 0f);
        builder.define(ROLL, 0f);
        builder.define(PIERCE, (byte) 0);
        builder.define(MODEL, "");
        builder.define(DELAY, 10);
    }

    @Override
    public void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);

        output.putInt("Color", this.getColor());
        output.putInt("life", this.ticksInGround);
        output.storeNullable("inBlockState", CompoundTag.CODEC, (this.inBlockState != null ? NbtUtils.writeBlockState(this.inBlockState) : null));
        output.putBoolean("inGround", this.inGround);
        output.putDouble("damage", this.damage);
        output.putBoolean("crit", this.getIsCritical());
        output.putBoolean("clip", this.isNoClip());
        output.putByte("PierceLevel", this.getPierce());
        output.putString("model", this.getModelName());
        output.putInt("Delay", this.getDelay());
    }

    @Override
    public void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);

        this.setColor(input.getIntOr("Color", 0x3333FF));
        this.ticksInGround = input.getIntOr("life", 0);
        input.read("inBlockState", CompoundTag.CODEC).ifPresent(tag ->
                this.inBlockState = NbtUtils.readBlockState(this.level().holderLookup(Registries.BLOCK), tag)
        );
        this.inGround = input.getBooleanOr("inGround", false);
        this.damage = input.getDoubleOr("damage", 0);
        this.setIsCritical(input.getBooleanOr("crit", false));
        this.setNoClip(input.getBooleanOr("clip", false));
        this.setPierce(input.getByteOr("PierceLevel", (byte) 0));
        this.setModelName(input.getStringOr("model", defaultModelName));
        this.setDelay(input.getIntOr("Delay", 0));
    }

    @Override
    public void shoot(double x, double y, double z, float velocity, float inaccuracy) {
        Vec3 vec3d = (new Vec3(x, y, z)).normalize()
                .add(this.random.nextGaussian() * (double) 0.0075F * (double) inaccuracy,
                        this.random.nextGaussian() * (double) 0.0075F * (double) inaccuracy,
                        this.random.nextGaussian() * (double) 0.0075F * (double) inaccuracy)
                .scale(velocity);
        this.setDeltaMovement(vec3d);
        float f = Mth.sqrt((float) vec3d.horizontalDistanceSqr());
        this.setYRot((float) (Mth.atan2(vec3d.x, vec3d.z) * (double) (180F / (float) Math.PI)));
        this.setXRot((float) (Mth.atan2(vec3d.y, f) * (double) (180F / (float) Math.PI)));
        this.yRotO = this.getYRot();
        this.xRotO = this.getXRot();
        this.ticksInGround = 0;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        double d0 = this.getBoundingBox().getSize() * 10.0D;
        if (Double.isNaN(d0)) {
            d0 = 1.0D;
        }

        d0 = d0 * 64.0D * getViewScale();
        return distance < d0 * d0;
    }

    @Override
    public void lerpMotion(Vec3 movement) {
        this.setDeltaMovement(movement);
        if (this.xRotO == 0.0F && this.yRotO == 0.0F) {
            double x = movement.x;
            double y = movement.y;
            double z = movement.z;
            float f = Mth.sqrt((float) (x * x + z * z));
            this.setXRot((float) (Mth.atan2(y, f) * (double) (180F / (float) Math.PI)));
            this.setYRot((float) (Mth.atan2(x, z) * (double) (180F / (float) Math.PI)));
            this.xRotO = this.getXRot();
            this.yRotO = this.getYRot();
            this.snapTo(this.getX(), this.getY(), this.getZ(), this.getYRot(), this.getXRot());
            this.ticksInGround = 0;
        }

    }

    enum FlagsState {
        Critical, NoClip,
    }

    protected EnumSet<FlagsState> flags = EnumSet.noneOf(FlagsState.class);
    protected int intFlags = 0;

    protected void setFlags(FlagsState value) {
        this.flags.add(value);
        refreshFlags();
    }

    protected void removeFlags(FlagsState value) {
        this.flags.remove(value);
        refreshFlags();
    }

    private void refreshFlags() {
        if (this.level().isClientSide()) {
            int newValue = this.entityData.get(FLAGS).intValue();
            if (intFlags != newValue) {
                intFlags = newValue;
                flags = EnumSetConverter.convertToEnumSet(FlagsState.class, intFlags);
            }
        } else {
            int newValue = EnumSetConverter.convertToInt(this.flags);
            if (this.intFlags != newValue) {
                this.entityData.set(FLAGS, newValue);
                this.intFlags = newValue;
            }
        }
    }

    public void setIsCritical(boolean value) {
        if (value)
            setFlags(FlagsState.Critical);
        else
            removeFlags(FlagsState.Critical);
    }

    public boolean getIsCritical() {
        refreshFlags();
        return flags.contains(FlagsState.Critical);
    }

    public void setNoClip(boolean value) {
        this.noPhysics = value;
        if (value)
            setFlags(FlagsState.NoClip);
        else
            removeFlags(FlagsState.NoClip);
    }

    // disallowedHitBlock
    public boolean isNoClip() {
        if (!this.level().isClientSide()) {
            return this.noPhysics;
        } else {
            refreshFlags();
            return flags.contains(FlagsState.NoClip);
        }
    }

    @Override
    public void tick() {
        super.tick();

        if (getHitEntity() != null) {
            Entity hits = getHitEntity();

            if (!hits.isAlive()) {
                this.burst();
            } else {
                this.setPos(hits.getX(), hits.getY() + hits.getEyeHeight() * 0.5f, hits.getZ());

                int delay = getDelay();
                delay--;
                setDelay(delay);

                if (!this.level().isClientSide() && delay < 0) {
                    this.burst();
                }
            }

            return;
        }

        boolean disallowedHitBlock = this.isNoClip();

        BlockPos blockpos = this.getOnPos();
        BlockState blockstate = this.level().getBlockState(blockpos);
        if (!blockstate.isAir() && !disallowedHitBlock) {
            VoxelShape voxelshape = blockstate.getCollisionShape(this.level(), blockpos);
            if (!voxelshape.isEmpty()) {
                for (AABB axisalignedbb : voxelshape.toAabbs()) {
                    if (axisalignedbb.move(blockpos).contains(new Vec3(this.getX(), this.getY(), this.getZ()))) {
                        this.inGround = true;
                        break;
                    }
                }
            }
        }

        if (this.isInWaterOrRain()) {
            this.clearFire();
        }

        if (this.inGround && !disallowedHitBlock) {
            if (!this.inBlockState.equals(blockstate) && this.level().noCollision(this.getBoundingBox().inflate(0.06D))) {
                // block breaked
                this.burst();
            } else if (!this.level().isClientSide()) {
                // onBlock
                this.tryDespawn();
            }
        } else {
            // process pose
            Vec3 motionVec = this.getDeltaMovement();
            if (this.xRotO == 0.0F && this.yRotO == 0.0F) {
                float f = Mth.sqrt((float) motionVec.horizontalDistanceSqr());
                this.setYRot((float) (Mth.atan2(motionVec.x, motionVec.z) * (double) (180F / (float) Math.PI)));
                this.setXRot((float) (Mth.atan2(motionVec.y, f) * (double) (180F / (float) Math.PI)));
                this.yRotO = this.getYRot();
                this.xRotO = this.getXRot();
            }

            // process inAir
            ++this.ticksInAir;
            Vec3 positionVec = this.position();
            Vec3 movedVec = positionVec.add(motionVec);
            HitResult raytraceresult = this.level().clip(
                    new ClipContext(positionVec, movedVec, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
            if (raytraceresult.getType() != HitResult.Type.MISS) {
                movedVec = raytraceresult.getLocation();
            }

            while (this.isAlive()) {
                // todo : replace TargetSelector
                EntityHitResult entityHit = this.getRayTrace(positionVec, movedVec);
                if (entityHit != null) {
                    raytraceresult = entityHit;
                }

                if (raytraceresult == null) {
                    break;
                }

                // boolean impactCheck = !net.neoforged.neoforge.event.EventHooks.onProjectileImpact(this, raytraceresult);

                if (raytraceresult.getType() == HitResult.Type.ENTITY /*&& impactCheck*/) {
                    Entity target = null;
                    if (raytraceresult instanceof EntityHitResult entityHitResult) {
                        target = entityHitResult.getEntity();
                    }
                    Entity shooter = this.getShooter();
                    if (target instanceof LivingEntity && shooter instanceof LivingEntity && target.level() instanceof ServerLevel serverLevel) {
                        if (!TargetSelector.test.test(serverLevel, (LivingEntity) shooter, (LivingEntity) target)) {
                            raytraceresult = null;
                            entityHit = null;
                        }
                    }
                }

                if (raytraceresult != null
                        && !(disallowedHitBlock && raytraceresult.getType() == HitResult.Type.BLOCK)
                       /* && impactCheck*/) {
                    this.onHit(raytraceresult);
                    //this.hasImpulse = true;
                } else if (/*!impactCheck &&*/ entityHit != null) {
                    Entity cancelledTarget = entityHit.getEntity();
                    if (this.alreadyHits == null) {
                        this.alreadyHits = new IntOpenHashSet(5);
                    }
                    this.alreadyHits.add(cancelledTarget.getId());
                }

                if (entityHit == null || this.getPierce() <= 0) {
                    break;
                }

                raytraceresult = null;
            }

            motionVec = this.getDeltaMovement();
            double mx = motionVec.x;
            double my = motionVec.y;
            double mz = motionVec.z;
            if (this.getIsCritical()) {
                for (int i = 0; i < 4; ++i) {
                    this.level().addParticle(ParticleTypes.CRIT, this.getX() + mx * (double) i / 4.0D,
                            this.getY() + my * (double) i / 4.0D, this.getZ() + mz * (double) i / 4.0D, -mx, -my + 0.2D,
                            -mz);
                }
            }

            this.setPos(this.getX() + mx, this.getY() + my, this.getZ() + mz);
            float f4 = Mth.sqrt((float) motionVec.horizontalDistanceSqr());
            if (disallowedHitBlock) {
                this.setYRot((float) (Mth.atan2(-mx, -mz) * (double) (180F / (float) Math.PI)));
            } else {
                this.setYRot((float) (Mth.atan2(mx, mz) * (double) (180F / (float) Math.PI)));
            }

            for (this.setXRot((float) (Mth.atan2(my, f4) * (double) (180F / (float) Math.PI))); this.getXRot()
                    - this.xRotO < -180.0F; this.xRotO -= 360.0F) {
            }

            while (this.getXRot() - this.xRotO >= 180.0F) {
                this.xRotO += 360.0F;
            }

            while (this.getYRot() - this.yRotO < -180.0F) {
                this.yRotO -= 360.0F;
            }

            while (this.getYRot() - this.yRotO >= 180.0F) {
                this.yRotO += 360.0F;
            }

            this.setXRot(Mth.lerp(0.2F, this.xRotO, this.getXRot()));
            this.setYRot(Mth.lerp(0.2F, this.yRotO, this.getYRot()));
            float f1 = 0.99F;
            if (this.isInWater()) {
                for (int j = 0; j < 4; ++j) {
                    this.level().addParticle(ParticleTypes.BUBBLE, this.getX() - mx * 0.25D, this.getY() - my * 0.25D,
                            this.getZ() - mz * 0.25D, mx, my, mz);
                }
            }

            this.setDeltaMovement(motionVec.scale(f1));
            if (!this.isNoGravity() && !disallowedHitBlock) {
                Vec3 vec3d3 = this.getDeltaMovement();
                this.setDeltaMovement(vec3d3.x, vec3d3.y - (double) 0.05F, vec3d3.z);
            }

            // this.setPosition(this.getPosX(), this.getPosY(), this.getPosZ());
            this.applyEffectsFromBlocks();
        }

        if (!this.level().isClientSide() && ticksInGround <= 0 && 100 < this.tickCount) {
            this.remove(RemovalReason.DISCARDED);
        }

    }

    protected void tryDespawn() {
        ++this.ticksInGround;
        if (getOnGroundLifeTime() <= this.ticksInGround) {
            this.burst();
        }

    }

    @Override
    protected void onHit(HitResult raytraceResultIn) {
        HitResult.Type type = raytraceResultIn.getType();
        switch (type) {
            case ENTITY:
                this.onHitEntity((EntityHitResult) raytraceResultIn);
                break;
            case BLOCK:
                this.onHitBlock((BlockHitResult) raytraceResultIn);
                break;
            default:
                break;
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult blockraytraceresult) {
        BlockState blockstate = this.level().getBlockState(blockraytraceresult.getBlockPos());
        this.inBlockState = blockstate;
        Vec3 vec3d = blockraytraceresult.getLocation().subtract(this.getX(), this.getY(), this.getZ());
        this.setDeltaMovement(vec3d);
        Vec3 vec3d1 = this.position().subtract(vec3d.normalize().scale(0.05F));
        this.setPos(vec3d1.x, vec3d1.y, vec3d1.z);
        this.playSound(this.getHitGroundSound(), 1.0F, 2.2F / (this.random.nextFloat() * 0.2F + 0.9F));
        this.inGround = true;
        this.setIsCritical(false);
        this.setPierce((byte) 0);
        this.resetAlreadyHits();
        blockstate.onProjectileHit(this.level(), blockstate, blockraytraceresult, this);
    }

    public void doForceHitEntity(Entity target) {
        if (target != null) {
            onHitEntity(new EntityHitResult(target));
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult entityHitResult) {
        Entity targetEntity = entityHitResult.getEntity();

//        if (targetEntity.getType().is(SlashBladeEntityTypeTagProvider.EntityTypeTags.ATTACKABLE_BLACKLIST))
//            return;

        SlashBladeEvent.SummonedSwordOnHitEntityEvent event = new SlashBladeEvent.SummonedSwordOnHitEntityEvent(this, targetEntity);
        SlashBladeEvent.SUMMONEDSWORD_ONHIT_ENTITY.invoker().onSummonedSwordOnHitEntity(event);
        int i = Mth.ceil(this.getDamage());
        if (this.getPierce() > 0) {
            if (this.alreadyHits == null) {
                this.alreadyHits = new IntOpenHashSet(5);
            }

            if (this.alreadyHits.size() >= this.getPierce() + 1) {
                this.burst();
                return;
            }

            this.alreadyHits.add(targetEntity.getId());
        }

        if (this.getIsCritical()) {
            i += this.random.nextInt(i / 2 + 2);
        }

        Entity shooter = this.getShooter();
        DamageSource damagesource;
        if (shooter == null) {
            damagesource = this.damageSources().indirectMagic(this, this);
        } else {
            damagesource = this.damageSources().indirectMagic(this, shooter);
            if (shooter instanceof LivingEntity) {
                Entity hits = targetEntity;
//                if (targetEntity instanceof PartEntity) {
//                    hits = ((PartEntity<?>) targetEntity).getParent();
//                }
                ((LivingEntity) shooter).setLastHurtMob(hits);
            }
        }

        int fireTime = targetEntity.getRemainingFireTicks();
        if (this.isOnFire() && !(targetEntity instanceof EnderMan)) {
            targetEntity.igniteForSeconds(5);
        }

        // todo: attack manager
        targetEntity.invulnerableTime = 0;
        float scale = 1f;
        if (shooter instanceof LivingEntity living) {
            scale = (float) (AttackManager.getSlashBladeDamageScale(living) * SLASHBLADE_DAMAGE_MULTIPLIER.get());
        }
        float damageValue = i * scale;
        if (targetEntity.level() instanceof ServerLevel serverLevel && targetEntity.hurtServer(serverLevel, damagesource, damageValue)) {
            Entity hits = targetEntity;
//            if (targetEntity instanceof PartEntity) {
//                hits = ((PartEntity<?>) targetEntity).getParent();
//            }

            if (hits instanceof LivingEntity targetLivingEntity) {

                StunManager.setStun(targetLivingEntity);

                if (!this.level().isClientSide() && this.getPierce() <= 0) {
                    setHitEntity(hits);
                }

                if (!this.level().isClientSide() && shooter instanceof LivingEntity) {
                    EnchantmentHelper.doPostAttackEffects((ServerLevel) targetLivingEntity.level(), targetLivingEntity, damagesource);
                }

                // this.arrowHit(targetLivingEntity);

                affectEntity(targetLivingEntity, getPotionEffects(), 1.0f);

                if (shooter != null && targetLivingEntity != shooter && targetLivingEntity instanceof Player
                        && shooter instanceof ServerPlayer) {
                    SoundUtil.playNotifySound(((ServerPlayer) shooter), this.getHitEntityPlayerSound(), SoundSource.PLAYERS, 0.18F,
                            0.45F);
                }
            }

            this.playSound(this.getHitEntitySound(), 1.0F, 1.2F / (this.random.nextFloat() * 0.2F + 0.9F));
            if (this.getPierce() <= 0 && (getHitEntity() == null || !getHitEntity().isAlive())) {
                this.burst();
            }
        } else {
            targetEntity.setRemainingFireTicks(fireTime);
            // this.setMotion(this.getMotion().scale(-0.1D));
            // this.setYRot(this.getYRot() + 180.0F);
            // this.yRotO += 180.0F;
            this.ticksInAir = 0;
            if (!this.level().isClientSide() && this.getDeltaMovement().lengthSqr() < 1.0E-7D) {
                if (getPierce() <= 1)
                    this.burst();
                else
                    this.setPierce((byte) (getPierce() - 1));
            }
        }

    }

    public int getColor() {
        return this.getEntityData().get(COLOR);
    }

    public void setColor(int value) {
        this.getEntityData().set(COLOR, value);
    }

    public byte getPierce() {
        return this.getEntityData().get(PIERCE);
    }

    public void setPierce(byte value) {
        this.getEntityData().set(PIERCE, value);
    }

    public int getDelay() {
        return this.getEntityData().get(DELAY);
    }

    public void setDelay(int value) {
        this.getEntityData().set(DELAY, value);
    }

    @Nullable
    protected EntityHitResult getRayTrace(Vec3 from, Vec3 to) {
        return ProjectileUtil.getEntityHitResult(this.level(), this, from, to,
                this.getBoundingBox().expandTowards(this.getDeltaMovement()).inflate(1.0D), (entity) ->
                        entity.canBeHitByProjectile() && !entity.isSpectator()
                                && (entity != this.getShooter() || this.ticksInAir >= 5)
                                && !this.isAlreadyHit(entity));
    }

    @Nullable
    @Override
    public Entity getShooter() {
        return this.getOwner();
    }

    @Override
    public void setShooter(Entity shooter) {
        setOwner(shooter);
    }

    public List<MobEffectInstance> getPotionEffects() {
        List<MobEffectInstance> effects = PotionUtils.getAllEffects(this.sb$getPersistentData());

        if (effects.isEmpty())
            effects.add(new MobEffectInstance(MobEffects.POISON, 1, 1));

        return effects;
    }

    public void burst() {
        this.playSound(SoundEvents.GLASS_BREAK, 1.0F, 1.2F / (this.random.nextFloat() * 0.2F + 0.9F));

        if (!this.level().isClientSide()) {
            if (this.level() instanceof ServerLevel)
                ((ServerLevel) this.level()).sendParticles(ParticleTypes.CRIT, this.getX(), this.getY(), this.getZ(),
                        16, 0.5, 0.5, 0.5, 0.25f);

            this.burst(getPotionEffects(), null);
        }

        super.remove(RemovalReason.DISCARDED);
    }

    public void burst(List<MobEffectInstance> effects, @Nullable Entity focusEntity) {
        // AABB axisalignedbb = this.getBoundingBox().inflate(4.0D, 2.0D, 4.0D);
        List<Entity> list = TargetSelector.getTargettableEntitiesWithinAABB(this.level(), 2, this);
        // this.world.getEntitiesWithinAABB(LivingEntity.class, axisalignedbb);

        list.stream().filter(e -> e instanceof LivingEntity).map(e -> (LivingEntity) e).forEach(e -> {
            double distanceSq = TargetSelector.distanceSqrBetweenEntity(this, e);
            if (distanceSq < 9.0D) {
                double factor = 1.0D - Math.sqrt(distanceSq) / 4.0D;
                if (e == focusEntity) {
                    factor = 1.0D;
                }

                affectEntity(e, effects, factor);
            }
        });
    }

    public void affectEntity(LivingEntity focusEntity, List<MobEffectInstance> effects, double factor) {
        for (MobEffectInstance effectinstance : effects) {
            var holder = effectinstance.getEffect();
            MobEffect effect = holder.value();
            if (effect.isInstantenous()) {
                Entity shooter = this.getShooter();
                if (shooter != null && this.level() instanceof ServerLevel serverLevel) {
                    effect.applyInstantenousEffect(serverLevel, this, shooter, focusEntity, effectinstance.getAmplifier(),
                            factor);
                }
            } else {
                int duration = (int) (factor * (double) effectinstance.getDuration() + 0.5D);
                if (duration > 0) {
                    focusEntity.addEffect(new MobEffectInstance(holder, duration, effectinstance.getAmplifier(),
                            effectinstance.isAmbient(), effectinstance.isVisible()));
                }
            }
        }
    }

    public void resetAlreadyHits() {
        if (this.alreadyHits != null)
            alreadyHits.clear();
    }

    public void setHitEntity(Entity hitEntity) {
        if (hitEntity != this) {
            this.entityData.set(HIT_ENTITY_ID, hitEntity.getId());

            this.entityData.set(OFFSET_YAW, this.random.nextFloat() * 360);

            this.setDelay(20 * 5);
        }
    }

    @Nullable
    public Entity getHitEntity() {
        if (hitEntity == null) {
            int id = this.entityData.get(HIT_ENTITY_ID);
            if (0 <= id) {
                hitEntity = this.level().getEntity(id);
            }
        }
        return hitEntity;
    }

    public float getOffsetYaw() {
        return this.entityData.get(OFFSET_YAW);
    }

    public float getRoll() {
        return this.entityData.get(ROLL);
    }

    public void setRoll(float value) {
        this.entityData.set(ROLL, value);
    }

    public void setDamage(double damageIn) {
        this.damage = damageIn;
    }

    @Override
    public double getDamage() {
        return this.damage;
    }

    private static final String defaultModelName = "slashblade:model/util/ss";

    public void setModelName(String name) {
        this.entityData.set(MODEL, Optional.ofNullable(name).orElse(defaultModelName));
    }

    public String getModelName() {
        String name = this.entityData.get(MODEL);
        if (name.isEmpty()) {
            name = defaultModelName;
        }
        return name;
    }

    private static final Identifier defaultModel = Identifier.parse(defaultModelName + ".obj");
    private static final Identifier defaultTexture = Identifier.parse(defaultModelName + ".png");

    public Identifier getModelLoc() {
        String name = getModelName();
        if (name.isEmpty())
            return defaultModel;
        return Identifier.parse(name + ".obj");
    }

    public Identifier getTextureLoc() {
        String name = getModelName();
        if (name.isEmpty())
            return defaultTexture;
        return Identifier.parse(name + ".png");
    }

    @Override
    public void push(Entity entityIn) {
        // Suppress velocity change due to collision
        // super.applyEntityCollision(entityIn);
    }

    // todo: 射撃攻撃との相殺 pierce値＝HPにした近接攻撃との相殺
}
