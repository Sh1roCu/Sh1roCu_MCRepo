package cn.sh1rocu.slashblade.util;

import cn.sh1rocu.slashblade.api.event.InputEvent;
import net.minecraft.class_1268;
import net.minecraft.class_304;

public class ClientHooks {
    public static InputEvent.InteractionKeyMappingTriggered onClickInput(int button, class_304 keyBinding, class_1268 hand) {
        InputEvent.InteractionKeyMappingTriggered event = new InputEvent.InteractionKeyMappingTriggered(button, keyBinding, hand);
        InputEvent.CLICK_INPUT_CALLBACK.invoker().onClickInput(event);
        return event;
    }
}
