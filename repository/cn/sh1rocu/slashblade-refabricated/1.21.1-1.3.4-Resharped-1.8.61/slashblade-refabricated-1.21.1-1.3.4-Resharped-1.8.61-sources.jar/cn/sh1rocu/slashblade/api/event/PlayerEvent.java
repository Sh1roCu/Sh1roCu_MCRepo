package cn.sh1rocu.slashblade.api.event;

import net.minecraft.class_1657;

public class PlayerEvent extends LivingEvent {
    private final class_1657 player;

    public PlayerEvent(class_1657 player) {
        super(player);
        this.player = player;
    }

    @Override
    public class_1657 getEntity() {
        return player;
    }
}