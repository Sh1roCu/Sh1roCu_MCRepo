package cn.sh1rocu.slashblade.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1266;
import net.minecraft.class_1308;
import net.minecraft.class_1315;
import net.minecraft.class_2487;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

public abstract class MobSpawnEvent extends BaseEvent {
    private final class_1308 mob;
    private final class_5425 level;
    public static final Event<FinalizeSpawnCallback> FINALIZE_SPAWN = EventFactory.createArrayBacked(FinalizeSpawnCallback.class, callbacks -> event -> {
        for (FinalizeSpawnCallback callback : callbacks) {
            callback.onFinalizeSpawn(event);
        }
    });

    public interface FinalizeSpawnCallback {
        void onFinalizeSpawn(FinalizeSpawn event);
    }

    protected MobSpawnEvent(class_1308 mob, class_5425 level) {
        this.mob = mob;
        this.level = level;
    }

    public class_1308 getEntity() {
        return this.mob;
    }

    public class_5425 getLevel() {
        return this.level;
    }

    public static class FinalizeSpawn extends MobSpawnEvent implements ICancellableEvent {
        private final class_3730 spawnType;
        private class_1266 difficulty;
        @Nullable
        private class_1315 spawnData;
        @Nullable
        private class_2487 spawnTag;

        @ApiStatus.Internal
        public FinalizeSpawn(class_1308 entity, class_5425 level, class_1266 difficulty, class_3730 spawnType, @Nullable class_1315 spawnData) {
            super(entity, level);
            this.difficulty = difficulty;
            this.spawnType = spawnType;
            this.spawnData = spawnData;
        }

        public class_1266 getDifficulty() {
            return this.difficulty;
        }

        public void setDifficulty(class_1266 inst) {
            this.difficulty = inst;
        }

        public class_3730 getSpawnType() {
            return this.spawnType;
        }

        @Nullable
        public class_1315 getSpawnData() {
            return this.spawnData;
        }

        public void setSpawnData(@Nullable class_1315 data) {
            this.spawnData = data;
        }

        @Nullable
        public class_2487 getSpawnTag() {
            return this.spawnTag;
        }

        public void setSpawnTag(@Nullable class_2487 tag) {
            this.spawnTag = tag;
        }
    }
}