package cn.sh1rocu.slashblade.mixin.accessor;

import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3222.class)
public interface ServerPlayerAccessor {
    @Accessor("isChangingDimension")
    void sb$setChangingDimension(boolean isChangingDimension);
}