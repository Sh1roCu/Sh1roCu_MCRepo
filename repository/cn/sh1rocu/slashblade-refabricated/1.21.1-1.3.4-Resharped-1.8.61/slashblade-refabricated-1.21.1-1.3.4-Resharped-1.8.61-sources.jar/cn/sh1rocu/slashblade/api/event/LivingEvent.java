package cn.sh1rocu.slashblade.api.event;

import net.minecraft.class_1309;

public class LivingEvent extends BaseEvent {
    private final class_1309 livingEntity;

    public LivingEvent(class_1309 livingEntity) {
        this.livingEntity = livingEntity;
    }

    public class_1309 getEntity() {
        return livingEntity;
    }
}
