package cn.sh1rocu.slashblade.mixin.client;

import mods.flammpfeil.slashblade.client.renderer.model.BladeMotionManager;
import net.minecraft.class_1059;
import net.minecraft.class_7766;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1059.class)
public abstract class TextureAtlasMixin {
    @Inject(method = "upload", at = @At("RETURN"))
    private void sb$postStitch(class_7766.class_7767 preparations, CallbackInfo ci) {
        class_1059 atlas = (class_1059) (Object) this;
        // BladeModelManager.getInstance().reload(atlas);
        BladeMotionManager.getInstance().reload(atlas);
    }
}