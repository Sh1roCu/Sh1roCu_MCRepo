package cn.sh1rocu.slashblade.mixin.accessor;

import net.minecraft.class_454;
import net.minecraft.class_457;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_457.class)
public interface AdvancementsScreenAccessor {
    @Accessor("selectedTab")
    class_454 sb$getSelectedTab();
}