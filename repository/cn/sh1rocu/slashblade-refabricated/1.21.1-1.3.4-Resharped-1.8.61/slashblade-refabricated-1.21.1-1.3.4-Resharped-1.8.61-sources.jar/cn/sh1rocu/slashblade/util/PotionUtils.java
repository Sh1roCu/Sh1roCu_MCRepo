package cn.sh1rocu.slashblade.util;

import com.google.common.collect.Lists;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1842;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class PotionUtils {
    public static List<class_1293> getAllEffects(@Nullable class_2487 compoundTag) {
        List<class_1293> list = Lists.newArrayList();
        var potion = getPotion(compoundTag);
        if (potion != null) {
            list.addAll(potion.method_8049());
        }
        getCustomEffects(compoundTag, list);
        return list;
    }

    public static void getCustomEffects(@Nullable class_2487 compoundTag, List<class_1293> list) {
        if (compoundTag != null && compoundTag.method_10573("CustomPotionEffects", 9)) {
            class_2499 listTag = compoundTag.method_10554("CustomPotionEffects", 10);

            for (int i = 0; i < listTag.size(); ++i) {
                class_2487 compoundTag2 = listTag.method_10602(i);
                class_1293 mobEffectInstance = class_1293.method_5583(compoundTag2);
                if (mobEffectInstance != null) {
                    list.add(mobEffectInstance);
                }
            }
        }

    }

    public static @Nullable class_1842 getPotion(@Nullable class_2487 compoundTag) {
        return compoundTag == null ? null : class_7923.field_41179.method_10223(class_2960.method_60654(compoundTag.method_10558("Potion")));
    }
}
