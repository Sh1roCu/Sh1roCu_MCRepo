package cn.sh1rocu.slashblade.mixin.client;

import cn.sh1rocu.slashblade.api.event.LivingEntityRenderEvents;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At("HEAD"), cancellable = true)
    public void sb$onPreRender(class_1309 entity, float entityYaw, float partialTicks, class_4587 matrixStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
        if (LivingEntityRenderEvents.PRE.invoker().beforeRender(entity, (class_922<?, ?>) (Object) this, partialTicks, matrixStack, buffer, packedLight))
            ci.cancel();
    }

    @Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At("TAIL"))
    public void sb$onPostRender(class_1309 entity, float entityYaw, float partialTicks, class_4587 matrixStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
        LivingEntityRenderEvents.POST.invoker().afterRender(entity, (class_922<?, ?>) (Object) this, partialTicks, matrixStack, buffer, packedLight);
    }
}