package cn.sh1rocu.slashblade.api.event;

import mods.flammpfeil.slashblade.SlashBlade;
import net.minecraft.class_2960;

public class BaseEvent {
    protected boolean isCanceled = false;

    public static final class_2960 HIGHEST = SlashBlade.prefix("event_highest_priority");
    public static final class_2960 HIGH = SlashBlade.prefix("event_high_priority");
    public static final class_2960 LOW = SlashBlade.prefix("event_low_priority");
    public static final class_2960 LOWEST = SlashBlade.prefix("event_lowest_priority");
}
