package cn.sh1rocu.slashblade.util;

import cn.sh1rocu.slashblade.api.event.AnvilRepairEvent;
import cn.sh1rocu.slashblade.api.event.AnvilUpdateEvent;
import cn.sh1rocu.slashblade.mixin.accessor.AnvilMenuAccessor;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1706;
import net.minecraft.class_1799;
import net.minecraft.class_3532;

public class CommonHooks {
    public static boolean onAnvilChange(class_1706 container, class_1799 left, class_1799 right, class_1263 outputSlot, String name, int baseCost, class_1657 player) {
        AnvilUpdateEvent e = new AnvilUpdateEvent(left, right, name, baseCost, player);
        AnvilUpdateEvent.CALLBACK.invoker().onAnvilUpdate(e);
        if (e.isCanceled()) {
            outputSlot.method_5447(0, class_1799.field_8037);
            ((AnvilMenuAccessor) container).sb$getCost().method_17404((int) class_3532.method_53062(0, 0L, Integer.MAX_VALUE));
            ((AnvilMenuAccessor) container).sb$setRepairItemCountCost(0);
            return false;
        }
        if (e.getOutput().method_7960())
            return true;

        outputSlot.method_5447(0, e.getOutput());
        ((AnvilMenuAccessor) container).sb$getCost().method_17404((int) class_3532.method_53062(e.getCost(), 0L, Integer.MAX_VALUE));
        ((AnvilMenuAccessor) container).sb$setRepairItemCountCost(e.getMaterialCost());
        return false;
    }

    public static float onAnvilRepair(class_1657 player, class_1799 output, class_1799 left, class_1799 right) {
        AnvilRepairEvent e = new AnvilRepairEvent(player, left, right, output);
        AnvilRepairEvent.CALLBACK.invoker().onAnvilRepair(e);
        return e.getBreakChance();
    }
}
