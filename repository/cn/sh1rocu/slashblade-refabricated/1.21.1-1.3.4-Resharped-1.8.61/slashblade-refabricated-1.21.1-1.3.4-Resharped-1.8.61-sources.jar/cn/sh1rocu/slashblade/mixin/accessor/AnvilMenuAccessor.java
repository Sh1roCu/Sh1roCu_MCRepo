package cn.sh1rocu.slashblade.mixin.accessor;

import net.minecraft.class_1706;
import net.minecraft.class_3915;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1706.class)
public interface AnvilMenuAccessor {
    @Accessor("cost")
    class_3915 sb$getCost();

    @Accessor("repairItemCountCost")
    void sb$setRepairItemCountCost(int repairItemCountCost);
}
