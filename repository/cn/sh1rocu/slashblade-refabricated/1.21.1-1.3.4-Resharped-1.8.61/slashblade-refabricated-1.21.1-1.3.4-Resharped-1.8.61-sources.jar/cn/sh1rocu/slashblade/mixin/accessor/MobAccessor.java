package cn.sh1rocu.slashblade.mixin.accessor;

import net.minecraft.class_1308;
import net.minecraft.class_1355;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1308.class)
public interface MobAccessor {
    // 开发环境被其他mod使用AW改为public，服务端不一定会安装上述mod，因此使用Accessor来访问
    @Accessor("goalSelector")
    class_1355 sb$getGoalSelector();
}
