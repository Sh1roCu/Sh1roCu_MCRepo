package cn.sh1rocu.slashblade.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_161;
import net.minecraft.class_454;
import net.minecraft.class_456;

@Mixin(class_454.class)
public interface AdvancementTabAccessor {
    @Accessor("scrollX")
    double sb$getScrollX();

    @Accessor("scrollY")
    double sb$getScrollY();

    @Accessor("widgets")
    Map<class_161, class_456> sb$getWidgets();
}
