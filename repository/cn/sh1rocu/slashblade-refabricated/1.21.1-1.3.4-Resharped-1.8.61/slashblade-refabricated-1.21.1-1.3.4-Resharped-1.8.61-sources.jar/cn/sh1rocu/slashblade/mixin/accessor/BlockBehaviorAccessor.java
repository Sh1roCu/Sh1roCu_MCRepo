package cn.sh1rocu.slashblade.mixin.accessor;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4970.class)
public interface BlockBehaviorAccessor {
    @Invoker("getCollisionShape")
    class_265 sb$getCollisionShape(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_3726 collisionContext);

    @Invoker("getVisualShape")
    class_265 sb$getVisualShape(class_2680 blockState, class_1922 blockGetter, class_2338 blockPos, class_3726 collisionContext);
}