package cn.sh1rocu.slashblade.api.extension;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_3532;
import net.minecraft.class_756;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;

public interface ItemSlashBladeExtension {
    default boolean sb$onLeftClickEntity(class_1799 stack, class_1657 player, class_1297 entity) {
        return false;
    }

    default void sb$setDamage(class_1799 stack, int damage) {
        stack.method_57379(class_9334.field_49629, class_3532.method_15340(damage, 0, stack.method_7936()));
    }

    default <T extends class_1309> int sb$damageItem(class_1799 stack, int amount, @Nullable T entity, Consumer<class_1792> onBroken) {
        return amount;
    }

    default int sb$getDamage(class_1799 stack) {
        return class_3532.method_15340(stack.method_57825(class_9334.field_49629, 0), 0, stack.method_7936());
    }

    default int sb$getMaxDamage(class_1799 stack) {
        return stack.method_57825(class_9334.field_50072, 0);
    }

    default boolean sb$onEntitySwing(class_1799 stack, class_1309 entity) {
        return false;
    }

    default boolean sb$onEntityItemUpdate(class_1799 stack, class_1542 entity) {
        return false;
    }

    @Environment(EnvType.CLIENT)
    class_756 getCustomRenderer();

    class_1814 getRarity(class_1799 stack);

    default @NotNull class_9285 sb$getDefaultAttributeModifiers(@NotNull class_1799 stack) {
        return ((class_1792) this).method_7844();
    }
}
