package cn.sh1rocu.slashblade.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_9779;

public class RenderTickEvent extends BaseEvent {
    private final class_9779.class_9781 timer;

    public RenderTickEvent(class_9779.class_9781 timer) {
        this.timer = timer;
    }

    public static final Event<Start> START = EventFactory.createArrayBacked(Start.class, callbacks -> event -> {
        for (Start callback : callbacks) {
            callback.onStart(event);
        }
    });
    public static final Event<End> END = EventFactory.createArrayBacked(End.class, callbacks -> event -> {
        for (End callback : callbacks) {
            callback.onEnd(event);
        }
    });

    public interface Start {
        void onStart(Pre event);
    }

    public interface End {
        void onEnd(Post event);
    }

    public static final class Pre extends RenderTickEvent {
        public Pre(class_9779.class_9781 timer) {
            super(timer);
        }
    }

    public static final class Post extends RenderTickEvent {
        public Post(class_9779.class_9781 timer) {
            super(timer);
        }
    }
}
