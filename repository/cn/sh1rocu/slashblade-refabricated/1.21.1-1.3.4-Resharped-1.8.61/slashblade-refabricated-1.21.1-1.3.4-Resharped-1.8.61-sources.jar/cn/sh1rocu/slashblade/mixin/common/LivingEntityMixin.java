package cn.sh1rocu.slashblade.mixin.common;

import cn.sh1rocu.slashblade.api.event.LivingTickEvent;
import cn.sh1rocu.slashblade.api.extension.EntityExtension;
import cn.sh1rocu.slashblade.api.extension.ItemSlashBladeExtension;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 implements EntityExtension {
    @Shadow
    public abstract class_1799 getItemInHand(class_1268 interactionHand);

    public LivingEntityMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;tick()V"), cancellable = true)
    private void sb$tickEvent(CallbackInfo ci) {
        LivingTickEvent event = new LivingTickEvent((class_1309) (Object) this);
        LivingTickEvent.CALLBACK.invoker().onLivingTick(event);
        if (event.isCanceled())
            ci.cancel();
    }

    @Inject(method = "swing(Lnet/minecraft/world/InteractionHand;Z)V", at = @At("HEAD"), cancellable = true)
    private void sb$swingHand(class_1268 hand, boolean bl, CallbackInfo ci) {
        class_1799 stack = getItemInHand(hand);
        if (!stack.method_7960() && stack.method_7909() instanceof ItemSlashBladeExtension blade) {
            if (blade.sb$onEntitySwing(stack, (class_1309) (Object) this))
                ci.cancel();
        }
    }
}