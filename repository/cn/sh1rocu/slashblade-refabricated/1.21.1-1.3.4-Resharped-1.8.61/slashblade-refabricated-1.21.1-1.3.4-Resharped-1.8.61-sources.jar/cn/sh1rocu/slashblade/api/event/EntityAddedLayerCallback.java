package cn.sh1rocu.slashblade.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_5617;
import net.minecraft.class_8685;
import net.minecraft.class_897;
import java.util.Map;

public interface EntityAddedLayerCallback {

    Event<EntityAddedLayerCallback> EVENT = EventFactory.createArrayBacked(EntityAddedLayerCallback.class, callbacks -> (renderers, skinMap, context) -> {
        for (EntityAddedLayerCallback event : callbacks) {
            event.addLayers(renderers, skinMap, context);
        }
    });

    void addLayers(final Map<class_1299<?>, class_897<?>> renderers, final Map<class_8685.class_7920, class_897<? extends class_1657>> skinMap, final class_5617.class_5618 context);
}