package cn.sh1rocu.slashblade.mixin.accessor;

import net.minecraft.class_897;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_897.class)
public interface EntityRendererAccessor {
    @Accessor("entityRenderDispatcher")
    class_898 sb$getEntityRenderDispatcher();
}
