package cn.sh1rocu.slashblade.util.network;

import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

public interface IEntityExtension {
    default void sb$sendPairingData(class_3222 serverPlayer, Consumer<class_8710> bundleBuilder) {
        if (this instanceof IEntityWithComplexSpawn) {
            bundleBuilder.accept(new AdvancedAddEntityPayload((class_1297) this));
        }
    }
}
