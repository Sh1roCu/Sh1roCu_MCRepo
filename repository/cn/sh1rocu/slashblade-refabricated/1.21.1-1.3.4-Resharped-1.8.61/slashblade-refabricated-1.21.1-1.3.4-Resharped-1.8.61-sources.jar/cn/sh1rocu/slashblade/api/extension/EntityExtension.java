package cn.sh1rocu.slashblade.api.extension;

import java.util.Collection;
import net.minecraft.class_1542;
import net.minecraft.class_2487;

public interface EntityExtension {
    default class_2487 sb$getPersistentData() {
        throw new RuntimeException();
    }

    default void sb$deserializeNBT(class_2487 nbt) {
        throw new RuntimeException();
    }

    default class_2487 sb$serializeNBT() {
        throw new RuntimeException();
    }


    default Collection<class_1542> sb$captureDrops() {
        throw new RuntimeException("this should be overridden via mixin. what?");
    }

    default Collection<class_1542> sb$captureDrops(Collection<class_1542> value) {
        throw new RuntimeException("this should be overridden via mixin. what?");
    }
}