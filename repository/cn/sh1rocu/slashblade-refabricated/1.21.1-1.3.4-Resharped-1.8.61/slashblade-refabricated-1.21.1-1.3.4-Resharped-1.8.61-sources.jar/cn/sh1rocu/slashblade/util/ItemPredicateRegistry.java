package cn.sh1rocu.slashblade.util;

import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.advancement.SlashBladeItemPredicate;
import net.minecraft.class_2378;
import net.minecraft.class_7923;
import net.minecraft.class_9360;

public class ItemPredicateRegistry {
    public static void init() {

    }

    public static class_9360.class_8745<SlashBladeItemPredicate> SLASHBLADE = register("slashblade", SlashBladeItemPredicate.TYPE);

    private static <T extends class_9360> class_9360.class_8745<T> register(String name, class_9360.class_8745<T> type) {
        return class_2378.method_10230(class_7923.field_49912, SlashBlade.prefix(name), type);
    }
}