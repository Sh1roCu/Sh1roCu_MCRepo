package cn.sh1rocu.slashblade.mixin.accessor;

import net.minecraft.class_185;
import net.minecraft.class_456;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_456.class)
public interface AdvancementWidgetAccessor {
    @Accessor("display")
    class_185 sb$getDisplay();
}
