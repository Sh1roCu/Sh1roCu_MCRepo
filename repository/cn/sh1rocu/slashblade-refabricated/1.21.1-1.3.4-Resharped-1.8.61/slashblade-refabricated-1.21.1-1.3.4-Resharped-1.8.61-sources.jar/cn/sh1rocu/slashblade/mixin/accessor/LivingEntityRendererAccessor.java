package cn.sh1rocu.slashblade.mixin.accessor;

import net.minecraft.class_3887;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_922.class)
public interface LivingEntityRendererAccessor {
    @Invoker("addLayer")
    boolean sb$addLayer(class_3887<?, ?> layer);
}
