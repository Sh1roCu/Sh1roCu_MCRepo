package mods.flammpfeil.slashblade.event;

import cn.sh1rocu.slashblade.api.event.BaseEvent;
import cn.sh1rocu.slashblade.api.event.ICancellableEvent;
import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.entity.BladeStandEntity;
import mods.flammpfeil.slashblade.entity.EntityAbstractSummonedSword;
import mods.flammpfeil.slashblade.slasharts.SlashArts;
import mods.flammpfeil.slashblade.util.KnockBacks;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2960;

public abstract class SlashBladeEvent extends BaseEvent {
    private final class_1799 blade;
    private final ISlashBladeState state;

    public static final Event<Break> BREAK = EventFactory.createArrayBacked(Break.class, callbacks -> event -> {
        for (Break callback : callbacks) {
            callback.onBreak(event);
        }
    });
    public static final Event<PowerBlade> POWER_BLADE = EventFactory.createArrayBacked(PowerBlade.class, callbacks -> event -> {
        for (PowerBlade callback : callbacks) {
            callback.onPower(event);
        }
    });
    public static final Event<AddProudSoul> ADD_PROUD_SOUL = EventFactory.createArrayBacked(AddProudSoul.class, callbacks -> event -> {
        for (AddProudSoul callback : callbacks) {
            callback.onAddProudSoul(event);
        }
    });
    public static final Event<AddKillCount> ADD_KILL_COUNT = EventFactory.createArrayBacked(AddKillCount.class, callbacks -> event -> {
        for (AddKillCount callback : callbacks) {
            callback.onAddAddKillCount(event);
        }
    });
    public static final Event<UpdateAttack> UPDATE_ATTACK = EventFactory.createArrayBacked(UpdateAttack.class, callbacks -> event -> {
        for (UpdateAttack callback : callbacks) {
            callback.onUpdateAttack(event);
        }
    });
    public static final Event<BladeStandAttack> BLADE_STAND_ATTACK = EventFactory.createWithPhases(BladeStandAttack.class, callbacks -> event -> {
        for (BladeStandAttack callback : callbacks) {
            callback.onBladeStandAttack(event);
        }
    }, HIGHEST, HIGH, Event.DEFAULT_PHASE, LOW, LOWEST);
    public static final Event<BladeStandTick> BLADE_STAND_TICK = EventFactory.createArrayBacked(BladeStandTick.class, callbacks -> event -> {
        for (BladeStandTick callback : callbacks) {
            callback.onBladeStandTick(event);
        }
    });
    public static final Event<Hit> HIT = EventFactory.createArrayBacked(Hit.class, callbacks -> event -> {
        for (Hit callback : callbacks) {
            callback.onHit(event);
        }
    });
    public static final Event<Update> UPDATE = EventFactory.createArrayBacked(Update.class, callbacks -> event -> {
        for (Update callback : callbacks) {
            callback.onUpdate(event);
        }
    });
    public static final Event<DoSlash> DO_SLASH = EventFactory.createArrayBacked(DoSlash.class, callbacks -> event -> {
        for (DoSlash callback : callbacks) {
            callback.onDoSlash(event);
        }
    });
    public static final Event<ChargeAction> CHARGE_ACTION = EventFactory.createArrayBacked(ChargeAction.class, callbacks -> event -> {
        for (ChargeAction callback : callbacks) {
            callback.onChargeAction(event);
        }
    });
    public static final Event<SummonedSwordOnHitEntity> SUMMONEDSWORD_ONHIT_ENTITY = EventFactory.createArrayBacked(SummonedSwordOnHitEntity.class, callbacks -> event -> {
        for (SummonedSwordOnHitEntity callback : callbacks) {
            callback.onSummonedSwordOnHitEntity(event);
        }
    });

    public SlashBladeEvent(class_1799 blade, ISlashBladeState state) {
        this.blade = blade;
        this.state = state;
    }

    public class_1799 getBlade() {
        return blade;
    }

    public ISlashBladeState getSlashBladeState() {
        return state;
    }

    public static class BreakEvent extends SlashBladeEvent implements ICancellableEvent {
        public BreakEvent(class_1799 blade, ISlashBladeState state) {
            super(blade, state);
        }
    }

    public static class PowerBladeEvent extends SlashBladeEvent {
        private final class_1309 user;
        private boolean isPowered;

        public PowerBladeEvent(class_1799 blade, ISlashBladeState state, class_1309 user, boolean isPowered) {
            super(blade, state);
            this.user = user;
            this.setPowered(isPowered);
        }

        public boolean isPowered() {
            return isPowered;
        }

        public void setPowered(boolean isPowered) {
            this.isPowered = isPowered;
        }

        public class_1309 getUser() {
            return user;
        }
    }

    public static class AddProudSoulEvent extends SlashBladeEvent {
        private final int originCount;
        private int newCount;

        public AddProudSoulEvent(class_1799 blade, ISlashBladeState state, int count) {
            super(blade, state);
            this.originCount = count;
            this.setNewCount(count);
        }

        public int getOriginCount() {
            return originCount;
        }

        public int getNewCount() {
            return newCount;
        }

        public void setNewCount(int newCount) {
            this.newCount = newCount;
        }
    }

    public static class AddKillCountEvent extends SlashBladeEvent {
        private final int originCount;
        private int newCount;

        public AddKillCountEvent(class_1799 blade, ISlashBladeState state, int count) {
            super(blade, state);
            this.originCount = count;
            this.setNewCount(count);
        }

        public int getOriginCount() {
            return originCount;
        }

        public int getNewCount() {
            return newCount;
        }

        public void setNewCount(int newCount) {
            this.newCount = newCount;
        }

    }

    public static class UpdateAttackEvent extends SlashBladeEvent {
        private final double originDamage;
        private double newDamage;

        public UpdateAttackEvent(class_1799 blade, ISlashBladeState state, double damage) {
            super(blade, state);
            this.originDamage = damage;
            this.newDamage = damage;
        }

        public double getNewDamage() {
            return newDamage;
        }

        public void setNewDamage(double newDamage) {
            this.newDamage = newDamage;
        }

        public double getOriginDamage() {
            return originDamage;
        }
    }

    public static class BladeStandAttackEvent extends SlashBladeEvent implements ICancellableEvent {
        private final BladeStandEntity bladeStand;
        private final class_1282 damageSource;

        public BladeStandAttackEvent(class_1799 blade, ISlashBladeState state, BladeStandEntity bladeStand, class_1282 damageSource) {
            super(blade, state);
            this.bladeStand = bladeStand;
            this.damageSource = damageSource;
        }

        public BladeStandEntity getBladeStand() {
            return bladeStand;
        }

        public class_1282 getDamageSource() {
            return damageSource;
        }

    }

    public static class BladeStandTickEvent extends SlashBladeEvent {
        private final BladeStandEntity bladeStand;

        public BladeStandTickEvent(class_1799 blade, ISlashBladeState state, BladeStandEntity bladeStand) {
            super(blade, state);
            this.bladeStand = bladeStand;
        }

        public BladeStandEntity getBladeStand() {
            return bladeStand;
        }

    }

    public static class HitEvent extends SlashBladeEvent implements ICancellableEvent {
        private final class_1309 target;
        private final class_1309 user;

        public HitEvent(class_1799 blade, ISlashBladeState state, class_1309 target, class_1309 user) {
            super(blade, state);
            this.target = target;
            this.user = user;
        }

        public class_1309 getUser() {
            return user;
        }

        public class_1309 getTarget() {
            return target;
        }

    }

    public static class UpdateEvent extends SlashBladeEvent implements ICancellableEvent {
        private final class_1937 level;
        private final class_1297 entity;
        private final int itemSlot;
        private final boolean isSelected;

        public UpdateEvent(class_1799 blade, ISlashBladeState state,
                           class_1937 worldIn, class_1297 entityIn, int itemSlot, boolean isSelected) {
            super(blade, state);
            this.level = worldIn;
            this.entity = entityIn;
            this.itemSlot = itemSlot;
            this.isSelected = isSelected;
        }

        public class_1937 getLevel() {
            return level;
        }

        public class_1297 getEntity() {
            return entity;
        }

        public int getItemSlot() {
            return itemSlot;
        }

        public boolean isSelected() {
            return isSelected;
        }

    }

    public static class DoSlashEvent extends SlashBladeEvent implements ICancellableEvent {
        private final class_1309 user;
        private float roll;
        private boolean critical;
        private double damage;
        private KnockBacks knockback;
        private float yRot = 0F;

        public DoSlashEvent(class_1799 blade, ISlashBladeState state, class_1309 user,
                            float roll, boolean critical, double damage, KnockBacks knockback) {
            super(blade, state);
            this.user = user;
            this.roll = roll;
            this.critical = critical;
            this.knockback = knockback;
            this.damage = damage;
        }

        public class_1309 getUser() {
            return user;
        }

        public float getRoll() {
            return roll;
        }

        public void setRoll(float roll) {
            this.roll = roll;
        }

        public boolean isCritical() {
            return critical;
        }

        public void setCritical(boolean critical) {
            this.critical = critical;
        }

        public double getDamage() {
            return damage;
        }

        public void setDamage(double damage) {
            this.damage = damage;
        }

        public KnockBacks getKnockback() {
            return knockback;
        }

        public void setKnockback(KnockBacks knockback) {
            this.knockback = knockback == null ? KnockBacks.cancel : knockback;
        }

        public float getYRot() {
            return yRot;
        }

        public void setYRot(float yRot) {
            this.yRot = yRot;
        }

    }


    public static class ChargeActionEvent extends BaseEvent implements ICancellableEvent {
        private final class_1309 entityLiving;
        private final int elapsed;
        private final ISlashBladeState state;
        private class_2960 comboState;
        private final SlashArts.ArtsType type;

        public ChargeActionEvent(class_1309 entityLiving, int elapsed, ISlashBladeState state, class_2960 comboState, SlashArts.ArtsType type) {
            this.entityLiving = entityLiving;
            this.elapsed = elapsed;
            this.state = state;
            this.comboState = comboState;
            this.type = type;
        }

        public class_1309 getEntityLiving() {
            return entityLiving;
        }

        public int getElapsed() {
            return elapsed;
        }

        public ISlashBladeState getSlashBladeState() {
            return state;
        }

        public class_2960 getComboState() {
            return comboState;
        }

        public void setComboState(class_2960 comboState) {
            this.comboState = comboState;
        }

        public SlashArts.ArtsType getType() {
            return type;
        }
    }

    public static class SummonedSwordOnHitEntityEvent extends BaseEvent {
        private final EntityAbstractSummonedSword summonedSword;
        private final class_1297 target;

        public SummonedSwordOnHitEntityEvent(EntityAbstractSummonedSword summonedSword, class_1297 target) {
            this.summonedSword = summonedSword;
            this.target = target;
        }

        public EntityAbstractSummonedSword getSummonedSword() {
            return summonedSword;
        }

        public class_1297 getTarget() {
            return target;
        }
    }

    public interface Break {
        void onBreak(BreakEvent event);
    }

    public interface AddProudSoul {
        void onAddProudSoul(AddProudSoulEvent event);
    }

    public interface AddKillCount {
        void onAddAddKillCount(AddKillCountEvent event);
    }

    public interface PowerBlade {
        void onPower(PowerBladeEvent event);
    }

    public interface UpdateAttack {
        void onUpdateAttack(UpdateAttackEvent event);
    }

    public interface BladeStandAttack {
        void onBladeStandAttack(BladeStandAttackEvent event);
    }

    public interface BladeStandTick {
        void onBladeStandTick(BladeStandTickEvent event);
    }

    public interface Hit {
        void onHit(HitEvent event);
    }

    public interface Update {
        void onUpdate(UpdateEvent event);
    }

    public interface DoSlash {
        void onDoSlash(DoSlashEvent event);
    }

    public interface ChargeAction {
        void onChargeAction(ChargeActionEvent event);
    }

    public interface SummonedSwordOnHitEntity {
        void onSummonedSwordOnHitEntity(SummonedSwordOnHitEntityEvent event);
    }
}
