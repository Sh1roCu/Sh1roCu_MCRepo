package mods.flammpfeil.slashblade.init;

import mods.flammpfeil.slashblade.SlashBlade;
import net.minecraft.class_2960;

public interface DefaultResources {
    class_2960 BaseMotionLocation = SlashBlade.prefix("combostate/old_motion.vmd");
    class_2960 ExMotionLocation = SlashBlade.prefix("combostate/motion.vmd");

    class_2960 testLocation = SlashBlade.prefix("combostate/piercing.vmd");

    class_2960 testPLLocation = SlashBlade.prefix("combostate/piercing_pl.vmd");

    class_2960 resourceDefaultModel = class_2960.method_60655("slashblade", "model/blade.obj");
    class_2960 resourceDefaultTexture = class_2960.method_60655("slashblade", "model/blade.png");

    class_2960 resourceDurabilityModel = class_2960.method_60655("slashblade",
            "model/util/durability.obj");
    class_2960 resourceDurabilityTexture = class_2960.method_60655("slashblade",
            "model/util/durability.png");
}
