package mods.flammpfeil.slashblade.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class SlashBladeKeyMappings {
    public static final class_304 KEY_SPECIAL_MOVE = new class_304("key.slashblade.special_move",
            /*KeyConflictContext.IN_GAME, KeyModifier.NONE, */class_3675.class_307.field_1668, GLFW.GLFW_KEY_V,
            "key.category.slashblade");

    public static final class_304 KEY_SUMMON_BLADE = new class_304("key.slashblade.summon_blade",
            /*KeyConflictContext.IN_GAME, KeyModifier.NONE,*/ class_3675.class_307.field_1672, GLFW.GLFW_MOUSE_BUTTON_MIDDLE,
            "key.category.slashblade");
}
