package mods.flammpfeil.slashblade.item;

import mods.flammpfeil.slashblade.entity.BladeStandEntity;
import mods.flammpfeil.slashblade.init.SBEntityTypes;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1530;
import net.minecraft.class_1657;
import net.minecraft.class_1790;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class BladeStandItem extends class_1790 {
    private final boolean isWallType;

    public BladeStandItem(class_1793 builder) {
        this(builder, false);
    }

    public BladeStandItem(class_1793 builder, boolean isWallType) {
        super(SBEntityTypes.BLADE_STAND, builder);

        this.isWallType = isWallType;
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_2338 blockpos = context.method_8037();
        class_2350 direction = context.method_8038();
        class_2338 blockpos1 = blockpos.method_10093(direction);
        class_1657 playerentity = context.method_8036();
        class_1799 itemstack = context.method_8041();
        if (playerentity != null && !this.method_7834(playerentity, direction, itemstack, blockpos1)) {
            return class_1269.field_5814;
        } else {
            class_1937 world = context.method_8045();
            class_1530 hangingentity = BladeStandEntity.createInstanceFromPos(world, blockpos1, direction, this);

            class_9279 customData = itemstack.method_57824(class_9334.field_49628);
            if (customData != null) {
                class_1299.method_5881(world, playerentity, hangingentity, customData);
            }

            if (hangingentity.method_6888()) {
                if (!world.field_9236) {
                    hangingentity.method_6894();
                    world.method_8649(hangingentity);
                }

                itemstack.method_7934(1);
                return class_1269.method_29236(world.field_9236);
            } else {
                return class_1269.field_21466;
            }
        }
    }

    protected boolean method_7834(class_1657 player, class_2350 dir, class_1799 stack, class_2338 pos) {
        if (isWallType)
            return !dir.method_10166().method_10178() && !player.method_37908().method_31606(pos)
                    && player.method_7343(pos, dir, stack);
        else
            return (dir == class_2350.field_11036) && !player.method_37908().method_31606(pos)
                    && player.method_7343(pos, dir, stack);
    }
}
