package mods.flammpfeil.slashblade.registry;

import mods.flammpfeil.slashblade.SlashBlade;
import net.minecraft.class_1320;
import net.minecraft.class_1329;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public class ModAttributes {
    public static final class_1320 SLASHBLADE_DAMAGE = register("slashblade_damage",
            new class_1329("attribute.name.generic.slashblade_damage", 1.0d, 0.0d, 512.0d).method_26829(true));


    public static class_1320 getSlashBladeDamage() {
        return SLASHBLADE_DAMAGE;
    }

    private static class_1320 register(String name, class_1320 attribute) {
        return class_2378.method_10230(class_7923.field_41190, SlashBlade.prefix(name), attribute);
    }

    public static void init() {

    }
}
