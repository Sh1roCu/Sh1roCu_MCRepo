package mods.flammpfeil.slashblade.data.tag;

import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.init.SBItems;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3489;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

public class SlashBladeItemTags extends FabricTagProvider.ItemTagProvider {
    public static final class_6862<class_1792> PROUD_SOULS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("slashblade", "proudsouls"));
    public static final class_6862<class_1792> BAMBOO = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("c", "bamboo"));

    public static final class_6862<class_1792> CAN_COPY_SA = class_6862.method_40092(class_7924.field_41197, SlashBlade.prefix("can_copy_sa"));
    public static final class_6862<class_1792> CAN_COPY_SE = class_6862.method_40092(class_7924.field_41197, SlashBlade.prefix("can_copy_se"));
    public static final class_6862<class_1792> CAN_CHANGE_SA = class_6862.method_40092(class_7924.field_41197, SlashBlade.prefix("can_change_sa"));
    public static final class_6862<class_1792> CAN_CHANGE_SE = class_6862.method_40092(class_7924.field_41197, SlashBlade.prefix("can_change_se"));

    public SlashBladeItemTags(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
    }


    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        this.getOrCreateTagBuilder(class_3489.field_42611).add(
                SBItems.SLASHBLADE,
                SBItems.SLASHBLADE_BAMBOO,
                SBItems.SLASHBLADE_SILVERBAMBOO,
                SBItems.SLASHBLADE_WHITE,
                SBItems.SLASHBLADE_WOOD);
    }
}
