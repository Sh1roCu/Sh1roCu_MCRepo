package mods.flammpfeil.slashblade.util;

import mods.flammpfeil.slashblade.SlashBlade;
import net.minecraft.class_1309;
import net.minecraft.class_167;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_8779;

public class AdvancementHelper {

    public static final class_2960 ADVANCEMENT_COMBO_A = SlashBlade.prefix("arts/combo_a");
    public static final class_2960 ADVANCEMENT_COMBO_A_EX = SlashBlade.prefix("arts/combo_a_ex");
    public static final class_2960 ADVANCEMENT_COMBO_B = SlashBlade.prefix("arts/combo_b");
    public static final class_2960 ADVANCEMENT_COMBO_B_MAX = SlashBlade.prefix("arts/combo_b_max");
    public static final class_2960 ADVANCEMENT_COMBO_C = SlashBlade.prefix("arts/combo_c");
    public static final class_2960 ADVANCEMENT_AERIAL_A = SlashBlade.prefix("arts/aerial_a");
    public static final class_2960 ADVANCEMENT_AERIAL_B = SlashBlade.prefix("arts/aerial_b");
    public static final class_2960 ADVANCEMENT_UPPERSLASH = SlashBlade.prefix("arts/upperslash");
    public static final class_2960 ADVANCEMENT_UPPERSLASH_JUMP = SlashBlade.prefix("arts/upperslash_jump");
    public static final class_2960 ADVANCEMENT_AERIAL_CLEAVE = SlashBlade.prefix("arts/aerial_cleave");
    public static final class_2960 ADVANCEMENT_RISING_STAR = SlashBlade.prefix("arts/rising_star");
    public static final class_2960 ADVANCEMENT_RAPID_SLASH = SlashBlade.prefix("arts/rapid_slash");
    public static final class_2960 ADVANCEMENT_JUDGEMENT_CUT = SlashBlade.prefix("arts/judgement_cut");
    public static final class_2960 ADVANCEMENT_JUDGEMENT_CUT_JUST = SlashBlade.prefix("arts/judgement_cut_just");
    public static final class_2960 ADVANCEMENT_QUICK_CHARGE = SlashBlade.prefix("arts/quick_charge");

    public static void grantCriterion(class_1309 entity, class_2960 resourcelocation) {
        if (entity instanceof class_3222)
            grantCriterion((class_3222) entity, resourcelocation);
    }

    public static void grantCriterion(class_3222 player, class_2960 resourcelocation) {
        class_8779 adv = player.method_5682().method_3851().method_12896(resourcelocation);
        if (adv == null)
            return;

        class_167 advancementprogress = player.method_14236().method_12882(adv);
        if (advancementprogress.method_740())
            return;

        for (String s : advancementprogress.method_731()) {
            player.method_14236().method_12878(adv, s);
        }
    }

    static final class_2960 EXEFFECT_ENCHANTMENT = SlashBlade.prefix("enchantment/");

    public static void grantedIf(class_5321<class_1887> enchantment, class_1309 owner) {
        class_6880.class_6883<class_1887> holder = owner.method_56673().method_46762(class_7924.field_41265).method_46747(enchantment);
        int level = class_1890.method_8225(holder, owner.method_6047());
        if (0 < level) {
            grantCriterion(owner, EXEFFECT_ENCHANTMENT.method_48331("root"));
            grantCriterion(owner,
                    EXEFFECT_ENCHANTMENT.method_48331(enchantment.method_29177().method_12832()));
        }
    }
}
