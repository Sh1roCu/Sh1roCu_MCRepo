package mods.flammpfeil.slashblade.recipe;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_161;
import net.minecraft.class_170;
import net.minecraft.class_175;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_2119;
import net.minecraft.class_2960;
import net.minecraft.class_7800;
import net.minecraft.class_8782;
import net.minecraft.class_8790;

public class SlashBladeSmithingRecipeBuilder {
    private final class_1856 template;
    private final class_1856 base;
    private final class_1856 addition;
    private final class_7800 category;
    private final class_2960 result;
    private final Map<String, class_175<?>> criteria = new LinkedHashMap<>();

    public SlashBladeSmithingRecipeBuilder(class_1865<?> serializer, class_1856 template, class_1856 base,
                                           class_1856 addition, class_7800 category, class_2960 result) {
        this.category = category;
        this.template = template;
        this.base = base;
        this.addition = addition;
        this.result = result;
    }

    public static SlashBladeSmithingRecipeBuilder smithing(class_1856 template, class_1856 base,
                                                           class_1856 addition, class_7800 category, class_2960 result) {
        return new SlashBladeSmithingRecipeBuilder(SlashBladeSmithingRecipe.SERIALIZER, template, base, addition,
                category, result);
    }

    public SlashBladeSmithingRecipeBuilder unlocks(String name, class_175<?> trigger) {
        this.criteria.put(name, trigger);
        return this;
    }

    public void save(class_8790 consumer, String name) {
        this.save(consumer, class_2960.method_60654(name));
    }

    public void save(class_8790 consumer, class_2960 id) {
        this.ensureValid(id);
        class_161.class_162 builder = consumer.method_53818();
        builder.method_705("has_the_recipe", class_2119.method_27847(id))
                .method_703(class_170.class_171.method_753(id)).method_704(class_8782.class_8797.field_1257);
        this.criteria.forEach(builder::method_705);
        consumer.method_53819(
                id,
                new SlashBladeSmithingRecipe(this.result, this.template, this.base, this.addition),
                builder.method_695(id.method_45138("recipes/" + this.category.method_46203() + "/")));
    }

    private void ensureValid(class_2960 id) {
        if (this.criteria.isEmpty()) {
            throw new IllegalStateException("No way of obtaining recipe " + id);
        }
    }
}