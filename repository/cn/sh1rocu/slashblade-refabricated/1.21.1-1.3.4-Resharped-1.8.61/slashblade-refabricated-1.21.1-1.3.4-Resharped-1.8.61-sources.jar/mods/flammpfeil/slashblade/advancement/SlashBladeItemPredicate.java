package mods.flammpfeil.slashblade.advancement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.init.SBItems;
import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import mods.flammpfeil.slashblade.recipe.RequestDefinition;
import net.minecraft.class_1799;
import net.minecraft.class_7923;
import net.minecraft.class_9360;
import org.jetbrains.annotations.NotNull;

public class SlashBladeItemPredicate implements class_9360 {
    public static final Codec<SlashBladeItemPredicate> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            RequestDefinition.CODEC.fieldOf("requestBlade").forGetter(SlashBladeItemPredicate::getRequest)
    ).apply(instance, SlashBladeItemPredicate::new));
    public static final class_9360.class_8745<SlashBladeItemPredicate> TYPE = new class_9360.class_8745<>(field_49805);

    private final RequestDefinition request;

    public SlashBladeItemPredicate(RequestDefinition request) {
        this.request = request;
    }

    @Override
    public boolean method_58161(@NotNull class_1799 stack) {
        var name = this.getRequest().getName();
        boolean requestCheck = this.getRequest().test(stack);
        if (name.equals(SlashBlade.prefix("none")))
            return requestCheck && stack.method_31574(SBItems.SLASHBLADE);
        if (class_7923.field_41178.method_10250(name)) {
            return requestCheck && stack.method_31574(class_7923.field_41178.method_10223(name));
        }
        return requestCheck && (stack.method_7909() instanceof ItemSlashBlade);
    }

    public RequestDefinition getRequest() {
        return request;
    }
}