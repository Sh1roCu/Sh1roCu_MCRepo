package mods.flammpfeil.slashblade.registry.specialeffects;

import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.registry.SpecialEffectsRegistry;
import net.minecraft.class_156;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public class SpecialEffect {
    public static final class_5321<class_2378<SpecialEffect>> REGISTRY_KEY = class_5321
            .method_29180(SlashBlade.prefix("special_effect"));

    private final int requestLevel;
    private final boolean isCopiable;
    private final boolean isRemovable;

    public SpecialEffect(int requestLevel) {
        this(requestLevel, false, false);
    }

    public SpecialEffect(int requestLevel, boolean isCopiable, boolean isRemovable) {
        this.requestLevel = requestLevel;
        this.isCopiable = isCopiable;
        this.isRemovable = isRemovable;
    }

    public int getRequestLevel() {
        return requestLevel;
    }

    public boolean isCopiable() {
        return isCopiable;
    }

    public boolean isRemovable() {
        return isRemovable;
    }

    public static boolean isEffective(SpecialEffect se, int level) {
        return se.requestLevel <= level;
    }

    public static boolean isEffective(class_2960 id, int level) {
        return SpecialEffectsRegistry.SPECIAL_EFFECT.method_10223(id).getRequestLevel() <= level;
    }

    public static class_2561 getDescription(class_2960 id) {
        return SpecialEffectsRegistry.SPECIAL_EFFECT.method_10223(id).getDescription();
    }

    public static int getRequestLevel(class_2960 id) {
        return SpecialEffectsRegistry.SPECIAL_EFFECT.method_10223(id).getRequestLevel();
    }

    public class_2561 getDescription() {
        return class_2561.method_43471(this.getDescriptionId());
    }

    public String toString() {
        return SpecialEffectsRegistry.SPECIAL_EFFECT.method_10221(this).toString();
    }

    private String descriptionId;

    protected String getOrCreateDescriptionId() {
        if (this.descriptionId == null) {
            this.descriptionId = class_156.method_646("se", SpecialEffectsRegistry.SPECIAL_EFFECT.method_10221(this));
        }
        return this.descriptionId;
    }

    public String getDescriptionId() {
        return this.getOrCreateDescriptionId();
    }
}
