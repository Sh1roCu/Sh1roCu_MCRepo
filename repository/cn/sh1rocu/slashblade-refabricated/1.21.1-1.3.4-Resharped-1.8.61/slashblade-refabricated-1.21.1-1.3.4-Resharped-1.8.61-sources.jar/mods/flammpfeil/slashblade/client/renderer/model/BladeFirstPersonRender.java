package mods.flammpfeil.slashblade.client.renderer.model;

import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.client.renderer.layers.LayerMainBlade;
import mods.flammpfeil.slashblade.client.renderer.util.MSAutoCloser;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3883;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5498;
import net.minecraft.class_746;
import net.minecraft.class_7833;
import net.minecraft.class_897;

/**
 * Created by Furia on 2016/02/07.
 */
public class BladeFirstPersonRender {
    private LayerMainBlade<class_746, ?> layer = null;

    @SuppressWarnings({"unchecked", "rawtypes"})
    private BladeFirstPersonRender() {
        class_310 mc = class_310.method_1551();

        class_897<?> renderer = mc.method_1561().method_3953(mc.field_1724);
        if (renderer instanceof class_3883)
            layer = new LayerMainBlade((class_3883) renderer);
    }

    private static final class SingletonHolder {
        private static final BladeFirstPersonRender instance = new BladeFirstPersonRender();
    }

    public static BladeFirstPersonRender getInstance() {
        return SingletonHolder.instance;
    }

    public void render(class_4587 matrixStack, class_4597 bufferIn, int combinedLightIn) {
        if (layer == null)
            return;

        class_310 mc = class_310.method_1551();
        boolean flag = mc.method_1560() instanceof class_1309
                && ((class_1309) mc.method_1560()).method_6113();
        if (!(mc.field_1690.method_31044() == class_5498.field_26664 && !flag && !mc.field_1690.field_1842
                && !mc.field_1761.method_2928())) {
            return;
        }
        class_746 player = mc.field_1724;
        class_1799 stack = player.method_5998(class_1268.field_5808);
        if (stack.method_7960())
            return;
        if (CapabilitySlashBlade.getBladeState(stack).isEmpty())
            return;

        try (MSAutoCloser msac = MSAutoCloser.pushMatrix(matrixStack)) {
            class_4587.class_4665 me = matrixStack.method_23760();
            me.method_23761().identity();
            me.method_23762().identity();

            float partialTicks = mc.method_60646().method_60637(false);

            matrixStack.method_22907(class_7833.field_40716.rotationDegrees(180.0F - class_3532.method_16439(partialTicks, player.field_5982, player.method_36454())));

            matrixStack.method_46416(0.0f, 0.0f, -0.5f);
            matrixStack.method_22907(class_7833.field_40718.rotationDegrees(180.0f));
            matrixStack.method_22905(1.2F, 1.0F, 1.0F);

            // no sync pitch
            matrixStack.method_22907(class_7833.field_40714.rotationDegrees(-class_3532.method_15363(player.method_36455(), -60F, 10F)));

            // layer.disableOffhandRendering();
            layer.render(matrixStack, bufferIn, combinedLightIn, mc.field_1724, 0, 0, partialTicks, 0, 0, 0);
        }
    }
}