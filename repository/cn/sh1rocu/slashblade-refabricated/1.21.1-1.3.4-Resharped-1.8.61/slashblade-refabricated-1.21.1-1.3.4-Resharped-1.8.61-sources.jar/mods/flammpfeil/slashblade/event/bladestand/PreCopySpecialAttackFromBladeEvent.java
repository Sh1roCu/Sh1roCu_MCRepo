package mods.flammpfeil.slashblade.event.bladestand;

import cn.sh1rocu.slashblade.api.event.ICancellableEvent;
import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.event.SlashBladeEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import javax.annotation.Nullable;

public class PreCopySpecialAttackFromBladeEvent extends SlashBladeEvent implements ICancellableEvent {
    private class_2960 SAKey;
    private int shrinkCount = 0;
    private final BladeStandAttackEvent originalEvent;
    public static final Event<Callback> CALLBACK = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.onPreCopySpecialAttack(event);
        }
    });

    public PreCopySpecialAttackFromBladeEvent(class_1799 blade, ISlashBladeState state, class_2960 SAKey,
                                              BladeStandAttackEvent originalEvent) {
        super(blade, state);
        this.SAKey = SAKey;
        this.originalEvent = originalEvent;
    }

    public class_2960 getSAKey() {
        return SAKey;
    }

    public class_2960 setSAKey(class_2960 SAKey) {
        this.SAKey = SAKey;
        return SAKey;
    }

    public int getShrinkCount() {
        return shrinkCount;
    }

    public int setShrinkCount(int shrinkCount) {
        this.shrinkCount = shrinkCount;
        return this.shrinkCount;
    }

    public @Nullable BladeStandAttackEvent getOriginalEvent() {
        return originalEvent;
    }

    public interface Callback {
        void onPreCopySpecialAttack(PreCopySpecialAttackFromBladeEvent event);
    }
}
