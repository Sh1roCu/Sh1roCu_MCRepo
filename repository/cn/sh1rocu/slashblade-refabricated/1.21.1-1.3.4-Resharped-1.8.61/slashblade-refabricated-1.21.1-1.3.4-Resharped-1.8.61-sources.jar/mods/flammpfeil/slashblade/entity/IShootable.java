package mods.flammpfeil.slashblade.entity;

import net.minecraft.class_1297;

public interface IShootable {

    void shoot(double x, double y, double z, float velocity, float inaccuracy);

    class_1297 getShooter();

    void setShooter(class_1297 shooter);

    double getDamage();
}
