package mods.flammpfeil.slashblade.compat.jei;

import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.ingredients.subtypes.ISubtypeInterpreter;
import mezz.jei.api.ingredients.subtypes.UidContext;
import mezz.jei.api.recipe.category.extensions.vanilla.smithing.IExtendableSmithingRecipeCategory;
import mezz.jei.api.registration.ISubtypeRegistration;
import mezz.jei.api.registration.IVanillaCategoryExtensionRegistration;
import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.init.SBItems;
import mods.flammpfeil.slashblade.recipe.SlashBladeSmithingRecipe;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import org.jetbrains.annotations.NotNull;

// FIXME: 拔刀剑在JEI的物品界面渲染不正常，耐久值会改变；在JEI的配方界面渲染正常
@JeiPlugin
public class JEICompat implements IModPlugin {

    @Override
    public class_2960 getPluginUid() {
        return SlashBlade.prefix(SlashBlade.MODID);
    }

    @Override
    public void registerItemSubtypes(ISubtypeRegistration registration) {
        registration.registerSubtypeInterpreter(SBItems.SLASHBLADE, new ISubtypeInterpreter<>() {
            @Override
            public @NotNull Object getSubtypeData(class_1799 ingredient, UidContext context) {
                return syncSlashBlade(ingredient, context);
            }

            @Override
            public String getLegacyStringSubtypeInfo(class_1799 ingredient, UidContext context) {
                return syncSlashBlade(ingredient, context);
            }
        });
    }

    public static String syncSlashBlade(class_1799 stack, UidContext context) {
        var cap = CapabilitySlashBlade.getBladeState(stack);
        cap.ifPresent(state -> state.setDamage(0));
        return cap.map(ISlashBladeState::getTranslationKey).orElse("");
    }

    @Override
    public void registerVanillaCategoryExtensions(IVanillaCategoryExtensionRegistration registration) {
        IExtendableSmithingRecipeCategory smithingCategory = registration.getSmithingCategory();

        smithingCategory.addExtension(SlashBladeSmithingRecipe.class, new SlashBladeSmithingCategoryExtension());
    }

}
