package mods.flammpfeil.slashblade.registry.specialeffects;

import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.event.SlashBladeEvent;
import mods.flammpfeil.slashblade.registry.SpecialEffectsRegistry;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;

public class WitherEdge extends SpecialEffect {

    public WitherEdge() {
        super(20, true, true);
    }

    public static void onSlashBladeUpdate(SlashBladeEvent.UpdateEvent event) {
        ISlashBladeState state = event.getSlashBladeState();
        if (state.hasSpecialEffect(SpecialEffectsRegistry.SPECIAL_EFFECT.method_10221(SpecialEffectsRegistry.WITHER_EDGE))) {
            if (!(event.getEntity() instanceof class_1657 player)) {
                return;
            }

            if (!event.isSelected())
                return;

            int level = player.field_7520;

            if (!SpecialEffect.isEffective(SpecialEffectsRegistry.SPECIAL_EFFECT.method_10221(SpecialEffectsRegistry.WITHER_EDGE), level))
                player.method_6092(new class_1293(class_1294.field_5920, 100, 1));
        }
    }

    public static void onSlashBladeHit(SlashBladeEvent.HitEvent event) {
        ISlashBladeState state = event.getSlashBladeState();
        if (state.hasSpecialEffect(SpecialEffectsRegistry.SPECIAL_EFFECT.method_10221(SpecialEffectsRegistry.WITHER_EDGE))) {
            if (!(event.getUser() instanceof class_1657 player)) {
                return;
            }

            int level = player.field_7520;

            if (SpecialEffect.isEffective(SpecialEffectsRegistry.SPECIAL_EFFECT.method_10221(SpecialEffectsRegistry.WITHER_EDGE), level))
                event.getTarget().method_6092(new class_1293(class_1294.field_5920, 100, 1));
        }
    }
}
