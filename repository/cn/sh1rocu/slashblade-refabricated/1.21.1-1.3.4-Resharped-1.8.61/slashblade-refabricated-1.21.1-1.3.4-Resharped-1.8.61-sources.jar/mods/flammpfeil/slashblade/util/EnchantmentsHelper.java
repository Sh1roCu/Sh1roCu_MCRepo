package mods.flammpfeil.slashblade.util;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_6880;
import net.minecraft.class_9304;

public class EnchantmentsHelper {
    //判断A是否含有B的附魔
    public static boolean hasEnchantmentsMatch(class_1799 stackA, class_1799 stackB) {
        class_9304 enchantmentsB = class_1890.method_57532(stackB);

        // 如果B没有附魔要求，直接返回true
        if (enchantmentsB.method_57543()) return true;

        class_9304 enchantmentsA = class_1890.method_57532(stackA);

        for (Object2IntMap.Entry<class_6880<class_1887>> entry : enchantmentsB.method_57539()) {
            class_6880<class_1887> ench = entry.getKey();
            int requiredLevel = entry.getIntValue();

            // 检查A是否包含该附魔且等级足够
            if (!enchantmentsA.method_57534().contains(ench) || enchantmentsA.method_57536(ench) < requiredLevel) {
                return false;
            }
        }
        return true;
    }
}
