package mods.flammpfeil.slashblade.event;

import cn.sh1rocu.slashblade.api.event.BaseEvent;
import cn.sh1rocu.slashblade.api.event.ICancellableEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1309;
import net.minecraft.class_2960;

public class BladeMotionEvent extends BaseEvent implements ICancellableEvent {
    private final class_1309 entity;
    private class_2960 combo;
    public static final Event<Callback> CALLBACK = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.onBladeMotion(event);
        }
    });

    public interface Callback {
        void onBladeMotion(BladeMotionEvent event);
    }

    public BladeMotionEvent(class_1309 entity, class_2960 combo) {
        this.entity = entity;
        this.combo = combo;
    }

    public class_1309 getEntity() {
        return entity;
    }

    public class_2960 getCombo() {
        return this.combo;
    }

    public void setCombo(class_2960 combo) {
        this.combo = combo;
    }
}
