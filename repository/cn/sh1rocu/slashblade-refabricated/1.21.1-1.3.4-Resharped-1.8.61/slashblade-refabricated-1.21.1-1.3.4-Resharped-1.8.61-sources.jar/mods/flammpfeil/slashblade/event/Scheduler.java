package mods.flammpfeil.slashblade.event;

import net.minecraft.class_1309;
import net.minecraft.class_233;
import net.minecraft.class_234;
import net.minecraft.class_236;
import net.minecraft.world.level.timers.*;

public class Scheduler {
    public static final class_233<class_1309> SB_CALLBACKS = (new class_233<class_1309>());
    
    private final class_236<class_1309> queue = new class_236<>(SB_CALLBACKS);

    public Scheduler() {
    }

    public void onTick(class_1309 entity) {
        queue.method_988(entity, entity.method_37908().method_8510());
    }

    public void schedule(String key, long time, class_234<class_1309> callback) {
        queue.method_985(key, time, callback);
    }
}
