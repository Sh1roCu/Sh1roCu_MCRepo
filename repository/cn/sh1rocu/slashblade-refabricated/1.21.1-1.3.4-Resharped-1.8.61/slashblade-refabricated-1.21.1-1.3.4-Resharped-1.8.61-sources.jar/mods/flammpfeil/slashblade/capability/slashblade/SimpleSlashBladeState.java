package mods.flammpfeil.slashblade.capability.slashblade;

import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2960;

public class SimpleSlashBladeState extends SlashBladeState {

    private final class_2960 model;
    private final class_2960 texture;
    private final float attack;
    private int damage;


    public SimpleSlashBladeState(class_1799 blade, class_2960 model, class_2960 texture, float attack, int damage) {
        super(blade);
        this.model = model;
        this.attack = attack;
        this.damage = damage;
        this.texture = texture;
    }

    @Override
    public @NotNull Optional<class_2960> getModel() {
        return Optional.ofNullable(model);
    }

    @Deprecated
    @Override
    public void setModel(class_2960 model) {
    }

    @Override
    public float getBaseAttackModifier() {
        return this.attack;
    }

    @Deprecated
    @Override
    public void setBaseAttackModifier(float baseAttackModifier) {
    }

    @Override
    public class_2960 getSlashArtsKey() {
        return super.getSlashArtsKey();
    }

    @Deprecated
    @Override
    public void setSlashArtsKey(class_2960 key) {
    }

    @Override
    public boolean isDefaultBewitched() {
        return false;
    }

    @Override
    public @NotNull String getTranslationKey() {
        return super.getTranslationKey();
    }

    @Deprecated
    @Override
    public void setTranslationKey(String translationKey) {
    }

    @Override
    public @NotNull Optional<class_2960> getTexture() {
        return Optional.ofNullable(texture);
    }

    @Deprecated
    @Override
    public void setTexture(class_2960 texture) {
    }

    @Override
    public int getMaxDamage() {
        return this.damage;
    }

    @Override
    public void setMaxDamage(int damage) {
        super.setMaxDamage(damage);
        this.damage = damage;
    }
}
