package mods.flammpfeil.slashblade.compat.emi;

import dev.emi.emi.api.stack.Comparison;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import net.minecraft.class_1799;
import net.minecraft.class_9279;

public class EMIUtils {

    public static Comparison SLASHBLADE_COMPARISON = Comparison.of((self, other) -> {
        class_1799 aStack = self.getItemStack();
        class_1799 bStack = other.getItemStack();
        if (aStack.method_7909() != bStack.method_7909()) return false;
        String keyA = self.getOrDefault(CapabilitySlashBlade.BLADESTATE_COMPONENT, class_9279.field_49302).method_57461().method_10558("translationKey");
        String keyB = other.getOrDefault(CapabilitySlashBlade.BLADESTATE_COMPONENT, class_9279.field_49302).method_57461().method_10558("translationKey");

        return keyB.equals(keyA);
    });
}