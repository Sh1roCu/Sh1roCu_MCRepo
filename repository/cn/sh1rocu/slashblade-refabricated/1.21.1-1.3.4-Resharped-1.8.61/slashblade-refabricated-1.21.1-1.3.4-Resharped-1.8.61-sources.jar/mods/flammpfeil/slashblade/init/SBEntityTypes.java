package mods.flammpfeil.slashblade.init;

import mods.flammpfeil.slashblade.entity.*;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

import static mods.flammpfeil.slashblade.SlashBlade.RegistryEvents.*;

public class SBEntityTypes {
    public static final class_1299<EntityAbstractSummonedSword> SUMMONED_SWORD = register(SUMMONED_SWORD_LOC, class_1299.class_1300
            .method_5903(EntityAbstractSummonedSword::new, class_1311.field_17715)
            .method_17687(0.5F, 0.5F)
            .method_27299(4)
            .method_27300(20)
            .build());

    public static final class_1299<EntityStormSwords> STORM_SWORDS = register(STORM_SWORDS_LOC, class_1299.class_1300
            .method_5903(EntityStormSwords::new, class_1311.field_17715)
            .method_17687(0.5F, 0.5F)
            .method_27299(4)
            .method_27300(20)
            .build());

    public static final class_1299<EntitySpiralSwords> SPIRAL_SWORDS = register(SPIRAL_SWORDS_LOC, class_1299.class_1300
            .method_5903(EntitySpiralSwords::new, class_1311.field_17715)
            .method_17687(0.5F, 0.5F)
            .method_27299(4)
            .method_27300(20)
            .build());

    public static final class_1299<EntityBlisteringSwords> BLISTERING_SWORDS = register(BLISTERING_SWORDS_LOC, class_1299.class_1300
            .method_5903(EntityBlisteringSwords::new, class_1311.field_17715)
            .method_17687(0.5F, 0.5F)
            .method_27299(4)
            .method_27300(20)
            .build());

    public static final class_1299<EntityHeavyRainSwords> HEAVY_RAIN_SWORDS = register(HEAVY_RAIN_SWORDS_LOC, class_1299.class_1300
            .method_5903(EntityHeavyRainSwords::new, class_1311.field_17715)
            .method_17687(0.5F, 0.5F)
            .method_27299(4)
            .method_27300(20)
            .build());

    public static final class_1299<EntityJudgementCut> JUDGEMENT_CUT = register(JUDGEMENT_CUT_LOC, class_1299.class_1300
            .method_5903(EntityJudgementCut::new, class_1311.field_17715)
            .method_17687(2.5F, 2.5F)
            .method_27299(4)
            .method_27300(20)
            .build());

    public static final class_1299<BladeItemEntity> BLADE_ITEM = register(BLADE_ITEM_ENTITY_LOC, class_1299.class_1300
            .method_5903(BladeItemEntity::new, class_1311.field_17715)
            .method_17687(0.25F, 0.25F)
            .method_27299(4)
            .method_27300(20)
            .build());

    public static final class_1299<BladeStandEntity> BLADE_STAND = register(BLADE_STAND_ENTITY_LOC, class_1299.class_1300
            .method_5903(BladeStandEntity::new, class_1311.field_17715)
            .method_17687(0.5F, 0.5F)
            .method_27299(10)
            .method_27300(20)
            .alwaysUpdateVelocity(false)
            .build());

    public static final class_1299<EntitySlashEffect> SLASH_EFFECT = register(SLASH_EFFECT_LOC, class_1299.class_1300
            .method_5903(EntitySlashEffect::new, class_1311.field_17715)
            .method_17687(3.0F, 3.0F)
            .method_27299(4)
            .method_27300(20).build());

    public static final class_1299<EntityDrive> DRIVE = register(DRIVE_LOC, class_1299.class_1300
            .method_5903(EntityDrive::new, class_1311.field_17715)
            .method_17687(3.0F, 3.0F)
            .method_27299(4)
            .method_27300(20)
            .build());

    private static <T extends class_1299<?>> T register(class_2960 loc, T type) {
        return class_2378.method_10230(class_7923.field_41177, loc, type);
    }

    public static void init() {

    }
}
