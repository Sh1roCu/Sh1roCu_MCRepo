package mods.flammpfeil.slashblade.util;

import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3442;
import net.minecraft.class_3445;
import net.minecraft.class_3468;

public class StatHelper {

    static final long MAX_VALUE = Integer.MAX_VALUE;

    public static int increase(class_3222 player, class_2960 loc, int amount) {
        class_3445<?> stat = class_3468.field_15419.method_14956(loc);
        class_3442 stats = player.method_14248();

        int oldValue = stats.method_15025(stat);
        int newValue = (int) Math.min((long) oldValue + (long) amount, MAX_VALUE);
        if (oldValue == newValue) {
            newValue--;
        }

        stats.method_15023(player, stat, newValue);

        return newValue;
    }
}
