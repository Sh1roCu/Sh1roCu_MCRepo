package mods.flammpfeil.slashblade.recipe;

import cn.sh1rocu.slashblade.SlashBladeFabric;
import com.google.common.collect.Lists;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.capability.slashblade.SlashBladeState;
import mods.flammpfeil.slashblade.item.SwordType;
import mods.flammpfeil.slashblade.registry.slashblade.EnchantmentDefinition;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class RequestDefinition {

    public static final Codec<RequestDefinition> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                    class_2960.field_25139.optionalFieldOf("name", SlashBlade.prefix("none"))
                            .forGetter(RequestDefinition::getName),
                    Codec.INT.optionalFieldOf("proud_soul", 0).forGetter(RequestDefinition::getProudSoulCount),
                    Codec.INT.optionalFieldOf("kill", 0).forGetter(RequestDefinition::getKillCount),
                    Codec.INT.optionalFieldOf("refine", 0).forGetter(RequestDefinition::getRefineCount),
                    EnchantmentDefinition.CODEC.listOf().optionalFieldOf("enchantments", Lists.newArrayList())
                            .forGetter(RequestDefinition::getEnchantments),
                    SwordType.CODEC.listOf().optionalFieldOf("sword_type", Lists.newArrayList())
                            .forGetter(RequestDefinition::getDefaultType))
            .apply(instance, RequestDefinition::new));

    public static final class_9139<class_9129, RequestDefinition> STREAM_CODEC = class_9139.method_58025(
            class_2960.field_48267,
            RequestDefinition::getName,
            class_9135.field_49675,
            RequestDefinition::getProudSoulCount,
            class_9135.field_49675,
            RequestDefinition::getKillCount,
            class_9135.field_49675,
            RequestDefinition::getRefineCount,
            EnchantmentDefinition.STREAM_CODEC.method_56433(class_9135.method_56363()),
            RequestDefinition::getEnchantments,
            SwordType.STREAM_CODEC.method_56433(class_9135.method_56363()),
            RequestDefinition::getDefaultType,
            RequestDefinition::new
    );

    private final class_2960 name;
    private final int proudSoulCount;
    private final int killCount;
    private final int refineCount;
    private final List<EnchantmentDefinition> enchantments;
    private final List<SwordType> defaultType;

    public RequestDefinition(class_2960 name, int proud, int kill, int refine,
                             List<EnchantmentDefinition> enchantments, List<SwordType> defaultType) {
        this.name = name;
        this.proudSoulCount = proud;
        this.killCount = kill;
        this.refineCount = refine;
        this.enchantments = enchantments;
        this.defaultType = defaultType;
    }

    public class_2960 getName() {
        return name;
    }

    public int getProudSoulCount() {
        return proudSoulCount;
    }

    public int getKillCount() {
        return killCount;
    }

    public int getRefineCount() {
        return refineCount;
    }

    public List<EnchantmentDefinition> getEnchantments() {
        return enchantments;
    }

    public List<SwordType> getDefaultType() {
        return defaultType;
    }

    public static RequestDefinition fromJSON(JsonObject json) {
        return CODEC.parse(JsonOps.INSTANCE, json).resultOrPartial(msg -> {
            SlashBlade.LOGGER.error("Failed to parse : {}", msg);
        }).orElseGet(Builder.newInstance()::build);
    }

    public JsonElement toJson() {
        return CODEC.encodeStart(JsonOps.INSTANCE, this).resultOrPartial(msg -> {
            SlashBlade.LOGGER.error("Failed to encode : {}", msg);
        }).orElseThrow();
    }

    public static void toNetwork(class_9129 buffer, RequestDefinition request) {
        buffer.method_10812(request.getName());
        buffer.method_53002(request.getProudSoulCount());
        buffer.method_53002(request.getKillCount());
        buffer.method_53002(request.getRefineCount());
        buffer.method_34062(request.getEnchantments(), (buf, enchantment) -> {
            buf.method_10812(enchantment.getEnchantmentID());
            buf.method_52997(enchantment.getEnchantmentLevel());
        });

        buffer.method_34062(request.getDefaultType(), (buf, swordType) -> {
            buf.method_10814(swordType.name().toLowerCase(Locale.ENGLISH));
        });
    }

    public static RequestDefinition fromNetwork(class_2540 buffer) {
        class_2960 name = buffer.method_10810();
        int proud = buffer.readInt();
        int kill = buffer.readInt();
        int refine = buffer.readInt();
        var enchantments = buffer.method_34066((buf) -> new EnchantmentDefinition(buf.method_10810(), buf.readByte()));
        var types = buffer.method_34066((buf) -> SwordType.valueOf(buf.method_19772().toUpperCase(Locale.ENGLISH)));
        return new RequestDefinition(name, proud, kill, refine, enchantments, types);
    }

    public void initItemStack(class_1799 blade) {
        var state = CapabilitySlashBlade.getBladeState(blade).orElse(new SlashBladeState(blade));
        state.setNonEmpty();
        if (!this.name.equals(SlashBlade.prefix("none")))
            state.setTranslationKey(getTranslationKey());
        state.setProudSoulCount(getProudSoulCount());
        state.setKillCount(getKillCount());
        state.setRefine(getRefineCount());

        var lookup = SlashBladeFabric.REGISTRY_ACCESS.method_46762(class_7924.field_41265);
        this.getEnchantments()
                .forEach(enchantment -> blade.method_7978(lookup.method_46747(
                                class_5321.method_29179(class_7924.field_41265, enchantment.getEnchantmentID())
                        ),
                        enchantment.getEnchantmentLevel()));
        this.defaultType.forEach(type -> {
            switch (type) {
                case BEWITCHED -> state.setDefaultBewitched(true);
                case BROKEN -> {
                    blade.method_7974(blade.method_7936() - 1);
                    state.setBroken(true);
                }
                case SEALED -> state.setSealed(true);
                default -> {
                }
            }
        });
    }


    public boolean test(class_1799 blade) {
        if (blade == null || blade.method_7960())
            return false;
        if (CapabilitySlashBlade.getBladeState(blade).isEmpty())
            return false;
        var state = CapabilitySlashBlade.getBladeState(blade).orElseThrow(NullPointerException::new);
        boolean nameCheck;
        if (this.name.equals(SlashBlade.prefix("none"))) {
            nameCheck = state.getTranslationKey().isBlank();
        } else {
            nameCheck = state.getTranslationKey().equals(getTranslationKey());
        }
        boolean proudCheck = state.getProudSoulCount() >= this.getProudSoulCount();
        boolean killCheck = state.getKillCount() >= this.getKillCount();
        boolean refineCheck = state.getRefine() >= this.getRefineCount();

        var matching = blade.method_58657().method_57539();

        for (var enchantment : this.getEnchantments()) {
            for (var entry : matching) {
                if (entry.getKey().method_40226(enchantment.getEnchantmentID()) && entry.getIntValue() < enchantment.getEnchantmentLevel()) {
                    return false;
                }
            }
        }

        boolean types = SwordType.from(blade).containsAll(this.getDefaultType());

        return nameCheck && proudCheck && killCheck && refineCheck && types;
    }

    public String getTranslationKey() {
        return class_156.method_646("item", this.getName());
    }

    public static class Builder {
        private class_2960 name;
        private int proudCount;
        private int killCount;
        private int refineCount;
        private final List<EnchantmentDefinition> enchantments;
        private final List<SwordType> defaultType;

        private Builder() {
            this.name = SlashBlade.prefix("none");
            this.proudCount = 0;
            this.killCount = 0;
            this.refineCount = 0;
            this.enchantments = new ArrayList<>();
            this.defaultType = new ArrayList<>();
        }

        public static Builder newInstance() {
            return new Builder();
        }

        public Builder name(class_2960 name) {
            this.name = name;
            return this;
        }

        public Builder proudSoul(int proudCount) {
            this.proudCount = proudCount;
            return this;
        }

        public Builder killCount(int killCount) {
            this.killCount = killCount;
            return this;
        }

        public Builder refineCount(int refineCount) {
            this.refineCount = refineCount;
            return this;
        }

        public Builder addEnchantment(EnchantmentDefinition... enchantments) {
            this.enchantments.addAll(Arrays.asList(enchantments));
            return this;
        }

        public Builder addSwordType(SwordType... types) {
            this.defaultType.addAll(Arrays.asList(types));
            return this;
        }

        public RequestDefinition build() {
            return new RequestDefinition(name, proudCount, killCount, refineCount, enchantments, defaultType);
        }
    }
}
