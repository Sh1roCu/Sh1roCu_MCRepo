package mods.flammpfeil.slashblade.data.tag;

import mods.flammpfeil.slashblade.SlashBlade;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1299;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7225.class_7874;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

public class SlashBladeEntityTypeTagProvider extends FabricTagProvider.EntityTypeTagProvider {
    public SlashBladeEntityTypeTagProvider(FabricDataOutput output, CompletableFuture<class_7874> completableFuture) {
        super(output, completableFuture);
    }

    @Override
    protected void method_10514(class_7874 lookupProvider) {
        this.getOrCreateTagBuilder(EntityTypeTags.ATTACKABLE_BLACKLIST)
                .add(class_1299.field_6077)
                .method_35922(class_2960.method_60655("touhou_little_maid", "maid"));

        this.getOrCreateTagBuilder(EntityTypeTags.RENDER_LAYER_BLACKLIST)
                .method_35922(class_2960.method_60655("touhou_little_maid", "maid"));
    }

    public static class EntityTypeTags {
        public static final class_6862<class_1299<?>> ATTACKABLE_BLACKLIST = class_6862.method_40092(class_7924.field_41266,
                SlashBlade.prefix("blacklist/attackable"));
        public static final class_6862<class_1299<?>> RENDER_LAYER_BLACKLIST = class_6862.method_40092(class_7924.field_41266,
                SlashBlade.prefix("blacklist/render_layer"));
    }
}
