package mods.flammpfeil.slashblade.data;

import mods.flammpfeil.slashblade.event.drop.EntityDropEntry;
import mods.flammpfeil.slashblade.registry.slashblade.SlashBladeDefinition;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class RegistryDataGenerator extends FabricDynamicRegistryProvider {
    public RegistryDataGenerator(FabricDataOutput output, CompletableFuture<class_7225.class_7874> provider) {
        super(output, provider);
    }

    @Override
    protected void configure(class_7225.class_7874 provider, Entries entries) {
        entries.addAll(provider.method_46762(SlashBladeDefinition.REGISTRY_KEY));
        entries.addAll(provider.method_46762(EntityDropEntry.REGISTRY_KEY));
    }

    @Override
    public String method_10321() {
        return "SlashBlade: Refabricated Registries";
    }
}