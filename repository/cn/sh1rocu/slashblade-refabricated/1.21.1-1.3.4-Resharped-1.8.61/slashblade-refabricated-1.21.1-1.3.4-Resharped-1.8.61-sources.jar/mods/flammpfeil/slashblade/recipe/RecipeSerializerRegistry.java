package mods.flammpfeil.slashblade.recipe;

import mods.flammpfeil.slashblade.SlashBlade;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_3956;
import net.minecraft.class_7923;

public class RecipeSerializerRegistry {
    public static final class_1865<?> SLASHBLADE_SHAPED = register("shaped_blade", SlashBladeShapedRecipe.SERIALIZER);

    public static final class_1865<?> PROUDSOUL_RECIPE = register("proudsoul", ProudsoulShapelessRecipe.SERIALIZER);

    public static final class_1865<?> SLASHBLADE_SMITHING = register("slashblade_smithing", SlashBladeSmithingRecipe.SERIALIZER);

    private static <S extends class_1865<T>, T extends class_1860<?>> S register(String name, S serializer) {
        return class_2378.method_10230(class_7923.field_41189, SlashBlade.prefix(name), serializer);
    }

    private static <T extends class_1860<?>> class_3956<T> register(String name, class_3956<T> type) {
        return class_2378.method_10230(class_7923.field_41188, SlashBlade.prefix(name), type);
    }

    public static void init() {

    }
}
