package mods.flammpfeil.slashblade.capability.slashblade;

import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9331;
import java.util.Optional;

public class CapabilitySlashBlade {
    public static void init() {

    }

    public static final class_9331<class_9279> BLADESTATE_COMPONENT = class_2378.method_10230(
            class_7923.field_49658, SlashBlade.prefix("blade_state"),
            class_9331.<class_9279>method_57873()
                    .method_57881(class_9279.field_49303)
                    .method_57882(class_9279.field_49305)
                    .method_57880()
    );

    public static Optional<ISlashBladeState> getBladeState(class_1799 stack) {
        if (stack.method_7909() instanceof ItemSlashBlade blade) {
            return Optional.of(blade.initCapability(stack));
        }
        return Optional.empty();
    }
}