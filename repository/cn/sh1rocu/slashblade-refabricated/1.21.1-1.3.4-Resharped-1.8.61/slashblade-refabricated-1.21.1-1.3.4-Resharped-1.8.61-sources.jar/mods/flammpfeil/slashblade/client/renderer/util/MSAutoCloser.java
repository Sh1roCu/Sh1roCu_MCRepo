package mods.flammpfeil.slashblade.client.renderer.util;

import net.minecraft.class_4587;

public class MSAutoCloser implements AutoCloseable {

    public static MSAutoCloser pushMatrix(class_4587 ms) {
        return new MSAutoCloser(ms);
    }

    class_4587 ms;

    MSAutoCloser(class_4587 ms) {
        this.ms = ms;
        this.ms.method_22903();
    }

    @Override
    public void close() {
        this.ms.method_22909();
    }
}
