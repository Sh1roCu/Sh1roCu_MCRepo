package mods.flammpfeil.slashblade.util;

import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import org.joml.Matrix4f;

public class VectorHelper {

    public static class_243 getVectorForRotation(float pitch, float yaw) {
        float f = pitch * ((float) Math.PI / 180F);
        float f1 = -yaw * ((float) Math.PI / 180F);
        float f2 = class_3532.method_15362(f1);
        float f3 = class_3532.method_15374(f1);
        float f4 = class_3532.method_15362(f);
        float f5 = class_3532.method_15374(f);
        return new class_243(f3 * f4, -f5, f2 * f4);
    }

    public static class_2382 f2i(class_243 src) {
        return new class_2382(class_3532.method_15357(src.field_1352), class_3532.method_15357(src.field_1351), class_3532.method_15357(src.field_1350));
    }

    public static class_2382 f2i(double x, double y, double z) {
        return new class_2382(class_3532.method_15357(x), class_3532.method_15357(y), class_3532.method_15357(z));
    }

    public static Matrix4f matrix4fFromArray(float[] in) {
        return new Matrix4f(in[0], in[1], in[2], in[3], in[4], in[5], in[6], in[7], in[8], in[9], in[10], in[11],
                in[12], in[13], in[14], in[15]);
    }
}
