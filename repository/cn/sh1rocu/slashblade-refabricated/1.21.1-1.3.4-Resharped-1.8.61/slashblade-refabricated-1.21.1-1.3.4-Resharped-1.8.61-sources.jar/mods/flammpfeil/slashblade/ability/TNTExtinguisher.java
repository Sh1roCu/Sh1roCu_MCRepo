package mods.flammpfeil.slashblade.ability;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1541;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1928;
import net.minecraft.class_2398;
import net.minecraft.class_3218;

public class TNTExtinguisher {
    public static void doExtinguishing(class_1297 target, class_1309 attacker) {
        if (!(target instanceof class_1541))
            return;

        if (attacker.method_37908().method_8608())
            return;

        target.method_5650(class_1297.class_5529.field_26998);

        class_3218 world = (class_3218) attacker.method_37908();

        world.method_14199(class_2398.field_11251, target.method_23317(), target.method_23318() + target.method_17682() * 0.5,
                target.method_23321(), 5, target.method_17681() * 1.5, target.method_17682(), target.method_17681() * 1.5, 0.02D);

        if (target.method_5864() == class_1299.field_6063) {
            if (world.method_8450().method_8355(class_1928.field_19391)) {
                class_1542 itementity = new class_1542(world, target.method_23317(), target.method_23318() + target.method_17682(),
                        target.method_23321(), new class_1799(class_1802.field_8626));
                itementity.method_6988();

                world.method_8649(itementity);
            }
        }
    }
}
