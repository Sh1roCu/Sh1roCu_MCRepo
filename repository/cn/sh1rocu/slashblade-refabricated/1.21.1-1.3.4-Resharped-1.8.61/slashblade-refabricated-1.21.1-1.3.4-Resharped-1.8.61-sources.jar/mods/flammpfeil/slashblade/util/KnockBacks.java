package mods.flammpfeil.slashblade.util;

import mods.flammpfeil.slashblade.event.handler.KnockBackHandler;
import net.minecraft.class_1309;
import java.util.function.Consumer;

public enum KnockBacks {
    cancel((e) -> KnockBackHandler.setFactor(e, 0, 0, 0)),
    toss((e) -> KnockBackHandler.setVertical(e, 0.75f)),
    meteor((e) -> KnockBackHandler.setVertical(e, -5.5f)),
    smash((e) -> KnockBackHandler.setSmash(e, 1.5f));

    public final Consumer<class_1309> action;

    KnockBacks(Consumer<class_1309> action) {
        this.action = action;
    }
}
