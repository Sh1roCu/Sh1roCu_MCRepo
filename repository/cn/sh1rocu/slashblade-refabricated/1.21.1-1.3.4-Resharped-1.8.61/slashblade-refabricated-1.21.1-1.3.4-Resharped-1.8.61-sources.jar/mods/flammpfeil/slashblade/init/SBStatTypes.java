package mods.flammpfeil.slashblade.init;

import mods.flammpfeil.slashblade.SlashBlade;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3446;
import net.minecraft.class_3468;
import net.minecraft.class_7923;

public class SBStatTypes {
    public static void init() {

    }

    public static class_2960 SWORD_SUMMONED = registerCustomStat("sword_summoned");

    private static class_2960 registerCustomStat(String name) {
        class_2960 resourcelocation = SlashBlade.prefix(name);
        class_2378.method_10226(class_7923.field_41183, name, resourcelocation);
        class_3468.field_15419.method_14955(resourcelocation, class_3446.field_16975);
        return resourcelocation;
    }
}
