package mods.flammpfeil.slashblade.registry.slashblade;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2960;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class EnchantmentDefinition {
    public static final Codec<EnchantmentDefinition> CODEC = RecordCodecBuilder.create(instance -> instance
            .group(class_2960.field_25139.fieldOf("id").forGetter(EnchantmentDefinition::getEnchantmentID),
                    Codec.INT.optionalFieldOf("lvl", 1).forGetter(EnchantmentDefinition::getEnchantmentLevel))
            .apply(instance, EnchantmentDefinition::new));

    public static class_9139<class_9129, EnchantmentDefinition> STREAM_CODEC = class_9139.method_56435(
            class_2960.field_48267,
            EnchantmentDefinition::getEnchantmentID,
            class_9135.field_49675,
            EnchantmentDefinition::getEnchantmentLevel,
            EnchantmentDefinition::new
    );

    private final class_2960 id;
    private final int lvl;

    public EnchantmentDefinition(class_2960 enchantment, int level) {
        this.id = enchantment;
        this.lvl = level;
    }

    public class_2960 getEnchantmentID() {
        return id;
    }

    public int getEnchantmentLevel() {
        return lvl;
    }
}