package mods.flammpfeil.slashblade.compat.jei;

import mezz.jei.api.gui.builder.IIngredientAcceptor;
import mezz.jei.api.recipe.category.extensions.vanilla.smithing.ISmithingCategoryExtension;
import mods.flammpfeil.slashblade.recipe.SlashBladeSmithingRecipe;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_638;
import net.minecraft.class_9697;

public class SlashBladeSmithingCategoryExtension implements ISmithingCategoryExtension<SlashBladeSmithingRecipe> {
    @Override
    public <T extends IIngredientAcceptor<T>> void setTemplate(SlashBladeSmithingRecipe recipe, T ingredientAcceptor) {
        class_1856 ingredient = recipe.template();
        ingredientAcceptor.addIngredients(ingredient);
    }

    @Override
    public <T extends IIngredientAcceptor<T>> void setBase(SlashBladeSmithingRecipe recipe, T ingredientAcceptor) {
        class_1856 ingredient = recipe.base();
        ingredientAcceptor.addIngredients(ingredient);
    }

    @Override
    public <T extends IIngredientAcceptor<T>> void setAddition(SlashBladeSmithingRecipe recipe, T ingredientAcceptor) {
        class_1856 ingredient = recipe.addition();
        ingredientAcceptor.addIngredients(ingredient);
    }

    @Override
    public <T extends IIngredientAcceptor<T>> void setOutput(SlashBladeSmithingRecipe recipe, T ingredientAcceptor) {
        class_1856 templateIngredient = recipe.template();
        class_1856 baseIngredient = recipe.base();
        class_1856 additionIngredient = recipe.addition();

        class_1799[] additions = additionIngredient.method_8105();
        if (additions.length == 0) {
            return;
        }
        class_1799 addition = additions[0];

        for (class_1799 template : templateIngredient.method_8105()) {
            for (class_1799 base : baseIngredient.method_8105()) {
                class_9697 recipeInput = createInput(template, base, addition);
                class_1799 output = assembleResultItem(recipeInput, recipe);
                ingredientAcceptor.addItemStack(output);
            }
        }
    }

    private static class_1799 assembleResultItem(class_9697 input, SlashBladeSmithingRecipe recipe) {
        class_310 minecraft = class_310.method_1551();
        class_638 level = minecraft.field_1687;
        if (level == null) {
            throw new NullPointerException("level must not be null.");
        }
        class_5455 registryAccess = level.method_30349();
        return recipe.assemble(input, registryAccess);
    }

    private static class_9697 createInput(class_1799 template, class_1799 base, class_1799 addition) {
        return new class_9697(template, base, addition);
    }
}