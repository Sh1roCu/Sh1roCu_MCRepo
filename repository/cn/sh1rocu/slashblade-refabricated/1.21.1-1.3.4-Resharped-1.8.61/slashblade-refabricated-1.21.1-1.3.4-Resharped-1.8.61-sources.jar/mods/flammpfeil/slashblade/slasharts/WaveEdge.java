package mods.flammpfeil.slashblade.slasharts;

import mods.flammpfeil.slashblade.capability.concentrationrank.CapabilityConcentrationRank;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.entity.EntityDrive;
import mods.flammpfeil.slashblade.init.SBEntityTypes;
import mods.flammpfeil.slashblade.util.KnockBacks;
import mods.flammpfeil.slashblade.util.VectorHelper;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class WaveEdge {
    public static void doSlash(class_1309 playerIn, float roll, int lifetime, class_243 centerOffset, boolean critical,
                               double damage, float minSpeed, float maxSpeed, int count) {
        doSlash(playerIn, roll, lifetime, centerOffset, critical, damage, KnockBacks.cancel, minSpeed, maxSpeed, count);
    }

    public static void doSlash(class_1309 playerIn, float roll, int lifetime, class_243 centerOffset, boolean critical,
                               double damage, KnockBacks knockback, float minSpeed, float maxSpeed, int count) {

        int colorCode = CapabilitySlashBlade.getBladeState(playerIn.method_6047())
                .map(ISlashBladeState::getColorCode).orElse(0xFF3333FF);

        doSlash(playerIn, roll, lifetime, colorCode, centerOffset, critical, damage, knockback, minSpeed, maxSpeed,
                count);
    }

    public static void doSlash(class_1309 playerIn, float roll, int lifetime, int colorCode, class_243 centerOffset,
                               boolean critical, double damage, KnockBacks knockback, float minSpeed, float maxSpeed, int count) {

        if (playerIn.method_37908().method_8608())
            return;

        class_243 pos = playerIn.method_19538().method_1031(0.0D, (double) playerIn.method_5751() * 0.75D, 0.0D)
                .method_1019(playerIn.method_5720().method_1021(0.3f));

        pos = pos.method_1019(VectorHelper.getVectorForRotation(-90.0F, playerIn.method_5705(0)).method_1021(centerOffset.field_1351))
                .method_1019(VectorHelper.getVectorForRotation(0, playerIn.method_5705(0) + 90).method_1021(centerOffset.field_1350))
                .method_1019(playerIn.method_5720().method_1021(centerOffset.field_1350));
        for (int i = 0; i <= count; i += 1) {
            EntityDrive drive = new EntityDrive(SBEntityTypes.DRIVE, playerIn.method_37908());

            playerIn.method_37908().method_8649(drive);
            float speed = class_3532.method_32750(drive.method_37908().method_8409(), minSpeed, maxSpeed);

            drive.method_5814(pos.field_1352, pos.field_1351, pos.field_1350);
            drive.setDamage(damage);
            drive.setSpeed(speed);
            drive.method_7485(playerIn.method_5720().field_1352, playerIn.method_5720().field_1351, playerIn.method_5720().field_1350,
                    drive.getSpeed(), 0);

            drive.method_7432(playerIn);
            drive.setRotationRoll(roll);
            drive.setColor(colorCode);
            drive.setIsCritical(critical);
            drive.setKnockBack(knockback);
            drive.setLifetime(lifetime);

            if (playerIn != null)
                CapabilityConcentrationRank.RANK_POINT.maybeGet(playerIn)
                        .ifPresent(rank -> drive.setRank(rank.getRankLevel(playerIn.method_37908().method_8510())));

        }
    }
}
