package mods.flammpfeil.slashblade.client.renderer.model;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1309;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;

/**
 * Created by Furia on 2016/02/07.
 */
public class BladeModel implements class_1087 {

    class_1087 original;

    public BladeModel(class_1087 original, class_1088 loader) {
        this.original = original;
    }

    public static class_1309 user = null;

    @Override
    public @NotNull class_806 method_4710() {
        return this.original.method_4710();
    }

    @Override
    public @NotNull List<class_777> method_4707(@org.jetbrains.annotations.Nullable class_2680 p_235039_,
                                             @org.jetbrains.annotations.Nullable class_2350 p_235040_, @NotNull class_5819 p_235041_) {
        return original.method_4707(p_235039_, p_235040_, p_235041_);
    }

    @Override
    public boolean method_4708() {
        return original.method_4708();
    }

    @Override
    public boolean method_4712() {
        return original.method_4712();
    }

    @Override
    public boolean method_24304() {
        return false;
    }

    @Override
    public boolean method_4713() {
        return true;
    }

    @Override
    public @NotNull class_1058 method_4711() {
        return original.method_4711();
        // return
        // Minecraft.getInstance().getItemRenderer().getItemModelMesher().getParticleIcon(SlashBlade.proudSoul);
    }

    @Override
    public @NotNull class_809 method_4709() {
        return class_809.field_4301;
    }

    /*
     * ItemCameraTransforms tf = new
     * ItemCameraTransforms(ItemCameraTransforms.DEFAULT){
     *
     * @Override public ItemTransformVec3f getTransform(TransformType srctype) {
     * type = srctype; return super.getTransform(srctype); } } ;
     *
     * @Override public ItemCameraTransforms getItemCameraTransforms() { return tf;
     * }
     */

    /*
     * @Override public IBakedModel
     * handlePerspective(ItemCameraTransforms.TransformType cameraTransformType,
     * MatrixStack mat) { this.type = cameraTransformType; return
     * net.minecraftforge.client.ForgeHooksClient.handlePerspective(getBakedModel(),
     * cameraTransformType, mat); }
     */
}
