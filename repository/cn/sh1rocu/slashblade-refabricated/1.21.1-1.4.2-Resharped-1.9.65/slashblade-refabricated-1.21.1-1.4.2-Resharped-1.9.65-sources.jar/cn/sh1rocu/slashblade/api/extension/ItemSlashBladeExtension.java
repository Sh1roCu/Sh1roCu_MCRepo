package cn.sh1rocu.slashblade.api.extension;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_756;
import net.minecraft.class_9285;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;

public interface ItemSlashBladeExtension {
    boolean onLeftClickEntity(class_1799 stack, class_1657 player, class_1297 entity);

    <T extends class_1309> int damageItem(class_1799 stack, int amount, @Nullable T entity, Consumer<class_1792> onBroken);

    void setDamage(class_1799 stack, int damage);

    int getDamage(class_1799 stack);

    int getMaxDamage(class_1799 stack);

    boolean onEntitySwing(class_1799 stack, class_1309 entity);

    boolean onEntityItemUpdate(class_1799 stack, class_1542 entity);

    @Environment(EnvType.CLIENT)
    class_756 getCustomRenderer();

    class_1814 getRarity(class_1799 stack);

    @NotNull class_9285 getDefaultAttributeModifiers(@NotNull class_1799 stack);
}
