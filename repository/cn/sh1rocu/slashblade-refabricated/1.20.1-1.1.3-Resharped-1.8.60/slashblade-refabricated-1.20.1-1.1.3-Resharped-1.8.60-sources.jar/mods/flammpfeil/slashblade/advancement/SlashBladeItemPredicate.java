package mods.flammpfeil.slashblade.advancement;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.init.SBItems;
import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import mods.flammpfeil.slashblade.recipe.RequestDefinition;
import net.minecraft.class_1799;
import net.minecraft.class_2073;
import net.minecraft.class_7923;
import org.jetbrains.annotations.NotNull;

public class SlashBladeItemPredicate extends class_2073 {
    private final RequestDefinition request;

    public SlashBladeItemPredicate(JsonObject json) {
        this(json.getAsJsonObject("requestBlade").isJsonNull()
                ? RequestDefinition.Builder.newInstance().build()
                : RequestDefinition.fromJSON(json.getAsJsonObject("requestBlade")));
    }

    @Override
    public @NotNull JsonElement method_8971() {
        JsonObject jsonobject = new JsonObject();
        jsonobject.addProperty("type", SlashBlade.prefix("slashblade").toString());
        jsonobject.add("requestBlade", this.getRequest().toJson());
        return jsonobject;
    }

    public SlashBladeItemPredicate(RequestDefinition request) {
        this.request = request;
    }

    @Override
    public boolean method_8970(@NotNull class_1799 stack) {
        var name = this.getRequest().getName();
        boolean requestCheck = this.getRequest().test(stack);
        if (name.equals(SlashBlade.prefix("none")))
            return requestCheck && stack.method_31574(SBItems.SLASHBLADE);
        if (class_7923.field_41178.method_10250(name)) {
            return requestCheck && stack.method_31574(class_7923.field_41178.method_10223(name));
        }
        return requestCheck && (stack.method_7909() instanceof ItemSlashBlade);
    }

    public RequestDefinition getRequest() {
        return request;
    }
}