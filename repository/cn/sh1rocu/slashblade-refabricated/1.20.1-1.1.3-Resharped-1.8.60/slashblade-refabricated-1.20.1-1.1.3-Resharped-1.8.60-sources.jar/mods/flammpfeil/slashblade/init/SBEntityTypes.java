package mods.flammpfeil.slashblade.init;

import mods.flammpfeil.slashblade.entity.*;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4048;
import net.minecraft.class_7923;

import static mods.flammpfeil.slashblade.SlashBlade.RegistryEvents.*;

public class SBEntityTypes {
    public static final class_1299<EntityAbstractSummonedSword> SUMMONED_SWORD = register(SUMMONED_SWORD_LOC, FabricEntityTypeBuilder
            .create(class_1311.field_17715, EntityAbstractSummonedSword::new)
            .dimensions(class_4048.method_18384(0.5F, 0.5F))
            .trackRangeChunks(4)
            .trackedUpdateRate(20)
            .build());

    public static final class_1299<EntityStormSwords> STORM_SWORDS = register(STORM_SWORDS_LOC, FabricEntityTypeBuilder
            .create(class_1311.field_17715, EntityStormSwords::new)
            .dimensions(class_4048.method_18384(0.5F, 0.5F))
            .trackRangeChunks(4)
            .trackedUpdateRate(20)
            .build());

    public static final class_1299<EntitySpiralSwords> SPIRAL_SWORDS = register(SPIRAL_SWORDS_LOC, FabricEntityTypeBuilder
            .create(class_1311.field_17715, EntitySpiralSwords::new)
            .dimensions(class_4048.method_18384(0.5F, 0.5F))
            .trackRangeChunks(4)
            .trackedUpdateRate(20)
            .build());

    public static final class_1299<EntityBlisteringSwords> BLISTERING_SWORDS = register(BLISTERING_SWORDS_LOC, FabricEntityTypeBuilder
            .create(class_1311.field_17715, EntityBlisteringSwords::new)
            .dimensions(class_4048.method_18384(0.5F, 0.5F))
            .trackRangeChunks(4)
            .trackedUpdateRate(20)
            .build());

    public static final class_1299<EntityHeavyRainSwords> HEAVY_RAIN_SWORDS = register(HEAVY_RAIN_SWORDS_LOC, FabricEntityTypeBuilder
            .create(class_1311.field_17715, EntityHeavyRainSwords::new)
            .dimensions(class_4048.method_18384(0.5F, 0.5F))
            .trackRangeChunks(4)
            .trackedUpdateRate(20)
            .build());

    public static final class_1299<EntityJudgementCut> JUDGEMENT_CUT = register(JUDGEMENT_CUT_LOC, FabricEntityTypeBuilder
            .create(class_1311.field_17715, EntityJudgementCut::new)
            .dimensions(class_4048.method_18384(2.5F, 2.5F))
            .trackRangeChunks(4)
            .trackedUpdateRate(20)
            .build());

    public static final class_1299<BladeItemEntity> BLADE_ITEM = register(BLADE_ITEM_ENTITY_LOC, FabricEntityTypeBuilder
            .create(class_1311.field_17715, BladeItemEntity::new)
            .dimensions(class_4048.method_18384(0.25F, 0.25F))
            .trackRangeChunks(4)
            .trackedUpdateRate(20)
            .build());

    public static final class_1299<BladeStandEntity> BLADE_STAND = register(BLADE_STAND_ENTITY_LOC, FabricEntityTypeBuilder
            .create(class_1311.field_17715, BladeStandEntity::new)
            .dimensions(class_4048.method_18384(0.5F, 0.5F))
            .trackRangeChunks(10)
            .trackedUpdateRate(20)
            .forceTrackedVelocityUpdates(false)
            .build());

    public static final class_1299<EntitySlashEffect> SLASH_EFFECT = register(SLASH_EFFECT_LOC, FabricEntityTypeBuilder
            .create(class_1311.field_17715, EntitySlashEffect::new)
            .dimensions(class_4048.method_18384(3.0F, 3.0F))
            .trackRangeChunks(4)
            .trackedUpdateRate(20).build());

    public static final class_1299<EntityDrive> DRIVE = register(DRIVE_LOC, FabricEntityTypeBuilder
            .create(class_1311.field_17715, EntityDrive::new)
            .dimensions(class_4048.method_18384(3.0F, 3.0F))
            .trackRangeChunks(4)
            .trackedUpdateRate(20)
            .build());

    private static <T extends class_1299<?>> T register(class_2960 loc, T type) {
        return class_2378.method_10230(class_7923.field_41177, loc, type);
    }

    public static void init() {

    }
}
