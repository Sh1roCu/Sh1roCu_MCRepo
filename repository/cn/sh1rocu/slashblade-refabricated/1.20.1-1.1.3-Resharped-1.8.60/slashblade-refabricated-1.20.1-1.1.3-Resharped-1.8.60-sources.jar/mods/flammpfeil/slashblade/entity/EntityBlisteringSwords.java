package mods.flammpfeil.slashblade.entity;

import mods.flammpfeil.slashblade.ability.StunManager;
import mods.flammpfeil.slashblade.capability.inputstate.CapabilityInputState;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.util.InputCommand;
import mods.flammpfeil.slashblade.util.KnockBacks;
import mods.flammpfeil.slashblade.util.RayTraceHelper;
import mods.flammpfeil.slashblade.util.TargetSelector;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import java.util.Optional;
import java.util.stream.Stream;

public class EntityBlisteringSwords extends EntityAbstractSummonedSword {
    private static final class_2940<Boolean> IT_FIRED = class_2945.method_12791(EntityBlisteringSwords.class,
            class_2943.field_13323);

    public EntityBlisteringSwords(class_1299<? extends Projectile> entityTypeIn, class_1937 worldIn) {
        super(entityTypeIn, worldIn);

        this.setPierce((byte) 5);
    }

    @Override
    protected void method_5693() {
        super.method_5693();

        this.field_6011.method_12784(IT_FIRED, false);
    }

    public void doFire() {
        this.method_5841().method_12778(IT_FIRED, true);
    }

    public boolean itFired() {
        return this.method_5841().method_12789(IT_FIRED);
    }

    long fireTime = -1;

    @Override
    public void method_5773() {
        if (!itFired()) {
            if (method_5854() == null && this.method_24921() != null) {
                method_5873(this.method_24921(), true);
            }
        }

        super.method_5773();
    }

    @Override
    public void method_5842() {
        if (itFired() && fireTime <= field_6012) {
            faceEntityStandby();
            class_1297 vehicle = method_5854();
            class_243 dir = this.method_5828(0);
            if (!(vehicle instanceof class_1309 sender)) {
                this.method_7485(dir.field_1352, dir.field_1351, dir.field_1350, 3.0f, 1.0f);
                return;
            }

            this.method_5848();

            this.field_6012 = 0;

            class_1937 worldIn;
            worldIn = sender.method_37908();
            class_1297 lockTarget = null;
            if (sender instanceof class_1309) {
                lockTarget = CapabilitySlashBlade.BLADESTATE.maybeGet(sender.method_6047())
                        .filter(state -> state.getTargetEntity(worldIn) != null)
                        .map(state -> state.getTargetEntity(worldIn)).orElse(null);
            }

            Optional<class_1297> foundTarget;
            foundTarget = Stream
                    .of(Optional.ofNullable(lockTarget),
                            RayTraceHelper
                                    .rayTrace(sender.method_37908(), sender, sender.method_5836(1.0f),
                                            sender.method_5720(), 12, 12, (e) -> true)
                                    .filter(r -> r.method_17783() == class_239.class_240.field_1331).filter(r -> {
                                        class_3966 er = (class_3966) r;
                                        class_1297 target = er.method_17782();

                                        boolean isMatch = true;
                                        if (target instanceof class_1309) {
                                            isMatch = TargetSelector.test.method_18419(sender, (class_1309) target);
                                        }

                                        if (target instanceof IShootable) {
                                            isMatch = ((IShootable) target).getShooter() != sender;
                                        }

                                        return isMatch;
                                    }).map(r -> ((class_3966) r).method_17782()))
                    .filter(Optional::isPresent).map(Optional::get).findFirst();

            class_243 targetPos = foundTarget.map((e) -> new class_243(e.method_23317(), e.method_23318() + e.method_5751() * 0.5, e.method_23321()))
                    .orElseGet(() -> {
                        class_243 start = sender.method_5836(1.0f);
                        class_243 end = start.method_1019(sender.method_5720().method_1021(40));
                        class_239 result;
                        result = worldIn.method_17742(new class_3959(start, end, class_3959.class_3960.field_17558,
                                class_3959.class_242.field_1348, sender));
                        return result.method_17784();
                    });

            class_243 pos = this.method_30950(0.0f);
            dir = targetPos.method_1020(pos).method_1029();

            this.method_7485(dir.field_1352, dir.field_1351, dir.field_1350, 3.0f, 1.0f);
            if (sender instanceof class_3222) {
                ((class_3222) sender).method_17356(class_3417.field_14550, class_3419.field_15248, 1.0F, 1.0F);
            }

            return;
        }

        // this.startRiding()
        this.method_18799(class_243.field_1353);
        // if (canUpdate())
        this.method_5670();

        faceEntityStandby();
        // this.getVehicle().positionRider(this);

        // lifetime check
        if (!itFired() && method_5854() instanceof class_1309 owner) {
            CapabilityInputState.INPUT_STATE.maybeGet(owner).ifPresent(s -> {
                if (!s.getCommands().contains(InputCommand.M_DOWN)) {

                    fireTime = field_6012 + getDelay();
                    doFire();
                }
            });
        }

        /*
         * if(!level().isClientSide()) hitCheck();
         */
    }

    private void faceEntityStandby() {
        int spawnNum = getDelay();

        boolean isRight = spawnNum % 2 == 0;
        int level = spawnNum / 2;

        class_243 pos = new class_243(0, 0, 0);

        if (this.method_5854() == null) {
            doFire();
            return;
        }

        pos = pos.method_1019(this.method_5854().method_19538()).method_1031(0, this.method_5854().method_5751() * 0.8, 0);

        double xOffset = (1 - 0.1 * level) * (isRight ? 1 : -1);
        double yOffset = 0.25 * level;
        double zOffset = -0.1 * level;

        class_243 offset = new class_243(xOffset, yOffset, zOffset);

        offset = offset.method_1037((float) Math.toRadians(-this.method_5854().method_36455()));
        offset = offset.method_1024((float) Math.toRadians(-this.method_5854().method_36454()));

        pos = pos.method_1019(offset);

        this.field_6004 = this.method_36455();
        this.field_5982 = this.method_36454();

        // ■初期位置・初期角度等の設定
        method_33574(pos);

        method_5710(-this.method_5854().method_36454(), -this.method_5854().method_36455());

    }

    @Override
    protected void method_24920(class_3965 blockraytraceresult) {
        burst();
    }

    @Override
    protected void method_7454(class_3966 entityHitResult) {

        class_1297 targetEntity = entityHitResult.method_17782();
        if (targetEntity instanceof class_1309) {
            KnockBacks.cancel.action.accept((class_1309) targetEntity);
            StunManager.setStun((class_1309) targetEntity);
        }

        super.method_7454(entityHitResult);
    }
}
