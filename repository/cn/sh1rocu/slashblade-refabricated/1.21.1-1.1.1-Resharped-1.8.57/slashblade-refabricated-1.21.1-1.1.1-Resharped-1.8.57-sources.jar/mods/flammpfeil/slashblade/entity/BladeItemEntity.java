package mods.flammpfeil.slashblade.entity;

import cn.sh1rocu.slashblade.api.extension.EntityExtension;
import mods.flammpfeil.slashblade.init.DefaultResources;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3532;

public class BladeItemEntity extends class_1542 implements EntityExtension {
    private static final class_2940<String> DATA_MODEL = class_2945.method_12791(BladeItemEntity.class,
            class_2943.field_13326);
    private static final class_2940<String> DATA_TEXTURE = class_2945.method_12791(BladeItemEntity.class,
            class_2943.field_13326);

    public BladeItemEntity(class_1299<? extends BladeItemEntity> p_i50217_1_, class_1937 p_i50217_2_) {
        super(p_i50217_1_, p_i50217_2_);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(DATA_MODEL, DefaultResources.resourceDefaultModel.toString());
        builder.method_56912(DATA_TEXTURE, DefaultResources.resourceDefaultTexture.toString());
    }

    public class_2960 getModel() {
        return class_2960.method_12829(this.method_5841().method_12789(DATA_MODEL));
    }

    public void setModel(class_2960 model) {
        this.method_5841().method_12778(DATA_MODEL, model.toString());
    }

    public class_2960 getTexture() {
        return class_2960.method_12829(this.method_5841().method_12789(DATA_TEXTURE));
    }

    public void setTexture(class_2960 texture) {
        this.method_5841().method_12778(DATA_TEXTURE, texture.toString());
    }

    public void init() {
        this.method_5684(true);

        class_2487 compoundnbt = this.method_5647(new class_2487());
        compoundnbt.method_10551("Dimension");
        compoundnbt.method_10575("Health", (short) 100);
        if (compoundnbt.method_10568("PickupDelay") != (short) 32767) {
            compoundnbt.method_10575("Age", Short.MIN_VALUE);
        }
        this.method_5651(compoundnbt);
    }

    @Override
    public void method_5773() {
        if (method_24828() && field_6012 % 40 == 0) {
            field_6012++;
        }
        super.method_5773();

        if (!this.method_5799() && !method_24828() && field_6012 % 6 == 0) {
            this.method_5783(class_3417.field_14706, 0.5F, 2.5F);
        }

        if (this.method_37908().method_8608()) {
            if (field_5974.method_43048(5) == 0 && method_5669() < 0) {
                class_2350 direction = class_2350.field_11036;
                double d0 = (double) this.method_23317() - (double) (field_5974.method_43057() * 0.1F);
                double d1 = (double) this.method_23318() - (double) (field_5974.method_43057() * 0.1F);
                double d2 = (double) this.method_23321() - (double) (field_5974.method_43057() * 0.1F);
                double d3 = (double) (0.4F - (field_5974.method_43057() + field_5974.method_43057()) * 0.4F);
                this.method_37908().method_8406(class_2398.field_11214, d0 + (double) direction.method_10148() * d3,
                        d1 + 2 + (double) direction.method_10164() * d3, d2 + (double) direction.method_10165() * d3,
                        field_5974.method_43059() * 0.005D, -2, field_5974.method_43059() * 0.005D);
            }

            if (!this.method_24828() && !this.method_5799() && field_5974.method_43048(3) == 0) {
                class_2350 direction = class_2350.field_11036;
                double d0 = (double) this.method_23317() - (double) (field_5974.method_43057() * 0.1F);
                double d1 = (double) this.method_23318() - (double) (field_5974.method_43057() * 0.1F);
                double d2 = (double) this.method_23321() - (double) (field_5974.method_43057() * 0.1F);
                double d3 = (double) (0.4F - (field_5974.method_43057() + field_5974.method_43057()) * 0.4F);
                this.method_37908().method_8406(class_2398.field_11207, d0 + (double) direction.method_10148() * d3,
                        d1 + (double) direction.method_10164() * d3, d2 + (double) direction.method_10165() * d3,
                        field_5974.method_43059() * 0.005D, field_5974.method_43059() * 0.005D, field_5974.method_43059() * 0.005D);
            }
        }
    }

    @Override
    public boolean method_5809() {
        return super.method_5809();
    }

    @Override
    public boolean method_5747(float distance, float damageMultiplier, class_1282 ds) {
        super.method_5747(distance, damageMultiplier, ds);

        int i = class_3532.method_15386(distance);
        if (i > 0) {
            this.method_5783(class_3417.field_14928, 1.0F, 1.0F);
            this.method_5643(this.method_37908().method_48963().method_48827(), (float) i);
            int j = class_3532.method_15357(this.method_23317());
            int k = class_3532.method_15357(this.method_23318() - (double) 0.2F);
            int l = class_3532.method_15357(this.method_23321());
            class_2680 blockstate = this.method_37908().method_8320(new class_2338(j, k, l));
            if (!blockstate.method_26215()) {
                class_2498 soundtype = blockstate.method_26231(/*level(), new BlockPos(j, k, l), this*/);
                this.method_5783(soundtype.method_10593(), soundtype.method_10597() * 0.5F, soundtype.method_10599() * 0.75F);
            }

            if (this.method_5851() && method_5669() < 0) {
                this.method_5834(false);
            }
        }

        return false;
    }

    @SuppressWarnings("deprecation")
    @Override
    public float method_5718() {
        if (method_5669() < 0)
            return 15728880;
        return super.method_5718();
    }
}
