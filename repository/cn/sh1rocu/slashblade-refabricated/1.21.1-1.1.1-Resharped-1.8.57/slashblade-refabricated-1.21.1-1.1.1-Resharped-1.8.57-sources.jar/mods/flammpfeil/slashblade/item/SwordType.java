package mods.flammpfeil.slashblade.item;

import com.mojang.serialization.Codec;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import net.minecraft.class_1799;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9334;
import java.util.EnumSet;

public enum SwordType {
    NONE, EDGEFRAGMENT, BROKEN, ENCHANTED, BEWITCHED, FIERCEREDGE, NOSCABBARD, SEALED, UNBREAKABLE, SOULEATER;

    public static final Codec<SwordType> CODEC = Codec.STRING.xmap(string -> SwordType.valueOf(string.toUpperCase()),
            instance -> instance.name().toLowerCase());

    public static final class_9139<class_9129, SwordType> STREAM_CODEC =
            class_9139.method_56437((buf, type) -> class_9135.field_48554.encode(buf, type.name().toLowerCase()),
                    buf -> SwordType.valueOf(class_9135.field_48554.decode(buf).toUpperCase()));

    public static EnumSet<SwordType> from(class_1799 itemStackIn) {
        EnumSet<SwordType> types = EnumSet.noneOf(SwordType.class);

        CapabilitySlashBlade.getBladeState(itemStackIn).ifPresentOrElse(s -> {
            if (s.isBroken())
                types.add(BROKEN);

            if (s.isSealed())
                types.add(SEALED);

            if (!s.isSealed() && itemStackIn.method_7942()
                    && (itemStackIn.method_57826(class_9334.field_49631) || s.isDefaultBewitched()))
                types.add(BEWITCHED);

            if (s.getKillCount() >= 1000)
                types.add(FIERCEREDGE);

            if (s.getProudSoulCount() >= 10000)
                types.add(SOULEATER);

        }, () -> {
            types.add(NOSCABBARD);
            types.add(EDGEFRAGMENT);
        });

        if (itemStackIn.method_7942())
            types.add(ENCHANTED);

        if (itemStackIn.method_7909() instanceof ItemSlashBladeDetune) {
            types.remove(SwordType.ENCHANTED);
            types.remove(SwordType.BEWITCHED);
        }

        if (itemStackIn.method_57826(class_9334.field_49630))
            types.remove(SwordType.BROKEN);

        return types;
    }
}
