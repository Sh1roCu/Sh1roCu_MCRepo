package mods.flammpfeil.slashblade.client;

import cn.sh1rocu.slashblade.mixin.accessor.LivingEntityRendererAccessor;
import mods.flammpfeil.slashblade.client.renderer.LockonCircleRender;
import mods.flammpfeil.slashblade.client.renderer.gui.RankRenderer;
import mods.flammpfeil.slashblade.client.renderer.layers.LayerMainBlade;
import mods.flammpfeil.slashblade.client.renderer.model.BladeModel;
import mods.flammpfeil.slashblade.compat.playerAnim.PlayerAnimationOverrider;
import mods.flammpfeil.slashblade.event.client.AdvancementsRecipeRenderer;
import mods.flammpfeil.slashblade.event.client.SneakingMotionCanceller;
import mods.flammpfeil.slashblade.event.client.UserPoseOverrider;
import mods.flammpfeil.slashblade.init.SBItems;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_5617;
import net.minecraft.class_7923;
import net.minecraft.class_8685;
import net.minecraft.class_897;
import net.minecraft.class_922;
import org.apache.logging.log4j.util.LoaderUtil;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Environment(EnvType.CLIENT)
public class ClientHandler {
    public static void doClientStuff() {
        SneakingMotionCanceller.getInstance().register();

        if (LoaderUtil.isClassAvailable("dev.kosmx.playerAnim.api.layered.AnimationStack")) {
            PlayerAnimationOverrider.getInstance().register();
        } else {
            UserPoseOverrider.getInstance().register();
        }
        LockonCircleRender.getInstance().register();
        AdvancementsRecipeRenderer.getInstance().register();


        RankRenderer.getInstance().register();

        class_5272.method_27879(SBItems.slashblade, class_2960.method_60654("slashblade:user"),
                (itemStack, level, livingEntity, i) -> {
                    BladeModel.user = livingEntity;
                    return 0;
                });

        class_5272.method_27879(SBItems.slashblade_bamboo, class_2960.method_60654("slashblade:user"),
                (itemStack, level, livingEntity, i) -> {
                    BladeModel.user = livingEntity;
                    return 0;
                });

        class_5272.method_27879(SBItems.slashblade_silverbamboo, class_2960.method_60654("slashblade:user"),
                (itemStack, level, livingEntity, i) -> {
                    BladeModel.user = livingEntity;
                    return 0;
                });

        class_5272.method_27879(SBItems.slashblade_white, class_2960.method_60654("slashblade:user"),
                (itemStack, level, livingEntity, i) -> {
                    BladeModel.user = livingEntity;
                    return 0;
                });

        class_5272.method_27879(SBItems.slashblade_wood, class_2960.method_60654("slashblade:user"),
                (itemStack, level, livingEntity, i) -> {
                    BladeModel.user = livingEntity;
                    return 0;
                });


        registerKeyMapping();
    }

    public static void registerKeyMapping() {
        KeyBindingHelper.registerKeyBinding(SlashBladeKeyMappings.KEY_SPECIAL_MOVE);
        KeyBindingHelper.registerKeyBinding(SlashBladeKeyMappings.KEY_SUMMON_BLADE);
    }

    private static final Set<class_1792> blades = new HashSet<>() {{
        add(SBItems.slashblade);
        add(SBItems.slashblade_white);
        add(SBItems.slashblade_wood);
        add(SBItems.slashblade_silverbamboo);
        add(SBItems.slashblade_bamboo);
    }};

    public static class_1087 Baked(class_1087 bakedModel, ModelModifier.AfterBake.Context context) {
        for (class_1792 blade : blades) {
            class_1091 modelLoc = class_1091.method_61078(class_7923.field_41178.method_10221(blade));
            class_1091 id = context.topLevelId();
            if (id != null && id.equals(modelLoc)) {
                return bakeBlade(bakedModel, context.loader());
            }
        }
        return bakedModel;
    }

    public static class_1087 bakeBlade(class_1087 bakedModel, class_1088 bakery) {
        return new BladeModel(bakedModel, bakery);
    }

    public static void addLayers(Map<class_1299<?>, class_897<?>> renderers, Map<class_8685.class_7920, class_897<? extends class_1657>> skinMap, class_5617.class_5618 context) {
        addPlayerLayer(skinMap, class_8685.class_7920.field_41123);
        addPlayerLayer(skinMap, class_8685.class_7920.field_41122);

        for (class_1299<?> type : class_7923.field_41177) {
            addEntityLayer(renderers, type);
        }

//        addEntityLayer(renderers, EntityType.ZOMBIE);
//        addEntityLayer(renderers, EntityType.HUSK);
//        addEntityLayer(renderers, EntityType.ZOMBIE_VILLAGER);
//
//        addEntityLayer(renderers, EntityType.WITHER_SKELETON);
//        addEntityLayer(renderers, EntityType.SKELETON);
//        addEntityLayer(renderers, EntityType.STRAY);
//
//        addEntityLayer(renderers, EntityType.PIGLIN);
//        addEntityLayer(renderers, EntityType.PIGLIN_BRUTE);
//        addEntityLayer(renderers, EntityType.ZOMBIFIED_PIGLIN);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void addPlayerLayer(Map<class_8685.class_7920, class_897<? extends class_1657>> skinMap, class_8685.class_7920 skin) {
        class_897<? extends class_1657> renderer = skinMap.get(skin);

        if (renderer instanceof class_922 livingRenderer) {
            ((LivingEntityRendererAccessor) livingRenderer).sb$addLayer(new LayerMainBlade<>(livingRenderer));
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void addEntityLayer(Map<class_1299<?>, class_897<?>> renderers, class_1299 type) {
        class_897<?> renderer = renderers.get(type);

        if (renderer instanceof class_922 livingRenderer) {
            ((LivingEntityRendererAccessor) livingRenderer).sb$addLayer(new LayerMainBlade<>(livingRenderer));
        }
    }
}
