package mods.flammpfeil.slashblade.slasharts;

import mods.flammpfeil.slashblade.capability.concentrationrank.CapabilityConcentrationRank;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.entity.EntityJudgementCut;
import mods.flammpfeil.slashblade.init.SBEntityTypes;
import mods.flammpfeil.slashblade.util.RayTraceHelper;
import mods.flammpfeil.slashblade.util.TargetSelector;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3966;
import java.util.List;
import java.util.Optional;

public class JudgementCut {
    public static EntityJudgementCut doJudgementCutJust(class_1309 user) {
        EntityJudgementCut sa = doJudgementCut(user);
        sa.setIsCritical(true);
        return sa;
    }

    public static EntityJudgementCut doJudgementCut(class_1309 user) {

        class_1937 worldIn = user.method_37908();

        class_243 eyePos = user.method_5836(1.0f);
        final double airReach = 5;
        final double entityReach = 7;

        class_1799 stack = user.method_6047();
        Optional<class_243> resultPos = CapabilitySlashBlade.getBladeState(stack)
                .filter(s -> s.getTargetEntity(worldIn) != null).map(s -> s.getTargetEntity(worldIn).method_5836(1.0f));

        if (resultPos.isEmpty()) {
            Optional<class_239> raytraceresult = RayTraceHelper.rayTrace(worldIn, user, eyePos, user.method_5720(),
                    airReach, entityReach, (entity) -> {
                        return !entity.method_7325() && entity.method_5805() && entity.method_5863() && (entity != user);
                    });

            resultPos = raytraceresult.map((rtr) -> {
                class_243 pos = null;
                class_239.class_240 type = rtr.method_17783();
                switch (type) {
                    case field_1331:
                        class_1297 target = ((class_3966) rtr).method_17782();
                        pos = target.method_19538().method_1031(0, target.method_5751() / 2.0f, 0);
                        break;
                    case field_1332:
                        class_243 hitVec = rtr.method_17784();
                        pos = hitVec;
                        break;
                    default:
                        break;
                }
                return pos;
            });
        }

        class_243 pos = resultPos.orElseGet(() -> eyePos.method_1019(user.method_5720().method_1021(airReach)));
        EntityJudgementCut jc = new EntityJudgementCut(SBEntityTypes.JudgementCut, worldIn);
        jc.method_5814(pos.field_1352, pos.field_1351, pos.field_1350);
        jc.method_7432(user);
        CapabilitySlashBlade.getBladeState(stack).ifPresent((state) -> jc.setColor(state.getColorCode()));

        if (user != null)
            CapabilityConcentrationRank.RANK_POINT.maybeGet(user)
                    .ifPresent(rank -> jc.setRank(rank.getRankLevel(worldIn.method_8510())));

        worldIn.method_8649(jc);

        worldIn.method_43128(null, jc.method_23317(), jc.method_23318(), jc.method_23321(), class_3417.field_14879,
                class_3419.field_15248, 0.5F, 0.8F / (user.method_59922().method_43057() * 0.4F + 0.8F));

        return jc;
    }

    public static void doJudgementCutSuper(class_1309 owner) {
        doJudgementCutSuper(owner, null);
    }

    public static void doJudgementCutSuper(class_1309 owner, List<class_1297> exclude) {
        class_1937 level = owner.method_37908();
        class_1799 stack = owner.method_6047();

        List<class_1297> founds = TargetSelector.getTargettableEntitiesWithinAABB(level, owner,
                owner.method_5829().method_1014(48.0D), TargetSelector.getResolvedReach(owner) + 32D);
        if (exclude != null)
            founds.removeAll(exclude);
        for (class_1297 entity : founds) {
            if (entity instanceof class_1309) {

                ((class_1309) entity).method_6092(new class_1293(class_1294.field_5909, 40, 10));
                EntityJudgementCut judgementCut = new EntityJudgementCut(SBEntityTypes.JudgementCut, level);
                judgementCut.method_5814(entity.method_23317(), entity.method_23318(), entity.method_23321());
                judgementCut.method_7432(owner);
                CapabilitySlashBlade.getBladeState(stack)
                        .ifPresent(state -> judgementCut.setColor(state.getColorCode()));
                CapabilityConcentrationRank.RANK_POINT.maybeGet(owner)
                        .ifPresent(rank -> judgementCut.setRank(rank.getRankLevel(level.method_8510())));
                level.method_8649(judgementCut);
            }
        }

        level.method_45445(owner, owner.method_24515(), class_3417.field_14879, class_3419.field_15248, 1.0F, 1.0F);
    }
}
