package mods.flammpfeil.slashblade.entity;

import cn.sh1rocu.slashblade.util.network.IEntityExtension;
import cn.sh1rocu.slashblade.util.network.IEntityWithComplexSpawn;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.event.SlashBladeEvent;
import mods.flammpfeil.slashblade.init.SBEntityTypes;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1533;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_4050;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import javax.annotation.Nullable;

public class BladeStandEntity extends class_1533 implements IEntityWithComplexSpawn, IEntityExtension {

    public class_1792 currentType = null;
    public class_1799 currentTypeStack = class_1799.field_8037;

    public BladeStandEntity(class_1299<? extends BladeStandEntity> p_i50224_1_, class_1937 p_i50224_2_) {
        super(p_i50224_1_, p_i50224_2_);
    }

    @Override
    public void method_5652(class_2487 compound) {
        super.method_5652(compound);
        String standTypeStr;
        if (this.currentType != null) {
            standTypeStr = class_7923.field_41178.method_10221(this.currentType).toString();
        } else {
            standTypeStr = "";
        }
        compound.method_10582("StandType", standTypeStr);

        compound.method_10567("Pose", (byte) this.method_18376().ordinal());
    }

    @Override
    public void method_5749(class_2487 compound) {
        super.method_5749(compound);
        this.currentType = class_7923.field_41178.method_10223(class_2960.method_60654(compound.method_10558("StandType")));

        this.method_18380(class_4050.values()[compound.method_10571("Pose") % class_4050.values().length]);
    }

    @Override
    public void writeSpawnData(class_9129 buffer) {
        class_2487 tag = new class_2487();
        this.method_5652(tag);
        buffer.method_10794(tag);
    }

    @Override
    public void readSpawnData(class_9129 additionalData) {
        class_2487 tag = additionalData.method_10798();
        this.method_5749(tag);
    }

    public static BladeStandEntity createInstanceFromPos(class_1937 worldIn, class_2338 placePos, class_2350 dir, class_1792 type) {
        BladeStandEntity e = new BladeStandEntity(SBEntityTypes.BladeStand, worldIn);

        e.field_51589 = placePos;
        e.method_6892(dir);
        e.currentType = type;

        return e;
    }

    @Nullable
    @Override
    public class_1542 method_5706(class_1935 iip) {
        if (iip == class_1802.field_8143) {
            if (this.currentType == null || this.currentType == class_1802.field_8162)
                return null;

            iip = this.currentType;
        }
        return super.method_5706(iip);
    }

    @Override
    public boolean method_5643(class_1282 damageSource, float cat) {
        class_1799 blade = this.method_6940();

        if (blade.method_7960())
            return super.method_5643(damageSource, cat);

        if (CapabilitySlashBlade.getBladeState(blade).isEmpty())
            return super.method_5643(damageSource, cat);

        ISlashBladeState state = CapabilitySlashBlade.getBladeState(blade).orElseThrow(NullPointerException::new);

        SlashBladeEvent.BladeStandAttackEvent event = new SlashBladeEvent.BladeStandAttackEvent(blade, state, this, damageSource);
        SlashBladeEvent.BLADE_STAND_ATTACK.invoker().onBladeStandAttack(event);
        if (event.isCanceled()) {
            return true;
        }

        return super.method_5643(damageSource, cat);
    }

    @Override
    public class_1269 method_5688(class_1657 player, class_1268 hand) {
        class_1269 result = class_1269.field_5811;
        if (!this.method_37908().method_8608() && hand == class_1268.field_5808) {
            class_1799 itemstack = player.method_5998(hand);
            if (player.method_5715() && !this.method_6940().method_7960()) {
                class_4050 current = this.method_18376();
                int newIndex = (current.ordinal() + 1) % class_4050.values().length;
                this.method_18380(class_4050.values()[newIndex]);
                result = class_1269.field_5812;
            } else if ((!itemstack.method_7960() && CapabilitySlashBlade.getBladeState(itemstack).isPresent())
                    || (itemstack.method_7960() && !this.method_6940().method_7960())) {

                if (this.method_6940().method_7960()) {
                    if (!this.method_31481()) {
                        this.method_6935(itemstack);
                        if (!player.method_31549().field_7477) {
                            itemstack.method_7934(1);
                        }
                        this.method_5783(class_3417.field_14667, 1.0F, 1.0F);
                        result = class_1269.field_5812;
                    }
                } else {
                    class_1799 displayed = this.method_6940().method_7972();

                    this.method_6935(itemstack);
                    player.method_6122(hand, displayed);

                    this.method_5783(class_3417.field_14770, 1.0F, 1.0F);
                    result = class_1269.field_5812;

                }

            } else {
                this.method_5783(class_3417.field_15038, 1.0F, 1.0F);
                this.method_6939(this.method_6934() + 1);
                result = class_1269.field_5812;
            }
        }
        return result;
    }

    protected class_1799 method_33340() {
        return new class_1799(currentType);
    }

    @Override
    public boolean method_6888() {
        return true;
    }
}
