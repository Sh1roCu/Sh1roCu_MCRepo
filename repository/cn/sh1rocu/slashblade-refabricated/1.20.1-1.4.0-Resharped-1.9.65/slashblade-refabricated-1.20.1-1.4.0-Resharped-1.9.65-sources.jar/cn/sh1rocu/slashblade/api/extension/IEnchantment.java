package cn.sh1rocu.slashblade.api.extension;

import net.minecraft.class_1799;
import net.minecraft.class_1887;

public interface IEnchantment {
     boolean canApplyAtEnchantingTable(class_1799 stack, class_1887 enchantment);
}