package cn.sh1rocu.slashblade.mixin.client;

import cn.sh1rocu.slashblade.api.event.EntityAddedLayerCallback;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_3300;
import net.minecraft.class_5599;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import net.minecraft.class_898;

@Mixin(class_898.class)
public abstract class EntityRenderDispatcherMixin {
    @Shadow
    private Map<class_1299<?>, class_897<?>> renderers;

    @Shadow
    private Map<String, class_897<? extends class_1657>> playerRenderers;

    @Shadow
    @Final
    private class_5599 entityModels;

    @Inject(method = "onResourceManagerReload", at = @At("TAIL"), locals = LocalCapture.CAPTURE_FAILHARD)
    public void sb$resourceReload(class_3300 resourceManager, CallbackInfo ci, class_5617.class_5618 context) {
        EntityAddedLayerCallback.EVENT.invoker().addLayers(renderers, this.playerRenderers, context, this.entityModels);
    }
}