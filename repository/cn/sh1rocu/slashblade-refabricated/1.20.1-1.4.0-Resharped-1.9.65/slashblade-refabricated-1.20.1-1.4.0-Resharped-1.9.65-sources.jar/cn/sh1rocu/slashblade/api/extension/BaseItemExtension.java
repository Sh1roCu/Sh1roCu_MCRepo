package cn.sh1rocu.slashblade.api.extension;

import net.minecraft.class_1542;
import net.minecraft.class_1799;

public interface BaseItemExtension {
    boolean onEntityItemUpdate(class_1799 stack, class_1542 entity);

    int getEnchantmentValue(class_1799 stack);

}
