package cn.sh1rocu.slashblade.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_5599;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import java.util.Map;

// Porting Lib
@FunctionalInterface
public interface EntityAddedLayerCallback {

    Event<EntityAddedLayerCallback> EVENT = EventFactory.createArrayBacked(EntityAddedLayerCallback.class,
            callbacks -> (renderers, skinMap, context, entityModelSet) -> {
                for (EntityAddedLayerCallback event : callbacks) {
                    event.addLayers(renderers, skinMap, context, entityModelSet);
                }
            });

    void addLayers(Map<class_1299<?>, class_897<?>> renderers, Map<String, class_897<? extends class_1657>> skinMap, class_5617.class_5618 context, class_5599 entityModelSet);

}