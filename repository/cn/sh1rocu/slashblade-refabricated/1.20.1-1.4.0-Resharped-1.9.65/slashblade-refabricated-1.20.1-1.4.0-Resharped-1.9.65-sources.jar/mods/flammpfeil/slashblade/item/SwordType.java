package mods.flammpfeil.slashblade.item;

import com.mojang.serialization.Codec;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import net.minecraft.class_1799;
import java.util.EnumSet;
import java.util.Locale;

public enum SwordType {
    NONE, EDGEFRAGMENT, BROKEN, ENCHANTED, BEWITCHED, FIERCEREDGE, NOSCABBARD, SEALED, UNBREAKABLE, SOULEATER;

    public static final Codec<SwordType> CODEC = Codec.STRING.xmap(string -> SwordType.valueOf(string.toUpperCase(Locale.ENGLISH)),
            instance -> instance.name().toLowerCase(Locale.ENGLISH));

    public static EnumSet<SwordType> from(class_1799 itemStackIn) {
        EnumSet<SwordType> types = EnumSet.noneOf(SwordType.class);

        CapabilitySlashBlade.BLADESTATE.maybeGet(itemStackIn).ifPresentOrElse(s -> {
            if (s.isBroken())
                types.add(BROKEN);

            if (s.isSealed())
                types.add(SEALED);

            if (!s.isSealed() && itemStackIn.method_7942()
                    && (itemStackIn.method_7938() || s.isDefaultBewitched()))
                types.add(BEWITCHED);

            if (s.getKillCount() >= 1000)
                types.add(FIERCEREDGE);

            if (s.getProudSoulCount() >= 10000)
                types.add(SOULEATER);

        }, () -> {
            types.add(NOSCABBARD);
            types.add(EDGEFRAGMENT);
        });

        if (itemStackIn.method_7942())
            types.add(ENCHANTED);

        if (itemStackIn.method_7909() instanceof ItemSlashBladeDetune) {
            types.remove(SwordType.ENCHANTED);
            types.remove(SwordType.BEWITCHED);
        }

        if (itemStackIn.method_7948().method_10577("Unbreakable"))
            types.remove(SwordType.BROKEN);

        return types;
    }
}
