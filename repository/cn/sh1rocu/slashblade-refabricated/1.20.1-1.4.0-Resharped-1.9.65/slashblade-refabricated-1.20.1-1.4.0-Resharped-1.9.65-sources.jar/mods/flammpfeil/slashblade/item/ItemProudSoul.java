package mods.flammpfeil.slashblade.item;

import cn.sh1rocu.slashblade.api.extension.BaseItemExtension;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public abstract class ItemProudSoul extends class_1792 implements BaseItemExtension {
    public ItemProudSoul(class_1793 properties) {
        super(properties);
    }

    @Override
    public boolean onEntityItemUpdate(class_1799 stack, class_1542 entity) {
        return false;
    }

    @Override
    public boolean method_7886(class_1799 item) {
        return true;
    }

}
