package mods.flammpfeil.slashblade.mixin;

import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3726;
import net.minecraft.class_3727;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class_4971.class)
public class MixinBlockBehaviour {

    @SuppressWarnings("deprecation")
    @Inject(at = @At("HEAD"), method = "getCollisionShape(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/phys/shapes/CollisionContext;)Lnet/minecraft/world/phys/shapes/VoxelShape;", cancellable = true, remap = true)
    public void getCollisionShape(class_1922 p_60743_, class_2338 p_60744_, class_3726 p_60745_,
            CallbackInfoReturnable<class_265> callback) {
        if (!(asState().method_26164(class_3481.field_15503)))
            return;
        if (p_60745_.method_16193())
            return;

        if (!(p_60745_ instanceof class_3727))
            return;
        if (!(((class_3727) p_60745_).method_32480() instanceof class_1657))
            return;

        class_1799 itemStack = ((class_1657) ((class_3727) p_60745_).method_32480()).method_6047();
        if (!(itemStack.method_7909() instanceof ItemSlashBlade))
            return;

        callback.setReturnValue(class_2246.field_16492.method_9549(class_2246.field_16492.method_9564(), p_60743_,
                p_60744_, p_60745_));
        callback.cancel();
    }

    @SuppressWarnings("deprecation")
    @Inject(at = @At("HEAD"), method = "getVisualShape(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/phys/shapes/CollisionContext;)Lnet/minecraft/world/phys/shapes/VoxelShape;", cancellable = true, remap = true)
    public void getVisualShape(class_1922 p_60743_, class_2338 p_60744_, class_3726 p_60745_,
            CallbackInfoReturnable<class_265> callback) {
        if (!(asState().method_26164(class_3481.field_15503)))
            return;

        callback.setReturnValue(class_2246.field_16492.method_26159(class_2246.field_16492.method_9564(), p_60743_,
                p_60744_, p_60745_));
        callback.cancel();
    }

    @Shadow
    protected class_2680 asState() {
        throw new IllegalStateException("Mixin failed to shadow asState()");
    };
}
