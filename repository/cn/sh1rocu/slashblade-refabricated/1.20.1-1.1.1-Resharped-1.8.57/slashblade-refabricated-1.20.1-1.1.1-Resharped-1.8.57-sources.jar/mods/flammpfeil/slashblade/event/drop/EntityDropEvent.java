package mods.flammpfeil.slashblade.event.drop;

import cn.sh1rocu.slashblade.api.event.LivingDropsEvent;
import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.SlashBladeConfig;
import mods.flammpfeil.slashblade.entity.BladeItemEntity;
import mods.flammpfeil.slashblade.init.SBEntityTypes;
import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1569;
import net.minecraft.class_1799;
import net.minecraft.class_7923;

public class EntityDropEvent {
    public static void dropBlade(LivingDropsEvent event) {
        class_1309 entity = event.getEntity();
        var bladeRegistry = SlashBlade.getSlashBladeDefinitionRegistry(entity.method_37908());
        entity.method_37908().method_30349().method_30530(EntityDropEntry.REGISTRY_KEY).forEach(entry -> {
            if (!class_7923.field_41177.method_10250(entry.getEntityType()))
                return;
            if (!bladeRegistry.method_10250(entry.getBladeName()))
                return;

            if (!(event.getSource().method_5529() instanceof class_1309))
                return;

            class_1309 attacker = (class_1309) event.getSource().method_5529();

            if(SlashBladeConfig.FRIENDLY_ENABLE.get() || (entity instanceof class_1569)) {
                if (entry.isRequestSlashBladeKill()
                        && !(attacker.method_6047().method_7909() instanceof ItemSlashBlade))
                    return ;
            }

            float resultRate = Math.min(1F, entry.getDropRate() + event.getLootingLevel() * 0.1F);

            if (entry.isDropFixedPoint())
                dropBlade(entity, class_7923.field_41177.method_10223(entry.getEntityType()),
                        bladeRegistry.method_10223(entry.getBladeName()).getBlade(), resultRate, entry.getDropPoint().field_1352,
                        entry.getDropPoint().field_1351, entry.getDropPoint().field_1350);
            else
                dropBlade(entity, class_7923.field_41177.method_10223(entry.getEntityType()),
                        bladeRegistry.method_10223(entry.getBladeName()).getBlade(), resultRate, entity.method_23317(), entity.method_23318(),
                        entity.method_23321());
        });

    }

    public static void dropBlade(class_1309 entity, class_1299<?> type, class_1799 blade, float percent, double x,
                                 double y, double z) {
        if (entity.method_5864().equals(type)) {
            var rand = entity.method_37908().method_8409();

            if (rand.method_43057() > percent)
                return;
            class_1542 itementity = new class_1542(entity.method_37908(), x, y, z, blade);
            BladeItemEntity e = new BladeItemEntity(SBEntityTypes.BladeItem, entity.method_37908());

            e.method_5878(itementity);
            e.init();
            e.method_5762(0, 0.4, 0);

            e.method_6982(20 * 2);
            e.method_5834(true);

            e.method_5855(-1);

            e.method_6981(entity.method_5667());

            entity.method_37908().method_8649(e);
        }
    }
}
