package cn.sh1rocu.slashblade.util;

import com.google.gson.JsonObject;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_2073;
import net.minecraft.class_2960;

// Porting Lib
public class ItemPredicateRegistry {
    public static final Map<class_2960, Function<JsonObject, class_2073>> custom_predicates = new HashMap<>();
    private static final Map<class_2960, Function<JsonObject, class_2073>> unmod_predicates = Collections.unmodifiableMap(custom_predicates);

    public static void register(class_2960 name, Function<JsonObject, class_2073> deserializer) {
        custom_predicates.put(name, deserializer);
    }

    public static Map<class_2960, Function<JsonObject, class_2073>> getPredicates() {
        return unmod_predicates;
    }
}