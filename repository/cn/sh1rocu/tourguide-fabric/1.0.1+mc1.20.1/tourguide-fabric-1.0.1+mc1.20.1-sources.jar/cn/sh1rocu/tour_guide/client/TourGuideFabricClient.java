package cn.sh1rocu.tour_guide.client;

import io.github.fabricators_of_create.porting_lib.event.client.KeyInputCallback;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import studio.fantasyit.tour_guide.client.event.*;
import studio.fantasyit.tour_guide.event.TooltipEvent;
import studio.fantasyit.tour_guide.network.Network;

public class TourGuideFabricClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        Network.registerS2CPackets();
        ClientInputEvent.init();
        KeyInputCallback.EVENT.register(ClientInputEvent::onKey);
        ClientTickEvents.END_CLIENT_TICK.register(ClientInputEvent::onTick);
        HudRenderCallback.EVENT.register(GuiRenderingEvent::onGuiRender);
        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            ScreenEvents.afterRender(screen).register(GuiRenderingEvent::onScreenRender);
        });
        WorldRenderEvents.AFTER_ENTITIES.register(LevelRenderingEvent::onLevelRender);
        ClientLifecycleEvents.CLIENT_STARTED.register(SetupEvent::onSetup);
        ClientTickEvents.START_CLIENT_TICK.register(TickScreenEvent::onTick);
        ClientTickEvents.END_CLIENT_TICK.register(TickScreenEvent::onTick);
        ItemTooltipCallback.EVENT.register(TooltipEvent::onTooltip);
    }
}
