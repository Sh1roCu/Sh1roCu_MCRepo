package studio.fantasyit.tour_guide.client.event;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import studio.fantasyit.tour_guide.client.counter.ClientItemTourGuideCounter;
import studio.fantasyit.tour_guide.client.counter.ClientQuitCounter;
import studio.fantasyit.tour_guide.network.C2SInteractTourGuideData;

public class ClientInputEvent {
    public static void init() {

    }

    public static final class_304 KEY_CHECK_STEP = registerKeyBinding(new class_304(
            "key.tour_guide.check_step",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_ENTER,
            "key.tour_guide.category"
    ));
    public static final class_304 KEY_SKIP = registerKeyBinding(new class_304(
            "key.tour_guide.skip",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_KP_SUBTRACT,
            "key.tour_guide.category"
    ));
    public static final class_304 KEY_QUIT = registerKeyBinding(new class_304(
            "key.tour_guide.quit",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_END,
            "key.tour_guide.category"
    ));
    public static final class_304 KEY_START_TOUR_GUIDE = registerKeyBinding(new class_304(
            "key.tour_guide.start",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_T,
            "key.tour_guide.category"
    ));
    public static final class_304 KEY_SWITCH_ITEM_GUIDE = registerKeyBinding(new class_304(
            "key.tour_guide.switch",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_TAB,
            "key.tour_guide.category"
    ));

    public static boolean pressingShiftKey = false;

    private static class_304 registerKeyBinding(class_304 key) {
        return KeyBindingHelper.registerKeyBinding(key);
    }

    public static void onKey(int keyCode, int scancode, int action, int mods) {
        class_3675.class_306 key = class_3675.method_15985(keyCode, scancode);
        if (action == GLFW.GLFW_PRESS) {
            if (KeyBindingHelper.getBoundKeyOf(KEY_QUIT).equals(key)) {
                ClientQuitCounter.keyPressed();
            }
            if (KeyBindingHelper.getBoundKeyOf(KEY_SKIP).equals(key)) {
                ClientPlayNetworking.send(C2SInteractTourGuideData.ID, C2SInteractTourGuideData.toNetwork(C2SInteractTourGuideData.Type.SKIP));
            }
            if (KeyBindingHelper.getBoundKeyOf(KEY_CHECK_STEP).equals(key)) {
                if ((mods & GLFW.GLFW_MOD_SHIFT) != 0)
                    ClientPlayNetworking.send(C2SInteractTourGuideData.ID, C2SInteractTourGuideData.toNetwork(C2SInteractTourGuideData.Type.BACK));
                else
                    ClientPlayNetworking.send(C2SInteractTourGuideData.ID, C2SInteractTourGuideData.toNetwork(C2SInteractTourGuideData.Type.DONE));
            }
            if (KeyBindingHelper.getBoundKeyOf(KEY_START_TOUR_GUIDE).equals(key)) {
                ClientItemTourGuideCounter.keyPressed();
            }
            if (KeyBindingHelper.getBoundKeyOf(KEY_SWITCH_ITEM_GUIDE).equals(key)) {
                ClientItemTourGuideCounter.offset();
            }
            if (key.method_1444() == GLFW.GLFW_KEY_LEFT_SHIFT) {
                pressingShiftKey = true;
            }
        }
        if (action == GLFW.GLFW_RELEASE) {
            if (KeyBindingHelper.getBoundKeyOf(KEY_START_TOUR_GUIDE).equals(key)) {
                ClientItemTourGuideCounter.keyReleased();
            }
            if (key.method_1444() == GLFW.GLFW_KEY_LEFT_SHIFT) {
                pressingShiftKey = false;
            }
            if (KeyBindingHelper.getBoundKeyOf(KEY_QUIT).equals(key)) {
                ClientQuitCounter.keyReleased();
            }
        }
    }

    public static void onTick(class_310 client) {

    }
}