package cn.sh1rocu.tour_guide.mixin.common;

import cn.sh1rocu.tour_guide.api.event.PlayerEvent;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3324.class)
public class PlayerListMixin {
    @Inject(method = "remove", at = @At("HEAD"))
    private void tour_guide$remove(class_3222 player, CallbackInfo ci) {
        PlayerEvent.LOGGED_OUT.invoker().post(new PlayerEvent.PlayerLoggedOutEvent(player));
    }
}