package cn.sh1rocu.tour_guide.mixin.accessor;

import net.minecraft.class_1735;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_465.class)
public interface AbstractContainerScreenAccessor {
    @Accessor("hoveredSlot")
    class_1735 tour_guide$getSlotUnderMouse();

    @Accessor("leftPos")
    int tour_guide$getGuiLeft();

    @Accessor("imageWidth")
    int tour_guide$getXSize();

    @Accessor("topPos")
    int tour_guide$getGuiTop();
}
