package cn.sh1rocu.tour_guide;

import cn.sh1rocu.tour_guide.api.event.PlayerEvent;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.CommonLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.event.PlayerLevelEvent;
import studio.fantasyit.tour_guide.event.RegisterCommandEvent;
import studio.fantasyit.tour_guide.event.ReloadedEvent;
import studio.fantasyit.tour_guide.event.SetupEvent;
import studio.fantasyit.tour_guide.network.Network;

public class TourGuideFabric implements ModInitializer {

    @Override
    public void onInitialize() {
        TourGuide.setup();
        Network.registerC2SPackets();
        PlayerEvent.LOGGED_OUT.register(PlayerLevelEvent::onPlayerLevel);
        RegisterCommandEvent.onRegisterCommand();
        CommonLifecycleEvents.TAGS_LOADED.register(ReloadedEvent::onReloaded);
        ServerLifecycleEvents.SERVER_STARTING.register(SetupEvent::onSetup);
    }
}
