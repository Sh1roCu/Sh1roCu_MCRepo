package cn.sh1rocu.tour_guide.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1657;

public class PlayerEvent {
    private final class_1657 player;

    public static final Event<PlayerLoggedOutCallback> LOGGED_OUT = EventFactory.createArrayBacked(PlayerLoggedOutCallback.class, callbacks -> event -> {
        for (PlayerLoggedOutCallback callback : callbacks) callback.post(event);
    });

    public interface PlayerLoggedOutCallback {
        void post(PlayerLoggedOutEvent event);
    }

    public PlayerEvent(class_1657 player) {
        this.player = player;
    }

    public class_1657 getEntity() {
        return player;
    }

    public static class PlayerLoggedOutEvent extends PlayerEvent {
        public PlayerLoggedOutEvent(class_1657 player) {
            super(player);
        }
    }
}