package studio.fantasyit.tour_guide.event;

import net.minecraft.server.MinecraftServer;
import studio.fantasyit.tour_guide.api.event.CommonMarkSerializerRegisterEvent;

public class SetupEvent {
    public static void onSetup(MinecraftServer server) {
        CommonMarkSerializerRegisterEvent.EVENT.invoker().post(new CommonMarkSerializerRegisterEvent());
    }
}
