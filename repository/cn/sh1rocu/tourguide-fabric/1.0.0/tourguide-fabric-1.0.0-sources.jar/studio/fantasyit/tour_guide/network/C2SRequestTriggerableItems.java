package studio.fantasyit.tour_guide.network;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.data.ItemTourGuide;

public class C2SRequestTriggerableItems {

    public static final class_2960 ID = new class_2960(TourGuide.MODID, "c2s_request_triggerable_items");
    public static final class_2540 INSTANCE = PacketByteBufs.empty();

    public static void handle(MinecraftServer server, class_3222 player, class_3244 handler, class_2540 buf, PacketSender responseSender) {
        server.execute(() -> ItemTourGuide.syncTo(player));
    }
}
