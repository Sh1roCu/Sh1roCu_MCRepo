package studio.fantasyit.tour_guide.integration.kubejs.event;

import dev.latvian.mods.kubejs.event.EventJS;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import studio.fantasyit.tour_guide.client.screen_predicator.ScreenPredicatorAndTransformer;

import java.util.function.BiConsumer;
import java.util.function.Predicate;

@Environment(EnvType.CLIENT)
public class ClientScreenPredicatorRegisterEventJS extends EventJS {
    public void registerPredicator(class_2960 id, Predicate<class_437> predicate) {
        ScreenPredicatorAndTransformer.register(id, predicate);
    }

    public void registerTransformer(class_2960 id, BiConsumer<class_437, class_332> transformer) {
        ScreenPredicatorAndTransformer.register(id, transformer);
    }
}
