package studio.fantasyit.tour_guide.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.client.IGuiMarkRenderer;
import studio.fantasyit.tour_guide.client.IWorldMarkRenderer;
import studio.fantasyit.tour_guide.client.MarkRendererManager;

public class ClientMarkRendererRegisterEvent {

    public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.post(event);
        }
    });

    public void register(class_2960 id, IGuiMarkRenderer<?> renderer) {
        MarkRendererManager.register(id, renderer);
    }

    public void register(class_2960 id, IWorldMarkRenderer<?> renderer) {
        MarkRendererManager.register(id, renderer);
    }

    public interface Callback {
        void post(ClientMarkRendererRegisterEvent event);
    }
}
