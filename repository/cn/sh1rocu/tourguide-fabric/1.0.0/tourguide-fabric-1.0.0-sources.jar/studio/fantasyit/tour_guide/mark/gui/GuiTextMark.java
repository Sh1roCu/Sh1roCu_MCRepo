package studio.fantasyit.tour_guide.mark.gui;

import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.mark.IGuiMark;

public record GuiTextMark(class_2960 screenPredicate, class_2561 text, int x, int y, int width,
                          int color,int background) implements IGuiMark {

    public static final class_2960 ID = new class_2960(TourGuide.MODID, "gui_text");
    @Override
    public class_2960 getId() {
        return ID;
    }
    public static GuiTextMark fromNetwork(class_2540 buf) {
        return new GuiTextMark(buf.method_10810(), buf.method_10808(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt());
    }

    public void toNetwork(class_2540 buf) {
        buf.method_10812(screenPredicate);
        buf.method_10805(text);
        buf.writeInt(x);
        buf.writeInt(y);
        buf.writeInt(width);
        buf.writeInt(color);
        buf.writeInt(background);
    }
}
