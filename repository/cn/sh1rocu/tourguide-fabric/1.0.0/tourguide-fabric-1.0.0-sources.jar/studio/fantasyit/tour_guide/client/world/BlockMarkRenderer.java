package studio.fantasyit.tour_guide.client.world;

import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_761;
import studio.fantasyit.tour_guide.client.IWorldMarkRenderer;
import studio.fantasyit.tour_guide.mark.world.BlockMark;

public class BlockMarkRenderer implements IWorldMarkRenderer<BlockMark>, ITextLikeRenderer {
    @Override
    public void render(class_4597 source, class_761 levelRenderer, class_4587 poseStack, class_4184 camera, float partialTicks, BlockMark mark, Context context) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) {
            return;
        }
        class_243 position = camera.method_19326().method_22882();
        class_238 aabb = new class_238(mark.pos()).method_997(position);
        class_4588 buffer = mc.method_22940().method_23000().getBuffer(class_1921.field_21695);
        int tColor = mark.color();
        class_761.method_22982(poseStack, buffer, aabb, (tColor & 0xff) / 255.0f, ((tColor >> 8) & 0xff) / 255.0f, ((tColor >> 16) & 0xff) / 255.0f, ((tColor >> 24) & 0xff)/255.0f);
        if (mark.face() != null) {
            class_2338 sidePos = mark.pos().method_10093(mark.face());
            int dx = sidePos.method_10263() - mark.pos().method_10263();
            int dy = sidePos.method_10264() - mark.pos().method_10264();
            int dz = sidePos.method_10260() - mark.pos().method_10260();
            class_238 sideAabb = new class_238(sidePos).method_997(position);
            if (dx != 0) {
                if (dx > 0)
                    sideAabb = sideAabb.method_35577(sideAabb.field_1323 + 0.07);
                else
                    sideAabb = sideAabb.method_35574(sideAabb.field_1320 - 0.07);
            } else {
                sideAabb = sideAabb.method_35577(sideAabb.field_1320 - 0.2);
                sideAabb = sideAabb.method_35574(sideAabb.field_1323 + 0.2);
            }
            if (dy != 0) {
                if (dy > 0)
                    sideAabb = sideAabb.method_35578(sideAabb.field_1322 + 0.07);
                else
                    sideAabb = sideAabb.method_35575(sideAabb.field_1325 - 0.07);
            } else {
                sideAabb = sideAabb.method_35578(sideAabb.field_1325 - 0.2);
                sideAabb = sideAabb.method_35575(sideAabb.field_1322 + 0.2);
            }
            if (dz != 0) {
                if (dz > 0)
                    sideAabb = sideAabb.method_35579(sideAabb.field_1321 + 0.07);
                else
                    sideAabb = sideAabb.method_35576(sideAabb.field_1324 - 0.07);
            } else {
                sideAabb = sideAabb.method_35579(sideAabb.field_1324 - 0.2);
                sideAabb = sideAabb.method_35576(sideAabb.field_1321 + 0.2);
            }
            class_761.method_22982(poseStack, buffer, sideAabb,(tColor & 0xff) / 255.0f, ((tColor >> 8) & 0xff) / 255.0f, ((tColor >> 16) & 0xff) / 255.0f, ((tColor >> 24) & 0xff)/255.0f);
        }

        class_243 livingFrom = mark.pos().method_46558().method_1031(0, 0.7f, 0);
        drawText(poseStack, partialTicks, mc, camera, livingFrom, mark.text(), 0xffffffff, context.floating().getOrDefault(mark.pos(), 0) * 0.3f);
        context.floating().put(mark.pos(), context.floating().getOrDefault(mark.pos(), 0) + 1);
    }
}
