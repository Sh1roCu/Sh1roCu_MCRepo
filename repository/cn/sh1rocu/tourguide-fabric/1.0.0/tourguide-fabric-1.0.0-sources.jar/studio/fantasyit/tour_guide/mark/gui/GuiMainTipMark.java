package studio.fantasyit.tour_guide.mark.gui;

import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.mark.IGuiMark;

public record GuiMainTipMark(class_2960 screenPredicate, class_2561 text, boolean canSkip) implements IGuiMark {
    public static final class_2960 ID = new class_2960(TourGuide.MODID, "gui_main_tip");

    @Override
    public class_2960 getId() {
        return ID;
    }

    public void toNetwork(class_2540 buf){
        buf.method_10812(screenPredicate);
        buf.method_10805(text);
        buf.writeBoolean(canSkip);
    }
    public static GuiMainTipMark fromNetwork(class_2540 buf){
        return new GuiMainTipMark(buf.method_10810(), buf.method_10808(), buf.readBoolean());
    }
}
