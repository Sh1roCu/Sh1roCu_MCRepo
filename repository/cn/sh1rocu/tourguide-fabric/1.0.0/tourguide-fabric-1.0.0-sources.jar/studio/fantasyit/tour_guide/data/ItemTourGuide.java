package studio.fantasyit.tour_guide.data;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import oshi.util.tuples.Pair;
import studio.fantasyit.tour_guide.api.event.ItemTourGuideRegisterEvent;
import studio.fantasyit.tour_guide.network.S2CSyncTriggerableItems;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ItemTourGuide {
    public static Map<class_1792, List<class_2960>> itemTourGuide = new HashMap<>();

    public static void clear() {
        itemTourGuide.clear();
    }

    public static void register(class_1792 item, class_2960 tourGuide) {
        if (itemTourGuide.containsKey(item))
            itemTourGuide.get(item).add(tourGuide);
        else
            itemTourGuide.put(item, new ArrayList<>(List.of(tourGuide)));
    }

    public static void syncTo(class_3222 player) {
        ServerPlayNetworking.send(player, S2CSyncTriggerableItems.ID, S2CSyncTriggerableItems.toNetwork(
                itemTourGuide
                        .entrySet()
                        .stream()
                        .flatMap(t ->
                                t.getValue()
                                        .stream()
                                        .map(tt -> new Pair<>(class_7923.field_41178.method_10221(t.getKey()), tt))
                        )
                        .toList()
        ));
    }

    public static void clearAndBroadcastRegister() {
        clear();
        ItemTourGuideRegisterEvent.EVENT.invoker().post(new ItemTourGuideRegisterEvent());
    }

    public static int getCount(class_1792 item) {
        return itemTourGuide.containsKey(item) ? itemTourGuide.get(item).size() : 0;
    }

    public static class_2960 get(class_1792 item, int offset) {
        if (itemTourGuide.containsKey(item))
            return itemTourGuide.get(item).get(offset % itemTourGuide.get(item).size());
        return null;
    }
}
