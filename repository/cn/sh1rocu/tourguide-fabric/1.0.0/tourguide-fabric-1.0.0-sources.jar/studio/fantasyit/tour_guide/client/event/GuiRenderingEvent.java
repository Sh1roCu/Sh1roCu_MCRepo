package studio.fantasyit.tour_guide.client.event;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import studio.fantasyit.tour_guide.client.MarkRendererManager;
import studio.fantasyit.tour_guide.client.TourGuidingClientData;

public class GuiRenderingEvent {

    public static void onGuiRender(class_332 guiGraphics, float tickDelta) {
        class_437 screen = class_310.method_1551().field_1755;
        if (screen == null)
            TourGuidingClientData.getMarks().forEach(mark ->
                    MarkRendererManager.dispatchGuiRender(mark, guiGraphics, screen));
    }

    public static void onScreenRender(class_437 screen, class_332 guiGraphics, int mouseX, int mouseY, float tickDelta) {
        TourGuidingClientData.getMarks().forEach(mark ->
                MarkRendererManager.dispatchGuiRender(mark, guiGraphics, screen));
    }
}
