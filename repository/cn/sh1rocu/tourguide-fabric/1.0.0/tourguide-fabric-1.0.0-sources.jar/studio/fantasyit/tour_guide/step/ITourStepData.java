package studio.fantasyit.tour_guide.step;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2561;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.tour_guide.data.TourData;
import studio.fantasyit.tour_guide.mark.IMark;
import studio.fantasyit.tour_guide.network.S2CTipMessage;

import java.util.List;

public interface ITourStepData<T> {
    TourStepId<T> getId();

    @Nullable List<class_2561> getChatText(TourData data);

    default boolean shouldSkipAtStart(TourData data) {
        return false;
    }

    List<IMark> init(TourData data);

    @Nullable class_2561 getUnfinishReason(TourData data);

    default boolean checkIfFinished(TourData data) {
        return getUnfinishReason(data) == null;
    }

    default boolean allowSkip() {
        return false;
    }

    default void skipped(TourData data) {
    }

    T finish(TourData data);

    default boolean receiveTrigger(String key, Object data) {
        return false;
    }

    default void sendExtraTip(TourData tourData) {
        ServerPlayNetworking.send(tourData.getPlayer(), S2CTipMessage.ID, S2CTipMessage.toNetwork(allowSkip(), false));
    }
}
