package studio.fantasyit.tour_guide.mark.gui;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.mark.IGuiMark;

public record GuiRectMark(class_2960 screenPredicate, int x, int y, int width, int height,
                          int color,int fill) implements IGuiMark {

    public static final class_2960 ID = new class_2960(TourGuide.MODID, "gui_rect");
    @Override
    public class_2960 getId() {
        return ID;
    }
    public static GuiRectMark fromNetwork(class_2540 buf) {
        return new GuiRectMark(buf.method_10810(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt());
    }

    public void toNetwork(class_2540 buf) {
        buf.method_10812(screenPredicate);
        buf.writeInt(x);
        buf.writeInt(y);
        buf.writeInt(width);
        buf.writeInt(height);
        buf.writeInt(color);
        buf.writeInt(fill);
    }
}
