package studio.fantasyit.tour_guide.client;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import studio.fantasyit.tour_guide.client.event.ClientInputEvent;

public class ClientMessages {
    public static void sendOp(boolean allowSkip, boolean noCondition) {
        class_5250 t;
        if (noCondition)
            t = class_2561.method_43469("message.tour_guide.next_step_tip_no_condition", KeyBindingHelper.getBoundKeyOf(ClientInputEvent.KEY_CHECK_STEP).method_27445()).method_27692(class_124.field_1080);
        else
            t = class_2561.method_43469("message.tour_guide.next_step_tip", KeyBindingHelper.getBoundKeyOf(ClientInputEvent.KEY_CHECK_STEP).method_27445()).method_27692(class_124.field_1080);
        if (allowSkip)
            t = t.method_10852(class_2561.method_43469("message.tour_guide.skip_step_tip", KeyBindingHelper.getBoundKeyOf(ClientInputEvent.KEY_SKIP).method_27445()).method_27692(class_124.field_1080));
        class_310.method_1551().field_1724.method_43496(t);
    }
}
