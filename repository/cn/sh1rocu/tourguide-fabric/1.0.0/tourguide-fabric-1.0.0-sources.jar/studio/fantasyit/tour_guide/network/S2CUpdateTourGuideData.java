package studio.fantasyit.tour_guide.network;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_634;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.client.TourGuidingClientData;
import studio.fantasyit.tour_guide.mark.ContextMarkSerializer;
import studio.fantasyit.tour_guide.mark.IMark;

import java.util.List;

public class S2CUpdateTourGuideData {

    public static final class_2960 ID = new class_2960(TourGuide.MODID, "s2c_update_data");

    public static class_2540 toNetwork(List<IMark> marks) {
        class_2540 buf = PacketByteBufs.create();
        buf.method_34062(marks, ContextMarkSerializer::serialize);
        return buf;
    }

    @Environment(EnvType.CLIENT)
    public static void handle(class_310 client, class_634 handler, class_2540 buf, PacketSender responseSender) {
        List<IMark> marks = buf.method_34066(ContextMarkSerializer::deserialize);
        client.execute(() -> TourGuidingClientData.setMarks(marks));
    }
}
