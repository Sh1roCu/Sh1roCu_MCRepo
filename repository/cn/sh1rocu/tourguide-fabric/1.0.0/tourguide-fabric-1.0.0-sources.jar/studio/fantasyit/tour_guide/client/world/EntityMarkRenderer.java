package studio.fantasyit.tour_guide.client.world;

import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_761;
import studio.fantasyit.tour_guide.client.IWorldMarkRenderer;
import studio.fantasyit.tour_guide.mark.world.EntityMark;

public class EntityMarkRenderer implements IWorldMarkRenderer<EntityMark>, ITextLikeRenderer {
    @Override
    public void render(class_4597 source, class_761 levelRenderer, class_4587 poseStack, class_4184 camera, float partialTicks, EntityMark mark, Context context) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) {
            return;
        }
        class_1297 entity = mc.field_1687.method_8469(mark.id());
        if (entity == null) {
            return;
        }
        class_243 position = camera.method_19326().method_22882();
        class_238 aabb = entity.method_5829().method_997(position).method_1014(0.3);
        class_4588 buffer = mc.method_22940().method_23000().getBuffer(class_1921.field_21695);
        int tColor = mark.color();
        class_761.method_22982(poseStack, buffer, aabb, (tColor & 0xff) / 255.0f, ((tColor >> 8) & 0xff) / 255.0f, ((tColor >> 16) & 0xff) / 255.0f, ((tColor >> 24) & 0xff) / 255.0f);
        class_243 livingFrom = entity.method_30950(partialTicks).method_1031(0, entity.method_17682() + 0.5f, 0);
        drawText(poseStack, partialTicks, mc, camera, livingFrom, mark.text(), 0xffffffff, 0);
    }
}
