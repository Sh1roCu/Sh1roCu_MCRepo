package studio.fantasyit.tour_guide.integration.kubejs.event;

import dev.latvian.mods.kubejs.event.EventJS;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.data.ItemTourGuide;

public class ItemTourGuideRegisterEventJS extends EventJS {
    public void register(class_2960 id, class_1792... items) {
        for (class_1792 item : items) {
            ItemTourGuide.register(item, id);
        }
    }
}
