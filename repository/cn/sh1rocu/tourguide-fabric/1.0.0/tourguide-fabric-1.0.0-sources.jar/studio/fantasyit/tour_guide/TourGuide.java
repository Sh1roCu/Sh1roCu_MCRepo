package studio.fantasyit.tour_guide;

import fuzs.forgeconfigapiport.api.config.v2.ModConfigEvents;

public class TourGuide {

    public static final String MODID = "tour_guide";

    public static void setup() {
        ModConfigEvents.loading(MODID).register(Config::onLoad);
        ModConfigEvents.reloading(MODID).register(Config::onLoad);
        ModConfigEvents.unloading(MODID).register(Config::onLoad);
    }
}
