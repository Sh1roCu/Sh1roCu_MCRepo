package studio.fantasyit.tour_guide.event;

import studio.fantasyit.tour_guide.client.counter.ClientItemTourGuideCounter;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

public class TooltipEvent {

    public static void onTooltip(class_1799 stack, class_1836 context, List<class_2561> lines) {
        ClientItemTourGuideCounter.addTooltip(stack.method_7909(), lines);
    }
}
