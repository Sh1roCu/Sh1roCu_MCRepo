package studio.fantasyit.tour_guide.event;


import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2170;
import net.minecraft.class_2232;
import net.minecraft.class_3222;
import studio.fantasyit.tour_guide.api.TourManager;
import studio.fantasyit.tour_guide.data.TourData;

public class RegisterCommandEvent {

    public static void onRegisterCommand() {
        CommandRegistrationCallback.EVENT.register((dispatcher, context, selection) -> {
                    dispatcher.register(class_2170.method_9247("tour_guide")
                            .then(class_2170.method_9247("start")
                                    .then(class_2170.method_9244("id", new class_2232())
                                            .executes(t -> {
                                                class_3222 player = t.getSource().method_9207();
                                                if (TourManager.start(player, class_2232.method_9443(t, "id")))
                                                    return 1;
                                                return 0;
                                            })
                                    )
                            )
                            .then(class_2170.method_9247("stop")
                                    .executes(t -> {
                                        TourManager.stop(t.getSource().method_9207());
                                        return 1;
                                    })
                            )
                            .then(class_2170.method_9247("check")
                                    .executes(t -> {
                                        TourData tourData = TourManager.get(t.getSource().method_9207());
                                        if (tourData == null)
                                            return 0;
                                        tourData.doneAndTryNextStep();
                                        return 1;
                                    })
                            )
                            .then(class_2170.method_9247("skip")
                                    .executes(t -> {
                                        TourData tourData = TourManager.get(t.getSource().method_9207());
                                        if (tourData == null)
                                            return 0;
                                        tourData.skipAndTryNextStep();
                                        return 1;
                                    })
                            ));
                }
        );
    }

}
