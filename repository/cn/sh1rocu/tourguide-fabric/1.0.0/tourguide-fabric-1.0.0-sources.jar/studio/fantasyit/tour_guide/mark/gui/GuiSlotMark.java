package studio.fantasyit.tour_guide.mark.gui;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.mark.IGuiMark;

public record GuiSlotMark(class_2960 screenPredicate, int id, int color) implements IGuiMark {
    public static final class_2960 ID = new class_2960(TourGuide.MODID, "gui_slot");
    @Override
    public class_2960 getId() {
        return ID;
    }
    public static GuiSlotMark fromNetwork(class_2540 buf) {
        return new GuiSlotMark(buf.method_10810(), buf.readInt(), buf.readInt());
    }

    public void toNetwork(class_2540 buf) {
        buf.method_10812(screenPredicate);
        buf.writeInt(id);
        buf.writeInt(color);
    }
}
