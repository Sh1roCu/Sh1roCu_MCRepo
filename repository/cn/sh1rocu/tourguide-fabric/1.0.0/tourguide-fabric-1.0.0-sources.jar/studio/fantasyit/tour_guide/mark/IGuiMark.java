package studio.fantasyit.tour_guide.mark;

import net.minecraft.class_2960;

public interface IGuiMark extends IMark {
    class_2960 screenPredicate();
}
