package studio.fantasyit.tour_guide.api;

import org.jetbrains.annotations.Nullable;
import studio.fantasyit.tour_guide.data.TourData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class TourManager {
    private static final Map<UUID, TourData> RUNNING_TOUR = new HashMap<>();

    public static boolean start(class_3222 player, class_2960 id) {
        if (RUNNING_TOUR.containsKey(player.method_5667())) {
            stop(player);
        }
        TourData tourData = TourDataManager.get(id, player);
        if (tourData == null)
            return false;
        RUNNING_TOUR.put(player.method_5667(), tourData);
        tourData.start();
        return true;
    }

    public static void stop(class_3222 player) {
        if (!RUNNING_TOUR.containsKey(player.method_5667()))
            return;
        TourData tourData = RUNNING_TOUR.get(player.method_5667());
        tourData.terminate();
    }

    public static void remove(class_3222 sender) {
        RUNNING_TOUR.remove(sender.method_5667());
    }

    public static @Nullable TourData get(class_3222 sender) {
        return RUNNING_TOUR.get(sender.method_5667());
    }

    public static void each(Consumer<TourData> o) {
        RUNNING_TOUR.values().forEach(o);
    }
}
