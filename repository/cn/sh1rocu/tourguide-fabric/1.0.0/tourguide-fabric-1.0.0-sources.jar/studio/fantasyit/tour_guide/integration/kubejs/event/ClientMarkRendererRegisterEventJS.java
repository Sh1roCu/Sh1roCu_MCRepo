package studio.fantasyit.tour_guide.integration.kubejs.event;

import dev.latvian.mods.kubejs.event.EventJS;
import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.client.IGuiMarkRenderer;
import studio.fantasyit.tour_guide.client.IWorldMarkRenderer;
import studio.fantasyit.tour_guide.client.MarkRendererManager;

public class ClientMarkRendererRegisterEventJS extends EventJS {
    public void registerGuiMark(class_2960 id, IGuiMarkRenderer<?> renderer) {
        MarkRendererManager.register(id, renderer);
    }

    public void registerWorldMark(class_2960 id, IWorldMarkRenderer<?> renderer) {
        MarkRendererManager.register(id, renderer);
    }
}
