package studio.fantasyit.tour_guide.integration.kubejs.helper;

import studio.fantasyit.tour_guide.api.TourGuideTrigger;
import studio.fantasyit.tour_guide.api.helper.TourDataBuilder;
import studio.fantasyit.tour_guide.api.helper.TourStepBuilder;
import studio.fantasyit.tour_guide.mark.IGuiMark;
import studio.fantasyit.tour_guide.mark.IMark;
import studio.fantasyit.tour_guide.mark.ServerScreenPredicatorMarks;
import studio.fantasyit.tour_guide.mark.gui.GuiMainTipMark;
import studio.fantasyit.tour_guide.mark.gui.GuiRectMark;
import studio.fantasyit.tour_guide.mark.gui.GuiSlotMark;
import studio.fantasyit.tour_guide.mark.gui.GuiTextMark;
import studio.fantasyit.tour_guide.mark.world.BlockMark;
import studio.fantasyit.tour_guide.mark.world.EntityMark;
import studio.fantasyit.tour_guide.mark.world.TextMark;
import studio.fantasyit.tour_guide.step.TourStepId;

import java.util.function.Function;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class TourGuideObj {
    public static TourGuideObj INSTANCE = new TourGuideObj();

    public class_2960 SCREEN_PREDICATE_ALL = ServerScreenPredicatorMarks.ALL;
    public class_2960 SCREEN_PREDICATE_NONE = ServerScreenPredicatorMarks.NO_GUI;

    public TourDataBuilder builder() {
        return new TourDataBuilder();
    }

    public <T> TourStepBuilder<T> stepBuilder() {
        return new TourStepBuilder<T>();
    }

    public <T> TourStepId<T> id(class_2960 id, Function<Object, T> caster) {
        return new TourStepId<>(id, caster);
    }

    public IMark makeGuiMainTipMark(class_2960 screenPredicate, class_2561 text, boolean allowSkip) {
        return new GuiMainTipMark(screenPredicate, text, allowSkip);
    }

    public IMark makeGuiRectMark(class_2960 screenPredicate, int x, int y, int width, int height, long color, int fill) {
        return new GuiRectMark(screenPredicate, x, y, width, height, (int)color, fill);
    }

    public IMark makeGuiSlotMark(class_2960 screenPredicate, int id, long color) {
        return new GuiSlotMark(screenPredicate, id, (int)color);
    }

    public IMark makeGuiTextMark(class_2960 screenPredicate, class_2561 text, int x, int y, int width, long color, int background) {
        return new GuiTextMark(screenPredicate, text, x, y, width, (int)color, background);
    }

    public class_2960 noTransform(class_2960 id){
        return ServerScreenPredicatorMarks.noTransform(id);
    }

    public IMark makeBlockMark(class_2338 pos, long color, class_2561 text) {
        return new BlockMark(pos, null, (int)color, text);
    }

    public IMark makeBlockMarkWithFace(class_2338 pos, class_2350 face, long color, class_2561 text) {
        return new BlockMark(pos, face, (int)color, text);
    }

    public IMark makeEntityMark(int entityId, long color, class_2561 text) {
        return new EntityMark(entityId, (int)color, text);
    }

    public IMark makeTextMark(class_243 pos, class_2561 text, long color) {
        return new TextMark(text, pos, (int)color);
    }

    public void trigger(class_3222 player, String key, Object data) {
        TourGuideTrigger.trigger(player, key, data);
    }

    public void triggerNoData(class_3222 player, String key) {
        TourGuideTrigger.trigger(player, key);
    }

    public void triggerGlobal(String key, Object data) {
        TourGuideTrigger.trigger(key, data);
    }

    public void triggerGlobalNoData(String key) {
        TourGuideTrigger.trigger(key);
    }

    public void triggerClient(String key) {
        TourGuideTrigger.triggerClient(key);
    }
}
