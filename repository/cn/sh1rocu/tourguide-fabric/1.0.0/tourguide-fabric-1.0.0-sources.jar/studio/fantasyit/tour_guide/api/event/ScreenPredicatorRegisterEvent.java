package studio.fantasyit.tour_guide.api.event;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import studio.fantasyit.tour_guide.client.screen_predicator.ScreenPredicatorAndTransformer;

import java.util.function.BiConsumer;
import java.util.function.Predicate;

@Environment(EnvType.CLIENT)
public class ScreenPredicatorRegisterEvent {

    public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.post(event);
        }
    });

    public void register(class_2960 id, Predicate<class_437> predicate) {
        ScreenPredicatorAndTransformer.register(id, predicate);
    }

    public void register(class_2960 id, BiConsumer<class_437, class_332> transformer) {
        ScreenPredicatorAndTransformer.register(id, transformer);
    }

    public interface Callback {
        void post(ScreenPredicatorRegisterEvent event);
    }
}
