package studio.fantasyit.tour_guide.client.gui;

import net.minecraft.class_332;
import net.minecraft.class_437;
import studio.fantasyit.tour_guide.client.IGuiMarkRenderer;
import studio.fantasyit.tour_guide.mark.gui.GuiRectMark;

public class GuiRectMarkRenderer implements IGuiMarkRenderer<GuiRectMark> {
    @Override
    public void render(class_332 graphics, GuiRectMark mark, class_437 screen) {
        int thickness = 3;
        graphics.method_25294(mark.x(), mark.y(), mark.x() + thickness, mark.y() + mark.height(), mark.color());
        graphics.method_25294(mark.x() + mark.width() - thickness, mark.y(), mark.x() + mark.width(), mark.y() + mark.height(), mark.color());
        graphics.method_25294(mark.x() + thickness, mark.y(), mark.x() + mark.width() - thickness, mark.y() + thickness, mark.color());
        graphics.method_25294(mark.x() + thickness, mark.y() + mark.height() - thickness, mark.x() + mark.width() - thickness, mark.y() + mark.height(), mark.color());
        graphics.method_25294(mark.x() + thickness, mark.y() + thickness, mark.x() + mark.width() - thickness, mark.y() + mark.height() - thickness, mark.fill());
    }
}
