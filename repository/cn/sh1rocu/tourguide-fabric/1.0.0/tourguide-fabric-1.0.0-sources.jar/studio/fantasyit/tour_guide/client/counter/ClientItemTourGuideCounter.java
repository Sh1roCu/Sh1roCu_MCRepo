package studio.fantasyit.tour_guide.client.counter;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import studio.fantasyit.tour_guide.client.event.ClientInputEvent;
import studio.fantasyit.tour_guide.data.ItemTourGuide;
import studio.fantasyit.tour_guide.network.C2SStartTourGuide;
import studio.fantasyit.tour_guide.screen.BlockHoldKeyScreen;

import java.util.List;

public class ClientItemTourGuideCounter {
    private static final long TIME_OUT = 900;
    public static long startTimeStamp = 0;
    public static class_1792 lastItem = null;
    public static boolean hasAvailable = false;
    public static boolean hasMultiple = false;
    public static int offset = 0;

    public static void addTooltip(class_1792 item, List<class_2561> tooltip) {
        if (lastItem != item || !hasAvailable) return;
        tooltip.add(class_2561.method_43469("tooltip.tour_guide.item_tour_guide",
                class_2561.method_43471("tour." + ItemTourGuide.get(item, offset).method_42094())
        ).method_27692(class_124.field_1080));
        if (hasMultiple)
            tooltip.add(class_2561.method_43469("tooltip.tour_guide.item_tour_guide.switch", KeyBindingHelper.getBoundKeyOf(ClientInputEvent.KEY_SWITCH_ITEM_GUIDE).method_27445()).method_27692(class_124.field_1080));
        if (startTimeStamp == 0) {
            tooltip.add(class_2561.method_43469("tooltip.tour_guide.item_tour_guide.start", KeyBindingHelper.getBoundKeyOf(ClientInputEvent.KEY_START_TOUR_GUIDE).method_27445()));
        } else {
            long hasHoldTime = System.currentTimeMillis() - startTimeStamp;
            int p1 = Math.toIntExact(hasHoldTime * 35 / TIME_OUT);
            int p2 = 35 - p1;
            StringBuilder sp1 = new StringBuilder();
            for (int i = 0; i < p1; i++) {
                sp1.append("|");
            }
            StringBuilder sp2 = new StringBuilder();
            for (int i = 0; i < p2; i++) {
                sp2.append("|");
            }
            tooltip.add(class_2561.method_43469("tooltip.tour_guide.item_tour_guide.hold",
                    class_2561.method_43470(sp1.toString()).method_27692(class_124.field_1068),
                    class_2561.method_43470(sp2.toString()).method_27692(class_124.field_1080)
            ));
        }
    }

    public static void keyPressed() {
        startTimeStamp = System.currentTimeMillis();
    }

    public static void keyReleased() {
        startTimeStamp = 0;
        if (class_310.method_1551().field_1755 instanceof BlockHoldKeyScreen) {
            class_310.method_1551().method_1507(null);
        }
    }

    public static void updateHoveredItem(class_1792 item) {
        if (item != lastItem) {
            lastItem = item;
            hasAvailable = ItemTourGuide.get(item, offset) != null;
            hasMultiple = ItemTourGuide.getCount(item) > 1;
            startTimeStamp = 0;
            offset = 0;
        }
        if (startTimeStamp != 0 && hasAvailable) {
            if (System.currentTimeMillis() - startTimeStamp > TIME_OUT) {
                sendStart();
                startTimeStamp = 0;
            }
        }
    }

    private static void sendStart() {
        ClientPlayNetworking.send(C2SStartTourGuide.ID, C2SStartTourGuide.toNetwork(ItemTourGuide.get(lastItem, offset)));
        class_310.method_1551().field_1724.method_7346();
        class_310.method_1551().method_1507(new BlockHoldKeyScreen());
    }

    public static boolean isHasAvailable() {
        return hasAvailable;
    }

    public static void offset() {
        offset++;
    }
}
