package studio.fantasyit.tour_guide.event;

import cn.sh1rocu.tour_guide.api.event.PlayerEvent;
import net.minecraft.class_3222;
import studio.fantasyit.tour_guide.api.TourManager;

public class PlayerLevelEvent {
    public static void onPlayerLevel(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof class_3222 sp)
            TourManager.remove(sp);
    }
}
