package studio.fantasyit.tour_guide.client;

import java.util.Map;
import net.minecraft.class_2338;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_761;

public interface IWorldMarkRenderer<T> {
    record Context(Map<class_2338, Integer> floating) {
    }

    void render(class_4597 source, class_761 levelRenderer, class_4587 poseStack, class_4184 camera, float partialTicks, T mark, Context context);
}
