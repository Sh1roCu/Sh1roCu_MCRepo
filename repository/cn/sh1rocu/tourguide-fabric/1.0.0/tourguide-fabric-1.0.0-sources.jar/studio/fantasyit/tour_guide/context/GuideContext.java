package studio.fantasyit.tour_guide.context;

import java.util.List;
import net.minecraft.class_2561;

public class GuideContext {
    List<Object> marks;
    class_2561 mainText;
}
