package studio.fantasyit.tour_guide.mark;

import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.TourGuide;

public class ServerScreenPredicatorMarks {
    public static final class_2960 ALL = new class_2960(TourGuide.MODID, "all");
    public static final class_2960 NO_GUI = new class_2960(TourGuide.MODID, "no_gui");

    public static class_2960 noTransform(class_2960 id) {
        return new class_2960(id.method_12836(), "no_transform/" + id.method_12832());
    }

    public static class_2960 base(class_2960 id) {
        if (isNoTransform(id)) {
            return new class_2960(id.method_12836(), id.method_12832().substring("no_transform/".length()));
        }
        return id;
    }

    public static boolean isNoTransform(class_2960 id) {
        return id.method_12832().startsWith("no_transform/");
    }
}
