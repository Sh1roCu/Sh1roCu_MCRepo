package studio.fantasyit.tour_guide.mark.world;

import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.mark.IMark;

public record TextMark(class_2561 text, class_243 pos, int color) implements IMark {

    public static final class_2960 ID = new class_2960(TourGuide.MODID, "text");
    @Override
    public class_2960 getId() {
        return ID;
    }
    public static TextMark fromNetwork(class_2540 buf) {
        return new TextMark(buf.method_10808(), new class_243(buf.readDouble(), buf.readDouble(), buf.readDouble()), buf.readInt());
    }

    public void toNetwork(class_2540 buf) {
        buf.method_10805(text);
        buf.writeDouble(pos.field_1352);
        buf.writeDouble(pos.field_1351);
        buf.writeDouble(pos.field_1350);
        buf.writeInt(color);
    }
}
