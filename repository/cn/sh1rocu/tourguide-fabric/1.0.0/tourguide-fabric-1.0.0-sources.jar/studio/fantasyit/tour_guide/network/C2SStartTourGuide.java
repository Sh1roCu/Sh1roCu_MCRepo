package studio.fantasyit.tour_guide.network;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.api.TourManager;

import java.util.Objects;

public class C2SStartTourGuide {

    public static final class_2960 ID = new class_2960(TourGuide.MODID, "c2s_start_tour_guide");

    public static class_2540 toNetwork(class_2960 id) {
        class_2540 buf = PacketByteBufs.create();
        buf.method_10812(id);
        return buf;
    }

    public static void handle(MinecraftServer server, class_3222 player, class_3244 handler, class_2540 buf, PacketSender responseSender) {
        var id = buf.method_10810();
        server.execute(() -> TourManager.start(Objects.requireNonNull(player), id));
    }
}
