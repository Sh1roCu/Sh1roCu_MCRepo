package studio.fantasyit.tour_guide.client.counter;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import studio.fantasyit.tour_guide.network.C2SInteractTourGuideData;
import studio.fantasyit.tour_guide.screen.BlockHoldKeyScreen;

public class ClientQuitCounter {
    private static final long TIME_OUT = 900;
    public static long startTimeStamp = 0;

    public static void tick() {
        if (startTimeStamp != 0)
            if (System.currentTimeMillis() - startTimeStamp > TIME_OUT) {
                sendQuit();
                startTimeStamp = 0;
            }
    }

    public static boolean isPressingQuitKey() {
        return startTimeStamp != 0;
    }

    public static void keyPressed() {
        startTimeStamp = System.currentTimeMillis();
    }

    public static void keyReleased() {
        startTimeStamp = 0;
        if (class_310.method_1551().field_1755 instanceof BlockHoldKeyScreen) {
            class_310.method_1551().method_1507(null);
        }
    }

    public static class_2561 getPressingProgressBar() {
        long hasHoldTime = System.currentTimeMillis() - startTimeStamp;
        int p1 = Math.toIntExact(hasHoldTime * 35 / TIME_OUT);
        int p2 = 35 - p1;
        StringBuilder sp1 = new StringBuilder();
        for (int i = 0; i < p1; i++) {
            sp1.append("|");
        }
        StringBuilder sp2 = new StringBuilder();
        for (int i = 0; i < p2; i++) {
            sp2.append("|");
        }
        return class_2561.method_43469("tooltip.tour_guide.item_tour_guide.hold",
                class_2561.method_43470(sp1.toString()).method_27692(class_124.field_1068),
                class_2561.method_43470(sp2.toString()).method_27692(class_124.field_1080)
        );
    }

    private static void sendQuit() {
        ClientPlayNetworking.send(C2SInteractTourGuideData.ID, C2SInteractTourGuideData.toNetwork(C2SInteractTourGuideData.Type.QUIT));
    }
}
