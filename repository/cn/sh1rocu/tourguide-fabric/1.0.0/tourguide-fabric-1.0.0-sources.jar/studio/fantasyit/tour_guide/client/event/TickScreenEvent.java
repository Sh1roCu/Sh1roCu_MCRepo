package studio.fantasyit.tour_guide.client.event;

import cn.sh1rocu.tour_guide.mixin.accessor.AbstractContainerScreenAccessor;
import net.minecraft.class_310;
import net.minecraft.class_465;
import studio.fantasyit.tour_guide.client.counter.ClientItemTourGuideCounter;
import studio.fantasyit.tour_guide.client.counter.ClientQuitCounter;

public class TickScreenEvent {

    public static void onTick(class_310 client) {
        if (client.field_1755 instanceof class_465<?> s && ((AbstractContainerScreenAccessor) s).tour_guide$getSlotUnderMouse() != null) {
            ClientItemTourGuideCounter.updateHoveredItem(((AbstractContainerScreenAccessor) s).tour_guide$getSlotUnderMouse().method_7677().method_7909());
        } else {
            ClientItemTourGuideCounter.updateHoveredItem(null);
        }
        ClientQuitCounter.tick();
    }
}
