package studio.fantasyit.tour_guide.mark.world;

import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.mark.IMark;

public record EntityMark(int id,int color, class_2561 text) implements IMark {

    public static final class_2960 ID = new class_2960(TourGuide.MODID, "entity");
    @Override
    public class_2960 getId() {
        return ID;
    }
    public static EntityMark fromNetwork(class_2540 buf) {
        return new EntityMark(buf.readInt(), buf.readInt(), buf.method_10808());
    }

    public void toNetwork(class_2540 buf) {
        buf.writeInt(id);
        buf.writeInt(color);
        buf.method_10805(text);
    }
}