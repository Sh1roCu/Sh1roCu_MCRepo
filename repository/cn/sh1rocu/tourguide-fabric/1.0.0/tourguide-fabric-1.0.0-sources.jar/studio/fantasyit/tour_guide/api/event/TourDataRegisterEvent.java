package studio.fantasyit.tour_guide.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.api.TourDataManager;
import studio.fantasyit.tour_guide.data.ITourDataFactory;

public class TourDataRegisterEvent {

    public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.post(event);
        }
    });

    public void register(class_2960 id, ITourDataFactory tourData) {
        TourDataManager.register(id, tourData);
    }

    public interface Callback {
        void post(TourDataRegisterEvent event);
    }
}
