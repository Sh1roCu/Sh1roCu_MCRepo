package studio.fantasyit.tour_guide.api;

import studio.fantasyit.tour_guide.api.event.TourDataRegisterEvent;
import studio.fantasyit.tour_guide.data.ITourDataFactory;
import studio.fantasyit.tour_guide.data.TourData;
import studio.fantasyit.tour_guide.integration.Integrations;
import studio.fantasyit.tour_guide.integration.kubejs.KubeJSPort;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class TourDataManager {
    private static final Map<class_2960, ITourDataFactory> TOURS = new HashMap<>();

    public static void register(class_2960 id, ITourDataFactory tourData) {
        TOURS.put(id, tourData);
    }

    public static void clearAndBroadcastRegister() {
        TOURS.clear();
        TourDataRegisterEvent.EVENT.invoker().post(new TourDataRegisterEvent());
        if (Integrations.kjs())
            KubeJSPort.reloaded();
    }

    public static TourData get(class_2960 id, class_3222 player) {
        return TOURS.get(id).create(player, id);
    }
}