package studio.fantasyit.tour_guide.client;

import com.mojang.datafixers.util.Either;
import studio.fantasyit.tour_guide.client.gui.GuiMainTipMarkRenderer;
import studio.fantasyit.tour_guide.client.gui.GuiRectMarkRenderer;
import studio.fantasyit.tour_guide.client.gui.GuiSlotMarkRenderer;
import studio.fantasyit.tour_guide.client.gui.GuiTextMarkRenderer;
import studio.fantasyit.tour_guide.client.screen_predicator.ScreenPredicatorAndTransformer;
import studio.fantasyit.tour_guide.client.world.BlockMarkRenderer;
import studio.fantasyit.tour_guide.client.world.EntityMarkRenderer;
import studio.fantasyit.tour_guide.client.world.TextMarkRenderer;
import studio.fantasyit.tour_guide.mark.IGuiMark;
import studio.fantasyit.tour_guide.mark.IMark;
import studio.fantasyit.tour_guide.mark.gui.GuiMainTipMark;
import studio.fantasyit.tour_guide.mark.gui.GuiRectMark;
import studio.fantasyit.tour_guide.mark.gui.GuiSlotMark;
import studio.fantasyit.tour_guide.mark.gui.GuiTextMark;
import studio.fantasyit.tour_guide.mark.world.BlockMark;
import studio.fantasyit.tour_guide.mark.world.EntityMark;
import studio.fantasyit.tour_guide.mark.world.TextMark;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4184;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_761;

public class MarkRendererManager {
    private static Map<class_2960, Either<IWorldMarkRenderer<?>, IGuiMarkRenderer<?>>> renderers = new HashMap<>();

    public static void register(class_2960 id, IWorldMarkRenderer<?> renderer) {
        renderers.put(id, Either.left(renderer));
    }

    public static void register(class_2960 id, IGuiMarkRenderer<?> renderer) {
        renderers.put(id, Either.right(renderer));
    }

    public static void dispatchWorldRender(IMark mark, class_4597 source, class_4184 camera, class_761 levelRenderer, class_4587 poseStack, float partialTicks) {
        if (!renderers.containsKey(mark.getId())) return;
        Either<IWorldMarkRenderer<?>, IGuiMarkRenderer<?>> iWorldMarkRendererIGuiMarkRendererEither = renderers.get(mark.getId());
        iWorldMarkRendererIGuiMarkRendererEither.ifLeft(i -> {
            ((IWorldMarkRenderer) i).render(source, levelRenderer, poseStack, camera, partialTicks, mark, new IWorldMarkRenderer.Context(new HashMap<>()));
        });
    }

    public static void dispatchGuiRender(IMark mark, class_332 graphics, class_437 screen) {
        if (!renderers.containsKey(mark.getId())) return;
        Either<IWorldMarkRenderer<?>, IGuiMarkRenderer<?>> iWorldMarkRendererIGuiMarkRendererEither = renderers.get(mark.getId());
        iWorldMarkRendererIGuiMarkRendererEither.ifRight(i -> {
            if (!(mark instanceof IGuiMark igm)) return;
            if (!ScreenPredicatorAndTransformer.predicate(igm.screenPredicate(), screen)) return;
            graphics.method_51448().method_22903();
            ScreenPredicatorAndTransformer.transform(igm.screenPredicate(), screen, graphics);
            ((IGuiMarkRenderer) i).render(graphics, mark, screen);
            graphics.method_51448().method_22909();
        });
    }


    static {
        register(GuiTextMark.ID, new GuiTextMarkRenderer());
        register(GuiSlotMark.ID, new GuiSlotMarkRenderer());
        register(GuiRectMark.ID, new GuiRectMarkRenderer());
        register(GuiMainTipMark.ID, new GuiMainTipMarkRenderer());
        register(TextMark.ID, new TextMarkRenderer());
        register(BlockMark.ID, new BlockMarkRenderer());
        register(EntityMark.ID, new EntityMarkRenderer());
    }
}
