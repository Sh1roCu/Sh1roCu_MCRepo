package studio.fantasyit.tour_guide.client.gui;

import net.minecraft.class_1735;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import studio.fantasyit.tour_guide.client.IGuiMarkRenderer;
import studio.fantasyit.tour_guide.mark.gui.GuiSlotMark;

public class GuiSlotMarkRenderer implements IGuiMarkRenderer<GuiSlotMark> {
    @Override
    public void render(class_332 graphics, GuiSlotMark mark, class_437 screen) {
        if (screen instanceof class_465<?> containerScreen && containerScreen.method_17577().field_7761.size() > mark.id()) {
            class_1735 slot = containerScreen.method_17577().method_7611(mark.id());
            int thickness = 3;
            graphics.method_25294(slot.field_7873, slot.field_7872, slot.field_7873 + thickness, slot.field_7872 + 18, mark.color());
            graphics.method_25294(slot.field_7873, slot.field_7872, slot.field_7873 + 18, slot.field_7872 + thickness, mark.color());
            graphics.method_25294(slot.field_7873 + 18 - thickness, slot.field_7872, slot.field_7873 + 18, slot.field_7872 + 18, mark.color());
            graphics.method_25294(slot.field_7873, slot.field_7872 + 18 - thickness, slot.field_7873 + 18, slot.field_7872 + 18, mark.color());
        }
    }
}
