package studio.fantasyit.tour_guide.network;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public class Network {

    @Environment(EnvType.CLIENT)
    public static void registerS2CPackets() {
        ClientPlayNetworking.registerGlobalReceiver(S2CUpdateTourGuideData.ID, S2CUpdateTourGuideData::handle);
        ClientPlayNetworking.registerGlobalReceiver(S2CSyncTriggerableItems.ID, S2CSyncTriggerableItems::handle);
        ClientPlayNetworking.registerGlobalReceiver(S2CTipMessage.ID, S2CTipMessage::handle);
    }

    public static void registerC2SPackets() {
        ServerPlayNetworking.registerGlobalReceiver(C2SRequestTriggerableItems.ID,C2SRequestTriggerableItems::handle);
        ServerPlayNetworking.registerGlobalReceiver(C2SStartTourGuide.ID,C2SStartTourGuide::handle);
        ServerPlayNetworking.registerGlobalReceiver(C2SInteractTourGuideData.ID,C2SInteractTourGuideData::handle);
        ServerPlayNetworking.registerGlobalReceiver(C2SClientTrigger.ID,C2SClientTrigger::handle);
    }
}
