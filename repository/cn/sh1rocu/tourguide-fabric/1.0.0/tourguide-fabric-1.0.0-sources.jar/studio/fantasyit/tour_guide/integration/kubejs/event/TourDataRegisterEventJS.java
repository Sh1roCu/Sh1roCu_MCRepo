package studio.fantasyit.tour_guide.integration.kubejs.event;

import dev.latvian.mods.kubejs.event.EventJS;
import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.api.TourDataManager;
import studio.fantasyit.tour_guide.data.ITourDataFactory;

public class TourDataRegisterEventJS extends EventJS {
    public void register(class_2960 id, ITourDataFactory tourData) {
        TourDataManager.register(id, tourData);
    }
}
