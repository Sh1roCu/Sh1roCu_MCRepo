package studio.fantasyit.tour_guide.client.screen_predicator;

import cn.sh1rocu.tour_guide.mixin.accessor.AbstractContainerScreenAccessor;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.tour_guide.mark.ServerScreenPredicatorMarks;
import studio.fantasyit.tour_guide.screen.BlockHoldKeyScreen;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Predicate;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_465;

public class ScreenPredicatorAndTransformer {
    private static final Map<class_2960, BiConsumer<class_437, class_332>> SCREEN_GRAPHICS_TRANSFORMERS = new HashMap<>(Map.of(
            ServerScreenPredicatorMarks.ALL, (screen, graphics) -> {
                if (screen instanceof class_465<?> containerScreen) {
                    graphics.method_51448().method_46416(
                            ((AbstractContainerScreenAccessor) containerScreen).tour_guide$getGuiLeft(),
                            ((AbstractContainerScreenAccessor) containerScreen).tour_guide$getGuiTop(),
                            0
                    );
                }
            },
            ServerScreenPredicatorMarks.NO_GUI, (screen, graphics) -> {
            }
    ));
    private static final Map<class_2960, Predicate<@Nullable class_437>> SCREEN_PREDICATORS = new HashMap<>(Map.of(
            ServerScreenPredicatorMarks.ALL, screen -> true,
            ServerScreenPredicatorMarks.NO_GUI, screen -> screen == null || screen instanceof class_408 || screen instanceof BlockHoldKeyScreen
    ));

    public static boolean predicate(class_2960 _id, class_437 screen) {
        class_2960 id = ServerScreenPredicatorMarks.base(_id);
        if (SCREEN_PREDICATORS.containsKey(id))
            return SCREEN_PREDICATORS.get(id).test(screen);
        return false;
    }

    public static void transform(class_2960 id, class_437 screen, class_332 graphics) {
        if (ServerScreenPredicatorMarks.isNoTransform(id)) {
            return;
        }
        if (SCREEN_GRAPHICS_TRANSFORMERS.containsKey(id))
            SCREEN_GRAPHICS_TRANSFORMERS.get(id).accept(screen, graphics);
        else
            SCREEN_GRAPHICS_TRANSFORMERS.get(ServerScreenPredicatorMarks.ALL).accept(screen, graphics);
    }

    public static void register(class_2960 id, Predicate<class_437> predicate) {
        SCREEN_PREDICATORS.put(id, predicate);
    }

    public static void register(class_2960 id, BiConsumer<class_437, class_332> transformer) {
        SCREEN_GRAPHICS_TRANSFORMERS.put(id, transformer);
    }
}
