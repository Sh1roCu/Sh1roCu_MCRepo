package studio.fantasyit.tour_guide.network;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_7923;
import oshi.util.tuples.Pair;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.data.ItemTourGuide;

import java.util.ArrayList;
import java.util.List;

public class S2CSyncTriggerableItems {

    public static final class_2960 ID = new class_2960(TourGuide.MODID, "s2c_sync_triggerable_items");

    public static class_2540 toNetwork(List<Pair<class_2960, class_2960>> items) {
        class_2540 buf = PacketByteBufs.create();
        buf.method_34062(items, (t, u) -> {
            t.method_10812(u.getA());
            t.method_10812(u.getB());
        });
        return buf;
    }

    @Environment(EnvType.CLIENT)
    public static void handle(class_310 client, class_634 handler, class_2540 buf, PacketSender responseSender) {
        var items = buf.method_34068(ArrayList::new, t -> new Pair<>(t.method_10810(), t.method_10810()));
        client.execute(() -> {
            ItemTourGuide.clear();
            items.forEach(t -> {
                ItemTourGuide.register(class_7923.field_41178.method_10223(t.getA()), t.getB());
            });
        });
    }
}
