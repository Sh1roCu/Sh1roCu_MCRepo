package studio.fantasyit.tour_guide.network;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_634;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.client.ClientMessages;

public class S2CTipMessage {

    public static final class_2960 ID = new class_2960(TourGuide.MODID, "s2c_tip_msg");

    public static class_2540 toNetwork(boolean allowSkip, boolean noCondition) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeBoolean(allowSkip);
        buf.writeBoolean(noCondition);
        return buf;
    }

    @Environment(EnvType.CLIENT)
    public static void handle(class_310 client, class_634 handler, class_2540 buf, PacketSender responseSender) {
        boolean allowSkip = buf.readBoolean();
        boolean noCondition = buf.readBoolean();
        client.execute(() -> ClientMessages.sendOp(allowSkip, noCondition));
    }
}
