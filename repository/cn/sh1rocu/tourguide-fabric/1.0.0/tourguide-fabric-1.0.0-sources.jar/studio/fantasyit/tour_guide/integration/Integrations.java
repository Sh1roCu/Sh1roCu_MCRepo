package studio.fantasyit.tour_guide.integration;

import net.fabricmc.loader.api.FabricLoader;

public class Integrations {
    public static boolean kjs() {
        return FabricLoader.getInstance().isModLoaded("kubejs");
    }
}
