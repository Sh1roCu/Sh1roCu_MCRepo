package studio.fantasyit.tour_guide.step;

import java.util.function.Function;
import net.minecraft.class_2960;

public record TourStepId<T>(class_2960 id, Function<Object, T> caster) {
    public TourStepId(class_2960 id, Class<T> caster) {
        this(id, t -> {
            if (t.getClass().equals(caster))
                return caster.cast(t);
            return null;
        });
    }

    public T cast(Object obj) {
        if (obj == null)
            return null;
        try {
            return caster.apply(obj);
        } catch (Exception e) {
            return null;
        }
    }
}
