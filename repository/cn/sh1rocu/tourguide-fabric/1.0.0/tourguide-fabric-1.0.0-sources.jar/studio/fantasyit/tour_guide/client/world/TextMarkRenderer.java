package studio.fantasyit.tour_guide.client.world;

import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_761;
import studio.fantasyit.tour_guide.client.IWorldMarkRenderer;
import studio.fantasyit.tour_guide.mark.world.TextMark;

public class TextMarkRenderer implements IWorldMarkRenderer<TextMark>, ITextLikeRenderer {
    @Override
    public void render(class_4597 source, class_761 levelRenderer, class_4587 poseStack, class_4184 camera, float partialTicks, TextMark mark, Context context) {
        drawText(poseStack, partialTicks, class_310.method_1551(), camera, mark.pos(), mark.text(), mark.color(), 0);
    }
}
