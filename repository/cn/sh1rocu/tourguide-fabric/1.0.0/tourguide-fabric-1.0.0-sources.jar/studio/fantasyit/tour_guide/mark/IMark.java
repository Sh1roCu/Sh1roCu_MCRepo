package studio.fantasyit.tour_guide.mark;

import net.minecraft.class_2960;

public interface IMark {
    class_2960 getId();
}
