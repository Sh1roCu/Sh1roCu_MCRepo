package studio.fantasyit.tour_guide.client.gui;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.tour_guide.client.IGuiMarkRenderer;
import studio.fantasyit.tour_guide.mark.gui.GuiTextMark;

public class GuiTextMarkRenderer implements IGuiMarkRenderer<GuiTextMark> {
    @Override
    public void render(class_332 graphics, GuiTextMark mark, @Nullable class_437 screen) {
        int height = class_310.method_1551().field_1772.method_1728(mark.text(), mark.width()).size() * (class_310.method_1551().field_1772.field_2000 + 2);
        graphics.method_25294(mark.x() - 2, mark.y() - 2, mark.x() + mark.width() + 2, mark.y() + height + 2, mark.background());
        graphics.method_51440(class_310.method_1551().field_1772, mark.text(), mark.x(), mark.y(), mark.width(), mark.color());
    }
}
