package studio.fantasyit.tour_guide.client.event;

import net.minecraft.class_310;
import studio.fantasyit.tour_guide.api.event.ClientMarkRendererRegisterEvent;
import studio.fantasyit.tour_guide.api.event.ScreenPredicatorRegisterEvent;
import studio.fantasyit.tour_guide.integration.Integrations;
import studio.fantasyit.tour_guide.integration.kubejs.KubeJSPort;

public class SetupEvent {

    public static void onSetup(class_310 client) {
        ClientMarkRendererRegisterEvent.EVENT.invoker().post(new ClientMarkRendererRegisterEvent());
        ScreenPredicatorRegisterEvent.EVENT.invoker().post(new ScreenPredicatorRegisterEvent());
        if (Integrations.kjs())
            KubeJSPort.setupClient();
    }
}
