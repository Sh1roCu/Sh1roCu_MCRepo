package studio.fantasyit.tour_guide.api;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_3222;
import studio.fantasyit.tour_guide.network.C2SClientTrigger;

import java.util.Optional;

public class TourGuideTrigger {
    public static void trigger(class_3222 player, String key) {
        trigger(player, key, null);
    }

    public static void trigger(class_3222 player, String key, Object data) {
        Optional.ofNullable(TourManager.get(player)).ifPresent(t -> t.receiveTrigger(key, data));
    }

    public static void trigger(String key) {
        trigger(key, null);
    }

    public static void trigger(String key, Object data) {
        TourManager.each(
                t -> t.receiveTrigger(key, data)
        );
    }

    public static void triggerClient(String key) {
        ClientPlayNetworking.send(C2SClientTrigger.ID, C2SClientTrigger.toNetwork(key));
    }
}
