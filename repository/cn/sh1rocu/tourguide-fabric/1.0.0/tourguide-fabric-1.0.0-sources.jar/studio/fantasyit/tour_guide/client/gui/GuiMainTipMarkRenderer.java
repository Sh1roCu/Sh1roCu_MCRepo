package studio.fantasyit.tour_guide.client.gui;

import cn.sh1rocu.tour_guide.mixin.accessor.AbstractContainerScreenAccessor;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import studio.fantasyit.tour_guide.client.IGuiMarkRenderer;
import studio.fantasyit.tour_guide.client.counter.ClientQuitCounter;
import studio.fantasyit.tour_guide.client.event.ClientInputEvent;
import studio.fantasyit.tour_guide.mark.ServerScreenPredicatorMarks;
import studio.fantasyit.tour_guide.mark.gui.GuiMainTipMark;

public class GuiMainTipMarkRenderer implements IGuiMarkRenderer<GuiMainTipMark> {
    private static final int COLOR = 0x60666666;
    private static final int FILL = 0x60000000;
    private static final int thickness = 3;
    private static final int x = 5;
    private static final int y = 5;
    private static final int _width = 160;

    @Override
    public void render(class_332 graphics, GuiMainTipMark mark, class_437 screen) {
        class_2561 keyTip;
        if (ClientQuitCounter.isPressingQuitKey()) {
            keyTip = class_2561.method_43469("gui.tour_guide.key_tip_quit",
                    ClientQuitCounter.getPressingProgressBar()
            );
        } else if (ClientInputEvent.pressingShiftKey) {
            keyTip = class_2561.method_43469("gui.tour_guide.key_tip_shift",
                    KeyBindingHelper.getBoundKeyOf(ClientInputEvent.KEY_CHECK_STEP).method_27445()
            );
        } else {
            keyTip = mark.canSkip() ?
                    class_2561.method_43469("gui.tour_guide.key_tip",
                           KeyBindingHelper.getBoundKeyOf(ClientInputEvent.KEY_CHECK_STEP).method_27445(),
                            KeyBindingHelper.getBoundKeyOf(ClientInputEvent.KEY_SKIP).method_27445(),
                            KeyBindingHelper.getBoundKeyOf(ClientInputEvent.KEY_QUIT).method_27445()
                    ) :
                    class_2561.method_43469("gui.tour_guide.key_tip_no_skip",
                           KeyBindingHelper.getBoundKeyOf(ClientInputEvent.KEY_CHECK_STEP).method_27445(),
                           KeyBindingHelper.getBoundKeyOf(ClientInputEvent.KEY_QUIT).method_27445()
                    );
        }

        int width = Math.max(class_310.method_1551().field_1772.method_27525(keyTip) + 2 * thickness, _width);
        if (screen instanceof class_465<?> containerScreen && ServerScreenPredicatorMarks.isNoTransform(mark.screenPredicate())) {
            graphics.method_51448().method_46416(((AbstractContainerScreenAccessor)containerScreen).tour_guide$getGuiLeft() + ((float) (((AbstractContainerScreenAccessor) containerScreen).tour_guide$getXSize() - width) / 2), 0, 0);
        }
        int height = class_310.method_1551().field_1772.method_1728(mark.text(), width - thickness * 2 - 4).size() * (class_310.method_1551().field_1772.field_2000 + 2) + 2 * thickness;
        graphics.method_25294(x, y, x + thickness, y + height, COLOR);
        graphics.method_25294(x + width - thickness, y, x + width, y + height, COLOR);
        graphics.method_25294(x + thickness, y, x + width - thickness, y + thickness, COLOR);
        graphics.method_25294(x + thickness, y + height - thickness, x + width - thickness, y + height, COLOR);
        graphics.method_25294(x + thickness, y + thickness, x + width - thickness, y + height - thickness, FILL);
        graphics.method_51440(class_310.method_1551().field_1772, mark.text(), x + thickness + 2, y + thickness + 2, width - thickness * 2 - 4, 0xFFFFFFFF);
        graphics.method_25294(x, y + height, x + width, y + height + class_310.method_1551().field_1772.field_2000 + 2, COLOR);
        graphics.method_27534(class_310.method_1551().field_1772,
                keyTip,
                x + width / 2,
                y + height + 1,
                0xFFFFFFFF);
    }
}
