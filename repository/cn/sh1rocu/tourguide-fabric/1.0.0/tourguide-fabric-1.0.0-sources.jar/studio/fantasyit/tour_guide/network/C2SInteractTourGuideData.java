package studio.fantasyit.tour_guide.network;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_124;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.api.TourManager;
import studio.fantasyit.tour_guide.data.TourData;

public class C2SInteractTourGuideData {

    public static final class_2960 ID = new class_2960(TourGuide.MODID, "c2s_interact_tour_guide");

    public enum Type {
        DONE,
        QUIT,
        SKIP,
        BACK
    }

    public static class_2540 toNetwork(Type type) {
        class_2540 buf = PacketByteBufs.create();
        buf.method_10817(type);
        return buf;
    }

    public static void handle(MinecraftServer server, class_3222 player, class_3244 handler, class_2540 buf, PacketSender responseSender) {
        var type = buf.method_10818(Type.class);
        server.execute(() -> {
            if (player == null) {
                return;
            }
            TourData tourData = TourManager.get(player);
            if (tourData == null) {
                return;
            }
            try {
                switch (type) {
                    case DONE -> tourData.doneAndTryNextStep();
                    case SKIP -> tourData.skipAndTryNextStep();
                    case QUIT -> tourData.terminate();
                    case BACK -> tourData.goPrevStep();
                }
            } catch (Exception e) {
                player.method_43496(class_2561.method_43470(e.getMessage()).method_27692(class_124.field_1061));
            }
        });
    }
}
