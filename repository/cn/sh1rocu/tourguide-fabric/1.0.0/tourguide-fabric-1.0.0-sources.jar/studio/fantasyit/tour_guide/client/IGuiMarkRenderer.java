package studio.fantasyit.tour_guide.client;

import net.minecraft.class_332;
import net.minecraft.class_437;

public interface IGuiMarkRenderer<T> {
    void render(class_332 graphics, T mark, class_437 screen);
}
