package studio.fantasyit.tour_guide.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.mark.ContextMarkSerializer;

public class CommonMarkSerializerRegisterEvent {

    public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.post(event);
        }
    });

    public void register(class_2960 id, ContextMarkSerializer.NetworkSerializer<?> mark) {
        ContextMarkSerializer.register(id, mark);
    }

    public interface Callback {
        void post(CommonMarkSerializerRegisterEvent event);
    }
}
