package studio.fantasyit.tour_guide.data;

import net.minecraft.class_2960;
import net.minecraft.class_3222;

public interface ITourDataFactory {
    TourData create(class_3222 player, class_2960 id);
}
