package studio.fantasyit.tour_guide.client.world;

import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

public interface ITextLikeRenderer {
    default void drawText(class_4587 pose, float partialTicks, class_310 mc, class_4184 camera, class_243 livingFrom, class_2561 text, int textColor, float floatingTransform) {
        class_243 fromPos = mc.field_1724.method_5836(partialTicks);
        class_243 posFromPlayer = fromPos.method_1035(livingFrom);
        pose.method_22903();
        pose.method_22904(posFromPlayer.field_1352, posFromPlayer.field_1351, posFromPlayer.field_1350);
        pose.method_46416(0, floatingTransform, 0);
        pose.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
        pose.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        pose.method_22905(-0.025f, -0.025f, -1f);
        pose.method_46416(-mc.field_1772.method_27525(text) / 2f, 0, 0);
//            guiGraphics.drawString(mc.font, key, 0, 0, textColor);
        mc.field_1772.method_30882(text,
                0,
                0,
                textColor,
                mc.field_1772.method_1726(),
                pose.method_23760().method_23761(),
                mc.method_22940().method_23000(),
                class_327.class_6415.field_33993,
                0,
                15728880);
        mc.method_22940().method_23000().method_22993();
        pose.method_22909();
    }
}
