package studio.fantasyit.tour_guide.api.helper;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.tour_guide.data.TourData;
import studio.fantasyit.tour_guide.mark.IMark;
import studio.fantasyit.tour_guide.mark.ServerScreenPredicatorMarks;
import studio.fantasyit.tour_guide.mark.gui.GuiMainTipMark;
import studio.fantasyit.tour_guide.network.S2CTipMessage;
import studio.fantasyit.tour_guide.step.ITourStepData;
import studio.fantasyit.tour_guide.step.TourStepId;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class TourStepBuilder<T> {
    private final TourDataBuilder builder;
    private TourStepId<T> id;
    private List<class_2561> chat = null;
    private BiConsumer<List<class_2561>, TourData> dynamicChats = null;

    private List<IMark> marks = null;
    private BiConsumer<List<IMark>, TourData> dynamicMarks = null;

    private boolean allowSkip = false;
    private boolean noCondition = false;

    private Function<TourData, class_2561> unfinishReason = null;
    private Function<TourData, T> finishCb = null;
    private Consumer<TourData> skippedCb = null;

    private Consumer<TourData> initCb = null;

    private Predicate<TourData> autoSkip = null;

    private List<String> triggers = null;
    private Predicate<String> triggerPredicate = null;
    private class_2561 mainTip = null;
    private Function<TourData, T> toGetData = null;
    private class_2561 onNoData = null;
    private boolean finishOnTriggerAndGetData = false;
    private class_2960 guiTipScreen = null;
    private class_2561 guiTip = null;

    public TourStepBuilder(TourDataBuilder builder, TourStepId<T> id) {
        this.builder = builder;
        this.id = id;
    }

    public TourStepBuilder() {
        this.builder = null;
    }


    public TourStepBuilder<T> chat(class_2561 chat) {
        this.chat = List.of(chat);
        return this;
    }

    public TourStepBuilder<T> chats(List<class_2561> chat) {
        this.chat = chat;
        return this;
    }

    public TourStepBuilder<T> dynamicChats(BiConsumer<List<class_2561>, TourData> dynamicChats) {
        this.dynamicChats = dynamicChats;
        return this;
    }

    public TourStepBuilder<T> mainTipNoGui(class_2561 tip) {
        this.mainTip = tip;
        return this;
    }

    public TourStepBuilder<T> mainTip(class_2561 tipNoGui, class_2960 screenPredicate, class_2561 tipGui) {
        this.mainTip = tipGui;
        this.guiTipScreen = screenPredicate;
        this.guiTip = tipNoGui;
        return this;
    }

    public TourStepBuilder<T> marks(List<IMark> marks) {
        this.marks = marks;
        return this;
    }

    public TourStepBuilder<T> dynamicMarks(BiConsumer<List<IMark>, TourData> dynamicMarks) {
        this.dynamicMarks = dynamicMarks;
        return this;
    }

    public TourStepBuilder<T> allowSkip(boolean allowSkip) {
        this.allowSkip = allowSkip;
        return this;
    }

    public TourStepBuilder<T> unfinishReason(Function<TourData, class_2561> unfinishReason) {
        this.unfinishReason = unfinishReason;
        return this;
    }

    public TourStepBuilder<T> onFinish(Function<TourData, T> finishCb) {
        this.finishCb = finishCb;
        return this;
    }

    public TourStepBuilder<T> onSkipped(Consumer<TourData> skippedCb) {
        this.skippedCb = skippedCb;
        return this;
    }

    public TourStepBuilder<T> onInit(Consumer<TourData> initCb) {
        this.initCb = initCb;
        return this;
    }

    public TourStepBuilder<T> autoSkip(Predicate<TourData> autoSkip) {
        this.autoSkip = autoSkip;
        return this;
    }

    public TourStepBuilder<T> triggers(List<String> triggers) {
        this.triggers = triggers;
        return this;
    }

    public TourStepBuilder<T> triggerPredicate(Predicate<String> triggerPredicate) {
        this.triggerPredicate = triggerPredicate;
        return this;
    }

    public TourStepBuilder<T> withToGetData(Function<TourData, T> dataGetter, class_2561 onNoData) {
        this.toGetData = dataGetter;
        this.onNoData = onNoData;
        return this;
    }

    public TourStepBuilder<T> noCondition(boolean noCondition) {
        this.noCondition = noCondition;
        return this;
    }

    public TourStepBuilder<T> finishOnTriggerAndGetData(boolean finishOnTriggerAndGetData, class_2561 onNoData) {
        this.finishOnTriggerAndGetData = finishOnTriggerAndGetData;
        this.onNoData = onNoData;
        return this;
    }

    public ITourStepData<T> build() {
        return new ITourStepData<T>() {
            T tData = null;

            @Override
            public TourStepId<T> getId() {
                return id;
            }

            @Override
            public @Nullable List<class_2561> getChatText(TourData data) {
                if (dynamicChats == null && chat == null)
                    return null;
                ArrayList<class_2561> tChat = new ArrayList<>();
                if (chat != null)
                    tChat.addAll(chat);
                if (dynamicChats != null)
                    dynamicChats.accept(tChat, data);
                return tChat;
            }

            @Override
            public List<IMark> init(TourData data) {
                if (initCb != null)
                    initCb.accept(data);
                if (dynamicMarks == null && marks == null && mainTip == null)
                    return List.of();
                ArrayList<IMark> tMarks = new ArrayList<>();
                if (mainTip != null)
                    tMarks.add(new GuiMainTipMark(ServerScreenPredicatorMarks.NO_GUI, mainTip, allowSkip));
                if (guiTip != null && guiTipScreen != null)
                    tMarks.add(new GuiMainTipMark(guiTipScreen, guiTip, allowSkip));
                if (marks != null)
                    tMarks.addAll(marks);
                if (dynamicMarks != null)
                    dynamicMarks.accept(tMarks, data);
                return tMarks;
            }

            @Override
            public @Nullable class_2561 getUnfinishReason(TourData data) {
                class_2561 d = null;
                if (unfinishReason != null)
                    d = unfinishReason.apply(data);
                if (d == null && toGetData != null && toGetData.apply(data) == null)
                    d = onNoData;
                if (d == null && tData == null && finishOnTriggerAndGetData && onNoData != null)
                    d = onNoData;
                return d;
            }

            @Override
            public T finish(TourData data) {
                T d = null;
                if (finishCb != null)
                    d = finishCb.apply(data);
                if (tData != null)
                    return tData;
                if (toGetData != null)
                    return toGetData.apply(data);
                return d;
            }

            @Override
            public boolean allowSkip() {
                return allowSkip;
            }

            @Override
            public void skipped(TourData data) {
                if (skippedCb != null)
                    skippedCb.accept(data);
            }

            @Override
            public boolean shouldSkipAtStart(TourData data) {
                return autoSkip != null && autoSkip.test(data);
            }

            @Override
            public void sendExtraTip(TourData tourData) {
                ServerPlayNetworking.send(tourData.getPlayer(), S2CTipMessage.ID, S2CTipMessage.toNetwork(allowSkip(), noCondition));
            }

            @Override
            public boolean receiveTrigger(String key, Object data) {
                boolean f = false;
                if (triggerPredicate != null && triggerPredicate.test(key))
                    f = true;
                if (triggers != null && triggers.contains(key))
                    f = true;
                if (f && finishOnTriggerAndGetData) {
                    tData = id.cast(data);
                }
                return f;
            }
        };
    }

    public TourDataBuilder add() {
        if (builder == null)
            throw new RuntimeException("TourStepBuilder must be added to TourDataBuilder");
        builder.add(build());
        return builder;
    }
}
