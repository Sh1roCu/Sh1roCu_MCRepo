package studio.fantasyit.tour_guide.client.event;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_310;
import studio.fantasyit.tour_guide.client.MarkRendererManager;
import studio.fantasyit.tour_guide.client.TourGuidingClientData;

public class LevelRenderingEvent {

    public static void onLevelRender(WorldRenderContext context) {
        TourGuidingClientData.getMarks().forEach(mark ->
                MarkRendererManager.dispatchWorldRender(
                mark,
                class_310.method_1551().method_22940().method_23000(),
                context.camera(),
                context.worldRenderer(),
                context.matrixStack(),
                context.tickDelta()
        ));
    }
}
