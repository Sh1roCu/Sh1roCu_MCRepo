package studio.fantasyit.tour_guide.mark;

import studio.fantasyit.tour_guide.mark.gui.GuiMainTipMark;
import studio.fantasyit.tour_guide.mark.gui.GuiRectMark;
import studio.fantasyit.tour_guide.mark.gui.GuiSlotMark;
import studio.fantasyit.tour_guide.mark.gui.GuiTextMark;
import studio.fantasyit.tour_guide.mark.world.BlockMark;
import studio.fantasyit.tour_guide.mark.world.EntityMark;
import studio.fantasyit.tour_guide.mark.world.TextMark;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Function;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

public class ContextMarkSerializer {
    public static <T> NetworkSerializer<T> of(Function<class_2540, T> reader, BiConsumer<T, class_2540> writer) {
        return new NetworkSerializer<T>() {
            @Override
            public T read(class_2540 buf) {
                return reader.apply(buf);
            }

            @Override
            public void write(T obj, class_2540 buf) {
                writer.accept(obj, buf);
            }
        };
    }

    public interface NetworkSerializer<T> {
        T read(class_2540 buf);

        void write(T obj, class_2540 buf);
    }

    public static final Map<class_2960, NetworkSerializer<?>> SERIALIZER_MAP = new HashMap<>();

    public static <T> void register(class_2960 id, NetworkSerializer<T> serializer) {
        SERIALIZER_MAP.put(id, serializer);
    }

    @SuppressWarnings("unchecked")
    public static <T extends IMark> void serialize(class_2540 buf, T obj) {
        buf.method_10812(obj.getId());
        ((NetworkSerializer<T>) (SERIALIZER_MAP.get(obj.getId()))).write(obj, buf);
    }

    @SuppressWarnings("unchecked")
    public static <T> T deserialize(class_2540 buf) {
        class_2960 id = buf.method_10810();
        return (T) SERIALIZER_MAP.get(id).read(buf);
    }

    static {
        register(GuiTextMark.ID, of(GuiTextMark::fromNetwork, GuiTextMark::toNetwork));
        register(GuiSlotMark.ID, of(GuiSlotMark::fromNetwork, GuiSlotMark::toNetwork));
        register(GuiRectMark.ID, of(GuiRectMark::fromNetwork, GuiRectMark::toNetwork));
        register(GuiMainTipMark.ID, of(GuiMainTipMark::fromNetwork, GuiMainTipMark::toNetwork));
        register(TextMark.ID, of(TextMark::fromNetwork, TextMark::toNetwork));
        register(BlockMark.ID, of(BlockMark::fromNetwork, BlockMark::toNetwork));
        register(EntityMark.ID, of(EntityMark::fromNetwork, EntityMark::toNetwork));
    }
}
