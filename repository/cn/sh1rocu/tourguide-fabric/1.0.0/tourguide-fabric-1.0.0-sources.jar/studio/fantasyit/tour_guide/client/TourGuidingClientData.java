package studio.fantasyit.tour_guide.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import studio.fantasyit.tour_guide.mark.IMark;

import java.util.List;

@Environment(EnvType.CLIENT)
public class TourGuidingClientData {
    static List<IMark> marks = List.of();

    public static void setMarks(List<IMark> _marks) {
        marks = _marks;
    }

    public static List<IMark> getMarks() {
        return marks;
    }

    public static void clear() {
        marks.clear();
    }
}
