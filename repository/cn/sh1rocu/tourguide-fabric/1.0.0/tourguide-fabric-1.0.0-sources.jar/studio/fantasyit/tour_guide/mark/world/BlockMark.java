package studio.fantasyit.tour_guide.mark.world;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.tour_guide.TourGuide;
import studio.fantasyit.tour_guide.mark.IMark;

public record BlockMark(class_2338 pos, @Nullable class_2350 face, int color, class_2561 text) implements IMark {

    public static final class_2960 ID = new class_2960(TourGuide.MODID, "block");
    @Override
    public class_2960 getId() {
        return ID;
    }

    public static BlockMark fromNetwork(class_2540 buf) {
        return new BlockMark(buf.method_10811(), buf.readBoolean() ? buf.method_10818(class_2350.class) : null, buf.readInt(), buf.method_10808());
    }

    public void toNetwork(class_2540 buf) {
        buf.method_10807(pos);
        buf.writeBoolean(face != null);
        if (face != null) buf.method_10817(face);
        buf.writeInt(color);
        buf.method_10805(text);
    }
}