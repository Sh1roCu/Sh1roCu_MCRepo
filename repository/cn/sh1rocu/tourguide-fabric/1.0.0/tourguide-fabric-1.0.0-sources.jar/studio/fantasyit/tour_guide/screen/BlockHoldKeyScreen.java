package studio.fantasyit.tour_guide.screen;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class BlockHoldKeyScreen extends class_437 {
    public BlockHoldKeyScreen() {
        super(class_2561.method_43473());
    }

    @Override
    public void method_25394(class_332 p_281549_, int p_281550_, int p_282878_, float p_282465_) {
    }

    @Override
    public void method_25420(class_332 p_283688_) {
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
