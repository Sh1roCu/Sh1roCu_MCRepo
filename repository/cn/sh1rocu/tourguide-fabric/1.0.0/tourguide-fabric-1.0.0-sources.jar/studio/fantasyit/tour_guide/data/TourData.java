package studio.fantasyit.tour_guide.data;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;
import studio.fantasyit.tour_guide.api.TourManager;
import studio.fantasyit.tour_guide.mark.IMark;
import studio.fantasyit.tour_guide.network.S2CUpdateTourGuideData;
import studio.fantasyit.tour_guide.step.ITourStepData;
import studio.fantasyit.tour_guide.step.TourStepId;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TourData {
    private final class_3222 player;
    private final List<ITourStepData<?>> steps;
    private final Map<class_2960, Object> data;
    private final class_2960 id;
    private Runnable onStart;
    private Runnable onFinish;

    private ITourStepData<?> currentStep = null;
    private int currentStepIndex = -1;

    public TourData(List<ITourStepData<?>> steps, class_2960 id, class_3222 player) {
        this.id = id;
        this.steps = steps;
        this.data = new HashMap<>();
        this.player = player;
    }


    public List<ITourStepData<?>> getSteps() {
        return steps;
    }

    public void doneAndTryNextStep() {
        if (currentStep == null)
            throw new IllegalStateException("TourData is not started");
        class_2561 unfinishReason = currentStep.getUnfinishReason(this);
        if (unfinishReason != null) {
            player.method_43496(unfinishReason);
            return;
        }
        data.put(currentStep.getId().id(), currentStep.finish(this));
        tryNextStep();
    }

    public void tryNextStep() {
        currentStepIndex++;
        if (currentStepIndex >= steps.size()) {
            currentStepIndex = steps.size();
            currentStep = null;
            stop();
            return;
        }
        currentStep = steps.get(currentStepIndex);
        startCurrentAndSync();
    }

    public void start() {
        player.method_43496(class_2561.method_43469("message.tour_guide.start", class_2561.method_43471("tour.tour_guide." + id.method_42094())).method_27692(class_124.field_1060));
        if (onStart != null) {
            onStart.run();
        }
        tryNextStep();
    }

    public boolean isFinished() {
        return currentStepIndex >= steps.size();
    }

    public void receiveTrigger(String key, Object d) {
        if (currentStep != null && currentStep.receiveTrigger(key, d) && currentStep.checkIfFinished(this)) {
            doneAndTryNextStep();
        }
    }

    public void skipAndTryNextStep() {
        if (currentStep == null)
            throw new IllegalStateException("TourData is not started");
        if (!currentStep.allowSkip()) {
            player.method_43496(class_2561.method_43471("message.tour_guide.cannot_skip").method_27692(class_124.field_1054));
            return;
        }
        currentStep.skipped(this);
        tryNextStep();
    }


    public void startCurrentAndSync() {
        if (currentStep == null)
            throw new IllegalStateException("TourData is not started");
        List<IMark> init = currentStep.init(this);
        @Nullable List<class_2561> chats = currentStep.getChatText(this);
        player.method_43496(class_2561.method_43469("message.tour_guide.step",
                class_2561.method_43471("tour." + id.method_42094())
                , currentStepIndex + 1, steps.size()).method_27692(class_124.field_1080));
        if (chats != null) {
            for (class_2561 chat : chats) {
                player.method_43496(class_2561.method_43471("message.tour_guide.prefix").method_10852(chat));
            }
        }
        currentStep.sendExtraTip(this);
        ServerPlayNetworking.send(player, S2CUpdateTourGuideData.ID, S2CUpdateTourGuideData.toNetwork(init));
    }

    public void stop() {
        if (onFinish != null)
            onFinish.run();
        player.method_43496(class_2561.method_43471("message.tour_guide.end").method_27692(class_124.field_1060));
        terminate();
    }

    public void terminate() {
        ServerPlayNetworking.send(player, S2CUpdateTourGuideData.ID, S2CUpdateTourGuideData.toNetwork(List.of()));
        TourManager.remove(player);
    }


    public TourData setOnStart(Runnable onStart) {
        this.onStart = onStart;
        return this;
    }

    public TourData setOnFinish(Runnable onFinish) {
        this.onFinish = onFinish;
        return this;
    }

    public <T> T getDataById(class_2960 id) {
        return (T) data.get(id);
    }

    public <T> T getData(TourStepId<T> id) {
        return getDataById(id.id());
    }

    public class_3222 getPlayer() {
        return player;
    }

    public void goPrevStep() {
        if (currentStepIndex <= 0)
            return;
        currentStepIndex--;
        currentStep = steps.get(currentStepIndex);
        startCurrentAndSync();
    }
}
