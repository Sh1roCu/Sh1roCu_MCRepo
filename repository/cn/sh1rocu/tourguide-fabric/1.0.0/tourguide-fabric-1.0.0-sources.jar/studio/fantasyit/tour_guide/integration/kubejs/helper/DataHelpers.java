package studio.fantasyit.tour_guide.integration.kubejs.helper;

import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;

public class DataHelpers {
    public static DataHelpers INSTANCE = new DataHelpers();

    public long rgba2argb(int r, int g, int b, int a) {
        return ((long) a << 24) | ((long) r << 16) | ((long) g << 8) | b;
    }

    public long argb(int a, int r, int g, int b) {
        return ((long) a << 24) | ((long) r << 16) | ((long) g << 8) | b;
    }


    public long hex2argb(long hex) {
        return hex;
    }

    public <T> List<T> list(T[] arr) {
        return List.of(arr);
    }


    public class_2338 pos(int x, int y, int z) {
        return new class_2338(x, y, z);
    }

    public class_243 vec(double x, double y, double z) {
        return new class_243(x, y, z);
    }

    public class_2561 text(String text) {
        return class_2561.method_43470(text);
    }

    public class_2561 textA(String text, Object... args) {
        return class_2561.method_43469(text, args);
    }

    public class_2561 translatable(String key) {
        return class_2561.method_43471(key);
    }

    public class_2561 translatableA(String key, Object... args) {
        return class_2561.method_43469(key, args);
    }
}
