package studio.fantasyit.tour_guide.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import studio.fantasyit.tour_guide.data.ItemTourGuide;

public class ItemTourGuideRegisterEvent {

    public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.post(event);
        }
    });

    public void register(class_2960 id, class_1792... items) {
        for (class_1792 item : items) {
            ItemTourGuide.register(item, id);
        }
    }

    public interface Callback {
        void post(ItemTourGuideRegisterEvent event);
    }
}
