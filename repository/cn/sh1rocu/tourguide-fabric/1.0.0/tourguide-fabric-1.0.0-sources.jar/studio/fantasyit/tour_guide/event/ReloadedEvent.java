package studio.fantasyit.tour_guide.event;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_5455;
import studio.fantasyit.tour_guide.api.TourDataManager;
import studio.fantasyit.tour_guide.data.ItemTourGuide;
import studio.fantasyit.tour_guide.network.C2SRequestTriggerableItems;

public class ReloadedEvent {

    public static void onReloaded(class_5455 registries, boolean client) {
        TourDataManager.clearAndBroadcastRegister();
        if (!client) {
            ItemTourGuide.clearAndBroadcastRegister();
        } else {
            ClientPlayNetworking.send(C2SRequestTriggerableItems.ID, C2SRequestTriggerableItems.INSTANCE);
        }
    }
}
