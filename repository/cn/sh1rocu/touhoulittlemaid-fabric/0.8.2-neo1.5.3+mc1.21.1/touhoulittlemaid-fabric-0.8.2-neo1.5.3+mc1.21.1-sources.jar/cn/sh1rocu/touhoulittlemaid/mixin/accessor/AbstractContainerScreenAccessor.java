package cn.sh1rocu.touhoulittlemaid.mixin.accessor;

import net.minecraft.class_1735;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_465.class)
public interface AbstractContainerScreenAccessor {
    @Accessor("hoveredSlot")
    class_1735 tlm$getSlotUnderMouse();
}
