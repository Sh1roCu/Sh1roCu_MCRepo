package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.api.event.EntityJoinLevelEvent;
import cn.sh1rocu.touhoulittlemaid.api.extension.IEntity;
import net.minecraft.class_1297;
import net.minecraft.class_5568;
import net.minecraft.class_5579;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5579.class)
public class PersistentEntitySectionManagerMixin<T extends class_5568> {
    @Inject(method = "addEntity", at = @At("HEAD"), cancellable = true)
    public void tlm$entityJoinLevelEvent(T entityAccess, boolean loadedFromDisk, CallbackInfoReturnable<Boolean> cir) {
        if (entityAccess instanceof class_1297 entity) {
            EntityJoinLevelEvent event = new EntityJoinLevelEvent(entity, entity.method_37908(), loadedFromDisk);
            EntityJoinLevelEvent.CALLBACK.invoker().post(event);
            if (event.isCanceled())
                cir.setReturnValue(false);
        }
    }

    // method_31857: processPendingLoads.11
    // method_31863: addWorldGenChunkEntities.1
    // method_31864: addLegacyChunkEntities.0
    @Inject(method = {"method_31857", "method_31863", "method_31864"}, at = @At("TAIL"))
    private void tlm$addedToWorld(class_5568 entityAccess, CallbackInfo ci) {
        if (entityAccess instanceof IEntity entity)
            entity.onAddedToLevel();
    }
}