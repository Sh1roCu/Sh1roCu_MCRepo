package cn.sh1rocu.touhoulittlemaid.util.itemhandler.entity;

import net.minecraft.class_1304;
import net.minecraft.class_1309;

public class EntityArmorInvWrapper extends EntityEquipmentInvWrapper {
    public EntityArmorInvWrapper(final class_1309 entity) {
        super(entity, class_1304.class_1305.field_6178);
    }
}