package cn.sh1rocu.touhoulittlemaid.mixin.client;

import com.github.tartaricacid.touhoulittlemaid.api.entity.IMaid;
import com.github.tartaricacid.touhoulittlemaid.client.entity.GeckoMaidEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1297.class)
public class EntityMixin {
    @Inject(method = "<init>", at = @At("TAIL"))
    private void init(CallbackInfo ci) {
        var self = (class_1297) (Object) this;
        if (self.method_37908().method_8608() && self instanceof class_1308 mob && !mob.hasAttached(GeckoMaidEntity.TYPE)) {
            IMaid maid = IMaid.convert(mob);
            if (maid != null) {
                mob.setAttached(GeckoMaidEntity.TYPE, new GeckoMaidEntity<>(mob, maid));
            }
        }
    }
}
