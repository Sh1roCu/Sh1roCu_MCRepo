package cn.sh1rocu.touhoulittlemaid.mixin.accessor;

import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_1703.class})
public interface AbstractContainerMenuAccessor {
    @Accessor("lastSlots")
    class_2371<class_1799> tlm$lastSlots();

    @Accessor("remoteSlots")
    class_2371<class_1799> tlm$remoteSlots();
}
