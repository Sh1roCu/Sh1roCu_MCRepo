package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.api.event.ExplosionEvents;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

@Mixin(class_1927.class)
public class ExplosionMixin {
    @Shadow
    @Final
    private class_1937 level;

    @Inject(method = "explode", at = @At(value = "NEW", target = "net/minecraft/world/phys/Vec3", ordinal = 1), locals = LocalCapture.CAPTURE_FAILHARD)
    public void tlm$onExplode(CallbackInfo ci, Set<class_2338> blocks, int i, float j, int k, int l, int d, int q, int e, int r, List<class_1297> list) {
        ExplosionEvents.DETONATE.invoker().onDetonate(this.level, (class_1927) (Object) this, list, j);
    }
}