package cn.sh1rocu.touhoulittlemaid.util.transfer;

import net.fabricmc.fabric.api.transfer.v1.item.base.SingleStackStorage;
import net.minecraft.class_1799;

public class ItemStackStorage extends SingleStackStorage {
    private class_1799 stack;

    public ItemStackStorage(class_1799 stack) {
        this.stack = stack;
    }

    @Override
    protected class_1799 getStack() {
        return stack;
    }

    @Override
    protected void setStack(class_1799 stack) {
        this.stack = stack;
    }
}
