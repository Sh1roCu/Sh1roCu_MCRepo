package com.github.tartaricacid.touhoulittlemaid.client.animation.gecko;

import com.github.tartaricacid.touhoulittlemaid.api.animation.IMagicCastingAnimationProvider;
import com.github.tartaricacid.touhoulittlemaid.api.animation.IMagicCastingState;
import com.github.tartaricacid.touhoulittlemaid.api.entity.IMaid;
import com.github.tartaricacid.touhoulittlemaid.client.animation.gecko.condition.*;
import com.github.tartaricacid.touhoulittlemaid.client.animation.gecko.magic.MagicCastingAnimationManager;
import com.github.tartaricacid.touhoulittlemaid.client.entity.GeckoMaidEntity;
import com.github.tartaricacid.touhoulittlemaid.compat.gun.common.GunClientUtil;
import com.github.tartaricacid.touhoulittlemaid.entity.item.EntityChair;
import com.github.tartaricacid.touhoulittlemaid.entity.item.EntitySit;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.MaidGameRecordManager;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.PlayState;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.builder.AnimationBuilder;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.builder.ILoopType;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.event.predicate.AnimationEvent;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.resource.GeckoLibCache;
import com.github.tartaricacid.touhoulittlemaid.network.message.MaidAnimationPackage;
import it.unimi.dsi.fastutil.objects.ReferenceArrayList;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import java.util.Objects;

public final class AnimationManager {
    private static AnimationManager MANAGER;
    @SuppressWarnings("unchecked")
    private final ReferenceArrayList<AnimationState>[] data = new ReferenceArrayList[Priority.LOWEST + 1];

    public AnimationManager() {
        for (int i = 0; i < data.length; i++) {
            data[i] = new ReferenceArrayList<>(6);
        }
    }

    public static AnimationManager getInstance() {
        if (MANAGER == null) {
            MANAGER = new AnimationManager();
        }
        return MANAGER;
    }

    @Nonnull
    public static PlayState playLoopAnimation(AnimationEvent<?> event, String animationName) {
        return playAnimation(event, animationName, ILoopType.EDefaultLoopTypes.LOOP);
    }

    @Nonnull
    private static PlayState playAnimation(AnimationEvent<?> event, String animationName, ILoopType loopType) {
        event.getController().setAnimation(new AnimationBuilder().addAnimation(animationName, loopType));
        return PlayState.CONTINUE;
    }

    @Nonnull
    private static PlayState playAnimation(AnimationEvent<?> event, String animationName) {
        event.getController().setAnimation(new AnimationBuilder().addAnimation(animationName));
        return PlayState.CONTINUE;
    }

    public void register(AnimationState state) {
        data[state.getPriority()].add(state);
    }

    public PlayState predicateParallel(AnimationEvent<?> event, String animationName) {
        if (class_310.method_1551().method_1493()) {
            return PlayState.STOP;
        }
        return playLoopAnimation(event, animationName);
    }

    @NotNull
    public PlayState predicateMain(AnimationEvent<GeckoMaidEntity<?>> event) {
        IMaid maid = event.getAnimatableEntity().getMaid();
        if (maid == null) {
            return PlayState.STOP;
        }
        for (int i = Priority.HIGHEST; i <= Priority.LOWEST; i++) {
            // 载具动画单独检查
            if (i == Priority.HIGH) {
                PlayState vehicleAnimation = getVehicleAnimation(event);
                if (vehicleAnimation != null) {
                    return vehicleAnimation;
                }
            }
            for (AnimationState state : data[i]) {
                if (state.getPredicate().test(maid, event)) {
                    String animationName = state.getAnimationName();
                    ILoopType loopType = state.getLoopType();
                    PlayState gunMainAnimation = GunClientUtil.playGunMainAnimation(maid, event, animationName, loopType);
                    return Objects.requireNonNullElseGet(gunMainAnimation, () -> playAnimation(event, animationName, loopType));
                }
            }
        }
        return PlayState.STOP;
    }

    public PlayState predicateOffhandHold(AnimationEvent<GeckoMaidEntity<?>> event) {
        IMaid maid = event.getAnimatableEntity().getMaid();
        if (maid == null) {
            return PlayState.STOP;
        }
        class_1308 entity = maid.asEntity();
        if (!entity.field_6252 && !entity.method_6115()) {
            class_1799 offhandItem = entity.method_5998(class_1268.field_5810);
            if (offhandItem.method_31574(class_1802.field_8399) && class_1764.method_7781(offhandItem)) {
                return playAnimation(event, "hold_offhand:charged_crossbow", ILoopType.EDefaultLoopTypes.LOOP);
            }
        }
        if (checkSwingAndUse(maid, class_1268.field_5810)) {
            class_1799 offhandItem = entity.method_5998(class_1268.field_5810);
            if (!isSameItem(maid, offhandItem, class_1268.field_5810)) {
                maid.getHandItemsForAnimation()[class_1268.field_5810.ordinal()] = offhandItem;
                playAnimation(event, "empty", ILoopType.EDefaultLoopTypes.LOOP);
            }

            class_2960 id = event.getAnimatableEntity().getAnimationFileLocation();
            ConditionalHold conditionalHold = ConditionManager.getHoldOffhand(id);
            if (conditionalHold != null) {
                String name = conditionalHold.doTest(maid, class_1268.field_5810);
                if (StringUtils.isNoneBlank(name)) {
                    return playAnimation(event, name, ILoopType.EDefaultLoopTypes.LOOP);
                }
            }
        }
        return PlayState.STOP;
    }

    public PlayState predicateMainhandHold(AnimationEvent<GeckoMaidEntity<?>> event) {
        IMaid maid = event.getAnimatableEntity().getMaid();
        if (maid == null) {
            return PlayState.STOP;
        }
        if (!maid.asEntity().field_6252 && !maid.asEntity().method_6115()) {
            class_1799 mainHandItem = maid.asEntity().method_5998(class_1268.field_5808);
            PlayState gunHoldAnimation = GunClientUtil.playGunHoldAnimation(mainHandItem, event);
            if (gunHoldAnimation != null) {
                return gunHoldAnimation;
            }
            if (mainHandItem.method_31574(class_1802.field_8399) && class_1764.method_7781(mainHandItem)) {
                return playAnimation(event, "hold_mainhand:charged_crossbow", ILoopType.EDefaultLoopTypes.LOOP);
            }
            if (maid.hasFishingHook()) {
                return playAnimation(event, "hold_mainhand:fishing", ILoopType.EDefaultLoopTypes.LOOP);
            }
        }

        if (checkSwingAndUse(maid, class_1268.field_5808)) {
            class_1799 mainHandItem = maid.asEntity().method_5998(class_1268.field_5808);
            if (!isSameItem(maid, mainHandItem, class_1268.field_5808)) {
                maid.getHandItemsForAnimation()[class_1268.field_5808.ordinal()] = mainHandItem;
                playAnimation(event, "empty", ILoopType.EDefaultLoopTypes.LOOP);
            }

            class_2960 id = event.getAnimatableEntity().getAnimationFileLocation();
            ConditionalHold conditionalHold = ConditionManager.getHoldMainhand(id);
            if (conditionalHold != null) {
                String name = conditionalHold.doTest(maid, class_1268.field_5808);
                if (StringUtils.isNoneBlank(name)) {
                    return playAnimation(event, name, ILoopType.EDefaultLoopTypes.LOOP);
                }
            }
        }
        return PlayState.STOP;
    }

    private boolean isSameItem(IMaid maid, class_1799 maidItem, class_1268 hand) {
        class_1799 preItem = maid.getHandItemsForAnimation()[hand.ordinal()];
        if (preItem.method_7986()) {
            return class_1799.method_7984(maidItem, preItem);
        }
        return class_1799.method_7973(maidItem, preItem);
    }

    public PlayState predicateSwing(AnimationEvent<GeckoMaidEntity<?>> event) {
        IMaid maid = event.getAnimatableEntity().getMaid();
        if (maid == null) {
            return PlayState.STOP;
        }
        if (maid.asEntity().field_6252 && !maid.asEntity().method_6113()) {
            if (maid.asEntity().field_6279 == 0) {
                // 空动画用于重置 PLAY_ONCE 动画
                playAnimation(event, "empty", ILoopType.EDefaultLoopTypes.PLAY_ONCE);
            }
            class_2960 id = event.getAnimatableEntity().getAnimationFileLocation();
            ConditionalSwing conditionalSwing = (maid.asEntity().field_6266 == class_1268.field_5808) ? ConditionManager.getSwingMainhand(id) : ConditionManager.getSwingOffhand(id);
            if (conditionalSwing != null) {
                String name = conditionalSwing.doTest(maid, maid.asEntity().field_6266);
                if (StringUtils.isNoneBlank(name)) {
                    return playAnimation(event, name, ILoopType.EDefaultLoopTypes.PLAY_ONCE);
                }
            }
            String defaultSwing = (maid.asEntity().field_6266 == class_1268.field_5808) ? "swing_hand" : "swing_offhand";
            return playAnimation(event, defaultSwing, ILoopType.EDefaultLoopTypes.PLAY_ONCE);
        }
        return PlayState.CONTINUE;
    }

    public PlayState predicateUse(AnimationEvent<GeckoMaidEntity<?>> event) {
        IMaid maid = event.getAnimatableEntity().getMaid();
        if (maid == null) {
            return PlayState.STOP;
        }
        if (maid.asEntity().method_6115() && !maid.asEntity().method_6113()) {
            if (maid.asEntity().method_6048() == 1) {
                playAnimation(event, "empty", ILoopType.EDefaultLoopTypes.PLAY_ONCE);
            }
            if (maid.asEntity().method_6058() == class_1268.field_5808) {
                class_2960 id = event.getAnimatableEntity().getAnimationFileLocation();
                ConditionalUse conditionalUse = ConditionManager.getUseMainhand(id);
                if (conditionalUse != null) {
                    String name = conditionalUse.doTest(maid, class_1268.field_5808);
                    if (StringUtils.isNoneBlank(name)) {
                        return playAnimation(event, name, ILoopType.EDefaultLoopTypes.LOOP);
                    }
                }
                return playAnimation(event, "use_mainhand", ILoopType.EDefaultLoopTypes.LOOP);
            } else {
                class_2960 id = event.getAnimatableEntity().getAnimationFileLocation();
                ConditionalUse conditionalUse = ConditionManager.getUseOffhand(id);
                if (conditionalUse != null) {
                    String name = conditionalUse.doTest(maid, class_1268.field_5810);
                    if (StringUtils.isNoneBlank(name)) {
                        return playAnimation(event, name, ILoopType.EDefaultLoopTypes.LOOP);
                    }
                }
                return playAnimation(event, "use_offhand", ILoopType.EDefaultLoopTypes.LOOP);
            }
        }
        return PlayState.STOP;
    }

    public PlayState predicateMisc(AnimationEvent<GeckoMaidEntity<?>> event) {
        IMaid maid = event.getAnimatableEntity().getMaid();
        if (maid == null) {
            return PlayState.STOP;
        }
        // 赢棋输棋优先
        if (maid instanceof EntityMaid entityMaid && entityMaid.method_5854() instanceof EntitySit) {
            MaidGameRecordManager manager = entityMaid.getGameRecordManager();
            if (manager.isWin()) {
                return playAnimation(event, "game_win", ILoopType.EDefaultLoopTypes.LOOP);
            }
            if (manager.isLost()) {
                return playAnimation(event, "game_lost", ILoopType.EDefaultLoopTypes.LOOP);
            }
        }
        // 祈求动画
        if (maid.isBegging()) {
            return playAnimation(event, "beg", ILoopType.EDefaultLoopTypes.LOOP);
        }
        // 其他杂项动画，目前仅捡雪球
        if (maid instanceof EntityMaid entityMaid) {
            if (entityMaid.animationId == MaidAnimationPackage.PICK_UP_SNOWBALL) {
                // 捡雪球动画默认 1750 毫秒
                if (System.currentTimeMillis() - entityMaid.animationRecordTime > 1750) {
                    entityMaid.animationId = MaidAnimationPackage.NONE;
                    entityMaid.animationRecordTime = -1L;
                    // 利用空动画重置 PLAY_ONCE 动画
                    return playAnimation(event, "empty", ILoopType.EDefaultLoopTypes.PLAY_ONCE);
                }
                return playAnimation(event, "pick_up_snowball", ILoopType.EDefaultLoopTypes.PLAY_ONCE);
            }
        }
        return PlayState.STOP;
    }

    public <T extends class_1308> PlayState predicateArmor(AnimationEvent<GeckoMaidEntity<T>> event, class_1304 slot) {
        IMaid maid = event.getAnimatableEntity().getMaid();
        if (maid == null) {
            return PlayState.STOP;
        }
        class_1799 itemBySlot = maid.asEntity().method_6118(slot);
        if (itemBySlot.method_7960()) {
            return PlayState.STOP;
        }

        class_2960 id = event.getAnimatableEntity().getAnimationFileLocation();
        ConditionArmor conditionArmor = ConditionManager.getArmor(id);
        if (conditionArmor != null) {
            String name = conditionArmor.doTest(maid, slot);
            if (StringUtils.isNoneBlank(name)) {
                return playAnimation(event, name, ILoopType.EDefaultLoopTypes.LOOP);
            }
        }

        class_2960 animation = event.getAnimatableEntity().getAnimationFileLocation();
        String defaultName = slot.method_5923() + ":default";
        if (GeckoLibCache.getInstance().getAnimations().get(animation).animations().containsKey(defaultName)) {
            return playAnimation(event, defaultName, ILoopType.EDefaultLoopTypes.LOOP);
        }
        return PlayState.STOP;
    }

    @Nullable
    public PlayState getVehicleAnimation(AnimationEvent<GeckoMaidEntity<?>> event) {
        class_1308 mob = event.getAnimatableEntity().getMaid().asEntity();
        if (mob == null) {
            return null;
        }
        class_1297 vehicle = mob.method_5854();
        if (vehicle == null || !vehicle.method_5805()) {
            return null;
        }
        class_2960 id = event.getAnimatableEntity().getAnimationFileLocation();

        // 如果是坐垫
        if (vehicle instanceof EntityChair) {
            ConditionalChair conditionalChair = ConditionManager.getChair(id);
            if (conditionalChair != null) {
                String name = conditionalChair.doTest(mob);
                if (StringUtils.isNoneBlank(name)) {
                    return playAnimation(event, name, ILoopType.EDefaultLoopTypes.LOOP);
                }
            }
        }

        // 其他情况
        ConditionalVehicle vehicleCondition = ConditionManager.getVehicle(id);
        if (vehicleCondition != null) {
            String name = vehicleCondition.doTest(mob);
            if (StringUtils.isNoneBlank(name)) {
                return playAnimation(event, name, ILoopType.EDefaultLoopTypes.LOOP);
            }
        }
        return null;
    }

    public PlayState predicatePassengerAnimation(AnimationEvent<GeckoMaidEntity<?>> event) {
        class_1308 mob = event.getAnimatableEntity().getMaid().asEntity();
        if (mob == null) {
            return PlayState.STOP;
        }
        class_1297 passenger = mob.method_31483();
        if (passenger == null || !passenger.method_5805()) {
            return PlayState.STOP;
        }

        class_2960 id = event.getAnimatableEntity().getAnimationFileLocation();
        ConditionalPassenger conditionalPassenger = ConditionManager.getPassenger(id);
        if (conditionalPassenger != null) {
            String name = conditionalPassenger.doTest(mob);
            if (StringUtils.isNoneBlank(name)) {
                return playAnimation(event, name, ILoopType.EDefaultLoopTypes.LOOP);
            }
        }
        return PlayState.STOP;
    }

    public PlayState predicateMagicCastingAnimation(AnimationEvent<GeckoMaidEntity<?>> event) {
        IMaid maid = event.getAnimatableEntity().getMaid();
        if (maid == null) {
            return PlayState.STOP;
        }
        var controller = event.getController();
        var geckoEntity = event.getAnimatableEntity();
        var lastPhase = geckoEntity.getLastCastingPhase();

        // 遍历所有注册的提供器，按优先级顺序
        for (IMagicCastingAnimationProvider provider : MagicCastingAnimationManager.getProviders()) {
            IMagicCastingState state = provider.getMagicCastingState(maid);

            // 如果咏唱被取消，跳过当前提供器，检查下一个
            if (state != null && state.isCancelled()) {
                // 清理取消标记，避免提供器没有清除状态
                state.setCancelled(false);
                continue;
            }

            // 获取当前 phase
            var currentPhase = (state != null) ? state.getCurrentPhase() : IMagicCastingState.CastingPhase.NONE;

            // 检查状态是否有效
            if (currentPhase == IMagicCastingState.CastingPhase.NONE) {
                // 当前 phase 为 NONE，检查是否需要让动画播放完毕
                // 从 INSTANT 或 END 过渡到 NONE 时，继续播放直到动画结束
                if ((lastPhase == IMagicCastingState.CastingPhase.INSTANT || lastPhase == IMagicCastingState.CastingPhase.END)
                        && controller.getAnimationState() != com.github.tartaricacid.touhoulittlemaid.geckolib3.core.AnimationState.STOPPED) {
                    return PlayState.CONTINUE;
                }
                // 从 START 或 CASTING 过渡到 NONE 时，允许终止
                geckoEntity.setLastCastingPhase(IMagicCastingState.CastingPhase.NONE);
                continue;
            }

            // 更新 lastPhase
            geckoEntity.setLastCastingPhase(currentPhase);

            // 尝试获取自定义动画
            AnimationBuilder builder = provider.getAnimationBuilder(maid, state);
            if (builder != null) {
                if (lastPhase != IMagicCastingState.CastingPhase.START && lastPhase != IMagicCastingState.CastingPhase.CASTING) {
                    controller.markNeedsReload();
                }
                controller.setAnimation(builder);
                return PlayState.CONTINUE;
            }

            // builder 为 null，但 phase 有效，继续播放当前动画
            if (controller.getAnimationState() != com.github.tartaricacid.touhoulittlemaid.geckolib3.core.AnimationState.STOPPED) {
                return PlayState.CONTINUE;
            }
        }

        // 没有任何附属提供有效的动画
        geckoEntity.setLastCastingPhase(IMagicCastingState.CastingPhase.NONE);
        controller.clearAnimationCache();
        return PlayState.STOP;
    }

    private boolean checkSwingAndUse(IMaid maid, class_1268 hand) {
        if (maid.asEntity().field_6252 && maid.asEntity().field_6266 == hand) {
            return false;
        }
        return !maid.asEntity().method_6115() || maid.asEntity().method_6058() != hand;
    }
}