package com.github.tartaricacid.touhoulittlemaid.client.animation.gecko.condition;

import com.github.tartaricacid.touhoulittlemaid.api.entity.IMaid;
import com.github.tartaricacid.touhoulittlemaid.item.ItemHakureiGohei;
import net.minecraft.class_1268;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1819;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_4537;
import net.minecraft.world.item.*;

public class InnerClassify {
    private static final String EMPTY = "";

    public static String doClassifyTest(String extraPre, IMaid maid, class_1268 hand) {
        class_1799 itemInHand = maid.asEntity().method_5998(hand);
        class_1792 item = itemInHand.method_7909();
        return switch (item) {
            case ItemHakureiGohei ignored -> extraPre + "gohei";
            case class_1829 ignored -> extraPre + "sword";
            case class_1743 ignored -> extraPre + "axe";
            case class_1810 ignored -> extraPre + "pickaxe";
            case class_1821 ignored -> extraPre + "shovel";
            case class_1794 ignored -> extraPre + "hoe";
            case class_1819 ignored -> extraPre + "shield";
            case class_4537 ignored -> extraPre + "throwable_potion";
            default -> EMPTY;
        };
    }
}
