package com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.ai;

import cn.sh1rocu.touhoulittlemaid.mixin.accessor.ScreenAccessor;
import com.github.tartaricacid.touhoulittlemaid.ai.manager.entity.ChatClientInfo;
import com.github.tartaricacid.touhoulittlemaid.ai.manager.entity.MaidAIChatManager;
import com.github.tartaricacid.touhoulittlemaid.ai.manager.entity.MaidAIChatSerializable;
import com.github.tartaricacid.touhoulittlemaid.ai.manager.site.ClientAvailableSitesSync;
import com.github.tartaricacid.touhoulittlemaid.ai.service.llm.DefaultLLMSite;
import com.github.tartaricacid.touhoulittlemaid.ai.service.llm.LLMMessage;
import com.github.tartaricacid.touhoulittlemaid.ai.service.llm.Role;
import com.github.tartaricacid.touhoulittlemaid.ai.service.tts.SupportLanguage;
import com.github.tartaricacid.touhoulittlemaid.ai.service.tts.system.TTSSystemSite;
import com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button.FlatColorButton;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.network.message.SendUserChatPackage;
import com.github.tartaricacid.touhoulittlemaid.network.message.ai.OpenAIConfigPacket;
import com.github.tartaricacid.touhoulittlemaid.network.message.ai.SaveMaidAIDataPackage;
import com.google.common.collect.Lists;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import net.minecraft.class_746;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.github.tartaricacid.touhoulittlemaid.ai.manager.entity.MaidAIChatSerializable.NO_TTS_SITE;

public class AIChatScreen extends class_437 {
    private static final int POPUP_ROW_HEIGHT = 16;

    private final EntityMaid maid;
    private final MaidAIChatManager manager;

    private int currentTokens = 0;
    private int maxTokens = Integer.MAX_VALUE;

    private class_342 input;

    private FlatColorButton configButton;
    private FlatColorButton historyButton;
    private FlatColorButton settingButton;

    private FlatColorButton llmButton;
    private FlatColorButton ttsButton;
    private FlatColorButton langButton;

    private PopupType openPopup;
    private int popupScrollOffset;
    private @Nullable PopupGeometry popupGeometry;

    private int inputHistoryIndex;

    /**
     * 用来禁止快捷键打开时，会把快捷键输入到聊天框里的问题<br>
     * 开屏后前几帧不处理输入
     */
    private int tickCounter = 0;

    public AIChatScreen(EntityMaid maid) {
        super(class_2561.method_43470("Maid AI Chat Screen"));
        this.maid = maid;
        this.manager = maid.getAiChatManager();
    }

    public void updateTokens(int current, int max) {
        this.currentTokens = current;
        this.maxTokens = max;
    }

    @Override
    protected void method_25426() {
        String currentInput = this.input != null ? this.input.method_1882() : StringUtils.EMPTY;
        this.method_37067();

        int posX = this.field_22789 / 2;
        int posY = this.field_22790 / 2;

        int inputX = posX - 165;
        int inputY = posY + 58;
        int inputWidth = 330;

        // 添加聊天输入框
        this.addInputWidget(inputX, inputY, inputWidth, currentInput);
        // 模型存在判定
        this.ensureValidSelections();

        // 添加上侧配置按钮
        int y = inputY - 28, size = 18, gap = 2;
        this.addLeftButtons(inputX - 8, y, size, gap);
        this.addRightButtons(inputX + inputWidth - size * 3 + gap * 2, y, size, gap);
        // 刷新下拉框相关内容的状态
        this.refreshSelectorButtons();
    }

    private void addInputWidget(int inputX, int inputY, int inputWidth, String currentInput) {
        this.input = new class_342(Screens.getClient(this).field_39924, inputX, inputY, inputWidth, 20, class_2561.method_43471("chat.editBox"));
        this.input.method_1880(128);
        this.input.method_1858(false);
        this.input.method_1852(currentInput);
        this.input.method_1856(false);

        this.method_25429(this.input);
        this.method_48265(this.input);
        this.inputHistoryIndex = 0;
    }

    private void addLeftButtons(int leftX, int y, int size, int gap) {
        this.historyButton = this.method_37063(new FlatColorButton(leftX, y, size, size, class_2561.method_43470("🕑"), b -> {
            HistoryAIChatScreen screen = new HistoryAIChatScreen(this, this.maid);
            Screens.getClient(this).method_1507(screen);
        }).setTooltips("ai.touhou_little_maid.chat.button.history.tip"));

        leftX = leftX + size + gap;
        this.settingButton = this.method_37063(new FlatColorButton(leftX, y, size, size, class_2561.method_43470("✎"), b -> {
            SettingEditScreen editScreen = new SettingEditScreen(this, this.maid);
            Screens.getClient(this).method_1507(editScreen);
        }).setTooltips("ai.touhou_little_maid.chat.button.setting.tip"));

        leftX = leftX + size + gap;
        this.configButton = this.method_37063(new FlatColorButton(leftX, y, size, size, class_2561.method_43470("⚙"), b -> {
            OpenAIConfigPacket.sendToServer();
        }).setTooltips("ai.touhou_little_maid.chat.button.config.tip"));
    }

    private void addRightButtons(int rightX, int y, int size, int gap) {
        this.llmButton = this.method_37063(new FlatColorButton(rightX, y, size, size, class_2561.method_43470("✦"),
                b -> this.togglePopup(PopupType.LLM)).setTooltips("ai.touhou_little_maid.chat.button.llm.tip"));

        rightX = rightX + size + gap;
        this.ttsButton = this.method_37063(new FlatColorButton(rightX, y, size, size, class_2561.method_43470("🔊"),
                b -> this.togglePopup(PopupType.TTS)).setTooltips("ai.touhou_little_maid.chat.button.tts.tip"));

        rightX = rightX + size + gap;
        this.langButton = this.method_37063(new FlatColorButton(rightX, y, size, size, class_2561.method_43470("🌐"),
                b -> this.togglePopup(PopupType.LANGUAGE)).setTooltips("ai.touhou_little_maid.chat.button.language.tip"));
    }

    private void togglePopup(PopupType type) {
        if (this.openPopup == type) {
            // 类型相同，说明是二次点击，关闭
            this.openPopup = null;
        } else {
            this.openPopup = type;
        }
        this.refreshSelectorButtons();
    }

    private void refreshSelectorButtons() {
        this.llmButton.setSelect(this.openPopup == PopupType.LLM);
        this.ttsButton.setSelect(this.openPopup == PopupType.TTS);
        this.langButton.setSelect(this.openPopup == PopupType.LANGUAGE);

        this.llmButton.field_22763 = !ClientAvailableSitesSync.getClientLLMSites().isEmpty();
        this.ttsButton.field_22763 = !this.getPopupEntries(PopupType.TTS).isEmpty();
        this.langButton.field_22763 = !SupportLanguage.SUPPORTED_LANGUAGES.isEmpty();

        if (this.openPopup == null) {
            this.popupGeometry = null;
            this.popupScrollOffset = 0;
        } else {
            this.popupGeometry = this.getPopupGeometry(this.openPopup);
            this.popupScrollOffset = this.getInitialPopupOffset(this.openPopup);
        }
    }

    private void applyPopupSelection(PopupType type, PopupEntry entry) {
        if (entry.header()) {
            return;
        }

        switch (type) {
            case LLM -> {
                this.manager.llmSite = entry.site();
                this.manager.llmModel = entry.model();
            }
            case TTS -> {
                this.manager.ttsSite = entry.site();
                this.manager.ttsModel = entry.model();
            }
            case LANGUAGE -> this.manager.ttsLanguage = entry.language();
        }

        // 验证结果，并向服务端发送确认信息
        this.ensureValidSelections();
        ClientPlayNetworking.send(new SaveMaidAIDataPackage(this.maid.method_5628(), this.manager));

        // 关闭下拉框
        this.openPopup = null;
        this.refreshSelectorButtons();
    }

    private List<PopupEntry> getPopupEntries(PopupType type) {
        List<PopupEntry> entries = Lists.newArrayList();
        if (Objects.requireNonNull(type) == PopupType.LLM) {
            var llmSites = ClientAvailableSitesSync.getClientLLMSites();
            this.addSiteModelEntries(entries, llmSites, this.manager.llmSite, this.manager.llmModel);
            return entries;
        }

        if (type == PopupType.TTS) {
            boolean selected = MaidAIChatSerializable.isNoTTSSite(this.manager.ttsSite);
            class_5250 noneName = class_2561.method_43471("ai.touhou_little_maid.chat.site.none.name");
            entries.add(new PopupEntry(noneName, false, selected, NO_TTS_SITE, StringUtils.EMPTY, null));

            var ttsSites = ClientAvailableSitesSync.getClientTTSSites();
            String selectedSite = StringUtils.isBlank(this.manager.ttsSite) ? TTSSystemSite.API_TYPE : this.manager.ttsSite;
            this.addSiteModelEntries(entries, ttsSites, selectedSite, this.manager.ttsModel);
            return entries;
        }

        SupportLanguage.SUPPORTED_LANGUAGES.forEach(language -> {
            class_2561 name = SupportLanguage.getLanguageName(language);
            boolean selected = language.equals(this.manager.ttsLanguage);
            PopupEntry entry = new PopupEntry(name, false, selected, null, null, language);
            entries.add(entry);
        });
        return entries;
    }

    private void addSiteModelEntries(List<PopupEntry> entries, Map<String, Map<String, String>> sites, String selectedSite, String selectedModel) {
        sites.forEach((site, models) -> {
            // 按站点添加主分类
            class_5250 siteName = class_2561.method_43470(site);
            PopupEntry entry = new PopupEntry(siteName, true, false, site, null, null);
            entries.add(entry);

            // 如果模型为空，添加占位符
            if (models == null || models.isEmpty()) {
                boolean selected = site.equals(selectedSite) && StringUtils.isBlank(selectedModel);
                class_5250 name = class_2561.method_43470("*");
                PopupEntry popupEntry = new PopupEntry(name, false, selected, site, StringUtils.EMPTY, null);
                entries.add(popupEntry);
                return;
            }

            // 否则正常添加模型
            models.forEach((modelId, modelName) -> {
                class_5250 name = class_2561.method_43470(modelName);
                boolean selected = site.equals(selectedSite) && modelId.equals(selectedModel);
                PopupEntry popupEntry = new PopupEntry(name, false, selected, site, modelId, null);
                entries.add(popupEntry);
            });
        });
    }

    /**
     * 计算下拉列表第一次打开时的初始滚动偏移。
     * 目标是让当前已选中的条目尽量出现在可视范围内，
     * 如果选中项正好属于某个分组，则优先把分组标题也一起显示出来。
     */
    private int getInitialPopupOffset(PopupType type) {
        // 依据当前窗口大小，决定下拉列表的长度
        int popupMaxVisible = this.getPopupMaxVisible();

        List<PopupEntry> entries = this.getPopupEntries(type);
        if (entries.size() <= popupMaxVisible) {
            return 0;
        }
        int selectedIndex = this.getSelectedPopupIndex(entries);
        if (selectedIndex < 0) {
            return 0;
        }
        // 默认以当前选中项作为锚点，让弹窗打开时直接定位到它附近。
        int anchorIndex = selectedIndex;
        // 如果选中项前一行是分组标题，就把标题也带上，避免只看到子项看不到分组名。
        if (0 < selectedIndex && entries.get(selectedIndex - 1).header()) {
            anchorIndex = selectedIndex - 1;
        }
        return Math.max(0, Math.min(anchorIndex, entries.size() - popupMaxVisible));
    }

    private int getPopupMaxVisible() {
        return this.field_22790 / 2 / POPUP_ROW_HEIGHT;
    }

    /**
     * 在线性列表中查找第一个被选中的条目下标；找不到就返回 -1。
     */
    private int getSelectedPopupIndex(List<PopupEntry> entries) {
        for (int i = 0; i < entries.size(); i++) {
            if (entries.get(i).selected()) {
                return i;
            }
        }
        return -1;
    }

    private FlatColorButton getPopupAnchor(PopupType type) {
        return switch (type) {
            case LLM -> this.llmButton;
            case TTS -> this.ttsButton;
            case LANGUAGE -> this.langButton;
        };
    }

    private void ensureValidSelections() {
        var llmSites = ClientAvailableSitesSync.getClientLLMSites();
        var ttsSites = ClientAvailableSitesSync.getClientTTSSites();

        // 站点存在判定
        if (StringUtils.isBlank(this.manager.llmSite) || !llmSites.containsKey(this.manager.llmSite)) {
            this.manager.llmSite = this.getDefaultLLMSite(llmSites);
        }
        if (MaidAIChatSerializable.isNoTTSSite(this.manager.ttsSite)) {
            this.manager.ttsModel = StringUtils.EMPTY;
        } else if (StringUtils.isNotBlank(this.manager.ttsSite) && !ttsSites.containsKey(this.manager.ttsSite)) {
            this.manager.ttsSite = ttsSites.keySet().stream().findFirst().orElse(StringUtils.EMPTY);
        }

        // 模型存在判定
        var llmModels = llmSites.get(this.manager.llmSite);
        this.manager.llmModel = this.ensureExistingModel(llmModels, this.manager.llmModel);
        if (MaidAIChatSerializable.isNoTTSSite(this.manager.ttsSite)) {
            this.manager.ttsModel = StringUtils.EMPTY;
        } else {
            String effectiveTtsSite = StringUtils.isBlank(this.manager.ttsSite) ? TTSSystemSite.API_TYPE : this.manager.ttsSite;
            var ttsModels = ttsSites.get(effectiveTtsSite);
            this.manager.ttsModel = this.ensureExistingModel(ttsModels, this.manager.ttsModel);
        }

        // 语言存在判定
        if (SupportLanguage.SUPPORTED_LANGUAGES.isEmpty() || StringUtils.isBlank(this.manager.ttsLanguage)) {
            this.manager.ttsLanguage = "en_us";
            return;
        }
        if (!SupportLanguage.SUPPORTED_LANGUAGES.contains(this.manager.ttsLanguage)) {
            this.manager.ttsLanguage = "en_us";
        }
    }

    private String ensureExistingModel(Map<String, String> models, String current) {
        if (models == null || models.isEmpty()) {
            return StringUtils.EMPTY;
        }
        if (StringUtils.isBlank(current) || !models.containsKey(current)) {
            return models.keySet().iterator().next();
        }
        return current;
    }

    private String getDefaultLLMSite(Map<String, Map<String, String>> llmSites) {
        if (llmSites.containsKey(DefaultLLMSite.DEEPSEEK.id())) {
            return DefaultLLMSite.DEEPSEEK.id();
        }
        return llmSites.keySet().stream().findFirst().orElse(StringUtils.EMPTY);
    }

    @Override
    public void method_25410(class_310 mc, int pWidth, int pHeight) {
        String chatText = this.input.method_1882();
        super.method_25410(mc, pWidth, pHeight);
        this.input.method_1852(chatText);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
        if (this.input != null) {
            int x = this.input.method_46426();
            int y = this.input.method_46427();
            int w = this.input.method_1859();
            int h = this.input.method_25364();
            String value = this.input.method_1882();

            graphics.method_25294(x - 8, y - 8, x + w + 8, y + h - 6, 0xBF090909);
            this.input.method_25394(graphics, mouseX, mouseY, partialTicks);

            if (StringUtils.isEmpty(value)) {
                class_5250 text = class_2561.method_43471("ai.touhou_little_maid.chat.input.tip")
                        .method_27695(class_124.field_1080, class_124.field_1056);
                graphics.method_27534(this.field_22793, text, x + w / 2, y + (h - 22) / 2, 0xFFFFFF);
            }
        }

        this.renderSelectionSummaries(graphics);
        this.renderTokenUsage(graphics);

        for (class_4068 renderable : ((ScreenAccessor) this).tlm$getRenderables()) {
            renderable.method_25394(graphics, mouseX, mouseY, partialTicks);
        }

        if (this.openPopup != null) {
            this.renderPopup(graphics, mouseX, mouseY);
        } else {
            this.historyButton.renderToolTip(graphics, this, mouseX, mouseY);
            this.settingButton.renderToolTip(graphics, this, mouseX, mouseY);
            this.configButton.renderToolTip(graphics, this, mouseX, mouseY);
            this.llmButton.renderToolTip(graphics, this, mouseX, mouseY);
            this.ttsButton.renderToolTip(graphics, this, mouseX, mouseY);
            this.langButton.renderToolTip(graphics, this, mouseX, mouseY);
        }
    }

    private void renderSelectionSummaries(class_332 graphics) {
        int left = this.input.method_46426() - 6;
        int right = this.input.method_46426() + this.input.method_1859() + 6;
        int summaryY = this.input.method_46427() + 16;
        int halfWidth = (right - left) / 2;
        float scale = 0.5f;

        graphics.method_51448().method_22903();
        graphics.method_51448().method_22905(scale, scale, 1.0f);

        int scaledLeft = Math.round(left / scale);
        int scaledRight = Math.round(right / scale);
        int scaledY = Math.round(summaryY / scale);
        int scaledHalfWidth = Math.round(halfWidth / scale);

        String llmModelSummary = "%s / %s".formatted(
                StringUtils.defaultIfEmpty(this.manager.llmSite, "*"),
                ClientAvailableSitesSync.getLLMModelName(this.manager.llmSite, this.manager.llmModel)
        );
        class_5250 llmSummary = class_2561.method_43469("ai.touhou_little_maid.chat.summary.llm", llmModelSummary);
        String trimmedLeft = this.trimToWidth(llmSummary.getString(), scaledHalfWidth);
        graphics.method_25303(this.field_22793, trimmedLeft, scaledLeft, scaledY, 0xFFADADAD);

        String ttsModelSummary;
        if (MaidAIChatSerializable.isNoTTSSite(this.manager.ttsSite)) {
            ttsModelSummary = class_2561.method_43471("ai.touhou_little_maid.chat.site.none.name").getString();
        } else {
            String effectiveTtsSite = StringUtils.isBlank(this.manager.ttsSite) ? TTSSystemSite.API_TYPE : this.manager.ttsSite;
            ttsModelSummary = "%s / %s".formatted(
                    effectiveTtsSite,
                    ClientAvailableSitesSync.getTTSModelName(effectiveTtsSite, this.manager.ttsModel)
            );
        }
        class_5250 ttsSummary = class_2561.method_43469("ai.touhou_little_maid.chat.summary.tts",
                ttsModelSummary, SupportLanguage.getLanguageName(this.manager.ttsLanguage));
        String trimmedRight = this.trimToWidth(ttsSummary.getString(), scaledHalfWidth);
        int rightX = scaledRight - this.field_22793.method_1727(trimmedRight);
        graphics.method_25303(this.field_22793, trimmedRight, rightX, scaledY, 0xFFADADAD);

        graphics.method_51448().method_22909();
    }

    private void renderTokenUsage(class_332 graphics) {
        int left = this.input.method_46426() - 6;
        int right = this.input.method_46426() + this.input.method_1859() + 6;
        int tokenY = this.input.method_46427() - 14;
        float scale = 0.5f;

        String currentStr = formatTokenCount(this.currentTokens);
        String text;
        if (this.maxTokens == Integer.MAX_VALUE) {
            text = "Token: %s / ∞".formatted(currentStr);
        } else {
            String maxStr = formatTokenCount(this.maxTokens);
            double percent = this.maxTokens > 0 ? (double) this.currentTokens / this.maxTokens * 100 : 0;
            text = "Token: %s / %s (%.1f%%)".formatted(currentStr, maxStr, percent);
        }

        graphics.method_51448().method_22903();
        graphics.method_51448().method_22905(scale, scale, 1.0f);
        int scaledX = Math.round((left + right) / 2.0f / scale) - this.field_22793.method_1727(text) / 2;
        int scaledY = Math.round(tokenY / scale);
        graphics.method_51433(this.field_22793, text, scaledX, scaledY, 0xFFADADAD, false);
        graphics.method_51448().method_22909();
    }

    private static String formatTokenCount(int count) {
        if (count < 1000) {
            return String.valueOf(count);
        }
        if (count < 1_000_000) {
            return "%.1fK".formatted(count / 1000.0);
        }
        if (count < 1_000_000_000) {
            return "%.1fM".formatted(count / 1_000_000.0);
        }
        return "%.1fG".formatted(count / 1_000_000_000.0);
    }

    private String trimToWidth(String text, int maxWidth) {
        if (maxWidth <= 0 || this.field_22793.method_1727(text) <= maxWidth) {
            return text;
        }
        String ellipsis = "…";
        int trimWidth = Math.max(0, maxWidth - this.field_22793.method_1727(ellipsis));
        return this.field_22793.method_27523(text, trimWidth) + ellipsis;
    }

    @Override
    public void method_25393() {
        tickCounter++;
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (this.openPopup != null) {
            // 执行正常下拉框按钮点击
            if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT && this.tryClickPopup(mouseX, mouseY)) {
                return true;
            }

            // 如果悬浮于下拉框按钮上，正常触发开启与关闭
            if (this.isPopupTriggerHovered(mouseX, mouseY)) {
                return super.method_25402(mouseX, mouseY, button);
            }

            // 否者关闭下拉框按钮
            this.openPopup = null;
            this.refreshSelectorButtons();
        }

        // 输入框点击
        if (this.input.method_25402(mouseX, mouseY, button)) {
            this.method_25395(this.input);
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    private boolean isPopupTriggerHovered(double mouseX, double mouseY) {
        return this.isButtonHovered(this.llmButton, mouseX, mouseY)
                || this.isButtonHovered(this.ttsButton, mouseX, mouseY)
                || this.isButtonHovered(this.langButton, mouseX, mouseY);
    }

    private boolean isButtonHovered(FlatColorButton button, double mouseX, double mouseY) {
        return button != null && button.method_25405(mouseX, mouseY);
    }

    @Override
    public boolean method_25400(char pCodePoint, int pModifiers) {
        // GUI 刚打开的 5 tick 内，不允许输入，否则会把按键录入
        if (this.tickCounter < 5) {
            return false;
        }
        return super.method_25400(pCodePoint, pModifiers);
    }

    @Override
    protected void method_25415(String text, boolean overwrite) {
        if (overwrite) {
            this.input.method_1852(text);
        } else {
            this.input.method_1867(text);
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER) {
            this.sendDoneMessage();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_UP) {
            return this.recallHistory(-1);
        }
        if (keyCode == GLFW.GLFW_KEY_DOWN) {
            return this.recallHistory(1);
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalDelta, double verticalDelta) {
        if (this.openPopup == null) {
            return super.method_25401(mouseX, mouseY, horizontalDelta, verticalDelta);
        }

        if (this.popupGeometry != null && this.popupGeometry.contains(mouseX, mouseY)) {
            int maxOffset = Math.max(0, this.popupGeometry.totalCount() - this.popupGeometry.visibleCount());
            if (verticalDelta < 0 && this.popupScrollOffset < maxOffset) {
                this.popupScrollOffset++;
                return true;
            }
            if (verticalDelta > 0 && this.popupScrollOffset > 0) {
                this.popupScrollOffset--;
                return true;
            }
        }
        return super.method_25401(mouseX, mouseY, horizontalDelta, verticalDelta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private void sendDoneMessage() {
        String value = this.input.method_1882();
        class_746 player = Screens.getClient(this).field_1724;
        if (StringUtils.isNotBlank(value) && player != null) {
            ChatClientInfo clientInfo = ChatClientInfo.fromMaid(this.maid);
            ClientPlayNetworking.send(new SendUserChatPackage(this.maid.method_5628(), value, clientInfo));
            String format = "<%s> %s".formatted(player.method_5820(), value);
            player.method_43496(class_2561.method_43470(format).method_27692(class_124.field_1080));
        }
        this.method_25419();
    }

    private void renderPopup(class_332 graphics, int mouseX, int mouseY) {
        if (this.popupGeometry == null || this.popupGeometry.entries().isEmpty()) {
            return;
        }

        List<PopupEntry> entries = this.popupGeometry.entries();

        int x = this.popupGeometry.x();
        int y = this.popupGeometry.y();
        int width = this.popupGeometry.width();
        int height = this.popupGeometry.height();
        int visible = this.popupGeometry.visibleCount();
        int endIndex = Math.min(entries.size(), this.popupScrollOffset + visible);

        // 背景
        graphics.method_25294(x, y, x + width, y + height, 0xF0101010);

        // 渲染每个条目
        for (int i = this.popupScrollOffset; i < endIndex; i++) {
            PopupEntry entry = entries.get(i);
            int renderIndex = i - this.popupScrollOffset;
            int top = y + renderIndex * POPUP_ROW_HEIGHT;
            boolean hover = x <= mouseX && mouseX < x + width && top <= mouseY && mouseY < top + POPUP_ROW_HEIGHT;

            // 如果是分组标题
            if (entry.header()) {
                this.drawPopupText(graphics, entry.label().getString(), x + 6, top + 4, width - 12, 0xFFF2F2F2);
                continue;
            }

            if (entry.selected()) {
                // 如果是选中条目
                graphics.method_25294(x + 1, top + 1, x + width - 1, top + POPUP_ROW_HEIGHT - 1, 0x1F55ff55);
                graphics.method_25294(x + 1, top + 1, x + 3, top + POPUP_ROW_HEIGHT - 1, 0xFF55ff55);
            } else if (hover) {
                // 如果是悬浮条目
                graphics.method_25294(x + 1, top + 1, x + width - 1, top + POPUP_ROW_HEIGHT - 1, 0xFF3C3C3C);
            }

            int textColor = entry.selected() ? 0xFF55ff55 : hover ? 0xFFF3EFE0 : 0xFF989898;
            this.drawPopupText(graphics, entry.label().getString(), x + 12, top + 4, width - 28, textColor);
        }

        // 渲染滚动条
        if (entries.size() > visible) {
            int barX = x + width - 4;
            int thumbHeight = Math.max(10, visible * visible * POPUP_ROW_HEIGHT / entries.size());
            int scrollRange = Math.max(1, entries.size() - visible);
            int thumbOffset = (height - thumbHeight) * this.popupScrollOffset / scrollRange;
            graphics.method_25294(barX - 1, y + thumbOffset + 1, barX + 2, y + thumbOffset + thumbHeight - 1, 0xFF55ff55);
        }
    }

    private void drawPopupText(class_332 graphics, String text, int x, int y, int maxWidth, int color) {
        graphics.method_51433(this.field_22793, this.trimToWidth(text, maxWidth), x, y, color, false);
    }

    private boolean tryClickPopup(double mouseX, double mouseY) {
        if (this.popupGeometry == null || !this.popupGeometry.contains(mouseX, mouseY) || this.popupGeometry.entries().isEmpty()) {
            return false;
        }

        List<PopupEntry> entries = this.popupGeometry.entries();

        int x = this.popupGeometry.x();
        int y = this.popupGeometry.y();
        int w = this.popupGeometry.width();
        int visibleCount = this.popupGeometry.visibleCount();

        // 如果点击的是右侧滚动条，跳过
        if (entries.size() > visibleCount) {
            int scrollbarLeft = x + w - 6;
            if (mouseX >= scrollbarLeft) {
                return true;
            }
        }

        // 如果点击的索引超出范围，跳过
        int index = this.popupScrollOffset + (int) ((mouseY - y) / POPUP_ROW_HEIGHT);
        if (index < 0 || index >= entries.size()) {
            return true;
        }

        // 执行点击应用
        PopupEntry entry = entries.get(index);
        if (!entry.header()) {
            this.applyPopupSelection(this.openPopup, entry);
        }
        return true;
    }

    @Nullable
    private PopupGeometry getPopupGeometry(@Nullable PopupType type) {
        if (type == null) {
            return null;
        }

        FlatColorButton anchor = this.getPopupAnchor(type);
        List<PopupEntry> entries = this.getPopupEntries(type);
        if (anchor == null || entries.isEmpty()) {
            return null;
        }

        int popupMaxVisible = this.getPopupMaxVisible();
        int visible = Math.min(popupMaxVisible, entries.size());

        int width = this.getPopupWidth(type, anchor, entries);
        int height = visible * POPUP_ROW_HEIGHT;

        int x = anchor.method_46426() + anchor.method_25368() - width;
        int y = anchor.method_46427() - height - 4;

        // 防止超出屏幕边界
        if (x < 8) {
            x = 8;
        }
        if (x + width > this.field_22789 - 8) {
            x = this.field_22789 - 8 - width;
        }
        if (y < 8) {
            y = 8;
        }
        return new PopupGeometry(x, y, width, visible, entries);
    }

    private int getPopupWidth(PopupType type, FlatColorButton anchor, List<PopupEntry> entries) {
        int contentWidth = anchor.method_25368();
        for (PopupEntry entry : entries) {
            int rowWidth = this.field_22793.method_27525(entry.label());
            rowWidth += entry.header() ? 12 : 26;
            contentWidth = Math.max(contentWidth, rowWidth);
        }
        int minWidth = type == PopupType.LANGUAGE ? 96 : 150;
        int maxWidth = type == PopupType.LANGUAGE ? 152 : 220;
        return Math.max(minWidth, Math.min(maxWidth, contentWidth));
    }

    private boolean recallHistory(int direction) {
        List<String> history = this.getSentInputHistory();
        if (history.isEmpty()) {
            return false;
        }

        if (this.inputHistoryIndex < 0 || this.inputHistoryIndex > history.size()) {
            this.inputHistoryIndex = 0;
        }

        // 上翻历史
        if (direction < 0) {
            if (this.inputHistoryIndex < history.size() - 1) {
                this.inputHistoryIndex++;
                this.input.method_1852(history.get(this.inputHistoryIndex));
                this.input.method_1872(false);
                return true;
            }
            return false;
        }

        // 下翻历史
        if (0 < this.inputHistoryIndex) {
            this.inputHistoryIndex--;
            this.input.method_1852(history.get(this.inputHistoryIndex));
            this.input.method_1872(false);
            return true;
        }
        return false;
    }

    private List<String> getSentInputHistory() {
        // 第 0 个为当前输入项
        List<String> output = Lists.newArrayList(StringUtils.EMPTY);
        output.addAll(this.manager.getHistory()
                .getDeque().stream()
                .filter(msg -> msg.role() == Role.USER)
                .map(LLMMessage::message)
                .toList());
        return output;
    }

    public EntityMaid getMaid() {
        return maid;
    }

    /**
     * 下拉框的范围信息，包括位置、宽度和可见条目数量；
     * <p>
     * 提供一个方法用于渲染、或判断鼠标是否在范围内。
     */
    private record PopupGeometry(int x, int y, int width, int visibleCount, List<PopupEntry> entries) {
        private int height() {
            return this.visibleCount * POPUP_ROW_HEIGHT;
        }

        private int totalCount() {
            return this.entries.size();
        }

        private boolean contains(double mouseX, double mouseY) {
            return this.x <= mouseX && mouseX < this.x + this.width
                    && this.y <= mouseY && mouseY < this.y + this.height();
        }
    }

    /**
     * 用于渲染的下拉框条目
     */
    private record PopupEntry(class_2561 label, boolean header, boolean selected,
                              String site, String model, String language) {
    }

    /**
     * 下拉框类型
     */
    private enum PopupType {
        LLM,
        TTS,
        LANGUAGE
    }
}
