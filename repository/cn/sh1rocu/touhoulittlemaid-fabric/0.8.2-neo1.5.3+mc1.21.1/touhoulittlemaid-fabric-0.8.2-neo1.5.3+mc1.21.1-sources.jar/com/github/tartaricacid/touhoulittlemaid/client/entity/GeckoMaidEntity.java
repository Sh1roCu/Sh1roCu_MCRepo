package com.github.tartaricacid.touhoulittlemaid.client.entity;

import com.github.tartaricacid.touhoulittlemaid.TouhouLittleMaid;
import com.github.tartaricacid.touhoulittlemaid.api.animation.IMagicCastingState;
import com.github.tartaricacid.touhoulittlemaid.api.entity.IMaid;
import com.github.tartaricacid.touhoulittlemaid.client.animation.HardcodedAnimationManger;
import com.github.tartaricacid.touhoulittlemaid.client.animation.gecko.AnimationManager;
import com.github.tartaricacid.touhoulittlemaid.client.resource.pojo.MaidModelInfo;
import com.github.tartaricacid.touhoulittlemaid.compat.immersivemelodies.client.ImmersiveMelodiesCompat;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.AnimatableEntity;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.controller.AnimationController;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.event.predicate.AnimationEvent;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.molang.MolangParser;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.molang.context.AnimationContext;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.processor.IBone;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.geo.IGeoEntity;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.geo.animated.AnimatedGeoModel;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.geo.animated.ILocationModel;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.model.provider.data.EntityModelData;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.resource.GeckoLibCache;
import it.unimi.dsi.fastutil.objects.Object2FloatOpenHashMap;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector2f;

import java.util.List;

import static com.github.tartaricacid.touhoulittlemaid.util.ResourceLocationUtil.getResourceLocation;


@SuppressWarnings("UnstableApiUsage")
public class GeckoMaidEntity<T extends class_1308> extends AnimatableEntity<T> implements IGeoEntity {
    @SuppressWarnings("rawtypes")
    public static final AttachmentType<GeckoMaidEntity> TYPE = AttachmentRegistry.create(getResourceLocation("gecko_maid"),
            AttachmentRegistry.Builder::copyOnDeath);

    private static final class_2960 GECKO_DEFAULT_ID = class_2960.method_60655(TouhouLittleMaid.MOD_ID, "fox_miko");
    private static final class_2960 GECKO_DEFAULT_TEXTURE = class_2960.method_60655(TouhouLittleMaid.MOD_ID, "textures/entity/empty.png");
    private static final int FPS = 60;

    private final IMaid maid;
    private final Vector2f headRot = new Vector2f();
    private final MaidState<T> state;
    private MaidModelInfo maidInfo;
    private float currentTick = -1;
    private boolean modelDirty = false;

    /**
     * 沉浸式奏乐兼容数据缓存
     */
    private ImmersiveMelodiesCompat.ImmersiveMelodiesData imData = new ImmersiveMelodiesCompat.ImmersiveMelodiesData();

    /**
     * 上一次的魔法咏唱阶段，用于判断阶段过渡时的动画行为
     */
    private IMagicCastingState.CastingPhase lastCastingPhase = IMagicCastingState.CastingPhase.NONE;

    public GeckoMaidEntity(T mob, IMaid maid) {
        super(mob, FPS);
        this.maid = maid;
        this.state = new MaidState<>(mob);
        registerControllers();
    }

    public void registerControllers() {
        AnimationManager manager = AnimationManager.getInstance();
        for (int i = 0; i < 8; i++) {
            String controllerName = String.format("pre_parallel_%d_controller", i);
            String animationName = String.format("pre_parallel%d", i);
            addAnimationController(new AnimationController<>(this, controllerName, 0, e -> manager.predicateParallel(e, animationName)));
        }
        addAnimationController(new AnimationController<>(this, "main", 2, manager::predicateMain));
        addAnimationController(new AnimationController<>(this, "hold_offhand", 0, manager::predicateOffhandHold));
        addAnimationController(new AnimationController<>(this, "hold_mainhand", 0, manager::predicateMainhandHold));
        addAnimationController(new AnimationController<>(this, "swing", 2, manager::predicateSwing));
        addAnimationController(new AnimationController<>(this, "use", 2, manager::predicateUse));
        addAnimationController(new AnimationController<>(this, "magic_casting", 2, manager::predicateMagicCastingAnimation));
        addAnimationController(new AnimationController<>(this, "misc", 2, manager::predicateMisc));
        addAnimationController(new AnimationController<>(this, "passenger", 2, manager::predicatePassengerAnimation));
        for (int i = 0; i < 8; i++) {
            String controllerName = String.format("parallel_%d_controller", i);
            String animationName = String.format("parallel%d", i);
            addAnimationController(new AnimationController<>(this, controllerName, 0, e -> manager.predicateParallel(e, animationName)));
        }
        for (class_1304 slot : class_1304.values()) {
            if (slot.method_5925() == class_1304.class_1305.field_48825) {
                String controllerName = String.format("%s_controller", slot.method_5923());
                addAnimationController(new AnimationController<>(this, controllerName, 0, e -> manager.predicateArmor(e, slot)));
            }
        }
    }

    @Override
    @SuppressWarnings("all")
    public boolean setCustomAnimations(AnimationContext context, @NotNull AnimationEvent event) {
        List extraData = event.getExtraData();
        MolangParser parser = GeckoLibCache.getInstance().parser;
        if (!class_310.method_1551().method_1493() && extraData.size() == 1 && extraData.get(0) instanceof EntityModelData data) {
            var update = super.setCustomAnimations(context, event);
            AnimatedGeoModel currentModel = this.getCurrentModel();
            if (currentModel != null) {
                this.updateHead(data, currentModel, update);
                HardcodedAnimationManger.playGeckoMaidAnimation(maid, currentModel, event.getLimbSwing(), event.getLimbSwingAmount(),
                        maid.asEntity().field_6012 + event.getPartialTick(), data.netHeadYaw, data.headPitch);

                // 更新沉浸式奏乐数据
                ImmersiveMelodiesCompat.updateMelodyProgress(maid.asEntity(), imData);
            }
            return update;
        } else {
            return super.setCustomAnimations(context, event);
        }
    }

    @SuppressWarnings("all")
    private void updateHead(EntityModelData data, AnimatedGeoModel currentModel, boolean update) {
        if (currentModel.head() != null) {
            IBone head = currentModel.head();
            if (update) {
                this.headRot.set(head.getRotationX(), head.getRotationY());
            }
            head.setRotationX(this.headRot.x + (float) Math.toRadians(data.headPitch));
            head.setRotationY(this.headRot.y + (float) Math.toRadians(data.netHeadYaw));
        }
    }

    @Override
    public class_2960 getModelLocation() {
        if (this.maidInfo != null && GeckoLibCache.getInstance().getGeoModels().containsKey(this.maidInfo.getModelId())) {
            return this.maidInfo.getModelId();
        }
        return GECKO_DEFAULT_ID;
    }

    @Override
    public class_2960 getTextureLocation() {
        return this.maidInfo != null ? maidInfo.getTexture() : GECKO_DEFAULT_TEXTURE;
    }

    @Override
    public class_2960 getAnimationFileLocation() {
        if (this.maidInfo != null && GeckoLibCache.getInstance().getAnimations().containsKey(this.maidInfo.getModelId())) {
            return this.maidInfo.getModelId();
        }
        return GECKO_DEFAULT_ID;
    }

    @Override
    protected boolean forceUpdate(AnimationEvent<?> animationEvent) {
        var tick = (float) getCurrentTick(animationEvent);
        if (tick > this.currentTick) {
            this.currentTick = tick;
            this.state.updateState();
            this.modelDirty = false;
            return false;
        }
        if (this.modelDirty || !this.state.compareState()) {
            this.state.updateState();
            this.modelDirty = false;
            return true;
        }
        return false;
    }

    @Override
    public IMaid getMaid() {
        return maid;
    }

    @Override
    public MaidModelInfo getMaidInfo() {
        return maidInfo;
    }

    @Override
    public ILocationModel getGeoModel() {
        return this.getCurrentModel();
    }

    @Override
    public void setMaidInfo(MaidModelInfo info) {
        if (this.maidInfo != info) {
            this.maidInfo = info;
            this.modelDirty = true;
        }
    }

    @Override
    public void setYsmModel(String modelId, String texture) {
    }

    @Override
    public void updateRoamingVars(Object2FloatOpenHashMap<String> roamingVars) {
    }

    public ImmersiveMelodiesCompat.ImmersiveMelodiesData getImmersiveMelodiesData() {
        return imData;
    }

    public IMagicCastingState.CastingPhase getLastCastingPhase() {
        return lastCastingPhase;
    }

    public void setLastCastingPhase(IMagicCastingState.CastingPhase phase) {
        this.lastCastingPhase = phase;
    }

    private static class MaidState<T extends class_1308> {
        private final T maid;

        private float yHeadRot = 0;
        private float yBodyRot = 0;

        private MaidState(T maid) {
            this.maid = maid;
        }

        public boolean compareState() {
            if (this.yHeadRot != this.maid.field_6241 || this.yBodyRot != this.maid.field_6283) {
                return false;
            }
            return true;
        }

        public void updateState() {
            this.yHeadRot = this.maid.field_6241;
            this.yBodyRot = this.maid.field_6283;
        }
    }
}
