package com.github.tartaricacid.touhoulittlemaid.client.animation.gecko.molang.variable;

import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.molang.context.IContext;
import com.github.tartaricacid.touhoulittlemaid.geckolib3.core.util.MathUtil;
import net.minecraft.class_1297;
import net.minecraft.class_3532;

public class MoveInputVariable {
    public static double getVertical(IContext<class_1297> context) {
        class_1297 entity = context.entity();
        float partialTick = context.animationEvent().getPartialTick();

        // 求出当前移动的水平分量
        double x = class_3532.method_16436(partialTick, entity.field_6014, entity.method_23317()) - entity.field_6014;
        double z = class_3532.method_16436(partialTick, entity.field_5969, entity.method_23321()) - entity.field_5969;

        // 如果移动数值过小，那么认为没有一点，返回 0
        if (Math.sqrt(x * x + z * z) < 1.0E-4) {
            return 0;
        }

        // 计算移动角度和实体偏航角度，并作差计算出相对角度
        float moveAngleDeg = MathUtil.radiansToDegrees((float) class_3532.method_15349(z, x));
        float entityYawDeg = 90 - class_3532.method_15393(-entity.method_5705(partialTick));
        float relativeAnglesDeg = class_3532.method_15393(moveAngleDeg - entityYawDeg);

        return class_3532.method_15362(MathUtil.degreesToRadians(relativeAnglesDeg));
    }

    public static double getHorizontal(IContext<class_1297> context) {
        class_1297 entity = context.entity();
        float partialTick = context.animationEvent().getPartialTick();

        // 求出当前移动的水平分量
        double x = class_3532.method_16436(partialTick, entity.field_6014, entity.method_23317()) - entity.field_6014;
        double z = class_3532.method_16436(partialTick, entity.field_5969, entity.method_23321()) - entity.field_5969;

        // 如果移动数值过小，那么认为没有一点，返回 0
        if (Math.sqrt(x * x + z * z) < 1.0E-4) {
            return 0;
        }

        // 计算移动角度和实体偏航角度，并作差计算出相对角度
        float moveAngleDeg = MathUtil.radiansToDegrees((float) class_3532.method_15349(z, x));
        float entityYawDeg = 90 - class_3532.method_15393(-entity.method_5705(partialTick));
        float relativeAnglesDeg = class_3532.method_15393(moveAngleDeg - entityYawDeg);

        return class_3532.method_15374(MathUtil.degreesToRadians(relativeAnglesDeg));
    }
}