package com.github.tartaricacid.touhoulittlemaid.ai.agent.context.tools;

import com.github.tartaricacid.touhoulittlemaid.ai.agent.context.AbstractMaidContext;
import com.github.tartaricacid.touhoulittlemaid.ai.agent.context.GameContextRegister;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;

import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

import static com.github.tartaricacid.touhoulittlemaid.ai.manager.setting.papi.StringConstant.LIST_SEPARATORS;
import static com.github.tartaricacid.touhoulittlemaid.ai.manager.setting.papi.StringConstant.NONE;

public final class NearbyEntityMaidContexts {
    public static final String CATEGORY = "nearby_entities";
    private static final String SUMMARY = "Nearby living entities, including type, entity id, distance to self, and distance to user.";
    private static final int MAX_ENTITIES = 20;

    private NearbyEntityMaidContexts() {
    }

    public static void registerAll(GameContextRegister register) {
        register.registerCategory(CATEGORY, SUMMARY, false);
        register.registerContext(CATEGORY, new NearbyEntitiesContext());
    }

    private static final class NearbyEntitiesContext extends AbstractMaidContext {
        private NearbyEntitiesContext() {
            super("nearby_entities", "List of nearby living entities with id and distances");
        }

        @Override
        public String getValue(EntityMaid maid) {
            class_238 scanBox = maid.getTask().searchDimension(maid);
            List<class_1309> entities = maid.field_6002.method_8390(class_1309.class, scanBox, e -> e != maid && e.method_5805());

            if (entities.isEmpty()) {
                return NONE;
            }

            class_1309 owner = maid.method_35057();
            List<String> entries = Lists.newArrayList();

            entities.stream()
                    .sorted(Comparator.comparingDouble(e -> e.method_5858(maid)))
                    .limit(MAX_ENTITIES)
                    .forEach(entity -> {
                        class_2960 type = class_7923.field_41177.method_10221(entity.method_5864());
                        int id = entity.method_5628();
                        float distToMaid = maid.method_5739(entity);

                        String entry;
                        if (owner != null) {
                            entry = "%s (id=%d, dist_self=%.1f, dist_user=%.1f)".formatted(type, id, distToMaid, owner.method_5739(entity));
                        } else {
                            entry = "%s (id=%d, dist_self=%.1f)".formatted(type, id, distToMaid);
                        }

                        if (entity instanceof class_1657 player) {
                            entry = "%s[%s]".formatted(player.method_5820(), entry);
                        }

                        entries.add(entry);
                    });

            return StringUtils.join(entries, LIST_SEPARATORS);
        }
    }
}
