package com.github.tartaricacid.touhoulittlemaid.ai.agent.context.tools;

import com.github.tartaricacid.touhoulittlemaid.ai.agent.context.AbstractMaidContext;
import com.github.tartaricacid.touhoulittlemaid.ai.agent.context.GameContextRegister;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1799;

import static com.github.tartaricacid.touhoulittlemaid.ai.manager.setting.papi.StringConstant.*;

public final class EquipmentMaidContexts {
    public static final String CATEGORY = "equipment";
    private static final String SUMMARY = "Held items, backpack inventory, and equipped armor.";

    private EquipmentMaidContexts() {
    }

    public static void registerAll(GameContextRegister register) {
        register.registerCategory(CATEGORY, SUMMARY, false);
        register.registerContext(CATEGORY, new MainHandItemContext());
        register.registerContext(CATEGORY, new OffHandItemContext());
        register.registerContext(CATEGORY, new InventoryItemsContext());
        register.registerContext(CATEGORY, new ArmorItemsContext());
    }

    private static final class MainHandItemContext extends AbstractMaidContext {
        private MainHandItemContext() {
            super("mainhand_item", "Main-hand item");
        }

        @Override
        public String getValue(EntityMaid maid) {
            return getSlotItemName(class_1304.field_6173, maid);
        }
    }

    private static final class OffHandItemContext extends AbstractMaidContext {
        private OffHandItemContext() {
            super("offhand_item", "Off-hand item");
        }

        @Override
        public String getValue(EntityMaid maid) {
            return getSlotItemName(class_1304.field_6171, maid);
        }
    }

    private static final class InventoryItemsContext extends AbstractMaidContext {
        private InventoryItemsContext() {
            super("inventory_items", "Backpack items");
        }

        @Override
        public String getValue(EntityMaid maid) {
            List<String> names = Lists.newArrayList();
            var backpack = maid.getAvailableBackpackInv();
            for (int i = 0; i < backpack.getSlots(); i++) {
                class_1799 stack = backpack.getStackInSlot(i);
                if (!stack.method_7960()) {
                    String itemName = stack.method_7954().getString();
                    int count = stack.method_7947();
                    names.add(ITEM_AND_COUNT_FORMAT.formatted(itemName, count));
                }
            }
            if (names.isEmpty()) {
                return EMPTY;
            }
            return StringUtils.join(names, LIST_SEPARATORS);
        }
    }

    private static final class ArmorItemsContext extends AbstractMaidContext {
        private ArmorItemsContext() {
            super("armor_items", "Equipped armor");
        }

        @Override
        public String getValue(EntityMaid maid) {
            List<String> names = Lists.newArrayList();
            maid.method_5661().forEach(stack -> {
                if (!stack.method_7960()) {
                    String itemName = stack.method_7954().getString();
                    int count = stack.method_7947();
                    names.add(ITEM_AND_COUNT_FORMAT.formatted(itemName, count));
                }
            });
            if (names.isEmpty()) {
                return EMPTY;
            }
            return StringUtils.join(names, LIST_SEPARATORS);
        }
    }

    private static String getSlotItemName(class_1304 slot, EntityMaid maid) {
        class_1799 stack = maid.method_6118(slot);
        if (stack.method_7960()) {
            return EMPTY;
        }
        String itemName = stack.method_7954().getString();
        int count = stack.method_7947();
        return ITEM_AND_COUNT_FORMAT.formatted(itemName, count);
    }
}
