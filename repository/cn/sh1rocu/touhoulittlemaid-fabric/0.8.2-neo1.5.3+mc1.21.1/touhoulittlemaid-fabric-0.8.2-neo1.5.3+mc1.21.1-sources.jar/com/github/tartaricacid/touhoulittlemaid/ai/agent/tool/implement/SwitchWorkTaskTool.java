package com.github.tartaricacid.touhoulittlemaid.ai.agent.tool.implement;

import com.github.tartaricacid.touhoulittlemaid.ai.agent.tool.ITool;
import com.github.tartaricacid.touhoulittlemaid.ai.manager.entity.LLMCallback;
import com.github.tartaricacid.touhoulittlemaid.ai.service.function.schema.parameter.IntegerParameter;
import com.github.tartaricacid.touhoulittlemaid.ai.service.function.schema.parameter.ObjectParameter;
import com.github.tartaricacid.touhoulittlemaid.ai.service.function.schema.parameter.Parameter;
import com.github.tartaricacid.touhoulittlemaid.ai.service.function.schema.parameter.StringParameter;
import com.github.tartaricacid.touhoulittlemaid.api.task.FunctionCallSwitchResult;
import com.github.tartaricacid.touhoulittlemaid.api.task.IAttackTask;
import com.github.tartaricacid.touhoulittlemaid.api.task.IMaidTask;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.entity.task.TaskManager;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Optional;
import java.util.StringJoiner;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_4140;
import net.minecraft.class_4168;
import net.minecraft.class_5250;

public class SwitchWorkTaskTool implements ITool<SwitchWorkTaskTool.Result> {
    public static final String TOOL_ID = "switch_work_task";

    private static final String TOOL_DESC = """
            Use this when the user wants to change the current work task.
            
            For attack tasks, should first obtain the context of nearby entities, then provide the target entity id as parameter to switch immediately after switching task.
            Non attack tasks not need to provide entity id.
            
            Reply with the entity name ONLY, omit internal data (e.g., ID, distance).
            """.trim();

    private static final String TASK_ID_PARAMETER_ID = "task_id";
    private static final String ENTITY_ID_PARAMETER_ID = "entity_id";

    private static final String ENTITY_ID_PARAMETER_DESC = "Entity id of the attack target";

    private static final String SUCCESS = "Switched to task %s";
    private static final String NO_CHANGE = "Already on task %s";
    private static final String MISSING_REQUIRED = "Switched to task %s, but a required item is missing";
    private static final String PARTIAL = "Switched to task %s, but some requirements are missing";
    private static final String SCHEDULED = "Switched to task %s, but current scheduled is %s, not in work time";

    private static final String TARGET_NOT_PROVIDED = "The task switch succeeded, but no target entity id provided";
    private static final String TARGET_NOT_FOUND = "The task switch succeeded, but no living entity with id %d was found";
    private static final String TARGET_NOT_ALLOWED = "The task switch succeeded, but cannot attack %s because it is excluded by attack rules.";
    private static final String TARGET_SUCCESS = "The task switch succeeded, and the attack target is successfully set to %s";

    private static final Codec<Result> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_2960.field_25139.fieldOf(TASK_ID_PARAMETER_ID).forGetter(Result::id),
            Codec.INT.optionalFieldOf(ENTITY_ID_PARAMETER_ID, -1).forGetter(Result::entityId)
    ).apply(instance, Result::new));

    @Override
    public String id() {
        return TOOL_ID;
    }

    @Override
    public String summary(EntityMaid maid) {
        return TOOL_DESC;
    }

    @Override
    public Parameter parameters(ObjectParameter root, EntityMaid maid) {
        StringParameter taskId = StringParameter.create()
                .setDescription(this.getTaskIdParameterDesc());
        IntegerParameter entityId = IntegerParameter.create()
                .setDescription(ENTITY_ID_PARAMETER_DESC);

        List<IMaidTask> tasks = TaskManager.getTaskIndex();
        tasks.stream().map(IMaidTask::getUid)
                .map(class_2960::toString)
                .forEach(taskId::addEnumValues);

        root.addProperties(TASK_ID_PARAMETER_ID, taskId);
        root.addProperties(ENTITY_ID_PARAMETER_ID, entityId, false);
        return root;
    }

    @Override
    public Codec<Result> codec() {
        return CODEC;
    }

    @Override
    public LLMCallback onCall(String toolId, Result result, LLMCallback callback) {
        class_2960 taskId = result.id;
        List<IMaidTask> tasks = TaskManager.getTaskIndex();
        Optional<IMaidTask> optional = TaskManager.findTask(taskId);

        if (optional.isEmpty()) {
            List<String> values = tasks.stream()
                    .map(IMaidTask::getUid)
                    .map(class_2960::toString)
                    .toList();
            String text = "Unknown task_id '%s'".formatted(taskId);
            return callback.addToolResult(ITool.invalidParam(TASK_ID_PARAMETER_ID, values, text), toolId);
        }

        EntityMaid maid = callback.getMaid();
        IMaidTask task = optional.get();
        IMaidTask currentTask = maid.getTask();
        FunctionCallSwitchResult switchResult;
        int entityId = result.entityId();

        if (task != currentTask) {
            maid.setTask(task);
        }
        switchResult = task.onFunctionCallSwitch(maid);

        // 日程表检查
        class_4168 activity = maid.getScheduleDetail();
        if (activity != class_4168.field_18596) {
            String msg = SCHEDULED.formatted(taskId, maid.getSchedule().name());
            return callback.addToolResult(msg, toolId);
        }

        if (task instanceof IAttackTask attackTask) {
            String msg = this.attackResult(maid, attackTask, entityId);
            return callback.addToolResult(msg, toolId);
        } else {
            String msg = this.switchResult(taskId, task == currentTask, switchResult);
            return callback.addToolResult(msg, toolId);
        }
    }

    @Override
    public class_2561 invocationSummaryComponent(Result result) {
        class_2960 id = result.id();
        return TaskManager.findTask(id).map(task -> {
            class_5250 name = task.getName();
            return class_2561.method_43469("ai.touhou_little_maid.chat.tool_call.switch_work_task", name)
                    .method_27692(class_124.field_1080);
        }).orElse(class_2561.method_43473());
    }

    private String switchResult(class_2960 taskId, boolean sameTask, FunctionCallSwitchResult switchResult) {
        if (sameTask) {
            return switch (switchResult) {
                case NO_CHANGE -> NO_CHANGE.formatted(taskId);
                case MISSING_REQUIRED_ITEM -> MISSING_REQUIRED.formatted(taskId);
                case PARTIAL_OK -> PARTIAL.formatted(taskId);
                case OK -> SUCCESS.formatted(taskId);
            };
        }
        return switch (switchResult) {
            case NO_CHANGE, OK -> SUCCESS.formatted(taskId);
            case MISSING_REQUIRED_ITEM -> MISSING_REQUIRED.formatted(taskId);
            case PARTIAL_OK -> PARTIAL.formatted(taskId);
        };
    }

    private String attackResult(EntityMaid maid, IAttackTask attackTask, int entityId) {
        if (entityId == -1) {
            return TARGET_NOT_PROVIDED;
        }

        class_1297 entity = maid.field_6002.method_8469(entityId);
        if (!(entity instanceof class_1309 target) || !target.method_5805()) {
            return TARGET_NOT_FOUND.formatted(entityId);
        }

        String targetName = target.method_5477().getString();
        class_1309 previousTarget = maid.method_6065();
        maid.method_6015(target);

        if (!attackTask.canAttack(maid, target)) {
            maid.method_6015(previousTarget);
            return TARGET_NOT_ALLOWED.formatted(targetName);
        }

        maid.method_18868().method_18878(class_4140.field_22355, target);
        return TARGET_SUCCESS.formatted(targetName);
    }

    private String getTaskIdParameterDesc() {
        StringJoiner joiner = new StringJoiner("\n", "Brief explanation of parameters: \n", "");
        TaskManager.getTaskIndex().forEach(task -> {
            String path = task.getUid().method_12832();
            String summary = task.getMaidActionSummary();
            joiner.add("- %s: %s".formatted(path, summary));
        });
        return joiner.toString();
    }

    public record Result(class_2960 id, int entityId) {
    }
}
