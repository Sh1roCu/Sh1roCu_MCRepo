package com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.ai;

import com.github.tartaricacid.touhoulittlemaid.ai.manager.entity.UserPromptContexts;
import com.github.tartaricacid.touhoulittlemaid.ai.manager.response.ResponseChat;
import com.github.tartaricacid.touhoulittlemaid.ai.service.llm.LLMMessage;
import com.github.tartaricacid.touhoulittlemaid.ai.service.llm.Role;
import com.github.tartaricacid.touhoulittlemaid.ai.service.llm.openai.response.ToolCall;
import com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button.FlatColorButton;
import com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button.HistoryChatWidget;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.github.tartaricacid.touhoulittlemaid.network.message.ai.ClearMaidAIDataPacket;
import com.google.common.collect.Lists;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1068;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4068;
import net.minecraft.class_410;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_746;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Nullable;

import java.util.Deque;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class HistoryAIChatScreen extends class_437 {
    private static final class_5250 HISTORY_TITLE = class_2561.method_43471("gui.touhou_little_maid.button.maid_ai_chat_config.history_chat.title");
    private static final class_5250 HISTORY_EMPTY = class_2561.method_43471("gui.touhou_little_maid.button.maid_ai_chat_config.history_chat_is_empty");
    private static final class_5250 SUMMARY_TITLE = class_2561.method_43471("gui.touhou_little_maid.button.maid_ai_chat_config.history_chat.summary_title");
    private static final class_5250 SUMMARY_EMPTY = class_2561.method_43471("gui.touhou_little_maid.button.maid_ai_chat_config.history_chat.summary_empty");

    private static final int CHAT_TEXT_WIDTH = 140;
    private static final int TOOL_TEXT_WIDTH = 180;

    private static final int SUMMARY_WIDTH = 120;
    private static final float SUMMARY_TEXT_SCALE = 0.5f;
    private static final int SUMMARY_TOP = 24;
    private static final int RIGHT_COLUMN_BOTTOM_MARGIN = 24;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_GAP = 6;
    private static final int SUMMARY_BUTTON_GAP = 12;
    private static final int SUMMARY_MIN_HEIGHT = 48;

    private final EntityMaid maid;
    private final @Nullable class_437 parent;
    private final class_2960 playerSkin;
    private final List<LLMMessage> history = Lists.newArrayList();
    private final List<class_4068> historyWidgets = Lists.newArrayList();

    private String summaryText = StringUtils.EMPTY;

    private double scroll = 0;
    private int maxHeight = 0;
    private int posX = 0;

    private int summaryTop = 0;
    private int summaryBottom = 0;
    private int historyTop = 0;
    private int historyBottom = 0;

    /**
     * 在渲染摘要时，缓存的一个变量，些许降低性能占用
     */
    private @Nullable List<String> linesCache = null;

    public HistoryAIChatScreen(EntityMaid maid) {
        this(null, maid);
    }

    public HistoryAIChatScreen(@Nullable class_437 parent, EntityMaid maid) {
        super(class_2561.method_43470("Maid History AI Chat Screen"));
        this.parent = parent;
        this.maid = maid;
        this.playerSkin = this.getPlayerSkin();
        this.summaryText = maid.getAiChatManager().getCompressedSummary();
        this.transformMessage();
    }

    @Override
    protected void method_25426() {
        this.method_37067();
        this.historyWidgets.clear();
        // 刷新时，重置缓存
        this.linesCache = null;

        this.posX = this.field_22789 / 2 - 75;

        this.summaryTop = SUMMARY_TOP;
        this.summaryBottom = this.summaryTop + this.getSummaryPanelHeight();
        this.historyTop = SUMMARY_TOP;
        this.historyBottom = this.field_22790 - 5;
        this.maxHeight = this.historyTop;

        for (LLMMessage message : this.history) {
            int lineHeight = this.addHistoryWidget(message, posX);
            maxHeight += lineHeight + 5;
        }
        this.addButtons();

        int visibleHeight = this.historyBottom - this.historyTop;
        int contentHeight = Math.max(0, this.maxHeight - this.historyTop);

        // 让滚动一开始就在中间
        if (contentHeight < visibleHeight) {
            this.scroll = (visibleHeight - contentHeight) / 2d;
        } else {
            double topMax = this.historyTop;
            double bottomMax = this.historyBottom;
            double scrollBottom = scroll + maxHeight;
            if (scroll > topMax) {
                scroll = topMax;
            }
            if (bottomMax > scrollBottom) {
                scroll = bottomMax - maxHeight;
            }
        }
    }

    private void addButtons() {
        class_5250 clearName = class_2561.method_43471("gui.touhou_little_maid.button.maid_ai_chat_config.clear_history_chat");
        class_5250 clearMsg = class_2561.method_43471("gui.touhou_little_maid.button.maid_ai_chat_config.clear_history_chat.confirm");
        this.method_37063(new FlatColorButton(this.getRightColumnLeft(), this.getClearButtonY(), SUMMARY_WIDTH, BUTTON_HEIGHT, clearName, button -> {
            Screens.getClient(this).method_1507(new class_410(yes -> {
                if (yes) {
                    this.history.clear();
                    this.historyWidgets.clear();
                    this.summaryText = StringUtils.EMPTY;
                    this.maid.getAiChatManager().clearAllChatMemory();
                    ClientPlayNetworking.send(new ClearMaidAIDataPacket(this.maid.method_5628()));
                    this.method_25426();
                }
                Screens.getClient(this).method_1507(this);
            }, clearName, clearMsg));
        }));
        this.method_37063(new FlatColorButton(this.getRightColumnLeft(), this.getBackButtonY(), SUMMARY_WIDTH, BUTTON_HEIGHT,
                class_5244.field_24339, button -> this.method_25419()));
    }

    private int addHistoryWidget(LLMMessage message, int posX) {
        boolean isTool = message.role() == Role.TOOL;
        boolean isLeft = message.role() != Role.USER;

        class_2561 msg = this.getDisplayMessage(message);
        int lineHeight = this.getHistoryLineHeight(msg, isTool);

        // 工具消息
        if (isTool) {
            historyWidgets.add(new HistoryChatWidget(posX - TOOL_TEXT_WIDTH / 2, maxHeight,
                    TOOL_TEXT_WIDTH, lineHeight, msg, playerSkin, message.gameTime(), true, true));
            return lineHeight;
        }

        // 普通聊天消息
        int width = Math.min(field_22793.method_27525(msg), CHAT_TEXT_WIDTH) + 10;
        if (isLeft) {
            historyWidgets.add(new HistoryChatWidget(posX - 100, maxHeight,
                    width, lineHeight, msg, playerSkin, message.gameTime(), true, false));
        } else {
            historyWidgets.add(new HistoryChatWidget(posX + 100 - width, maxHeight,
                    width, lineHeight, msg, playerSkin, message.gameTime(), false, false));
        }
        return lineHeight;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
        super.method_25394(graphics, mouseX, mouseY, partialTicks);

        graphics.method_27534(field_22793, HISTORY_TITLE, posX + 210, 8, 0xFFFFFF);
        this.renderSummaryPanel(graphics);

        if (this.historyWidgets.isEmpty()) {
            List<class_5481> split = field_22793.method_1728(HISTORY_EMPTY, 150);
            for (int i = 0; i < split.size(); i++) {
                int height = i * field_22793.field_2000;
                graphics.method_35719(field_22793, split.get(i), posX, this.historyTop + 15 + height, 0xff5555);
            }
        } else {
            graphics.method_44379(posX - 128, this.historyTop, posX + 128, this.historyBottom);
            graphics.method_51448().method_22903();
            graphics.method_51448().method_22904(0, scroll, 0);
            for (class_4068 renderable : this.historyWidgets) {
                renderable.method_25394(graphics, mouseX, mouseY, partialTicks);
            }
            graphics.method_51448().method_22909();
            graphics.method_44380();
        }
    }

    @Override
    public boolean method_25401(double pMouseX, double pMouseY, double scrollX, double scrollY) {
        if (scrollY != 0) {
            double topMax = this.historyTop;
            double bottomMax = this.historyBottom;
            double scrollBottom = scroll + maxHeight;
            if (scrollY < 0 && bottomMax < scrollBottom) {
                scroll += scrollY * 15;
            }
            if (0 < scrollY && scroll < topMax) {
                scroll += scrollY * 15;
            }
        }
        return super.method_25401(pMouseX, pMouseY, scrollX, scrollY);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            class_437 screen = Objects.requireNonNullElse(this.parent, new AIChatScreen(this.maid));
            this.field_22787.method_1507(screen);
        }
    }

    private void transformMessage() {
        Deque<LLMMessage> deque = this.maid.getAiChatManager().getHistory().getDeque();
        deque.descendingIterator().forEachRemaining(message -> {
            if (message.role() == Role.USER) {
                this.history.add(message);
                return;
            }

            if (message.role() == Role.ASSISTANT) {
                // LLM 发起的工具调用信息，只显示工具名
                List<ToolCall> toolCalls = message.toolCalls();
                if (toolCalls != null && !toolCalls.isEmpty()) {
                    LLMMessage msg = new LLMMessage(Role.TOOL, this.getToolCallNames(toolCalls), message.gameTime());
                    this.history.add(msg);
                    return;
                }

                // 普通的 LLM 返回信息
                String text = message.message();
                if (StringUtils.isNotBlank(text)) {
                    String chatText = new ResponseChat(text).getChatText();
                    if (StringUtils.isNotBlank(chatText)) {
                        LLMMessage msg = new LLMMessage(Role.ASSISTANT, chatText, message.gameTime());
                        this.history.add(msg);
                    }
                }
            }

            // 自身发送给 LLM 的历史记录，不显示在聊天记录中
            // if (message.role() == Role.TOOL) {}
        });
    }

    private String getToolCallNames(List<ToolCall> toolCalls) {
        return toolCalls.stream()
                .map(tool -> tool.getFunction().getName())
                .filter(StringUtils::isNotBlank)
                .distinct()
                .collect(Collectors.joining(", "));
    }

    private class_2561 getDisplayMessage(LLMMessage message) {
        if (message.role() == Role.TOOL) {
            if (StringUtils.isBlank(message.message())) {
                return class_2561.method_43471("gui.touhou_little_maid.button.maid_ai_chat_config.history_chat.tool_call.generic");
            }
            return class_2561.method_43469("gui.touhou_little_maid.button.maid_ai_chat_config.history_chat.tool_call.named", message.message());
        }

        // 需要剔除 user 的 context 部分
        if (message.role() == Role.USER) {
            String content = UserPromptContexts.removeContext(message.message());
            return class_2561.method_43470(content);
        }
        return class_2561.method_43470(message.message());
    }

    private int getHistoryLineHeight(class_2561 message, boolean isTool) {
        if (isTool) {
            int lineCount = field_22793.method_1728(message, TOOL_TEXT_WIDTH).size();
            return lineCount * field_22793.field_2000 / 5;
        } else {
            int lineCount = field_22793.method_1728(message, CHAT_TEXT_WIDTH).size();
            return 10 + lineCount * field_22793.field_2000;
        }
    }

    private void renderSummaryPanel(class_332 graphics) {
        int left = this.getRightColumnLeft();
        int right = left + SUMMARY_WIDTH;

        graphics.method_25294(left, this.summaryTop, right, this.summaryBottom, 0xAA111111);
        graphics.method_25294(left, this.summaryTop, right, this.summaryTop + 1, 0x66FFFFFF);
        graphics.method_25294(left, this.summaryBottom - 1, right, this.summaryBottom, 0x66FFFFFF);

        graphics.method_27534(field_22793, SUMMARY_TITLE, left + SUMMARY_WIDTH / 2, this.summaryTop + 6, 0xFFFFFF);

        // 依据窗口大小，调整 summary 的显示内容
        if (this.linesCache == null) {
            class_2561 content = StringUtils.isBlank(this.summaryText) ? SUMMARY_EMPTY : class_2561.method_43470(this.summaryText);
            this.linesCache = this.getSummaryDisplayLines(content);
        }

        // 渲染缩放字符大小的 summary
        graphics.method_51448().method_22903();
        graphics.method_51448().method_22905(SUMMARY_TEXT_SCALE, SUMMARY_TEXT_SCALE, 1);

        int color = StringUtils.isBlank(this.summaryText) ? 0x999999 : 0xDDDDDD;
        float x = (left + 6) / SUMMARY_TEXT_SCALE;
        float y = (this.summaryTop + 22) / SUMMARY_TEXT_SCALE;
        for (int i = 0; i < this.linesCache.size(); i++) {
            graphics.method_51433(field_22793, this.linesCache.get(i), (int) x, (int) (y + i * field_22793.field_2000), color, false);
        }

        graphics.method_51448().method_22909();
    }

    private int getSummaryPanelHeight() {
        return Math.max(SUMMARY_MIN_HEIGHT, this.getClearButtonY() - SUMMARY_BUTTON_GAP - this.summaryTop);
    }

    private int getRightColumnLeft() {
        return this.posX + 150;
    }

    private int getClearButtonY() {
        return this.field_22790 - RIGHT_COLUMN_BOTTOM_MARGIN - BUTTON_HEIGHT * 2 - BUTTON_GAP;
    }

    private int getBackButtonY() {
        return this.field_22790 - RIGHT_COLUMN_BOTTOM_MARGIN - BUTTON_HEIGHT;
    }

    private List<String> getSummaryDisplayLines(class_2561 content) {
        int logicalWidth = Math.max(1, (int) ((SUMMARY_WIDTH - 12) / SUMMARY_TEXT_SCALE));
        int maxLines = Math.max(1, (int) ((this.summaryBottom - this.summaryTop - 28) / (field_22793.field_2000 * SUMMARY_TEXT_SCALE)));

        List<String> lines = Lists.newArrayList();
        String[] paragraphs = content.getString().replace("\r", StringUtils.EMPTY).split("\n", -1);

        boolean truncated = false;

        outer:
        for (String paragraph : paragraphs) {
            String remaining = paragraph;
            if (remaining.isEmpty()) {
                if (lines.size() >= maxLines) {
                    truncated = true;
                    break;
                }
                lines.add(StringUtils.EMPTY);
                continue;
            }

            while (!remaining.isEmpty()) {
                if (lines.size() >= maxLines) {
                    truncated = true;
                    break outer;
                }
                String part = field_22793.method_27523(remaining, logicalWidth);
                if (part.isEmpty()) {
                    truncated = true;
                    break outer;
                }
                lines.add(part);
                remaining = remaining.substring(part.length()).trim();
            }
        }

        if (lines.isEmpty()) {
            lines.add(StringUtils.EMPTY);
        }

        if (truncated) {
            int lastIndex = lines.size() - 1;
            String ellipsis = "…";
            String last = lines.get(lastIndex);
            String clipped = field_22793.method_27523(last, Math.max(1, logicalWidth - field_22793.method_1727(ellipsis)));
            lines.set(lastIndex, clipped + ellipsis);
        }
        return lines;
    }

    private class_2960 getPlayerSkin() {
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null) {
            return class_1068.method_4649();
        }
        return mc.method_1582().method_52862(player.method_7334()).comp_1626();
    }
}
