package com.github.tartaricacid.touhoulittlemaid.ai.manager.entity;

import net.minecraft.class_2487;
import net.minecraft.class_2540;

public class MaidAIChatSerializable {
    public static final String NO_TTS_SITE = "__none__";

    public String llmSite = "";
    public String llmModel = "";

    public String ttsSite = "";
    public String ttsModel = "";
    public String ttsLanguage = "";
    public String chatLanguage = "";

    public String ownerName = "";
    public String customSetting = "";

    /**
     * 哨兵值，如果为此值，说明此时对当前女仆禁用 TTS 功能
     */
    public static boolean isNoTTSSite(String siteId) {
        return NO_TTS_SITE.equals(siteId);
    }

    public void decode(class_2540 buf) {
        llmSite = buf.method_19772();
        llmModel = buf.method_19772();
        ttsSite = buf.method_19772();
        ttsModel = buf.method_19772();
        ttsLanguage = buf.method_19772();
        chatLanguage = buf.method_19772();
        ownerName = buf.method_19772();
        customSetting = buf.method_19772();
    }

    public void encode(class_2540 buf) {
        buf.method_10814(llmSite);
        buf.method_10814(llmModel);
        buf.method_10814(ttsSite);
        buf.method_10814(ttsModel);
        buf.method_10814(ttsLanguage);
        buf.method_10814(chatLanguage);
        buf.method_10814(ownerName);
        buf.method_10814(customSetting);
    }

    public void copyFrom(MaidAIChatSerializable data) {
        llmSite = data.llmSite;
        llmModel = data.llmModel;
        ttsSite = data.ttsSite;
        ttsModel = data.ttsModel;
        ttsLanguage = data.ttsLanguage;
        chatLanguage = data.chatLanguage;
        ownerName = data.ownerName;
        customSetting = data.customSetting;
    }

    public class_2487 readFromTag(class_2487 tag) {
        if (tag.method_10545("MaidAIChat")) {
            class_2487 data = tag.method_10562("MaidAIChat");
            llmSite = data.method_10558("LLMSite");
            llmModel = data.method_10558("LLMModel");
            ttsSite = data.method_10558("TTSSiteName");
            ttsModel = data.method_10558("TTSModel");
            ttsLanguage = data.method_10558("TTSLanguage");
            chatLanguage = data.method_10558("ChatLanguage");
            ownerName = data.method_10558("OwnerName");
            customSetting = data.method_10558("CustomSetting");
        }
        return tag;
    }

    public class_2487 writeToTag(class_2487 tag) {
        class_2487 data = new class_2487();
        {
            data.method_10582("LLMSite", llmSite);
            data.method_10582("LLMModel", llmModel);
            data.method_10582("TTSSiteName", ttsSite);
            data.method_10582("TTSModel", ttsModel);
            data.method_10582("TTSLanguage", ttsLanguage);
            data.method_10582("ChatLanguage", chatLanguage);
            data.method_10582("OwnerName", ownerName);
            data.method_10582("CustomSetting", customSetting);
        }
        tag.method_10566("MaidAIChat", data);
        return tag;
    }
}