package com.github.tartaricacid.touhoulittlemaid.ai.manager.entity;

import com.github.tartaricacid.touhoulittlemaid.ai.manager.response.ResponseChat;
import com.github.tartaricacid.touhoulittlemaid.ai.service.ErrorCode;
import com.github.tartaricacid.touhoulittlemaid.ai.service.llm.LLMClient;
import com.github.tartaricacid.touhoulittlemaid.ai.service.llm.LLMMessage;
import com.github.tartaricacid.touhoulittlemaid.ai.service.llm.openai.response.Message;
import com.github.tartaricacid.touhoulittlemaid.entity.chatbubble.implement.TextChatBubbleData;
import net.minecraft.class_124;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

import static com.github.tartaricacid.touhoulittlemaid.entity.chatbubble.IChatBubbleData.DEFAULT_PRIORITY;
import static com.github.tartaricacid.touhoulittlemaid.entity.chatbubble.IChatBubbleData.TYPE_2;

public class AutoGenSettingCallback extends LLMCallback {
    public AutoGenSettingCallback(MaidAIChatManager chatManager, List<LLMMessage> messages) {
        super(chatManager, messages, true);
        this.needAddTools = false;
        // 添加自己的提示聊天气泡
        class_5250 component = class_2561.method_43471("ai.touhou_little_maid.chat.llm.role_no_setting_and_gen_setting");
        TextChatBubbleData bubbleData = TextChatBubbleData.create(30 * 20, component, TYPE_2, DEFAULT_PRIORITY);
        this.waitingChatBubbleId = this.getMaid().getChatBubbleManager().addChatBubble(bubbleData);
    }

    @Override
    public void onSuccess(ResponseChat responseChat) {
        String result = responseChat.getChatText();
        if (StringUtils.isBlank(result)) {
            onFailure(null, new Throwable("Error in Response Chat: %s".formatted(responseChat)), ErrorCode.CHAT_TEXT_IS_EMPTY);
            return;
        }
        chatManager.customSetting = result.replaceAll("\n+", "\n\n");

        // 有可能人设提示词会超过 4096 字符长度，故额外检查并适当截断
        // 留部分冗余，故意设置为 4000 而非 4096
        if (chatManager.customSetting.length() > 4000) {
            chatManager.customSetting = chatManager.customSetting.substring(0, 4000);
        }

        class_1309 owner = maid.method_35057();
        if (owner instanceof class_1657 player) {
            player.method_43496(class_2561.method_43471("ai.touhou_little_maid.chat.llm.auto_gen_setting").method_27692(class_124.field_1080));
        }
        if (maid.field_6002 instanceof class_3218 serverLevel) {
            MinecraftServer server = serverLevel.method_8503();
            server.method_20493(() -> {
                maid.getChatBubbleManager().removeChatBubble(waitingChatBubbleId);
                maid.getChatBubbleManager().addTextChatBubble("ai.touhou_little_maid.chat.llm.auto_gen_setting");
            });
        }
    }

    @Override
    public void onFunctionCall(Message choice, LLMClient client) {
        // 生成人设不处理函数调用，直接忽略（理论上也不会触发此回调）
    }
}