package com.github.tartaricacid.touhoulittlemaid.block;

import com.github.tartaricacid.touhoulittlemaid.datagen.tag.TagBlock;
import com.github.tartaricacid.touhoulittlemaid.tileentity.TileEntitySnackCabinet;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_124;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3620;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import net.minecraft.class_9062;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

import java.util.List;

@SuppressWarnings("deprecation")
public class BlockSnackCabinet extends class_2237 {
    public static final MapCodec<BlockSnackCabinet> CODEC = method_54094((properties) -> new BlockSnackCabinet());
    public static final class_2753 FACING = class_2741.field_12481;
    public static final class_2758 TYPE = class_2758.method_11867("type", 0, 2);

    public static final int TYPE_NONE = 0;
    public static final int TYPE_FULL = 1;
    public static final int TYPE_HALF = 2;

    public BlockSnackCabinet() {
        super(class_4970.class_2251.method_9637()
                .method_31710(class_3620.field_15996)
                .method_9626(class_2498.field_11547)
                .method_9629(2.0F, 3.0F)
                .method_22488());
        this.method_9590(this.field_10647.method_11664()
                .method_11657(FACING, class_2350.field_11043)
                .method_11657(TYPE, TYPE_NONE));
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState,
                                  class_1936 level, class_2338 pos, class_2338 neighborPos) {
        // 判断上方方块的 AABB 的 Y 最大值
        if (direction == class_2350.field_11036) {
            if (neighborState.method_26164(TagBlock.SNACK_CABINET_HALF)) {
                return state.method_11657(TYPE, TYPE_HALF);
            }
            if (neighborState.method_26164(TagBlock.SNACK_CABINET_FULL)) {
                return state.method_11657(TYPE, TYPE_FULL);
            }
        }
        return super.method_9559(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    public class_9062 method_55765(class_1799 heldItem, class_2680 state, class_1937 level, class_2338 pos,
                                           class_1657 player, class_1268 hand, class_3965 hit) {
        // 如果是手持方块物品并点击上方，那么不打开界面，方便放置方块
        class_2350 direction = hit.method_17780();
        if (direction == class_2350.field_11036 && heldItem.method_7909() instanceof class_1747) {
            return class_9062.field_47731;
        }

        // 否则打开界面
        if (level.field_9236) {
            return class_9062.field_47728;
        } else {
            class_3908 provider = this.method_17454(state, level, pos);
            if (provider != null) {
                player.method_17355(provider);
            }
            return class_9062.field_47729;
        }
    }

    @Override
    public void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean isMoving) {
        class_1264.method_54291(state, newState, level, pos);
        super.method_9536(state, level, pos, newState, isMoving);
    }

    @Override
    public void method_9588(class_2680 state, class_3218 level, class_2338 pos, class_5819 random) {
        class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof TileEntitySnackCabinet cabinet) {
            cabinet.recheckOpen();
        }
    }

    @Override
    public boolean method_9498(class_2680 state) {
        return true;
    }

    @Override
    public int method_9572(class_2680 blockState, class_1937 level, class_2338 pos) {
        return class_1703.method_7608(level.method_8321(pos));
    }

    @Override
    @Nullable
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new TileEntitySnackCabinet(pos, state);
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(FACING, context.method_8042().method_10153());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, TYPE);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11456;
    }


    @Override
    public void method_9568(class_1799 stack, class_1792.class_9635 context, List<class_2561> tooltip, class_1836 flag) {
        tooltip.add(class_2561.method_43471("block.touhou_little_maid.snack_cabinet.tip").method_27692(class_124.field_1080));
    }

    @Override
    public class_2680 method_9598(class_2680 pState, class_2470 pRot) {
        return pState.method_11657(FACING, pRot.method_10503(pState.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 pState, class_2415 pMirror) {
        return pState.method_26186(pMirror.method_10345(pState.method_11654(FACING)));
    }
}