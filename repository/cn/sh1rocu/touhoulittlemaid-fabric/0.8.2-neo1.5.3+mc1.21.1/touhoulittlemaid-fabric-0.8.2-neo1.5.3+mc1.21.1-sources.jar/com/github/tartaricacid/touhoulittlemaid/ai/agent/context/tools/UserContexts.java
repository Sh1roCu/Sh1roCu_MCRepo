package com.github.tartaricacid.touhoulittlemaid.ai.agent.context.tools;

import com.github.tartaricacid.touhoulittlemaid.ai.agent.context.AbstractMaidContext;
import com.github.tartaricacid.touhoulittlemaid.ai.agent.context.GameContextRegister;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import org.apache.commons.lang3.StringUtils;

import static com.github.tartaricacid.touhoulittlemaid.ai.manager.setting.papi.StringConstant.*;

public final class UserContexts {
    public static final String CATEGORY = "user";
    private static final String SUMMARY = "User identity, health, and equipment information.";

    private UserContexts() {
    }

    public static void registerAll(GameContextRegister register) {
        register.registerCategory(CATEGORY, SUMMARY, false);
        register.registerContext(CATEGORY, new UserNameContext());
        register.registerContext(CATEGORY, new UserHealthContext());
        register.registerContext(CATEGORY, new UserMainHandContext());
        register.registerContext(CATEGORY, new UserArmorContext());
    }

    private static final class UserNameContext extends AbstractMaidContext {
        private UserNameContext() {
            super("user_name", "User name");
        }

        @Override
        public String getValue(EntityMaid maid) {
            String ownerName = maid.getAiChatManager().ownerName;
            if (StringUtils.isBlank(ownerName)) {
                return DEFAULT_OWNER_NAME;
            }
            return ownerName;
        }
    }

    private static final class UserHealthContext extends AbstractMaidContext {
        private UserHealthContext() {
            super("user_healthy", "User health");
        }

        @Override
        public String getValue(EntityMaid maid) {
            class_1309 owner = maid.method_35057();
            if (owner != null) {
                float maxHealth = owner.method_6063();
                float health = owner.method_6032();
                return HEALTHY_FORMAT.formatted(health, maxHealth);
            }
            return StringUtils.EMPTY;
        }
    }

    private static final class UserMainHandContext extends AbstractMaidContext {
        private UserMainHandContext() {
            super("user_mainhand", "User main-hand item");
        }

        @Override
        public String getValue(EntityMaid maid) {
            class_1309 owner = maid.method_35057();
            if (owner == null) {
                return EMPTY;
            }
            class_1799 stack = owner.method_6118(class_1304.field_6173);
            if (stack.method_7960()) {
                return EMPTY;
            }
            return ITEM_AND_COUNT_FORMAT.formatted(stack.method_7954().getString(), stack.method_7947());
        }
    }

    private static final class UserArmorContext extends AbstractMaidContext {
        private UserArmorContext() {
            super("user_armor", "User equipped armor");
        }

        @Override
        public String getValue(EntityMaid maid) {
            class_1309 owner = maid.method_35057();
            if (owner == null) {
                return EMPTY;
            }
            java.util.List<String> names = com.google.common.collect.Lists.newArrayList();
            owner.method_5661().forEach(stack -> {
                if (!stack.method_7960()) {
                    names.add(ITEM_AND_COUNT_FORMAT.formatted(stack.method_7954().getString(), stack.method_7947()));
                }
            });
            if (names.isEmpty()) {
                return EMPTY;
            }
            return StringUtils.join(names, LIST_SEPARATORS);
        }
    }
}
