package com.github.tartaricacid.touhoulittlemaid.ai.agent.context.prompts;

import com.github.tartaricacid.touhoulittlemaid.ai.agent.context.AbstractMaidContext;
import com.github.tartaricacid.touhoulittlemaid.ai.agent.context.GameContextRegister;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

import static com.github.tartaricacid.touhoulittlemaid.ai.manager.setting.papi.StringConstant.*;

public final class WorldContexts {
    public static final String CATEGORY = "world";
    private static final String SUMMARY = "Time, weather, dimension, and biome around";

    private WorldContexts() {
    }

    public static void registerAll(GameContextRegister register) {
        register.registerCategory(CATEGORY, SUMMARY, true);
        register.registerContext(CATEGORY, new GameTimeContext());
        register.registerContext(CATEGORY, new WeatherContext());
        register.registerContext(CATEGORY, new DimensionContext());
        register.registerContext(CATEGORY, new BiomeContext());
    }

    private static final class GameTimeContext extends AbstractMaidContext {
        private GameTimeContext() {
            super("game_time", "Time");
        }

        @Override
        public String getValue(EntityMaid maid) {
            long time = maid.field_6002.method_8532();
            long hours = (time / 1000 + 6) % 24;
            long minutes = (time % 1000) / (50 / 3);
            return TIME_FORMAT.formatted(hours, minutes);
        }
    }

    private static final class WeatherContext extends AbstractMaidContext {
        private WeatherContext() {
            super("weather", "Weather");
        }

        @Override
        public String getValue(EntityMaid maid) {
            class_1937 level = maid.field_6002;
            if (level.method_8546()) {
                return THUNDERING;
            }
            if (level.method_8419()) {
                return RAINING;
            }
            return SUNNY;
        }
    }

    private static final class DimensionContext extends AbstractMaidContext {
        private DimensionContext() {
            super("dimension", "Dimension");
        }

        @Override
        public String getValue(EntityMaid maid) {
            class_5321<class_1937> dimension = maid.field_6002.method_27983();
            if (dimension == class_1937.field_25179) {
                return OVERWORLD;
            }
            if (dimension == class_1937.field_25180) {
                return NETHER;
            }
            if (dimension == class_1937.field_25181) {
                return END;
            }
            return dimension.method_29177().toString();
        }
    }

    private static final class BiomeContext extends AbstractMaidContext {
        private BiomeContext() {
            super("biome", "Biome");
        }

        @Override
        public String getValue(EntityMaid maid) {
            class_1959 biome = maid.field_6002.method_23753(maid.method_24515()).comp_349();
            class_2960 key = maid.field_6002.method_30349().method_30530(class_7924.field_41236).method_10221(biome);
            return key == null ? UNKNOWN_BIOME : key.toString();
        }
    }
}
