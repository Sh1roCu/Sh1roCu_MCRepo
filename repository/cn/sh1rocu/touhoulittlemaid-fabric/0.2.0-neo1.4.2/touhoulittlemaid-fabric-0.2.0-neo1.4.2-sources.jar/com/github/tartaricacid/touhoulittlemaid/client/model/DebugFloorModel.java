package com.github.tartaricacid.touhoulittlemaid.client.model;


import com.github.tartaricacid.touhoulittlemaid.TouhouLittleMaid;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;
import net.minecraft.client.model.geom.builders.*;

public class DebugFloorModel extends AbstractModel<class_1297> {
    public static class_5601 LAYER = new class_5601(class_2960.method_60655(TouhouLittleMaid.MOD_ID, "main"), "debug_floor");
    private final class_630 floor;

    public DebugFloorModel(class_630 root) {
        this.floor = root.method_32086("floor");
    }

    public static class_5607 createBodyLayer() {
        class_5609 meshdefinition = new class_5609();
        class_5610 partdefinition = meshdefinition.method_32111();

        class_5610 floor = partdefinition.method_32117("floor", class_5606.method_32108().method_32101(0, 0).method_32098(-8.0F, 0.0F, -11.0F, 16.0F, 0.0F, 19.0F, class_5605.field_27715),
                class_5603.method_32091(0.0F, -8.0F, 0.0F, -3.1416F, 0.0F, 3.1416F));

        return class_5607.method_32110(meshdefinition, 64, 32);
    }

    @Override
    public void method_2819(class_1297 entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
    }

    @Override
    public void method_2828(class_4587 poseStack, class_4588 buffer, int packedLight, int packedOverlay, int color) {
        floor.method_22698(poseStack, buffer, packedLight, packedOverlay);
    }
}