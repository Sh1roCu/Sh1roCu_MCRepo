package com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.ai.editor;

import com.github.tartaricacid.touhoulittlemaid.ai.service.llm.LLMSite;
import com.github.tartaricacid.touhoulittlemaid.ai.service.llm.openai.LLMOpenAISite;
import com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.ai.settings.AIChatSettingsHubScreen;
import com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.ai.settings.AIChatSettingsLLMSiteScreen;
import com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button.FlatColorButton;
import com.github.tartaricacid.touhoulittlemaid.network.NetworkHandler;
import com.github.tartaricacid.touhoulittlemaid.network.message.ai.SaveLLMSiteMessage;
import com.github.tartaricacid.touhoulittlemaid.util.Rectangle;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1074;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;

import static com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.ai.Translations.*;
import static net.minecraft.class_5244.field_24339;

public class LLMSiteEditorScreen extends class_437 {
    private static final int LABEL_COLOR = 0xFF777777;

    private static final int BASE_WIDTH = 400;
    private static final int BASE_HEIGHT = 230;

    private final AIChatSettingsLLMSiteScreen parent;
    private final LLMSite sourceSite;
    private final String siteDisplayName;

    /**
     * 是否是新增站点的状态，此状态可以自定义 site id
     */
    private final boolean createMode;
    /**
     * 是否能够设置模型的 “深度思考” 属性，部分国内 api 目前还不支持新版 openai api 格式
     */
    private final boolean supportsReasoning;
    /**
     * 模型列表
     */
    private final List<ModelRow> modelRows = Lists.newArrayList();

    private int startX;
    private int startY;

    private class_342 siteIdInput;
    private class_342 urlInput;
    private class_342 secretInput;

    /**
     * 模型列表框
     */
    private int modelScrollOffset;
    private Rectangle modelArea;

    /**
     * 保存时的提示信息
     */
    private long tipTimestamp = -1;
    private class_2561 statusMessage = class_2561.method_43473();

    public LLMSiteEditorScreen(AIChatSettingsLLMSiteScreen parent, LLMSite sourceSite, boolean createMode, boolean supportsReasoning) {
        super(class_2561.method_43470("LLM OpenAI Site Editor"));

        this.parent = parent;
        this.sourceSite = sourceSite;
        this.createMode = createMode;
        this.supportsReasoning = supportsReasoning;

        String nameKey = sourceSite.getNameKey();
        this.siteDisplayName = class_1074.method_4663(nameKey) ? class_1074.method_4662(nameKey) : sourceSite.id();

        if (!this.createMode && this.sourceSite instanceof LLMOpenAISite site) {
            // 如果非创建模式，那么需要预先填充 models 字段
            site.modelEntries().forEach((id, entry) -> {
                ModelRow modelRow = new ModelRow(entry.name(), entry.isReasoning());
                this.modelRows.add(modelRow);
            });
        }
    }

    public LLMSiteEditorScreen(AIChatSettingsLLMSiteScreen parent, LLMSite sourceSite, boolean createMode) {
        this(parent, sourceSite, createMode, false);
    }

    @Override
    protected void method_25426() {
        // 输入框数值读取，这样在改变窗口时，数值不会丢失
        String siteIdValue = this.getEditBoxInitValue(this.siteIdInput, this.sourceSite.id());
        String urlValue = this.getEditBoxInitValue(this.urlInput, this.sourceSite.url());
        String secretValue = this.getEditBoxInitValue(this.secretInput, this.sourceSite instanceof LLMOpenAISite site ? site.secretKey() : StringUtils.EMPTY);

        this.method_37067();
        this.startX = (this.field_22789 - BASE_WIDTH) / 2;
        this.startY = (this.field_22790 - BASE_HEIGHT) / 2;

        int left = this.startX + 12;
        int contentWidth = BASE_WIDTH - 24;

        // 站点 ID，仅在新建模式下可修改
        this.siteIdInput = this.addInput(left, this.startY + 30, 124, SITE_ID_NAME, siteIdValue);
        this.siteIdInput.field_22763 = this.createMode;

        // URL
        this.urlInput = this.addInput(left + 132, this.startY + 30, contentWidth - 132, URL_NAME, urlValue);

        // 秘钥，隐藏显示
        this.secretInput = this.addInput(left, this.startY + 65, contentWidth, SECRET_KEY_NAME, secretValue);
        // 将秘钥输入框的字符显示为 ·，但末尾两个字符正常显示
        this.secretInput.method_1854((text, pos) -> class_5481.method_30747("·".repeat(text.length()), class_2583.field_24360));

        // 模型列表
        this.modelArea = new Rectangle(left, this.startY + 104, contentWidth, BASE_HEIGHT - 103 - 34);
        this.createRows();

        // 底部按钮
        int bottomY = this.startY + BASE_HEIGHT - 24;

        this.method_37063(new FlatColorButton(left, bottomY, 96, 20, ADD_MODEL_NAME, b -> {
            this.modelRows.add(new ModelRow(StringUtils.EMPTY, false));
            int visibleCount = this.getVisibleModelCount();
            this.modelScrollOffset = Math.max(0, this.modelRows.size() - visibleCount);
            this.method_25426();
        }));

        this.method_37063(new FlatColorButton(this.startX + BASE_WIDTH - 200, bottomY, 90, 20, SAVE_NAME, b -> this.saveSite()));
        this.method_37063(new FlatColorButton(this.startX + BASE_WIDTH - 102, bottomY, 90, 20, field_24339, b -> this.method_25419()));
    }

    private String getEditBoxInitValue(@Nullable class_342 editBox, String initValue) {
        if (editBox != null) {
            return editBox.method_1882();
        }
        if (this.createMode) {
            return StringUtils.EMPTY;
        }
        return initValue;
    }

    private class_342 addInput(int x, int y, int width, class_2561 title, String value) {
        class_342 box = new class_342(this.field_22793, x + 6, y + 8, width - 12, 16, title);
        box.method_1880(512);
        box.method_1858(false);
        box.method_1852(value);
        this.method_25429(box);
        return box;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        graphics.method_25296(0, 0, this.field_22789, this.field_22790, 0xc0101010, 0xc0101010);

        // 居中标题
        graphics.method_27534(this.field_22793, llmEditorTitle(this.siteDisplayName),
                this.startX + BASE_WIDTH / 2, this.startY + 4, 0xFFF3EFE0);

        this.renderInputField(graphics, this.siteIdInput, mouseX, mouseY, partialTick);
        this.renderInputField(graphics, this.urlInput, mouseX, mouseY, partialTick);
        this.renderInputField(graphics, this.secretInput, mouseX, mouseY, partialTick);

        this.renderModelArea(graphics, mouseX, mouseY, partialTick);

        super.method_25394(graphics, mouseX, mouseY, partialTick);

        // 提示显示 2 秒
        if (System.currentTimeMillis() - this.tipTimestamp < 2000) {
            int x = this.startX + BASE_WIDTH - 155;
            int y = this.startY + BASE_HEIGHT - 35;
            graphics.method_27534(this.field_22793, this.statusMessage, x, y, 0xFFFF7777);
        }
    }

    private void renderInputField(class_332 graphics, class_342 box, int mouseX, int mouseY, float partialTick) {
        int x = box.method_46426() - 6;
        int y = box.method_46427() - 6;
        int width = box.method_1859() + 12;
        int height = box.method_25364() + 3;

        graphics.method_51439(this.field_22793, box.method_25369(), x + 2, y - 10, LABEL_COLOR, false);
        graphics.method_25294(x, y, x + width, y + height, 0xAA111111);
        box.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private void renderModelArea(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int left = (int) this.modelArea.x;
        int top = (int) this.modelArea.y;

        // 标题
        graphics.method_27535(this.field_22793, MODELS_NAME, left + 2, top - 12, LABEL_COLOR);

        // 确定滚动起始值
        int visibleCount = this.getVisibleModelCount();
        int maxOffset = Math.max(0, this.modelRows.size() - visibleCount);
        if (this.modelScrollOffset > maxOffset) {
            this.modelScrollOffset = maxOffset;
        }

        // 渲染模型列表
        graphics.method_44379(left, top - 2, (int) this.modelArea.right(), (int) this.modelArea.bottom() + 2);
        int startIndex = this.modelScrollOffset;
        int endIndex = Math.min(this.modelRows.size(), startIndex + visibleCount);
        for (int i = startIndex; i < endIndex; i++) {
            ModelRow row = this.modelRows.get(i);
            int rowY = top + 2 + (i - startIndex) * 22;
            if (row.nameBox != null) {
                int rowLeft = (int) this.modelArea.x;
                graphics.method_25294(rowLeft, rowY - 4, rowLeft + row.nameBox.method_1859(), rowY + 20 - 4, 0xAA111111);
                row.nameBox.method_25394(graphics, mouseX, mouseY, partialTick);
            }
        }
        graphics.method_44380();

        // 渲染滚动条：仅当模型总数超过可见区域能容纳的数量时才显示
        if (this.modelRows.size() > visibleCount) {
            // 滚动条轨道的起始 Y 坐标
            int trackTop = top - 1;
            // 滚动条轨道的总高度
            int trackHeight = (int) this.modelArea.h - 9;
            // 滑块高度：按可见行数占总行数的比例缩放，但最小不低于 12px，防止滑块太小难以点击
            int thumbHeight = Math.max(12, visibleCount * trackHeight / this.modelRows.size());
            // 可滚动的最大偏移量（总行数 - 可见行数），至少为 1 防止除零
            int scrollRange = Math.max(1, this.modelRows.size() - visibleCount);
            // 根据当前滚动偏移量，按比例计算滑块在轨道中的 Y 偏移
            int thumbOffset = (trackHeight - thumbHeight) * this.modelScrollOffset / scrollRange;
            // 在模型区域的右侧绘制一个 2px 宽的绿色滑块
            graphics.method_25294((int) this.modelArea.right() - 4,
                    trackTop + thumbOffset,
                    (int) this.modelArea.right() - 2,
                    trackTop + thumbOffset + thumbHeight,
                    0xFF55FF55);
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double delta) {
        if (this.modelArea.contains(mouseX, mouseY)) {
            int visibleCount = this.getVisibleModelCount();
            int maxOffset = Math.max(0, this.modelRows.size() - visibleCount);
            if (delta < 0 && this.modelScrollOffset < maxOffset) {
                this.modelScrollOffset++;
                this.method_25426();
                return true;
            }
            if (delta > 0 && this.modelScrollOffset > 0) {
                this.modelScrollOffset--;
                this.method_25426();
                return true;
            }
        }
        return super.method_25401(mouseX, mouseY, delta);
    }

    @Override
    public void method_25393() {
        this.siteIdInput.method_1865();
        this.urlInput.method_1865();
        this.secretInput.method_1865();
        this.modelRows.stream().map(row -> row.nameBox).filter(Objects::nonNull).forEach(class_342::method_1865);
        super.method_25393();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    public AIChatSettingsHubScreen getParentHub() {
        return this.parent;
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    private void saveSite() {
        LLMSite site = this.buildSite();
        if (site == null) {
            return;
        }
        SaveLLMSiteMessage message = this.createMode ? SaveLLMSiteMessage.create(site) : SaveLLMSiteMessage.update(site);
        ClientPlayNetworking.send(SaveLLMSiteMessage.ID,SaveLLMSiteMessage.encode(message));
    }

    private LLMSite buildSite() {
        if (!(this.sourceSite instanceof LLMOpenAISite site)) {
            return null;
        }

        String siteId = StringUtils.trim(this.siteIdInput.method_1882());
        if (StringUtils.isBlank(siteId)) {
            this.showStatus(SITE_ID_IS_EMPTY);
            return null;
        }
        if (this.createMode && this.parent.hasLLMSite(siteId)) {
            this.showStatus(SITE_ID_ALREADY_EXISTS);
            return null;
        }

        String url = StringUtils.trim(this.urlInput.method_1882());
        if (StringUtils.isBlank(url)) {
            this.showStatus(URL_IS_EMPTY);
            return null;
        }

        List<ModelRow> rows = this.modelRows;
        boolean hasModel = rows.stream().anyMatch(row -> StringUtils.isNotBlank(row.name()));
        if (this.createMode && !hasModel) {
            this.showStatus(MODEL_IS_EMPTY);
            return null;
        }

        // 秘钥可以为空（部分本地模型没有秘钥）
        String secretKey = this.secretInput.method_1882();

        // 普通 OpenAI 模型
        List<LLMOpenAISite.ModelEntry> models = Lists.newArrayList();
        HashSet<String> seen = Sets.newHashSet();
        for (ModelRow row : rows) {
            String modelName = row.name();
            if (StringUtils.isBlank(modelName) || !seen.add(modelName)) {
                continue;
            }
            models.add(new LLMOpenAISite.ModelEntry(modelName, row.reasoning()));
        }
        return new LLMOpenAISite(siteId, site.icon(), url, site.enabled(), secretKey, site.headers(), models);
    }


    /**
     * 创建模型列表
     */
    private void createRows() {
        int visibleCount = this.getVisibleModelCount();
        int maxOffset = Math.max(0, this.modelRows.size() - visibleCount);
        if (this.modelScrollOffset > maxOffset) {
            this.modelScrollOffset = maxOffset;
        }

        int startIndex = this.modelScrollOffset;
        int endIndex = Math.min(this.modelRows.size(), startIndex + visibleCount);

        int left = (int) this.modelArea.x;
        int top = (int) this.modelArea.y;
        int right = (int) this.modelArea.right();

        for (int i = startIndex; i < endIndex; i++) {
            int rowY = top + 3 + (i - startIndex) * 22;
            int inputWidth = this.supportsReasoning ? BASE_WIDTH - 100 : BASE_WIDTH - 38;
            ModelRow row = this.modelRows.get(i);

            String preValue = row.name();
            row.nameBox = new class_342(this.field_22793, left + 6, rowY + 2, inputWidth - 12, 16, class_2561.method_43473());
            row.nameBox.method_1880(512);
            row.nameBox.method_1858(false);
            row.nameBox.method_1852(preValue);
            this.method_25429(row.nameBox);

            if (this.supportsReasoning) {
                String key = row.reasoning ? "ai.touhou_little_maid.chat.settings.hub.model.reasoning" : "ai.touhou_little_maid.chat.settings.hub.model.normal";
                row.toggleButton = this.method_37063(new FlatColorButton(right - 86, rowY - 4, 60, 18, class_2561.method_43471(key), b -> {
                    row.reasoning = !row.reasoning;
                    this.method_25426();
                }));
            } else {
                row.toggleButton = null;
            }

            final int index = i;
            row.deleteButton = this.method_37063(new FlatColorButton(right - 24, rowY - 4, 18, 18, class_2561.method_43470("✕"), b -> {
                this.modelRows.remove(index);
                this.method_25426();
            }));
        }
    }

    private int getVisibleModelCount() {
        return (int) Math.max(1, (this.modelArea.h - 4) / 22);
    }

    private void showStatus(class_2561 message) {
        this.statusMessage = message;
        this.tipTimestamp = System.currentTimeMillis();
    }

    private static final class ModelRow {
        /**
         * nameBox 创建前的初始值缓冲，一旦 nameBox 存在就不再使用
         */
        private final String initialName;

        private boolean reasoning;
        private class_342 nameBox;
        private FlatColorButton toggleButton;
        private FlatColorButton deleteButton;

        private ModelRow(String name, boolean reasoning) {
            this.initialName = name;
            this.reasoning = reasoning;
        }

        private String name() {
            return this.nameBox != null ? this.nameBox.method_1882() : this.initialName;
        }

        private boolean reasoning() {
            return this.reasoning;
        }
    }
}
