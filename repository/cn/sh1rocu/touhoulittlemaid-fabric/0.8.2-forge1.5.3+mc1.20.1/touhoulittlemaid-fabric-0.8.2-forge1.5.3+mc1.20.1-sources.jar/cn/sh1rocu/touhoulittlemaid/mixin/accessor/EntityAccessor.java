package cn.sh1rocu.touhoulittlemaid.mixin.accessor;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1297.class)
public interface EntityAccessor {
    @Accessor("firstTick")
    boolean tlm$firstTick();
}