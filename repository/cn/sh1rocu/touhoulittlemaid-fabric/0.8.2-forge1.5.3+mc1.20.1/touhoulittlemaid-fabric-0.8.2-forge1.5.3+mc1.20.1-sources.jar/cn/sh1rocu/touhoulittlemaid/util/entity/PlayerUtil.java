package cn.sh1rocu.touhoulittlemaid.util.entity;

import com.jamieswhiteshirt.reachentityattributes.ReachEntityAttributes;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;

public class PlayerUtil {
    public static boolean canReach(class_1657 player, class_1297 entity, double padding) {
        return isCloseEnough(player, entity, getEntityReach(player) + padding);
    }

    public static boolean isCloseEnough(class_1657 player, class_1297 entity, double dist) {
        class_243 eye = player.method_33571();
        class_238 aabb = entity.method_5829().method_1014(entity.method_5871());
        return aabb.method_49271(eye) < dist * dist;
    }

    public static double getEntityReach(class_1657 player) {
        double range = player.method_26825(ReachEntityAttributes.REACH) + 3;
        return range == (double) 0.0F ? (double) 0.0F : range + (double) (player.method_7337() ? 3 : 0);
    }
}
