package cn.sh1rocu.touhoulittlemaid.util.forge;

import com.google.gson.JsonElement;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredient;
import net.fabricmc.fabric.api.recipe.v1.ingredient.CustomIngredientSerializer;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2540;
import net.minecraft.class_6862;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.stream.Stream;

/**
 * Extension of {@link class_1856} which makes most methods custom ingredients need to implement abstract, and removes the static constructors
 * Mods are encouraged to extend this class for their custom ingredients
 */
public abstract class AbstractIngredient extends class_1856 implements CustomIngredient {
    /**
     * Empty constructor, for the sake of dynamic ingredients
     */
    protected AbstractIngredient() {
        super(Stream.of());
    }

    /**
     * Value constructor, for ingredients that have some vanilla representation
     */
    protected AbstractIngredient(Stream<? extends class_1859> values) {
        super(values);
    }


    @Override
    public abstract boolean requiresTesting();

    @Override
    public abstract List<class_1799> getMatchingStacks();

    @Override
    public abstract CustomIngredientSerializer<? extends class_1856> getSerializer();

    @Override
    public abstract JsonElement method_8089();


    /* Hide vanilla ingredient static constructors to reduce errors with constructing custom ingredients */

    /**
     * @deprecated use {@link class_1856#method_8092(Stream)}
     */
    @Deprecated
    public static class_1856 method_8092(Stream<? extends class_1856.class_1859> values) {
        throw new UnsupportedOperationException("Use Ingredient.fromValues()");
    }

    /**
     * @deprecated use {@link class_1856#method_35226()}
     */
    @Deprecated
    public static class_1856 method_35226() {
        throw new UnsupportedOperationException("Use Ingredient.of()");
    }

    /**
     * @deprecated use {@link class_1856#method_8091(class_1935...)} (Stream)}
     */
    @Deprecated
    public static class_1856 method_8091(class_1935... items) {
        throw new UnsupportedOperationException("Use Ingredient.of()");
    }

    /**
     * @deprecated use {@link class_1856#method_8101(class_1799...)} (Stream)}
     */
    @Deprecated
    public static class_1856 method_8101(class_1799... stacks) {
        throw new UnsupportedOperationException("Use Ingredient.of()");
    }

    /**
     * @deprecated use {@link class_1856#method_26964(Stream)} (Stream)}
     */
    @Deprecated
    public static class_1856 method_26964(Stream<class_1799> stacks) {
        throw new UnsupportedOperationException("Use Ingredient.of()");
    }

    /**
     * @deprecated use {@link class_1856#method_8106(class_6862)} (Stream)}
     */
    @Deprecated
    public static class_1856 method_8106(class_6862<class_1792> tag) {
        throw new UnsupportedOperationException("Use Ingredient.of()");
    }

    /**
     * @deprecated use {@link class_1856#method_8086(class_2540)}
     */
    @Deprecated
    public static class_1856 method_8086(class_2540 buffer) {
        throw new UnsupportedOperationException("Use Ingredient.fromNetwork()");
    }

    /**
     * @deprecated use {@link class_1856#method_52177(JsonElement)} (Stream)}
     */
    @Deprecated
    public static class_1856 method_52177(@Nullable JsonElement json) {
        throw new UnsupportedOperationException("Use Ingredient.fromJson()");
    }
}
