package cn.sh1rocu.touhoulittlemaid.mixin.common;

import cn.sh1rocu.touhoulittlemaid.api.extension.IItemEntity;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1542.class)
public abstract class ItemEntityMixin {
    @Shadow
    public abstract class_1799 getItem();

    @Inject(method = "tick()V", at = @At("HEAD"), cancellable = true)
    public void tlm$tick(CallbackInfo ci) {
        class_1799 stack = this.getItem();
        if (stack.method_7909() instanceof IItemEntity item) {
            if (item.onEntityItemUpdate(stack, (class_1542) (Object) this))
                ci.cancel();
        }
    }
}