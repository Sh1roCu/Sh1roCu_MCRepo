package cn.sh1rocu.touhoulittlemaid.api.extension;

import javax.annotation.Nullable;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_2244;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface IBedBlock {
    default boolean isBed(class_2680 state, class_1922 world, class_2338 pos, @Nullable class_1297 entity) {
        return this instanceof class_2244;
    }
}
