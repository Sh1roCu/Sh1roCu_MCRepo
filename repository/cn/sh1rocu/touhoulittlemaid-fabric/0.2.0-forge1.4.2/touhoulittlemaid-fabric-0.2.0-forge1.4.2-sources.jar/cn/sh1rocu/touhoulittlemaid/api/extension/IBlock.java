package cn.sh1rocu.touhoulittlemaid.api.extension;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_702;

public interface IBlock {
    @Environment(EnvType.CLIENT)
    boolean addHitEffects(class_2680 state, class_1937 world, class_239 target, class_702 manager);

    @Environment(EnvType.CLIENT)
    default boolean addDestroyEffects(class_2680 state, class_1937 Level, class_2338 pos, class_702 engine) {
        return !state.method_45475();
    }

    default void onBlockExploded(class_2680 state, class_1937 world, class_2338 pos, class_1927 explosion) {
        world.method_8652(pos, class_2246.field_10124.method_9564(), 3);
        ((class_2248) this).method_9586(world, pos, explosion);
    }
}
