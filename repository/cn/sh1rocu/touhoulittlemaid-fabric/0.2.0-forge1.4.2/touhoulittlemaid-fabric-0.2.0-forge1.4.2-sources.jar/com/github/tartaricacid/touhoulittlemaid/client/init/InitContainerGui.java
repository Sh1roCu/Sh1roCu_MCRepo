package com.github.tartaricacid.touhoulittlemaid.client.init;

import com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.backpack.*;
import com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.config.MaidAIChatConfigContainerGui;
import com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.config.MaidConfigContainerGui;
import com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.task.AttackTaskConfigGui;
import com.github.tartaricacid.touhoulittlemaid.client.gui.entity.maid.task.DefaultMaidTaskConfigGui;
import com.github.tartaricacid.touhoulittlemaid.client.gui.item.PicnicBasketContainerScreen;
import com.github.tartaricacid.touhoulittlemaid.client.gui.item.WirelessIOContainerGui;
import com.github.tartaricacid.touhoulittlemaid.init.InitContainer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3929;

@Environment(EnvType.CLIENT)
public final class InitContainerGui {
    public static void clientSetup() {
        class_3929.method_17542(InitContainer.MAID_EMPTY_BACKPACK_CONTAINER, EmptyBackpackContainerScreen::new);
        class_3929.method_17542(InitContainer.MAID_SMALL_BACKPACK_CONTAINER, SmallBackpackContainerScreen::new);
        class_3929.method_17542(InitContainer.MAID_MIDDLE_BACKPACK_CONTAINER, MiddleBackpackContainerScreen::new);
        class_3929.method_17542(InitContainer.MAID_BIG_BACKPACK_CONTAINER, BigBackpackContainerScreen::new);
        class_3929.method_17542(InitContainer.MAID_CRAFTING_TABLE_BACKPACK_CONTAINER, CraftingTableBackpackContainerScreen::new);
        class_3929.method_17542(InitContainer.MAID_ENDER_CHEST_CONTAINER, EnderChestBackpackContainerScreen::new);
        class_3929.method_17542(InitContainer.MAID_FURNACE_CONTAINER, FurnaceBackpackContainerScreen::new);
        class_3929.method_17542(InitContainer.MAID_TANK_CONTAINER, TankBackpackContainerScreen::new);

        class_3929.method_17542(InitContainer.MAID_BAUBLE_CONTAINER, BaubleContainerScreen::new);
        class_3929.method_17542(InitContainer.MAID_CONFIG_CONTAINER, MaidConfigContainerGui::new);
        class_3929.method_17542(InitContainer.MAID_AI_CHAT_CONFIG_CONTAINER, MaidAIChatConfigContainerGui::new);
        class_3929.method_17542(InitContainer.WIRELESS_IO_CONTAINER, WirelessIOContainerGui::new);
        class_3929.method_17542(InitContainer.PICNIC_BASKET_CONTAINER, PicnicBasketContainerScreen::new);

        class_3929.method_17542(InitContainer.DEFAULT_MAIK_TASK_CONFIG, DefaultMaidTaskConfigGui::new);
        class_3929.method_17542(InitContainer.ATTACK_TASK_CONFIG, AttackTaskConfigGui::new);
    }
}
