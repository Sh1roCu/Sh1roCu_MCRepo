package com.github.tartaricacid.touhoulittlemaid.client.gui.widget.button;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_5244;

public class TouhouImageButton extends class_4185 {
    protected final class_2960 resourceLocation;
    protected final int xTexStart;
    protected final int yTexStart;
    protected final int yDiffTex;
    protected final int textureWidth;
    protected final int textureHeight;

    public TouhouImageButton(int pX, int pY, int pWidth, int pHeight, int pXTexStart, int pYTexStart, class_2960 pResourceLocation, class_4241 pOnPress) {
        this(pX, pY, pWidth, pHeight, pXTexStart, pYTexStart, pHeight, pResourceLocation, 256, 256, pOnPress);
    }

    public TouhouImageButton(int pX, int pY, int pWidth, int pHeight, int pXTexStart, int pYTexStart, int pYDiffTex, class_2960 pResourceLocation, class_4241 pOnPress) {
        this(pX, pY, pWidth, pHeight, pXTexStart, pYTexStart, pYDiffTex, pResourceLocation, 256, 256, pOnPress);
    }

    public TouhouImageButton(int pX, int pY, int pWidth, int pHeight, int pXTexStart, int pYTexStart, int pYDiffTex, class_2960 pResourceLocation, int pTextureWidth, int pTextureHeight, class_4241 pOnPress) {
        this(pX, pY, pWidth, pHeight, pXTexStart, pYTexStart, pYDiffTex, pResourceLocation, pTextureWidth, pTextureHeight, pOnPress, class_5244.field_39003);
    }

    public TouhouImageButton(int pX, int pY, int pWidth, int pHeight, int pXTexStart, int pYTexStart, int pYDiffTex, class_2960 pResourceLocation, int pTextureWidth, int pTextureHeight, class_4241 pOnPress, class_2561 pMessage) {
        super(pX, pY, pWidth, pHeight, pMessage, pOnPress, field_40754);
        this.textureWidth = pTextureWidth;
        this.textureHeight = pTextureHeight;
        this.xTexStart = pXTexStart;
        this.yTexStart = pYTexStart;
        this.yDiffTex = pYDiffTex;
        this.resourceLocation = pResourceLocation;
    }

    public void method_48579(class_332 pGuiGraphics, int pMouseX, int pMouseY, float pPartialTick) {
        this.method_48588(pGuiGraphics, this.resourceLocation, this.method_46426(), this.method_46427(), this.xTexStart, this.yTexStart, this.yDiffTex, this.field_22758, this.field_22759, this.textureWidth, this.textureHeight);
    }

    public void method_48588(class_332 pGuiGraphics, class_2960 pTexture, int pX, int pY, int pUOffset, int pVOffset, int p_283472_, int pWidth, int pHeight, int pTextureWidth, int pTextureHeight) {
        int i = pVOffset;
        if (!this.method_37303()) {
            i = pVOffset + p_283472_ * 2;
        } else if (this.method_25367()) {
            i = pVOffset + p_283472_;
        }

        RenderSystem.enableDepthTest();
        pGuiGraphics.method_25290(pTexture, pX, pY, (float) pUOffset, (float) i, pWidth, pHeight, pTextureWidth, pTextureHeight);
    }
}
