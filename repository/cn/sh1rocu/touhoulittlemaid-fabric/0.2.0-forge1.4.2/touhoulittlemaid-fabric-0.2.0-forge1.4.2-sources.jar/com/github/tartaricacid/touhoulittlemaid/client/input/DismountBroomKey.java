package com.github.tartaricacid.touhoulittlemaid.client.input;

import com.github.tartaricacid.touhoulittlemaid.network.message.DismountMessage;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class DismountBroomKey {
    public static final class_304 DISMOUNT_KEY = new class_304("key.touhou_little_maid.dismount.desc",
//            KeyConflictContext.IN_GAME,
//            KeyModifier.NONE,
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_C,
            "key.category.touhou_little_maid");

    public static void onDismountPress(int key, int scanCode, int action, int mods) {
        if (keyIsMatch(key, scanCode, action, mods)) {
            class_746 player = class_310.method_1551().field_1724;
            if (player == null || player.method_7325()) {
                return;
            }
            if (!isInGame()) {
                return;
            }
            DISMOUNT_KEY.method_1436();
            if (action == GLFW.GLFW_RELEASE) {
                ClientPlayNetworking.send(DismountMessage.ID, DismountMessage.encode(DismountMessage.DISMOUNT_BROOM));
            }
        }
    }

    private static boolean keyIsMatch(int key, int scanCode, int action, int mods) {
        return DISMOUNT_KEY.method_1417(key, scanCode)
                /*&& DISMOUNT_KEY.getKeyModifier().equals(KeyModifier.getActiveModifier())*/;
    }

    private static boolean isInGame() {
        class_310 mc = class_310.method_1551();
        // 不能是加载界面
        if (mc.method_18506() != null) {
            return false;
        }
        // 不能打开任何 GUI
        if (mc.field_1755 != null) {
            return false;
        }
        // 当前窗口捕获鼠标操作
        if (!mc.field_1729.method_1613()) {
            return false;
        }
        // 选择了当前窗口
        return mc.method_1569();
    }
}