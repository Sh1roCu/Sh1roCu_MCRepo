package cn.sh1rocu.tacz.mixin.client.accessor;

import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_465.class)
public interface AbstractContainerScreenAccessor {
    @Accessor("leftPos")
    int tacz$getGuiLeft();

    @Accessor("topPos")
    int tacz$getGuiTop();
}
