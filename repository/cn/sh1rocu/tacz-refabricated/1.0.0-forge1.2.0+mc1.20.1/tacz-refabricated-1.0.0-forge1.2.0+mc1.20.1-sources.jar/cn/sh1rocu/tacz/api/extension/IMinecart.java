package cn.sh1rocu.tacz.api.extension;

import net.minecraft.class_1688;

public interface IMinecart {
    default boolean tacz$canBeRidden() {
        return ((class_1688) this).method_7518() == class_1688.class_1689.field_7674;
    }
}
