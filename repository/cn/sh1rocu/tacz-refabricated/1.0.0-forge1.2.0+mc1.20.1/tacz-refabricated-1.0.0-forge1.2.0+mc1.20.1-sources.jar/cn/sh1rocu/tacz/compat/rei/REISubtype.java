package cn.sh1rocu.tacz.compat.rei;

import com.tacz.guns.api.item.*;
import me.shedaniel.rei.api.common.entry.comparison.EntryComparator;
import net.minecraft.class_1799;

public class REISubtype {
    public static EntryComparator<class_1799> getAmmoSubtype() {
        return (context, stack) -> {
            if (stack.method_7909() instanceof IAmmo iAmmo) {
                return iAmmo.getAmmoId(stack).hashCode();
            }
            return 0;
        };
    }

    public static EntryComparator<class_1799> getGunSubtype() {
        return (context, stack) -> {
            if (stack.method_7909() instanceof IGun iGun) {
                return iGun.getGunId(stack).hashCode();
            }
            return 0;
        };
    }

    public static EntryComparator<class_1799> getAttachmentSubtype() {
        return (context, stack) -> {
            if (stack.method_7909() instanceof IAttachment iAttachment) {
                return iAttachment.getAttachmentId(stack).hashCode();
            }
            return 0;
        };
    }

    public static EntryComparator<class_1799> getTableSubType() {
        return (context, stack) -> {
            if (stack.method_7909() instanceof IBlock iBlock) {
                return iBlock.getBlockId(stack).hashCode();
            }
            return 0;
        };
    }


    public static EntryComparator<class_1799> getAmmoBoxSubtype() {
        return (context, stack) -> {
            if (stack.method_7909() instanceof IAmmoBox iAmmoBox) {
                if (iAmmoBox.isAllTypeCreative(stack)) {
                    return "all_type_creative".hashCode();
                }
                if (iAmmoBox.isCreative(stack)) {
                    return "creative".hashCode();
                }
                return String.format("level_%d", iAmmoBox.getAmmoLevel(stack)).hashCode();
            }
            return 0;
        };
    }
}
