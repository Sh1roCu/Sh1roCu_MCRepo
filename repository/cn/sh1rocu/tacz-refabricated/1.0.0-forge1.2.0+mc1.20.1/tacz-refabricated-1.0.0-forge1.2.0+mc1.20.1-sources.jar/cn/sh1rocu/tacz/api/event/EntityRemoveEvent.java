package cn.sh1rocu.tacz.api.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;

public class EntityRemoveEvent extends BaseEvent {
    public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback e : callbacks) e.onEntityRemove(event);
    });

    private final class_1297 entity;

    public EntityRemoveEvent(class_1297 entity) {
        this.entity = entity;
    }

    public class_1297 getEntity() {
        return entity;
    }

    public interface Callback {
        void onEntityRemove(EntityRemoveEvent event);
    }
}