package cn.sh1rocu.tacz.mixin.client;

import cn.sh1rocu.tacz.api.event.RenderPlayerEvent;
import net.minecraft.class_1007;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
public class PlayerRendererMixin {
    @Inject(method = "render(Lnet/minecraft/client/player/AbstractClientPlayer;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"), cancellable = true)
    private void goety$onRenderPlayerPre(class_742 player, float f, float partialTick, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
        var event = new RenderPlayerEvent.Pre(player, (class_1007) (Object) this, partialTick, poseStack, buffer, packedLight);
        RenderPlayerEvent.PRE.invoker().post(event);
        if (event.isCanceled())
            ci.cancel();
    }

    @Inject(method = "render(Lnet/minecraft/client/player/AbstractClientPlayer;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At("RETURN"))
    private void tacz$onRenderPlayerPost(class_742 player, float f, float partialTick, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
        var event = new RenderPlayerEvent.Post(player, (class_1007) (Object) this, partialTick, poseStack, buffer, packedLight);
        RenderPlayerEvent.POST.invoker().post(event);
    }
}