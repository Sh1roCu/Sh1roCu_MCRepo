package cn.sh1rocu.tacz.mixin.client.accessor;

import net.minecraft.class_2960;
import net.minecraft.class_357;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_357.class)
public interface AbstractSliderButtonAccessor {
    @Accessor("SLIDER_LOCATION")
    static class_2960 tacz$getSliderLocation() {
        throw new AssertionError();
    }

    @Invoker("getTextureY")
    int tacz$getTextureY();

    @Invoker("getHandleTextureY")
    int tacz$getHandleTextureY();
}
