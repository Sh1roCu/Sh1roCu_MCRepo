package cn.sh1rocu.tacz.mixin.client;

import cn.sh1rocu.tacz.util.forge.ClientHooks;
import net.minecraft.class_1059;
import net.minecraft.class_7766;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1059.class)
public class TextureAtlasMixin {
    @Inject(method = "upload", at = @At("TAIL"))
    private void tacz$uploadPost(class_7766.class_7767 preparations, CallbackInfo ci) {
        ClientHooks.onTextureStitchedPost((class_1059) (Object) this);
    }
}
