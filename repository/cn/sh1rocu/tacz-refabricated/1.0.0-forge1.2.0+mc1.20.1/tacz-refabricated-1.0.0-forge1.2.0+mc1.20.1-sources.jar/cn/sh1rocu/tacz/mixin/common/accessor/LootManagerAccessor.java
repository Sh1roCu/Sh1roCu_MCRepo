package cn.sh1rocu.tacz.mixin.common.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_60;
import net.minecraft.class_8488;

@Mixin(class_60.class)
public interface LootManagerAccessor {
    @Accessor("elements")
    Map<class_8488<?>, ?> tacz$elements();
}