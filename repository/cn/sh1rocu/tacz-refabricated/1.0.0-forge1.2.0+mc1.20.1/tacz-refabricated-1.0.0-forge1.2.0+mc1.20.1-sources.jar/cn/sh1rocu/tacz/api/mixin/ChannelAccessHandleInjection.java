package cn.sh1rocu.tacz.api.mixin;

import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_4225;

// From Kilt
public interface ChannelAccessHandleInjection {
    void tacz$setPool(class_4225.class_4105 pool);

    void tacz$setSoundInstance(class_1113 instance);

    void tacz$setSoundEngine(class_1140 engine);
}