package cn.sh1rocu.tacz.mixin.compat.tweakeroo;

import com.tacz.guns.item.AmmoItem;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1792.class)
public class ItemMixin {
    @SuppressWarnings("MixinAnnotationTarget")
    @Inject(method = "getMaxStackSize(Lnet/minecraft/world/item/ItemStack;)I", at = @At("HEAD"), cancellable = true)
    private void getMaxStackSize(class_1799 stack, CallbackInfoReturnable<Integer> cir) {
        if (((class_1792) (Object) this) instanceof AmmoItem item) {
            cir.setReturnValue(item.tacz$getMaxStackSize(stack));
        }
    }
}
