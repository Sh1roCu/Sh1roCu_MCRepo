package cn.sh1rocu.tacz.mixin.common;

import cn.sh1rocu.tacz.api.extension.IItem;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1799.class)
public abstract class ItemStackMixin {
    @Shadow
    public abstract class_1792 getItem();

    @ModifyReturnValue(method = "getMaxStackSize", at = @At("RETURN"))
    private int tacz$getMaxStackSize(int original) {
        if (this.getItem() instanceof IItem item) {
            class_1799 stack = (class_1799) (Object) this;
            return item.tacz$getMaxStackSize(stack);
        }
        return original;
    }
}
