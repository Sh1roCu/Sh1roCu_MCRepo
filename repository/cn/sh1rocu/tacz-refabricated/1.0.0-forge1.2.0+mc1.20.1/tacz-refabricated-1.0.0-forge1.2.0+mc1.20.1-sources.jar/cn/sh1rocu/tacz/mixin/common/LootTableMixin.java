package cn.sh1rocu.tacz.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.tacz.guns.loot.LootTableInjectorModifier;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.class_1799;
import net.minecraft.class_47;
import net.minecraft.class_52;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_52.class)
public class LootTableMixin {
    @ModifyReturnValue(method = "getRandomItems(Lnet/minecraft/world/level/storage/loot/LootContext;)Lit/unimi/dsi/fastutil/objects/ObjectArrayList;",
            at = @At(value = "RETURN"))
    private ObjectArrayList<class_1799> tacz$globalModifier(ObjectArrayList<class_1799> list, class_47 lootContext) {
        return LootTableInjectorModifier.doApply(list, lootContext, (class_52) (Object) this);
    }
}