package cn.sh1rocu.tacz.util.itemhandler.entity.player;

import cn.sh1rocu.tacz.util.itemhandler.CombinedInvWrapper;
import net.minecraft.class_1661;

public class PlayerInvWrapper extends CombinedInvWrapper {
    public PlayerInvWrapper(class_1661 inv) {
        super(new PlayerMainInvWrapper(inv), new PlayerArmorInvWrapper(inv), new PlayerOffhandInvWrapper(inv));
    }
}