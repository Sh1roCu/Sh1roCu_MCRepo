package cn.sh1rocu.tacz.api.event;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_583;
import net.minecraft.class_922;

@Environment(EnvType.CLIENT)
public abstract class RenderLivingEvent<T extends class_1309, M extends class_583<T>> extends BaseEvent {
    private final class_1309 entity;
    private final class_922<T, M> renderer;
    private final float partialTick;
    private final class_4587 poseStack;
    private final class_4597 multiBufferSource;
    private final int packedLight;

    public static final Event<PostCallback> POST = EventFactory.createArrayBacked(PostCallback.class, callbacks -> event -> {
        for (PostCallback callback : callbacks) {
            callback.post(event);
        }
    });

    public interface PostCallback {
        void post(Post<?, ?> event);
    }

    protected RenderLivingEvent(class_1309 entity, class_922<T, M> renderer, float partialTick, class_4587 poseStack,
                                class_4597 multiBufferSource, int packedLight) {
        this.entity = entity;
        this.renderer = renderer;
        this.partialTick = partialTick;
        this.poseStack = poseStack;
        this.multiBufferSource = multiBufferSource;
        this.packedLight = packedLight;
    }

    public class_1309 getEntity() {
        return entity;
    }

    public class_922<T, M> getRenderer() {
        return renderer;
    }

    public float getPartialTick() {
        return partialTick;
    }

    public class_4587 getPoseStack() {
        return poseStack;
    }

    public class_4597 getMultiBufferSource() {
        return multiBufferSource;
    }

    public int getPackedLight() {
        return packedLight;
    }

    public static class Post<T extends class_1309, M extends class_583<T>> extends RenderLivingEvent<T, M> {
        public Post(class_1309 entity, class_922<T, M> renderer, float partialTick, class_4587 poseStack, class_4597 multiBufferSource, int packedLight) {
            super(entity, renderer, partialTick, poseStack, multiBufferSource, packedLight);
        }
    }
}
