package cn.sh1rocu.tacz.util.itemhandler.entity.player;

import cn.sh1rocu.tacz.util.itemhandler.InvWrapper;
import cn.sh1rocu.tacz.util.itemhandler.RangedWrapper;
import net.minecraft.class_1661;

public class PlayerOffhandInvWrapper extends RangedWrapper {
    public PlayerOffhandInvWrapper(class_1661 inv) {
        super(new InvWrapper(inv), inv.field_7547.size() + inv.field_7548.size(), inv.field_7547.size() + inv.field_7548.size() + inv.field_7544.size());
    }
}