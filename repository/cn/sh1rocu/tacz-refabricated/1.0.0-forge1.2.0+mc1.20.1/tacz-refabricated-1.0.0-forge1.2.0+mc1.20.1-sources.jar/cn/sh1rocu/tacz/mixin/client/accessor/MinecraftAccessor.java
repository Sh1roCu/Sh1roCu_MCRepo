package cn.sh1rocu.tacz.mixin.client.accessor;

import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_310.class)
public interface MinecraftAccessor {
    @Accessor("pausePartialTick")
    float tacz$getPausePartialTick();
}
