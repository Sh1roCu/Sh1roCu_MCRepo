package cn.sh1rocu.tacz.mixin.client;

import cn.sh1rocu.tacz.util.forge.ClientHooks;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_2724;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPacketListenerMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Inject(method = "handleRespawn", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/ClientLevel;addPlayer(ILnet/minecraft/client/player/AbstractClientPlayer;)V"))
    private void tacz$cloneEvent(class_2724 packet, CallbackInfo ci, @Local(ordinal = 0) class_746 oldPlayer, @Local(ordinal = 1) class_746 newPlayer) {
        ClientHooks.firePlayerRespawn(this.minecraft.field_1761, oldPlayer, newPlayer, newPlayer.field_3944.method_48296());
    }
}
