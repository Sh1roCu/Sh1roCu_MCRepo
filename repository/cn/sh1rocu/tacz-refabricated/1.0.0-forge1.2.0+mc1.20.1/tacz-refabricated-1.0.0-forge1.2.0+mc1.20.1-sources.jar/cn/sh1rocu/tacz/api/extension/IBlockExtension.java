package cn.sh1rocu.tacz.api.extension;

import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface IBlockExtension {
    default void tacz$onBlockExploded(class_2680 state, class_1937 world, class_2338 pos, class_1927 explosion) {
        world.method_8652(pos, class_2246.field_10124.method_9564(), 3);
        ((class_2248) this).method_9586(world, pos, explosion);
    }
}