package cn.sh1rocu.tacz.mixin.client;

import cn.sh1rocu.tacz.api.event.InputEvent;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class KeyboardHandlerMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Inject(method = "keyPress", at = @At("TAIL"))
    private void tacz$onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (window == this.minecraft.method_22683().method_4490()) {
            InputEvent.Key.EVENT.invoker().onKey(new InputEvent.Key(key, scancode, action, modifiers));
        }
    }
}
