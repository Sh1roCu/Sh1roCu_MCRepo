package cn.sh1rocu.tacz.mixin.common.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1255;

@Mixin(class_1255.class)
public interface BlockableEventLoopAccessor {
    @Invoker("submitAsync")
    CompletableFuture<Void> tacz$submitAsync(Runnable task);
}
