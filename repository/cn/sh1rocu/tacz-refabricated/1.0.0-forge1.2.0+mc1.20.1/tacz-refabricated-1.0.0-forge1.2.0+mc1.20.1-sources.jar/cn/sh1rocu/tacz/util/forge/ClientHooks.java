package cn.sh1rocu.tacz.util.forge;

import cn.sh1rocu.tacz.api.event.ClientPlayerNetworkEvent;
import cn.sh1rocu.tacz.api.event.ComputeFovModifierEvent;
import cn.sh1rocu.tacz.api.event.TextureStitchEvent;
import net.minecraft.class_1059;
import net.minecraft.class_1657;
import net.minecraft.class_2535;
import net.minecraft.class_636;
import net.minecraft.class_746;

public class ClientHooks {
    public static float getFieldOfViewModifier(class_1657 entity, float fovModifier) {
        ComputeFovModifierEvent fovModifierEvent = new ComputeFovModifierEvent(entity, fovModifier);
        ComputeFovModifierEvent.CALLBACK.invoker().post(fovModifierEvent);
        return fovModifierEvent.getNewFovModifier();
    }

    public static void firePlayerRespawn(class_636 pc, class_746 oldPlayer, class_746 newPlayer, class_2535 networkManager) {
        ClientPlayerNetworkEvent.CLONE.invoker().post(new ClientPlayerNetworkEvent.Clone(pc, oldPlayer, newPlayer, networkManager));
    }

    public static void onTextureStitchedPost(class_1059 map) {
        TextureStitchEvent.POST.invoker().post(new TextureStitchEvent.Post(map));
    }
}
