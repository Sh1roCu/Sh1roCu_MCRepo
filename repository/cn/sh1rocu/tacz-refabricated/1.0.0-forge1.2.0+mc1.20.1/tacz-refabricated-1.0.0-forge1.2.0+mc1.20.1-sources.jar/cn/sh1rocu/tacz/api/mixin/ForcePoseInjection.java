package cn.sh1rocu.tacz.api.mixin;

import net.minecraft.class_4050;

public interface ForcePoseInjection {
    class_4050 tacz$getForcedPose();

    void tacz$setForcedPose(class_4050 pose);
}