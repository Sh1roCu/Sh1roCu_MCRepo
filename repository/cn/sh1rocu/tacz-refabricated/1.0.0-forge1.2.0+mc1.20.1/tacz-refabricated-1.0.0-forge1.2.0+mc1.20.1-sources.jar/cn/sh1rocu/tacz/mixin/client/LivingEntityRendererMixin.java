package cn.sh1rocu.tacz.mixin.client;

import cn.sh1rocu.tacz.api.event.RenderLivingEvent;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V", at = @At("TAIL"))
    public void tacz$onPostEvent(class_1309 entity, float entityYaw, float partialTicks, class_4587 matrixStack, class_4597 buffer, int packedLight, CallbackInfo ci) {
        var event = new RenderLivingEvent.Post<>(entity, (class_922<?, ?>) (Object) this, partialTicks, matrixStack, buffer, packedLight);
        RenderLivingEvent.POST.invoker().post(event);
    }
}