package cn.sh1rocu.tacz.mixin.common;

import cn.sh1rocu.tacz.api.extension.IBlockExtension;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1927.class)
public class ExplosionMixin {
    @Shadow
    @Final
    public class_1937 level;

    @Inject(
            method = "finalizeExplosion",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/util/profiling/ProfilerFiller;pop()V"
            )
    )
    private void tacz$onBlockExploded(boolean spawnParticles, CallbackInfo ci, @Local(ordinal = 0) class_2338 pos, @Local(ordinal = 0) class_2680 state) {
        if (state.method_26204() instanceof IBlockExtension block) {
            block.tacz$onBlockExploded(state, this.level, pos, (class_1927) (Object) this);
        }
    }
}