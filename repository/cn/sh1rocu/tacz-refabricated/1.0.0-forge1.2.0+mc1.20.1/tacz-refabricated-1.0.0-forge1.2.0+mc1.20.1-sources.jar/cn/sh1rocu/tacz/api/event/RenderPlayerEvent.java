package cn.sh1rocu.tacz.api.event;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1007;
import net.minecraft.class_1657;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

@Environment(EnvType.CLIENT)
public class RenderPlayerEvent extends PlayerEvent {
    private final class_1007 renderer;
    private final float partialTick;
    private final class_4587 poseStack;
    private final class_4597 multiBufferSource;
    private final int packedLight;

    public static final Event<PreCallback> PRE = EventFactory.createArrayBacked(PreCallback.class, callbacks -> event -> {
        for (PreCallback callback : callbacks) {
            callback.post(event);
        }
    });

    public static final Event<PostCallback> POST = EventFactory.createArrayBacked(PostCallback.class, callbacks -> event -> {
        for (PostCallback callback : callbacks)
            callback.post(event);
    });


    public interface PreCallback {
        void post(Pre event);
    }

    public interface PostCallback {
        void post(Post event);
    }

    protected RenderPlayerEvent(class_1657 player, class_1007 renderer, float partialTick, class_4587 poseStack, class_4597 multiBufferSource, int packedLight) {
        super(player);
        this.renderer = renderer;
        this.partialTick = partialTick;
        this.poseStack = poseStack;
        this.multiBufferSource = multiBufferSource;
        this.packedLight = packedLight;
    }

    public class_1007 getRenderer() {
        return renderer;
    }

    public float getPartialTick() {
        return partialTick;
    }

    public class_4587 getPoseStack() {
        return poseStack;
    }

    public class_4597 getMultiBufferSource() {
        return multiBufferSource;
    }

    public int getPackedLight() {
        return packedLight;
    }

    public static class Pre extends RenderPlayerEvent implements ICancellableEvent {
        public Pre(class_1657 player, class_1007 renderer, float partialTick, class_4587 poseStack, class_4597 multiBufferSource, int packedLight) {
            super(player, renderer, partialTick, poseStack, multiBufferSource, packedLight);
        }
    }

    public static class Post extends RenderPlayerEvent {
        public Post(class_1657 player, class_1007 renderer, float partialTick, class_4587 poseStack, class_4597 multiBufferSource, int packedLight) {
            super(player, renderer, partialTick, poseStack, multiBufferSource, packedLight);
        }
    }
}