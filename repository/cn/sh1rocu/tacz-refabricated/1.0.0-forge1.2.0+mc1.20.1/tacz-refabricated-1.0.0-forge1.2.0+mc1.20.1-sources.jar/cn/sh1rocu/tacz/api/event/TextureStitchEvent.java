package cn.sh1rocu.tacz.api.event;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1059;

@Environment(EnvType.CLIENT)
public class TextureStitchEvent extends BaseEvent {
    private final class_1059 atlas;

    public static final Event<PostCallback> POST = EventFactory.createArrayBacked(PostCallback.class, callbacks -> event -> {
        for (PostCallback callback : callbacks) {
            callback.post(event);
        }
    });

    public interface PostCallback {
        void post(Post event);
    }

    public TextureStitchEvent(class_1059 atlas) {
        this.atlas = atlas;
    }

    public class_1059 getAtlas() {
        return atlas;
    }

    public static class Post extends TextureStitchEvent {
        public Post(class_1059 map) {
            super(map);
        }
    }
}
