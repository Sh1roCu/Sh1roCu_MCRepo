package cn.sh1rocu.tacz.mixin.client;

import cn.sh1rocu.tacz.api.mixin.ChannelAccessHandleInjection;
import cn.sh1rocu.tacz.util.SoundConsumerStorage;
import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1111;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_4224;
import net.minecraft.class_4225;
import net.minecraft.class_4235;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Consumer;

@Environment(EnvType.CLIENT)
@Mixin(class_1140.class)
public abstract class SoundEngineMixin {
    // From Kilt
    @Inject(method = "play", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sounds/ChannelAccess$ChannelHandle;execute(Ljava/util/function/Consumer;)V", shift = At.Shift.AFTER))
    private void tacz$prepareChannelInfo(class_1113 soundInstance, CallbackInfo ci, @Local class_4235.class_4236 channelHandle, @Local class_1111 sound) {
        var injection = ((ChannelAccessHandleInjection) channelHandle);

        if (sound.method_4769())
            injection.tacz$setPool(class_4225.class_4105.field_18353);
        else
            injection.tacz$setPool(class_4225.class_4105.field_18352);

        injection.tacz$setSoundInstance(soundInstance);
        injection.tacz$setSoundEngine((class_1140) (Object) this);
    }

    // From Kilt
    @ModifyArg(method = "method_19757", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sounds/ChannelAccess$ChannelHandle;execute(Ljava/util/function/Consumer;)V"))
    private static Consumer<class_4224> tacz$storeSourceConsumer(Consumer<class_4224> consumer) {
        SoundConsumerStorage.soundConsumerChannels.add(consumer);
        return consumer;
    }

    // 暂时用不到
    // From Kilt
/*    @ModifyArg(method = "method_19758", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sounds/ChannelAccess$ChannelHandle;execute(Ljava/util/function/Consumer;)V"))
    private static Consumer<Channel> tacz$storeStreamConsumer(Consumer<Channel> consumer) {
        SoundConsumerStorage.soundConsumerChannels.add(consumer);
        return consumer;
    }*/
}
