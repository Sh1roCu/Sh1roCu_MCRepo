package cn.sh1rocu.tacz.api.extension;

import net.minecraft.class_2487;

public interface IEntityPersistentData {
    default class_2487 tacz$getPersistentData() {
        throw new RuntimeException();
    }
}