package cn.sh1rocu.tacz.api.mixin;

import net.minecraft.class_3285;

public interface PackRepositoryExtension {
    default void tacz$addPackFinder(class_3285 packFinder) {
        throw new RuntimeException("PackRepository implementation does not support adding sources!");
    }
}