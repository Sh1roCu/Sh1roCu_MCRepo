package com.tacz.guns.client.resource.manager;

import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.tacz.guns.GunMod;
import com.tacz.guns.api.client.animation.gltf.AnimationStructure;
import com.tacz.guns.client.resource.ClientAssetsManager;
import com.tacz.guns.client.resource.pojo.animation.gltf.RawAnimationStructure;
import com.tacz.guns.resource.manager.LazyJsonDataManager;
import net.minecraft.class_2960;
import net.minecraft.class_7654;
import org.jetbrains.annotations.Nullable;


public class GltfManager extends LazyJsonDataManager<AnimationStructure> {
    private static final class_7654 FILE_TO_ID_CONVERTER = new class_7654("animations", ".gltf");

    public GltfManager() {
        super(AnimationStructure.class, ClientAssetsManager.GSON, FILE_TO_ID_CONVERTER, "GltfAnimationLoader",
                id -> GunMod.MOD_ID.equals(id.method_12836()));
    }

    @Override
    protected @Nullable AnimationStructure parseJson(JsonElement element) throws JsonParseException {
        RawAnimationStructure rawStructure = getGson().fromJson(element, RawAnimationStructure.class);
        return rawStructure == null ? null : new AnimationStructure(rawStructure);
    }

    public AnimationStructure getGltfAnimation(class_2960 id) {
        return getData(id);
    }
}
