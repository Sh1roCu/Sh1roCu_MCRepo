package com.tacz.guns.client.model.papi;

import java.util.function.Function;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class PlayerNamePapi implements Function<class_1799, String> {
    public static final String NAME = "player_name";

    @Override
    public String apply(class_1799 stack) {
        class_746 player = class_310.method_1551().field_1724;
        if (player != null) {
            return player.method_5477().getString();
        }
        return "";
    }
}
