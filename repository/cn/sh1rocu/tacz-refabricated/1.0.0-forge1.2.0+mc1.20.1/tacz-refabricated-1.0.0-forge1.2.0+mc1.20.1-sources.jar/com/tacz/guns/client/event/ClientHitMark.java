package com.tacz.guns.client.event;

import cn.sh1rocu.tacz.api.LogicalSide;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.event.common.EntityHurtByGunEvent;
import com.tacz.guns.api.event.common.EntityKillByGunEvent;
import com.tacz.guns.client.gui.overlay.KillAmountOverlay;
import com.tacz.guns.client.sound.SoundPlayManager;
import com.tacz.guns.config.client.RenderConfig;
import com.tacz.guns.entity.TargetMinecart;
import com.tacz.guns.util.time.GunTime;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public class ClientHitMark {
    public static long lastHitTimestamp = -1;
    public static float damageAmount = 0;

    public static void onEntityHurt(EntityHurtByGunEvent.Post event) {
        LogicalSide logicalSide = event.getLogicalSide();
        if (logicalSide != LogicalSide.CLIENT) {
            return;
        }
        class_1309 attacker = event.getAttacker();
        class_746 player = class_310.method_1551().field_1724;
        class_1297 hurtEntity = event.getHurtEntity();
        if (player != null && player.equals(attacker) && hurtEntity != null) {
            class_2960 gunId = event.getGunId();
            class_2960 gunDisplayId = event.getGunDisplayId();
            RenderCrosshairEvent.markHitTimestamp();
            if (event.isHeadShot()) {
                RenderCrosshairEvent.markHeadShotTimestamp();
                TimelessAPI.getGunDisplay(gunDisplayId, gunId).ifPresent(index -> SoundPlayManager.playHeadHitSound(player, index));
            } else {
                TimelessAPI.getGunDisplay(gunDisplayId, gunId).ifPresent(index -> SoundPlayManager.playFleshHitSound(player, index));
            }

            if(hurtEntity instanceof TargetMinecart){
                if (GunTime.isWithin(lastHitTimestamp, RenderConfig.DAMAGE_COUNTER_RESET_TIME.get())) {
                    damageAmount += event.getAmount();
                } else {
                    damageAmount = event.getAmount();
                }
                float distance = player.method_5739(event.getHurtEntity());
                player.method_7353(class_2561.method_43469("message.tacz.target_minecart.hit", String.format("%.1f", damageAmount), String.format("%.2f", distance)), true);

                lastHitTimestamp = GunTime.nowMillis();
            }
        }
    }

    public static void onEntityKill(EntityKillByGunEvent event) {
        LogicalSide logicalSide = event.getLogicalSide();
        if (logicalSide != LogicalSide.CLIENT) {
            return;
        }
        class_1309 attacker = event.getAttacker();
        class_746 player = class_310.method_1551().field_1724;
        if (player != null && player.equals(attacker)) {
            RenderCrosshairEvent.markKillTimestamp();
            KillAmountOverlay.markTimestamp();
            TimelessAPI.getGunDisplay(event.getGunDisplayId(), event.getGunId()).ifPresent(index -> SoundPlayManager.playKillSound(player, index));
            if (event.isHeadShot()) {
                RenderCrosshairEvent.markHeadShotTimestamp();
            }
        }
    }

    public static void resetTimestamp() {
        lastHitTimestamp = -1;
        damageAmount = 0;
    }
}
