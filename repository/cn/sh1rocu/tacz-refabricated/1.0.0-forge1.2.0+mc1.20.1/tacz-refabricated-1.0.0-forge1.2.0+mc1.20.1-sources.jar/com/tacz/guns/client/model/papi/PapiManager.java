package com.tacz.guns.client.model.papi;

import com.google.common.collect.Maps;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1074;
import net.minecraft.class_1799;
import java.util.Map;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
public final class PapiManager {
    private static final Map<String, Function<class_1799, String>> PAPI = Maps.newHashMap();

    // 注册，不知道放哪里，先放这
    static {
        addPapi(PlayerNamePapi.NAME, new PlayerNamePapi());
        addPapi(AmmoCountPapi.NAME, new AmmoCountPapi());
        addPapi(RangefinderPapi.NAME, new RangefinderPapi());
    }

    public static void addPapi(String textKey, Function<class_1799, String> function) {
        textKey = "%" + textKey + "%";
        PAPI.put(textKey, function);
    }

    public static String getTextShow(String textKey, class_1799 stack) {
        String text = class_1074.field_25290.method_48307(textKey);
        for (var entry : PAPI.entrySet()) {
            String placeholder = entry.getKey();
            if (!text.contains(placeholder)) {
                continue;
            }
            String data = entry.getValue().apply(stack);
            text = text.replace(placeholder, data);
        }
        return text;
    }
}
