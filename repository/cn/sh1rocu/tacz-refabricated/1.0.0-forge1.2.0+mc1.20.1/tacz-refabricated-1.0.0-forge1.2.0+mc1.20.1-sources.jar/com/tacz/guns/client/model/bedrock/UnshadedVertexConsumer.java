package com.tacz.guns.client.model.bedrock;

import com.tacz.guns.mixin.client.RenderSystemAccessor;
import net.minecraft.class_4588;
import org.joml.Matrix3f;
import org.joml.Vector3f;

public final class UnshadedVertexConsumer implements class_4588 {
    private static final float FALLBACK_NORMAL_X = 0.0F;
    private static final float FALLBACK_NORMAL_Y = 1.0F;
    private static final float FALLBACK_NORMAL_Z = 0.0F;

    private final class_4588 delegate;
    private final float normalX;
    private final float normalY;
    private final float normalZ;

    private UnshadedVertexConsumer(class_4588 delegate) {
        this.delegate = delegate;

        Vector3f[] lightDirections = RenderSystemAccessor.getShaderLightDirections();
        Vector3f primaryLight = lightDirections.length > 0 ? lightDirections[0] : null;
        if (primaryLight == null) {
            this.normalX = FALLBACK_NORMAL_X;
            this.normalY = FALLBACK_NORMAL_Y;
            this.normalZ = FALLBACK_NORMAL_Z;
            return;
        }

        float maxComponent = Math.max(Math.abs(primaryLight.x()),
                Math.max(Math.abs(primaryLight.y()), Math.abs(primaryLight.z())));
        if (maxComponent < 1.0E-6F) {
            this.normalX = FALLBACK_NORMAL_X;
            this.normalY = FALLBACK_NORMAL_Y;
            this.normalZ = FALLBACK_NORMAL_Z;
            return;
        }

        // The entity shader does not normalize vertex normals. Scaling the primary light direction
        // until its largest component reaches one makes minecraft_mix_light clamp to full brightness.
        this.normalX = primaryLight.x() / maxComponent;
        this.normalY = primaryLight.y() / maxComponent;
        this.normalZ = primaryLight.z() / maxComponent;
    }

    private UnshadedVertexConsumer(class_4588 delegate, float normalX, float normalY, float normalZ) {
        this.delegate = delegate;
        this.normalX = normalX;
        this.normalY = normalY;
        this.normalZ = normalZ;
    }

    public static class_4588 wrap(class_4588 consumer) {
        if (consumer instanceof UnshadedVertexConsumer) {
            return consumer;
        }
        return new UnshadedVertexConsumer(consumer);
    }

    public static class_4588 wrapFixedNormal(class_4588 consumer) {
        return new UnshadedVertexConsumer(consumer,
                FALLBACK_NORMAL_X, FALLBACK_NORMAL_Y, FALLBACK_NORMAL_Z);
    }

    public class_4588 getDelegate() {
        return delegate;
    }

    public Matrix3f createNormalMatrix() {
        // Accelerated meshes store +Y as their canonical unshaded normal. The second matrix column
        // maps that normal to the shader light direction captured for this render call.
        return new Matrix3f()
                .m10(normalX)
                .m11(normalY)
                .m12(normalZ);
    }

    @Override
    public class_4588 method_22912(double x, double y, double z) {
        delegate.method_22912(x, y, z);
        return this;
    }

    @Override
    public class_4588 method_1336(int red, int green, int blue, int alpha) {
        delegate.method_1336(red, green, blue, alpha);
        return this;
    }

    @Override
    public class_4588 method_22913(float u, float v) {
        delegate.method_22913(u, v);
        return this;
    }

    @Override
    public class_4588 method_22917(int u, int v) {
        delegate.method_22917(u, v);
        return this;
    }

    @Override
    public class_4588 method_22921(int u, int v) {
        delegate.method_22921(u, v);
        return this;
    }

    @Override
    public class_4588 method_22914(float x, float y, float z) {
        delegate.method_22914(normalX, normalY, normalZ);
        return this;
    }

    @Override
    public void method_1344() {
        delegate.method_1344();
    }

    @Override
    public void method_22901(int red, int green, int blue, int alpha) {
        delegate.method_22901(red, green, blue, alpha);
    }

    @Override
    public void method_35666() {
        delegate.method_35666();
    }
}
