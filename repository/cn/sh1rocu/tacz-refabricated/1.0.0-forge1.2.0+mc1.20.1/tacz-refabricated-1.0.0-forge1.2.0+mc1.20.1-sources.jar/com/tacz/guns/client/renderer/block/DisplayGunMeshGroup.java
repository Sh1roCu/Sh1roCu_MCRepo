package com.tacz.guns.client.renderer.block;

import com.github.mcmodderanchor.simplebedrockmodel.v2.client.mesh.cache.MeshCachePolicy;
import com.github.mcmodderanchor.simplebedrockmodel.v2.client.mesh.capture.GeometryCollector;
import com.github.mcmodderanchor.simplebedrockmodel.v2.client.mesh.world.MeshRenderableAdapter;
import com.github.mcmodderanchor.simplebedrockmodel.v2.client.mesh.world.WorldMeshGroup;
import com.github.mcmodderanchor.simplebedrockmodel.v2.client.mesh.world.WorldMeshRenderer;
import com.github.mcmodderanchor.simplebedrockmodel.v2.client.mesh.world.WorldMeshStrategy;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.block.entity.DisplayGunSlot;
import com.tacz.guns.block.entity.GunDisplayBlockEntity;
import com.tacz.guns.client.renderer.external.ExternalGunAppearance;
import com.tacz.guns.client.resource.ClientIndexManager;
import com.tacz.guns.config.client.RenderConfig;
import org.joml.Matrix4f;

import java.time.Duration;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_811;

/** 每个悬挂物独立登记；稳定身份由所属方块实体创建和持有。 */
public class DisplayGunMeshGroup {
    private static final double ITEM_DEPTH = 0.25D;
    private static WorldMeshGroup<DisplayGunSlot> group;
    private static boolean configWasEnabled;
    private static final Map<DisplayGunSlot, CachedAppearance> APPEARANCES = new WeakHashMap<>();
    public static final MeshCachePolicy TTL_300 = new MeshCachePolicy(Duration.ofSeconds(300), 128,
            512L * 1024L * 1024L);

    private DisplayGunMeshGroup() {
    }

    private record CachedAppearance(long appearanceRevision, long resourceRevision,
                                    ExternalGunAppearance.Resolution resolution) {
    }

    private static final MeshRenderableAdapter<DisplayGunSlot> ADAPTER = new MeshRenderableAdapter<>() {
        @Override
        public boolean isValid(DisplayGunSlot slot) {
            GunDisplayBlockEntity owner = slot.owner();
            class_2586 blockEntity = owner.getBlockEntity();
            class_1799 stack = owner.getItem(slot.index());
            boolean valid = !blockEntity.method_11015() && blockEntity.method_10997() == class_310.method_1551().field_1687
                    && !stack.method_7960() && IGun.getIGunOrNull(stack) != null;
            if (!valid) {
                APPEARANCES.remove(slot);
            }
            return valid;
        }

        @Override
        public boolean isVisible(DisplayGunSlot slot) {
            return snapshot(slot) != null;
        }

        @Override
        public class_243 origin(DisplayGunSlot slot) {
            return class_243.method_24954(slot.owner().getBlockEntity().method_11016());
        }

        @Override
        public Matrix4f localTransform(DisplayGunSlot slot) {
            GunDisplayBlockEntity owner = slot.owner();
            int index = slot.index();
            int gridSize = owner.getGridSize();
            int localIndex = index % (gridSize * gridSize);
            double x = ((localIndex % gridSize) + 0.5D) / gridSize - 0.5D;
            double y = ((localIndex / gridSize) + 0.5D) / gridSize - 0.5D;
            class_4587 pose = new class_4587();
            DisplayItemTransforms.apply(pose, owner.getSlotFacing(index), x, y, ITEM_DEPTH, owner.getRotation(index));
            return new Matrix4f(pose.method_23760().method_23761());
        }

        @Override
        public int packedLight(DisplayGunSlot slot) {
            GunDisplayBlockEntity owner = slot.owner();
            if (owner.isDisplayGlowing()) {
                return class_765.method_23687(15, 15);
            }
            class_2586 blockEntity = owner.getBlockEntity();
            return class_761.method_23794(blockEntity.method_10997(), blockEntity.method_11016());
        }

        @Override
        public Object geometryKey(DisplayGunSlot slot) {
            ExternalGunAppearance.Snapshot current = snapshot(slot);
            return current == null ? slot : current.key();
        }

        @Override
        public boolean collectGeometry(DisplayGunSlot slot, GeometryCollector collector) {
            ExternalGunAppearance.Snapshot current = snapshot(slot);
            return current != null && DisplayGunGeometry.capture(current, class_811.field_4319, collector);
        }
    };

    /** 方块实体渲染器对当前槽位调用；返回 true 表示由 SBM 接管，包括等待模型或 VBO 就绪。 */
    public static boolean tryRender(GunDisplayBlockEntity owner, int index, int overlay) {
        if (!RenderConfig.DISPLAY_GUN_VBO.get()) {
            if (configWasEnabled) {
                if (group != null) {
                    group.clear();
                }
                APPEARANCES.clear();
            }
            configWasEnabled = false;
            return false;
        }
        configWasEnabled = true;
        if (overlay != class_4608.field_21444 || owner.getBlockEntity().method_10997() != class_310.method_1551().field_1687) {
            return false;
        }

        class_1799 stack = owner.getItem(index);
        if (stack.method_7960() || IGun.getIGunOrNull(stack) == null) {
            return false;
        }

        DisplayGunSlot slot = owner.getDisplaySlot(index);
        ExternalGunAppearance.Snapshot current = snapshot(slot);
        CachedAppearance cached = APPEARANCES.get(slot);
        if (current == null) {
            return cached != null && cached.resolution().pending();
        }

        if (group == null) {
            group = WorldMeshRenderer.createGroup(
                    "tacz:display_guns",
                    WorldMeshStrategy.INSTANCE,
                    Set.of(WorldMeshStrategy.INSTANCE),
                    TTL_300
            );
        }
        group.track(slot, ADAPTER);
        if (slot.consumeChange()) {
            group.markDirty(slot);
        }

        ExternalGunAppearance.Snapshot previous = cached.resolution().variants().select(!current.useLod());
        group.claimForWorldDraw(slot, current.key(), previous.key());
        // 捕获或上传尚未完成时继续由 VBO 路径接管，避免回退到开销较大的普通渲染。
        return true;
    }

    public static ExternalGunAppearance.Snapshot snapshot(DisplayGunSlot slot) {
        GunDisplayBlockEntity owner = slot.owner();
        class_2586 blockEntity = owner.getBlockEntity();
        if (blockEntity.method_11015()) {
            return null;
        }

        long appearanceRevision = slot.appearanceRevision();
        long resourceRevision = ClientIndexManager.resourceRevision();
        CachedAppearance cached = APPEARANCES.get(slot);
        if (cached == null || cached.appearanceRevision() != appearanceRevision
                || cached.resourceRevision() != resourceRevision || cached.resolution().pending()) {
            cached = new CachedAppearance(appearanceRevision, resourceRevision,
                    ExternalGunAppearance.resolve(owner.getItem(slot.index())));
            APPEARANCES.put(slot, cached);
        }
        ExternalGunAppearance.Variants variants = cached.resolution().variants();
        if (variants == null) {
            return null;
        }
        if (variants.near() == variants.far()) {
            return variants.near();
        }

        int range = RenderConfig.GUN_LOD_RENDER_DISTANCE.get();
        boolean useLod = range == 0 || blockEntity.method_11016().method_19770(
                class_310.method_1551().field_1773.method_19418().method_19326()) >= (double) range * range;
        return variants.select(useLod);
    }
}
