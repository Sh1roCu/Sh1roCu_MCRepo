package com.tacz.guns.client.event;

import cn.sh1rocu.tacz.api.event.ClientPlayerNetworkEvent;
import com.tacz.guns.api.client.event.SwapItemWithOffHand;
import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.api.item.IAnimationItem;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.client.resource.ClientIndexManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public class InventoryEvent {
    private static final int HOTBAR_WARM_UP_INTERVAL_TICKS = 7;
    private static final int BACKPACK_WARM_UP_INTERVAL_TICKS = 41;

    // 用于切枪逻辑
    private static int oldHotbarSelected = -1;
    private static class_1799 oldHotbarSelectItem = class_1799.field_8037;

    public static void onPlayerChangeSelect(class_310 client, boolean isPhaseEnd) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null) {
            return;
        }
        class_1661 inventory = player.method_31548();
        // 玩家切换选中框的情况
        if (oldHotbarSelected != inventory.field_7545) {
            ClientIndexManager.warmUpItem(inventory.method_5438(inventory.field_7545));
            if (oldHotbarSelected == -1) {
                IClientPlayerGunOperator.fromLocalPlayer(player).draw(class_1799.field_8037);
            } else {
                IClientPlayerGunOperator.fromLocalPlayer(player).draw(inventory.method_5438(oldHotbarSelected));
            }
            oldHotbarSelected = inventory.field_7545;
            oldHotbarSelectItem = inventory.method_5438(inventory.field_7545).method_7972();
            return;
        }
        // 玩家选中的物品改变的情况
        class_1799 currentItem = inventory.method_5438(inventory.field_7545);
        if (currentItem.method_7909() instanceof IAnimationItem item) {
            if (!item.isSame(oldHotbarSelectItem, currentItem)) {
                IClientPlayerGunOperator.fromLocalPlayer(player).draw(oldHotbarSelectItem);
            }
        } else {
            if (!class_1799.method_7973(oldHotbarSelectItem, currentItem)) {
                IClientPlayerGunOperator.fromLocalPlayer(player).draw(oldHotbarSelectItem);
            }
        }

        if (!class_1799.method_7973(oldHotbarSelectItem, currentItem)) {
            oldHotbarSelectItem = currentItem.method_7972();
        }
        if (isPhaseEnd) {
            if (player.field_6012 % HOTBAR_WARM_UP_INTERVAL_TICKS == 0) {
                ClientIndexManager.warmUpEquippedAndHotbarModels();
            }
            if (player.field_6012 % BACKPACK_WARM_UP_INTERVAL_TICKS == 0) {
                ClientIndexManager.warmUpBackpackModels();
            }
        }
    }

    public static void onPlayerSwapMainHand(SwapItemWithOffHand event) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null) {
            return;
        }
        IClientPlayerGunOperator.fromLocalPlayer(player).draw(player.method_6047());
    }

    public static void onPlayerLoggedOut(class_634 handler, class_310 client) {
        // 离开游戏时重置客户端 draw 状态
        oldHotbarSelected = -1;
        oldHotbarSelectItem = class_1799.field_8037;
    }

    private static boolean isSame(class_1799 i, class_1799 j) {
        IGun iGun1 = IGun.getIGunOrNull(i);
        IGun iGun2 = IGun.getIGunOrNull(j);
        if (iGun1 != null && iGun2 != null) {
            return iGun1.getGunId(i).equals(iGun2.getGunId(j));
        }
        if (i.method_7960() || j.method_7960()) {
            return i.method_7960() && j.method_7960();
        }
        return class_1799.method_7973(i, j);
    }
}
