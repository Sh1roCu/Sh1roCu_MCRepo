package com.tacz.guns.client.animation.third;

import com.tacz.guns.compat.playeranimator.PlayerAnimatorCompat;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_1306;
import net.minecraft.class_5603;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_630;

/** Restore the shared player model after a vanilla or mod-provided hand draw. */
public final class PlayerModelRenderState implements AutoCloseable {
    private final class_591<?> model;
    private final List<PartState> parts;
    private final float attackTime;
    private final float swimAmount;
    private final boolean crouching;
    private final boolean riding;
    private final boolean young;
    private final class_572.class_573 leftArmPose;
    private final class_572.class_573 rightArmPose;
    private final Runnable restoreAnimation;

    public PlayerModelRenderState(class_591<?> model) {
        this.model = model;
        parts = Stream.of(model.field_3398, model.field_3394, model.field_3391, model.field_27433, model.field_3401,
                        model.field_3397, model.field_3392, model.field_3483, model.field_3484, model.field_3486,
                        model.field_3482, model.field_3479)
                .flatMap(class_630::method_32088).distinct().map(PartState::new).toList();
        attackTime = model.field_3447;
        swimAmount = model.field_3396;
        crouching = model.field_3400;
        riding = model.field_3449;
        young = model.field_3448;
        leftArmPose = model.field_3399;
        rightArmPose = model.field_3395;
        restoreAnimation = PlayerAnimatorCompat.captureModelState(model);
    }

    public void prepareArm(class_1306 arm, boolean visible) {
        // A RenderArmEvent replacement can draw sleeve geometry before vanilla initializes it.
        // Vanilla's fallback still applies the player's skin-part settings in renderHand().
        if (arm == class_1306.field_6183) {
            model.field_3401.field_3665 = visible;
            model.field_3486.field_3665 = visible;
        } else {
            model.field_27433.field_3665 = visible;
            model.field_3484.field_3665 = visible;
        }
    }

    @Override
    public void close() {
        restoreAnimation.run();
        parts.forEach(PartState::restore);
        model.field_3447 = attackTime;
        model.field_3396 = swimAmount;
        model.field_3400 = crouching;
        model.field_3449 = riding;
        model.field_3448 = young;
        model.field_3399 = leftArmPose;
        model.field_3395 = rightArmPose;
    }

    private record PartState(class_630 part, class_5603 pose, float xScale, float yScale, float zScale,
                             boolean visible, boolean skipDraw) {
        private PartState(class_630 part) {
            this(part, part.method_32084(), part.field_37938, part.field_37939, part.field_37940, part.field_3665, part.field_38456);
        }

        private void restore() {
            part.method_32085(pose);
            part.field_37938 = xScale;
            part.field_37939 = yScale;
            part.field_37940 = zScale;
            part.field_3665 = visible;
            part.field_38456 = skipDraw;
        }
    }
}
