package com.tacz.guns.advancement;

import com.google.gson.JsonObject;
import net.minecraft.advancements.critereon.*;
import net.minecraft.class_174;
import net.minecraft.class_195;
import net.minecraft.class_2096;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5257;
import net.minecraft.class_5258;
import net.minecraft.class_5267;

public class TargetHitTrigger extends class_4558<TargetHitTrigger.TriggerInstance> {
    public static final TargetHitTrigger INSTANCE = new TargetHitTrigger();
    static final class_2960 ID = new class_2960("tacz", "target_hit");

    public static void register() {
        class_174.method_767(INSTANCE);
    }

    @Override
    public class_2960 method_794() {
        return ID;
    }

    public void trigger(class_3222 player, double distance) {
        this.method_22510(player, instance -> instance.matches(distance));
    }

    @Override
    protected TriggerInstance method_27854(JsonObject json, class_5258 player, class_5257 context) {
        class_2096.class_2099 distance = class_2096.class_2099.method_9051(json.get("distance"));
        return new TriggerInstance(player, distance);
    }

    public static class TriggerInstance extends class_195 {
        private final class_2096.class_2099 distance;

        public TriggerInstance(class_5258 player, class_2096.class_2099 distance) {
            super(ID, player);
            this.distance = distance;
        }

        public boolean matches(double distance) {
            return this.distance.method_9047(distance);
        }

        @Override
        public JsonObject method_807(class_5267 context) {
            JsonObject json = super.method_807(context);
            if (!this.distance.method_9041()) {
                json.add("distance", this.distance.method_9036());
            }
            return json;
        }
    }
}