package com.tacz.guns.client.input;

import com.tacz.guns.client.gui.compat.ClothConfigScreen;
import com.tacz.guns.compat.cloth.MenuIntegration;
import com.tacz.guns.init.CompatRegistry;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_5250;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

import static com.tacz.guns.util.InputExtraCheck.isInGame;

@Environment(EnvType.CLIENT)
public class ConfigKey {
    public static final class_304 OPEN_CONFIG_KEY = new class_304("key.tacz.open_config.desc",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_T,
            "key.category.tacz");

    public static void onOpenConfig() {
        if (isInGame()) {
            class_746 player = class_310.method_1551().field_1724;
            if (player == null || player.method_7325()) {
                return;
            }
            if (!FabricLoader.getInstance().isModLoaded(CompatRegistry.CLOTH_CONFIG)) {
                class_2558 clickEvent = new class_2558(class_2558.class_2559.field_11749, ClothConfigScreen.CLOTH_CONFIG_URL);
                class_2568 hoverEvent = new class_2568(class_2568.class_5247.field_24342, class_2561.method_43471("gui.tacz.cloth_config_warning.download"));
                class_5250 component = class_2561.method_43471("gui.tacz.cloth_config_warning.tips").method_27694(style ->
                        style.method_27706(class_124.field_1078).method_27706(class_124.field_1073).method_10958(clickEvent).method_10949(hoverEvent));
                player.method_43496(component);
            } else {
                CompatRegistry.checkModLoad(CompatRegistry.CLOTH_CONFIG, () -> class_310.method_1551().method_1507(MenuIntegration.getConfigScreen(null)));
            }
        }
    }
}
