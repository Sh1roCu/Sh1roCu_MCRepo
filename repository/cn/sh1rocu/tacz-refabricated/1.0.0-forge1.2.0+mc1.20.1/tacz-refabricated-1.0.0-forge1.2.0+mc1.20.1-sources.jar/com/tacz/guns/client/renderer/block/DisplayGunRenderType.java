package com.tacz.guns.client.renderer.block;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4668;

/** 采用原版无方向光、带 alpha 裁剪的 shader；独立配置实体材质的深度与混合状态。 */
public class DisplayGunRenderType extends class_4668 {
    private static final Map<class_2960, class_1921> CACHE = new HashMap<>();

    public DisplayGunRenderType(String name, Runnable setup, Runnable clear) {
        super(name, setup, clear);
    }

    public static class_1921 emissive(class_2960 texture) {
        return CACHE.computeIfAbsent(texture, key -> class_1921.method_24049(
                "tacz_display_gun_emissive", class_290.field_1580, class_293.class_5596.field_27382, 256, true, false,
                class_1921.class_4688.method_23598()
                        .method_34578(field_29415)
                        .method_34577(new class_4683(texture, false, false))
                        .method_23615(field_21364)
                        .method_23603(field_21344)
                        .method_23614(new class_4684("tacz_display_gun_identity_uv",
                                RenderSystem::resetTextureMatrix, RenderSystem::resetTextureMatrix))
                        .method_23608(field_21383)
                        .method_23611(field_21385)
                        .method_23610(field_25643)
                        .method_23616(field_21349)
                        .method_23617(true)));
    }
}
