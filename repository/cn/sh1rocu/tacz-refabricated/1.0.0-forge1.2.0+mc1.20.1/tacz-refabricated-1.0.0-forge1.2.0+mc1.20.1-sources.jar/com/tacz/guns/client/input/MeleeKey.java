package com.tacz.guns.client.input;

import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

import static com.tacz.guns.util.InputExtraCheck.isInGame;

@Environment(EnvType.CLIENT)
public class MeleeKey {
    public static final class_304 MELEE_KEY = new class_304("key.tacz.melee.desc",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_V,
            "key.category.tacz");

    public static boolean onMeleeControllerPress(boolean isPress) {
        return isPress && onMeleePress();
    }

    public static boolean onMeleePress() {
        if (!isInGame()) {
            return false;
        }
        class_746 player = class_310.method_1551().field_1724;
        if (player == null || player.method_7325()) {
            return false;
        }
        IClientPlayerGunOperator operator = IClientPlayerGunOperator.fromLocalPlayer(player);
        if (!operator.isAim()) {
            operator.melee();
            return true;
        }
        return false;
    }
}
