package com.tacz.guns.client.model.bedrock;

import net.minecraft.class_4587;
import net.minecraft.class_4588;

public interface BedrockCube {
    void compile(class_4587.class_4665 pose, class_4588 consumer, int light, int overlay, float red, float green, float blue, float alpha);
}
