package com.tacz.guns.client.gui.components.refit;

import com.mojang.blaze3d.systems.RenderSystem;
import com.tacz.guns.client.gui.GunRefitScreen;
import javax.annotation.Nonnull;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;

public class RefitUnloadButton extends class_4185 implements IComponentTooltip {
    public RefitUnloadButton(int pX, int pY, class_4185.class_4241 pOnPress) {
        super(pX, pY, 8, 8, class_2561.method_43473(), pOnPress, field_40754);
    }

    @Override
    public void method_48579(@Nonnull class_332 graphics, int pMouseX, int pMouseY, float pPartialTick) {
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();

        int x = method_46426(), y = method_46427();
        if (method_25367()) {
            graphics.method_25293(GunRefitScreen.UNLOAD_TEXTURE, x, y, field_22758, field_22759, 0, 0, 80, 80, 160, 80);
        } else {
            graphics.method_25293(GunRefitScreen.UNLOAD_TEXTURE, x, y, field_22758, field_22759, 80, 0, 80, 80, 160, 80);
        }

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    @Override
    public void renderTooltip(Consumer<List<class_2561>> consumer) {
        if (this.method_25367()) {
            consumer.accept(Collections.singletonList(class_2561.method_43471("tooltip.tacz.refit.unload")));
        }
    }
}
