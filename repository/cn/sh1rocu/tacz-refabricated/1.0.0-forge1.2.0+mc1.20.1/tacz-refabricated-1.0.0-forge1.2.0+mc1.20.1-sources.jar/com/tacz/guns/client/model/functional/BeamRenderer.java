package com.tacz.guns.client.model.functional;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.tacz.guns.GunMod;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.item.IAttachment;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.client.model.bedrock.BedrockPart;
import com.tacz.guns.client.resource.GunDisplayInstance;
import com.tacz.guns.client.resource.index.ClientAttachmentIndex;
import com.tacz.guns.client.resource.pojo.display.LaserConfig;
import com.tacz.guns.compat.ar.ARCompat;
import com.tacz.guns.config.client.RenderConfig;
import com.tacz.guns.util.LaserColorUtil;
import com.tacz.guns.util.RenderHelper;
import javax.annotation.Nonnull;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4668;
import net.minecraft.class_765;
import net.minecraft.class_811;
import java.util.List;

public class BeamRenderer {
    public static final class_2960 LASER_BEAM_TEXTURE = new class_2960(GunMod.MOD_ID, "textures/entity/beam.png");
    private static final LaserConfig DEFAULT_LASER_CONFIG = new LaserConfig();

    public static void renderLaserBeam(class_1799 stack, class_4587 poseStack, class_811 transformType, @Nonnull List<BedrockPart> path, class_4597 bufferSource) {
        if (stack == null || !transformType.method_29998() && !(transformType == class_811.field_4320)) {
            return;
        }

		if (ARCompat.shouldAccelerate() && renderLaserBeamAccelerated(stack, poseStack, transformType, path, bufferSource)) {
			return;
		}

        renderLaserBeamUnaccelerated(stack, poseStack, transformType, path, bufferSource);
    }

    /** Resolve the legacy bone path before drawing an unaccelerated beam. */
    public static void renderLaserBeamUnaccelerated(class_1799 stack, class_4587 poseStack, class_811 transformType,
                                                     @Nonnull List<BedrockPart> path, class_4597 bufferSource) {
        if (stack == null || !transformType.method_29998() && transformType != class_811.field_4320) {
            return;
        }

        poseStack.method_22903();
        for (int i = 0; i < path.size(); ++i) {
            path.get(i).translateAndRotateAndScale(poseStack);
        }
        renderLaserBeamUnaccelerated(stack, poseStack, transformType, bufferSource);
        poseStack.method_22909();
    }

    /** Draw at an already resolved emitter pose, including SBM bone anchors. */
    public static void renderLaserBeamUnaccelerated(class_1799 stack, class_4587 poseStack, class_811 transformType,
                                                     class_4597 bufferSource) {
        if (stack == null || !transformType.method_29998() && transformType != class_811.field_4320) {
            return;
        }
        class_4588 builder = bufferSource.getBuffer(LaserBeamRenderState.getLaserBeam());
        LaserConfig laserConfig = getLaserConfig(stack);

        int color = LaserColorUtil.getLaserColor(stack, laserConfig);
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;

        stringVertex(transformType.method_29998() ? -laserConfig.getLength() : -laserConfig.getLengthThird(),
                transformType.method_29998() ? laserConfig.getWidth() : laserConfig.getWidthThird(),
                builder, poseStack.method_23760(), r, g, b, RenderConfig.ENABLE_LASER_FADE_OUT.get());
    }

	public static boolean renderLaserBeamAccelerated(class_1799 stack, class_4587 poseStack, class_811 transformType, @Nonnull List<BedrockPart> path) {
		return renderLaserBeamAccelerated(stack, poseStack, transformType, path, RenderHelper.getBufferSource(transformType));
	}

	public static boolean renderLaserBeamAccelerated(class_1799 stack, class_4587 poseStack, class_811 transformType, @Nonnull List<BedrockPart> path, class_4597 bufferSource) {
		// 获取VertexConsumer拓展方法
		var builder = bufferSource.getBuffer(LaserBeamRenderState.getLaserBeamEntity()); //替换为LASER_BEAM_ENTITY确保镭射和枪体在同一个format的同一层

		// 加速渲染的实现机制是每个VertexFormat一个bufferSource, 每个bufferSource维护一个Map<层编号, 层>
		// 因此如果镭射和枪体不在一个format, 则可能出现镭射无法正确被模板缓冲剔除掉
		// 因为枪体渲染完成之后已经擦除了模板缓冲区, 再到下一个format镭射开始渲染时就读取不到模板缓冲了

		// 如果不支持则回退
		if (!ARCompat.isAccelerated(builder)) {
			return false;
		}

		poseStack.method_22903();
		{
			for (int i = 0; i < path.size(); ++i) {
				path.get(i).translateAndRotateAndScale(poseStack);
			}

			var laserConfig = getLaserConfig(stack);

			// 这里直接调用及其容易触发类加载(编译期常量?), 所以封装到ARCompat中
			ARCompat.renderLaser(
					builder,
					transformType.method_29998() ? -laserConfig.getLength() : -laserConfig.getLengthThird(), //z
					transformType.method_29998() ? laserConfig.getWidth() : laserConfig.getWidthThird(), //width
					RenderConfig.ENABLE_LASER_FADE_OUT.get(), //fadeOut
					poseStack,
					//不透明的镭射颜色
					(255 << 24) | (LaserColorUtil.getLaserColor(stack, laserConfig) & 0xFF_FF_FF)
			);
		}
		poseStack.method_22909();

		// 渲染完成, 阻止后续原始方法的渲染
		return true;
	}

    private static LaserConfig getLaserConfig(class_1799 stack) {
        if (stack == null) {
            return DEFAULT_LASER_CONFIG;
        }

        if (stack.method_7909() instanceof IAttachment iAttachment) {
            return TimelessAPI.getClientAttachmentIndex(iAttachment.getAttachmentId(stack))
                    .map(ClientAttachmentIndex::getLaserConfig)
                    .orElse(DEFAULT_LASER_CONFIG);
        }

        if (stack.method_7909() instanceof IGun) {
            return TimelessAPI.getGunDisplay(stack)
                    .map(GunDisplayInstance::getLaserConfig)
                    .orElse(DEFAULT_LASER_CONFIG);
        }

        return DEFAULT_LASER_CONFIG;
    }

    private static void stringVertex(float z, float width, class_4588 pConsumer, class_4587.class_4665 pPose, int r, int g, int b, boolean fadeOut) {
        float halfWidth = width / 2;
        int endAlpha = fadeOut ? 0 : 255;
        int light = class_765.method_23687(15, 15);
    	pConsumer.method_22918(pPose.method_23761(), -halfWidth, -halfWidth, 0).method_1336(r, g, b, 255).method_22913(0, 0).method_22916(light).method_1344();
        pConsumer.method_22918(pPose.method_23761(), -halfWidth, halfWidth, 0).method_1336(r, g, b, 255).method_22913(0, 1).method_22916(light).method_1344();
        pConsumer.method_22918(pPose.method_23761(), -halfWidth, halfWidth, z).method_1336(r, g, b, endAlpha).method_22913(1, 1).method_22916(light).method_1344();
        pConsumer.method_22918(pPose.method_23761(), -halfWidth, -halfWidth, z).method_1336(r, g, b, endAlpha).method_22913(1, 0).method_22916(light).method_1344();

        pConsumer.method_22918(pPose.method_23761(), -halfWidth, halfWidth, 0).method_1336(r, g, b, 255).method_22913(0, 0).method_22916(light).method_1344();
        pConsumer.method_22918(pPose.method_23761(), halfWidth, halfWidth, 0).method_1336(r, g, b, 255).method_22913(0, 1).method_22916(light).method_1344();
        pConsumer.method_22918(pPose.method_23761(), halfWidth, halfWidth, z).method_1336(r, g, b, endAlpha).method_22913(1, 1).method_22916(light).method_1344();
        pConsumer.method_22918(pPose.method_23761(), -halfWidth, halfWidth, z).method_1336(r, g, b, endAlpha).method_22913(1, 0).method_22916(light).method_1344();

        pConsumer.method_22918(pPose.method_23761(), halfWidth, halfWidth, 0).method_1336(r, g, b, 255).method_22913(0, 0).method_22916(light).method_1344();
        pConsumer.method_22918(pPose.method_23761(), halfWidth, -halfWidth, 0).method_1336(r, g, b, 255).method_22913(0, 1).method_22916(light).method_1344();
        pConsumer.method_22918(pPose.method_23761(), halfWidth, -halfWidth, z).method_1336(r, g, b, endAlpha).method_22913(1, 1).method_22916(light).method_1344();
        pConsumer.method_22918(pPose.method_23761(), halfWidth, halfWidth, z).method_1336(r, g, b, endAlpha).method_22913(1, 0).method_22916(light).method_1344();

        pConsumer.method_22918(pPose.method_23761(), halfWidth, -halfWidth, 0).method_1336(r, g, b, 255).method_22913(0, 1).method_22916(light).method_1344();
        pConsumer.method_22918(pPose.method_23761(), -halfWidth, -halfWidth, 0).method_1336(r, g, b, 255).method_22913(0, 1).method_22916(light).method_1344();
        pConsumer.method_22918(pPose.method_23761(), -halfWidth, -halfWidth, z).method_1336(r, g, b, endAlpha).method_22913(1, 1).method_22916(light).method_1344();
        pConsumer.method_22918(pPose.method_23761(), halfWidth, -halfWidth, z).method_1336(r, g, b, endAlpha).method_22913(1, 0).method_22916(light).method_1344();
    }

    public static class LaserBeamRenderState extends class_4668 {
    	
        public LaserBeamRenderState(String pName, Runnable pSetupState, Runnable pClearState) {
			super(pName, pSetupState, pClearState);
		}

        public static final class_4668.class_4685  LIGHTNING_ADDITIVE_TRANSPARENCY = new class_4668.class_4685(
                "lightning_transparency", () -> {
                    RenderSystem.enableBlend();
                    RenderSystem.blendFuncSeparate(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE,
                            GlStateManager.class_4535.ONE, GlStateManager.class_4534.ZERO);
                }, () -> {
                    RenderSystem.disableBlend();
                    RenderSystem.defaultBlendFunc();
                });

        protected static final class_1921 LASER_BEAM = class_1921.method_24049("laser_beam", class_290.field_20888,
                class_293.class_5596.field_27382, 256, true, true,
                class_1921.class_4688.method_23598()
                        .method_34578(class_4668.field_29441)
                        .method_23607(field_22241)
                        .method_23615(LIGHTNING_ADDITIVE_TRANSPARENCY)
                        .method_23610(field_25643)
                        .method_23608(field_21383)
                        .method_23616(field_21349)
                        .method_23603(field_21345)
                        .method_34577(new class_4668.class_4683(LASER_BEAM_TEXTURE, false, false))
                        .method_23617(false));

		protected static final class_1921 LASER_BEAM_ENTITY = class_1921.method_24049("laser_beam_entity", class_290.field_1580,
				class_293.class_5596.field_27382, 256, true, true,
				class_1921.class_4688.method_23598()
						.method_34578(class_4668.field_38344)
						.method_23607(field_22241)
						.method_23615(LIGHTNING_ADDITIVE_TRANSPARENCY)
						.method_23610(field_25643)
						.method_23608(field_21383)
						.method_23611(field_21385)
						.method_23616(field_21349)
						.method_23603(field_21345)
						.method_34577(new class_4668.class_4683(LASER_BEAM_TEXTURE, false, false))
						.method_23617(false));
    	
        public static class_1921 getLaserBeam() {
            return LASER_BEAM;
        }

		public static class_1921 getLaserBeamEntity() {
			return LASER_BEAM_ENTITY;
		}
	}
}
