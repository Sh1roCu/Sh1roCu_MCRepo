package com.tacz.guns.client.input;

import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.api.item.IGun;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

import static com.tacz.guns.util.InputExtraCheck.isInGame;

@Environment(EnvType.CLIENT)
public class FireSelectKey {
    public static final class_304 FIRE_SELECT_KEY = new class_304("key.tacz.fire_select.desc",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_G,
            "key.category.tacz");

    public static boolean onFireSelectControllerPress(boolean isPress) {
        return isPress && onFireSelectPress();
    }

    public static boolean onFireSelectPress() {
        if (!isInGame()) {
            return false;
        }
        class_746 player = class_310.method_1551().field_1724;
        if (player == null || player.method_7325()) {
            return false;
        }
        if (IGun.mainHandHoldGun(player)) {
            IClientPlayerGunOperator.fromLocalPlayer(player).fireSelect();
            return true;
        }
        return false;
    }
}
