package com.tacz.guns.client.model.papi;

import com.tacz.guns.client.resource.pojo.display.gun.RangefinderManager;
import java.util.function.Function;
import net.minecraft.class_1799;

public class RangefinderPapi implements Function<class_1799, String> {
    public static final String NAME = "rangefinder";

    @Override
    public String apply(class_1799 stack) {
        return RangefinderManager.getText(stack);
    }
}
