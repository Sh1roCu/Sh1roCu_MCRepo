package com.tacz.guns.client.gameplay;

import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.api.entity.IGunOperator;
import com.tacz.guns.api.item.gun.AbstractGunItem;
import com.tacz.guns.client.animation.statemachine.GunAnimationConstant;
import com.tacz.guns.client.sound.SoundPlayManager;
import com.tacz.guns.network.message.ClientMessagePlayerUnloadGun;
import com.tacz.guns.resource.pojo.data.gun.Bolt;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class LocalPlayerUnload {
    private final LocalPlayerDataHolder data;
    private final class_746 player;

    public LocalPlayerUnload(LocalPlayerDataHolder data, class_746 player) {
        this.data = data;
        this.player = player;
    }

    public void unloadAmmo() {
        if (isLocalIdle()) {
            showCannotUnload();
            return;
        }
        class_1799 stack = player.method_6047();
        if (!(stack.method_7909() instanceof AbstractGunItem gun)) {
            showCannotUnload();
            return;
        }
        IGunOperator operator = IGunOperator.fromLivingEntity(player);
        if (isSyncIdle(operator)) {
            showCannotUnload();
            return;
        }
        var gunId = gun.getGunId(stack);
        var index = TimelessAPI.getCommonGunIndex(gunId).orElse(null);
        if (index == null) {
            showCannotUnload();
            return;
        }
        if (!index.canUnloadAmmo() || gun.useInventoryAmmo(stack)) {
            player.method_7353(class_2561.method_43471("message.tacz.unload.unsupported"), true);
            return;
        }
        if (gun.getCurrentAmmoCount(stack) <= 0
                && (index.getGunData().getBolt() == Bolt.OPEN_BOLT || !gun.hasBulletInBarrel(stack))) {
            player.method_7353(class_2561.method_43471("message.tacz.unload.no_ammo"), true);
            return;
        }

        data.lockState();
        data.autoReloadSuppressed = true;
        data.chargeProgress = 0;
        TimelessAPI.getGunDisplay(stack).ifPresent(display -> {
            SoundPlayManager.stopPlayGunSound();
            var stateMachine = display.getAnimationStateMachine();
            if (stateMachine != null) {
                stateMachine.trigger(GunAnimationConstant.INPUT_INSPECT_BREAK_OUT);
            }
        });
        if (class_310.method_1551().field_1761 != null) {
            class_310.method_1551().field_1761.method_2911();
        }
        ClientPlayNetworking.send(new ClientMessagePlayerUnloadGun(player.method_31548().field_7545, gunId));
    }

    private void showCannotUnload() {
        player.method_7353(class_2561.method_43471("message.tacz.unload.cannot"), true);
    }

    private boolean isSyncIdle(IGunOperator operator) {
        return operator.getSynReloadState().getStateType().isReloading() || operator.getSynIsBolting()
                || operator.getSynShootCoolDown() != 0 || operator.getSynDrawCoolDown() != 0
                || operator.getSynMeleeCoolDown() != 0 || operator.getSynSprintTime() > 0
                || IClientPlayerGunOperator.fromLocalPlayer(player).getClientShootCoolDown() > 0;
    }

    private boolean isLocalIdle() {
        return !player.method_5805() || player.method_7325() || data.clientStateLock
                || data.isCharging || data.isBolting || data.clientReloadStarting
                || !data.isShootRecorded || data.hasPendingShoot()
                || data.clientIsAiming || data.clientAimingProgress > 0 || player.method_5624();
    }
}
