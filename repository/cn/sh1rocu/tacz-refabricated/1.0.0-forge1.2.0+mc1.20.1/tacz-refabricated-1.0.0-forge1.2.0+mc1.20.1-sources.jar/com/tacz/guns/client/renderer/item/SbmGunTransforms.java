package com.tacz.guns.client.renderer.item;

import com.tacz.guns.client.model.DisplayGunModelInstance;
import com.tacz.guns.client.model.ExternalGunModel;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Vector3f;

/** 根据 SBM 骨骼定义构造外部视角定位矩阵，不访问 TACZ 的旧模型实例。 */
public class SbmGunTransforms {
    private SbmGunTransforms() {}

    public static void applyFixed(class_4587 pose, ExternalGunModel external, Vector3f configuredScale) {
        apply(pose, external, "fixed", configuredScale);
    }

    public static void applyGround(class_4587 pose, ExternalGunModel external, Vector3f configuredScale) {
        apply(pose, external, "ground", configuredScale);
    }

    public static void applyThirdPerson(class_4587 pose, ExternalGunModel external, Vector3f configuredScale) {
        apply(pose, external, "thirdperson_hand", configuredScale);
    }

    public static void apply(class_4587 pose, ExternalGunModel external, String anchor, Vector3f configuredScale) {
        Vector3f scale = configuredScale == null ? new Vector3f(1, 1, 1) : configuredScale;
        // BedrockGunModel 的模型空间与 SBM 烘焙空间相差一个固定的轴变换 B。
        // 将旧外部锚点语义在 SBM 坐标内表示为 B * positioning * displayScale * B。
        bedrockToSbm(pose);
        pose.method_22904(0, 1.5, 0);
        var bones = external.model().bones();
        int index = external.model().getIndex(anchor);
        while (index >= 0) {
            var bone = bones[index];
            var rotation = bone.bindEulerRotation();
            pose.method_22907(class_7833.field_40714.rotation(rotation.x()));
            pose.method_22907(class_7833.field_40716.rotation(rotation.y()));
            pose.method_22907(class_7833.field_40717.rotation(rotation.z()));
            if (bone.parentIndex() >= 0) {
                pose.method_46416(bone.bindX() * scale.x() / 16.0F,
                        bone.bindY() * scale.y() / 16.0F,
                        -bone.bindZ() * scale.z() / 16.0F);
            } else {
                pose.method_46416(bone.pivotX() * scale.x(), bone.pivotY() * scale.y(),
                        -bone.pivotZ() * scale.z());
            }
            index = bone.parentIndex();
        }
        if (configuredScale != null) {
            pose.method_22905(scale.x(), scale.y(), scale.z());
        }
        pose.method_22904(0, -1.5, 0);
        bedrockToSbm(pose);
    }

    public static void bedrockToSbm(class_4587 pose) {
        pose.method_22904(0, 1.5, 0);
        pose.method_22905(-1, -1, 1);
    }

    public static void applyBonePivot(class_4587 pose, DisplayGunModelInstance instance, int index) {
        instance.mulGlobalTransform(pose, index);
        var bone = instance.getBone(index).definition();
        pose.method_46416(bone.pivotX(), bone.pivotY(), bone.pivotZ());
    }
}
