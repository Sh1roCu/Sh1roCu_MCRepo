package com.tacz.guns.block;

import com.tacz.guns.api.DefaultAssets;
import com.tacz.guns.api.item.IAmmoBox;
import com.tacz.guns.block.entity.AmmoStorageBlockEntity;
import com.tacz.guns.init.ModBlocks;
import com.tacz.guns.util.AmmoStorageHelper;
import com.tacz.guns.util.AmmoStorageInteractionHelper;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2487;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_3965;
import net.minecraft.class_8567;

public class AmmoStorageBlock extends class_2237 {
    public static final class_2753 FACING = class_2741.field_12481;
    public static final int IRON_CAPACITY_STACKS = 216;
    public static final int GOLD_CAPACITY_STACKS = 432;
    public static final int DIAMOND_CAPACITY_STACKS = 864;

    private final int capacityStacks;

    public AmmoStorageBlock() {
        this(IRON_CAPACITY_STACKS);
    }

    public AmmoStorageBlock(int capacityStacks) {
        super(class_2251.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_11533).method_9632(2.0F).method_9624().method_50012(class_3619.field_15971));
        this.capacityStacks = capacityStacks;
        method_9590(field_10647.method_11664().method_11657(FACING, class_2350.field_11043));
    }

    public int getCapacityStacks() {
        return capacityStacks;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new AmmoStorageBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        return method_9564().method_11657(FACING, context.method_8042().method_10153());
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_2586 blockEntity = level.method_8321(pos);
        if (!(blockEntity instanceof AmmoStorageBlockEntity storage)) {
            return class_1269.field_5811;
        }
        class_1799 held = player.method_5998(hand);
        if (held.method_7909() instanceof IAmmoBox ammoBox) {
            if (level.method_8608()) {
                return class_1269.field_5812;
            }
            if (player.method_5715()) {
                return AmmoStorageInteractionHelper.unloadAmmoBox(storage, held, ammoBox, player);
            }
            return fillAmmoBox(storage, held, ammoBox, player);
        }
        if (level.method_8608()) {
            return class_1269.field_5812;
        }
        if (player instanceof class_3222 serverPlayer) {
            serverPlayer.method_17355(storage);
        }
        return class_1269.field_21466;
    }

    private class_1269 fillAmmoBox(AmmoStorageBlockEntity storage, class_1799 boxStack, IAmmoBox ammoBox, class_1657 player) {
        class_2960 ammoId = ammoBox.getAmmoId(boxStack);
        if (ammoId.equals(DefaultAssets.EMPTY_AMMO_ID)) {
            player.method_7353(class_2561.method_43471("message.tacz.ammo_storage.ammo_box_empty"), true);
            return class_1269.field_21466;
        }
        int current = ammoBox.getAmmoCount(boxStack);
        int levelMultiplier = ammoBox.getAmmoLevel(boxStack) + 1;
        int max = AmmoStorageHelper.getStackSize(AmmoStorageHelper.createAmmoStack(ammoId, 1)) * com.tacz.guns.config.sync.SyncConfig.AMMO_BOX_STACK_SIZE.get() * levelMultiplier;
        int need = Math.max(0, max - current);
        if (need <= 0) {
            return class_1269.field_21466;
        }
        class_1799 extracted = storage.extractAmmo(ammoId, need, false);
        if (extracted.method_7960()) {
            player.method_7353(class_2561.method_43471("message.tacz.ammo_storage.no_ammo_box_stock"), true);
            return class_1269.field_21466;
        }
        ammoBox.setAmmoCount(boxStack, current + extracted.method_7947());
        player.method_7353(class_2561.method_43469("message.tacz.ammo_storage.picked", extracted.method_7964(), extracted.method_7947()), true);
        player.method_37908().method_8396(null, player.method_24515(), class_3417.field_14862, class_3419.field_15248, 0.8F, 1.0F);
        return class_1269.field_21466;
    }

    @Override
    public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder) {
        class_2586 blockEntity = builder.method_51876(class_181.field_1228);
        class_1799 stack = new class_1799(state.method_26204());
        if (blockEntity instanceof AmmoStorageBlockEntity storage) {
            class_2487 tag = storage.method_38244();
            if (!tag.method_33133()) {
                class_1747.method_38073(stack, ModBlocks.AMMO_STORAGE_BE, tag);
            }
        }
        return Collections.singletonList(stack);
    }

    @Override
    public boolean method_9498(class_2680 state) {
        return true;
    }

    @Override
    public int method_9572(class_2680 state, class_1937 level, class_2338 pos) {
        class_2586 blockEntity = level.method_8321(pos);
        if (blockEntity instanceof AmmoStorageBlockEntity storage) {
            return storage.getComparatorSignal();
        }
        return 0;
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }
}
