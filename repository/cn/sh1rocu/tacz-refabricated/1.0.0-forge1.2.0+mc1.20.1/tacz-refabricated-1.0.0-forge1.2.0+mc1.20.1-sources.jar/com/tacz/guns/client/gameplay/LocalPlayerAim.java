package com.tacz.guns.client.gameplay;

import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.entity.IGunOperator;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.network.message.ClientMessagePlayerAim;
import com.tacz.guns.resource.modifier.custom.AdsModifier;
import com.tacz.guns.resource.pojo.data.gun.GunData;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import com.tacz.guns.util.time.GunTime;

public class LocalPlayerAim {
    private final LocalPlayerDataHolder data;
    private final class_746 player;

    public LocalPlayerAim(LocalPlayerDataHolder data, class_746 player) {
        this.data = data;
        this.player = player;
    }

    public void aim(boolean isAim) {
        // 暂定为主手
        class_1799 mainHandItem = player.method_6047();
        if (!(mainHandItem.method_7909() instanceof IGun iGun)) {
            return;
        }
        class_2960 gunId = iGun.getGunId(mainHandItem);
        TimelessAPI.getClientGunIndex(gunId).ifPresent(gunIndex -> {
            if (isAim && shouldBlockAim(gunIndex.getGunData())) {
                if (data.clientIsAiming) {
                    data.clientIsAiming = false;
                    ClientPlayNetworking.send(new ClientMessagePlayerAim(false));
                }
                return;
            }
            data.clientIsAiming = isAim;
            // 发送切换开火模式的数据包，通知服务器
            ClientPlayNetworking.send(new ClientMessagePlayerAim(isAim));
        });
    }

    public float getClientAimingProgress(float partialTicks) {
        return class_3532.method_16439(partialTicks, LocalPlayerDataHolder.oldAimingProgress, data.clientAimingProgress);
    }

    public boolean isAim() {
        return data.clientIsAiming;
    }

    public void tickAimingProgress() {
        class_1799 mainHandItem = player.method_6047();
        // 如果主手物品不是枪械，则取消瞄准状态并将 aimingProgress 归零，返回。
        if (!(mainHandItem.method_7909() instanceof IGun iGun)) {
            data.clientAimingProgress = 0;
            LocalPlayerDataHolder.oldAimingProgress = 0;
            return;
        }
        // 如果正在收枪，则不能瞄准
        if (GunTime.nowMillis() - data.clientDrawTimestamp < 0) {
            data.clientIsAiming = false;
        }
        class_2960 gunId = iGun.getGunId(mainHandItem);
        TimelessAPI.getCommonGunIndex(gunId).ifPresentOrElse(index -> {
            if (shouldBlockAim(index.getGunData())) {
                data.clientIsAiming = false;
            }
            float alphaProgress = this.getAlphaProgress(index.getGunData());
            this.aimProgressCalculate(alphaProgress);
        }, () -> {
            data.clientAimingProgress = 0;
            LocalPlayerDataHolder.oldAimingProgress = 0;
        });
    }

    private void aimProgressCalculate(float alphaProgress) {
        LocalPlayerDataHolder.oldAimingProgress = data.clientAimingProgress;
        if (data.clientIsAiming) {
            // 处于执行瞄准状态，增加 aimingProgress
            data.clientAimingProgress += alphaProgress;
            if (data.clientAimingProgress > 1) {
                data.clientAimingProgress = 1;
            }
        } else {
            // 处于取消瞄准状态，减小 aimingProgress
            data.clientAimingProgress -= alphaProgress;
            if (data.clientAimingProgress < 0) {
                data.clientAimingProgress = 0;
            }
        }
        data.clientAimingTimestamp = GunTime.nowMillis();
    }

    private boolean shouldBlockAim(GunData gunData) {
        IGunOperator operator = IGunOperator.fromLivingEntity(this.player);
        boolean isReloading = operator.getSynReloadState().getStateType().isReloading();
        boolean isReloadStarting = data.clientReloadStarting;
        boolean isBolting = data.isBolting || operator.getSynIsBolting();
        return data.isTimedStateLocked() || (gunData.isForceAimExitOnReload() && (isReloading || isReloadStarting)) ||
                (gunData.isForceAimExitOnBolt() && isBolting);
    }

    private float getAlphaProgress(GunData gunData) {
        float aimTime = gunData.getAimTime();
        IGunOperator operator = IGunOperator.fromLivingEntity(this.player);
        if (operator.getCacheProperty() != null) {
            aimTime = operator.getCacheProperty().<Float>getCache(AdsModifier.ID);
        }
        aimTime = Math.max(0, aimTime);
        return (GunTime.nowMillis() - data.clientAimingTimestamp + 1) / (aimTime * 1000);
    }
}
