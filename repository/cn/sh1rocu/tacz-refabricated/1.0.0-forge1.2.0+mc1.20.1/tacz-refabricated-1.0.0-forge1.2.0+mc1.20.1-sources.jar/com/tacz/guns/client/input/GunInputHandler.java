package com.tacz.guns.client.input;

import cn.sh1rocu.tacz.api.event.InputEvent;
import com.tacz.guns.client.gui.GunRefitScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import java.util.List;

import static com.tacz.guns.util.InputExtraCheck.isInGame;

@Environment(EnvType.CLIENT)
public final class GunInputHandler {
    private static final List<PressBinding> PRESS_BINDINGS = List.of(
            new PressBinding(UnloadKey.UNLOAD_KEY, UnloadKey::onUnloadPress),
            new PressBinding(AimKey.AIM_KEY, AimKey::onAimPress),
            new PressBinding(CrawlKey.CRAWL_KEY, CrawlKey::onCrawlPress),
            new PressBinding(ReloadKey.RELOAD_KEY, ReloadKey::onReloadPress),
            new PressBinding(InspectKey.INSPECT_KEY, InspectKey::onInspectPress),
            new PressBinding(FireSelectKey.FIRE_SELECT_KEY, FireSelectKey::onFireSelectPress),
            new PressBinding(MeleeKey.MELEE_KEY, MeleeKey::onMeleePress),
            new PressBinding(ZoomKey.ZOOM_KEY, ZoomKey::onZoomPress),
            new PressBinding(InteractKey.INTERACT_KEY, InteractKey::onInteractPress),
            new PressBinding(RefitKey.REFIT_KEY, RefitKey::onRefitPress),
            new PressBinding(ConfigKey.OPEN_CONFIG_KEY, ConfigKey::onOpenConfig)
    );

    private GunInputHandler() {
    }

    public static void registerKeyMappings() {
        for (PressBinding binding : PRESS_BINDINGS) {
            KeyBindingHelper.registerKeyBinding(binding.keyMapping());
        }
        KeyBindingHelper.registerKeyBinding(ShootKey.SHOOT_KEY);
    }

    public static void onKeyPress(InputEvent.Key event) {
        class_3675.class_306 key = class_3675.method_15985(event.getKey(), event.getScanCode());
        if (event.getAction() == GLFW.GLFW_RELEASE) {
            onRelease(key);
        }
        if (event.getAction() != GLFW.GLFW_PRESS) {
            return;
        }
        if (!closeRefitScreen(key)) {
            onPress(key);
        }
    }

    public static void onMousePress(InputEvent.MouseButton.Post event) {
        class_3675.class_306 key = class_3675.class_307.field_1672.method_1447(event.getButton());
        if (event.getAction() == GLFW.GLFW_RELEASE) {
            onRelease(key);
        }
        if (event.getAction() == GLFW.GLFW_PRESS) {
            onPress(key);
        }
    }

    public static void onMousePressPre(InputEvent.MouseButton.Pre event) {
        if (event.getAction() == GLFW.GLFW_PRESS
                && closeRefitScreen(class_3675.class_307.field_1672.method_1447(event.getButton()))) {
            // 消费关闭界面的点击，避免同一次输入在 Post 阶段重新打开界面。
            event.setCanceled(true);
        }
    }

    private static void onPress(class_3675.class_306 key) {
        for (PressBinding binding : PRESS_BINDINGS) {
            // 某个动作可能打开界面，后续动作不能继续穿透到游戏中。
            if (!isInGame()) {
                return;
            }
            if (key != null && KeyBindingHelper.getBoundKeyOf(binding.keyMapping()).equals(key)) {
                binding.action().run();
                // 即使卸弹条件不满足，也不能让 Alt+R 穿透成普通换弹。
                if (binding.keyMapping() == UnloadKey.UNLOAD_KEY) {
                    return;
                }
            }
        }
    }

    private static boolean closeRefitScreen(class_3675.class_306 key) {
        class_310 mc = class_310.method_1551();
        if (mc.method_18506() != null || !mc.method_1569()
                || !(mc.field_1755 instanceof GunRefitScreen refitScreen)) {
            return false;
        }
        class_304 refitKey = RefitKey.REFIT_KEY;
        if (key != class_3675.field_16237 && key.equals(KeyBindingHelper.getBoundKeyOf(refitKey))
            /* && refitKey.getKeyModifier().isActive(refitKey.getKeyConflictContext())*/) {
            refitScreen.method_25419();
            return true;
        }
        return false;
    }

    private static void onRelease(class_3675.class_306 key) {
        for (PressBinding binding : PRESS_BINDINGS) {
            if (key.equals(KeyBindingHelper.getBoundKeyOf(binding.keyMapping()))) {
                binding.keyMapping().method_23481(false);
            }
        }
        if (key.equals(KeyBindingHelper.getBoundKeyOf(ShootKey.SHOOT_KEY))) {
            ShootKey.SHOOT_KEY.method_23481(false);
        }
    }

    private record PressBinding(class_304 keyMapping, Runnable action) {
    }
}
