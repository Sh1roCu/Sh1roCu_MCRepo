package com.tacz.guns.api.item.builder;

import com.tacz.guns.api.DefaultAssets;
import com.tacz.guns.api.item.IBlock;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2960;

public final class BlockItemBuilder {
    private int count = 1;
    private class_2960 blockId = DefaultAssets.DEFAULT_BLOCK_ID;
    private final class_1935 blockItem;

    private BlockItemBuilder(class_1935 blockItem) {
        this.blockItem = blockItem;
    }

    public static BlockItemBuilder create(class_1935 blockItem) {
        return new BlockItemBuilder(blockItem);
    }

    public BlockItemBuilder setCount(int count) {
        this.count = Math.max(count, 1);
        return this;
    }

    public BlockItemBuilder setId(class_2960 id) {
        this.blockId = id;
        return this;
    }

    public class_1799 build() {
        class_1799 block = new class_1799(blockItem, this.count);
        if (block.method_7909() instanceof IBlock iBlock) {
            iBlock.setBlockId(block, this.blockId);
        }
        return block;
    }
}
