package com.tacz.guns.client.renderer.block;

import com.tacz.guns.block.TargetBlock;
import com.tacz.guns.block.entity.StatueBlockEntity;
import com.tacz.guns.client.model.bedrock.BedrockModel;
import com.tacz.guns.client.resource.InternalAssetLoader;
import com.tacz.guns.config.client.RenderConfig;
import com.tacz.guns.util.time.GunTime;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;

public class StatueRenderer implements class_827<StatueBlockEntity> {
    public StatueRenderer(class_5614.class_5615 context) {
    }

    public static Optional<BedrockModel> getModel() {
        return InternalAssetLoader.getBedrockModel(InternalAssetLoader.STATUE_MODEL_LOCATION);
    }

    @Override
    public void render(StatueBlockEntity blockEntity, float partialTick, class_4587 poseStack, class_4597 bufferIn, int combinedLightIn, int combinedOverlayIn) {
        getModel().ifPresent(model -> {
            class_1937 level = blockEntity.method_10997();
            if (level == null) {
                return;
            }

            poseStack.method_22903();
            {
                class_2680 blockState = blockEntity.method_11010();
                class_2350 facing = blockState.method_11654(TargetBlock.FACING);

                poseStack.method_22904(0.5, 1.5, 0.5);

                poseStack.method_22907(class_7833.field_40715.rotationDegrees((facing.method_10161() + 2) % 4 * 90));
                poseStack.method_22907(class_7833.field_40717.rotationDegrees(180));

                class_1921 renderType = RenderConfig.BLOCK_ENTITY_TRANSLUCENT.get() ?
                        class_1921.method_23580(getTextureLocation()) :
                        class_1921.method_23576(getTextureLocation());
                model.render(poseStack, class_811.field_4315, renderType, combinedLightIn, combinedOverlayIn);

                poseStack.method_22905(0.5f, 0.5f, 0.5f);
                poseStack.method_22904(0, -0.875, -1.2);
                poseStack.method_22907(class_7833.field_40718.rotationDegrees(180));

                double offset = Math.sin(GunTime.nowMillis() / 500.0) * 0.1;
                poseStack.method_22904(0, offset, 0);

                class_1799 stack = blockEntity.getGunItem();

                class_310.method_1551().method_1480().method_23178(
                        stack,
                        class_811.field_4319,
                        class_765.method_23687(15, 15),
                        class_4608.field_21444,
                        poseStack,
                        bufferIn,
                        level,
                        0
                );
            }
            poseStack.method_22909();
        });
    }

    public static class_2960 getTextureLocation() {
        return InternalAssetLoader.STATUE_TEXTURE_LOCATION;
    }

    @Override
    public int method_33893() {
        return RenderConfig.TARGET_RENDER_DISTANCE.get();
    }

    @Override
    public boolean shouldRenderOffScreen(StatueBlockEntity blockEntity) {
        return true;
    }

    @Override
    public boolean shouldRender(StatueBlockEntity pBlockEntity, class_243 pCameraPos) {
        return class_243.method_24953(pBlockEntity.method_11016().method_10084()).method_24802(pCameraPos, this.method_33893());
    }
}
