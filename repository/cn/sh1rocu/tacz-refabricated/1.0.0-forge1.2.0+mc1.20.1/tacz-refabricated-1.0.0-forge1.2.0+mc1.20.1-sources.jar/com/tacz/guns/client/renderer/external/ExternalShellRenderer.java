package com.tacz.guns.client.renderer.external;

import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.client.model.BedrockAmmoModel;
import com.tacz.guns.client.model.DisplayGunModelInstance;
import com.tacz.guns.client.renderer.item.SbmGunTransforms;
import com.tacz.guns.client.resource.GunDisplayInstance;
import com.tacz.guns.client.resource.pojo.display.gun.ShellEjection;
import com.tacz.guns.compat.iris.IrisCompat;
import com.tacz.guns.resource.pojo.data.gun.GunData;
import com.tacz.guns.util.time.GunTime;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.concurrent.ConcurrentLinkedDeque;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;

public final class ExternalShellRenderer {
    private static final int MAX_SHELLS = 128;
    private final ConcurrentLinkedDeque<Shell> shells = new ConcurrentLinkedDeque<>();

    public void addShell(int origin, Vector3f randomVelocity) {
        if (origin < 0) return;
        if (shells.size() >= MAX_SHELLS) shells.pollFirst();
        var randomOffset = new Vector3f((float) (Math.random() * randomVelocity.x()),
                (float) (Math.random() * randomVelocity.y()), (float) (Math.random() * randomVelocity.z()));
        shells.offerLast(new Shell(origin, randomOffset));
    }

    public void render(GunDisplayInstance display, GunData gunData, DisplayGunModelInstance instance,
                       class_4587 modelPose, class_4597 buffers, int packedLight, int packedOverlay) {
        if (IrisCompat.isRenderShadow()) return;
        ShellEjection ejection = display.getShellEjection();
        if (ejection == null) {
            shells.clear();
            return;
        }
        long now = GunTime.nowMillis();
        long epoch = GunTime.epoch();
        long lifetime = (long) (ejection.getLivingTime() * 1000);
        shells.removeIf(shell -> shell.epoch != epoch || now - shell.timestamp > lifetime);
        if (shells.isEmpty()) return;

        BedrockAmmoModel model = display.getShellModel();
        class_2960 texture = display.getShellTextureLocation();
        if (model == null || texture == null) {
            var ammoIndex = TimelessAPI.getClientAmmoIndex(gunData.getAmmoId()).orElse(null);
            if (ammoIndex == null) return;
            model = ammoIndex.getShellModel();
            texture = ammoIndex.getShellTextureLocation();
        }
        if (model == null || texture == null) return;

        int[] origins = instance.shellOriginBones();
        for (Shell shell : shells) {
            if (shell.pose == null) {
                if (shell.origin >= origins.length) continue;
                modelPose.method_22903();
                SbmGunTransforms.applyBonePivot(modelPose, instance, origins[shell.origin]);
                // 弹壳资源与运动参数使用基岩模型坐标轴。
                modelPose.method_22905(-1, -1, 1);
                shell.pose = new Matrix4f(modelPose.method_23760().method_23761());
                shell.normal = new Matrix3f(modelPose.method_23760().method_23762());
                modelPose.method_22909();
            }
            renderShell(shell, now, ejection, model, texture, buffers, packedLight, packedOverlay);
        }
    }

    private static void renderShell(Shell shell, long now, ShellEjection ejection, BedrockAmmoModel model,
                                    class_2960 texture, class_4597 buffers,
                                    int packedLight, int packedOverlay) {
        class_4587 pose = new class_4587();
        pose.method_23760().method_23761().set(shell.pose);
        pose.method_23760().method_23762().set(shell.normal);
        double time = (now - shell.timestamp) / 1000.0;
        Vector3f velocity = ejection.getInitialVelocity();
        Vector3f acceleration = ejection.getAcceleration();
        Vector3f angularVelocity = ejection.getAngularVelocity();
        double x = (velocity.x() + shell.randomOffset.x()) * time + 0.5 * acceleration.x() * time * time;
        double y = (velocity.y() + shell.randomOffset.y()) * time + 0.5 * acceleration.y() * time * time;
        double z = (velocity.z() + shell.randomOffset.z()) * time + 0.5 * acceleration.z() * time * time;
        pose.method_22904(-x, -y, z);
        pose.method_22907(class_7833.field_40713.rotationDegrees((float) (time * angularVelocity.x())));
        pose.method_22907(class_7833.field_40715.rotationDegrees((float) (time * angularVelocity.y())));
        pose.method_22907(class_7833.field_40718.rotationDegrees((float) (time * angularVelocity.z())));
        pose.method_22904(0, -1.5, 0);
        model.render(pose, class_811.field_4320, class_1921.method_23576(texture),
                packedLight, packedOverlay, buffers);
    }

    private static final class Shell {
        final int origin;
        final long timestamp = GunTime.nowMillis();
        final long epoch = GunTime.epoch();
        final Vector3f randomOffset;
        Matrix4f pose;
        Matrix3f normal;

        Shell(int origin, Vector3f randomOffset) {
            this.origin = origin;
            this.randomOffset = randomOffset;
        }
    }
}
