package com.tacz.guns.api.event.common;

import cn.sh1rocu.tacz.api.LogicalSide;
import cn.sh1rocu.tacz.api.event.BaseEvent;
import cn.sh1rocu.tacz.api.event.ICancellableEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

import static cn.sh1rocu.tacz.TaCZFabric.*;

/**
 * 枪械单次击发的事件。{@link GunShootEvent} 每次扣动扳机触发一次，连发则可能多次触发本事件。
 * 服务端在弹药校验和扣弹前触发，可以取消。成功击发通知请监听 {@link GunFirePostEvent}。
 */
public class GunFireEvent extends BaseEvent implements KubeJSGunEventPoster<GunFireEvent>, ICancellableEvent {
    private final class_1309 shooter;
    private final class_1799 gunItemStack;
    private final LogicalSide logicalSide;

    public static final Event<Callback> CALLBACK = EventFactory.createWithPhases(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.post(event);
        }
    }, HIGHEST, HIGH, Event.DEFAULT_PHASE, LOW, LOWEST);

    public interface Callback {
        void post(GunFireEvent event);
    }

    public GunFireEvent(class_1309 shooter, class_1799 gunItemStack, LogicalSide side) {
        this.shooter = shooter;
        this.gunItemStack = gunItemStack;
        this.logicalSide = side;
        postEventToKubeJS(this);
    }

    public class_1309 getShooter() {
        return shooter;
    }

    public class_1799 getGunItemStack() {
        return gunItemStack;
    }

    public LogicalSide getLogicalSide() {
        return logicalSide;
    }
}
