package com.tacz.guns.client.tooltip;

import com.tacz.guns.inventory.tooltip.AmmoStorageTooltip;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4597;
import net.minecraft.class_5684;
import org.joml.Matrix4f;

public class ClientAmmoStorageTooltip implements class_5684 {
    private static final int ENTRY_HEIGHT = 28;
    private final AmmoStorageTooltip tooltip;

    public ClientAmmoStorageTooltip(AmmoStorageTooltip tooltip) {
        this.tooltip = tooltip;
    }

    @Override
    public int method_32661() {
        int height = tooltip.getEntries().size() * ENTRY_HEIGHT;
        return tooltip.getHidden() > 0 ? height + 10 : height;
    }

    @Override
    public int method_32664(class_327 font) {
        int width = 0;
        for (AmmoStorageTooltip.Entry entry : tooltip.getEntries()) {
            width = Math.max(width, font.method_27525(entry.getAmmoName()));
            width = Math.max(width, font.method_27525(getCount(entry)));
        }
        if (tooltip.getHidden() > 0) {
            width = Math.max(width, font.method_27525(getHidden()));
        }
        return width + 22;
    }

    @Override
    public void method_32665(class_327 font, int x, int y, Matrix4f matrix, class_4597.class_4598 bufferSource) {
        int yOffset = y;
        for (AmmoStorageTooltip.Entry entry : tooltip.getEntries()) {
            font.method_30882(entry.getAmmoName(), x + 20, yOffset + 4, 0xffaa00, false, matrix, bufferSource, class_327.class_6415.field_33993, 0, 0xF000F0);
            font.method_30882(getCount(entry), x + 20, yOffset + 15, 0x666666, false, matrix, bufferSource, class_327.class_6415.field_33993, 0, 0xF000F0);
            yOffset += ENTRY_HEIGHT;
        }
        if (tooltip.getHidden() > 0) {
            font.method_30882(getHidden(), x, yOffset, 0x9e9e9e, false, matrix, bufferSource, class_327.class_6415.field_33993, 0, 0xF000F0);
        }
    }

    @Override
    public void method_32666(class_327 font, int x, int y, class_332 guiGraphics) {
        int yOffset = y;
        for (AmmoStorageTooltip.Entry entry : tooltip.getEntries()) {
            guiGraphics.method_51427(entry.ammo(), x, yOffset + 5);
            yOffset += ENTRY_HEIGHT;
        }
    }

    private static class_2561 getCount(AmmoStorageTooltip.Entry entry) {
        return class_2561.method_43469("tooltip.tacz.ammo_box.count", entry.count());
    }

    private class_2561 getHidden() {
        return class_2561.method_43469("container.shulkerBox.more", tooltip.getHidden()).method_27692(class_124.field_1056);
    }
}
