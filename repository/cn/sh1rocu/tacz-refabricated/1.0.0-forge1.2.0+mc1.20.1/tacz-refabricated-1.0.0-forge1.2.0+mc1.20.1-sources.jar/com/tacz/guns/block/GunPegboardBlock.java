package com.tacz.guns.block;

import com.tacz.guns.block.entity.GunPegboardBlockEntity;
import com.tacz.guns.config.util.GunPegboardItemConfigRead;
import com.tacz.guns.item.GunPegboardItem;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1768;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_181;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_8567;

public class GunPegboardBlock extends class_2237 {
    public static final class_2753 FACING = class_2741.field_12481;
    public static final class_2746 DYED = class_2746.method_11825("dyed");
    public static final class_2754<PegboardShape> SHAPE = class_2754.method_11850("shape", PegboardShape.class);
    private static final class_265 NORTH_SHAPE = class_2248.method_9541(0, 0, 13, 16, 16, 16);
    private static final class_265 SOUTH_SHAPE = class_2248.method_9541(0, 0, 0, 16, 16, 3);
    private static final class_265 WEST_SHAPE = class_2248.method_9541(13, 0, 0, 16, 16, 16);
    private static final class_265 EAST_SHAPE = class_2248.method_9541(0, 0, 0, 3, 16, 16);
    private final boolean glowing;

    public GunPegboardBlock() {
        this(false);
    }

    public GunPegboardBlock(boolean glowing) {
        super(class_2251.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_11533).method_9629(5.0F, 6.0F).method_22488().method_9631(state -> glowing ? 10 : 0).method_50012(class_3619.field_15971));
        this.glowing = glowing;
        method_9590(field_10647.method_11664().method_11657(FACING, class_2350.field_11043).method_11657(DYED, false).method_11657(SHAPE, PegboardShape.STRAIGHT));
    }

    public boolean isGlowing() {
        return glowing;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, DYED, SHAPE);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new GunPegboardBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2680 state;
        class_2350 clickedFace = context.method_8038();
        class_2338 target = context.method_8037().method_10093(clickedFace.method_10153());
        class_2680 targetState = context.method_8045().method_8320(target);
        if (!context.method_7717() && targetState.method_26204() instanceof GunPegboardBlock) {
            class_2350 targetFacing = targetState.method_11654(FACING);
            if (GunPegboardSlotHelper.hasCorner(targetState)
                    && clickedFace == targetState.method_11654(SHAPE).getCornerFacing(targetFacing)) {
                targetFacing = clickedFace;
            }
            class_2350 playerFacing = context.method_8042();
            // 水平视线正对板面时延续朝向，沿板面看时按玩家朝向放置垂直板。
            class_2350 placedFacing = playerFacing.method_10166() == targetFacing.method_10166()
                    ? targetFacing : playerFacing.method_10153();
            state = method_9564().method_11657(FACING, placedFacing);
        } else if (clickedFace.method_10166() == class_2350.class_2351.field_11052) {
            state = method_9564().method_11657(FACING, context.method_8042().method_10153());
        } else {
            state = method_9564().method_11657(FACING, clickedFace);
        }
        return state.method_11657(SHAPE, getConnectedShape(state, context.method_8045(), context.method_8037()));
    }

    private PegboardShape getConnectedShape(class_2680 state, class_1922 level, class_2338 pos) {
        class_2350 facing = state.method_11654(FACING);
        class_2680 front = level.method_8320(pos.method_10093(facing));
        if (front.method_26204() instanceof GunPegboardBlock) {
            class_2350 otherFacing = front.method_11654(FACING);
            // 折面位于其朝向的反侧；该边已有同朝向直板时不能转角。
            if (otherFacing == facing.method_10160()
                    && !hasStraightConnection(level, pos.method_10093(facing.method_10170()), facing)) {
                return PegboardShape.CORNER_LEFT;
            }
            if (otherFacing == facing.method_10170()
                    && !hasStraightConnection(level, pos.method_10093(facing.method_10160()), facing)) {
                return PegboardShape.CORNER_RIGHT;
            }
        }
        return PegboardShape.STRAIGHT;
    }

    private static boolean hasStraightConnection(class_1922 level, class_2338 pos, class_2350 facing) {
        class_2680 neighbor = level.method_8320(pos);
        return neighbor.method_26204() instanceof GunPegboardBlock && neighbor.method_11654(FACING) == facing;
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 level, class_2338 pos, class_2338 neighborPos) {
        return state.method_11657(SHAPE, getConnectedShape(state, level, pos));
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        if (mirror == class_2415.field_11302) return state;
        PegboardShape shape = switch (state.method_11654(SHAPE)) {
            case CORNER_LEFT -> PegboardShape.CORNER_RIGHT;
            case CORNER_RIGHT -> PegboardShape.CORNER_LEFT;
            case STRAIGHT -> PegboardShape.STRAIGHT;
        };
        return state.method_11657(FACING, mirror.method_10343(state.method_11654(FACING))).method_11657(SHAPE, shape);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (player.method_5998(hand).method_31574(class_1802.field_8688)) return class_1269.field_5811;
        if (player.method_5998(hand).method_7909() instanceof GunPegboardItem) {
            return class_1269.field_5811;
        }
        if (player.method_5715()) {
            return class_1269.field_5811;
        }
        int slot = GunPegboardSlotHelper.getSlot(state, pos, hit.method_17784());
        if (slot < 0) {
            return class_1269.field_5811;
        }
        class_2586 blockEntity = level.method_8321(pos);
        if (!(blockEntity instanceof GunPegboardBlockEntity pegboard)) {
            return class_1269.field_5811;
        }
        if (level.method_8608()) {
            return class_1269.field_5812;
        }

        class_1799 held = player.method_5998(hand);
        class_1799 stored = pegboard.getItem(slot);
        if (stored.method_7960()) {
            if (!held.method_7960() && GunPegboardItemConfigRead.canPlace(held) && pegboard.setItem(slot, held)) {
                if (!player.method_31549().field_7477) {
                    held.method_7934(1);
                }
                level.method_8396(null, pos, class_3417.field_14667, class_3419.field_15245, 1.0F, 1.0F);
                return class_1269.field_21466;
            }
            return class_1269.field_5811;
        }

        if (pegboard.rotateItem(slot)) {
            level.method_8396(null, pos, class_3417.field_15038, class_3419.field_15245, 1.0F, 1.0F);
            return class_1269.field_21466;
        }
        return class_1269.field_5811;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        class_265 plate = getPlateShape(state.method_11654(FACING));
        if (state.method_11654(SHAPE) == PegboardShape.STRAIGHT) return plate;
        return class_259.method_1084(plate, getPlateShape(state.method_11654(SHAPE).getCornerFacing(state.method_11654(FACING))));
    }

    private static class_265 getPlateShape(class_2350 facing) {
        return switch (facing) {
            case field_11035 -> SOUTH_SHAPE;
            case field_11039 -> WEST_SHAPE;
            case field_11034 -> EAST_SHAPE;
            case field_11043 -> NORTH_SHAPE;
            default -> class_259.method_1077();
        };
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return method_9530(state, level, pos, context);
    }

    @Override
    public void method_9536(class_2680 oldState, class_1937 level, class_2338 pos, class_2680 newState, boolean movedByPiston) {
        if (!oldState.method_27852(newState.method_26204())) {
            class_2586 blockEntity = level.method_8321(pos);
            if (blockEntity instanceof GunPegboardBlockEntity pegboard) {
                pegboard.dropAllItems();
            }
        }
        super.method_9536(oldState, level, pos, newState, movedByPiston);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public List<class_1799> method_9560(class_2680 state, class_8567.class_8568 builder) {
        List<class_1799> drops = super.method_9560(state, builder);
        if (builder.method_51876(class_181.field_1228) instanceof GunPegboardBlockEntity pegboard) {
            for (class_1799 drop : drops) {
                if (drop.method_31574(method_8389()) && pegboard.getColor() >= 0 && !pegboard.hasInheritedColor()) {
                    ((class_1768) drop.method_7909()).method_7799(drop, pegboard.getColor());
                }
            }
        }
        return drops;
    }

    @Override
    public class_1799 method_9574(class_1922 level, class_2338 pos, class_2680 state) {
        class_1799 stack = new class_1799(method_8389());
        if (level.method_8321(pos) instanceof GunPegboardBlockEntity pegboard && pegboard.getColor() >= 0) {
            ((class_1768) stack.method_7909()).method_7799(stack, pegboard.getColor());
        }
        return stack;
    }
}
