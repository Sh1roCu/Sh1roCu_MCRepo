package com.tacz.guns.block;

import com.tacz.guns.block.entity.GunPegboardBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;

public final class GunPegboardSlotHelper {
    private static final double PLATE_THICKNESS = 3.0 / 16.0;
    private static final double LINE_OFFSET = 0.004;
    private static final double LINE_DEPTH = 0.0125;

    private GunPegboardSlotHelper() {
    }

    public static boolean hasCorner(class_2680 state) {
        return state.method_26204() instanceof GunPegboardBlock
                && state.method_11654(GunPegboardBlock.SHAPE) != PegboardShape.STRAIGHT;
    }

    public static class_2350 getSlotFacing(class_2680 state, int slot) {
        class_2350 facing = state.method_11654(GunPegboardBlock.FACING);
        if (slot < GunPegboardBlockEntity.SLOTS_PER_FACE || !hasCorner(state)) return facing;
        return state.method_11654(GunPegboardBlock.SHAPE).getCornerFacing(facing);
    }

    public static boolean isSlotActive(class_2680 state, int slot) {
        if (slot < 0 || slot >= GunPegboardBlockEntity.SLOT_COUNT) return false;
        boolean secondFace = slot >= GunPegboardBlockEntity.SLOTS_PER_FACE;
        if (!hasCorner(state)) return !secondFace;
        int column = slot % GunPegboardBlockEntity.GRID_SIZE;
        boolean left = state.method_11654(GunPegboardBlock.SHAPE) == PegboardShape.CORNER_LEFT;
        int blockedColumn = left == secondFace ? 0 : GunPegboardBlockEntity.GRID_SIZE - 1;
        return column != blockedColumn;
    }

    public static int getSlot(class_2680 state, class_2338 pos, class_243 hitLocation) {
        class_2350 facing = state.method_11654(GunPegboardBlock.FACING);
        double x = hitLocation.field_1352 - pos.method_10263();
        double y = hitLocation.field_1351 - pos.method_10264();
        double z = hitLocation.field_1350 - pos.method_10260();
        int faceOffset = 0;
        if (hasCorner(state)) {
            if (!onDisplayFace(facing, x, z)) {
                facing = getSlotFacing(state, GunPegboardBlockEntity.SLOTS_PER_FACE);
                if (!onDisplayFace(facing, x, z)) return -1;
                faceOffset = GunPegboardBlockEntity.SLOTS_PER_FACE;
            }
        }
        double u = switch (facing) {
            case field_11035 -> 1.0 - x;
            case field_11034 -> z;
            case field_11039 -> 1.0 - z;
            default -> x;
        };
        if (u < 0 || u >= 1 || y < 0 || y >= 1) {
            return -1;
        }
        int col = Math.min((int) (u * GunPegboardBlockEntity.GRID_SIZE), GunPegboardBlockEntity.GRID_SIZE - 1);
        int row = Math.min((int) (y * GunPegboardBlockEntity.GRID_SIZE), GunPegboardBlockEntity.GRID_SIZE - 1);
        int slot = faceOffset + row * GunPegboardBlockEntity.GRID_SIZE + col;
        return isSlotActive(state, slot) ? slot : -1;
    }

    private static boolean onDisplayFace(class_2350 facing, double x, double z) {
        double depth = switch (facing) {
            case field_11035 -> z;
            case field_11034 -> x;
            case field_11039 -> 1.0 - x;
            default -> 1.0 - z;
        };
        return Math.abs(depth - PLATE_THICKNESS) < 0.001;
    }

    public static class_238 getSlotAabb(class_2680 state, class_2338 pos, int slot) {
        int row = (slot % GunPegboardBlockEntity.SLOTS_PER_FACE) / GunPegboardBlockEntity.GRID_SIZE;
        int col = slot % GunPegboardBlockEntity.GRID_SIZE;
        double minU = col / (double) GunPegboardBlockEntity.GRID_SIZE;
        double maxU = (col + 1) / (double) GunPegboardBlockEntity.GRID_SIZE;
        double minY = row / (double) GunPegboardBlockEntity.GRID_SIZE;
        double maxY = (row + 1) / (double) GunPegboardBlockEntity.GRID_SIZE;
        class_2350 facing = getSlotFacing(state, slot);
        double x0;
        double x1;
        double z0;
        double z1;
        switch (facing) {
            case field_11035 -> {
                x0 = 1.0 - maxU;
                x1 = 1.0 - minU;
                z0 = PLATE_THICKNESS + LINE_OFFSET;
                z1 = PLATE_THICKNESS + LINE_OFFSET + LINE_DEPTH;
            }
            case field_11034 -> {
                x0 = PLATE_THICKNESS + LINE_OFFSET;
                x1 = PLATE_THICKNESS + LINE_OFFSET + LINE_DEPTH;
                z0 = minU;
                z1 = maxU;
            }
            case field_11039 -> {
                x0 = 1.0 - PLATE_THICKNESS - LINE_OFFSET - LINE_DEPTH;
                x1 = 1.0 - PLATE_THICKNESS - LINE_OFFSET;
                z0 = 1.0 - maxU;
                z1 = 1.0 - minU;
            }
            default -> {
                x0 = minU;
                x1 = maxU;
                z0 = 1.0 - PLATE_THICKNESS - LINE_OFFSET - LINE_DEPTH;
                z1 = 1.0 - PLATE_THICKNESS - LINE_OFFSET;
            }
        }
        return new class_238(pos.method_10263() + x0, pos.method_10264() + minY, pos.method_10260() + z0, pos.method_10263() + x1, pos.method_10264() + maxY, pos.method_10260() + z1).method_1014(0.002);
    }
}
