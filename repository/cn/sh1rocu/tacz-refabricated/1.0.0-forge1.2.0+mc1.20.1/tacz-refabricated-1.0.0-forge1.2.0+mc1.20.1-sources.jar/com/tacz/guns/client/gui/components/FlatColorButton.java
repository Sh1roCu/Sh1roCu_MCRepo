package com.tacz.guns.client.gui.components;

import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.Collections;
import java.util.List;

public class FlatColorButton extends class_4185 {
    private boolean isSelect = false;
    private List<class_2561> tooltips;

    public FlatColorButton(int pX, int pY, int pWidth, int pHeight, class_2561 pMessage, class_4241 pOnPress) {
        super(pX, pY, pWidth, pHeight, pMessage, pOnPress, field_40754);
    }

    public FlatColorButton setTooltips(String key) {
        tooltips = Collections.singletonList(class_2561.method_43471(key));
        return this;
    }

    public FlatColorButton setTooltips(List<class_2561> tooltips) {
        this.tooltips = tooltips;
        return this;
    }

    public FlatColorButton setTooltips(class_2561... tooltips) {
        this.tooltips = List.of(tooltips);
        return this;
    }

    public void renderToolTip(class_332 graphics, class_437 screen, int pMouseX, int pMouseY) {
        if (this.field_22762 && tooltips != null) {
            graphics.method_51434(Screens.getClient(screen).field_1772, tooltips, pMouseX, pMouseY);
        }
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float pPartialTick) {
        class_310 minecraft = class_310.method_1551();
        class_327 font = minecraft.field_1772;
        if (isSelect) {
            graphics.method_25296(this.method_46426(), this.method_46427(), this.method_46426() + this.field_22758, this.method_46427() + this.field_22759, 0xAF222222, 0xAF222222);
        } else {
            graphics.method_25296(this.method_46426(), this.method_46427(), this.method_46426() + this.field_22758, this.method_46427() + this.field_22759, 0xAF222222, 0xAF222222);
        }
        if (this.method_25367()) {
            graphics.method_25296(this.method_46426(), this.method_46427() + 1, this.method_46426() + 1, this.method_46427() + this.field_22759 - 1, 0xff_F3EFE0, 0xff_F3EFE0);
            graphics.method_25296(this.method_46426(), this.method_46427(), this.method_46426() + this.field_22758, this.method_46427() + 1, 0xff_F3EFE0, 0xff_F3EFE0);
            graphics.method_25296(this.method_46426() + this.field_22758 - 1, this.method_46427() + 1, this.method_46426() + this.field_22758, this.method_46427() + this.field_22759 - 1, 0xff_F3EFE0, 0xff_F3EFE0);
            graphics.method_25296(this.method_46426(), this.method_46427() + this.field_22759 - 1, this.method_46426() + this.field_22758, this.method_46427() + this.field_22759, 0xff_F3EFE0, 0xff_F3EFE0);
        }
        this.method_49604(graphics, font, 2, 0xF3EFE0);
        this.renderToolTip(graphics, minecraft.field_1755, mouseX, mouseY);
    }

    public void setSelect(boolean select) {
        isSelect = select;
    }
}
