package com.tacz.guns.client.renderer.block;

import com.github.mcmodderanchor.simplebedrockmodel.v2.client.mesh.capture.GeometryCollector;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.item.IAttachment;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.api.item.attachment.AttachmentType;
import com.tacz.guns.client.model.DisplayGunModelInstance;
import com.tacz.guns.client.model.ExternalGunModel;
import com.tacz.guns.client.renderer.external.ExternalGunAppearance;
import com.tacz.guns.client.renderer.item.SbmGunTransforms;
import com.tacz.guns.client.resource.index.ClientAttachmentIndex;
import com.tacz.guns.client.resource.index.ClientAttachmentVariantIndex;
import com.tacz.guns.client.resource.index.ClientSlotAdapterIndex;
import com.tacz.guns.util.SlotAdapterHelper;
import org.joml.Vector3f;

import java.util.EnumMap;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_811;

public class DisplayGunGeometry {
    private DisplayGunGeometry() {}

    @FunctionalInterface
    public interface AttachmentModelVisitor {
        void accept(ExternalGunModel model, class_2960 texture, class_1799 stack, class_4587 pose);
    }

    public static EnumMap<AttachmentType, ClientAttachmentIndex> resolveAttachments(IGun gun, class_1799 stack) {
        EnumMap<AttachmentType, ClientAttachmentIndex> indexes = new EnumMap<>(AttachmentType.class);
        for (AttachmentType type : AttachmentType.values()) {
            if (type == AttachmentType.NONE) continue;
            class_1799 attachment = effectiveAttachment(gun, stack, type);
            if (attachment.method_7960()) continue;
            IAttachment item = IAttachment.getIAttachmentOrNull(attachment);
            if (item == null) continue;
            class_2960 id = item.getAttachmentId(attachment);
            ClientAttachmentIndex index = TimelessAPI.getClientAttachmentIndex(id).orElse(null);
            if (index == null) return null;
            indexes.put(type, index);
        }
        return indexes;
    }

    public static class_1799 effectiveAttachment(IGun gun, class_1799 stack, AttachmentType type) {
        class_1799 attached = gun.getAttachment(stack, type);
        return attached.method_7960() ? gun.getBuiltinAttachment(stack, type) : attached;
    }

    public static boolean capture(ExternalGunAppearance.Snapshot snapshot, class_811 context,
                                  GeometryCollector collector) {
        return capture(snapshot, context, false, collector);
    }

    /** compensateItemRenderer is true for an immediate BEWLR capture after ItemRenderer's -0.5 translation. */
    public static boolean capture(ExternalGunAppearance.Snapshot snapshot, class_811 context,
                                  boolean compensateItemRenderer, GeometryCollector collector) {
        class_1799 stack = snapshot.stack();
        IGun gun = IGun.getIGunOrNull(stack);
        if (gun == null) return false;
        EnumMap<AttachmentType, ClientAttachmentIndex> attachments = resolveAttachments(gun, stack);
        if (attachments == null) return false;
        ExternalGunModel external = snapshot.model();
        DisplayGunModelInstance instance = external.displayInstance();
        instance.configureGun(gun, stack, attachments);

        class_4587 pose = new class_4587();
        if (!applyTransform(snapshot, context, compensateItemRenderer, pose)) return false;
        renderModel(external, instance, pose, snapshot.texture(), collector);
        renderAttachments(instance, pose, snapshot.useLod(), gun, stack, attachments, collector);
        return true;
    }

    /** 静态几何与动态特效必须使用同一份外观、显示原点和缩放。 */
    public static boolean applyTransform(ExternalGunAppearance.Snapshot snapshot, class_811 context,
                                         boolean compensateItemRenderer, class_4587 pose) {
        ExternalGunModel external = snapshot.model();
        var scales = snapshot.display().getTransform().getScale();
        switch (context) {
            case field_4319 -> {
                // 展示槽位绕过 ItemRenderer；即时 FIXED 的 BEWLR 则收到其 -0.5 居中变换。
                if (compensateItemRenderer) pose.method_22904(0.5, 0.5, 0.5);
                SbmGunTransforms.applyFixed(pose, external, scales == null ? null : scales.getFixed());
            }
            case field_4318 -> {
                pose.method_22904(0.5, 0.5, 0.5);
                SbmGunTransforms.applyGround(pose, external, scales == null ? null : scales.getGround());
            }
            case field_4320 -> {
                pose.method_22904(0.5, 0.5, 0.5);
                SbmGunTransforms.applyThirdPerson(pose, external,
                        scales == null ? null : scales.getThirdPerson());
            }
            default -> { return false; }
        }
        return true;
    }

    public static void renderAttachments(DisplayGunModelInstance instance, class_4587 pose, boolean useLod,
                                          IGun gun, class_1799 gunStack,
                                          EnumMap<AttachmentType, ClientAttachmentIndex> attachments,
                                          GeometryCollector collector) {
        forEachAttachmentModel(instance, pose, useLod, gun, gunStack, attachments,
                (model, texture, stack, modelPose) -> renderModel(model, model.displayInstance(), modelPose, texture, collector));
    }

    /** 共用本体与特效的挂点判定、转接口偏移以及变体/LOD 选择。 */
    public static void forEachAttachmentModel(DisplayGunModelInstance instance, class_4587 pose, boolean useLod,
                                              IGun gun, class_1799 gunStack,
                                              EnumMap<AttachmentType, ClientAttachmentIndex> attachments,
                                              AttachmentModelVisitor visitor) {
        for (var entry : attachments.entrySet()) {
            AttachmentType type = entry.getKey();
            ClientAttachmentIndex index = entry.getValue();
            class_1799 attached = effectiveAttachment(gun, gunStack, type);
            IAttachment attachmentItem = IAttachment.getIAttachmentOrNull(attached);
            if (attachmentItem == null) continue;
            class_2960 attachmentId = attachmentItem.getAttachmentId(attached);
            int position = instance.attachmentPosition(type);
            // LOD 模型可能省略挂点；旧渲染路径此时也不会绘制该配件。
            if (position < 0) continue;
            class_4587 attachmentPose = new class_4587();
            attachmentPose.method_23760().method_23761().mul(pose.method_23760().method_23761());
            attachmentPose.method_23760().method_23762().mul(pose.method_23760().method_23762());
            SbmGunTransforms.applyBonePivot(attachmentPose, instance, position);

            class_2960 adapterId = SlotAdapterHelper.getEffectiveSlotAdapter(gunStack, type, attachmentId);
            ClientSlotAdapterIndex adapter = adapterId == null ? null
                    : TimelessAPI.getClientSlotAdapterIndex(adapterId).orElse(null);
            if (adapter != null) {
                visitOptionalModel(adapter.getExternalModel(), adapter.getModelTexture(), class_1799.field_8037, attachmentPose, visitor);
                applyMountOffset(attachmentPose, adapter.getMountOffset());
            }

            ClientAttachmentVariantIndex variant = TimelessAPI.getClientAttachmentVariantIndex(attached).orElse(null);
            if (variant != null && variant.isOverlayMode()) {
                visitOptionalModel(variant.getExternalModel(), variant.getModelTexture(), attached, attachmentPose, visitor);
                applyMountOffset(attachmentPose, variant.getMountOffset());
            }

            ExternalGunModel attachment = index.getExternalModel();
            class_2960 attachmentTexture = index.getModelTexture();
            if (variant != null && variant.isReplaceMode()
                    && variant.getAttachmentModel() != null && variant.getModelTexture() != null) {
                attachment = variant.getExternalModel();
                attachmentTexture = variant.getModelTexture();
            }
            // 与 AttachmentRender 一致：普通配件的远距模型在 replace 变体之后选择。
            var lod = index.getExternalLodModel();
            if (useLod && lod != null) {
                attachment = lod.getLeft();
                attachmentTexture = lod.getRight();
            }
            visitOptionalModel(attachment, attachmentTexture, attached, attachmentPose, visitor);
        }
    }

    private static void visitOptionalModel(ExternalGunModel model, class_2960 texture, class_1799 stack,
                                           class_4587 pose, AttachmentModelVisitor visitor) {
        if (model == null || texture == null) return;
        visitor.accept(model, texture, stack, pose);
    }

    private static void applyMountOffset(class_4587 pose, Vector3f offset) {
        if (offset != null) {
            // AttachmentRender 的偏移处在旧模型坐标；SBM 副本的 X/Y 轴与之反向。
            pose.method_46416(-offset.x() / 16.0F, offset.y() / 16.0F, offset.z() / 16.0F);
        }
    }

    public static void renderModel(ExternalGunModel external, DisplayGunModelInstance instance, class_4587 pose,
                                    class_2960 texture, GeometryCollector collector) {
        var buffer = collector.buffer(class_1921.method_23576(texture),
                DisplayGunRenderType.emissive(texture), class_293.class_5596.field_27382);
        external.model().renderBoneTree(instance, pose, buffer, 0, class_4608.field_21444,
                1, 1, 1, 1, true, true);
    }
}
