package com.tacz.guns.client.resource.serialize;

import com.github.mcmodderanchor.simplebedrockmodel.v1.common.resource.pojo.ParticleEffectData;
import com.google.gson.*;
import com.tacz.guns.client.resource.pojo.animation.bedrock.ParticleEffectKeyframes;
import it.unimi.dsi.fastutil.doubles.Double2ObjectRBTreeMap;
import java.lang.reflect.Type;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3518;

/**
 * 解析动画 JSON 中的 {@code "particle_effects"}：
 * <pre>
 * "particle_effects": {
 *     "0.0": { "effect": "tacz:muzzle_flash_rifle", "locator": "muzzle_flash" },
 *     "0.25": "tacz:reload_smoke"
 * }
 * </pre>
 * 值为字符串时仅指定效果 id，locator 留空（渲染时回退到枪口骨骼）。
 */
public class ParticleEffectKeyframesSerializer implements JsonDeserializer<ParticleEffectKeyframes> {
    @Override
    public ParticleEffectKeyframes deserialize(JsonElement json, Type type, JsonDeserializationContext context) throws JsonParseException {
        Double2ObjectRBTreeMap<ParticleEffectData> keyframes = new Double2ObjectRBTreeMap<>();
        if (json.isJsonObject()) {
            JsonObject jsonObject = json.getAsJsonObject();
            for (Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                double time;
                try {
                    time = Double.parseDouble(entry.getKey());
                } catch (NumberFormatException e) {
                    continue;
                }
                JsonElement value = entry.getValue();
                class_2960 effect = null;
                String locator = null;
                String preEffectScript = null;
                if (value.isJsonPrimitive() && value.getAsJsonPrimitive().isString()) {
                    effect = class_2960.method_12829(value.getAsString());
                } else if (value.isJsonObject()) {
                    JsonObject obj = value.getAsJsonObject();
                    effect = class_2960.method_12829(class_3518.method_15265(obj, "effect"));
                    if (obj.has("locator")) {
                        locator = class_3518.method_15265(obj, "locator");
                    }
                    if (obj.has("pre_effect_script")) {
                        preEffectScript = class_3518.method_15265(obj, "pre_effect_script");
                    }
                }
                if (effect != null) {
                    keyframes.put(time, new ParticleEffectData(effect, locator, preEffectScript));
                }
            }
        }
        return new ParticleEffectKeyframes(keyframes);
    }
}
