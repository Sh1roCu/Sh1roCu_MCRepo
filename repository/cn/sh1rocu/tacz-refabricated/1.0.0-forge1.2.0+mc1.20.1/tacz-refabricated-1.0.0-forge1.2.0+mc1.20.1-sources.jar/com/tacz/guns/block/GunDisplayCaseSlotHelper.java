package com.tacz.guns.block;

import com.tacz.guns.block.entity.GunDisplayCaseBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;

public final class GunDisplayCaseSlotHelper {
    private static final double BACK_PANEL_THICKNESS = 3.0 / 16.0;
    private static final double LINE_OFFSET = 0.004;
    private static final double LINE_DEPTH = 0.0125;

    private GunDisplayCaseSlotHelper() {
    }

    public static int getSlot(class_2680 state, class_2338 pos, class_243 hitLocation) {
        class_2350 facing = state.method_11654(GunDisplayCaseBlock.FACING);
        double x = hitLocation.field_1352 - pos.method_10263();
        double y = hitLocation.field_1351 - pos.method_10264();
        double z = hitLocation.field_1350 - pos.method_10260();
        double u = switch (facing) {
            case field_11035 -> 1.0 - x;
            case field_11034 -> z;
            case field_11039 -> 1.0 - z;
            default -> x;
        };
        if (u < 0 || u >= 1 || y < 0 || y >= 1) {
            return -1;
        }
        int col = Math.min((int) (u * GunDisplayCaseBlockEntity.GRID_SIZE), GunDisplayCaseBlockEntity.GRID_SIZE - 1);
        int row = Math.min((int) (y * GunDisplayCaseBlockEntity.GRID_SIZE), GunDisplayCaseBlockEntity.GRID_SIZE - 1);
        return row * GunDisplayCaseBlockEntity.GRID_SIZE + col;
    }

    public static class_238 getSlotAabb(class_2680 state, class_2338 pos, int slot) {
        int row = slot / GunDisplayCaseBlockEntity.GRID_SIZE;
        int col = slot % GunDisplayCaseBlockEntity.GRID_SIZE;
        double minU = col / (double) GunDisplayCaseBlockEntity.GRID_SIZE;
        double maxU = (col + 1) / (double) GunDisplayCaseBlockEntity.GRID_SIZE;
        double minY = row / (double) GunDisplayCaseBlockEntity.GRID_SIZE;
        double maxY = (row + 1) / (double) GunDisplayCaseBlockEntity.GRID_SIZE;
        class_2350 facing = state.method_11654(GunDisplayCaseBlock.FACING);
        double x0;
        double x1;
        double z0;
        double z1;
        switch (facing) {
            case field_11035 -> {
                x0 = 1.0 - maxU;
                x1 = 1.0 - minU;
                z0 = BACK_PANEL_THICKNESS + LINE_OFFSET;
                z1 = BACK_PANEL_THICKNESS + LINE_OFFSET + LINE_DEPTH;
            }
            case field_11034 -> {
                x0 = BACK_PANEL_THICKNESS + LINE_OFFSET;
                x1 = BACK_PANEL_THICKNESS + LINE_OFFSET + LINE_DEPTH;
                z0 = minU;
                z1 = maxU;
            }
            case field_11039 -> {
                x0 = 1.0 - BACK_PANEL_THICKNESS - LINE_OFFSET - LINE_DEPTH;
                x1 = 1.0 - BACK_PANEL_THICKNESS - LINE_OFFSET;
                z0 = 1.0 - maxU;
                z1 = 1.0 - minU;
            }
            default -> {
                x0 = minU;
                x1 = maxU;
                z0 = 1.0 - BACK_PANEL_THICKNESS - LINE_OFFSET - LINE_DEPTH;
                z1 = 1.0 - BACK_PANEL_THICKNESS - LINE_OFFSET;
            }
        }
        return new class_238(pos.method_10263() + x0, pos.method_10264() + minY, pos.method_10260() + z0, pos.method_10263() + x1, pos.method_10264() + maxY, pos.method_10260() + z1).method_1014(0.002);
    }
}
