package com.tacz.guns.client.resource.pojo.skin.attachment;

import com.google.gson.annotations.SerializedName;
import net.minecraft.class_2960;

public class AttachmentSkin {
    @SerializedName("parent")
    private class_2960 parent;
    @SerializedName("name")
    private String name;
    @SerializedName("model")
    private class_2960 model;
    @SerializedName("texture")
    private class_2960 texture;

    public class_2960 getParent() {
        return parent;
    }

    public String getName() {
        return name;
    }

    public class_2960 getModel() {
        return model;
    }

    public class_2960 getTexture() {
        return texture;
    }
}
