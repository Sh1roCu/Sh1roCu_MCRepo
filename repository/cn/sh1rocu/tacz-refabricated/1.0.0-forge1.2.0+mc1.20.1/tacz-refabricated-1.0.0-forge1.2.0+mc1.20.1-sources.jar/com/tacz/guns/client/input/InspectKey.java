package com.tacz.guns.client.input;

import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

import static com.tacz.guns.util.InputExtraCheck.isInGame;

@Environment(EnvType.CLIENT)
public class InspectKey {
    public static final class_304 INSPECT_KEY = new class_304("key.tacz.inspect.desc",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_H,
            "key.category.tacz");

    public static boolean onInspectPress() {
        if (isInGame()) {
            class_746 player = class_310.method_1551().field_1724;
            if (player == null || player.method_7325()) {
                return false;
            }
            IClientPlayerGunOperator.fromLocalPlayer(player).inspect();
            return true;
        }
        return false;
    }

    public static boolean onInspectControllerPress(boolean isPress) {
        return isPress && onInspectPress();
    }
}
