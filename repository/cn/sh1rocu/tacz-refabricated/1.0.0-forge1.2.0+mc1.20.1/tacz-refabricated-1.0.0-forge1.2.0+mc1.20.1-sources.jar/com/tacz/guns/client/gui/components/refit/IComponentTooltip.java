package com.tacz.guns.client.gui.components.refit;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_746;

public interface IComponentTooltip {
    /**
     * 获取物品的文本提示
     */
    static List<class_2561> getTooltipFromItem(class_1799 stack) {
        class_315 options = class_310.method_1551().field_1690;
        class_746 player = class_310.method_1551().field_1724;
        return stack.method_7950(player, options.field_1827 ? class_1836.class_1837.field_41071 : class_1836.class_1837.field_41070);
    }

    /**
     * 添加此接口，会调用此渲染文本提示
     *
     * @param consumer 需要渲染的文本提示
     */
    void renderTooltip(Consumer<List<class_2561>> consumer);
}
