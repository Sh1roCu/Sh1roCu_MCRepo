package com.tacz.guns.client.input;

import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.network.message.ClientMessagePlayerZoom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

import static com.tacz.guns.util.InputExtraCheck.isInGame;

@Environment(EnvType.CLIENT)
public class ZoomKey {
    public static final class_304 ZOOM_KEY = new class_304("key.tacz.zoom.desc",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_V,
            "key.category.tacz");

    public static boolean onZoomControllerPress(boolean isPress) {
        return isPress && onZoomPress();
    }

    public static boolean onZoomPress() {
        if (!isInGame()) {
            return false;
        }
        class_746 player = class_310.method_1551().field_1724;
        if (player == null || player.method_7325()) {
            return false;
        }
        IClientPlayerGunOperator operator = IClientPlayerGunOperator.fromLocalPlayer(player);
        if (operator.isAim()) {
            ClientPlayNetworking.send(new ClientMessagePlayerZoom());
            return true;
        }
        return false;
    }
}
