package com.tacz.guns.client.model;

import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_811;

public interface IFunctionalRenderer {
    @Deprecated
    void render(class_4587 poseStack, class_4588 vertexBuffer, class_811 transformType, int light, int overlay);

    /**
     * 带 bufferSource 的渲染：由模型渲染循环在持有当前 bufferSource 时调用。
     * 需要按手部 buffer（而非全局 renderBuffers）绘制的渲染器覆写此方法；
     * 默认实现保留旧函数式委托；需要另取顶点消费者的实现应沿用此 bufferSource。
     */
    default void render(class_4587 poseStack, class_4588 vertexBuffer, class_811 transformType, int light, int overlay, class_4597 bufferSource) {
        render(poseStack, vertexBuffer, transformType, light, overlay);
    }
}
