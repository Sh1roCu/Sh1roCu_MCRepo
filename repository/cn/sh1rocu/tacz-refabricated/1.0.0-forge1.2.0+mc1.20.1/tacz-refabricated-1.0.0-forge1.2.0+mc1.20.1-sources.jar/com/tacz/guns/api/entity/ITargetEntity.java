package com.tacz.guns.api.entity;

import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_3966;

/**
 * 用于进行一些并非 {@link class_1309} 但是可被子弹击中的特殊实体的处理
 */
public interface ITargetEntity {
    /**
     * @param projectile 弹射物实体
     * @param result     击中实体的位置
     * @param source     伤害源类型
     * @param damage     伤害值
     */
    void onProjectileHit(class_1297 projectile, class_3966 result, class_1282 source, float damage);
}
