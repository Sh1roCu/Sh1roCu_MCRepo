package com.tacz.guns.client.resource.pojo.animation.bedrock;

import it.unimi.dsi.fastutil.doubles.Double2ObjectRBTreeMap;
import net.minecraft.class_2960;

public class SoundEffectKeyframes {
    private final Double2ObjectRBTreeMap<class_2960> keyframes;

    public SoundEffectKeyframes(Double2ObjectRBTreeMap<class_2960> keyframes) {
        this.keyframes = keyframes;
    }

    public Double2ObjectRBTreeMap<class_2960> getKeyframes() {
        return keyframes;
    }
}
