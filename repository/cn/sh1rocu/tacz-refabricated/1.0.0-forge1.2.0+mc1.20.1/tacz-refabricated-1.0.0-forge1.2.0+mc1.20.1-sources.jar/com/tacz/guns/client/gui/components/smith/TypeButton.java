package com.tacz.guns.client.gui.components.smith;

import com.mojang.blaze3d.systems.RenderSystem;
import com.tacz.guns.GunMod;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import org.jetbrains.annotations.NotNull;

public class TypeButton extends class_4185 {
    private static final class_2960 TEXTURE = new class_2960(GunMod.MOD_ID, "textures/gui/gun_smith_table.png");
    private final class_1799 stack;
    private boolean isSelected = false;

    public TypeButton(int pX, int pY, class_1799 stack, class_4185.class_4241 onPress) {
        super(pX, pY, 24, 25, class_2561.method_43473(), onPress, field_40754);
        this.stack = stack;
    }

    @Override
    protected void method_48579(@NotNull class_332 gui, int pMouseX, int pMouseY, float pPartialTick) {
        RenderSystem.enableDepthTest();

        int vOffset = method_25367() ? 204 + this.field_22759 : 204;
        if (isSelected) {
            gui.method_25290(TEXTURE, this.method_46426(), this.method_46427(), 0, vOffset, this.field_22758, this.field_22759, 256, 256);
        } else {
            gui.method_25290(TEXTURE, this.method_46426(), this.method_46427(), 26, vOffset, this.field_22758, this.field_22759, 256, 256);
        }

        gui.method_51427(this.stack, this.method_46426() + 4, this.method_46427() + 5);
    }

    @Override
    public void method_25306() {
        this.isSelected = true;
        this.field_22767.onPress(this);
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
