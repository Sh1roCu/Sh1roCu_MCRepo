package com.tacz.guns.client.init;

import com.tacz.guns.block.entity.GunSmithTableBlockEntity;
import com.tacz.guns.block.entity.GunDisplayCaseBlockEntity;
import com.tacz.guns.block.entity.GunPegboardBlockEntity;
import com.tacz.guns.block.entity.StatueBlockEntity;
import com.tacz.guns.block.entity.TargetBlockEntity;
import com.tacz.guns.client.renderer.block.GunSmithTableRenderer;
import com.tacz.guns.client.renderer.block.GunDisplayCaseRenderer;
import com.tacz.guns.client.renderer.block.GunPegboardRenderer;
import com.tacz.guns.client.renderer.block.StatueRenderer;
import com.tacz.guns.client.renderer.block.TargetRenderer;
import com.tacz.guns.client.renderer.entity.EntityBulletRenderer;
import com.tacz.guns.client.renderer.entity.TargetMinecartRenderer;
import com.tacz.guns.entity.EntityKineticBullet;
import com.tacz.guns.entity.TargetMinecart;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_5616;

@Environment(EnvType.CLIENT)
public class ModEntitiesRender {
    public static void registerEntityRenderers() {
        EntityRendererRegistry.register(EntityKineticBullet.TYPE, EntityBulletRenderer::new);
        EntityRendererRegistry.register(TargetMinecart.TYPE, TargetMinecartRenderer::new);
        class_5616.method_32144(GunSmithTableBlockEntity.TYPE, GunSmithTableRenderer::new);
        class_5616.method_32144(TargetBlockEntity.TYPE, TargetRenderer::new);
        class_5616.method_32144(StatueBlockEntity.TYPE, StatueRenderer::new);
        class_5616.method_32144(GunPegboardBlockEntity.TYPE, GunPegboardRenderer::new);
        class_5616.method_32144(GunDisplayCaseBlockEntity.TYPE, GunDisplayCaseRenderer::new);
    }
}
