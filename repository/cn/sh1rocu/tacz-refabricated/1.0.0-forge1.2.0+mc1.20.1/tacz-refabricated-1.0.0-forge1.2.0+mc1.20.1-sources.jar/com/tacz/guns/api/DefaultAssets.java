package com.tacz.guns.api;

import com.tacz.guns.GunMod;
import net.minecraft.class_2960;

public final class DefaultAssets {
    public static class_2960 DEFAULT_GUN_DISPLAY_ID = new class_2960(GunMod.MOD_ID, "default");
    public static class_2960 EMPTY_GUN_ID = new class_2960(GunMod.MOD_ID, "empty");

    public static class_2960 DEFAULT_AMMO_ID = new class_2960(GunMod.MOD_ID, "762x39");
    public static class_2960 EMPTY_AMMO_ID = new class_2960(GunMod.MOD_ID, "empty");

    public static class_2960 DEFAULT_BLOCK_ID = new class_2960(GunMod.MOD_ID, "gun_smith_table");
    public static class_2960 EMPTY_BLOCK_ID = new class_2960(GunMod.MOD_ID, "empty");

    public static class_2960 DEFAULT_ATTACHMENT_ID = new class_2960(GunMod.MOD_ID, "sight_sro_dot");
    public static class_2960 EMPTY_ATTACHMENT_ID = new class_2960(GunMod.MOD_ID, "empty");

    public static class_2960 DEFAULT_ATTACHMENT_SKIN_ID = new class_2960(GunMod.MOD_ID, "sight_sro_dot_blue");
    public static class_2960 EMPTY_ATTACHMENT_SKIN_ID = new class_2960(GunMod.MOD_ID, "empty");

    public static boolean isEmptyAttachmentId(class_2960 attachmentId) {
        return EMPTY_ATTACHMENT_ID.equals(attachmentId);
    }
}
