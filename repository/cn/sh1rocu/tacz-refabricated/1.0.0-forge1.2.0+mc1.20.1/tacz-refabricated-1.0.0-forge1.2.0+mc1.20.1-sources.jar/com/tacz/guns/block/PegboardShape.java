package com.tacz.guns.block;

import net.minecraft.class_2350;
import net.minecraft.class_3542;

public enum PegboardShape implements class_3542 {
    STRAIGHT("straight"),
    CORNER_LEFT("corner_left"),
    CORNER_RIGHT("corner_right");

    private final String name;

    PegboardShape(String name) {
        this.name = name;
    }

    @Override
    public String method_15434() {
        return name;
    }

    public class_2350 getCornerFacing(class_2350 facing) {
        return switch (this) {
            case CORNER_LEFT -> facing.method_10160();
            case CORNER_RIGHT -> facing.method_10170();
            case STRAIGHT -> facing;
        };
    }
}
