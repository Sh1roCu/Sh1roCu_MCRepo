package com.tacz.guns.advancement;

import com.google.gson.JsonObject;
import net.minecraft.class_174;
import net.minecraft.class_1799;
import net.minecraft.class_195;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5257;
import net.minecraft.class_5258;

public class GunRefitTrigger extends class_4558<GunRefitTrigger.TriggerInstance> {
    public static final GunRefitTrigger INSTANCE = new GunRefitTrigger();
    private static final class_2960 ID = new class_2960("tacz", "gun_refit");

    public static void register() {
        class_174.method_767(INSTANCE);
    }

    @Override
    public class_2960 method_794() {
        return ID;
    }

    public void trigger(class_3222 player, class_1799 before, class_1799 after) {
        if (!class_1799.method_7973(before, after)) {
            this.method_22510(player, instance -> true);
        }
    }

    @Override
    protected TriggerInstance method_27854(JsonObject json, class_5258 player, class_5257 context) {
        return new TriggerInstance(player);
    }

    public static class TriggerInstance extends class_195 {
        public TriggerInstance(class_5258 player) {
            super(ID, player);
        }
    }
}
