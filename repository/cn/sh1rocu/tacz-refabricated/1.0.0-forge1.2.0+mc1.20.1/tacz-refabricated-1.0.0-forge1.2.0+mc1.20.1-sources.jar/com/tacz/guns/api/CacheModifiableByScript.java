package com.tacz.guns.api;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

/**
 * 文档性质的注解。被注解的枪械属性在配件缓存中的值可以被逻辑脚本修改。
 *
 * @author ChloePrime
 * @see com.tacz.guns.resource.modifier.AttachmentPropertyManager#postChangeEvent(class_1309, class_1799)
 * @since 1.1.7
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.SOURCE)
public @interface CacheModifiableByScript {
}