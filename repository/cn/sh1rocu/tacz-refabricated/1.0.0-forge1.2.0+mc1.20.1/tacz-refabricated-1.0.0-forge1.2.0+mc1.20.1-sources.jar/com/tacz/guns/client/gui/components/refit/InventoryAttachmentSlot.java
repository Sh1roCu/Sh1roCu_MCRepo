package com.tacz.guns.client.gui.components.refit;

import com.mojang.blaze3d.systems.RenderSystem;
import com.tacz.guns.client.gui.GunRefitScreen;
import javax.annotation.Nonnull;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import java.util.function.Consumer;

public class InventoryAttachmentSlot extends class_4185 implements IStackTooltip {
    private final int slotIndex;
    private final class_1661 inventory;
    private final class_1799 displayStack;

    public InventoryAttachmentSlot(int pX, int pY, int slotIndex, class_1661 inventory, class_4185.class_4241 onPress) {
        this(pX, pY, slotIndex, inventory, class_1799.field_8037, onPress);
    }

    public InventoryAttachmentSlot(int pX, int pY, class_1799 displayStack, class_1661 inventory, class_4185.class_4241 onPress) {
        this(pX, pY, -1, inventory, displayStack, onPress);
    }

    private InventoryAttachmentSlot(int pX, int pY, int slotIndex, class_1661 inventory, class_1799 displayStack, class_4185.class_4241 onPress) {
        super(pX, pY, 18, 18, class_2561.method_43473(), onPress, field_40754);
        this.slotIndex = slotIndex;
        this.inventory = inventory;
        this.displayStack = displayStack;
    }

    @Override
    public void renderTooltip(Consumer<class_1799> consumer) {
        if (this.method_25367()) {
            class_1799 item = getItemStack();
            if (!item.method_7960()) {
                consumer.accept(item);
            }
        }
    }

    @Override
    public void method_48579(@Nonnull class_332 graphics, int pMouseX, int pMouseY, float pPartialTick) {
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();

        int x = method_46426(), y = method_46427();
        if (method_25367()) {
            graphics.method_25290(GunRefitScreen.SLOT_TEXTURE, x, y, 0, 0, field_22758, field_22759, 18, 18);
        } else {
            graphics.method_25290(GunRefitScreen.SLOT_TEXTURE, x + 1, y + 1, 1, 1, field_22758 - 2, field_22759 - 2, 18, 18);
        }
        graphics.method_51427(getItemStack(), x + 1, y + 1);

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    public int getSlotIndex() {
        return slotIndex;
    }

    public class_1799 getItemStack() {
        if (!displayStack.method_7960()) {
            return displayStack;
        }
        if (0 <= this.slotIndex && this.slotIndex < this.inventory.method_5439()) {
            return this.inventory.method_5438(slotIndex);
        }
        return class_1799.field_8037;
    }
}
