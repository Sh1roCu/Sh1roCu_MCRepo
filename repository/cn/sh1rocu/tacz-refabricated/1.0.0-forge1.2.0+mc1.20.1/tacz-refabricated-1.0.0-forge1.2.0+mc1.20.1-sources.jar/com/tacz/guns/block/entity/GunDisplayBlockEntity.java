package com.tacz.guns.block.entity;

import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import org.jetbrains.annotations.NotNull;

/** 展示方块实体的共同契约；每个展示面按网格大小的平方连续编号。 */
public interface GunDisplayBlockEntity {
    class_1799 getItem(int slot);

    int getRotation(int slot);

    DisplayGunSlot getDisplaySlot(int slot);

    int getGridSize();

    class_2350 getSlotFacing(int slot);

    /** 展示物品是否使用满亮度。 */
    boolean isDisplayGlowing();

    @NotNull
    class_2586 getBlockEntity();
}
