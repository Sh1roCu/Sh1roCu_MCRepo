package com.tacz.guns.api.item;

import net.minecraft.class_1799;

public interface IAnimationItem {
    /**
     * 返回物品是否需要重新初始化状态机或属性
     *
     * @param stack1 物品2
     * @param stack2 物品2
     * @return 是否需要重新初始化
     */
    boolean isSame(class_1799 stack1, class_1799 stack2);

    static boolean matchesIgnoreCount(class_1799 pStack, class_1799 pOther) {
        if (pStack == pOther) {
            return true;
        } else {
            return class_1799.method_31577(pStack, pOther);
        }
    }
}
