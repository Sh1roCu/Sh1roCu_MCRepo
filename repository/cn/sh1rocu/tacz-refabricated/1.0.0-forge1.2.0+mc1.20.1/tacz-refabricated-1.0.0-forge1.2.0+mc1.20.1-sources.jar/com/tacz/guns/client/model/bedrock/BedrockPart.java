package com.tacz.guns.client.model.bedrock;

import com.tacz.guns.util.RenderHelper;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.joml.Quaternionf;

import javax.annotation.Nullable;
import java.util.Random;

@Environment(EnvType.CLIENT)
public class BedrockPart {
    @Nullable
    public final String name;
    public final ObjectList<BedrockCube> cubes = new ObjectArrayList<>();
    public final ObjectList<BedrockPart> children = new ObjectArrayList<>();
    public float x;
    public float y;
    public float z;
    public float xRot;
    public float yRot;
    public float zRot;
    public float offsetX;
    public float offsetY;
    public float offsetZ;
    public boolean visible = true;
    public boolean illuminated = false;
    public boolean mirror;
    /**
     * 通常用于动画旋转。
     */
    public Quaternionf additionalQuaternion = new Quaternionf(0, 0, 0, 1);
    public float xScale = 1;
    public float yScale = 1;
    public float zScale = 1;
    protected BedrockPart parent;
    private float initRotX;
    private float initRotY;
    private float initRotZ;

    public BedrockPart(@Nullable String name) {
        this.name = name;
    }

    public void setPos(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public void render(class_4587 poseStack, class_811 transformType, class_4588 consumer, int light, int overlay) {
        this.render(poseStack, transformType, consumer, light, overlay, 1.0F, 1.0F, 1.0F, 1.0F);
    }

    public void render(class_4587 poseStack, class_811 transformType, class_4588 consumer, int light, int overlay, float red, float green, float blue, float alpha) {
        render(poseStack, transformType, consumer, light, overlay, red, green, blue, alpha, RenderHelper.getBufferSource(transformType));
    }

    public void render(class_4587 poseStack, class_811 transformType, class_4588 consumer, int light, int overlay, float red, float green, float blue, float alpha, @Nullable class_4597 bufferSource) {
        int cubePackedLight = light;
        class_4588 cubeConsumer = consumer;
        if (illuminated) {
            // 最大亮度
            cubePackedLight = class_765.method_23687(15, 15);
            cubeConsumer = UnshadedVertexConsumer.wrap(consumer);
        }
        if (this.visible) {
            if (!this.cubes.isEmpty() || !this.children.isEmpty()) {
                poseStack.method_22903();
                this.translateAndRotateAndScale(poseStack);
                this.compile(poseStack.method_23760(), cubeConsumer, cubePackedLight, overlay, red, green, blue, alpha);

                for (BedrockPart part : this.children) {
                    part.render(poseStack, transformType, cubeConsumer, cubePackedLight, overlay, red, green, blue, alpha, bufferSource);
                }

                poseStack.method_22909();
            }
        }
    }

    public void translateAndRotateAndScale(class_4587 poseStack) {
        poseStack.method_46416(this.offsetX, this.offsetY, this.offsetZ);
        poseStack.method_46416((this.x / 16.0F), (this.y / 16.0F), (this.z / 16.0F));
        if (this.zRot != 0.0F) {
            poseStack.method_22907(class_7833.field_40718.rotation(this.zRot));
        }
        if (this.yRot != 0.0F) {
            poseStack.method_22907(class_7833.field_40716.rotation(this.yRot));
        }
        if (this.xRot != 0.0F) {
            poseStack.method_22907(class_7833.field_40714.rotation(this.xRot));
        }
        poseStack.method_22907(additionalQuaternion);
        poseStack.method_22905(xScale, yScale, zScale);
    }

    public void compile(class_4587.class_4665 pose, class_4588 consumer, int light, int overlay, float red, float green, float blue, float alpha) {
        for (BedrockCube bedrockCube : this.cubes) {
            bedrockCube.compile(pose, consumer, light, overlay, red, green, blue, alpha);
        }
    }

    public BedrockCube getRandomCube(Random random) {
        return this.cubes.get(random.nextInt(this.cubes.size()));
    }

    public boolean isEmpty() {
        return this.cubes.isEmpty();
    }

    public void setInitRotationAngle(float x, float y, float z) {
        this.initRotX = x;
        this.initRotY = y;
        this.initRotZ = z;
    }

    public float getInitRotX() {
        return initRotX;
    }

    public float getInitRotY() {
        return initRotY;
    }

    public float getInitRotZ() {
        return initRotZ;
    }

    public void addChild(BedrockPart model) {
        this.children.add(model);
    }

    public BedrockPart getParent() {
        return parent;
    }
}
