package com.tacz.guns.client.gui.components.refit;

import java.util.function.Consumer;
import net.minecraft.class_1799;

public interface IStackTooltip {
    /**
     * 添加此接口，会调用此渲染文本提示
     *
     * @param consumer 需要渲染文本提示的物品
     */
    void renderTooltip(Consumer<class_1799> consumer);
}
