package com.tacz.guns.client.renderer.scope;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.tacz.guns.GunMod;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.api.item.IAttachment;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.api.item.attachment.AttachmentType;
import com.tacz.guns.compat.iris.IrisCompat;
import com.tacz.guns.config.client.RenderConfig;
import com.tacz.guns.util.ThermalImagingHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4720;
import net.minecraft.class_5944;
import net.minecraft.class_6367;
import net.minecraft.class_8251;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL32;
import org.lwjgl.system.MemoryStack;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Records the existing entity draws; never renders or animates an entity a second time.
 */
@Environment(EnvType.CLIENT)
public class ScopeThermalRenderer {
    // One pixel of depth slope covers subpixel TAA jitter; units cover depth rounding.
    static final float DEPTH_BIAS_FACTOR = -1.0f;
    static final float DEPTH_BIAS_UNITS = -2.0f;
    private static final Map<class_1921, class_287> BUILDERS = new LinkedHashMap<>();
    private static final Map<class_1921, class_287> ACTIVE = new LinkedHashMap<>();
    private static class_6367 target;
    private static class_5944 shader;
    private static Matrix4f projection;
    private static Matrix4f modelView;
    private static boolean collecting;
    private static boolean ready;
    private static Boolean thermalScope;

    private ScopeThermalRenderer() {
    }

    public static void registerShader() {
        shader = null;
        CoreShaderRegistrationCallback.EVENT.register(ctx -> {
            try {
                ctx.register(
                        new class_2960(GunMod.MOD_ID, "scope_thermal_mask"),
                        class_290.field_20887,
                        instance -> shader = instance
                );
            } catch (IOException exception) {
                GunMod.LOGGER.error("Could not load scope thermal mask shader; thermal scopes will use the normal lens", exception);
            }
        });
    }

    public static void beginFrame() {
        for (class_287 builder : ACTIVE.values()) builder.method_1326().method_43585();
        ACTIVE.clear();
        projection = null;
        modelView = null;
        collecting = true;
        ready = false;
        thermalScope = null;
    }

    public static boolean enabled() {
        class_310 mc = class_310.method_1551();
        if (shader == null || !RenderConfig.EXPERIMENTAL_SCOPE_LENS.get() || !RenderConfig.SCOPE_THERMAL_ENABLE.get()
                || mc.field_1687 == null || mc.field_1724 == null || mc.method_1560() != mc.field_1724
                || !mc.field_1690.method_31044().method_31034() || mc.field_1690.field_1842
                || IClientPlayerGunOperator.fromLocalPlayer(mc.field_1724).getClientAimingProgress(mc.method_1488()) <= 0.001f
                || IrisCompat.isRenderShadow()) return false;
        // Resolve attachment NBT and variants once per frame, rather than once per entity draw.
        if (thermalScope == null) thermalScope = hasThermalScope(mc.field_1724.method_6047());
        return thermalScope;
    }

    private static boolean hasThermalScope(class_1799 gunItem) {
        IGun gun = IGun.getIGunOrNull(gunItem);
        if (gun == null) return false;
        class_1799 scope = gun.getAttachment(gunItem, AttachmentType.SCOPE);
        if (scope.method_7960()) scope = gun.getBuiltinAttachment(gunItem, AttachmentType.SCOPE);
        IAttachment attachment = IAttachment.getIAttachmentOrNull(scope);
        if (attachment == null) return false;
        var index = TimelessAPI.getClientAttachmentIndex(attachment.getAttachmentId(scope)).orElse(null);
        if (index == null) return false;
        var variant = TimelessAPI.getClientAttachmentVariantIndex(scope).orElse(null);
        // Match AttachmentRender's replacement/overlay selection, including unavailable model fallback.
        if (variant != null && variant.getAttachmentModel() != null && variant.getModelTexture() != null) {
            boolean variantThermal = variant.isScope() && variant.getScopeLens().getVisionMode().isThermal();
            if (variant.isReplaceMode()) return variantThermal;
            if (variantThermal) return true;
        }
        return index.isScope() && index.getScopeLens().getVisionMode().isThermal();
    }

    public static class_4597 wrap(class_4597 source, class_1297 entity) {
        // Nested entity renders evaluate their own tags instead of inheriting the parent's heat mask.
        // Unwrap only our source; other mods' buffer wrappers remain in the chain.
        while (source instanceof ThermalBuffers thermal) source = thermal.source();
        if (!collecting || !enabled() || !entity.method_5805()
                || entity.method_5767() || entity.method_7325() || entity == class_310.method_1551().method_1560()
                || !ThermalImagingHelper.isHeatSource(entity)) return source;
        return new ThermalBuffers(source);
    }

    public static void onWorldStage(WorldRenderContext context) {
        if (/*event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES ||*/ IrisCompat.isRenderShadow()) return;
        collecting = false;
        if (!enabled()) return;
        var main = class_310.method_1551().method_1522();
        try (MemoryStack stack = MemoryStack.stackPush(); var state = new ScopeLensRenderer.RenderState(stack)) {
            // Unsupported render scales/targets fall back to the optical lens for this frame.
            if (state.drawFbo == 0 || state.viewport.get(0) != 0 || state.viewport.get(1) != 0
                    || state.viewport.get(2) != main.field_1482 || state.viewport.get(3) != main.field_1481) return;
            int depthType = GL30.glGetFramebufferAttachmentParameteri(GL30.GL_DRAW_FRAMEBUFFER,
                    GL30.GL_DEPTH_ATTACHMENT, GL30.GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE);
            if (depthType != GL11.GL_TEXTURE && depthType != GL30.GL_RENDERBUFFER) return;
            int depthObject = GL30.glGetFramebufferAttachmentParameteri(GL30.GL_DRAW_FRAMEBUFFER,
                    GL30.GL_DEPTH_ATTACHMENT, GL30.GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME);
            int depthLevel = depthType == GL11.GL_TEXTURE
                    ? GL30.glGetFramebufferAttachmentParameteri(GL30.GL_DRAW_FRAMEBUFFER,
                    GL30.GL_DEPTH_ATTACHMENT, GL30.GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL) : 0;
            RenderSystem.disableScissor();
            GL11.glDisable(GL11.GL_STENCIL_TEST);
            RenderSystem.colorMask(true, true, true, true);
            RenderSystem.depthMask(false);
            if (target == null) {
                // Own only the mask colour. Borrow the live scene depth with all depth writes disabled.
                target = new class_6367(main.field_1482, main.field_1481, false, class_310.field_1703);
                target.method_1236(0, 0, 0, 0);
                target.method_1232(GL11.GL_LINEAR);
            } else if (target.field_1482 != main.field_1482 || target.field_1481 != main.field_1481) {
                target.method_1234(main.field_1482, main.field_1481, class_310.field_1703);
                target.method_1232(GL11.GL_LINEAR);
            }
            target.method_1230(class_310.field_1703);
            var view = RenderSystem.getModelViewStack();
            view.method_22903();
            target.method_1235(true);
            try {
                attachSceneDepth(depthType, depthObject, depthLevel);
                // Includes mismatched sample counts/layered attachments: use the optical fallback.
                if (GL30.glCheckFramebufferStatus(GL30.GL_DRAW_FRAMEBUFFER) != GL30.GL_FRAMEBUFFER_COMPLETE) return;
                if (projection != null) {
                    RenderSystem.setProjectionMatrix(projection, class_8251.field_43360);
                    view.method_34426();
                    view.method_34425(modelView);
                    RenderSystem.applyModelViewMatrix();
                }
                var batches = ACTIVE.entrySet().iterator();
                while (batches.hasNext()) {
                    var entry = batches.next();
                    class_1921 type = entry.getKey();
                    class_287.class_7433 vertices = entry.getValue().method_1326();
                    batches.remove();
                    try {
                        type.method_23516();
                        target.method_1235(true);
                        RenderSystem.setShader(() -> shader);
                        RenderSystem.enableDepthTest();
                        RenderSystem.depthFunc(GL11.GL_LEQUAL);
                        RenderSystem.depthMask(false);
                        // Bias only mask depth: keep cutout silhouettes and scene occlusion intact.
                        // Apply after the material state, which may set its own polygon offset.
                        RenderSystem.enablePolygonOffset();
                        RenderSystem.polygonOffset(DEPTH_BIAS_FACTOR, DEPTH_BIAS_UNITS);
                        RenderSystem.disableBlend();
                        RenderSystem.colorMask(true, true, true, true);
                        class_287.class_7433 submitted = vertices;
                        vertices = null;
                        class_286.method_43433(submitted);
                    } finally {
                        if (vertices != null) vertices.method_43585();
                        type.method_23518();
                    }
                }
                ready = true;
            } finally {
                target.method_1235(false);
                attachSceneDepth(depthType, 0, 0);
                for (class_287 builder : ACTIVE.values()) builder.method_1326().method_43585();
                ACTIVE.clear();
                view.method_22909();
                RenderSystem.applyModelViewMatrix();
            }
        }
    }

    public static void attachSceneDepth(int type, int object, int level) {
        if (type == GL11.GL_TEXTURE) {
            GL32.glFramebufferTexture(GL30.GL_DRAW_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, object, level);
        } else {
            GL30.glFramebufferRenderbuffer(GL30.GL_DRAW_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL30.GL_RENDERBUFFER, object);
        }
    }

    public static boolean isReady(int width, int height) {
        return ready && target != null && target.field_1482 == width && target.field_1481 == height;
    }

    public static int textureOr(int fallback, int width, int height) {
        return isReady(width, height) ? target.method_30277() : fallback;
    }

    public static void close() {
        beginFrame();
        if (target != null) {
            target.method_1238();
            target = null;
        }
        // Keep BufferBuilders for reuse: their native allocations are not freed by the GC.
    }

    public record ThermalBuffers(class_4597 source) implements class_4597 {
        @Override
        public class_4588 getBuffer(class_1921 type) {
            class_4588 original = source.getBuffer(type);
            if ((!type.method_24295() && type.method_23289().isEmpty()) || !collecting) return original;
            if (projection == null) {
                projection = new Matrix4f(RenderSystem.getProjectionMatrix());
                modelView = new Matrix4f(RenderSystem.getModelViewMatrix());
            }
            // Keep the material state too: armor's view offset must match the scene depth.
            class_287 builder = ACTIVE.computeIfAbsent(type, key -> {
                class_287 buffer = BUILDERS.computeIfAbsent(key, unused -> new class_287(4096));
                buffer.method_1328(key.method_23033(), class_290.field_20887);
                return buffer;
            });
            return class_4720.method_24037(original, new MaskVertices(builder));
        }
    }

    /** Equivalent to vanilla's outline generator: keep texture cutouts, ignore lighting and hurt tint. */
    public static final class MaskVertices implements class_4588 {
        private final class_4588 output;
        private double x, y, z;
        private float u, v;

        MaskVertices(class_4588 output) {
            this.output = output;
        }

        @Override
        public class_4588 method_22912(double x, double y, double z) {
            this.x = x;
            this.y = y;
            this.z = z;
            return this;
        }

        @Override
        public class_4588 method_22913(float u, float v) {
            this.u = u; this.v = v; return this;
        }

        @Override
        public class_4588 method_1336(int r, int g, int b, int a) {
            return this;
        }

        @Override
        public class_4588 method_22917(int u, int v) {
            return this;
        }

        @Override
        public class_4588 method_22921(int u, int v) {
            return this;
        }

        @Override
        public class_4588 method_22914(float x, float y, float z) {
            return this;
        }

        @Override
        public void method_22901(int r, int g, int b, int a) { }

        @Override
        public void method_35666() {

        }

        @Override
        public void method_1344() {
            output.method_22912(x, y, z).method_1336(255, 255, 255, 255).method_22913(u, v).method_1344();
        }
    }
}
