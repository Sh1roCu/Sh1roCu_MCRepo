package com.tacz.guns.client.renderer.external;

import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.client.model.ExternalGunModel;
import com.tacz.guns.client.model.functional.BeamRenderer;
import com.tacz.guns.client.particle.ThirdPersonMuzzleParticleManager;
import com.tacz.guns.client.renderer.block.DisplayGunGeometry;
import com.tacz.guns.client.renderer.item.GunItemRendererWrapper;
import com.tacz.guns.client.renderer.item.SbmGunTransforms;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;

public final class ExternalGunEffects {
    private ExternalGunEffects() {}

    public static void renderThirdPerson(ExternalGunAppearance.Snapshot snapshot, class_4587 pose,
                                         class_4597 buffers, int packedLight, int packedOverlay) {
        class_1799 stack = snapshot.stack();
        IGun gun = IGun.getIGunOrNull(stack);
        if (gun == null) return;
        var attachments = DisplayGunGeometry.resolveAttachments(gun, stack);
        if (attachments == null) return;
        var instance = snapshot.model().displayInstance();
        instance.configureGun(gun, stack, attachments);

        pose.method_22903();
        DisplayGunGeometry.applyTransform(snapshot, class_811.field_4320, true, pose);
        renderLasers(snapshot.model(), stack, pose, buffers);
        DisplayGunGeometry.forEachAttachmentModel(instance, pose, snapshot.useLod(), gun, stack, attachments,
                (model, texture, attached, modelPose) -> renderLasers(model, attached, modelPose, buffers));
        renderShells(snapshot, gun, pose, buffers, packedLight, packedOverlay);

        int muzzle = instance.muzzleFlashPosition();
        if (muzzle >= 0) {
            SbmGunTransforms.applyBonePivot(pose, instance, muzzle);
            pose.method_22905(-1, -1, 1);
            GunItemRendererWrapper.captureThirdPersonMuzzle(pose.method_23760().method_23761());
        }
        pose.method_22909();
    }

    private static void renderShells(ExternalGunAppearance.Snapshot snapshot, IGun gun, class_4587 pose,
                                     class_4597 buffers, int packedLight, int packedOverlay) {
        var player = class_310.method_1551().field_1724;
        if (player == null || ThirdPersonMuzzleParticleManager.currentEntity != player) return;
        var display = snapshot.display();
        var gunIndex = TimelessAPI.getClientGunIndex(gun.getGunId(snapshot.stack())).orElse(null);
        if (gunIndex == null) return;
        display.getExternalShellRenderer().render(display, gunIndex.getGunData(), snapshot.model().displayInstance(),
                pose, buffers, packedLight, packedOverlay);
    }

    private static void renderLasers(ExternalGunModel model, class_1799 stack, class_4587 pose,
                                     class_4597 buffers) {
        var instance = model.displayInstance();
        for (int laser : instance.laserBeamBones()) {
            pose.method_22903();
            SbmGunTransforms.applyBonePivot(pose, instance, laser);
            pose.method_22905(-1, -1, 1);
            BeamRenderer.renderLaserBeamUnaccelerated(stack, pose, class_811.field_4320, buffers);
            pose.method_22909();
        }
    }
}
