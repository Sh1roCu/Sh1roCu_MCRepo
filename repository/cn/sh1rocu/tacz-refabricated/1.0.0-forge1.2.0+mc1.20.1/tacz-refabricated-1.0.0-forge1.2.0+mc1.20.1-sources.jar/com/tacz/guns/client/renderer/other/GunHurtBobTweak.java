package com.tacz.guns.client.renderer.other;

import com.tacz.guns.util.time.GunTime;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.class_7833;

public class GunHurtBobTweak {
    private static long hurtByGunTimeStamp = -1L;
    private static float lastTweakMultiplier = 0.05f;

    public static boolean onHurtBobTweak(class_746 player, class_4587 matrixStack, float partialTicks) {
        // 原版受伤的时长是 500 ms，所以如果大于 500 ms，那么说明不是子弹造成的伤害了
        if (!GunTime.isWithin(hurtByGunTimeStamp, 500)) {
            // 返回 false，让程序调用原版受伤晃动
            return false;
        }
        float zRot = (float) player.field_6235 - partialTicks;
        if (zRot < 0) {
            return true;
        }
        zRot /= (float) player.field_6254;
        zRot = class_3532.method_15374(zRot * zRot * zRot * zRot * (float) Math.PI);
        float yRot = player.method_48157();

        yRot = yRot * lastTweakMultiplier;
        zRot = zRot * lastTweakMultiplier;

        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(-yRot));
        matrixStack.method_22907(class_7833.field_40714.rotationDegrees(-zRot * 14.0F));
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(yRot));
        return true;
    }

    public static void markTimestamp(float tweakMultiplier) {
        hurtByGunTimeStamp = GunTime.nowMillis();
        lastTweakMultiplier = tweakMultiplier;
    }

    public static void resetTimestamp() {
        hurtByGunTimeStamp = -1L;
        lastTweakMultiplier = 0.05f;
    }
}
