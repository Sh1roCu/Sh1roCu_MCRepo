package com.tacz.guns.client.resource.pojo.display.gun;

import com.tacz.guns.api.GunProperties;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.api.entity.IGunOperator;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.client.event.CameraSetupEvent;
import com.tacz.guns.client.resource.GunDisplayInstance;
import com.tacz.guns.client.resource.index.ClientGunIndex;
import com.tacz.guns.config.common.AmmoConfig;
import com.tacz.guns.resource.modifier.AttachmentCacheProperty;
import com.tacz.guns.resource.pojo.data.gun.BulletData;
import com.tacz.guns.resource.pojo.data.gun.GunData;
import com.tacz.guns.util.HitboxHelper;
import com.tacz.guns.util.block.BlockRayTrace;
import com.tacz.guns.util.math.Easing;
import com.tacz.guns.util.math.MathUtil;
import com.tacz.guns.util.time.GunTime;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import javax.annotation.Nullable;
import java.util.Comparator;
import java.util.Optional;
import java.util.function.Predicate;

@Environment(EnvType.CLIENT)
public final class RangefinderManager {
    private static final String MISS_TEXT = "---";
    private static final double ENTITY_XZ_EXPAND = 0.25;
    private static final double ENTITY_Y_EXPAND = 8.0;
    private static final long MILLIS_PER_TICK = 50L;
    private static final Predicate<class_1297> RANGEFINDER_TARGETS = entity -> entity != null && entity.method_5863() && !entity.method_7325() && entity.method_5805();

    private static Rangefinder currentConfig = null;
    private static long lastUpdateTimestamp = 0L;
    private static int lastRefreshTick = 2;
    private static String text = MISS_TEXT;
    private static boolean hitEntity = false;
    private static double hitDistance = 0.0;
    private static float impactProjectionY = 0.0f;
    private static int impactPredictionColor = 0xFFFFFFFF;
    private static float impactPredictionScale = 1.0f;
    private static boolean showImpactPrediction = false;

    private RangefinderManager() {
    }

    public static void resetTimestamps() {
        currentConfig = null;
        lastUpdateTimestamp = 0L;
        lastRefreshTick = 2;
        clearResult();
    }

    public static void setCurrentConfig(@Nullable Rangefinder config) {
        currentConfig = config;
    }

    public static void clearCurrentConfig() {
        currentConfig = null;
    }

    public static String getText(class_1799 stack) {
        if (currentConfig == null) {
            return "";
        }
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null || stack == null || stack.method_7960()) {
            lastUpdateTimestamp = 0L;
            clearResult();
            return MISS_TEXT;
        }
        int refreshTick = currentConfig.getRefreshTick();
        long now = GunTime.nowMillis();
        if (lastUpdateTimestamp != 0L && GunTime.isWithin(lastUpdateTimestamp, refreshTick * MILLIS_PER_TICK) && refreshTick == lastRefreshTick) {
            return text;
        }
        lastUpdateTimestamp = now;
        lastRefreshTick = refreshTick;
        updateResult(player, stack, currentConfig);
        return text;
    }

    public static boolean shouldRenderImpactPrediction() {
        if (!showImpactPrediction) {
            return false;
        }
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null || !GunTime.isWithin(lastUpdateTimestamp, (lastRefreshTick + 1L) * MILLIS_PER_TICK)) {
            showImpactPrediction = false;
            return false;
        }
        if (!(player instanceof IClientPlayerGunOperator operator) || operator.getClientAimingProgress(mc.method_1488()) < 0.9f) {
            showImpactPrediction = false;
            return false;
        }
        return true;
    }

    public static float getImpactProjectionY() {
        return impactProjectionY;
    }

    public static int getImpactPredictionColor() {
        return impactPredictionColor;
    }

    public static float getImpactPredictionScale() {
        return impactPredictionScale;
    }

    private static void updateResult(class_746 player, class_1799 stack, Rangefinder config) {
        impactPredictionColor = config.getImpactPredictionColor();
        impactPredictionScale = config.getImpactPredictionScale();
        if (!(stack.method_7909() instanceof IGun iGun) || !(player instanceof IClientPlayerGunOperator operator)) {
            clearResult();
            return;
        }
        if (operator.getClientAimingProgress(class_310.method_1551().method_1488()) < 0.9f) {
            clearResult();
            return;
        }

        float maxDistance = config.getMaxDistance();
        class_243 start = player.method_5836(class_310.method_1551().method_1488());
        class_243 look = player.method_5828(class_310.method_1551().method_1488());
        class_243 end = start.method_1019(look.method_1021(maxDistance));

        class_3965 blockResult = BlockRayTrace.rayTraceBlocks(player.method_37908(), new class_3959(start, end, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, player));
        double blockDistance = blockResult.method_17783() == class_239.class_240.field_1333 ? Double.MAX_VALUE : start.method_1022(blockResult.method_17784());
        EntityHit entityHit = findEntityHit(player, start, end, blockDistance).orElse(null);

        if (entityHit != null) {
            double distance = start.method_1022(entityHit.hitPos());
            setDistanceText(distance, true, maxDistance);
            updateImpactPrediction(player, stack, iGun, config, distance);
        } else if (blockDistance != Double.MAX_VALUE) {
            setDistanceText(blockDistance, false, maxDistance);
            showImpactPrediction = false;
        } else {
            clearResult();
        }
    }

    private static Optional<EntityHit> findEntityHit(class_746 player, class_243 start, class_243 end, double maxDistance) {
        class_238 scanBox = new class_238(start, end).method_1009(ENTITY_XZ_EXPAND, ENTITY_Y_EXPAND, ENTITY_XZ_EXPAND);
        return player.method_37908().method_8333(player, scanBox, RANGEFINDER_TARGETS)
                .stream()
                .filter(entity -> !entity.equals(player))
                .filter(entity -> !entity.method_5794(player))
                .map(entity -> HitboxHelper.getFixedBoundingBox(entity, player).method_1009(ENTITY_XZ_EXPAND, ENTITY_Y_EXPAND, ENTITY_XZ_EXPAND).method_992(start, end).map(EntityHit::new).orElse(null))
                .filter(hit -> hit != null && start.method_1022(hit.hitPos()) <= maxDistance)
                .min(Comparator.comparingDouble(hit -> start.method_1022(hit.hitPos())));
    }

    private static void setDistanceText(double distance, boolean entityHit, float maxDistance) {
        hitDistance = distance;
        hitEntity = entityHit;
        int roundedDistance = class_3532.method_15357(distance + 0.5);
        // 与距离使用相同的取整规则，按测距上限的位数补零。
        int digits = Integer.toString(class_3532.method_15357(maxDistance + 0.5)).length();
        String distanceText = Integer.toString(roundedDistance);
        text = "0".repeat(Math.max(0, digits - distanceText.length())) + distanceText;
    }

    private static void clearResult() {
        text = MISS_TEXT;
        hitEntity = false;
        hitDistance = 0.0;
        impactProjectionY = 0.0f;
        showImpactPrediction = false;
    }

    private static void updateImpactPrediction(class_746 player, class_1799 stack, IGun iGun, Rangefinder config, double distance) {
        showImpactPrediction = false;
        if (!hitEntity || !config.isShowImpactPrediction() || MISS_TEXT.equals(text) || distance <= 0.0) {
            return;
        }
        class_2960 gunId = iGun.getGunId(stack);
        ClientGunIndex gunIndex = TimelessAPI.getClientGunIndex(gunId).orElse(null);
        if (gunIndex == null) {
            return;
        }
        GunData gunData = gunIndex.getGunData();
        if (gunData == null || gunData.getBulletData() == null) {
            return;
        }
        BulletData bulletData = gunData.getBulletData();
        float speed = getAmmoSpeed(player, stack, bulletData);
        if (speed <= 0.0f) {
            return;
        }
        class_243 look = player.method_5828(class_310.method_1551().method_1488());
        double drop = calculateDrop(distance, look.field_1351, speed / 20.0f, bulletData.getGravity(), bulletData.getFriction());
        if (!Double.isFinite(drop)) {
            return;
        }

        float fov = getCurrentFov(player, stack, iGun);
        double angle = Math.atan2(-drop, Math.max(distance, 0.001));
        impactProjectionY = (float) (Math.tan(angle) / Math.tan(Math.toRadians(fov) / 2.0));
        showImpactPrediction = Float.isFinite(impactProjectionY);
    }

    private static float getAmmoSpeed(class_746 player, class_1799 stack, BulletData bulletData) {
        float speed = bulletData.getSpeed();
        AttachmentCacheProperty cacheProperty = IGunOperator.fromLivingEntity(player).getCacheProperty();
        if (cacheProperty != null) {
            try {
                speed = cacheProperty.getCache(GunProperties.AMMO_SPEED);
            } catch (RuntimeException ignored) {
                speed = bulletData.getSpeed();
            }
        }
        return Math.max(0.0f, speed * AmmoConfig.GLOBAL_BULLET_SPEED_MODIFIER.get().floatValue());
    }

    private static float getCurrentFov(class_746 player, class_1799 stack, IGun iGun) {
        float configuredFov = class_310.method_1551().field_1690.method_41808().method_41753().floatValue();
        float aimingProgress = IClientPlayerGunOperator.fromLocalPlayer(player).getClientAimingProgress(class_310.method_1551().method_1488());
        AdsFov.Channel curve = TimelessAPI.getGunDisplay(stack)
                .map(GunDisplayInstance::getAdsFov).map(AdsFov::getWorld).orElse(null);
        float fovProgress = curve == null ? (float) Easing.easeInExpo(aimingProgress)
                : curve.evaluate(aimingProgress);
        float zoom = iGun.getAimingZoom(stack);
        float targetFov = (float) MathUtil.magnificationToFov(1 + (zoom - 1) * fovProgress, configuredFov);
        if (curve != null && curve.isSmooth()) {
            float actualFov = CameraSetupEvent.WORLD_FOV_DYNAMICS.get();
            if (Float.isFinite(actualFov) && actualFov > 0) {
                return actualFov;
            }
        }
        return targetFov;
    }

    private static double calculateDrop(double distance, double lookY, float speedPerTick, float gravity, float friction) {
        double traveled = 0.0;
        double vertical = 0.0;
        double speed = speedPerTick;
        double verticalVelocity = lookY * speedPerTick;
        int maxTicks = 20 * 30;
        for (int i = 0; i < maxTicks && traveled < distance && speed > 1.0E-4; i++) {
            double step = Math.min(speed, distance - traveled);
            double ratio = step / speed;
            vertical += verticalVelocity * ratio;
            traveled += step;
            speed *= 1.0f - friction;
            verticalVelocity = verticalVelocity * (1.0f - friction) - gravity;
        }
        return vertical - lookY * distance;
    }

    private record EntityHit(class_243 hitPos) {
    }
}
