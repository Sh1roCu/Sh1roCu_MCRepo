package com.tacz.guns.client.renderer.block;

import net.minecraft.class_2350;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

/** 展示容器的槽位变换；输出是调用 ItemRenderer.renderStatic 之前的坐标空间。 */
public class DisplayItemTransforms {
    private DisplayItemTransforms() {}

    public static void apply(class_4587 pose, class_2350 facing, double x, double y, double offset, int rotation) {
        pose.method_22904(0.5D, 0.5D, 0.5D);
        pose.method_22907(class_7833.field_40716.rotationDegrees(180.0F - facing.method_10161() * 90.0F));
        pose.method_22904(x, y, offset);
        pose.method_22907(class_7833.field_40718.rotationDegrees(rotation * 45.0F));
        pose.method_22905(0.5F, 0.5F, 0.5F);
    }
}
