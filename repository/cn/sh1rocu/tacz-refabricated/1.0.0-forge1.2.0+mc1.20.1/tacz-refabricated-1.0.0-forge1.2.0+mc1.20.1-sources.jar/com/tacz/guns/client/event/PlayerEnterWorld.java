package com.tacz.guns.client.event;

import cn.sh1rocu.tacz.api.event.PlayerEvent;
import com.tacz.guns.resource.PackConvertor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import java.io.File;

@Environment(EnvType.CLIENT)
public class PlayerEnterWorld {
    public static void onPlayerEnterWorld(PlayerEvent.PlayerLoggedInEvent event) {
        File[] files = PackConvertor.FOLDER.toFile().listFiles();
        if (files != null && files.length > 0) {
            event.getEntity().method_43496(pre(class_2561.method_43471("message.tacz.convert_from_legacy.intro")));
            event.getEntity().method_43496(pre(class_2561.method_43471("message.tacz.convert_from_legacy.intro2")));
            class_2561 component = class_2561.method_43471("message.tacz.convert_from_legacy")
                    .method_10852(class_2561.method_43471("message.tacz.convert_from_legacy.button")
                            .method_27696(class_2583.field_24360.method_10977(class_124.field_1060)
                                    .method_10958(new class_2558(class_2558.class_2559.field_11750, "/tacz convert"))
                                    .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43471("message.tacz.convert_from_legacy.hover"))
                                    )));
            event.getEntity().method_43496(pre(component));
            event.getEntity().method_43496(pre(class_2561.method_43471("message.tacz.convert_from_legacy.hint")));
            event.getEntity().method_43496(pre(class_2561.method_43471("message.tacz.convert_from_legacy.hide")));
        }
    }

    private static class_2561 pre(class_2561 component) {
        return class_2561.method_43471("message.tacz.pre").method_10852(component);
    }
}
