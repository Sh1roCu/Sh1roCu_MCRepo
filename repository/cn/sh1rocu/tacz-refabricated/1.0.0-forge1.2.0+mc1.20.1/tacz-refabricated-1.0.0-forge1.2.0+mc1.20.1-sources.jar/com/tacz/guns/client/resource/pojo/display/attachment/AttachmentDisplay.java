package com.tacz.guns.client.resource.pojo.display.attachment;

import com.google.common.collect.Maps;
import com.google.gson.annotations.SerializedName;
import com.tacz.guns.client.resource.pojo.display.IDisplay;
import com.tacz.guns.client.resource.pojo.display.LaserConfig;
import com.tacz.guns.client.resource.pojo.display.SoundData;
import com.tacz.guns.client.resource.pojo.display.gun.TextShow;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import net.minecraft.class_2960;
import java.util.Map;

public class AttachmentDisplay implements IDisplay {
    @SerializedName("laser")
    private LaserConfig laserConfig;

    @SerializedName("slot")
    private class_2960 slotTextureLocation;

    @SerializedName("model")
    private class_2960 model;

    @SerializedName("texture")
    private class_2960 texture;

    @SerializedName("lod")
    @Nullable
    private AttachmentLod attachmentLod;

    @SerializedName("adapter")
    @Nullable
    private String adapterNodeName;

    @SerializedName("show_muzzle")
    private boolean showMuzzle = false;

    @SerializedName("show_mount")
    private boolean showMount = true;

    /**
     * Blockbench 模型单位，指向枪口前方；16 单位等于一格。
     * 用于将第一人称枪口粒子发射原点沿枪口方向前移（如加装长消音器/制退器时）。
     */
    @SerializedName("muzzle_flash_offset")
    private float muzzleFlashOffset = 0.0f;

    @SerializedName("text_show")
    private Map<String, TextShow> textShows = Maps.newHashMap();

    @SerializedName("zoom")
    @Nullable
    private float[] zoom;

    @SerializedName("views")
    @Nullable
    private int[] views;

    @SerializedName("scope")
    private boolean isScope = false;

    @SerializedName("scope_lens")
    private ScopeLensConfig scopeLens = new ScopeLensConfig();

    @SerializedName("sight")
    private boolean isSight = false;

    @SerializedName("fov")
    private float fov = 70;

    @SerializedName("views_fov")
    @Nullable
    private float[] viewsFov;

    @SerializedName("idle_scope_height_adjust")
    private float idleScopeHeightAdjust = 0;

    @SerializedName("sounds")
    private Map<String, SoundData> sounds = Maps.newHashMap();

    @SerializedName("mode")
    private String variantMode = "replace";

    @SerializedName("mount_offset")
    @Nullable
    private Vector3f mountOffset;

    public class_2960 getSlotTextureLocation() {
        return slotTextureLocation;
    }

    public class_2960 getModel() {
        return model;
    }

    public class_2960 getTexture() {
        return texture;
    }

    @Nullable
    public AttachmentLod getAttachmentLod() {
        return attachmentLod;
    }

    @Nullable
    public String getAdapterNodeName() {
        return adapterNodeName;
    }

    public boolean isShowMuzzle() {
        return showMuzzle;
    }

    public boolean isShowMount() {
        return showMount;
    }

    public float getMuzzleFlashOffset() {
        return muzzleFlashOffset;
    }

    public Map<String, TextShow> getTextShows() {
        return textShows;
    }

    @Nullable
    public float[] getZoom() {
        return zoom;
    }

    @Nullable
    public int[] getViews() {
        return views;
    }

    public boolean isScope() {
        return isScope;
    }

    public ScopeLensConfig getScopeLens() {
        return scopeLens;
    }

    public boolean isSight() {
        return isSight;
    }

    public float getFov() {
        return fov;
    }

    @Nullable
    public float[] getViewsFov() {
        return viewsFov;
    }

    public float getIdleScopeHeightAdjust() {
        return idleScopeHeightAdjust;
    }

    public Map<String, SoundData> getSounds() {
        return sounds;
    }

    public String getVariantMode() {
        return variantMode == null ? "replace" : variantMode;
    }

    @Nullable
    public Vector3f getMountOffset() {
        return mountOffset;
    }

    @Nullable
    public LaserConfig getLaserConfig() {
        return laserConfig;
    }

    @Override
    public void init() {
        if (scopeLens == null) scopeLens = new ScopeLensConfig();
        scopeLens.init();
        if (!Float.isFinite(muzzleFlashOffset) || muzzleFlashOffset < 0.0f) {
            muzzleFlashOffset = 0.0f;
        }
        if (slotTextureLocation != null) {
            slotTextureLocation = converter.method_45112(slotTextureLocation);
        }
        if (texture != null) {
            texture = converter.method_45112(texture);
        }
        if (attachmentLod != null && attachmentLod.modelTexture != null) {
            attachmentLod.modelTexture = converter.method_45112(attachmentLod.modelTexture);
        }
    }
}
