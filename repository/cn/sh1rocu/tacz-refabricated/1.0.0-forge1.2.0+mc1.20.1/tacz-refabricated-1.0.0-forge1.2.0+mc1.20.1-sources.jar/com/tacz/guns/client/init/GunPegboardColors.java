package com.tacz.guns.client.init;

import com.tacz.guns.GunMod;
import com.tacz.guns.block.entity.GunPegboardBlockEntity;
import com.tacz.guns.init.ModBlocks;
import com.tacz.guns.init.ModItems;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.class_1768;
import net.minecraft.class_2960;
import net.minecraft.class_5272;

@Environment(EnvType.CLIENT)
public final class GunPegboardColors {
    public static void blockColors() {
        ColorProviderRegistry.BLOCK.register((state, level, pos, tint) -> level != null && pos != null
                && level.method_8321(pos) instanceof GunPegboardBlockEntity pegboard && pegboard.getColor() >= 0
                ? pegboard.getColor() : -1, ModBlocks.GUN_PEGBOARD, ModBlocks.GLOW_GUN_PEGBOARD);
    }

    public static void itemColors() {
        ColorProviderRegistry.ITEM.register((stack, tint) -> ((class_1768) stack.method_7909()).method_7801(stack)
                ? ((class_1768) stack.method_7909()).method_7800(stack) : -1, ModItems.GUN_PEGBOARD, ModItems.GLOW_GUN_PEGBOARD);
    }

    public static void setup() {
        class_5272.method_27879(ModItems.GUN_PEGBOARD, new class_2960(GunMod.MOD_ID, "dyed"),
                (stack, level, entity, seed) -> ((class_1768) stack.method_7909()).method_7801(stack) ? 1 : 0);
        class_5272.method_27879(ModItems.GLOW_GUN_PEGBOARD, new class_2960(GunMod.MOD_ID, "dyed"),
                (stack, level, entity, seed) -> ((class_1768) stack.method_7909()).method_7801(stack) ? 1 : 0);
    }
}
