package com.tacz.guns.api.client.other;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.class_1309;
import net.minecraft.class_3532;
import net.minecraft.class_630;

/**
 * 简单的第三人称持枪动画 Manager
 */
public final class ThirdPersonManager {
    private static final Map<String, IThirdPersonAnimation> CACHE = Maps.newHashMap();
    private static final String RESERVED_DEFAULT_NAME = "default";
    private static final IThirdPersonAnimation DEFAULT = new IThirdPersonAnimation() {
        @Override
        public void animateGunHold(class_1309 entity, class_630 rightArm, class_630 leftArm, class_630 body, class_630 head) {
            rightArm.field_3675 = -0.3F + head.field_3675;
            leftArm.field_3675 = 0.8F + head.field_3675;
            rightArm.field_3654 = -1.4F + head.field_3654;
            leftArm.field_3654 = -1.4F + head.field_3654;
        }

        @Override
        public void animateGunAim(class_1309 entity, class_630 rightArm, class_630 leftArm, class_630 body, class_630 head, float aimProgress) {
            float lerp1 = class_3532.method_16439(aimProgress, 0.3f, 0.35f);
            float lerp2 = class_3532.method_16439(aimProgress, 1.4f, 1.6f);
            rightArm.field_3675 = -lerp1 + head.field_3675;
            leftArm.field_3675 = 0.8F + head.field_3675;
            rightArm.field_3654 = -lerp2 + head.field_3654;
            leftArm.field_3654 = -lerp2 + head.field_3654;
        }
    };

    private static final String MINI_GUN_NAME = "minigun";
    private static final IThirdPersonAnimation MINI_GUN = new IThirdPersonAnimation() {
        @Override
        public void animateGunHold(class_1309 entity, class_630 rightArm, class_630 leftArm, class_630 body, class_630 head) {
            body.field_3675 = head.field_3675 + 0.8f;

            double cosTheta = Math.cos(-body.field_3675);
            double sinTheta = Math.sin(-body.field_3675);

            float x = rightArm.field_3657;
            rightArm.field_3657 = (float) (x * cosTheta);
            rightArm.field_3655 = (float) (x * sinTheta);

            rightArm.field_3675 = -1.0F + body.field_3675;
            rightArm.field_3654 = -0.1F + body.field_3654;

            float x2 = leftArm.field_3657;
            leftArm.field_3657 = (float) (x2 * cosTheta);
            leftArm.field_3655 = (float) (x2 * sinTheta);

            leftArm.field_3675 = -0.1F + body.field_3675;
            leftArm.field_3654 = -1F + body.field_3654;
        }

        @Override
        public void animateGunAim(class_1309 entity, class_630 rightArm, class_630 leftArm, class_630 body, class_630 head, float aimProgress) {
            this.animateGunHold(entity, rightArm, leftArm, body, head);
        }
    };

    public static void registerDefault() {
        CACHE.put(RESERVED_DEFAULT_NAME, DEFAULT);
        CACHE.put(MINI_GUN_NAME, MINI_GUN);
    }

    public static void register(String name, IThirdPersonAnimation animation) {
        if (name.equals(RESERVED_DEFAULT_NAME)) {
            return;
        }
        CACHE.put(name, animation);
    }

    public static IThirdPersonAnimation getAnimation(String name) {
        return CACHE.getOrDefault(name, DEFAULT);
    }
}
