package com.tacz.guns.client.input;

import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.client.gui.GunRefitScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

import static com.tacz.guns.util.InputExtraCheck.isInGame;

@Environment(EnvType.CLIENT)
public class RefitKey {
    public static final class_304 REFIT_KEY = new class_304("key.tacz.refit.desc",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_Z,
            "key.category.tacz");

    public static void onRefitPress() {
        if (!isInGame()) {
            return;
        }
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null || player.method_7325() || !IGun.mainHandHoldGun(player)) {
            return;
        }
        if (IClientPlayerGunOperator.fromLocalPlayer(player).isCharging()) {
            return;
        }
        IGun iGun = IGun.getIGunOrNull(player.method_6047());
        if (iGun != null && iGun.hasAttachmentLock(player.method_6047())) {
            return;
        }
        mc.method_1507(new GunRefitScreen());
    }
}
