package com.tacz.guns.client.particle;

import com.tacz.guns.init.ModBlocks;
import com.tacz.guns.particles.BulletHoleOption;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_638;

public final class HitBlockEffectHandler {
    private static final int MAX_SAME_STEP_SOUND_PER_TICK = 1;
    private static final double MAX_HIT_STEP_SOUND_DISTANCE_SQR = 64.0D * 64.0D;
    private static final Map<class_3414, SoundLimit> STEP_SOUND_LIMITS = new HashMap<>();

    private HitBlockEffectHandler() {
    }

    public static void handle(class_638 level, class_243 hitPos, class_2350 direction, class_2338 blockPos, String ammoId, String gunId, String gunDisplayId, boolean incendiary) {
        class_2680 state = level.method_8320(blockPos);
        if (state.method_27852(ModBlocks.TARGET) || shouldRemove(level, blockPos, hitPos)) {
            return;
        }
        HitSurfaceParticleSpawner.spawn(level, hitPos, direction, blockPos, ammoId, gunId, gunDisplayId, incendiary);
        playHitBlockStepSound(level, state, hitPos.field_1352, hitPos.field_1351, hitPos.field_1350);
        if (BulletHoleParticle.isBulletHoleEnabled(ammoId, gunId, gunDisplayId)) {
            level.method_8466(new BulletHoleOption(direction, blockPos, ammoId, gunId, gunDisplayId, incendiary), true, hitPos.field_1352, hitPos.field_1351, hitPos.field_1350, 0, 0, 0);
        }
    }

    private static void playHitBlockStepSound(class_638 level, class_2680 state, double x, double y, double z) {
        if (!canHearHitBlockStepSound(x, y, z)) {
            return;
        }
        class_2498 soundType = state.method_26231();
        class_3414 stepSound = soundType.method_10594();
        if (!canPlayStepSound(level, stepSound)) {
            return;
        }
        float volume = soundType.method_10597() * 0.6F;
        float pitch = soundType.method_10599() * (0.9F + level.field_9229.method_43057() * 0.2F);
        level.method_8486(x, y, z, stepSound, class_3419.field_15245, volume, pitch, false);
    }

    private static boolean canHearHitBlockStepSound(double x, double y, double z) {
        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null) {
            return false;
        }
        return minecraft.field_1724.method_5649(x, y, z) <= MAX_HIT_STEP_SOUND_DISTANCE_SQR;
    }

    private static boolean canPlayStepSound(class_638 level, class_3414 sound) {
        long gameTime = level.method_8510();
        SoundLimit limit = STEP_SOUND_LIMITS.get(sound);
        if (limit == null || limit.gameTime != gameTime) {
            STEP_SOUND_LIMITS.put(sound, new SoundLimit(gameTime, 1));
            return true;
        }
        if (limit.count >= MAX_SAME_STEP_SOUND_PER_TICK) {
            return false;
        }
        limit.count++;
        return true;
    }

    private static boolean shouldRemove(class_638 level, class_2338 blockPos, class_243 hitPos) {
        class_2680 blockState = level.method_8320(blockPos);
        if (blockState.method_26215()) {
            return true;
        }
        class_265 shape = blockState.method_26220(level, blockPos);
        if (shape.method_1110()) {
            return true;
        }
        class_238 baseBlockBoundingBox = shape.method_1107();
        class_238 blockBoundingBox = baseBlockBoundingBox.method_996(blockPos);
        boolean intersects = blockBoundingBox.method_1003(
                hitPos.field_1352 - 0.1, hitPos.field_1351 - 0.1, hitPos.field_1350 - 0.1,
                hitPos.field_1352 + 0.1, hitPos.field_1351 + 0.1, hitPos.field_1350 + 0.1);
        return !intersects;
    }

    private static class SoundLimit {
        private final long gameTime;
        private int count;

        private SoundLimit(long gameTime, int count) {
            this.gameTime = gameTime;
            this.count = count;
        }
    }
}
