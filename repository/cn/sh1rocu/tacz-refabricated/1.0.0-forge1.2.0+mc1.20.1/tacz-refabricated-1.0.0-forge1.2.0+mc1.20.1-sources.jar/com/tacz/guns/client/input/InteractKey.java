package com.tacz.guns.client.input;

import com.tacz.guns.api.item.IGun;
import com.tacz.guns.block.AmmoStorageBlock;
import com.tacz.guns.block.GunDisplayCaseBlock;
import com.tacz.guns.client.event.GunDisplayCaseClientInteractionEvent;
import com.tacz.guns.config.util.InteractKeyConfigRead;
import com.tacz.guns.network.message.ClientMessageAmmoStorageInteract;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

import static com.tacz.guns.util.InputExtraCheck.isInGame;

@Environment(EnvType.CLIENT)
public class InteractKey {
    public static final class_304 INTERACT_KEY = new class_304("key.tacz.interact.desc",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_O,
            "key.category.tacz");

    public static boolean onInteractControllerPress(boolean isPress) {
        return isPress && onInteractPress();
    }

    public static boolean onInteractPress() {
        if (!isInGame()) {
            return false;
        }
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null || player.method_7325()) {
            return false;
        }
        if (!IGun.mainHandHoldGun(player)) {
            return false;
        }
        class_239 hitResult = mc.field_1765;
        if (hitResult == null) {
            return false;
        }
        if (hitResult instanceof class_3965 blockHitResult) {
            interactBlock(blockHitResult, player, mc);
            return true;
        }
        if (hitResult instanceof class_3966 entityHitResult) {
            interactEntity(entityHitResult, mc);
            return true;
        }
        return false;
    }

    private static void interactBlock(class_3965 blockHitResult, class_746 player, class_310 mc) {
        class_2338 blockPos = blockHitResult.method_17777();
        class_2680 block = player.method_37908().method_8320(blockPos);
        if (block.method_26204() instanceof GunDisplayCaseBlock) {
            GunDisplayCaseClientInteractionEvent.showHintForTarget(mc, true);
        }
        if (block.method_26204() instanceof AmmoStorageBlock) {
            ClientPlayNetworking.send(new ClientMessageAmmoStorageInteract(blockPos));
            return;
        }
        if (InteractKeyConfigRead.canInteractBlock(block)) {
            mc.method_1583();
        }
    }

    private static void interactEntity(class_3966 entityHitResult, class_310 mc) {
        class_1297 entity = entityHitResult.method_17782();
        if (InteractKeyConfigRead.canInteractEntity(entity)) {
            mc.method_1583();
        }
    }
}
