package com.tacz.guns.api.item;

import javax.annotation.Nullable;
import net.minecraft.class_1799;
import net.minecraft.class_2960;

public interface IBlock {
    /**
     * 获取方块 ID
     *
     * @param block 输入物品
     * @return 方块 ID
     */
    class_2960 getBlockId(class_1799 block);

    /**
     * 设置方块 ID
     */
    void setBlockId(class_1799 block, @Nullable class_2960 blockId);
}
