package com.tacz.guns.api.item.builder;

import com.tacz.guns.api.DefaultAssets;
import com.tacz.guns.api.item.IAttachment;
import com.tacz.guns.init.ModItems;
import net.minecraft.class_1799;
import net.minecraft.class_2960;

public class AttachmentItemBuilder {
    private int count = 1;
    private class_2960 attachmentId = DefaultAssets.DEFAULT_ATTACHMENT_ID;

    private AttachmentItemBuilder() {
    }

    public static AttachmentItemBuilder create() {
        return new AttachmentItemBuilder();
    }

    public AttachmentItemBuilder setCount(int count) {
        this.count = Math.max(count, 1);
        return this;
    }

    public AttachmentItemBuilder setId(class_2960 id) {
        this.attachmentId = id;
        return this;
    }

    @Deprecated
    public AttachmentItemBuilder setSkinId(class_2960 skinId) {
        return this;
    }

    public class_1799 build() {
        class_1799 attachment = new class_1799(ModItems.ATTACHMENT, this.count);
        if (attachment.method_7909() instanceof IAttachment iAttachment) {
            iAttachment.setAttachmentId(attachment, this.attachmentId);
        }
        return attachment;
    }
}
