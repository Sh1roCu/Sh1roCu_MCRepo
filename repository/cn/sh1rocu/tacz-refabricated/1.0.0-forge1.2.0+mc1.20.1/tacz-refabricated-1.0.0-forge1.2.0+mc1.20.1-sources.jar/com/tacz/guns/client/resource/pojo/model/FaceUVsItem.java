package com.tacz.guns.client.resource.pojo.model;

import com.google.gson.annotations.SerializedName;
import net.minecraft.class_2350;

public class FaceUVsItem {
    @SerializedName("down")
    private FaceItem down;
    @SerializedName("east")
    private FaceItem east;
    @SerializedName("north")
    private FaceItem north;
    @SerializedName("south")
    private FaceItem south;
    @SerializedName("up")
    private FaceItem up;
    @SerializedName("west")
    private FaceItem west;

    public static FaceUVsItem singleSouthFace() {
        FaceUVsItem faces = new FaceUVsItem();
        faces.north = FaceItem.EMPTY;
        faces.east = FaceItem.EMPTY;
        faces.west = FaceItem.EMPTY;
        faces.south = FaceItem.single16X();
        faces.up = FaceItem.EMPTY;
        faces.down = FaceItem.EMPTY;
        return faces;
    }

    public FaceItem getFace(class_2350 direction) {
        switch (direction) {
            case field_11034:
                return west == null ? FaceItem.EMPTY : west;
            case field_11039:
                return east == null ? FaceItem.EMPTY : east;
            case field_11043:
                return north == null ? FaceItem.EMPTY : north;
            case field_11035:
                return south == null ? FaceItem.EMPTY : south;
            case field_11036:
                return down == null ? FaceItem.EMPTY : down;
            case field_11033:
            default:
                return up == null ? FaceItem.EMPTY : up;
        }
    }
}
