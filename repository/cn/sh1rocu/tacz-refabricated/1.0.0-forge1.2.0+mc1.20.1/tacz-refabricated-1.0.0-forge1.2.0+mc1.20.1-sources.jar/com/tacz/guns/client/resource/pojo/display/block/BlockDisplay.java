package com.tacz.guns.client.resource.pojo.display.block;

import com.google.gson.annotations.SerializedName;
import com.tacz.guns.client.resource.pojo.display.IDisplay;
import net.minecraft.class_2960;
import net.minecraft.class_809;

public class BlockDisplay implements IDisplay {
    @SerializedName("model")
    private class_2960 modelLocation;
    @SerializedName("texture")
    private class_2960 modelTexture;
    @SerializedName("transforms")
    private class_809 transforms;

    public class_2960 getModelLocation() {
        return modelLocation;
    }

    public class_2960 getModelTexture() {
        return modelTexture;
    }

    public class_809 getTransforms() {
        return transforms;
    }

    @Override
    public void init() {
        if (modelTexture != null) {
            modelTexture = converter.method_45112(modelTexture);
        }
    }
}
