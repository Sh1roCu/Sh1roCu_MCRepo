package com.tacz.guns.client.gui;

import cn.sh1rocu.tacz.mixin.client.accessor.ScreenAccessor;
import com.tacz.guns.GunMod;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.api.item.IAttachment;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.api.item.attachment.AttachmentType;
import com.tacz.guns.api.item.builder.AttachmentItemBuilder;
import com.tacz.guns.client.animation.screen.RefitTransform;
import com.tacz.guns.client.gui.components.FlatColorButton;
import com.tacz.guns.client.gui.components.refit.*;
import com.tacz.guns.client.resource.GunDisplayInstance;
import com.tacz.guns.client.resource.index.ClientAttachmentIndex;
import com.tacz.guns.client.sound.SoundPlayManager;
import com.tacz.guns.network.message.*;
import com.tacz.guns.resource.index.CommonAttachmentVariantIndex;
import com.tacz.guns.resource.index.CommonSlotAdapterIndex;
import com.tacz.guns.sound.SoundManager;
import com.tacz.guns.util.SlotAdapterHelper;
import com.tacz.guns.util.VariantHelper;
import com.tacz.guns.util.VirtualOemAttachment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_746;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.NotNull;

import java.util.*;

@Environment(EnvType.CLIENT)
public class GunRefitScreen extends class_437 {
    public static final class_2960 SLOT_TEXTURE = new class_2960(GunMod.MOD_ID, "textures/gui/refit_slot.png");
    public static final class_2960 TURN_PAGE_TEXTURE = new class_2960(GunMod.MOD_ID, "textures/gui/refit_turn_page.png");
    public static final class_2960 UNLOAD_TEXTURE = new class_2960(GunMod.MOD_ID, "textures/gui/refit_unload.png");
    public static final class_2960 ICONS_TEXTURE = new class_2960(GunMod.MOD_ID, "textures/gui/refit_slot_icons.png");

    public static final int ICON_UV_SIZE = 32;
    public static final int SLOT_SIZE = 18;
    private static final int VARIANT_BUTTON_WIDTH = 78;
    private static final int VARIANT_BUTTON_HEIGHT = 12;
    private static final int VARIANT_BUTTON_SPACING = 1;
    private static final int INVENTORY_ATTACHMENT_START_Y = 50;
    private static final int LIST_COLUMN_GAP = 4;
    private static final int INVENTORY_ATTACHMENT_SLOT_COUNT = 8;
    private static boolean HIDE_GUN_PROPERTY_DIAGRAMS = true;

    private int currentPage = 0;

    public GunRefitScreen() {
        super(class_2561.method_43470("Gun Refit Screen"));
        RefitTransform.init();
    }

    public static int getSlotTextureXOffset(class_1799 gunItem, AttachmentType attachmentType) {
        IGun iGun = IGun.getIGunOrNull(gunItem);
        if (iGun == null) {
            return -1;
        }
        if (!iGun.allowAttachmentType(gunItem, attachmentType)) {
            return ICON_UV_SIZE * 6;
        }
        switch (attachmentType) {
            case GRIP -> {
                return 0;
            }
            case LASER -> {
                return ICON_UV_SIZE;
            }
            case MUZZLE -> {
                return ICON_UV_SIZE * 2;
            }
            case SCOPE -> {
                return ICON_UV_SIZE * 3;
            }
            case STOCK -> {
                return ICON_UV_SIZE * 4;
            }
            case EXTENDED_MAG -> {
                return ICON_UV_SIZE * 5;
            }
        }
        return -1;
    }

    public static int getSlotsTextureWidth() {
        return ICON_UV_SIZE * 7;
    }

    @Override
    public void method_25426() {
        this.method_37067();
        // 添加配件槽位
        this.addAttachmentTypeButtons();
        // 添加可选配件列表
        this.addInventoryAttachmentButtons();
        // 添加属性图隐藏按钮
        if (HIDE_GUN_PROPERTY_DIAGRAMS) {
            this.method_37063(new FlatColorButton(11, 11, 288, 16,
                    class_2561.method_43471("gui.tacz.gun_refit.property_diagrams.show"), b -> switchHideButton()));
        } else {
            this.method_37063(new FlatColorButton(14, 14, 12, 12, class_2561.method_43470("S"), b -> {
                class_746 player = class_310.method_1551().field_1724;
                if (player == null || player.method_7325()) return;
                if (IGun.mainHandHoldGun(player)) {
                    IClientPlayerGunOperator.fromLocalPlayer(player).fireSelect();
                    this.method_25426();
                }
            }).setTooltips(class_2561.method_43471("gui.tacz.gun_refit.property_diagrams.fire_mode.switch")));
            int buttonYOffset = GunPropertyDiagrams.getHidePropertyButtonYOffset();
            this.method_37063(new FlatColorButton(11, buttonYOffset, 288, 12,
                    class_2561.method_43471("gui.tacz.gun_refit.property_diagrams.hide"), b -> switchHideButton()));
        }
    }

    @Override
    public void method_25394(@NotNull class_332 graphics, int mouseX, int mouseY, float pPartialTick) {
        super.method_25394(graphics, mouseX, mouseY, pPartialTick);

        if (!HIDE_GUN_PROPERTY_DIAGRAMS) {
            GunPropertyDiagrams.draw(graphics, field_22793, 11, 11);
        }

        ((ScreenAccessor) this).tacz$getRenderables().stream().filter(w -> w instanceof IComponentTooltip).forEach(w -> ((IComponentTooltip) w)
                .renderTooltip(component -> graphics.method_51434(field_22793, component, mouseX, mouseY)));
        ((ScreenAccessor) this).tacz$getRenderables().stream().filter(w -> w instanceof IStackTooltip).forEach(w -> ((IStackTooltip) w)
                .renderTooltip(stack -> renderAttachmentTooltip(graphics, stack, mouseX, mouseY)));
    }

    private void renderAttachmentTooltip(class_332 graphics, class_1799 stack, int mouseX, int mouseY) {
        if (!isBuiltinOemAttachment(stack)) {
            graphics.method_51446(field_22793, stack, mouseX, mouseY);
            return;
        }
        List<class_2561> tooltip = method_25408(Screens.getClient(this), stack);
        if (!tooltip.isEmpty()) {
            tooltip.set(0, tooltip.get(0).method_27661().method_10852(class_2561.method_43471("gui.tacz.refit.builtin_suffix")));
        }
        graphics.method_51437(field_22793, tooltip, stack.method_32347()/*, stack*/, mouseX, mouseY);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private void addInventoryAttachmentButtons() {
        class_746 player = Screens.getClient(this).field_1724;
        if (RefitTransform.getCurrentTransformType() == AttachmentType.NONE || player == null) {
            return;
        }
        int startX = this.field_22789 - 30;
        int startY = INVENTORY_ATTACHMENT_START_Y;
        int pageStart = currentPage * INVENTORY_ATTACHMENT_SLOT_COUNT;
        int count = 0;
        int currentY = startY;
        class_1661 inventory = player.method_31548();
        class_1799 gunItem = player.method_6047();
        IGun iGun = IGun.getIGunOrNull(gunItem);
        if (iGun == null) {
            return;
        }
        AttachmentType attachmentType = RefitTransform.getCurrentTransformType();
        Set<class_2960> displayedAttachmentIds = new HashSet<>();
        List<RefitAttachmentEntry> attachmentEntries = new ArrayList<>();
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 inventoryItem = inventory.method_5438(i);
            IAttachment attachment = IAttachment.getIAttachmentOrNull(inventoryItem);
            if (attachment != null && attachment.getType(inventoryItem) == attachmentType) {
                if (!iGun.allowAttachment(gunItem, inventoryItem)) {
                    continue;
                }
                displayedAttachmentIds.add(attachment.getAttachmentId(inventoryItem));
                attachmentEntries.add(new RefitAttachmentEntry(i, inventoryItem, false));
            }
        }

        getVirtualOemAttachments(gunItem, iGun, attachmentType, displayedAttachmentIds)
                .forEach(attachment -> attachmentEntries.add(new RefitAttachmentEntry(-1, attachment, true)));
        // 仅显式标注的内置原厂配件置顶，通用配件保持原有顺序。
        attachmentEntries.sort(Comparator.comparingInt(entry -> isBuiltinOemAttachment(entry.stack()) ? 0 : 1));

        for (RefitAttachmentEntry entry : attachmentEntries) {
            count++;
            if (count <= pageStart) {
                continue;
            }
            if (count > pageStart + INVENTORY_ATTACHMENT_SLOT_COUNT) {
                continue;
            }
            InventoryAttachmentSlot button;
            if (entry.virtualOem()) {
                button = new InventoryAttachmentSlot(startX, currentY, entry.stack(), inventory, b -> {
                    class_1799 attachmentStack = ((InventoryAttachmentSlot) b).getItemStack();
                    IAttachment attachment = IAttachment.getIAttachmentOrNull(attachmentStack);
                    if (attachment == null) {
                        return;
                    }
                    SoundPlayManager.playerRefitSound(attachmentStack, player, SoundManager.INSTALL_SOUND);
                    ClientMessageInstallVirtualAttachment message = new ClientMessageInstallVirtualAttachment(inventory.field_7545, attachmentType, attachment.getAttachmentId(attachmentStack));
                    ClientPlayNetworking.send(message);
                });
            } else {
                button = new InventoryAttachmentSlot(startX, currentY, entry.slotIndex(), inventory, b -> {
                    int slotIndex = ((InventoryAttachmentSlot) b).getSlotIndex();
                    SoundPlayManager.playerRefitSound(inventory.method_5438(slotIndex), player, SoundManager.INSTALL_SOUND);
                    ClientMessageRefitGun message = new ClientMessageRefitGun(slotIndex, inventory.field_7545, attachmentType);
                    ClientPlayNetworking.send(message);
                });
            }
            this.method_37063(button);
            currentY = currentY + SLOT_SIZE;
        }
        int totalPage = (count - 1) / INVENTORY_ATTACHMENT_SLOT_COUNT;
        RefitTurnPageButton turnPageButtonUp = new RefitTurnPageButton(startX, startY - 10, true, b -> {
            if (currentPage > 0) {
                currentPage--;
                method_25426();
            }
        });
        RefitTurnPageButton turnPageButtonDown = new RefitTurnPageButton(startX, startY + SLOT_SIZE * INVENTORY_ATTACHMENT_SLOT_COUNT + 2, false, b -> {
            if (currentPage < totalPage) {
                currentPage++;
                method_25426();
            }
        });
        if (currentPage < totalPage) {
            this.method_37063(turnPageButtonDown);
        }
        if (currentPage > 0) {
            this.method_37063(turnPageButtonUp);
        }
    }

    private void addAttachmentTypeButtons() {
        class_746 player = Screens.getClient(this).field_1724;
        if (player == null) {
            return;
        }
        IGun iGun = IGun.getIGunOrNull(player.method_6047());
        if (iGun == null) {
            return;
        }
        int startX = this.field_22789 - 30;
        int startY = 10;
        class_1661 inventory = player.method_31548();
        for (AttachmentType type : AttachmentType.values()) {
            if (type == AttachmentType.NONE) {
                if (RefitTransform.getCurrentTransformType() == AttachmentType.NONE) {
                    TimelessAPI.getGunDisplay(player.method_6047())
                            .map(GunDisplayInstance::getLaserConfig)
                            .ifPresent(laserConfig -> {
                                if (laserConfig.canEdit()) {
                                    // 添加镭射颜色选择器
                                    HSVSliderGroup hsvSliderGroup = new HSVSliderGroup(field_22789 - 140, field_22790 - 64, 120, 16, inventory, inventory.field_7545, AttachmentType.NONE);
                                    this.method_37063(hsvSliderGroup.getHueSlider());
                                    this.method_37063(hsvSliderGroup.getSaturationSlider());
                                }
                            });
                }
                continue;
            }
            GunAttachmentSlot button = new GunAttachmentSlot(startX, startY, type, inventory.field_7545, inventory, b -> {
                AttachmentType buttonType = ((GunAttachmentSlot) b).getType();
                // 如果这个槽位不允许安装配件，则默认退回概览，不选中槽位。
                if (!((GunAttachmentSlot) b).isAllow()) {
                    if (RefitTransform.changeRefitScreenView(AttachmentType.NONE)) {
                        this.method_25426();
                    }
                    return;
                }
                // 点击的是当前选中的槽位，则退回概览
                if (RefitTransform.getCurrentTransformType() == buttonType && buttonType != AttachmentType.NONE) {
                    if (RefitTransform.changeRefitScreenView(AttachmentType.NONE)) {
                        this.method_25426();
                    }
                    return;
                }
                // 切换选中的槽位。
                if (RefitTransform.changeRefitScreenView(buttonType)) {
                    this.method_25426();
                }
            });
            if (RefitTransform.getCurrentTransformType() == type) {
                button.setSelected(true);
                int adapterListX = this.field_22789 - 30 - VARIANT_BUTTON_WIDTH - LIST_COLUMN_GAP;
                boolean hasSlotAdapters = !SlotAdapterHelper.getAvailableSlotAdapters(player.method_6047(), type).isEmpty();
                int variantListX = hasSlotAdapters
                        ? adapterListX - VARIANT_BUTTON_WIDTH - LIST_COLUMN_GAP
                        : startX + SLOT_SIZE - VARIANT_BUTTON_WIDTH;
                // 添加拆卸配件按钮
                RefitUnloadButton unloadButton = new RefitUnloadButton(startX + 5, startY + SLOT_SIZE + 2, b -> {
                    class_1799 attachmentItem = button.getAttachmentItem();
                    if (!attachmentItem.method_7960()) {
                        int freeSlot = inventory.method_7376();
                        if (freeSlot != -1 || VirtualOemAttachment.isMarked(attachmentItem)) {
                            SoundPlayManager.playerRefitSound(attachmentItem, player, SoundManager.UNINSTALL_SOUND);
                            ClientMessageUnloadAttachment message = new ClientMessageUnloadAttachment(inventory.field_7545, RefitTransform.getCurrentTransformType());
                            ClientPlayNetworking.send(message);
                        } else {
                            player.method_43496(class_2561.method_43471("gui.tacz.gun_refit.unload.no_space"));
                        }
                    }
                });
                if (!button.getAttachmentItem().method_7960()) {
                    this.method_37063(unloadButton);
                    addVariantButtons(type, button.getAttachmentItem(), inventory,
                            variantListX, startY + SLOT_SIZE + 14);

                    if (button.getAttachmentItem().method_7909() instanceof IAttachment iAttachment) {
                        TimelessAPI.getClientAttachmentIndex(iAttachment.getAttachmentId(button.getAttachmentItem()))
                                .map(ClientAttachmentIndex::getLaserConfig)
                                .ifPresent(laserConfig -> {
                                    if (laserConfig.canEdit()) {
                                        // 添加镭射颜色选择器
                                        HSVSliderGroup hsvSliderGroup = new HSVSliderGroup(field_22789 - 140, field_22790 - 64, 120, 16, inventory, inventory.field_7545, type);
                                        this.method_37063(hsvSliderGroup.getHueSlider());
                                        this.method_37063(hsvSliderGroup.getSaturationSlider());
                                    }
                                });
                    }
                }
                addSlotAdapterButtons(type, button.getAttachmentItem(), inventory,
                        adapterListX, INVENTORY_ATTACHMENT_START_Y);
            }
            this.method_37063(button);
            startX = startX - SLOT_SIZE;
        }
    }

    private void addVariantButtons(AttachmentType type, class_1799 attachmentItem, class_1661 inventory, int x, int y) {
        if (!(attachmentItem.method_7909() instanceof IAttachment attachment)) {
            return;
        }
        class_2960 attachmentId = attachment.getAttachmentId(attachmentItem);
        List<Map.Entry<class_2960, CommonAttachmentVariantIndex>> variants = TimelessAPI.getAllCommonAttachmentVariantIndex().stream()
                .filter(entry -> entry.getValue().appliesTo(attachmentId))
                .sorted(Comparator.comparingInt(entry -> entry.getValue().getSort()))
                .toList();
        if (variants.isEmpty()) {
            return;
        }
        class_2960 current = VariantHelper.getVariant(attachmentItem);
        class_2561 standardLabel = current == null
                ? class_2561.method_43470("> ").method_10852(class_2561.method_43471("gui.tacz.refit.variant_default"))
                : class_2561.method_43471("gui.tacz.refit.variant_default");
        this.method_37063(new FlatColorButton(x, y, VARIANT_BUTTON_WIDTH, VARIANT_BUTTON_HEIGHT, standardLabel, b -> {
            ClientPlayNetworking.send(new ClientMessageSetAttachmentVariant(inventory.field_7545, type, null));
            this.method_25426();
        }));
        int currentY = y + VARIANT_BUTTON_HEIGHT + VARIANT_BUTTON_SPACING;
        for (Map.Entry<class_2960, CommonAttachmentVariantIndex> entry : variants) {
            class_2960 variantId = entry.getKey();
            class_2561 name = class_2561.method_43471(entry.getValue().getPojo().getName());
            class_2561 label = variantId.equals(current) ? class_2561.method_43470("> ").method_10852(name) : name;
            this.method_37063(new FlatColorButton(x, currentY, VARIANT_BUTTON_WIDTH, VARIANT_BUTTON_HEIGHT, label, b -> {
                ClientPlayNetworking.send(new ClientMessageSetAttachmentVariant(inventory.field_7545, type, variantId));
                this.method_25426();
            }));
            currentY += VARIANT_BUTTON_HEIGHT + VARIANT_BUTTON_SPACING;
        }
    }

    private void addSlotAdapterButtons(AttachmentType type, class_1799 attachmentItem, class_1661 inventory, int x, int y) {
        class_1799 gunItem = inventory.method_5438(inventory.field_7545);
        List<Map.Entry<class_2960, CommonSlotAdapterIndex>> adapters = SlotAdapterHelper.getAvailableSlotAdapters(gunItem, type);
        if (adapters.isEmpty()) {
            return;
        }

        class_2960 attachmentId = null;
        if (!attachmentItem.method_7960()) {
            IAttachment attachment = IAttachment.getIAttachmentOrNull(attachmentItem);
            if (attachment == null || attachment.getType(attachmentItem) != type) {
                return;
            }
            attachmentId = attachment.getAttachmentId(attachmentItem);
        }

        class_2960 current = SlotAdapterHelper.getSelectedAvailableSlotAdapter(gunItem, type);
        class_2960 currentAttachmentId = attachmentId;
        int currentY = y;

        boolean noneSelected = current == null;
        class_2561 noneLabel = noneSelected
                ? class_2561.method_43470("> ").method_10852(class_2561.method_43471("gui.tacz.refit.adapter_none"))
                : class_2561.method_43471("gui.tacz.refit.adapter_none");
        FlatColorButton noneButton = new FlatColorButton(x, currentY, VARIANT_BUTTON_WIDTH, VARIANT_BUTTON_HEIGHT, noneLabel, b -> {
            currentPage = 0;
            ClientPlayNetworking.send(new ClientMessageSetSlotAdapter(inventory.field_7545, type, null));
            this.method_25426();
        });
        if (currentAttachmentId != null && !SlotAdapterHelper.allowsDirectAttachment(gunItem, currentAttachmentId)) {
            noneButton.field_22763 = false;
            noneButton.setTooltips(class_2561.method_43471("gui.tacz.refit.adapter_requires_unload"));
        }
        this.method_37063(noneButton);
        currentY += VARIANT_BUTTON_HEIGHT + VARIANT_BUTTON_SPACING;

        for (Map.Entry<class_2960, CommonSlotAdapterIndex> entry : adapters) {
            class_2960 adapterId = entry.getKey();
            class_2561 name = class_2561.method_43471(entry.getValue().getPojo().getName());
            class_2561 label = adapterId.equals(current) ? class_2561.method_43470("> ").method_10852(name) : name;
            FlatColorButton adapterButton = new FlatColorButton(x, currentY, VARIANT_BUTTON_WIDTH, VARIANT_BUTTON_HEIGHT, label, b -> {
                currentPage = 0;
                ClientPlayNetworking.send(new ClientMessageSetSlotAdapter(inventory.field_7545, type, adapterId));
                this.method_25426();
            });
            if (currentAttachmentId != null && !entry.getValue().allowsAttachment(currentAttachmentId)) {
                adapterButton.field_22763 = false;
                adapterButton.setTooltips(class_2561.method_43471("gui.tacz.refit.adapter_requires_unload"));
            }
            this.method_37063(adapterButton);
            currentY += VARIANT_BUTTON_HEIGHT + VARIANT_BUTTON_SPACING;
        }
    }

    @Override
    public void method_25419() {
        // 关闭界面时，一次性上传所有的染色数据
        class_746 player = Screens.getClient(this).field_1724;
        if (player != null) {
            class_1799 gun = player.method_6047();
            if (player.method_6047().method_7909() instanceof IGun) {
                ClientMessageLaserColor message = new ClientMessageLaserColor(gun, player.method_31548().field_7545);
                ClientPlayNetworking.send(message);
            }
        }
        super.method_25419();
    }

    private void switchHideButton() {
        HIDE_GUN_PROPERTY_DIAGRAMS = !HIDE_GUN_PROPERTY_DIAGRAMS;
        this.method_25426();
    }

    private static List<class_1799> getVirtualOemAttachments(class_1799 gunItem, IGun iGun, AttachmentType type, Set<class_2960> excludedAttachmentIds) {
        class_2960 currentAttachmentId = iGun.getAttachmentId(gunItem, type);
        return TimelessAPI.getAllCommonAttachmentIndex().stream()
                .filter(entry -> entry.getValue().getType() == type)
                .filter(entry -> VirtualOemAttachment.isAllowedVirtualOem(iGun.getGunId(gunItem), entry.getKey(), type))
                .filter(entry -> VirtualOemAttachment.shouldShowIcon(iGun.getGunId(gunItem), entry.getKey(), type))
                .filter(entry -> !excludedAttachmentIds.contains(entry.getKey()))
                .sorted(Comparator.comparingInt(entry -> entry.getValue().getSort()))
                .map(entry -> Pair.of(entry.getKey(), AttachmentItemBuilder.create().setId(entry.getKey()).build()))
                .filter(pair -> !pair.getKey().equals(currentAttachmentId))
                .filter(pair -> iGun.allowAttachment(gunItem, pair.getValue()))
                .map(Pair::getValue)
                .toList();
    }

    private static boolean isBuiltinOemAttachment(class_1799 attachmentStack) {
        IAttachment attachment = IAttachment.getIAttachmentOrNull(attachmentStack);
        if (attachment == null) {
            return false;
        }
        return VirtualOemAttachment.isBuiltinAttachment(attachment.getAttachmentId(attachmentStack));
    }

    private record RefitAttachmentEntry(int slotIndex, class_1799 stack, boolean virtualOem) {
    }
}
