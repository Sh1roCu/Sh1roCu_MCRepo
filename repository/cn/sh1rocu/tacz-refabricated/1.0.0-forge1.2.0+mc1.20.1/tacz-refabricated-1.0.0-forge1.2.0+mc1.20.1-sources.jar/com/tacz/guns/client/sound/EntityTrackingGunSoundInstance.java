package com.tacz.guns.client.sound;

import javax.annotation.Nullable;
import net.minecraft.class_1117;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import java.lang.ref.WeakReference;

public class EntityTrackingGunSoundInstance extends GunSoundInstance implements class_1117 {
    private final WeakReference<class_1297> entityRef;
    private boolean stopped;

    public EntityTrackingGunSoundInstance(class_3414 soundEvent, class_3419 source, float volume, float pitch, class_1297 entity, int soundDistance,
                                          @Nullable class_2960 registryName, boolean mono, boolean useTaczSound) {
        super(soundEvent, source, volume, pitch, entity, soundDistance, registryName, mono, false, useTaczSound);
        this.entityRef = new WeakReference<>(entity);
    }

    @Override
    public boolean method_26273() {
        class_1297 entity = this.entityRef.get();
        return super.method_26273() && entity != null && !entity.method_5701();
    }

    @Override
    public boolean method_4793() {
        return this.stopped;
    }

    @Override
    public void method_16896() {
        class_1297 entity = this.entityRef.get();
        if (entity == null || entity.method_31481() || entity instanceof class_1309 livingEntity && livingEntity.method_29504()) {
            this.setStop();
            return;
        }
        this.field_5439 = entity.method_23317();
        this.field_5450 = entity.method_23320();
        this.field_5449 = entity.method_23321();
    }

    @Override
    public void setStop() {
        this.stopped = true;
        super.setStop();
    }
}