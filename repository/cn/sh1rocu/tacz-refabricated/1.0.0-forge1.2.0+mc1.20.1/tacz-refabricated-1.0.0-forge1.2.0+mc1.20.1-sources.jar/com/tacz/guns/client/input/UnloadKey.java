package com.tacz.guns.client.input;

import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

import static com.tacz.guns.util.InputExtraCheck.isInGame;

@Environment(EnvType.CLIENT)
public class UnloadKey {
    public static final class_304 UNLOAD_KEY = new class_304("key.tacz.unload.desc",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_R,
            "key.category.tacz");

    public static void onUnloadPress() {
        if (!isInGame()) {
            return;
        }
        class_746 player = class_310.method_1551().field_1724;
        if (player != null && player.method_5805() && !player.method_7325()) {
            IClientPlayerGunOperator.fromLocalPlayer(player).unloadAmmo();
        }
    }
}
