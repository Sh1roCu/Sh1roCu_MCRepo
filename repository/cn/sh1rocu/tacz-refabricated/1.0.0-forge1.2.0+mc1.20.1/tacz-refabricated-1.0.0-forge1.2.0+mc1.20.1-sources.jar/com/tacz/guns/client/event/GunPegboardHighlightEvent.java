package com.tacz.guns.client.event;

import com.tacz.guns.block.GunPegboardBlock;
import com.tacz.guns.block.GunPegboardSlotHelper;
import com.tacz.guns.block.entity.GunPegboardBlockEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_3965;
import net.minecraft.class_4588;
import net.minecraft.class_4668;
import net.minecraft.class_761;

@Environment(EnvType.CLIENT)
public class GunPegboardHighlightEvent {
    public static boolean onRenderBlockHighlight(WorldRenderContext worldRenderContext, class_3965 target) {
        class_2338 pos = target.method_17777();
        class_1297 cameraEntity = worldRenderContext.camera().method_19331();
        class_1937 level = cameraEntity.method_37908();
        class_2680 state = level.method_8320(pos);
        if (!(state.method_26204() instanceof GunPegboardBlock)) {
            return true;
        }
        class_2586 blockEntity = level.method_8321(pos);
        GunPegboardBlockEntity pegboard = blockEntity instanceof GunPegboardBlockEntity value ? value : null;
        if (cameraEntity.method_5715()) {
            renderOccupiedSlots(worldRenderContext, state, pos, pegboard);
            return true;
        }
        renderAimedSlot(worldRenderContext, state, pos, target, pegboard);

        return true;
    }

    private static void renderAimedSlot(WorldRenderContext context, class_2680 state, class_2338 pos, class_3965 target, GunPegboardBlockEntity pegboard) {
        int slot = GunPegboardSlotHelper.getSlot(state, pos, target.method_17784());
        if (slot < 0) {
            return;
        }
        boolean occupied = pegboard != null && !pegboard.getItem(slot).method_7960();
        renderSlotBox(context, state, pos, slot, occupied ? 1.0F : 1.0F, occupied ? 0.0F : 1.0F, 0.0F);
    }

    private static void renderOccupiedSlots(WorldRenderContext context, class_2680 state, class_2338 pos, GunPegboardBlockEntity pegboard) {
        if (pegboard == null) {
            return;
        }
        for (int slot = 0; slot < GunPegboardBlockEntity.SLOT_COUNT; slot++) {
            if (!pegboard.getItem(slot).method_7960()) {
                renderSlotBox(context, state, pos, slot, 1.0F, 0.0F, 0.0F);
            }
        }
    }

    private static void renderSlotBox(WorldRenderContext context, class_2680 state, class_2338 pos, int slot, float red, float green, float blue) {
        var consumer = context.consumers();
        if (consumer == null)
            return;

        class_243 camera = context.camera().method_19326();
        class_238 aabb = GunPegboardSlotHelper.getSlotAabb(state, pos, slot).method_989(-camera.field_1352, -camera.field_1351, -camera.field_1350);
        class_4588 buffer = consumer.getBuffer(PegboardHighlightRenderType.getLines());
        class_761.method_22982(context.matrixStack(), buffer, aabb, red, green, blue, 1.0F);
    }

    private static class PegboardHighlightRenderType extends class_4668 {
        private static final class_1921 LINES_NO_DEPTH = class_1921.method_24049(
                "tacz_pegboard_highlight",
                class_290.field_29337,
                class_293.class_5596.field_27377,
                256,
                false,
                false,
                class_1921.class_4688.method_23598()
                        .method_34578(field_29433)
                        .method_23609(field_21360)
                        .method_23607(field_22241)
                        .method_23604(field_21346)
                        .method_23616(field_21350)
                        .method_23603(field_21345)
                        .method_23617(false)
        );

        private PegboardHighlightRenderType(String name, Runnable setupState, Runnable clearState) {
            super(name, setupState, clearState);
        }

        private static class_1921 getLines() {
            return LINES_NO_DEPTH;
        }
    }
}
