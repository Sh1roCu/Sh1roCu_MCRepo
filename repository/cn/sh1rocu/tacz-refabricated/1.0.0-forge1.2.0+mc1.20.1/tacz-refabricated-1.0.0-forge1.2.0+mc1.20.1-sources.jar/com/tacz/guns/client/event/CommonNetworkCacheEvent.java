package com.tacz.guns.client.event;

import com.tacz.guns.client.resource.ClientIndexManager;
import com.tacz.guns.network.message.ServerMessageSyncGunPack;
import com.tacz.guns.resource.CommonAssetsManager;
import com.tacz.guns.resource.network.CommonNetworkCache;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_310;
import net.minecraft.class_634;

@Environment(EnvType.CLIENT)
public class CommonNetworkCacheEvent {
    public static void onClientPlayerLoggingIn(class_634 handler, PacketSender sender, class_310 client) {
        ServerMessageSyncGunPack.clearPendingSync();
        if (handler.method_48296() == null || handler.method_48296().method_10756()) {
            return;
        }
        CommonAssetsManager.clearInstance();
        CommonNetworkCache.INSTANCE.clear();
        ClientIndexManager.clear();
    }

    public static void onClientPlayerLoggingOut(class_634 handler, class_310 client) {
        ServerMessageSyncGunPack.clearPendingSync();
    }
}
