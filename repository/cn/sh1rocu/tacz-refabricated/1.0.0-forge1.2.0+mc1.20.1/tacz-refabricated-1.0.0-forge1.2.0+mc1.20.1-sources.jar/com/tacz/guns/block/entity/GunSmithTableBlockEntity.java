package com.tacz.guns.block.entity;

import com.tacz.guns.api.DefaultAssets;
import com.tacz.guns.init.ModBlocks;
import com.tacz.guns.inventory.GunSmithTableMenu;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

public class GunSmithTableBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory {
    public static final class_2591<GunSmithTableBlockEntity> TYPE = class_2591.class_2592.method_20528(GunSmithTableBlockEntity::new,
            ModBlocks.GUN_SMITH_TABLE,
            ModBlocks.WORKBENCH_111,
            ModBlocks.WORKBENCH_121,
            ModBlocks.WORKBENCH_211
    ).method_11034(null);

    private static final String ID_TAG = "BlockId";

    @Nullable
    private class_2960 id = null;

    public GunSmithTableBlockEntity(class_2338 pos, class_2680 blockState) {
        super(TYPE, pos, blockState);
    }

    public void setId(class_2960 id) {
        this.id = id;
    }

    @Nullable
    public class_2960 getId() {
        return id;
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    // TODO
//    @Override
//    @Environment(EnvType.CLIENT)
//    public AABB getRenderBoundingBox() {
//        return new AABB(worldPosition.offset(-2, 0, -2), worldPosition.offset(2, 1, 2));
//    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43470("Gun Smith Table");
    }

    @Override
    public void writeScreenOpeningData(class_3222 serverPlayer, class_2540 buf) {
        class_2960 rl = this.getId() == null ? DefaultAssets.DEFAULT_BLOCK_ID : this.getId();
        buf.method_10812(rl);
    }

    @Nullable
    @Override
    public class_1703 createMenu(int id, class_1661 inventory, class_1657 player) {
        return new GunSmithTableMenu(id, inventory, getId());
    }

    @Override
    public void method_11014(class_2487 tag) {
        super.method_11014(tag);
        if (tag.method_10573(ID_TAG, class_2520.field_33258)) {
            this.id = class_2960.method_12829(tag.method_10558(ID_TAG));
        } else {
            this.id = DefaultAssets.DEFAULT_BLOCK_ID;
        }
    }

    @Override
    protected void method_11007(class_2487 tag) {
        super.method_11007(tag);
        if (id != null) {
            tag.method_10582(ID_TAG, id.toString());
        }
    }

    @Override
    public class_2487 method_16887() {
        return method_38244();
    }
}
