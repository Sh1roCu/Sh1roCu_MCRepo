package com.tacz.guns.client.renderer.block;

import com.mojang.blaze3d.systems.RenderSystem;
import com.tacz.guns.block.GunPegboardBlock;
import com.tacz.guns.block.GunPegboardSlotHelper;
import com.tacz.guns.block.entity.GunPegboardBlockEntity;
import com.tacz.guns.client.renderer.item.DisplayItemRenderContext;
import com.tacz.guns.client.renderer.item.ItemPreviewRenderContext;
import com.tacz.guns.config.client.RenderConfig;
import com.tacz.guns.config.util.GunPegboardItemConfigRead;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_746;
import net.minecraft.class_765;
import net.minecraft.class_811;
import net.minecraft.class_827;

public class GunPegboardRenderer implements class_827<GunPegboardBlockEntity> {
    private static final double ITEM_FRAME_ITEM_OFFSET = 0.4375D - 3.0D / 16.0D;
    private static final float PREVIEW_ALPHA = 0.65F;

    public GunPegboardRenderer(class_5614.class_5615 context) {
    }

    @Override
    public void render(GunPegboardBlockEntity blockEntity, float partialTick, class_4587 poseStack, class_4597 buffer, int packedLight, int packedOverlay) {
        for (int slot = 0; slot < GunPegboardBlockEntity.SLOT_COUNT; slot++) {
            class_1799 stack = blockEntity.getItem(slot);
            if (stack.method_7960()) {
                continue;
            }
            if (DisplayGunMeshGroup.tryRender(blockEntity, slot, packedOverlay)) {
                continue;
            }
            class_2350 facing = GunPegboardSlotHelper.getSlotFacing(blockEntity.method_11010(), slot);
            int row = (slot % GunPegboardBlockEntity.SLOTS_PER_FACE) / GunPegboardBlockEntity.GRID_SIZE;
            int col = slot % GunPegboardBlockEntity.GRID_SIZE;
            double x = (col + 0.5D) / GunPegboardBlockEntity.GRID_SIZE - 0.5D;
            double y = (row + 0.5D) / GunPegboardBlockEntity.GRID_SIZE - 0.5D;

            int itemLight = isGlowing(blockEntity) ? class_765.method_23687(15, 15) : packedLight;
            renderPegboardItem(stack, blockEntity.method_10997(), facing, x, y, blockEntity.getRotation(slot), poseStack, buffer, itemLight, packedOverlay, 1.0F);
        }
        renderPlacementPreview(blockEntity, poseStack, buffer, packedLight, packedOverlay);
    }

    private static void renderPlacementPreview(GunPegboardBlockEntity blockEntity, class_4587 poseStack, class_4597 buffer, int packedLight, int packedOverlay) {
        class_310 minecraft = class_310.method_1551();
        class_746 player = minecraft.field_1724;
        class_1937 level = blockEntity.method_10997();
        if (player == null || level == null || player.method_5715() || !(minecraft.field_1765 instanceof class_3965 hit) || hit.method_17783() != class_239.class_240.field_1332) {
            return;
        }
        class_2338 pos = blockEntity.method_11016();
        if (!hit.method_17777().equals(pos)) {
            return;
        }
        class_1799 held = player.method_5998(class_1268.field_5808);
        if (held.method_7960() || !GunPegboardItemConfigRead.canPlace(held)) {
            return;
        }
        int slot = GunPegboardSlotHelper.getSlot(blockEntity.method_11010(), pos, hit.method_17784());
        if (slot < 0 || !blockEntity.getItem(slot).method_7960()) {
            return;
        }
        int row = (slot % GunPegboardBlockEntity.SLOTS_PER_FACE) / GunPegboardBlockEntity.GRID_SIZE;
        int col = slot % GunPegboardBlockEntity.GRID_SIZE;
        double x = (col + 0.5D) / GunPegboardBlockEntity.GRID_SIZE - 0.5D;
        double y = (row + 0.5D) / GunPegboardBlockEntity.GRID_SIZE - 0.5D;
        class_2350 facing = GunPegboardSlotHelper.getSlotFacing(blockEntity.method_11010(), slot);
        int itemLight = isGlowing(blockEntity) ? class_765.method_23687(15, 15) : packedLight;
        class_1799 preview = held.method_7972();
        preview.method_7939(1);
        renderPegboardItem(preview, level, facing, x, y, 0, poseStack, buffer, itemLight, packedOverlay, PREVIEW_ALPHA);
    }

    private static void renderPegboardItem(class_1799 stack, class_1937 level, class_2350 facing, double x, double y, int rotation, class_4587 poseStack, class_4597 buffer, int packedLight, int packedOverlay, float alpha) {
        poseStack.method_22903();
        DisplayItemTransforms.apply(poseStack, facing, x, y, ITEM_FRAME_ITEM_OFFSET, rotation);
        if (alpha < 1.0F) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, alpha);
            ItemPreviewRenderContext.setAlpha(alpha);
        }
        DisplayItemRenderContext.render(() -> class_310.method_1551().method_1480().method_23178(
                stack,
                class_811.field_4319,
                packedLight,
                alpha < 1.0F ? class_4608.field_21444 : packedOverlay,
                poseStack,
                buffer,
                level,
                0
        ));
        if (alpha < 1.0F) {
            ItemPreviewRenderContext.setAlpha(1.0F);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.disableBlend();
        }
        poseStack.method_22909();
    }

    private static boolean isGlowing(GunPegboardBlockEntity blockEntity) {
        return blockEntity.method_11010().method_26204() instanceof GunPegboardBlock pegboard && pegboard.isGlowing();
    }

    @Override
    public int method_33893() {
        return RenderConfig.TARGET_RENDER_DISTANCE.get();
    }

    @Override
    public boolean shouldRenderOffScreen(GunPegboardBlockEntity blockEntity) {
        return true;
    }

    @Override
    public boolean shouldRender(GunPegboardBlockEntity blockEntity, class_243 cameraPos) {
        return class_243.method_24953(blockEntity.method_11016()).method_24802(cameraPos, this.method_33893());
    }
}
