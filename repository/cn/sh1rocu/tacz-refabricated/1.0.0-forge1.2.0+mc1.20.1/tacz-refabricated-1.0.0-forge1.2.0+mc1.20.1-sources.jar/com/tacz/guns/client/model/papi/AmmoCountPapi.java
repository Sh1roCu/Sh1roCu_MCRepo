package com.tacz.guns.client.model.papi;

import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.client.gameplay.ClientAmmoCount;
import com.tacz.guns.client.resource.index.ClientGunIndex;
import com.tacz.guns.resource.pojo.data.gun.Bolt;
import com.tacz.guns.resource.pojo.data.gun.GunData;
import java.util.function.Function;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class AmmoCountPapi implements Function<class_1799, String> {
    public static final String NAME = "ammo_count";

    @Override
    public String apply(class_1799 stack) {
        IGun iGun = IGun.getIGunOrNull(stack);
        if (iGun != null) {
            class_2960 gunId = iGun.getGunId(stack);
            ClientGunIndex gunIndex = TimelessAPI.getClientGunIndex(gunId).orElse(null);
            if (gunIndex == null) {
                return "";
            }
            GunData gunData = gunIndex.getGunData();
            if (gunData == null) {
                return "";
            }
            class_746 player = class_310.method_1551().field_1724;
            int ammoCount = iGun.useInventoryAmmo(stack) && player != null && player.method_6047() == stack
                    ? ClientAmmoCount.getCached(player, stack, iGun)
                    : iGun.getCurrentAmmoCount(stack);
            ammoCount += iGun.hasBulletInBarrel(stack) && gunData.getBolt() != Bolt.OPEN_BOLT ? 1 : 0;
            return "" + ammoCount;
        }
        return "";
    }
}
