package com.tacz.guns.block.entity;

import com.tacz.guns.block.GunPegboardBlock;
import com.tacz.guns.block.GunPegboardSlotHelper;
import com.tacz.guns.block.PegboardShape;
import com.tacz.guns.init.ModBlocks;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;

public class GunPegboardBlockEntity extends class_2586 implements GunDisplayBlockEntity {
    public static final int GRID_SIZE = 4;
    public static final int SLOTS_PER_FACE = GRID_SIZE * GRID_SIZE;
    // 原有 0..15 槽位保持不变，16..31 属于折面；转角时每面仅启用三列。
    public static final int SLOT_COUNT = SLOTS_PER_FACE * 2;
    public static final class_2591<GunPegboardBlockEntity> TYPE = class_2591.class_2592.method_20528(GunPegboardBlockEntity::new, ModBlocks.GUN_PEGBOARD, ModBlocks.GLOW_GUN_PEGBOARD).method_11034(null);
    private static final String ITEMS_TAG = "Items";
    private static final String SLOT_TAG = "Slot";
    private static final String ITEM_TAG = "Item";
    private static final String ROTATIONS_TAG = "Rotations";
    private static final String SLOT_SHAPE_TAG = "SlotShape";
    private static final String COLOR_TAG = "Color";
    private static final String INHERITED_COLOR_TAG = "InheritedColor";

    private final class_1799[] items = new class_1799[SLOT_COUNT];
    private final byte[] rotations = new byte[SLOT_COUNT];
    private int color = -1;
    private boolean inheritedColor;
    private final DisplayGunSlot[] displaySlots = new DisplayGunSlot[SLOT_COUNT];

    public GunPegboardBlockEntity(class_2338 pos, class_2680 state) {
        super(TYPE, pos, state);
        for (int i = 0; i < items.length; i++) {
            items[i] = class_1799.field_8037;
        }
    }

    @Override
    public class_1799 getItem(int slot) {
        return GunPegboardSlotHelper.isSlotActive(method_11010(), slot) ? items[slot] : class_1799.field_8037;
    }

    public int getColor() {
        return color;
    }

    public boolean hasInheritedColor() {
        return inheritedColor;
    }

    public void setColor(int color, boolean inherited) {
        int normalized = color < 0 ? -1 : color & 0xFFFFFF;
        boolean inheritedColor = normalized >= 0 && inherited;
        if (this.color == normalized && this.inheritedColor == inheritedColor) return;
        this.color = normalized;
        this.inheritedColor = inheritedColor;
        if (field_11863 != null && !field_11863.method_8608()) {
            field_11863.method_8652(field_11867, method_11010().method_11657(GunPegboardBlock.DYED, this.color >= 0), class_2248.field_31036);
        }
        update();
    }

    @Override
    public int getRotation(int slot) {
        return isValidSlot(slot) ? rotations[slot] & 7 : 0;
    }

    @Override
    public DisplayGunSlot getDisplaySlot(int slot) {
        if (!isValidSlot(slot)) throw new IndexOutOfBoundsException(slot);
        DisplayGunSlot handle = displaySlots[slot];
        if (handle == null) displaySlots[slot] = handle = new DisplayGunSlot(this, slot);
        return handle;
    }

    @Override
    public int getGridSize() {
        return GRID_SIZE;
    }

    @Override
    public class_2350 getSlotFacing(int slot) {
        return GunPegboardSlotHelper.getSlotFacing(method_11010(), slot);
    }

    @Override
    public boolean isDisplayGlowing() {
        return method_11010().method_26204() instanceof GunPegboardBlock pegboard && pegboard.isGlowing();
    }

    @Override
    public class_2586 getBlockEntity() {
        return this;
    }

    private void displaySlotChanged(int slot) {
        if (displaySlots[slot] != null) displaySlots[slot].changed();
    }

    public boolean setItem(int slot, class_1799 stack) {
        if (!GunPegboardSlotHelper.isSlotActive(method_11010(), slot) || !items[slot].method_7960()) {
            return false;
        }
        class_1799 stored = stack.method_7972();
        stored.method_7939(1);
        items[slot] = stored;
        rotations[slot] = 0;
        displaySlotChanged(slot);
        update();
        return true;
    }

    /** Fill empty slots in one update when creating a display wall. */
    public boolean setItems(Map<Integer, class_1799> stacks) {
        if (stacks.isEmpty() || stacks.size() > SLOT_COUNT) {
            return false;
        }
        for (Map.Entry<Integer, class_1799> entry : stacks.entrySet()) {
            int slot = entry.getKey();
            if (!GunPegboardSlotHelper.isSlotActive(method_11010(), slot) || entry.getValue().method_7960() || !items[slot].method_7960()) {
                return false;
            }
        }
        for (Map.Entry<Integer, class_1799> entry : stacks.entrySet()) {
            int slot = entry.getKey();
            class_1799 stored = entry.getValue().method_7972();
            stored.method_7939(1);
            items[slot] = stored;
            rotations[slot] = 0;
            displaySlotChanged(slot);
        }
        update();
        return true;
    }

    public boolean rotateItem(int slot) {
        if (!GunPegboardSlotHelper.isSlotActive(method_11010(), slot) || items[slot].method_7960()) {
            return false;
        }
        rotations[slot] = (byte) ((rotations[slot] + 1) & 7);
        if (displaySlots[slot] != null) displaySlots[slot].transformed();
        update();
        return true;
    }

    public boolean dropItem(int slot) {
        if (!isValidSlot(slot) || items[slot].method_7960() || field_11863 == null) {
            return false;
        }
        class_2350 facing = GunPegboardSlotHelper.getSlotFacing(method_11010(), slot);
        class_2248.method_9577(field_11863, field_11867.method_10093(facing), items[slot]);
        items[slot] = class_1799.field_8037;
        rotations[slot] = 0;
        displaySlotChanged(slot);
        update();
        return true;
    }

    public boolean removeItem(int slot) {
        if (!isValidSlot(slot) || items[slot].method_7960()) {
            return false;
        }
        items[slot] = class_1799.field_8037;
        rotations[slot] = 0;
        displaySlotChanged(slot);
        update();
        return true;
    }

    public void dropAllItems() {
        if (field_11863 == null) {
            return;
        }
        for (int i = 0; i < SLOT_COUNT; i++) {
            if (!items[i].method_7960()) {
                class_2248.method_9577(field_11863, field_11867.method_10093(GunPegboardSlotHelper.getSlotFacing(method_11010(), i)), items[i]);
                items[i] = class_1799.field_8037;
                rotations[i] = 0;
                displaySlotChanged(i);
            }
        }
        update();
    }

    private void update() {
        method_5431();
        if (field_11863 != null) {
            class_2680 state = method_11010();
            field_11863.method_8413(field_11867, state, state, class_2248.field_31036);
        }
    }

    private static boolean isValidSlot(int slot) {
        return slot >= 0 && slot < SLOT_COUNT;
    }

    @Override
    public void method_31664(class_2680 state) {
        class_2680 previous = method_11010();
        super.method_31664(state);
        if (previous.method_11654(GunPegboardBlock.FACING) != state.method_11654(GunPegboardBlock.FACING)
                || previous.method_11654(GunPegboardBlock.SHAPE) != state.method_11654(GunPegboardBlock.SHAPE)) {
            boolean changed = false;
            for (int slot = 0; slot < SLOT_COUNT; slot++) {
                if (displaySlots[slot] != null) displaySlots[slot].transformed();
                boolean removedFace = slot >= SLOTS_PER_FACE
                        && previous.method_11654(GunPegboardBlock.SHAPE) != state.method_11654(GunPegboardBlock.SHAPE);
                if (field_11863 != null && !field_11863.method_8608() && !items[slot].method_7960()
                        && (!GunPegboardSlotHelper.isSlotActive(state, slot) || removedFace)) {
                    class_2248.method_9577(field_11863, field_11867.method_10093(GunPegboardSlotHelper.getSlotFacing(previous, slot)), items[slot]);
                    items[slot] = class_1799.field_8037;
                    rotations[slot] = 0;
                    displaySlotChanged(slot);
                    changed = true;
                }
            }
            if (changed) update();
        }
    }

    @Override
    public void method_11014(class_2487 tag) {
        super.method_11014(tag);
        color = tag.method_10573(COLOR_TAG, class_2520.field_33253) ? tag.method_10550(COLOR_TAG) & 0xFFFFFF : -1;
        inheritedColor = color >= 0 && tag.method_10577(INHERITED_COLOR_TAG);
        class_1799[] previousItems = items.clone();
        byte[] previousRotations = rotations.clone();
        for (int i = 0; i < items.length; i++) {
            items[i] = class_1799.field_8037;
            rotations[i] = 0;
        }
        if (tag.method_10573(ITEMS_TAG, class_2520.field_33259)) {
            class_2499 list = tag.method_10554(ITEMS_TAG, class_2520.field_33260);
            for (int i = 0; i < list.size(); i++) {
                class_2487 entry = list.method_10602(i);
                int slot = entry.method_10571(SLOT_TAG) & 255;
                if (isValidSlot(slot) && entry.method_10573(ITEM_TAG, class_2520.field_33260)) {
                    items[slot] = class_1799.method_7915(entry.method_10562(ITEM_TAG));
                }
            }
        }
        if (tag.method_10573(ROTATIONS_TAG, class_2520.field_33257)) {
            byte[] saved = tag.method_10547(ROTATIONS_TAG);
            System.arraycopy(saved, 0, rotations, 0, Math.min(saved.length, rotations.length));
        }
        PegboardShape shape = method_11010().method_11654(GunPegboardBlock.SHAPE);
        String savedShape = tag.method_10558(SLOT_SHAPE_TAG);
        // 结构镜像只转换方块状态；左右转角互换时，同步镜像每面的槽位列和旋转角度。
        boolean mirrored = shape == PegboardShape.CORNER_LEFT
                && savedShape.equals(PegboardShape.CORNER_RIGHT.method_15434())
                || shape == PegboardShape.CORNER_RIGHT
                && savedShape.equals(PegboardShape.CORNER_LEFT.method_15434());
        if (mirrored) {
            class_1799[] savedItems = items.clone();
            byte[] savedRotations = rotations.clone();
            for (int slot = 0; slot < SLOT_COUNT; slot++) {
                int mirroredSlot = slot - slot % GRID_SIZE + GRID_SIZE - 1 - slot % GRID_SIZE;
                items[mirroredSlot] = savedItems[slot];
                rotations[mirroredSlot] = (byte) (-savedRotations[slot] & 7);
            }
        }
        for (int i = 0; i < displaySlots.length; i++) {
            DisplayGunSlot handle = displaySlots[i];
            if (handle == null) continue;
            if (!class_1799.method_7973(previousItems[i], items[i])) handle.changed();
            else if (previousRotations[i] != rotations[i]) handle.transformed();
        }
    }

    @Override
    protected void method_11007(class_2487 tag) {
        super.method_11007(tag);
        tag.method_10582(SLOT_SHAPE_TAG, method_11010().method_11654(GunPegboardBlock.SHAPE).method_15434());
        if (color >= 0) tag.method_10569(COLOR_TAG, color);
        if (inheritedColor) tag.method_10556(INHERITED_COLOR_TAG, true);
        class_2499 list = new class_2499();
        for (int i = 0; i < items.length; i++) {
            if (!items[i].method_7960()) {
                class_2487 entry = new class_2487();
                entry.method_10567(SLOT_TAG, (byte) i);
                entry.method_10566(ITEM_TAG, items[i].method_7953(new class_2487()));
                list.add(entry);
            }
        }
        tag.method_10566(ITEMS_TAG, list);
        tag.method_10570(ROTATIONS_TAG, rotations);
    }

    @Override
    public class_2487 method_16887() {
        class_2487 tag = super.method_16887();
        method_11007(tag);
        // 网络更新不能按结构镜像解释，客户端可能尚未收到对应的方块状态。
        tag.method_10551(SLOT_SHAPE_TAG);
        return tag;
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    // TODO
//    @Override
//    public AABB getRenderBoundingBox() {
//        return new AABB(worldPosition.offset(-2, -2, -2), worldPosition.offset(3, 3, 3));
//    }
}
