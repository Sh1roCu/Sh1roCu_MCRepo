package com.tacz.guns.api.event.common;

import cn.sh1rocu.tacz.api.LogicalSide;
import cn.sh1rocu.tacz.api.event.BaseEvent;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

/**
 * 换弹流程结束或被打断后触发一次。
 * 不可取消的结束通知，此时弹药已经结算；阻止换弹请取消 {@link GunReloadEvent}。
 */
public class GunFinishReloadEvent extends BaseEvent implements KubeJSGunEventPoster<GunFinishReloadEvent> {
    private final class_1309 entity;
    private final class_1799 gunItemStack;
    private final LogicalSide logicalSide;

    public static final Event<Callback> EVENT = EventFactory.createArrayBacked(Callback.class, callbacks -> event -> {
        for (Callback callback : callbacks) {
            callback.post(event);
        }
    });

    public GunFinishReloadEvent(class_1309 entity, class_1799 gunItemStack, LogicalSide side) {
        this.entity = entity;
        this.gunItemStack = gunItemStack;
        this.logicalSide = side;
        postEventToKubeJS(this);
    }

    @Nullable
    public class_1309 getEntity() {
        return entity;
    }

    public class_1799 getGunItemStack() {
        return gunItemStack;
    }

    public LogicalSide getLogicalSide() {
        return logicalSide;
    }

    public interface Callback {
        void post(GunFinishReloadEvent event);
    }
}
