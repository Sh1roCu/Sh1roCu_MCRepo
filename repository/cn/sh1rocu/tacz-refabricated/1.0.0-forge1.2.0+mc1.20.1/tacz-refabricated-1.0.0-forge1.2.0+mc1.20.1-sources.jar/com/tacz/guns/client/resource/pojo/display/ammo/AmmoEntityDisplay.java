package com.tacz.guns.client.resource.pojo.display.ammo;

import com.google.gson.annotations.SerializedName;
import net.minecraft.class_2960;

public class AmmoEntityDisplay {
    @SerializedName("model")
    private class_2960 modelLocation;
    @SerializedName("texture")
    protected class_2960 modelTexture;

    public class_2960 getModelLocation() {
        return modelLocation;
    }

    public class_2960 getModelTexture() {
        return modelTexture;
    }
}
