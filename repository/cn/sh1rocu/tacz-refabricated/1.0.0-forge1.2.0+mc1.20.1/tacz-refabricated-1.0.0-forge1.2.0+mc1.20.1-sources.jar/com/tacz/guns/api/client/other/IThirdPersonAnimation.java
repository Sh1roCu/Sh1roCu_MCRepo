package com.tacz.guns.api.client.other;

import net.minecraft.class_1309;
import net.minecraft.class_630;

public interface IThirdPersonAnimation {
    /**
     * 第三人称动画：主手持有枪械时
     *
     * @param entity   持有枪械的实体
     * @param rightArm 右手模型
     * @param leftArm  左手模型
     * @param head     头部模型
     */
    void animateGunHold(class_1309 entity, class_630 rightArm, class_630 leftArm, class_630 body, class_630 head);

    /**
     * 第三人称动画：枪械瞄准时
     *
     * @param entity      持有枪械的实体
     * @param rightArm    右手模型
     * @param leftArm     左手模型
     * @param head        头部模型
     * @param aimProgress 瞄准进度 0-1
     */
    void animateGunAim(class_1309 entity, class_630 rightArm, class_630 leftArm, class_630 body, class_630 head, float aimProgress);
}
