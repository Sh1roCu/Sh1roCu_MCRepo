package com.tacz.guns.client.event;

import cn.sh1rocu.tacz.api.event.InputEvent;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.client.input.InteractKey;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1533;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public class ClientPreventGunClick {
    public static void onClickInput(InputEvent.InteractionKeyMappingTriggered event) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null) {
            return;
        }
        // 当交互键按下时，允许交互
        if (InteractKey.INTERACT_KEY.method_1434()) {
            return;
        }
        // 只要主手有枪，那么禁止交互
        class_1799 itemInHand = player.method_5998(class_1268.field_5808);
        if (itemInHand.method_7909() instanceof IGun) {
            // 展示框可以交互
            class_239 hitResult = class_310.method_1551().field_1765;
            if (hitResult instanceof class_3966 entityHitResult && entityHitResult.method_17782() instanceof class_1533) {
                return;
            }
            // 这个设置为 false 就能阻止客户端粒子的生成
            event.setSwingHand(false);
            event.setCanceled(true);
        }
    }
}
