package com.tacz.guns.client.model.functional;

import com.tacz.guns.client.model.BedrockAnimatedModel;
import com.tacz.guns.client.model.IFunctionalRenderer;
import com.tacz.guns.compat.iris.IrisCompat;
import com.tacz.guns.util.RenderHelper;
import net.minecraft.class_1306;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

public class LeftHandRender implements IFunctionalRenderer {
    private final BedrockAnimatedModel bedrockGunModel;

    public LeftHandRender(BedrockAnimatedModel bedrockGunModel) {
        this.bedrockGunModel = bedrockGunModel;
    }

    @Override
    public void render(class_4587 poseStack, class_4588 vertexBuffer, class_811 transformType, int light, int overlay) {
        render(poseStack, vertexBuffer, transformType, light, overlay, RenderHelper.getBufferSource(transformType));
    }

    @Override
    public void render(class_4587 poseStack, class_4588 vertexBuffer, class_811 transformType, int light, int overlay, class_4597 bufferSource) {
        if (transformType.method_29998()) {
            if (!bedrockGunModel.getRenderHand()) {
                return;
            }
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(180f));
            Matrix3f normal = new Matrix3f(poseStack.method_23760().method_23762());
            Matrix4f pose = new Matrix4f(poseStack.method_23760().method_23761());
            //和枪械模型共用顶点缓冲的都需要代理到渲染结束后渲染
            bedrockGunModel.delegateRender((poseStack1, vertexBuffer1, transformType1, light1, overlay1) -> {
                class_4587 poseStack2 = new class_4587();
                poseStack2.method_23760().method_23762().mul(normal);
                poseStack2.method_23760().method_23761().mul(pose);
                RenderHelper.renderFirstPersonArm(class_310.method_1551().field_1724, class_1306.field_6182, poseStack2, light1, bufferSource);
                if (!IrisCompat.endBatch(bufferSource)) {
                    RenderHelper.endBatch(bufferSource);
                }
            });
        }
    }
}
