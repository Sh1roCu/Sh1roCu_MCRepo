package com.tacz.guns.client.gameplay;

import cn.sh1rocu.tacz.api.mixin.ForcePoseInjection;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.config.sync.SyncConfig;
import com.tacz.guns.network.message.ClientMessagePlayerCrawl;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_4050;
import net.minecraft.class_746;

public class LocalPlayerCrawl {
    /**
     * 冷却时间为 10 tick
     */
    private static final int COOLDOWN_TICKS = 10;
    private final class_746 player;
    private boolean isCrawling = false;
    private int crawCooldownTicks = 0;

    public LocalPlayerCrawl(class_746 player) {
        this.player = player;
    }

    public void crawl(boolean isCrawl) {
        // 退出不能被冷却、切枪或离地拦截，且只同步实际发生的状态变化。
        if (!isCrawl) {
            setCrawling(false);
            return;
        }
        class_1799 mainHandItem = player.method_6047();
        if (isCrawling || crawCooldownTicks > 0 || !canCrawl()) {
            return;
        }
        if (mainHandItem.method_7909() instanceof IGun gun
                && TimelessAPI.getClientGunIndex(gun.getGunId(mainHandItem)).isEmpty()) {
            return;
        }
        setCrawling(true);
        this.crawCooldownTicks = COOLDOWN_TICKS;
    }

    public void tickCrawl() {
        if (crawCooldownTicks > 0) {
            crawCooldownTicks--;
        }
        if (!isCrawling) {
            return;
        }
        boolean poseChanged = ((ForcePoseInjection) player).tacz$getForcedPose() != class_4050.field_18079;
        if (poseChanged || !canCrawl()) {
            setCrawling(false);
        }
    }

    public boolean isCrawling() {
        return isCrawling;
    }

    private boolean canCrawl() {
        if (!SyncConfig.ENABLE_CRAWL.get()) {
            return false;
        }
        boolean invalidState = !player.method_5805() || player.method_7325() || player.method_5765();
        boolean invalidMovement = player.field_6282 || player.method_5681() || !player.method_24828();
        boolean incompatiblePose = player.method_6113() || player.method_6128() || player.method_6123();
        if (invalidState || invalidMovement || incompatiblePose) {
            return false;
        }
        class_1799 mainHandItem = player.method_6047();
        if (mainHandItem.method_7909() instanceof IGun gun) {
            return gun.isCanCrawl(mainHandItem)
                    && TimelessAPI.getCommonGunIndex(gun.getGunId(mainHandItem)).isPresent();
        }
        return SyncConfig.ENABLE_CRAWL_WITHOUT_GUN.get();
    }

    private void setCrawling(boolean crawling) {
        if (isCrawling == crawling) {
            return;
        }
        isCrawling = crawling;
        // 趴下状态变化时设置或清除一次
        if (crawling || ((ForcePoseInjection) player).tacz$getForcedPose() == class_4050.field_18079) {
            ((ForcePoseInjection) player).tacz$setForcedPose(crawling ? class_4050.field_18079 : null);
        }
        ClientPlayNetworking.send(new ClientMessagePlayerCrawl(crawling));
    }
}
