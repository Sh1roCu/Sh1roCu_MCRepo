package com.tacz.guns.client.animation.statemachine;

import net.minecraft.class_1799;

public class ThrowableAnimationStateContext extends ItemAnimationStateContext {
    private class_1799 currentItem = class_1799.field_8037;
    private int usingTick = 0;
    private boolean using = false;

    public void setCurrentItem(class_1799 currentItem) {
        this.currentItem = currentItem;
    }

    public int getStackCount() {
        return currentItem.method_7947();
    }

    public int getUsingTick() {
        return usingTick;
    }

    public void setUsingTick(int throwTime) {
        this.usingTick = throwTime;
    }

    public boolean isUsing() {
        return using;
    }

    public void setUsing(boolean using) {
        this.using = using;
    }
}
