package com.tacz.guns.client.renderer.item;

import com.tacz.guns.client.model.BedrockGunModel;
import com.tacz.guns.client.model.bedrock.BedrockPart;
import com.tacz.guns.client.resource.pojo.TransformScale;
import org.joml.Vector3f;

import java.util.List;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_811;

/**
 * 现有 TACZ 模型的外部视角局部变换，仅供旧渲染路径使用。
 * 输入仍处于 ItemRenderer 调用自定义物品渲染器时的坐标空间；不包含槽位或相机变换。
 * SBM 模型有独立坐标约定，不能将本类的翻转矩阵直接套到 SBM 顶点上。
 */
public final class GunItemTransforms {
    private GunItemTransforms() {}

    public static void apply(class_811 context, TransformScale scale, BedrockGunModel model, class_4587 pose) {
        pose.method_22904(0.5, 2, 0.5);
        pose.method_22905(-1, -1, 1);
        switch (context) {
            case field_4319 -> applyPositioningNode(model.getFixedOriginPath(), pose, scale.getFixed());
            case field_4318 -> applyPositioningNode(model.getGroundOriginPath(), pose, scale.getGround());
            case field_4320, field_4323 ->
                    applyPositioningNode(model.getThirdPersonHandOriginPath(), pose, scale.getThirdPerson());
        }
        applyScale(context, scale, pose);
    }

    private static void applyScale(class_811 context, TransformScale scale, class_4587 pose) {
        if (scale == null) return;
        Vector3f value = switch (context) {
            case field_4319 -> scale.getFixed();
            case field_4318 -> scale.getGround();
            case field_4320, field_4323 -> scale.getThirdPerson();
            default -> null;
        };
        if (value != null) {
            pose.method_22904(0, 1.5, 0);
            pose.method_22905(value.x(), value.y(), value.z());
            pose.method_22904(0, -1.5, 0);
        }
    }

    private static void applyPositioningNode(List<BedrockPart> path, class_4587 pose, Vector3f scale) {
        if (path == null) return;
        if (scale == null) scale = new Vector3f(1, 1, 1);
        pose.method_22904(0, 1.5, 0);
        for (int i = path.size() - 1; i >= 0; i--) {
            BedrockPart part = path.get(i);
            pose.method_22907(class_7833.field_40713.rotation(part.xRot));
            pose.method_22907(class_7833.field_40715.rotation(part.yRot));
            pose.method_22907(class_7833.field_40717.rotation(part.zRot));
            if (part.getParent() != null) {
                pose.method_46416(-part.x * scale.x() / 16.0F, -part.y * scale.y() / 16.0F, -part.z * scale.z() / 16.0F);
            } else {
                pose.method_46416(-part.x * scale.x() / 16.0F, (1.5F - part.y / 16.0F) * scale.y(), -part.z * scale.z() / 16.0F);
            }
        }
        pose.method_22904(0, -1.5, 0);
    }
}
