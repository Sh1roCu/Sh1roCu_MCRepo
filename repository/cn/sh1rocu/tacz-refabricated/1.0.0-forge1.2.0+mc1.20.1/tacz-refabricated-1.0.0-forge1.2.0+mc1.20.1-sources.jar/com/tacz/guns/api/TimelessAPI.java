package com.tacz.guns.api;

import com.tacz.guns.api.client.other.IThirdPersonAnimation;
import com.tacz.guns.api.client.other.ThirdPersonManager;
import com.tacz.guns.api.item.IAttachment;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.client.resource.ClientIndexManager;
import com.tacz.guns.client.resource.GunDisplayInstance;
import com.tacz.guns.client.resource.index.ClientAmmoIndex;
import com.tacz.guns.client.resource.index.ClientAttachmentIndex;
import com.tacz.guns.client.resource.index.ClientAttachmentVariantIndex;
import com.tacz.guns.client.resource.index.ClientBlockIndex;
import com.tacz.guns.client.resource.index.ClientGunIndex;
import com.tacz.guns.client.resource.index.ClientSlotAdapterIndex;
import com.tacz.guns.crafting.GunSmithTableRecipe;
import com.tacz.guns.resource.CommonAssetsManager;
import com.tacz.guns.resource.index.CommonAmmoIndex;
import com.tacz.guns.resource.index.CommonAttachmentIndex;
import com.tacz.guns.resource.index.CommonAttachmentVariantIndex;
import com.tacz.guns.resource.index.CommonBlockIndex;
import com.tacz.guns.resource.index.CommonGunIndex;
import com.tacz.guns.resource.index.CommonSlotAdapterIndex;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public final class TimelessAPI {
    @Environment(EnvType.CLIENT)
    public static Optional<GunDisplayInstance> getGunDisplay(class_1799 stack) {
        if (stack.method_7909() instanceof IGun iGun) {
            class_2960 gunId = iGun.getGunId(stack);
            if (getCommonGunIndex(gunId).isEmpty()) {
                return Optional.empty();
            }
            class_2960 displayId = iGun.getGunDisplayId(stack);
            if (displayId.equals(DefaultAssets.DEFAULT_GUN_DISPLAY_ID)) {
                return getClientGunIndex(gunId).map(ClientGunIndex::getDefaultDisplay);
            } else {
                return getGunDisplay(displayId, gunId);
            }
        }
        return Optional.empty();
    }

    @Environment(EnvType.CLIENT)
    public static Optional<ClientGunIndex> getClientGunIndex(class_2960 gunId) {
        return Optional.ofNullable(ClientIndexManager.GUN_INDEX.get(gunId));
    }

    @Environment(EnvType.CLIENT)
    public static Optional<GunDisplayInstance> getGunDisplay(class_2960 displayId, class_2960 fallbackGunId) {
        if (displayId == null || displayId.equals(DefaultAssets.DEFAULT_GUN_DISPLAY_ID)) {
            return getClientGunIndex(fallbackGunId).map(ClientGunIndex::getDefaultDisplay);
        }

        GunDisplayInstance instance = ClientIndexManager.getOrCreateGunDisplay(displayId);
        if (instance == null) {
            return getClientGunIndex(fallbackGunId).map(ClientGunIndex::getDefaultDisplay);
        }
        return Optional.of(instance);
    }

    @Environment(EnvType.CLIENT)
    public static Optional<ClientAttachmentIndex> getClientAttachmentIndex(class_2960 attachmentId) {
        return Optional.ofNullable(ClientIndexManager.ATTACHMENT_INDEX.get(attachmentId));
    }

    @Environment(EnvType.CLIENT)
    public static Optional<ClientAttachmentVariantIndex> getClientAttachmentVariantIndex(class_1799 attachment) {
        class_2960 variantId = com.tacz.guns.util.VariantHelper.getVariant(attachment);
        if (variantId == null) {
            return Optional.empty();
        }
        IAttachment iAttachment = IAttachment.getIAttachmentOrNull(attachment);
        if (iAttachment == null) {
            return Optional.empty();
        }
        class_2960 attachmentId = iAttachment.getAttachmentId(attachment);
        boolean valid = getCommonAttachmentVariantIndex(variantId)
                .map(index -> index.appliesTo(attachmentId))
                .orElse(false);
        if (!valid) {
            return Optional.empty();
        }
        return Optional.ofNullable(ClientIndexManager.ATTACHMENT_VARIANT_INDEX.get(variantId));
    }

    @Environment(EnvType.CLIENT)
    public static Optional<ClientAttachmentVariantIndex> getClientAttachmentVariantIndex(class_2960 variantId) {
        return Optional.ofNullable(ClientIndexManager.ATTACHMENT_VARIANT_INDEX.get(variantId));
    }

    @Environment(EnvType.CLIENT)
    public static Optional<ClientSlotAdapterIndex> getClientSlotAdapterIndex(class_2960 adapterId) {
        return Optional.ofNullable(ClientIndexManager.SLOT_ADAPTER_INDEX.get(adapterId));
    }

    @Environment(EnvType.CLIENT)
    public static Optional<ClientAmmoIndex> getClientAmmoIndex(class_2960 ammoId) {
        return Optional.ofNullable(ClientIndexManager.AMMO_INDEX.get(ammoId));
    }

    @Environment(EnvType.CLIENT)
    public static Optional<ClientBlockIndex> getClientBlockIndex(class_2960 blockId) {
        return Optional.ofNullable(ClientIndexManager.BLOCK_INDEX.get(blockId));
    }

    @Environment(EnvType.CLIENT)
    public static Set<Map.Entry<class_2960, ClientGunIndex>> getAllClientGunIndex() {
        return ClientIndexManager.getAllGuns();
    }

    @Environment(EnvType.CLIENT)
    public static Set<Map.Entry<class_2960, ClientAmmoIndex>> getAllClientAmmoIndex() {
        return ClientIndexManager.getAllAmmo();
    }

    @Environment(EnvType.CLIENT)
    public static Set<Map.Entry<class_2960, ClientAttachmentIndex>> getAllClientAttachmentIndex() {
        return ClientIndexManager.getAllAttachments();
    }

    @Environment(EnvType.CLIENT)
    public static Set<Map.Entry<class_2960, ClientAttachmentVariantIndex>> getAllClientAttachmentVariantIndex() {
        return ClientIndexManager.getAllAttachmentVariants();
    }

    @Environment(EnvType.CLIENT)
    public static Set<Map.Entry<class_2960, ClientSlotAdapterIndex>> getAllClientSlotAdapterIndex() {
        return ClientIndexManager.getAllSlotAdapters();
    }

    public static Optional<CommonBlockIndex> getCommonBlockIndex(class_2960 blockId) {
        return Optional.ofNullable(CommonAssetsManager.get().getBlockIndex(blockId));
    }

    public static Optional<CommonGunIndex> getCommonGunIndex(class_2960 gunId) {
        return Optional.ofNullable(CommonAssetsManager.get().getGunIndex(gunId));
    }

    public static Optional<CommonAttachmentIndex> getCommonAttachmentIndex(class_2960 attachmentId) {
        return Optional.ofNullable(CommonAssetsManager.get().getAttachmentIndex(attachmentId));
    }

    public static Optional<CommonAttachmentVariantIndex> getCommonAttachmentVariantIndex(class_2960 variantId) {
        return Optional.ofNullable(CommonAssetsManager.get().getAttachmentVariantIndex(variantId));
    }

    public static Optional<CommonSlotAdapterIndex> getCommonSlotAdapterIndex(class_2960 adapterId) {
        return Optional.ofNullable(CommonAssetsManager.get().getSlotAdapterIndex(adapterId));
    }

    public static Optional<CommonAmmoIndex> getCommonAmmoIndex(class_2960 ammoId) {
        return Optional.ofNullable(CommonAssetsManager.get().getAmmoIndex(ammoId));
    }

    /**
     * @deprecated 不再使用独立的配方同步，而是使用原版的配方加载器<br/>
     * 请用 {@link net.minecraft.class_1863#method_8130(class_2960)}和{@link net.minecraft.class_1863#method_30027(class_3956)}获取配方
     */
    @Deprecated
    public static Optional<GunSmithTableRecipe> getRecipe(class_2960 recipeId) {
        return Optional.empty();
    }

    public static Set<Map.Entry<class_2960, CommonBlockIndex>> getAllCommonBlockIndex() {
        return CommonAssetsManager.get().getAllBlocks();
    }

    public static Set<Map.Entry<class_2960, CommonGunIndex>> getAllCommonGunIndex() {
        return CommonAssetsManager.get().getAllGuns();
    }

    public static Set<Map.Entry<class_2960, CommonAmmoIndex>> getAllCommonAmmoIndex() {
        return CommonAssetsManager.get().getAllAmmos();
    }

    public static Set<Map.Entry<class_2960, CommonAttachmentIndex>> getAllCommonAttachmentIndex() {
        return CommonAssetsManager.get().getAllAttachments();
    }

    public static Set<Map.Entry<class_2960, CommonAttachmentVariantIndex>> getAllCommonAttachmentVariantIndex() {
        return CommonAssetsManager.get().getAllAttachmentVariants();
    }

    public static Set<Map.Entry<class_2960, CommonSlotAdapterIndex>> getAllCommonSlotAdapterIndex() {
        return CommonAssetsManager.get().getAllSlotAdapters();
    }

    /**
     * @deprecated 不再使用独立的配方同步，而是使用原版的配方加载器<br/>
     * 请用 {@link net.minecraft.class_1863#method_8130(class_2960)}和{@link net.minecraft.class_1863#method_30027(class_3956)}获取配方
     */
    @Deprecated
    public static Map<class_2960, GunSmithTableRecipe> getAllRecipes() {
        return Map.of();
    }

    public static void registerThirdPersonAnimation(String name, IThirdPersonAnimation animation) {
        ThirdPersonManager.register(name, animation);
    }
}
