package com.tacz.guns.client.event;

import cn.sh1rocu.tacz.api.event.InputEvent;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.block.GunDisplayCaseBlock;
import com.tacz.guns.client.gui.overlay.DisplayCaseLockHintOverlay;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class GunDisplayCaseClientInteractionEvent {
    public static void onUseKey(InputEvent.Key event) {
        class_310 minecraft = class_310.method_1551();
        class_746 player = minecraft.field_1724;
        if (player == null || player.method_7325() || event.getAction() != GLFW.GLFW_PRESS || !minecraft.field_1690.field_1904.method_1417(event.getKey(), event.getScanCode())) {
            return;
        }
        if (!player.method_6047().method_7960() || player.method_5715()) {
            return;
        }
        showHintForTarget(minecraft, false);
    }

    public static void onUseMouse(InputEvent.MouseButton.Post event) {
        class_310 minecraft = class_310.method_1551();
        class_746 player = minecraft.field_1724;
        if (player == null || player.method_7325() || event.getAction() != GLFW.GLFW_PRESS || !minecraft.field_1690.field_1904.method_1433(event.getButton())) {
            return;
        }
        if (!player.method_6047().method_7960() || player.method_5715()) {
            return;
        }
        showHintForTarget(minecraft, false);
    }

    public static void showHintForTarget(class_310 minecraft, boolean lockedOnly) {
        if (!(minecraft.field_1765 instanceof class_3965 hit) || hit.method_17783() != class_239.class_240.field_1332 || minecraft.field_1687 == null) {
            return;
        }
        class_2680 state = minecraft.field_1687.method_8320(hit.method_17777());
        if (!(state.method_26204() instanceof GunDisplayCaseBlock)) {
            return;
        }
        boolean locked = state.method_11654(GunDisplayCaseBlock.LOCKED);
        if (lockedOnly && !locked) {
            return;
        }
        DisplayCaseLockHintOverlay.show(createHint(locked, minecraft));
    }

    private static class_2561 createHint(boolean locked, class_310 minecraft) {
        String shiftKey = minecraft.field_1690.field_1832.method_16007().getString();
        String useKey = minecraft.field_1690.field_1904.method_16007().getString();
        String chord = shiftKey + " + " + useKey;
        return class_2561.method_43469(locked ? "gui.tacz.display_case.locked_hint" : "gui.tacz.display_case.unlocked_hint", chord);
    }

    public static boolean holdingGun(class_746 player) {
        return player.method_6047().method_7909() instanceof IGun;
    }
}
