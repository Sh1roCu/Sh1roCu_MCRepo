package com.tacz.guns.client.renderer.item;

import cn.sh1rocu.simplebedrockmodel.api.event.ViewportEvent;
import com.google.common.base.Suppliers;
import com.github.mcmodderanchor.simplebedrockmodel.v1.client.handler.FirstPersonRenderHandler;
import com.github.mcmodderanchor.simplebedrockmodel.v1.common.resource.pojo.ParticleEffectData;
import com.github.mcmodderanchor.simplebedrockmodel.v1.particle.firstperson.FirstPersonParticleSystem;
import com.github.mcmodderanchor.simplebedrockmodel.v1.particle.render.CameraStateCache;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.client.animation.statemachine.LuaAnimationStateMachine;
import com.tacz.guns.api.client.event.BeforeRenderHandEvent;
import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.client.animation.screen.RefitTransform;
import com.tacz.guns.client.animation.statemachine.GunAnimationConstant;
import com.tacz.guns.client.animation.statemachine.GunAnimationStateContext;
import com.tacz.guns.client.event.CameraSetupEvent;
import com.tacz.guns.client.event.FirstPersonRenderGunEvent;
import com.tacz.guns.client.model.BedrockGunModel;
import com.tacz.guns.client.model.IFunctionalRenderer;
import com.tacz.guns.client.model.SlotModel;
import com.tacz.guns.client.model.bedrock.BedrockPart;
import com.tacz.guns.client.model.functional.MuzzleFlashRender;
import com.tacz.guns.client.model.functional.ShellRender;
import com.tacz.guns.client.particle.MuzzleParticleManager;
import com.tacz.guns.client.resource.GunDisplayInstance;
import com.tacz.guns.util.RenderDistance;
import com.tacz.guns.util.math.MathUtil;
import org.apache.commons.lang3.tuple.Pair;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.class_1047;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_746;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import static com.tacz.guns.client.particle.ThirdPersonMuzzleParticleManager.currentEntity;
import static com.tacz.guns.client.particle.ThirdPersonMuzzleParticleManager.onMuzzleRendered;
import static net.minecraft.class_811.*;

/**
 * 负责主要的枪械动画模型渲染。额外的效果见 {@link com.tacz.guns.client.event.FirstPersonRenderGunEvent}
 */
public class GunItemRendererWrapper extends AnimateGeoItemRenderer<BedrockGunModel, GunAnimationStateContext> {
    private static final SlotModel SLOT_GUN_MODEL = new SlotModel();
    private static BedrockGunModel lastModel = null;
    public static final Vector3f muzzleRenderOffset = new Vector3f();

    public static final Supplier<GunItemRendererWrapper> INSTANCE = Suppliers.memoize(GunItemRendererWrapper::new);

    public GunItemRendererWrapper() {
        super();
    }

    @Override
    public GunAnimationStateContext initContext(class_1799 stack, class_1657 player, float partialTick) {
        GunAnimationStateContext context = new GunAnimationStateContext();
        this.updateContext(context, stack, player, partialTick);
        return context;
    }

    @Override
    public void updateContext(GunAnimationStateContext context, class_1799 stack, class_1657 player, float partialTick) {
        context.setPartialTicks(partialTick);
        context.setCurrentGunItem(stack);
    }

    @Override
    public void tryInit(class_1799 stack, class_1657 player, float partialTick) {
        super.tryInit(stack, player, partialTick);
    }

    @Override
    public void tryExit(class_1799 stack, long putAwayTime) {
        var stateMachine = getStateMachine(stack);
        if (stateMachine == null) {
            return;
        }
        stateMachine.processContextIfExist(context -> {
            context.setPutAwayTime(putAwayTime / 1000F);
            context.setCurrentGunItem(stack);
        });
        if (stateMachine.isInitialized()) {
            stateMachine.trigger(GunAnimationConstant.INPUT_PUT_AWAY);
//            KeepingItemRenderer.getRenderer().keep(stack, putAwayTime);
            stateMachine.exit();
            stateMachine.setExitingTime(putAwayTime + 50);
        }
    }

    @Override
    public long getPutAwayTime(class_1799 stack) {
        if (stack.method_7909() instanceof IGun iGun) {
            return TimelessAPI.getCommonGunIndex(iGun.getGunId(stack))
                    .map(index -> (long) (index.getGunData().getPutAwayTime() * 1000L))
                    .orElse(0L);
        }
        return 0;
    }

    @Nullable
    @Override
    public LuaAnimationStateMachine<GunAnimationStateContext> getStateMachine(class_1799 stack) {
        return TimelessAPI.getGunDisplay(stack).map(GunDisplayInstance::getAnimationStateMachine).orElse(null);
    }

    @Override
    public BedrockGunModel getModel(class_1799 stack) {
        return TimelessAPI.getGunDisplay(stack).map(GunDisplayInstance::getGunModel).orElse(null);
    }

    @Override
    public class_2960 getTextureLocation(class_1799 stack) {
        return TimelessAPI.getGunDisplay(stack).map(GunDisplayInstance::getModelTexture).orElse(null);
    }

    @Override
    public void applyLevelCameraAnimation(ViewportEvent.ComputeCameraAngles event, class_1799 stack, class_746 player) {
        if (!(stack.method_7909() instanceof IGun iGun)) {
            return;
        }
        Optional.ofNullable(getModel(stack)).ifPresent(model -> {
            if (lastModel != model) {
                // 切换枪械模型的时候清理一下摄像机动画数据，以避免上一次播放到一半的摄像机动画影响观感。
                model.cleanCameraAnimationTransform();
                lastModel = model;
            }
            IClientPlayerGunOperator clientPlayerGunOperator = IClientPlayerGunOperator.fromLocalPlayer(player);
            float partialTicks = class_310.method_1551().method_1488();
            float aimingProgress = clientPlayerGunOperator.getClientAimingProgress(partialTicks);
            float zoom = iGun.getAimingZoom(stack);
            float multiplier = 1 - aimingProgress + aimingProgress / (float) Math.sqrt(zoom);
            this.applyLevelCameraAnimation(event, stack, multiplier);
        });
    }

    @Override
    public void applyItemInHandCameraAnimation(BeforeRenderHandEvent event, class_1799 stack, class_746 player) {
        if (!(stack.method_7909() instanceof IGun iGun)) {
            return;
        }
        Optional.ofNullable(getModel(stack)).ifPresent(model -> {
            class_4587 poseStack = event.getPoseStack();
            IClientPlayerGunOperator clientPlayerGunOperator = IClientPlayerGunOperator.fromLocalPlayer(player);
            float partialTicks = class_310.method_1551().method_1488();
            float aimingProgress = clientPlayerGunOperator.getClientAimingProgress(partialTicks);
            float zoom = iGun.getAimingZoom(stack);
            float multiplier = 1 - aimingProgress + aimingProgress / (float) Math.sqrt(zoom);
            Quaternionf quaternion = MathUtil.multiplyQuaternion(model.getCameraAnimationObject().rotationQuaternion, multiplier);
            poseStack.method_22907(quaternion);
            // 截至目前，摄像机动画数据已消费完毕。是否有更好的清理动画数据的方法？
            model.cleanCameraAnimationTransform();
        });
    }

    @Override
    public void renderFirstPerson(class_746 player, class_1799 stack, class_811 ctx, class_4587 poseStack, class_4597 bufferSource,
                                  int light, float partialTick) {
        if (!(stack.method_7909() instanceof IGun)) {
            return;
        }

        TimelessAPI.getGunDisplay(stack).ifPresent(display -> {
            BedrockGunModel gunModel = display.getGunModel();
            var animationStateMachine = display.getAnimationStateMachine();
            if (gunModel == null) {
                return;
            }

            // 在渲染之前，先更新动画，让动画数据写入模型
            List<ParticleEffectData> pendingParticles = null;
            if (animationStateMachine != null) {
                animationStateMachine.processContextIfExist(context -> {
                    updateContext(context, stack, player, partialTick);
                });
                animationStateMachine.update();
                // 消费本帧动画 particle_effects 关键帧触发的粒子请求
                pendingParticles = animationStateMachine.getAnimationController().consumePendingParticles();
            }

            poseStack.method_22903();
            // 逆转原版施加在手上的延滞效果，改为写入模型动画数据中
            float xRotOffset = class_3532.method_16439(partialTick, player.field_3914, player.field_3916);
            float yRotOffset = class_3532.method_16439(partialTick, player.field_3931, player.field_3932);
            float xRot = player.method_5695(partialTick) - xRotOffset;
            float yRot = player.method_5705(partialTick) - yRotOffset;
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(xRot * -0.1F));
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(yRot * -0.1F));
            BedrockPart rootNode = gunModel.getRootNode();
            if (rootNode != null) {
                xRot = (float) Math.tanh(xRot / 25) * 25;
                yRot = (float) Math.tanh(yRot / 25) * 25;
                rootNode.offsetX += yRot * 0.1F / 16F / 3F;
                rootNode.offsetY += -xRot * 0.1F / 16F / 3F;
                rootNode.additionalQuaternion.mul(class_7833.field_40714.rotationDegrees(xRot * 0.05F));
                rootNode.additionalQuaternion.mul(class_7833.field_40716.rotationDegrees(yRot * 0.05F));
            }
            // 从渲染原点 (0, 24, 0) 移动到模型原点 (0, 0, 0)
            poseStack.method_46416(0, 1.5f, 0);
            // 基岩版模型是上下颠倒的，需要翻转过来。
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(180f));
            // 应用持枪姿态变换，如第一人称摄像机定位
            FirstPersonRenderGunEvent.applyFirstPersonGunTransform(player, stack, poseStack, gunModel, partialTick);

            class_1268 particleHand = ctx == class_811.field_4321
                    ? class_1268.field_5810 : class_1268.field_5808;
            gunModel.setParticleWindowRenderer(new IFunctionalRenderer() {
                @Override
                public void render(class_4587 poseStack1, class_4588 vertexBuffer1, class_811 transformType1, int light1, int overlay1) {
                }

                @Override
                public void render(class_4587 poseStack1, class_4588 vertexBuffer1, class_811 transformType1, int light1, int overlay1, class_4597 particleBuffer) {
                    Matrix4f basePose = MuzzleParticleManager.getBasePose(particleHand);
                    if (basePose == null) {
                        return;
                    }
                    poseStack1.method_22903();
                    poseStack1.method_23760().method_23761().set(basePose);
                    // 枪口照明只作用于模型；烟雾仍读取原始环境光，火光粒子自身保持全亮。
                    FirstPersonRenderHandler.renderParticlesNow(particleHand, poseStack1, particleBuffer, light, partialTick);
                    poseStack1.method_22909();
                }
            });

            // 开启第一人称弹壳和火焰渲染
            MuzzleFlashRender.isSelf = true;
            ShellRender.isSelf = true;
            // 如果正在打开改装界面，则取消手臂渲染
            boolean renderHand = gunModel.getRenderHand();
            if (RefitTransform.getOpeningProgress() != 0) {
                gunModel.setRenderHand(false);
            }
            class_1268 hand = ctx == class_811.field_4321
                    ? class_1268.field_5810 : class_1268.field_5808;
            MuzzleParticleManager.spawnAndBind(FirstPersonRenderHandler.getParticleSystem(), poseStack, gunModel, hand, pendingParticles);
            // 调用枪械模型渲染
            class_1921 renderType = display.enablesTransparency()
                    ? class_1921.method_23580(display.getModelTexture())
                    : class_1921.method_23576(display.getModelTexture());
            int modelLight = MuzzleParticleManager.getFirstPersonModelLight(stack, light);
            gunModel.render(poseStack, stack, ctx, renderType, modelLight, class_4608.field_21444, bufferSource);
            // 缓存枪口位置，为第一人称曳光弹渲染作准备
            cacheMuzzlePosition(poseStack, gunModel);
            // 创建并绑定第一人称枪口 snowstorm 粒子（火光/烟雾）

            // 恢复手臂渲染
            gunModel.setRenderHand(renderHand);
            // 渲染完成后，将动画数据从模型中清除，不对其他视角下的模型渲染产生影响
            poseStack.method_22909();
            gunModel.cleanAnimationTransform();
            // 关闭第一人称弹壳和火焰渲染
            MuzzleFlashRender.isSelf = false;
            ShellRender.isSelf = false;
        });
    }

    /**
     * 第一人称粒子由本渲染器在枪体渲染的模板窗口内自行渲染（让粒子被镜内剔除），
     * SBM 因此跳过事件末尾的自动粒子渲染，避免双重绘制。
     */
    @Override
    public boolean renderParticlesInModelWindow() {
        return true;
    }

    private static void cacheMuzzlePosition(class_4587 poseStack, BedrockGunModel gunModel) {
        if (gunModel.getMuzzleFlashPosPath() != null) {
            // 计算出枪口相对于摄像机中心的坐标
            poseStack.method_22903();
            for (BedrockPart bedrockPart : gunModel.getMuzzleFlashPosPath()) {
                bedrockPart.translateAndRotateAndScale(poseStack);
            }
            Matrix4f pose = poseStack.method_23760().method_23761();
            double itemRenderFov = CameraSetupEvent.ITEM_MODEL_FOV_DYNAMICS.get();
            double levelRenderFov = CameraSetupEvent.WORLD_FOV_DYNAMICS.get();
            poseStack.method_22909();
            // 缓存转换后的偏移坐标。手部与世界的投影 FOV 不同，这里与枪口粒子使用同一套补偿：
            // 横向偏移 (x, y) 乘 tan(worldFov/2)/tan(modelFov/2)，让曳光弹起点落在模型 FOV 下枪口的
            // 屏幕位置上，而深度 z 保持真实，不再把起点搬到更近/更远的深度上。
            double itemTan = Math.tan(itemRenderFov / 2 * Math.PI / 180);
            double levelTan = Math.tan(levelRenderFov / 2 * Math.PI / 180);
            float lateral = itemTan > 1.0e-6 ? (float) (levelTan / itemTan) : 1.0f;
            muzzleRenderOffset.set(
                    pose.m30() * lateral,
                    pose.m31() * lateral,
                    pose.m32()
            );
        }
    }

    /**
     * SBM 第一人称粒子系统在渲染枪体前调用：捕获当前 pass 的基准矩阵，供粒子绑定变换使用。
     */
    @Override
    public void updateParticleEmitterTransforms(FirstPersonParticleSystem system, class_4587 poseStack, class_1268 hand) {
        MuzzleParticleManager.captureBasePose(hand, poseStack.method_23760().method_23761());
    }

    @Override
    public void method_3166(@Nonnull class_1799 stack, @Nonnull class_811 transformType, @Nonnull class_4587 poseStack, @Nonnull class_4597 pBuffer,
                             int pPackedLight, int pPackedOverlay) {
        if (!(stack.method_7909() instanceof IGun)) {
            return;
        }
        poseStack.method_22903();

        TimelessAPI.getGunDisplay(stack).ifPresentOrElse(gunIndex -> {
            // 第一人称就不渲染了，交给别的地方
            if (transformType == field_4321 || transformType == field_4322) {
                return;
            }
            // 第三人称副手也不渲染了
            if (transformType == field_4323) {
                return;
            }
            // GUI 特殊渲染
            if (transformType == field_4317) {
                renderSlotTexture(poseStack, pBuffer, pPackedLight, pPackedOverlay, gunIndex.getSlotTexture());
                return;
            }

            // vbo
            boolean outsideHighPolyDistance = !RenderDistance.inRenderHighPolyModelDistance(poseStack);
            StaticGunRenderResult vbo = ExternalGunItemVboRenderer.tryRender(
                    stack, transformType, outsideHighPolyDistance,
                    poseStack, pBuffer, pPackedLight, pPackedOverlay
            );

            if (vbo.status() != StaticGunRenderResult.Status.UNSUPPORTED) {
                return;
            }

            // 回退
            BedrockGunModel gunModel;
            class_2960 gunTexture;
            Pair<BedrockGunModel, class_2960> lodModel = gunIndex.getLodModel();
            boolean useLod = lodModel != null && outsideHighPolyDistance;
            if (!useLod) {
                gunModel = gunIndex.getGunModel();
                gunTexture = gunIndex.getModelTexture();
            } else {
                gunModel = lodModel.getLeft();
                gunTexture = lodModel.getRight();
            }
            if (gunModel == null) {
                renderSlotTexture(poseStack, pBuffer, pPackedLight, pPackedOverlay, gunIndex.getSlotTexture());
                return;
            }
            GunItemTransforms.apply(transformType, gunIndex.getTransform().getScale(), gunModel, poseStack);
            // 渲染枪械模型
            float alpha = ItemPreviewRenderContext.alpha();
            class_1921 renderType = ItemPreviewRenderContext.isPreview() ? class_1921.method_23580(gunTexture) : class_1921.method_23576(gunTexture);
            
            gunModel.render(poseStack, stack, transformType, renderType, pPackedLight, pPackedOverlay, 1.0F, 1.0F, 1.0F, alpha, pBuffer);

            // 第三人称持枪渲染：捕获枪口世界坐标，触发第三人称枪口粒子
            if (transformType == field_4320) {
                captureThirdPersonMuzzle(poseStack, gunModel);
            }
        }, () -> {
            // 没有这个 gunID，渲染个错误材质提醒别人
            renderSlotTexture(poseStack, pBuffer, pPackedLight, pPackedOverlay, class_1047.method_4539());
        });

        poseStack.method_22909();
    }

    // 捕获实际的世界位置
    public static void captureThirdPersonMuzzle(class_4587 poseStack, BedrockGunModel gunModel) {
        if (currentEntity == null) return;
        List<BedrockPart> muzzlePath = gunModel.getMuzzleFlashPosPath();
        if (muzzlePath == null) return;
        poseStack.method_22903();
        for (BedrockPart part : muzzlePath) {
            part.translateAndRotateAndScale(poseStack);
        }
        captureThirdPersonMuzzle(poseStack.method_23760().method_23761());
        poseStack.method_22909();
    }

    public static void captureThirdPersonMuzzle(Matrix4f pose) {
        if (currentEntity == null) return;

        class_4184 camera = class_310.method_1551().field_1773.method_19418();
        class_243 camPos = camera.method_19326();

        Matrix4f viewRotationInv = new Matrix4f()
                .rotationY((float) Math.toRadians(-(camera.method_19330() + 180f)))
                .rotateX((float) Math.toRadians(-camera.method_19329()))
                .rotateZ(-CameraStateCache.getCameraRollRadians());

        Matrix4f muzzleWorld = new Matrix4f(viewRotationInv).mul(pose);
        muzzleWorld.m30(muzzleWorld.m30() + (float) camPos.field_1352);
        muzzleWorld.m31(muzzleWorld.m31() + (float) camPos.field_1351);
        muzzleWorld.m32(muzzleWorld.m32() + (float) camPos.field_1350);
        onMuzzleRendered(currentEntity, muzzleWorld);
    }

    private static void renderSlotTexture(class_4587 poseStack, class_4597 bufferSource, int packedLight, int packedOverlay, class_2960 texture) {
        poseStack.method_22904(0.5, 1.5, 0.5);
        poseStack.method_22907(class_7833.field_40717.rotationDegrees(180));
        class_4588 buffer = bufferSource.getBuffer(class_1921.method_23580(texture));
        SLOT_GUN_MODEL.method_2828(poseStack, buffer, packedLight, packedOverlay, 1.0F, 1.0F, 1.0F, ItemPreviewRenderContext.alpha());
    }

}
