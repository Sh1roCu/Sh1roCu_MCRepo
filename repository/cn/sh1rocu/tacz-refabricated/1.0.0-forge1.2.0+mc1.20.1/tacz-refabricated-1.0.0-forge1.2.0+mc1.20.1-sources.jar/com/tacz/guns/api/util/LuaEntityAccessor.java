package com.tacz.guns.api.util;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2561;

@SuppressWarnings("unused")
public record LuaEntityAccessor(class_1309 entity) {
    public void sendSystemMessage(class_2561 message) {
        entity.method_43496(message);
    }

    public void sendActionBar(class_2561 message) {
        if (entity instanceof class_1657 player) {
            player.method_7353(message, true);
        }
    }

    public float getHealth() {
        return entity.method_6032();
    }

    public boolean hurt(float amount) {
        return entity.method_5643(entity.method_37908().method_48963().method_48830(), amount);
    }

    public class_2561 literal(String text) {
        return class_2561.method_43470(text);
    }

    public class_2561 translatable(String key) {
        return class_2561.method_43471(key);
    }

    public class_2561 translatable(String key, class_2561... components) {
        return class_2561.method_43469(key, (Object[]) components);
    }
}
