package com.tacz.guns.client.renderer.entity;

import com.mojang.authlib.GameProfile;
import com.tacz.guns.client.model.bedrock.BedrockModel;
import com.tacz.guns.client.model.bedrock.BedrockPart;
import com.tacz.guns.client.resource.InternalAssetLoader;
import com.tacz.guns.entity.TargetMinecart;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1921;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_925;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class TargetMinecartRenderer extends class_925<TargetMinecart> {
    private static final String HEAD_NAME = "head";
    private static final String HEAD_2_NAME = "head2";

    public TargetMinecartRenderer(class_5617.class_5618 ctx) {
        super(ctx, class_5602.field_27666);
        this.field_4673 = 0.25F;
    }

    public static Optional<BedrockModel> getModel() {
        return InternalAssetLoader.getBedrockModel(InternalAssetLoader.TARGET_MINECART_MODEL_LOCATION);
    }

    @Override
    public class_2960 getTextureLocation(TargetMinecart minecart) {
        return InternalAssetLoader.ENTITY_EMPTY_TEXTURE;
    }

    @Override
    protected void renderMinecartContents(TargetMinecart targetMinecart, float pPartialTicks, class_2680 pState, class_4587 stack, class_4597 buffer, int pPackedLight) {
        getModel().ifPresent(model -> {
            BedrockPart headModel = model.getNode(HEAD_NAME);
            BedrockPart head2Model = model.getNode(HEAD_2_NAME);
            headModel.visible = false;
            head2Model.visible = false;

            stack.method_22903();
            stack.method_22904(0.5, 1.875, 0.5);
            stack.method_22905(1.5f, 1.5f, 1.5f);
            stack.method_22907(class_7833.field_40717.rotationDegrees(180));
            stack.method_22907(class_7833.field_40715.rotationDegrees(90));
            class_1921 renderType = class_1921.method_23580(InternalAssetLoader.TARGET_MINECART_TEXTURE_LOCATION);
            model.render(stack, class_811.field_4315, renderType, pPackedLight, class_4608.field_21444);
            if (targetMinecart.getGameProfile() != null) {
                stack.method_22904(0, 1, -4.5 / 16d);
                class_310 minecraft = class_310.method_1551();
                GameProfile gameProfile = targetMinecart.getGameProfile().comp_2413();
                class_2960 skin = minecraft.method_1582().method_52862(gameProfile).comp_1626();
                headModel.visible = true;
                class_1921 skullRenderType = class_1921.method_23689(skin);
                headModel.render(stack, class_811.field_4315, buffer.getBuffer(skullRenderType), pPackedLight, class_4608.field_21444);

                head2Model.visible = true;
                stack.method_22904(0, 0, 0.01);
                head2Model.render(stack, class_811.field_4315, buffer.getBuffer(skullRenderType), pPackedLight, class_4608.field_21444);
            }
            stack.method_22909();
        });
    }
}