package com.tacz.guns.client.model.functional;

import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.item.IAttachment;
import com.tacz.guns.api.item.attachment.AttachmentType;
import com.tacz.guns.client.model.BedrockGunModel;
import com.tacz.guns.client.model.IFunctionalRenderer;
import com.tacz.guns.client.model.SlotModel;
import com.tacz.guns.client.model.bedrock.BedrockModel;
import com.tacz.guns.client.particle.ThirdPersonMuzzleParticleManager;
import com.tacz.guns.client.resource.GunDisplayInstance;
import com.tacz.guns.client.resource.pojo.display.gun.MuzzleFlash;
import com.tacz.guns.compat.iris.IrisCompat;
import com.tacz.guns.resource.modifier.custom.SilenceModifier;
import com.tacz.guns.util.time.GunTime;
import it.unimi.dsi.fastutil.Pair;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_811;

public class MuzzleFlashRender implements IFunctionalRenderer {
    private static final SlotModel MUZZLE_FLASH_MODEL = new SlotModel(true);
    /**
     * 50ms 显示时间
     */
    private static final long TIME_RANGE = 50;
    public static boolean isSelf = false;
    private static long shootTimeStamp = -1;
    private static float muzzleFlashRandomRotate = 0;
    private static Matrix3f muzzleFlashNormal = new Matrix3f();
    private static Matrix4f muzzleFlashPose = new Matrix4f();

    /**
     * 第三人称开火时间戳（按实体）：让附着在枪口骨骼上的四边形火光对任意射手生效，
     * 随枪械渲染逐帧附着（跟随枪口），其他玩家视角也始终可见。WeakHashMap 避免实体泄漏。
     */
    private static final Map<class_1309, Long> TP_SHOOT_TIMESTAMPS = new WeakHashMap<>();

    private final BedrockGunModel bedrockGunModel;

    public MuzzleFlashRender(BedrockGunModel bedrockGunModel) {
        this.bedrockGunModel = bedrockGunModel;
    }

    public static void onShoot() {
        // 记录开火时间戳
        shootTimeStamp = GunTime.nowMillis();
        // 随机给予枪口火焰的旋转
        muzzleFlashRandomRotate = (float) (Math.random() * 360);
    }

    /**
     * 记录某实体（任意射手）的第三人称开火时间戳，用于附着在枪口骨骼上的火光。
     */
    public static void onEntityShoot(class_1309 entity) {
        TP_SHOOT_TIMESTAMPS.put(entity, GunTime.nowMillis());
    }

    public static void resetTimestamps() {
        shootTimeStamp = -1;
        TP_SHOOT_TIMESTAMPS.clear();
    }

    private static void renderMuzzleFlash(GunDisplayInstance display, class_4587 poseStack, BedrockModel bedrockModel, long time, class_4597 bufferSource) {
        MuzzleFlash muzzleFlash = display.getMuzzleFlash();
        if (muzzleFlash == null) {
            return;
        }
        // 每帧捕获当前枪口变换，使火光逐帧跟随枪口（后坐/摆动/瞄准均跟随）
        muzzleFlashNormal = new Matrix3f(poseStack.method_23760().method_23762());
        muzzleFlashPose = new Matrix4f(poseStack.method_23760().method_23761());
        bedrockModel.delegateRender((poseStack1, vertexConsumer1, transformType1, light, overlay) -> doRender(light, overlay, muzzleFlash, time, bufferSource));
    }

    private static void doRender(int light, int overlay, MuzzleFlash muzzleFlash, long time, class_4597 bufferSource) {
        if (muzzleFlashNormal != null && muzzleFlashPose != null) {
            float scale = 0.5f * muzzleFlash.getScale();
            float scaleTime = TIME_RANGE / 2.0f;
            scale = time < scaleTime ? (scale * (time / scaleTime)) : scale;
            class_4597 multiBufferSource = bufferSource;

            // 推送到指定位置
            class_4587 poseStack2 = new class_4587();
            poseStack2.method_23760().method_23762().mul(muzzleFlashNormal);
            poseStack2.method_23760().method_23761().mul(muzzleFlashPose);

            // 先渲染一遍半透明背景
            poseStack2.method_22903();
            {
                poseStack2.method_22905(scale, scale, scale);
                poseStack2.method_22907(class_7833.field_40718.rotationDegrees(muzzleFlashRandomRotate));
                poseStack2.method_46416(0, -1, 0);
                class_1921 renderTypeBg = class_1921.method_23580(muzzleFlash.getTexture());
                MUZZLE_FLASH_MODEL.method_60879(poseStack2, multiBufferSource.getBuffer(renderTypeBg), light, overlay);
            }
            poseStack2.method_22909();

            // 然后渲染发光效果
            poseStack2.method_22903();
            {
                poseStack2.method_22905(scale / 2, scale / 2, scale / 2);
                poseStack2.method_22907(class_7833.field_40718.rotationDegrees(muzzleFlashRandomRotate));
                poseStack2.method_22904(0, -0.9, 0);
                class_1921 renderTypeLight = class_1921.method_23018(muzzleFlash.getTexture(), 1, 1);
                MUZZLE_FLASH_MODEL.method_60879(poseStack2, multiBufferSource.getBuffer(renderTypeLight), light, overlay);
            }
            poseStack2.method_22909();
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void render(class_4587 poseStack, class_4588 vertexBuffer, class_811 transformType, int light, int overlay) {
    }

    @Override
    @SuppressWarnings("unchecked")
    public void render(class_4587 poseStack, class_4588 vertexBuffer, class_811 transformType, int light, int overlay, class_4597 bufferSource) {
        if (IrisCompat.isRenderShadow()) {
            return;
        }
        long time;
        if (transformType.method_29998()) {
            // 第一人称：仅本机玩家开火；renew 枪械由 FP 粒子系统表现
            if (!isSelf) {
                return;
            }
            if (!GunTime.isWithin(shootTimeStamp, TIME_RANGE + 1)) {
                return;
            }
            time = GunTime.nowMillis() - shootTimeStamp;
        } else {
            // 第三人称：任意实体（本机 F5 + 其他玩家），按实体计时，附着枪口渲染（跟随枪口）
            class_1309 entity = ThirdPersonMuzzleParticleManager.currentEntity;
            if (entity == null) {
                return;
            }
            Long ts = TP_SHOOT_TIMESTAMPS.get(entity);
            if (ts == null) {
                return;
            }
            time = GunTime.nowMillis() - ts;
            if (time < 0 || time > TIME_RANGE) {
                TP_SHOOT_TIMESTAMPS.remove(entity);
                return;
            }
        }
        class_1799 currentGunItem = bedrockGunModel.getCurrentGunItem();

        TimelessAPI.getGunDisplay(currentGunItem).ifPresent(display -> {
            MuzzleFlash muzzleFlash = display.getMuzzleFlash();
            if (muzzleFlash == null) {
                return;
            }
            // renew 枪械的枪口火光由 snowstorm 粒子表现（第一人称 FP 粒子 / 第三人称锚点跟随世界粒子），
            // 不再渲染旧四边形火光；default 枪械保留四边形火光（第一人称本机 + 第三人称按实体）
            if (muzzleFlash.isRenew()) {
                return;
            }
            class_1799 muzzleAttachment = bedrockGunModel.getCurrentAttachmentItem().get(AttachmentType.MUZZLE);
            IAttachment iAttachment = IAttachment.getIAttachmentOrNull(muzzleAttachment);
            if (iAttachment != null) {
                class_2960 attachmentId = iAttachment.getAttachmentId(muzzleAttachment);
                TimelessAPI.getCommonAttachmentIndex(attachmentId).ifPresent(index -> {
                    var modifier = index.getData().getModifier();
                    if (modifier.containsKey(SilenceModifier.ID) && modifier.get(SilenceModifier.ID).getValue() instanceof Pair<?, ?> pair) {
                        // 如果安装了消音器，则不渲染枪口火光
                        if (((Pair<Integer, Boolean>) pair).right()) {
                            return;
                        }
                    }
                    renderMuzzleFlash(display, poseStack, bedrockGunModel, time, bufferSource);
                });
            } else {
                renderMuzzleFlash(display, poseStack, bedrockGunModel, time, bufferSource);
            }
        });
    }
}
