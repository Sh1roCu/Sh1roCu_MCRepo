package com.tacz.guns.client.gui.components;

import cn.sh1rocu.tacz.mixin.client.accessor.AbstractContainerScreenAccessor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.tacz.guns.GunMod;
import com.tacz.guns.api.DefaultAssets;
import com.tacz.guns.api.item.*;
import com.tacz.guns.client.resource.ClientAssetsManager;
import com.tacz.guns.client.resource.pojo.PackInfo;
import com.tacz.guns.config.client.RenderConfig;
import javax.annotation.Nullable;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_481;
import net.minecraft.class_7919;
import net.minecraft.class_7923;
import java.util.*;
import java.util.function.Consumer;

/**
 * A screen-local content pack filter; the registered creative tabs keep their full contents.
 */
public class CreativePackFilters {
    private static final class_2960 TAB_SPRITE = class_2960.method_60656("recipe_book/tab");
    private static final class_2960 SELECTED_TAB_SPRITE = class_2960.method_60656("recipe_book/tab_selected");
    private static final class_2960 ALL_PACKS_ICON = class_2960.method_60655(GunMod.MOD_ID, "textures/gui/creative_pack_all.png");
    private static final int VISIBLE_PACKS = 3;
    private static final int TAB_HEIGHT = 26;
    private static final int TAB_SPACING = 29;

    private final class_481 screen;
    private final Runnable resetScroll;
    private final Map<class_1761, String> selections = new IdentityHashMap<>();
    private final List<PackFilterButton> buttons = new ArrayList<>();
    private final List<FilterOption> options = new ArrayList<>();
    private class_4185 previousButton;
    private class_4185 nextButton;
    private class_1761 currentTab;
    private Collection<class_1799> sourceItems;
    private long packInfoVersion = -1;
    private int packScroll;

    public CreativePackFilters(class_481 screen, Runnable resetScroll) {
        this.screen = screen;
        this.resetScroll = resetScroll;
    }

    public void init(Consumer<class_339> add, class_1761 tab) {
        buttons.clear();
        for (int i = 0; i <= VISIBLE_PACKS; i++) {
            PackFilterButton button = new PackFilterButton(((AbstractContainerScreenAccessor) screen).tacz$getGuiLeft() - 28,
                    ((AbstractContainerScreenAccessor) screen).tacz$getGuiTop() + 11 + TAB_SPACING * i);
            buttons.add(button);
            add.accept(button);
        }
        previousButton = class_4185.method_46430(class_2561.method_43470("▲"), button -> scrollPacks(-1))
                .method_46434(((AbstractContainerScreenAccessor) screen).tacz$getGuiLeft() - 24, ((AbstractContainerScreenAccessor) screen).tacz$getGuiTop() - 3, 20, 12)
                .method_46436(class_7919.method_47407(class_2561.method_43471("gui.tacz.creative_pack_filter.previous"))).method_46431();
        nextButton = class_4185.method_46430(class_2561.method_43470("▼"), button -> scrollPacks(1))
                .method_46434(((AbstractContainerScreenAccessor) screen).tacz$getGuiLeft() - 24, ((AbstractContainerScreenAccessor) screen).tacz$getGuiTop() + 127, 20, 12)
                .method_46436(class_7919.method_47407(class_2561.method_43471("gui.tacz.creative_pack_filter.next"))).method_46431();
        add.accept(previousButton);
        add.accept(nextButton);
        updateTab(tab, true);
    }

    public void updateTab(class_1761 tab, boolean force) {
        if (!RenderConfig.RENDER_CREATIVE_PACK_SIDEBAR.get()) {
            if (currentTab == tab) {
                showItems(tab.method_47313());
            }
            selections.clear();
            hideWidgets();
            return;
        }
        class_2960 tabId = class_7923.field_44687.method_10221(tab);
        if (tabId == null || !GunMod.MOD_ID.equals(tabId.method_12836()) || tab.method_47312() != class_1761.class_7916.field_41052) {
            hideWidgets();
            return;
        }

        Collection<class_1799> displayItems = tab.method_47313();
        long reloadVersion = ClientAssetsManager.INSTANCE.getPackInfoReloadVersion();
        if (!force && currentTab == tab && sourceItems == displayItems && packInfoVersion == reloadVersion) {
            return;
        }
        if (currentTab != tab) {
            packScroll = 0;
        }
        currentTab = tab;
        sourceItems = displayItems;
        packInfoVersion = reloadVersion;
        options.clear();

        List<class_1799> allItems = displayItems.stream().map(class_1799::method_7972).toList();
        options.add(new FilterOption(null, class_2561.method_43471("gui.tacz.creative_pack_filter.all"),
                class_1799.field_8037, ALL_PACKS_ICON, allItems));
        Map<String, List<class_1799>> groupedItems = groupItems(displayItems);
        groupedItems.forEach((namespace, items) -> {
            PackInfo info = ClientAssetsManager.INSTANCE.getPackInfo(namespace);
            class_2561 name = info == null || info.getName() == null || info.getName().isBlank()
                    || "custom.tacz.error.no_name".equals(info.getName())
                    ? class_2561.method_43470(namespace) : class_2561.method_43471(info.getName());
            class_2960 logo = info == null ? null : info.getLogo(namespace);
            if (logo != null && class_310.method_1551().method_1478().method_14486(logo).isEmpty()) {
                logo = null;
            }
            FilterOption option = new FilterOption(namespace, name, items.get(0).method_7972(), logo, items);
            if (GunMod.MOD_ID.equals(namespace)) {
                options.add(1, option);
            } else {
                options.add(option);
            }
        });
        String selected = selections.get(tab);
        if (selected != null && !groupedItems.containsKey(selected)) {
            selections.remove(tab);
        }
        packScroll = class_3532.method_15340(packScroll, 0, maxScroll());
        updateButtons();
        applyFilter();
    }

    private void hideWidgets() {
        currentTab = null;
        sourceItems = null;
        buttons.forEach(button -> button.setOption(null));
        previousButton.field_22764 = nextButton.field_22764 = false;
        previousButton.field_22763 = nextButton.field_22763 = false;
    }

    /**
     * Keeps every stack, including multiple NBT variants of the same registered item.
     */
    static Map<String, List<class_1799>> groupItems(Collection<class_1799> items) {
        Map<String, List<class_1799>> groups = new LinkedHashMap<>();
        for (class_1799 stack : items) {
            if (!stack.method_7960()) {
                class_1799 copy = stack.method_7972();
                groups.computeIfAbsent(getContentId(copy).method_12836(), key -> new ArrayList<>()).add(copy);
            }
        }
        return groups;
    }

    static class_2960 getContentId(class_1799 stack) {
        if (stack.method_7909() instanceof IGun gun) {
            return gun.getGunId(stack);
        }
        if (stack.method_7909() instanceof IAmmo ammo) {
            return ammo.getAmmoId(stack);
        }
        if (stack.method_7909() instanceof IAttachment attachment) {
            return attachment.getAttachmentId(stack);
        }
        if (stack.method_7909() instanceof IBlock block) {
            return block.getBlockId(stack);
        }
        if (stack.method_7909() instanceof IAmmoBox box) {
            class_2960 ammoId = box.getAmmoId(stack);
            if (!DefaultAssets.EMPTY_AMMO_ID.equals(ammoId)) {
                return ammoId;
            }
        }
        return class_7923.field_41178.method_10221(stack.method_7909());
    }

    private void select(FilterOption option) {
        if (option.namespace() == null) {
            selections.remove(currentTab);
        } else {
            selections.put(currentTab, option.namespace());
        }
        applyFilter();
    }

    private void applyFilter() {
        String selected = selections.get(currentTab);
        FilterOption option = options.stream().filter(entry -> Objects.equals(entry.namespace(), selected))
                .findFirst().orElse(options.get(0));
        showItems(option.items());
    }

    private void showItems(Collection<class_1799> items) {
        screen.method_17577().field_2897.clear();
        items.forEach(stack -> screen.method_17577().field_2897.add(stack.method_7972()));
        resetScroll.run();
        screen.method_17577().method_2473(0);
    }

    private int maxScroll() {
        return Math.max(0, options.size() - 1 - VISIBLE_PACKS);
    }

    private void scrollPacks(int delta) {
        packScroll = class_3532.method_15340(packScroll + delta, 0, maxScroll());
        updateButtons();
    }

    private void updateButtons() {
        buttons.get(0).setOption(options.get(0));
        for (int i = 1; i < buttons.size(); i++) {
            int optionIndex = packScroll + i;
            buttons.get(i).setOption(optionIndex < options.size() ? options.get(optionIndex) : null);
        }
        previousButton.field_22764 = nextButton.field_22764 = maxScroll() > 0;
        previousButton.field_22763 = packScroll > 0;
        nextButton.field_22763 = packScroll < maxScroll();
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (!RenderConfig.RENDER_CREATIVE_PACK_SIDEBAR.get() || currentTab == null || scrollY == 0) {
            return false;
        }
        int x = ((AbstractContainerScreenAccessor) screen).tacz$getGuiLeft() - 28;
        int y = ((AbstractContainerScreenAccessor) screen).tacz$getGuiTop() + 11;
        if (mouseX >= x && mouseX < x + 32 && mouseY >= y && mouseY < y + TAB_SPACING * VISIBLE_PACKS + TAB_HEIGHT) {
            scrollPacks(scrollY > 0 ? -1 : 1);
            return true;
        }
        return false;
    }

    private record FilterOption(@Nullable String namespace, class_2561 name, class_1799 icon,
                                @Nullable class_2960 logo, List<class_1799> items) {
    }

    private class PackFilterButton extends class_4185 {
        @Nullable
        private FilterOption option;

        private PackFilterButton(int x, int y) {
            super(x, y, 32, TAB_HEIGHT, class_2561.method_43473(), button -> {
                FilterOption selected = ((PackFilterButton) button).option;
                if (selected != null) {
                    select(selected);
                }
            }, field_40754);
        }

        private void setOption(@Nullable FilterOption option) {
            this.option = option;
            field_22764 = field_22763 = option != null;
            method_25355(option == null ? class_2561.method_43473() : option.name());
            method_47400(option == null ? null : class_7919.method_47407(option.name()));
        }

        @Override
        public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            if (option == null) {
                return;
            }
            boolean selected = Objects.equals(option.namespace(), selections.get(currentTab));
            RenderSystem.enableBlend();
            class_2960 background = selected ? SELECTED_TAB_SPRITE : TAB_SPRITE;
            int backgroundWidth = selected ? 31 : 28;
            int sourceWidth = selected ? 35 : 30;
            // Both sprites are 35x27; the unselected tab has five transparent columns on the right.
            // Crop only the flat center to preserve the borders and the selected tab's panel join.
            graphics.method_52708(background, 35, 27, 0, 0,
                    method_46426(), method_46427(), backgroundWidth - 3, TAB_HEIGHT);
            graphics.method_52708(background, 35, 27, sourceWidth - 3, 0,
                    method_46426() + backgroundWidth - 3, method_46427(), 3, TAB_HEIGHT);
            if (option.logo() != null) {
                // UVs cover the full image, independently of its pixel dimensions.
                graphics.method_25290(option.logo(), method_46426() + 8, method_46427() + 5, 0, 0, 16, 16, 16, 16);
            } else {
                graphics.method_51427(option.icon(), method_46426() + 8, method_46427() + 5);
            }
            if (method_25370() && class_310.method_1551().method_48186().method_48183()) {
                graphics.method_49601(method_46426() + 5, method_46427() + 3, 22, 20, 0xFFFFFFFF);
            }
        }
    }
}