package com.tacz.guns.client.sound;

import com.tacz.guns.GunMod;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.item.IAttachment;
import com.tacz.guns.client.resource.GunDisplayInstance;
import com.tacz.guns.client.resource.pojo.display.SoundData;
import com.tacz.guns.config.client.SoundConfig;
import com.tacz.guns.config.common.GunConfig;
import com.tacz.guns.init.ModSounds;
import com.tacz.guns.network.message.ServerMessageSound;
import com.tacz.guns.resource.pojo.data.gun.GunData;
import com.tacz.guns.sound.SoundManager;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_7654;
import org.jetbrains.annotations.Nullable;

import java.util.*;

@Environment(EnvType.CLIENT)
public class SoundPlayManager {
    private static final class_7654 TACZ_SOUND_LISTER = new class_7654("tacz_sounds", ".ogg");
    private static final SoundData DEFAULT_UNLOAD_SOUND = SoundData.of(class_2960.method_60655(GunMod.MOD_ID,
            "attachments/attachment_general_uninstall"));

    private static final Map<SoundKey, ArrayDeque<TrackedGunSound>> TRACKED_GUN_SOUNDS = new HashMap<>();
    private static final Map<class_2960, Boolean> SOUND_RESOURCE_EXISTS_CACHE = new HashMap<>();
    private static final Set<class_2960> MISSING_SOUND_WARNED = new HashSet<>();

    private static int soundCleanupTickCounter = 0;

    /**
     * 用于阻止连发时，反复播放 DryFire 音效
     */
    private static boolean DRY_SOUND_TRACK = true;

    /**
     * 临时缓存，用于停止播放的
     */
    private static GunSoundInstance tmpSoundInstance = null;

    @Nullable
    public static GunSoundInstance playClientSound(class_1297 entity, @Nullable class_2960 name, float volume, float pitch, int distance, boolean mono) {
        boolean trackFirstPerson = SoundConfig.FIRST_PERSON_ANIMATION_SOUND_TRACKING.get();
        return playClientSound(entity, name, volume, pitch, distance, mono, SoundConfig.DEFAULT_SOUND_CONCURRENCY_LIMIT.get(), trackFirstPerson, true);
    }

    @Nullable
    public static GunSoundInstance playClientSound(class_1297 entity, @Nullable SoundData sound, float volume, float pitch, int distance) {
        return playClientSound(entity, sound, volume, pitch, distance, false);
    }

    @Nullable
    public static GunSoundInstance playClientSound(class_1297 entity, @Nullable SoundData sound, float volume, float pitch, int distance, boolean mono) {
        boolean trackFirstPerson = SoundConfig.FIRST_PERSON_ANIMATION_SOUND_TRACKING.get();
        return playClientSound(entity, sound, volume, pitch, distance, mono, SoundConfig.DEFAULT_SOUND_CONCURRENCY_LIMIT.get(), trackFirstPerson, true);
    }

    @Nullable
    private static GunSoundInstance playClientSound(class_1297 entity, @Nullable SoundData sound, float volume, float pitch, int distance, boolean mono, int concurrencyLimit, boolean trackEntity, boolean relative) {
        if (sound == null) {
            return null;
        }
        class_5819 random = entity != null ? entity.method_37908().field_9229 : class_5819.method_43047();
        float resolvedVolume = sound.resolveVolume(random, volume);
        float resolvedPitch = sound.resolvePitch(random, pitch);
        return playClientSound(entity, sound.getSound(), resolvedVolume, resolvedPitch, distance, mono, concurrencyLimit, trackEntity, relative);
    }

    @Nullable
    private static GunSoundInstance playClientSound(class_1297 entity, @Nullable class_2960 name, float volume, float pitch, int distance, boolean mono, int concurrencyLimit, boolean trackEntity, boolean relative) {
        class_310 minecraft = class_310.method_1551();
        if (name == null) {
            return null;
        }
        boolean useTaczSound = hasTaczSoundResource(minecraft, name);
        if (!useTaczSound && minecraft.method_1483().method_4869(name) == null) {
            warnMissingSound(name);
            return null;
        }
        if (concurrencyLimit > 0) {
            limitConcurrentGunSound(minecraft, entity.method_5628(), name, concurrencyLimit);
        }
        class_3414 soundEvent = useTaczSound ? ModSounds.GUN : class_3414.method_47908(name);
        GunSoundInstance instance = trackEntity
                ? new EntityTrackingGunSoundInstance(soundEvent, class_3419.field_15248, volume, pitch, entity, distance, name, mono, useTaczSound)
                : new GunSoundInstance(soundEvent, class_3419.field_15248, volume, pitch, entity, distance, name, mono, relative, useTaczSound);
        minecraft.method_1483().method_4873(instance);
        if (concurrencyLimit > 0) {
            trackGunSound(entity.method_5628(), entity.method_5667(), name, instance);
        }
//        traceGunSoundPlay(minecraft, instance, entity, name, volume, pitch, distance, mono);
        return instance;
    }

    @Nullable
    public static GunSoundInstance playClientSound(class_1297 entity, @Nullable class_2960 name, float volume, float pitch, int distance) {
        return playClientSound(entity, name, volume, pitch, distance, false);
    }

    @Nullable
    public static GunSoundInstance playAnimationSound(class_1297 entity, @Nullable class_2960 name, float volume, float pitch, int distance) {
        if (isLocalPlayer(entity)) {
            boolean trackFirstPerson = SoundConfig.FIRST_PERSON_ANIMATION_SOUND_TRACKING.get();
            return playClientSound(entity, name, volume, pitch, distance, false, SoundConfig.HIGH_FREQUENCY_SOUND_CONCURRENCY_LIMIT.get(), trackFirstPerson, !trackFirstPerson);
        }
        return playClientSound(entity, name, volume, pitch, distance, false, SoundConfig.HIGH_FREQUENCY_SOUND_CONCURRENCY_LIMIT.get(), true, false);
    }


    public static void stopPlayGunSound() {
        if (tmpSoundInstance != null) {
            tmpSoundInstance.setStop();
        }
    }

    public static void stopPlayGunSound(GunDisplayInstance gunIndex, String animationName) {
        if (tmpSoundInstance != null) {
            SoundData sound = gunIndex.getSounds(animationName);
            if (sound != null && tmpSoundInstance.getRegistryName() != null && tmpSoundInstance.getRegistryName().equals(sound.getSound())) {
                tmpSoundInstance.setStop();
            }
        }
    }

    public static void playerRefitSound(class_1799 attachmentItem, class_746 player, String soundName) {
        IAttachment iAttachment = IAttachment.getIAttachmentOrNull(attachmentItem);
        if (iAttachment == null) {
            return;
        }
        class_2960 attachmentId = iAttachment.getAttachmentId(attachmentItem);
        TimelessAPI.getClientAttachmentIndex(attachmentId).ifPresent(index -> {
            Map<String, SoundData> sounds = index.getSounds();
            if (sounds.containsKey(soundName)) {
                SoundData sound = sounds.get(soundName);
                SoundPlayManager.playClientSound(player, sound, 1.0f, 1.0f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
            }
        });
    }

    public static void playShootSound(class_1309 entity, GunDisplayInstance gunIndex, GunData gunData) {
        playClientSound(entity, gunIndex.getSounds(SoundManager.SHOOT_SOUND), 0.8f, 0.9f + entity.method_59922().method_43057() * 0.125f, (int) (GunConfig.DEFAULT_GUN_FIRE_SOUND_DISTANCE.get() * gunData.getFireSound().getFireMultiplier()), false, SoundConfig.HIGH_FREQUENCY_SOUND_CONCURRENCY_LIMIT.get(), false, false);
    }

    public static void playSilenceSound(class_1309 entity, GunDisplayInstance gunIndex, GunData gunData) {
        playClientSound(entity, gunIndex.getSounds(SoundManager.SILENCE_SOUND), 0.6f, 0.9f + entity.method_59922().method_43057() * 0.125f, (int) (GunConfig.DEFAULT_GUN_SILENCE_SOUND_DISTANCE.get() * gunData.getFireSound().getSilenceMultiplier()), false, SoundConfig.HIGH_FREQUENCY_SOUND_CONCURRENCY_LIMIT.get(), false, false);
    }

    public static void playDryFireSound(class_1309 entity, GunDisplayInstance gunIndex) {
        if (DRY_SOUND_TRACK) {
            playClientSound(entity, gunIndex.getSounds(SoundManager.DRY_FIRE_SOUND), 1.0f, 0.9f + entity.method_59922().method_43057() * 0.125f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
            DRY_SOUND_TRACK = false;
        }
    }

    /**
     * 只有松开鼠标时，才会重置
     */
    public static void resetDryFireSound() {
        DRY_SOUND_TRACK = true;
    }

    public static void playReloadSound(class_1309 entity, GunDisplayInstance display, boolean noAmmo) {
        if (noAmmo) {
            tmpSoundInstance = playClientSound(entity, display.getSounds(SoundManager.RELOAD_EMPTY_SOUND), 1.0f, 1.0f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
        } else {
            tmpSoundInstance = playClientSound(entity, display.getSounds(SoundManager.RELOAD_TACTICAL_SOUND), 1.0f, 1.0f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
        }
    }

    public static void playInspectSound(class_1309 entity, GunDisplayInstance display, boolean noAmmo) {
        if (noAmmo) {
            tmpSoundInstance = playClientSound(entity, display.getSounds(SoundManager.INSPECT_EMPTY_SOUND), 1.0f, 1.0f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
        } else {
            tmpSoundInstance = playClientSound(entity, display.getSounds(SoundManager.INSPECT_SOUND), 1.0f, 1.0f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
        }
    }

    public static void playBoltSound(class_1309 entity, GunDisplayInstance display) {
        tmpSoundInstance = playClientSound(entity, display.getSounds(SoundManager.BOLT_SOUND), 1.0f, 1.0f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
    }

    public static void playDrawSound(class_1309 entity, GunDisplayInstance display) {
        tmpSoundInstance = playClientSound(entity, display.getSounds(SoundManager.DRAW_SOUND), 1.0f, 1.0f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
    }

    public static void playPutAwaySound(class_1309 entity, GunDisplayInstance display) {
        tmpSoundInstance = playClientSound(entity, display.getSounds(SoundManager.PUT_AWAY_SOUND), 1.0f, 1.0f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
    }

    public static void playFireSelectSound(class_1309 entity, GunDisplayInstance display) {
        playClientSound(entity, display.getSounds(SoundManager.FIRE_SELECT), 1.0f, 1.0f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
    }

    public static void playMeleeBayonetSound(class_1309 entity, GunDisplayInstance display) {
        playClientSound(entity, display.getSounds(SoundManager.MELEE_BAYONET), 1.0f, 0.9f + entity.method_59922().method_43057() * 0.125f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
    }

    public static void playMeleePushSound(class_1309 entity, GunDisplayInstance display) {
        playClientSound(entity, display.getSounds(SoundManager.MELEE_PUSH), 1.0f, 0.9f + entity.method_59922().method_43057() * 0.125f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
    }

    public static void playMeleeStockSound(class_1309 entity, GunDisplayInstance display) {
        playClientSound(entity, display.getSounds(SoundManager.MELEE_STOCK), 1.0f, 0.9f + entity.method_59922().method_43057() * 0.125f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
    }

    public static void playUnloadSound(class_1309 entity, class_2960 gunId, class_2960 gunDisplayId) {
        SoundData sound = TimelessAPI.getGunDisplay(gunDisplayId, gunId)
                .map(display -> display.getSounds(SoundManager.UNLOAD_SOUND))
                .orElse(DEFAULT_UNLOAD_SOUND);
        playClientSound(entity, sound, 1.0F, 1.0F, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
    }

    public static void playHeadHitSound(class_1309 entity, GunDisplayInstance display) {
        boolean relative = isLocalPlayer(entity);
        playClientSound(entity, display.getSounds(SoundManager.HEAD_HIT_SOUND), 1.0f, 1.0f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get(), false, SoundConfig.HIT_SOUND_CONCURRENCY_LIMIT.get(), !relative, relative);
    }

    public static void playFleshHitSound(class_1309 entity, GunDisplayInstance display) {
        boolean relative = isLocalPlayer(entity);
        playClientSound(entity, display.getSounds(SoundManager.FLESH_HIT_SOUND), 1.0f, 1.0f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get(), false, SoundConfig.HIT_SOUND_CONCURRENCY_LIMIT.get(), !relative, relative);
    }

    public static void playKillSound(class_1309 entity, GunDisplayInstance display) {
        playClientSound(entity, display.getSounds(SoundManager.KILL_SOUND), 1.0f, 1.0f, GunConfig.DEFAULT_GUN_OTHER_SOUND_DISTANCE.get());
    }

    public static void playMessageSound(ServerMessageSound message) {
        class_638 level = class_310.method_1551().field_1687;
        if (level == null || !(level.method_8469(message.entityId()) instanceof class_1309 livingEntity)) {
            return;
        }
        class_2960 gunId = message.gunId();
        class_2960 gunDisplayId = message.gunDisplayId();
        TimelessAPI.getGunDisplay(gunDisplayId, gunId).ifPresent(index -> {
            String soundName = message.messageSound().soundName();
            SoundData sound = index.getSounds(soundName);
            if (sound == null) {
                return;
            }
            var soundMessage = message.messageSound();
            if (SoundManager.SHOOT_3P_SOUND.equals(soundName) || SoundManager.SILENCE_3P_SOUND.equals(soundName)) {
                playClientSound(livingEntity, sound, soundMessage.volume(), soundMessage.pitch(), soundMessage.distance(), true, SoundConfig.HIGH_FREQUENCY_SOUND_CONCURRENCY_LIMIT.get(), true, false);
            } else {
                playClientSound(livingEntity, sound, soundMessage.volume(), soundMessage.pitch(), soundMessage.distance(), true, SoundConfig.DEFAULT_SOUND_CONCURRENCY_LIMIT.get(), true, false);
            }
        });
    }

    public static void onClientTick(class_310 minecraft) {
//        if (event.phase != TickEvent.Phase.END) {
//            return;
//        }
        if (minecraft.field_1687 == null) {
            cleanupInvalidEntitySounds(minecraft);
            return;
        }
        soundCleanupTickCounter++;
        if (soundCleanupTickCounter % 5 == 0) {
            cleanupInvalidEntitySounds(minecraft);
        }
    }

    public static void clearSoundResourceCache() {
        SOUND_RESOURCE_EXISTS_CACHE.clear();
        MISSING_SOUND_WARNED.clear();
    }

    private static void limitConcurrentGunSound(class_310 minecraft, int entityId, class_2960 soundId, int limit) {
        SoundKey key = new SoundKey(entityId, soundId);
        ArrayDeque<TrackedGunSound> sounds = TRACKED_GUN_SOUNDS.get(key);
        if (sounds == null) {
            return;
        }
        int activeForKey = 0;
        Iterator<TrackedGunSound> iterator = sounds.iterator();
        while (iterator.hasNext()) {
            TrackedGunSound tracked = iterator.next();
            if (minecraft.method_1483().method_4877(tracked.instance())) {
                activeForKey++;
            } else {
                iterator.remove();
            }
        }
        if (sounds.isEmpty()) {
            TRACKED_GUN_SOUNDS.remove(key);
        }

        int toStop = activeForKey - limit + 1;
        if (toStop <= 0) {
            return;
        }

        int stopped = 0;
        iterator = sounds.iterator();
        while (iterator.hasNext() && stopped < toStop) {
            TrackedGunSound tracked = iterator.next();
            if (minecraft.method_1483().method_4877(tracked.instance())) {
                tracked.instance().setStop();
                iterator.remove();
                stopped++;
            }
        }
        if (sounds.isEmpty()) {
            TRACKED_GUN_SOUNDS.remove(key);
        }
    }

    private static void trackGunSound(int entityId, UUID entityUuid, class_2960 soundId, GunSoundInstance instance) {
        SoundKey key = new SoundKey(entityId, soundId);
        TRACKED_GUN_SOUNDS.computeIfAbsent(key, ignored -> new ArrayDeque<>()).addLast(new TrackedGunSound(instance, entityUuid));
    }

    private static void cleanupInvalidEntitySounds(class_310 minecraft) {
        if (minecraft.field_1687 == null) {
            stopAndClearTrackedSounds();
            return;
        }
        Iterator<Map.Entry<SoundKey, ArrayDeque<TrackedGunSound>>> entryIterator = TRACKED_GUN_SOUNDS.entrySet().iterator();
        while (entryIterator.hasNext()) {
            Map.Entry<SoundKey, ArrayDeque<TrackedGunSound>> entry = entryIterator.next();
            Iterator<TrackedGunSound> soundIterator = entry.getValue().iterator();
            while (soundIterator.hasNext()) {
                TrackedGunSound tracked = soundIterator.next();
                if (!minecraft.method_1483().method_4877(tracked.instance())) {
                    soundIterator.remove();
                    continue;
                }
                class_1297 owner = minecraft.field_1687.method_8469(entry.getKey().entityId());
                if (isInvalidSoundOwner(owner, tracked.entityUuid())) {
                    tracked.instance().setStop();
                    soundIterator.remove();
                }
            }
            if (entry.getValue().isEmpty()) {
                entryIterator.remove();
            }
        }
    }

    private static void stopAndClearTrackedSounds() {
        for (ArrayDeque<TrackedGunSound> sounds : TRACKED_GUN_SOUNDS.values()) {
            for (TrackedGunSound tracked : sounds) {
                tracked.instance().setStop();
            }
        }
        TRACKED_GUN_SOUNDS.clear();
    }

    private static boolean isInvalidSoundOwner(@Nullable class_1297 entity, UUID entityUuid) {
        return entity == null
                || !entity.method_5667().equals(entityUuid)
                || entity.method_31481()
                || entity instanceof class_1309 livingEntity && livingEntity.method_29504();
    }

    private static boolean isLocalPlayer(class_1297 entity) {
        return entity == class_310.method_1551().field_1724;
    }

    private static boolean hasTaczSoundResource(class_310 minecraft, class_2960 soundId) {
        return SOUND_RESOURCE_EXISTS_CACHE.computeIfAbsent(soundId, id -> {
            class_2960 soundPath = TACZ_SOUND_LISTER.method_45112(id);
            return minecraft.method_1478().method_14486(soundPath).isPresent();
        });
    }

    private static void warnMissingSound(class_2960 soundId) {
        if (MISSING_SOUND_WARNED.add(soundId)) {
            class_2960 soundPath = TACZ_SOUND_LISTER.method_45112(soundId);
            GunMod.LOGGER.warn("[TACZ Sound] Missing tacz_sounds resource and fallback sound event, skipped. sound={}, path={}", soundId, soundPath);
        }
    }

    private record SoundKey(int entityId, class_2960 soundId) {}

    private record TrackedGunSound(GunSoundInstance instance, UUID entityUuid) {}
}
