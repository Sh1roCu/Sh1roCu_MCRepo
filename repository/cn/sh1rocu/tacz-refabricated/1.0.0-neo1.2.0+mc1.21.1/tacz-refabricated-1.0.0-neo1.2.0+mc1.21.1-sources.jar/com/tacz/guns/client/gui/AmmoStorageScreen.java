package com.tacz.guns.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.tacz.guns.inventory.AmmoStorageEntry;
import com.tacz.guns.inventory.AmmoStorageMenu;
import com.tacz.guns.network.message.ClientMessageAmmoStorageClick;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_465;
import java.util.ArrayList;
import java.util.List;

public class AmmoStorageScreen extends class_465<AmmoStorageMenu> {
    private static final class_2960 CONTAINER_LOCATION = class_2960.method_60656("textures/gui/container/generic_54.png");
    private static final int CONTAINER_ROWS = AmmoStorageMenu.STORAGE_ROWS;
    private int virtualClickButton = -1;

    public AmmoStorageScreen(AmmoStorageMenu menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
        field_2792 = 176;
        field_2779 = 114 + CONTAINER_ROWS * 18 + AmmoStorageMenu.STATUS_HEIGHT;
        field_25270 = field_2779 - 94;
    }

    @Override
    protected void method_2389(class_332 graphics, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShaderColor(1, 1, 1, 1);
        int storageHeight = CONTAINER_ROWS * 18 + 17 + AmmoStorageMenu.STATUS_HEIGHT;
        graphics.method_25302(CONTAINER_LOCATION, field_2776, field_2800, 0, 0, field_2792, 17);
        graphics.method_25293(CONTAINER_LOCATION, field_2776, field_2800 + 17, field_2792, AmmoStorageMenu.STATUS_HEIGHT,
                0.0F, 7.0F, field_2792, 1, 256, 256);
        graphics.method_25302(CONTAINER_LOCATION, field_2776, field_2800 + 17 + AmmoStorageMenu.STATUS_HEIGHT,
                0, 17, field_2792, CONTAINER_ROWS * 18);
        graphics.method_25302(CONTAINER_LOCATION, field_2776, field_2800 + storageHeight, 0, 126, field_2792, 96);
        renderCapacity(graphics);
        var entries = field_2797.getEntries();
        for (int i = 0; i < entries.size(); i++) {
            AmmoStorageEntry entry = entries.get(i);
            int x = field_2776 + AmmoStorageMenu.INVENTORY_X + i % AmmoStorageMenu.STORAGE_COLUMNS * 18;
            int y = field_2800 + AmmoStorageMenu.STORAGE_Y + i / AmmoStorageMenu.STORAGE_COLUMNS * 18;
            graphics.method_51427(entry.sample(), x, y);
            renderSizeLabel(graphics, x, y, formatCount(entry.count()));
        }
        int hovered = getVirtualCell(mouseX, mouseY);
        if (hovered >= 0) {
            int x = field_2776 + AmmoStorageMenu.INVENTORY_X + hovered % AmmoStorageMenu.STORAGE_COLUMNS * 18;
            int y = field_2800 + AmmoStorageMenu.STORAGE_Y + hovered / AmmoStorageMenu.STORAGE_COLUMNS * 18;
            method_33285(graphics, x, y, 0);
        }
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        method_25420(graphics, mouseX, mouseY, partialTick);
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        method_2380(graphics, mouseX, mouseY);
    }

    @Override
    protected void method_2380(class_332 graphics, int mouseX, int mouseY) {
        if (method_2378(8, 17, 160, 21, mouseX, mouseY)) {
            graphics.method_51434(field_22793, List.of(
                    class_2561.method_43469("gui.tacz.ammo_storage.capacity_detail", field_2797.getUsedStacks(), field_2797.getCapacityStacks()),
                    class_2561.method_43469("gui.tacz.ammo_storage.free_capacity", Math.max(0, field_2797.getCapacityStacks() - field_2797.getUsedStacks()))
            ), mouseX, mouseY);
            return;
        }
        int cell = getVirtualCell(mouseX, mouseY);
        if (cell >= 0 && cell < field_2797.getEntries().size() && field_2797.method_34255().method_7960()) {
            AmmoStorageEntry entry = field_2797.getEntries().get(cell);
            var tooltip = new ArrayList<>(method_51454(entry.sample()));
            tooltip.add(class_2561.method_43469("gui.tacz.ammo_storage.count", entry.count()).method_27692(class_124.field_1080));
            tooltip.add(class_2561.method_43469("gui.tacz.ammo_storage.remaining", entry.remainingCapacity())
                    .method_27692(entry.remainingCapacity() == 0 ? class_124.field_1061 : class_124.field_1080));
            graphics.method_51437(field_22793, tooltip, entry.sample().method_32347(),/* entry.sample(),*/ mouseX, mouseY);
            return;
        }
        super.method_2380(graphics, mouseX, mouseY);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int cell = getVirtualCell(mouseX, mouseY);
        if (cell >= 0 && (button == 0 || button == 1)) {
            int entryId = cell < field_2797.getEntries().size() ? field_2797.getEntries().get(cell).id() : -1;
            AmmoStorageMenu.Action action = method_25442() ? AmmoStorageMenu.Action.QUICK_MOVE
                    : button == 1 ? AmmoStorageMenu.Action.PICKUP_HALF : AmmoStorageMenu.Action.PICKUP;
            ClientPlayNetworking.send(new ClientMessageAmmoStorageClick(field_2797.field_7763, entryId, action));
            virtualClickButton = button;
            return true;
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        return virtualClickButton >= 0 || super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (button == virtualClickButton) {
            virtualClickButton = -1;
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    private int getVirtualCell(double mouseX, double mouseY) {
        for (int cell = 0; cell < AmmoStorageMenu.STORAGE_SLOT_COUNT; cell++) {
            int x = AmmoStorageMenu.INVENTORY_X + cell % AmmoStorageMenu.STORAGE_COLUMNS * 18;
            int y = AmmoStorageMenu.STORAGE_Y + cell / AmmoStorageMenu.STORAGE_COLUMNS * 18;
            if (method_2378(x, y, 16, 16, mouseX, mouseY)) {
                return cell;
            }
        }
        return -1;
    }

    private void renderCapacity(class_332 graphics) {
        class_2561 capacity = class_2561.method_43469("gui.tacz.ammo_storage.capacity", field_2797.getUsedStacks(), field_2797.getCapacityStacks());
        class_2561 types = class_2561.method_43469("gui.tacz.ammo_storage.types", field_2797.getEntries().size(), AmmoStorageMenu.STORAGE_SLOT_COUNT);
        graphics.method_51439(field_22793, capacity, field_2776 + 8, field_2800 + 18, 0x404040, false);
        graphics.method_51439(field_22793, types, field_2776 + field_2792 - 8 - field_22793.method_27525(types), field_2800 + 18,
                field_2797.getEntries().size() == AmmoStorageMenu.STORAGE_SLOT_COUNT ? 0xAA3030 : 0x404040, false);
        int x = field_2776 + 8;
        int y = field_2800 + 31;
        double fullness = field_2797.getCapacityStacks() <= 0 ? 0
                : Math.min(1, (double) field_2797.getUsedStacks() / field_2797.getCapacityStacks());
        int color = fullness >= 1 ? 0xFFC45A48 : fullness >= 0.75 ? 0xFFD7A744 : 0xFF65A85C;
        graphics.method_25294(x, y, x + 160, y + 6, 0xFF373737);
        graphics.method_25294(x + 1, y + 1, x + 159, y + 5, 0xFF777777);
        graphics.method_25294(x + 1, y + 1, x + 1 + (int) Math.round(158 * fullness), y + 5, color);
    }

    private String formatCount(long count) {
        if (count >= 1_000_000_000) {
            return formatCompact(count, 1_000_000_000, "b");
        }
        if (count >= 1_000_000) {
            return formatCompact(count, 1_000_000, "m");
        }
        if (count >= 1_000) {
            return formatCompact(count, 1_000, "k");
        }
        return Long.toString(count);
    }

    private String formatCompact(long count, int unit, String suffix) {
        long whole = count / unit;
        long decimal = count % unit / (unit / 10);
        return decimal == 0 || whole >= 10 ? whole + suffix : whole + "." + decimal + suffix;
    }

    private void renderSizeLabel(class_332 graphics, int x, int y, String text) {
        float scale = 0.666F;
        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(0, 0, 200);
        graphics.method_51448().method_22905(scale, scale, 1);
        graphics.method_51433(field_22793, text, (int) ((x + 17 - field_22793.method_1727(text) * scale) / scale),
                (int) ((y + 12) / scale), 0xFFFFFFFF, true);
        graphics.method_51448().method_22909();
    }
}
