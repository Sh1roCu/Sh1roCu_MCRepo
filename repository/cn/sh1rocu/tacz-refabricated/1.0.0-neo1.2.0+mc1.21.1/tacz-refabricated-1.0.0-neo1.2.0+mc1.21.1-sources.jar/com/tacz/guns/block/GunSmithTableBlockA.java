package com.tacz.guns.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

/**
 * 单方块的枪械工作台
 */
public class GunSmithTableBlockA extends AbstractGunSmithTableBlock {
    public static final MapCodec<GunSmithTableBlockA> CODEC = method_54094((properties) -> new GunSmithTableBlockA());

    @Override
    protected MapCodec<GunSmithTableBlockA> method_53969() {
        return field_46280;
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2350 direction = context.method_8042().method_10153();
        return this.method_9564().method_11657(FACING, direction);
    }

    @Override
    public boolean isRoot(class_2680 blockState) {
        return true;
    }

    @Override
    public class_2338 getRootPos(class_2338 pos, class_2680 blockState) {
        return pos;
    }
}
