package com.tacz.guns.client.model.functional;

import com.mojang.blaze3d.systems.RenderSystem;
import com.tacz.guns.client.model.IFunctionalRenderer;
import com.tacz.guns.client.model.bedrock.BedrockModel;
import com.tacz.guns.client.resource.pojo.display.gun.RangefinderManager;
import com.tacz.guns.util.RenderHelper;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4668;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector4f;

public class RangefinderImpactPredictionRender implements IFunctionalRenderer {
    private static final float MODEL_TEXT_SCALE = 2.0f / 300.0f;
    private static final float FALLBACK_MODEL_PROJECTION_HALF_HEIGHT = 80.0f;
    private static final float HALF_SIZE = 3.0f;
    private static final float LINE_WIDTH = 1.0f;
    private static final int FULL_BRIGHT = class_765.method_23687(15, 15);

    private final BedrockModel bedrockModel;

    public RangefinderImpactPredictionRender(BedrockModel bedrockModel) {
        this.bedrockModel = bedrockModel;
    }

    @Override
    public void render(class_4587 poseStack, class_4588 vertexBuffer, class_811 transformType, int light, int overlay) {
        render(poseStack, vertexBuffer, transformType, light, overlay, RenderHelper.getBufferSource(transformType));
    }

    @Override
    public void render(class_4587 poseStack, class_4588 vertexBuffer, class_811 transformType, int light, int overlay, class_4597 bufferSource) {
        if (!transformType.method_29998() || !RangefinderManager.shouldRenderImpactPrediction()) {
            return;
        }

        poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0f));
        Matrix3f normal = new Matrix3f(poseStack.method_23760().method_23762());
        Matrix4f pose = new Matrix4f(poseStack.method_23760().method_23761());

        bedrockModel.delegateRender((poseStack1, vertexBuffer1, transformType1, light1, overlay1) -> {
            class_4587 poseStack2 = new class_4587();
            poseStack2.method_23760().method_23762().mul(normal);
            poseStack2.method_23760().method_23761().mul(pose);
            poseStack2.method_22905(MODEL_TEXT_SCALE, -MODEL_TEXT_SCALE, -MODEL_TEXT_SCALE);

            class_1921 renderType = ImpactPredictionRenderState.getBox();
            class_4588 consumer = bufferSource.getBuffer(renderType);
            float yOffset = getCalibratedYOffset(poseStack2.method_23760().method_23761());
            renderBox(consumer, poseStack2.method_23760().method_23761(), yOffset, RangefinderManager.getImpactPredictionColor(), RangefinderManager.getImpactPredictionScale());
            RenderHelper.endBatch(bufferSource, renderType);
        });
    }

    private static float getCalibratedYOffset(Matrix4f pose) {
        class_310 mc = class_310.method_1551();
        int height = mc.method_22683().method_4502();
        float targetY = height / 2.0f + RangefinderManager.getImpactProjectionY() * height / 2.0f;
        float originY = projectGuiY(pose, 0.0f);
        float unitY = projectGuiY(pose, 1.0f);
        float pixelsPerLocalY = unitY - originY;
        if (!Float.isFinite(originY) || !Float.isFinite(unitY) || Math.abs(pixelsPerLocalY) < 1.0E-4f) {
            return RangefinderManager.getImpactProjectionY() * FALLBACK_MODEL_PROJECTION_HALF_HEIGHT;
        }
        return class_3532.method_15363((targetY - originY) / pixelsPerLocalY, -1000.0f, 1000.0f);
    }

    private static float projectGuiY(Matrix4f pose, float localY) {
        int height = class_310.method_1551().method_22683().method_4502();
        Vector4f point = new Vector4f(0.0f, localY, 0.0f, 1.0f);
        point.mul(pose);
        point.mul(RenderSystem.getProjectionMatrix());
        if (point.w() <= 0.0f) {
            return Float.NaN;
        }
        float ndcY = point.y() / point.w();
        return (1.0f - ndcY) * height / 2.0f;
    }

    private static void renderBox(class_4588 consumer, Matrix4f pose, float yOffset, int color, float scale) {
        int a = color >>> 24 & 0xFF;
        int r = color >>> 16 & 0xFF;
        int g = color >>> 8 & 0xFF;
        int b = color & 0xFF;

        float halfSize = HALF_SIZE * scale;
        float left = -halfSize;
        float right = halfSize;
        float top = yOffset - halfSize;
        float bottom = yOffset + halfSize;

        quad(consumer, pose, left, top, right, top + LINE_WIDTH, r, g, b, a);
        quad(consumer, pose, left, bottom - LINE_WIDTH, right, bottom, r, g, b, a);
        quad(consumer, pose, left, top, left + LINE_WIDTH, bottom, r, g, b, a);
        quad(consumer, pose, right - LINE_WIDTH, top, right, bottom, r, g, b, a);
    }

    private static void quad(class_4588 consumer, Matrix4f pose, float minX, float minY, float maxX, float maxY,
                             int r, int g, int b, int a) {
        consumer.method_22918(pose, minX, minY, 0.0f).method_1336(r, g, b, a).method_22913(0.0f, 0.0f).method_60803(FULL_BRIGHT);
        consumer.method_22918(pose, minX, maxY, 0.0f).method_1336(r, g, b, a).method_22913(0.0f, 1.0f).method_60803(FULL_BRIGHT);
        consumer.method_22918(pose, maxX, maxY, 0.0f).method_1336(r, g, b, a).method_22913(1.0f, 1.0f).method_60803(FULL_BRIGHT);
        consumer.method_22918(pose, maxX, minY, 0.0f).method_1336(r, g, b, a).method_22913(1.0f, 0.0f).method_60803(FULL_BRIGHT);
    }

    private static class ImpactPredictionRenderState extends class_4668 {
        private static final class_1921 BOX = class_1921.method_24049(
                "tacz_rangefinder_impact_prediction",
                class_290.field_20888,
                class_293.class_5596.field_27382,
                256,
                true,
                true,
                class_1921.class_4688.method_23598()
                        .method_34578(field_29441)
                        .method_23607(field_22241)
                        .method_23615(BeamRenderer.LaserBeamRenderState.LIGHTNING_ADDITIVE_TRANSPARENCY)
                        .method_23610(field_25643)
                        .method_23608(field_21383)
                        .method_23616(field_21349)
                        .method_23603(field_21345)
                        .method_34577(new class_4683(BeamRenderer.LASER_BEAM_TEXTURE, false, false))
                        .method_23617(false));

        private ImpactPredictionRenderState(String name, Runnable setupState, Runnable clearState) {
            super(name, setupState, clearState);
        }

        private static class_1921 getBox() {
            return BOX;
        }
    }
}
