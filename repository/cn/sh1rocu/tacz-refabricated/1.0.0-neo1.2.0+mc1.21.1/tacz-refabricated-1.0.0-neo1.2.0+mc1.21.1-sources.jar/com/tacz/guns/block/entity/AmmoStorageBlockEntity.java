package com.tacz.guns.block.entity;

import com.tacz.guns.block.AmmoStorageBlock;
import com.tacz.guns.init.ModBlocks;
import com.tacz.guns.inventory.AmmoStorageInventory;
import com.tacz.guns.inventory.AmmoStorageMenu;
import com.tacz.guns.util.AmmoStorageHelper;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SidedStorageBlockEntity;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class AmmoStorageBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338>, SidedStorageBlockEntity {
    public static final class_2591<AmmoStorageBlockEntity> TYPE = class_2591.class_2592.method_20528(AmmoStorageBlockEntity::new,
            ModBlocks.AMMO_STORAGE, ModBlocks.AMMO_STORAGE_GOLD, ModBlocks.AMMO_STORAGE_DIAMOND).method_11034(null);
    public static final int MAX_AMMO_TYPES = 27;

    private final AmmoStorageInventory inventory = new AmmoStorageInventory(MAX_AMMO_TYPES, this::getCapacityStacks,
            AmmoStorageHelper::isValidAmmo, AmmoStorageHelper::getStackSize, this::onInventoryChanged);

    public AmmoStorageBlockEntity(class_2338 pos, class_2680 state) {
        super(TYPE, pos, state);
    }

    public int insertAmmo(class_1799 stack, boolean simulate) {
        return inventory.insert(stack, simulate);
    }

    public class_1799 extractAmmo(class_1799 sample, int count, boolean simulate) {
        return inventory.extract(sample, count, simulate);
    }

    public class_1799 extractAmmo(class_2960 ammoId, int count, boolean simulate) {
        for (AmmoStorageInventory.Content content : inventory.getContents()) {
            if (ammoId.equals(AmmoStorageHelper.getAmmoId(content.sample()))) {
                // Never combine differently tagged ammo into one returned ItemStack.
                return inventory.extract(content.sample(), count, simulate);
            }
        }
        return class_1799.field_8037;
    }

    public int moveAmmoToInventory(class_1263 target, int targetSlots, class_1799 sample, int count) {
        return inventory.moveToInventory(target, targetSlots, sample, count);
    }

    public List<AmmoStorageInventory.Content> getContents() {
        return inventory.getContents();
    }

    public long getInventoryRevision() {
        return inventory.getRevision();
    }

    public long getUsedStacks() {
        return inventory.getUsedStacks();
    }

    public long getRemainingCapacity(class_1799 sample) {
        return inventory.getRemainingCapacity(sample);
    }

    public int getComparatorSignal() {
        return inventory.getComparatorSignal();
    }

    public boolean stillValid(class_1657 player) {
        return field_11863 != null && field_11863.method_8321(field_11867) == this
                && player.method_5649(field_11867.method_10263() + 0.5D, field_11867.method_10264() + 0.5D, field_11867.method_10260() + 0.5D) <= 64;
    }

    @Override
    public void method_11014(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11014(tag, provider);
        inventory.load(tag.method_10554("Entries", class_2520.field_33260), provider);
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 provider) {
        super.method_11007(tag, provider);
        tag.method_10566("Entries", inventory.save(provider));
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471("gui.tacz.ammo_storage.title");
    }

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) {
        return field_11867;
    }

    @Nullable
    @Override
    public class_1703 createMenu(int id, class_1661 inventory, class_1657 player) {
        return new AmmoStorageMenu(id, inventory, this);
    }

    @Override
    public Storage<ItemVariant> getItemStorage(@Nullable class_2350 side) {
        return inventory.storage;
    }

    private void onInventoryChanged() {
        method_5431();
        if (field_11863 != null && !field_11863.method_8608()) {
            field_11863.method_8455(field_11867, method_11010().method_26204());
        }
        // Contents are sent only to open menus, never through block-entity/chunk synchronization.
    }

    public int getCapacityStacks() {
        return method_11010().method_26204() instanceof AmmoStorageBlock storage
                ? storage.getCapacityStacks() : AmmoStorageBlock.IRON_CAPACITY_STACKS;
    }
}
