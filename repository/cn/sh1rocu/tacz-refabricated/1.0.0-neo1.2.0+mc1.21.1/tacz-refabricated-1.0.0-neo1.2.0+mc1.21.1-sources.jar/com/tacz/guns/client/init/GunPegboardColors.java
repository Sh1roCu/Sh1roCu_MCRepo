package com.tacz.guns.client.init;

import com.tacz.guns.GunMod;
import com.tacz.guns.block.entity.GunPegboardBlockEntity;
import com.tacz.guns.init.ModBlocks;
import com.tacz.guns.init.ModItems;
import com.tacz.guns.item.GunPegboardItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_5253;
import net.minecraft.class_5272;

@Environment(EnvType.CLIENT)
public final class GunPegboardColors {
    public static void blockColors() {
        ColorProviderRegistry.BLOCK.register((state, level, pos, tint) -> level != null && pos != null
                && level.method_8321(pos) instanceof GunPegboardBlockEntity pegboard && pegboard.getColor() >= 0
                ? pegboard.getColor() : -1, ModBlocks.GUN_PEGBOARD, ModBlocks.GLOW_GUN_PEGBOARD);
    }

    public static void itemColors() {
        ColorProviderRegistry.ITEM.register((stack, tint) -> GunPegboardItem.hasCustomColor(stack)
                ? class_5253.class_5254.method_57174(GunPegboardItem.getColor(stack)) : -1, ModItems.GUN_PEGBOARD, ModItems.GLOW_GUN_PEGBOARD);
    }

    public static void setup() {
        class_5272.method_27879(ModItems.GUN_PEGBOARD, class_2960.method_60655(GunMod.MOD_ID, "dyed"),
                (stack, level, entity, seed) -> GunPegboardItem.hasCustomColor(stack) ? 1 : 0);
        class_5272.method_27879(ModItems.GLOW_GUN_PEGBOARD, class_2960.method_60655(GunMod.MOD_ID, "dyed"),
                (stack, level, entity, seed) -> GunPegboardItem.hasCustomColor(stack) ? 1 : 0);
    }
}
