package com.tacz.guns.client.sound;

import javax.annotation.Nullable;
import net.minecraft.class_1102;
import net.minecraft.class_1111;
import net.minecraft.class_1144;
import net.minecraft.class_1146;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5819;
import net.minecraft.class_746;
import net.minecraft.class_7654;

public class GunSoundInstance extends class_1102 {
    private static final class_7654 TACZ_SOUND_LISTER = new class_7654("tacz_sounds", ".ogg");

    @Nullable
    private final class_2960 registryName;
    private final boolean canPlay;
    @Nullable
    private class_1111 redirectedSound;
    private final boolean useTaczSound;

    public GunSoundInstance(class_3414 soundEvent, class_3419 source, float volume, float pitch, class_1297 entity, int soundDistance,
                            class_2960 registryName, boolean mono, boolean relative, boolean useTaczSound) {
        super(soundEvent, source, class_5819.method_43049(943));
        this.field_5440 = class_1114.field_5478;
        this.field_18936 = relative;
        this.registryName = registryName;
        this.useTaczSound = useTaczSound;
        this.canPlay = !entity.method_5701();
        this.field_5442 = volume;
        this.field_5441 = pitch;
        this.field_5439 = relative ? 0 : entity.method_23317();
        this.field_5450 = relative ? 0 : entity.method_23318();
        this.field_5449 = relative ? 0 : entity.method_23321();
        class_746 player = class_310.method_1551().field_1724;
        if (player != null && !relative) {
            this.field_5442 = volume * (1.0F - Math.min(1.0F, (float) Math.sqrt(player.method_5649(field_5439, field_5450, field_5449)) / soundDistance));
            this.field_5442 *= this.field_5442;
        }

    }

    public void setStop() {
        class_310.method_1551().method_1483().method_4870(this);
    }

    @Override
    public boolean method_26273() {
        return this.canPlay;
    }

    @Nullable
    public class_2960 getRegistryName() {
        return registryName;
    }

    @Override
    public class_1146 method_4783(class_1144 manager) {
        class_1146 events = super.method_4783(manager);
        if (this.useTaczSound && this.registryName != null) {
            this.redirectedSound = new TaczSound(this.registryName, TACZ_SOUND_LISTER.method_45112(this.registryName), super.method_4776());
            this.field_5444 = this.redirectedSound;
        } else {
            this.redirectedSound = null;
        }
        return events;
    }

    @Override
    public class_1111 method_4776() {
        return redirectedSound == null ? super.method_4776() : redirectedSound;
    }

    private static class TaczSound extends class_1111 {
        private final class_2960 location;
        private final class_2960 path;

        private TaczSound(class_2960 location, class_2960 path, class_1111 template) {
            super(location, template.method_4771(), template.method_4772(), template.method_4894(), class_1112.field_5474,
                    template.method_4769(), false, template.method_4770());
            this.location = location;
            this.path = path;
        }

        @Override
        public class_2960 method_4767() {
            return location;
        }

        @Override
        public class_2960 method_4766() {
            return path;
        }
    }
}
