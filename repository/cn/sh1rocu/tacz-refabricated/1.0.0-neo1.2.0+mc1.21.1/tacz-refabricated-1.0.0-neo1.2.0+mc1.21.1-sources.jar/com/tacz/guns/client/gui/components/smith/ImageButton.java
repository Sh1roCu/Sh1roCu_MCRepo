package com.tacz.guns.client.gui.components.smith;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_5244;
import org.jetbrains.annotations.NotNull;

public class ImageButton extends class_4185 {
    private final int xTexStart;
    private final int yTexStart;
    private final int yDiffTex;
    private final class_2960 resourceLocation;

    public ImageButton(int pX, int pY, int pWidth, int pHeight, int pXTexStart, int pYTexStart, int pYDiffTex, class_2960 pResourceLocation, class_4185.class_4241 pOnPress) {
        super(pX, pY, pWidth, pHeight, class_5244.field_39003, pOnPress, field_40754);
        xTexStart = pXTexStart;
        yTexStart = pYTexStart;
        yDiffTex = pYDiffTex;
        resourceLocation = pResourceLocation;
    }

    @Override
    public void method_48579(@NotNull class_332 gui, int pMouseX, int pMouseY, float pPartialTick) {
        this.renderTexture(gui, this.resourceLocation, this.method_46426(), this.method_46427(), this.xTexStart, this.yTexStart, this.yDiffTex, this.field_22758, this.field_22759, 256, 256);
    }

    private void renderTexture(class_332 pGuiGraphics, class_2960 pTexture, int pX, int pY, int pUOffset, int pVOffset, int pTextureDifference, int pWidth, int pHeight, int pTextureWidth, int pTextureHeight) {
        int i = pVOffset;
        if (!this.method_37303()) {
            i = pVOffset + pTextureDifference * 2;
        } else if (this.method_25367()) {
            i = pVOffset + pTextureDifference;
        }

        RenderSystem.enableDepthTest();
        pGuiGraphics.method_25290(pTexture, pX, pY, (float)pUOffset, (float)i, pWidth, pHeight, pTextureWidth, pTextureHeight);
    }
}