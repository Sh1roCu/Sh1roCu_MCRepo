package com.tacz.guns.client.event;

import cn.sh1rocu.simplebedrockmodel.api.event.RenderFrameEvent;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.client.animation.statemachine.GunAnimationConstant;
import com.tacz.guns.client.renderer.item.AnimateGeoItemRenderer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public class TickAnimationEvent {
    public static void tickAnimation(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null) {
            return;
        }
        class_1799 mainHandItem = player.method_6047();
        TimelessAPI.getGunDisplay(mainHandItem).ifPresent(gunIndex -> {
            var animationStateMachine = gunIndex.getAnimationStateMachine();
            if (animationStateMachine == null) {
                return;
            }
            // 群组服切世界导致的特殊 BUG 处理，正常情况不会遇到此问题
            if (player.field_3913 == null) {
                animationStateMachine.trigger(GunAnimationConstant.INPUT_IDLE);
                return;
            }
            if (!player.method_20303() && player.method_5624()) {
                // 如果玩家正在移动，播放移动动画，否则播放 idle 动画
                animationStateMachine.trigger(GunAnimationConstant.INPUT_RUN);
            } else if (!player.method_20303() && player.field_3913.method_3128().method_35584() > 0.01) {
                animationStateMachine.trigger(GunAnimationConstant.INPUT_WALK);
            } else {
                animationStateMachine.trigger(GunAnimationConstant.INPUT_IDLE);
            }
        });
    }

    public static void tickAnimation(RenderFrameEvent event) {
        if (event.phase == RenderFrameEvent.Phase.END) {
            return;
        }
        if (class_310.method_1551().field_1690.method_31044().method_31034()) {
            return;
        }
        class_746 player = class_310.method_1551().field_1724;
        if (player == null) {
            return;
        }
        class_1799 mainHandItem = player.method_6047();
        if (BuiltinItemRendererRegistry.INSTANCE.get(mainHandItem.method_7909()) instanceof AnimateGeoItemRenderer<?, ?> renderer) {
            // 如果物品不一样了，先尝试初始化状态机
            if (renderer.needReInit(mainHandItem)) {
                renderer.tryInit(mainHandItem, player, event.getTimer().method_60637(false));
            }
            renderer.visualUpdate(mainHandItem);
        }
    }
}
