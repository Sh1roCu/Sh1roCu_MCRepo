package com.tacz.guns.client.resource.serialize;

import com.google.gson.*;
import com.mojang.serialization.JsonOps;
import java.lang.reflect.Type;
import net.minecraft.class_1799;

public class ItemStackSerializer implements JsonDeserializer<class_1799> {
    @Override
    public class_1799 deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        if (json.isJsonObject()) {
            JsonObject jsonObject = json.getAsJsonObject();
            return class_1799.field_24671.parse(JsonOps.INSTANCE, jsonObject).getOrThrow();
        } else {
            throw new JsonSyntaxException("Expected " + json + " to be a ItemStack because it's not an object");
        }
    }
}