package com.tacz.guns.client.renderer.scope;

import cn.sh1rocu.tacz.api.mixin.RenderTargetStencil;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.tacz.guns.GunMod;
import com.tacz.guns.client.resource.pojo.display.attachment.ScopeLensConfig;
import com.tacz.guns.client.util.FirstPersonRenderMath;
import com.tacz.guns.compat.iris.IrisCompat;
import com.tacz.guns.config.client.RenderConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.class_1921;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5944;
import net.minecraft.class_6367;
import net.minecraft.class_8251;
import net.minecraft.class_9799;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.*;
import org.lwjgl.system.MemoryStack;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Local screen-space lens pass, submitted after vanilla hands or Iris' world composite.
 */
@Environment(EnvType.CLIENT)
public final class ScopeLensRenderer {
    private static final int SEGMENTS = 90;
    private static final float SURFACE_Z = -90;
    private static final List<Capture> CAPTURES = new ArrayList<>();
    private static final List<Lens> LENSES = new ArrayList<>();
    private static class_5944 shader;

    private ScopeLensRenderer() {
    }

    public static void registerShader() {
        beginFrame();
        ScopeThermalRenderer.registerShader();
        ScopeLensContour.registerShaders();
        shader = null;
        CoreShaderRegistrationCallback.EVENT.register(ctx -> {
            try {
                ctx.register(
                        class_2960.method_60655(GunMod.MOD_ID, "scope_lens"),
                        class_290.field_1592,
                        instance -> shader = instance
                );
            } catch (IOException exception) {
                GunMod.LOGGER.error("Could not load experimental scope lens shader; using normal scopes", exception);
            }
        });
    }

    /**
     * Drop unfinished draws too, e.g. after a resize, hidden hands or an interrupted frame.
     */
    public static void beginFrame() {
        ScopeThermalRenderer.beginFrame();
        for (Lens lens : LENSES) {
            if (lens.surface != null) lens.surface.close();
            for (Draw draw : lens.reticle) {
                if (draw.vertices != null) draw.vertices.close();
            }
        }
        LENSES.clear();
    }

    /**
     * Called with the live scope stencil/pose; callbacks record geometry, without submitting draws.
     */
    public static boolean capture(float centerX, float centerY, float radius, int stencil, ScopeLensConfig config,
                                  Consumer<class_4588> ocular,
                                  Consumer<class_4597> reticle) {
        if (shader == null || !RenderConfig.EXPERIMENTAL_SCOPE_LENS.get() || radius <= 0.001f
                || IrisCompat.isRenderShadow()) return false;
        class_310 mc = class_310.method_1551();
        var main = mc.method_1522();
        int drawFbo = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        if (drawFbo == 0 || main.field_1482 <= 0 || main.field_1481 <= 0) return false;
        if (GL30.glGetFramebufferAttachmentParameteri(GL30.GL_DRAW_FRAMEBUFFER,
                GL30.GL_STENCIL_ATTACHMENT, GL30.GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE) == GL11.GL_NONE) return false;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            IntBuffer viewport = stack.mallocInt(4);
            GL11.glGetIntegerv(GL11.GL_VIEWPORT, viewport);
            // The captured mask must use the same pixel grid as the final scene colour.
            if (viewport.get(0) != 0 || viewport.get(1) != 0
                    || viewport.get(2) != main.field_1482 || viewport.get(3) != main.field_1481) return false;

            Matrix4f projection = new Matrix4f(RenderSystem.getProjectionMatrix());
            Matrix4f modelView = new Matrix4f(RenderSystem.getModelViewMatrix());
            Bounds bounds = new Bounds(new Matrix4f(projection).mul(modelView));
            ocular.accept(bounds);
            if (!bounds.isValid()) return false;

            // Capture does not draw: only framebuffer/scissor and texture-upload state can change.
            int readFbo = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
            boolean scissor = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
            int activeTexture = GlStateManager._getActiveTexture();
            RenderSystem.activeTexture(GL13.GL_TEXTURE0);
            int texture = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
            try {
                RenderSystem.disableScissor();
                Capture capture = prepareCapture(main.field_1482, main.field_1481, viewport, stack);
                GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, drawFbo);
                GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, capture.target.field_1476);
                // Only the live window mask is needed; capture does not draw or copy depth.
                GlStateManager._glBlitFrameBuffer(0, 0, main.field_1482, main.field_1481, 0, 0, main.field_1482, main.field_1481,
                        GL11.GL_STENCIL_BUFFER_BIT, GL11.GL_NEAREST);
                try {
                    reticle.accept(capture.reticle);
                } catch (RuntimeException exception) {
                    capture.reticle.discard();
                    throw exception;
                }
                LENSES.add(new Lens(capture, stencil, projection, modelView,
                        config, bounds,
                        buildSurface(capture.surface, modelView, centerX, centerY, radius), capture.reticle.finish()));
                return true;
            } finally {
                GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, readFbo);
                GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, drawFbo);
                // Font baking can upload new glyphs even though the reticle only records vertices.
                RenderSystem.activeTexture(GL13.GL_TEXTURE0);
                GlStateManager._bindTexture(texture);
                RenderSystem.activeTexture(activeTexture);
                if (scissor) GlStateManager._enableScissorTest();
                else RenderSystem.disableScissor();
            }
        }
    }

    /**
     * RenderTarget allocation changes extra state; pay for its snapshot only on creation/resize.
     */
    private static Capture prepareCapture(int width, int height, IntBuffer viewport, MemoryStack stack) {
        int slot = LENSES.size();
        Capture capture = slot < CAPTURES.size() ? CAPTURES.get(slot) : null;
        if (capture != null && capture.target.field_1476 >= 0
                && capture.target.field_1482 == width && capture.target.field_1481 == height) return capture;

        boolean depthTest = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
        double clearDepth = GL11.glGetDouble(GL11.GL_DEPTH_CLEAR_VALUE);
        FloatBuffer clearColor = stack.mallocFloat(4);
        GL11.glGetFloatv(GL11.GL_COLOR_CLEAR_VALUE, clearColor);
        try {
            if (capture == null) {
                capture = new Capture(width, height);
                CAPTURES.add(capture);
            } else {
                capture.target.method_1234(width, height, class_310.field_1703);
            }
            capture.target.method_58226(GL11.GL_LINEAR);
            return capture;
        } finally {
            if (depthTest) RenderSystem.enableDepthTest();
            else RenderSystem.disableDepthTest();
            RenderSystem.viewport(viewport.get(0), viewport.get(1), viewport.get(2), viewport.get(3));
            RenderSystem.clearColor(clearColor.get(0), clearColor.get(1), clearColor.get(2), clearColor.get(3));
            RenderSystem.clearDepth(clearDepth);
        }
    }

    /**
     * Both entry points run before screen overlays / Iris' final colour-space conversion.
     */
    public static void render() {
        if (LENSES.isEmpty()) return;
        var main = class_310.method_1551().method_1522();
        try (MemoryStack stack = MemoryStack.stackPush(); RenderState state = new RenderState(stack)) {
            var modelView = RenderSystem.getModelViewStack();
            modelView.pushMatrix();
            try {
                RenderSystem.disableScissor();
                for (Lens lens : LENSES) {
                    class_6367 target = lens.capture.target;
                    if (target.field_1482 != main.field_1482 || target.field_1481 != main.field_1481 || main.method_30277() < 0)
                        continue;
                    ScopeLensContour.Lookup contour = shader != null && RenderConfig.EXPERIMENTAL_SCOPE_LENS.get()
                            && lens.config.hasEdgeEffects()
                            ? ScopeLensContour.prepare(target, lens.stencil, main.field_1482, main.field_1481,
                            lens.centerU - lens.radiusU, lens.centerV - lens.radiusV,
                            lens.centerU + lens.radiusU, lens.centerV + lens.radiusV) : null;
                    target.method_1235(false);
                    // Pair the saved stencil with the final scene, leaving main's depth/stencil untouched.
                    GlStateManager._glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0,
                            GL11.GL_TEXTURE_2D, main.method_30277(), 0);
                    try {
                        RenderSystem.viewport(0, 0, main.field_1482, main.field_1481);
                        RenderSystem.setProjectionMatrix(lens.projection, class_8251.field_43360);
                        modelView.identity();
                        modelView.mul(lens.modelView);
                        RenderSystem.applyModelViewMatrix();
                        GL11.glEnable(GL11.GL_STENCIL_TEST);
                        RenderSystem.stencilFunc(GL11.GL_EQUAL, lens.stencil, 0xFF);
                        RenderSystem.stencilOp(GL11.GL_KEEP, GL11.GL_KEEP, GL11.GL_KEEP);
                        RenderSystem.colorMask(true, true, true, true);
                        if (shader != null && RenderConfig.EXPERIMENTAL_SCOPE_LENS.get()) {
                            drawLens(lens, main.field_1482, main.field_1481, contour);
                        }
                        // Reticle and functional readouts retain their original geometry and colours.
                        for (Draw draw : lens.reticle) {
                            draw.type.method_23516();
                            try {
                                // A RenderType output state may bind another target (e.g. fabulous graphics).
                                target.method_1235(false);
                                RenderSystem.disableDepthTest();
                                RenderSystem.depthMask(false);
                                class_9801 vertices = draw.vertices;
                                draw.vertices = null; // BufferUploader takes ownership, including empty batches.
                                class_286.method_43433(vertices);
                            } finally {
                                draw.type.method_23518();
                            }
                        }
                    } finally {
                        target.method_1235(false);
                        GlStateManager._glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0,
                                GL11.GL_TEXTURE_2D, target.method_30277(), 0);
                    }
                }
            } finally {
                beginFrame();
                modelView.popMatrix();
                RenderSystem.applyModelViewMatrix();
            }
        }
    }

    private static void drawLens(Lens lens, int width, int height, ScopeLensContour.Lookup contour) {
        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
        // Its own colour texture is detached while this FBO writes into main, so reuse it as the snapshot.
        int screenTexture = lens.capture.target.method_30277();
        GlStateManager._bindTexture(screenTexture);
        // Copy first: sampling main's colour texture while drawing back into it is undefined.
        GlStateManager._glCopyTexSubImage2D(GL11.GL_TEXTURE_2D, 0, 0, 0, 0, 0, width, height);
        RenderSystem.setShaderTexture(0, screenTexture);
        // Bind a valid black/scene texture even without a thermal capture; ThermalReady gates sampling.
        RenderSystem.setShaderTexture(1, ScopeThermalRenderer.textureOr(screenTexture, width, height));
        RenderSystem.setShaderTexture(2, contour != null ? contour.texture() : screenTexture);
        RenderSystem.setShader(() -> shader);
        shader.method_35785("ScreenSize").method_1255((float) width, (float) height);
        shader.method_35785("LensCenter").method_1255(lens.centerU, lens.centerV);
        shader.method_35785("LensRadius").method_1255(lens.radiusU, lens.radiusV);
        shader.method_35785("ContourReady").method_35649(contour != null ? 1 : 0);
        if (contour != null) {
            shader.method_35785("ContourRect").method_1254((float) contour.x(), (float) contour.y(),
                    (float) contour.width(), (float) contour.height());
            shader.method_35785("ContourSize").method_1255((float) contour.mapWidth(), (float) contour.mapHeight());
        }
        ScopeLensConfig config = lens.config;
        shader.method_35785("Distortion").method_1251(config.getDistortion());
        shader.method_35785("Aberration").method_1251(config.getAberration());
        shader.method_35785("EdgeWidth").method_1251(config.getEdgeWidth());
        shader.method_35785("VignetteStrength").method_1251(config.getVignetteStrength());
        shader.method_35785("VignetteWidth").method_1251(config.getVignetteWidth());
        int tint = config.getTint();
        float strength = config.getTintStrength();
        shader.method_35785("LensTint").method_1249(
                1 + (((tint >> 16) & 0xFF) / 255f - 1) * strength,
                1 + (((tint >> 8) & 0xFF) / 255f - 1) * strength,
                1 + ((tint & 0xFF) / 255f - 1) * strength);
        ScopeVisionMode mode = config.getVisionMode();
        if (mode.isThermal() && !RenderConfig.SCOPE_THERMAL_ENABLE.get()) mode = ScopeVisionMode.NORMAL;
        shader.method_35785("VisionMode").method_35649(mode.ordinal());
        shader.method_35785("VisionGain").method_1251(config.getVisionGain());
        shader.method_35785("VisionNoise").method_1251(config.getVisionNoise());
        shader.method_35785("SensorTime").method_1251((net.minecraft.class_156.method_658() % 60000L) / 1000f);
        shader.method_35785("ThermalReady").method_35649(ScopeThermalRenderer.isReady(width, height) ? 1 : 0);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.disableBlend();
        class_9801 surface = lens.surface;
        lens.surface = null;
        class_286.method_43433(surface);
    }

    private static class_9801 buildSurface(class_9799 storage, Matrix4f modelView, float x, float y, float radius) {
        // Exactly the same view-space circle used by BedrockAttachmentModel's stencil inversion.
        Matrix4f viewToRender = FirstPersonRenderMath.viewToRender(modelView);
        class_287 builder = new class_287(storage, class_293.class_5596.field_27381, class_290.field_1592);
        builder.method_22918(viewToRender, x, y, SURFACE_Z);
        for (int i = 0; i <= SEGMENTS; i++) {
            double angle = i * Math.PI * 2 / SEGMENTS;
            float cos = (float) Math.cos(angle);
            float sin = (float) Math.sin(angle);
            builder.method_22918(viewToRender, x + cos * radius, y + sin * radius, SURFACE_Z);
        }
        return builder.method_60800();
    }

    public static void close() {
        if (!RenderSystem.isOnRenderThread()) {
            RenderSystem.recordRenderCall(ScopeLensRenderer::close);
            return;
        }
        beginFrame();
        ScopeThermalRenderer.close();
        ScopeLensContour.close();
        for (Capture capture : CAPTURES) {
            capture.target.method_1238();
            capture.surface.close();
            capture.reticle.close();
        }
        CAPTURES.clear();
    }

    private static final class Capture {
        final class_6367 target;
        final class_9799 surface = new class_9799(4096);
        final ReticleBuffers reticle = new ReticleBuffers();

        @SuppressWarnings("RedundantCast")
        Capture(int width, int height) {
            target = new class_6367(width, height, true, class_310.field_1703);
            ((RenderTargetStencil) target).tacz$enableStencil();
        }
    }

    private static final class Draw {
        final class_1921 type;
        class_9801 vertices;

        Draw(class_1921 type, class_9801 vertices) {
            this.type = type;
            this.vertices = vertices;
        }
    }

    private static final class ReticleBuffers implements class_4597 {
        final Map<class_1921, class_9799> builders = new LinkedHashMap<>();
        final Map<class_1921, class_287> active = new LinkedHashMap<>();

        @Override
        public class_4588 getBuffer(class_1921 type) {
            return active.computeIfAbsent(type, key -> new class_287(
                    builders.computeIfAbsent(key, value -> new class_9799(value.method_22722())),
                    key.method_23033(), key.method_23031()));
        }

        List<Draw> finish() {
            List<Draw> draws = new ArrayList<>();
            active.forEach((type, builder) -> {
                class_9801 vertices = builder.method_60794();
                if (vertices != null) draws.add(new Draw(type, vertices));
            });
            active.clear();
            return draws;
        }

        void discard() {
            for (class_287 builder : active.values()) {
                class_9801 vertices = builder.method_60794();
                if (vertices != null) vertices.close();
            }
            active.clear();
        }

        void close() {
            discard();
            builders.values().forEach(class_9799::close);
            builders.clear();
        }
    }

    private static final class Lens {
        final Capture capture;
        final ScopeLensConfig config;
        final int stencil;
        final Matrix4f projection;
        final Matrix4f modelView;
        final float centerU;
        final float centerV;
        final float radiusU;
        final float radiusV;
        class_9801 surface;
        final List<Draw> reticle;

        Lens(Capture capture, int stencil, Matrix4f projection, Matrix4f modelView,
             ScopeLensConfig config, Bounds bounds, class_9801 surface, List<Draw> reticle) {
            this.capture = capture;
            this.config = config;
            this.stencil = stencil;
            this.projection = projection;
            this.modelView = modelView;
            this.centerU = (bounds.minU + bounds.maxU) * 0.5f;
            this.centerV = (bounds.minV + bounds.maxV) * 0.5f;
            this.radiusU = (bounds.maxU - bounds.minU) * 0.5f;
            this.radiusV = (bounds.maxV - bounds.minV) * 0.5f;
            this.surface = surface;
            this.reticle = reticle;
        }
    }

    /**
     * Project the actual ocular geometry, independently of the much larger eye-box circle.
     */
    private static final class Bounds implements class_4588 {
        final Matrix4f projection;
        final Vector4f point = new Vector4f();
        float minU = Float.POSITIVE_INFINITY;
        float minV = Float.POSITIVE_INFINITY;
        float maxU = Float.NEGATIVE_INFINITY;
        float maxV = Float.NEGATIVE_INFINITY;
        boolean behindCamera;

        Bounds(Matrix4f projection) {
            this.projection = projection;
        }

        boolean isValid() {
            return !behindCamera && Float.isFinite(minU) && Float.isFinite(minV)
                    && Float.isFinite(maxU) && Float.isFinite(maxV)
                    && maxU - minU > 0.00001f && maxV - minV > 0.00001f;
        }

        @Override
        public class_4588 method_22912(float x, float y, float z) {
            point.set(x, y, z, 1).mul(projection);
            if (point.w <= 0.0001f || !Float.isFinite(point.w)) {
                behindCamera = true;
                return this;
            }
            float u = point.x / point.w * 0.5f + 0.5f;
            float v = point.y / point.w * 0.5f + 0.5f;
            minU = Math.min(minU, u);
            maxU = Math.max(maxU, u);
            minV = Math.min(minV, v);
            maxV = Math.max(maxV, v);
            return this;
        }

        @Override
        public class_4588 method_1336(int r, int g, int b, int a) {
            return this;
        }

        @Override
        public class_4588 method_22913(float u, float v) {
            return this;
        }

        @Override
        public class_4588 method_60796(int u, int v) {
            return this;
        }

        @Override
        public class_4588 method_22921(int u, int v) {
            return this;
        }

        @Override
        public class_4588 method_22914(float x, float y, float z) {
            return this;
        }
    }

    /**
     * Scope drawing must not leak its framebuffer, projection or GL state into later renderers.
     */
    static final class RenderState implements AutoCloseable {
        final int drawFbo = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        final int readFbo = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        final int vao = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
        final int arrayBuffer = GL11.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
        final IntBuffer viewport;
        final IntBuffer scissorBox;
        final ByteBuffer colorMask;
        final Matrix4f projection = new Matrix4f(RenderSystem.getProjectionMatrix());
        final class_8251 sorting = RenderSystem.getVertexSorting();
        final class_5944 previousShader = RenderSystem.getShader();
        final int activeTexture = GlStateManager._getActiveTexture();
        final int[] textures = new int[3];
        final int[] shaderTextures = new int[12];
        final boolean depthTest = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
        final boolean depthMask = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
        final int depthFunc = GL11.glGetInteger(GL11.GL_DEPTH_FUNC);
        final boolean polygonOffset = GL11.glIsEnabled(GL11.GL_POLYGON_OFFSET_FILL);
        final float polygonOffsetFactor = GL11.glGetFloat(GL11.GL_POLYGON_OFFSET_FACTOR);
        final float polygonOffsetUnits = GL11.glGetFloat(GL11.GL_POLYGON_OFFSET_UNITS);
        final double clearDepth = GL11.glGetDouble(GL11.GL_DEPTH_CLEAR_VALUE);
        final FloatBuffer clearColor;
        final boolean blend = GL11.glIsEnabled(GL11.GL_BLEND);
        final boolean cull = GL11.glIsEnabled(GL11.GL_CULL_FACE);
        final boolean dither = GL11.glIsEnabled(GL11.GL_DITHER);
        final boolean scissor = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
        final boolean stencil = GL11.glIsEnabled(GL11.GL_STENCIL_TEST);
        final int blendSrc = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB);
        final int blendDst = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
        final int blendSrcAlpha = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA);
        final int blendDstAlpha = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
        final int stencilFunc = GL11.glGetInteger(GL11.GL_STENCIL_FUNC);
        final int stencilRef = GL11.glGetInteger(GL11.GL_STENCIL_REF);
        final int stencilValueMask = GL11.glGetInteger(GL11.GL_STENCIL_VALUE_MASK);
        final int stencilFail = GL11.glGetInteger(GL11.GL_STENCIL_FAIL);
        final int stencilDepthFail = GL11.glGetInteger(GL11.GL_STENCIL_PASS_DEPTH_FAIL);
        final int stencilPass = GL11.glGetInteger(GL11.GL_STENCIL_PASS_DEPTH_PASS);

        RenderState(MemoryStack stack) {
            viewport = stack.mallocInt(4);
            scissorBox = stack.mallocInt(4);
            colorMask = stack.malloc(4);
            clearColor = stack.mallocFloat(4);
            GL11.glGetIntegerv(GL11.GL_VIEWPORT, viewport);
            GL11.glGetIntegerv(GL11.GL_SCISSOR_BOX, scissorBox);
            GL11.glGetBooleanv(GL11.GL_COLOR_WRITEMASK, colorMask);
            GL11.glGetFloatv(GL11.GL_COLOR_CLEAR_VALUE, clearColor);
            for (int i = 0; i < shaderTextures.length; i++) shaderTextures[i] = RenderSystem.getShaderTexture(i);
            for (int i = 0; i < textures.length; i++) {
                RenderSystem.activeTexture(GL13.GL_TEXTURE0 + i);
                textures[i] = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
            }
            RenderSystem.activeTexture(activeTexture);
        }

        @Override
        public void close() {
            GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, readFbo);
            GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, drawFbo);
            class_286.method_43436();
            GlStateManager._glBindVertexArray(vao);
            GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, arrayBuffer);
            RenderSystem.viewport(viewport.get(0), viewport.get(1), viewport.get(2), viewport.get(3));
            RenderSystem.setProjectionMatrix(projection, sorting);
            RenderSystem.setShader(() -> previousShader);
            for (int i = 0; i < shaderTextures.length; i++) RenderSystem.setShaderTexture(i, shaderTextures[i]);
            for (int i = 0; i < textures.length; i++) {
                RenderSystem.activeTexture(GL13.GL_TEXTURE0 + i);
                GlStateManager._bindTexture(textures[i]);
            }
            RenderSystem.activeTexture(activeTexture);
            if (depthTest) RenderSystem.enableDepthTest();
            else RenderSystem.disableDepthTest();
            RenderSystem.depthMask(depthMask);
            RenderSystem.depthFunc(depthFunc);
            RenderSystem.polygonOffset(polygonOffsetFactor, polygonOffsetUnits);
            if (polygonOffset) RenderSystem.enablePolygonOffset();
            else RenderSystem.disablePolygonOffset();
            RenderSystem.clearDepth(clearDepth);
            RenderSystem.clearColor(clearColor.get(0), clearColor.get(1), clearColor.get(2), clearColor.get(3));
            RenderSystem.colorMask(colorMask.get(0) != 0, colorMask.get(1) != 0, colorMask.get(2) != 0, colorMask.get(3) != 0);
            if (blend) RenderSystem.enableBlend();
            else RenderSystem.disableBlend();
            RenderSystem.blendFuncSeparate(blendSrc, blendDst, blendSrcAlpha, blendDstAlpha);
            if (cull) RenderSystem.enableCull();
            else RenderSystem.disableCull();
            if (dither) GL11.glEnable(GL11.GL_DITHER);
            else GL11.glDisable(GL11.GL_DITHER);
            RenderSystem.enableScissor(scissorBox.get(0), scissorBox.get(1), scissorBox.get(2), scissorBox.get(3));
            if (!scissor) RenderSystem.disableScissor();
            RenderSystem.stencilFunc(stencilFunc, stencilRef, stencilValueMask);
            RenderSystem.stencilOp(stencilFail, stencilDepthFail, stencilPass);
            if (stencil) GL11.glEnable(GL11.GL_STENCIL_TEST);
            else GL11.glDisable(GL11.GL_STENCIL_TEST);
        }
    }
}
