package com.tacz.guns.client.input;

import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.config.client.KeyConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

import static com.tacz.guns.util.InputExtraCheck.isInGame;

@Environment(EnvType.CLIENT)
public class AimKey {
    public static final class_304 AIM_KEY = new class_304("key.tacz.aim.desc",
            class_3675.class_307.field_1672,
            GLFW.GLFW_MOUSE_BUTTON_RIGHT,
            "key.category.tacz");
    private static boolean controllerAimDown;

    public static boolean onAimPress() {
        return onAimInput(true);
    }

    /**
     * 合并键鼠和手柄的按住状态，同时保留切换武器时的瞄准预输入。
     */
    public static void onAimHoldingPreInput(class_310 client) {
        if (/*event.phase != TickEvent.Phase.END ||*/ !KeyConfig.HOLD_TO_AIM.get()) {
            return;
        }
        onAimInput(false);
    }

    public static boolean onAimControllerPress(boolean isPress) {
        controllerAimDown = isPress;
        return onAimInput(isPress);
    }

    public static void setControllerAimDown(boolean isDown) {
        controllerAimDown = isDown;
    }

    private static boolean onAimInput(boolean isPress) {
        if (!isInGame()) {
            return false;
        }
        class_746 player = class_310.method_1551().field_1724;
        if (player == null || player.method_7325()) {
            return false;
        }
        if (!(player instanceof IClientPlayerGunOperator operator)) {
            return false;
        }
        if (!IGun.mainHandHoldGun(player)) {
            return false;
        }
        boolean holdToAim = KeyConfig.HOLD_TO_AIM.get();
        if (!isPress && !holdToAim) {
            return false;
        }
        boolean aim = holdToAim ? AIM_KEY.method_1434() || controllerAimDown : !operator.isAim();
        if (operator.isAim() != aim) {
            operator.aim(aim);
        }
        return true;
    }

    public static void cancelAim(class_310 client) {
//        if (event.phase != TickEvent.Phase.END) {
//            return;
//        }
        class_310 mc = class_310.method_1551();
        if (!isInGame()) {
            controllerAimDown = false;
        }
        class_746 player = mc.field_1724;
        if (!(player instanceof IClientPlayerGunOperator operator)) {
            return;
        }
        if (operator.isAim() && (!isInGame() || player.method_7325())) {
            IClientPlayerGunOperator.fromLocalPlayer(player).aim(false);
        }
    }
}
