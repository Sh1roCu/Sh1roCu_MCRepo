package com.tacz.guns.client.renderer.scope;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.tacz.guns.GunMod;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5944;
import net.minecraft.class_6367;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

import java.io.IOException;

/**
 * GPU distance-to-ocular-boundary lookup, shared by scopes drawn sequentially in the lens pass.
 */
@Environment(EnvType.CLIENT)
final class ScopeLensContour {
    private static final int MAX_SIZE = 512;
    private static final class_6367[] TARGETS = new class_6367[2];
    private static class_5944 maskShader;
    private static class_5944 seedShader;
    private static class_5944 distanceShader;

    private ScopeLensContour() {
    }

    static void registerShaders() {
        maskShader = null;
        seedShader = null;
        distanceShader = null;
        CoreShaderRegistrationCallback.EVENT.register(ctx -> {
            try {
                ctx.register(
                        class_2960.method_60655(GunMod.MOD_ID, "scope_lens_mask"),
                        class_290.field_1592,
                        instance -> maskShader = instance
                );
                ctx.register(
                        class_2960.method_60655(GunMod.MOD_ID, "scope_lens_seed"), class_290.field_1592,
                        instance -> seedShader = instance
                );
                ctx.register(
                        class_2960.method_60655(GunMod.MOD_ID, "scope_lens_distance"), class_290.field_1592,
                        instance -> distanceShader = instance
                );
            } catch (IOException exception) {
                GunMod.LOGGER.error("Could not load scope contour shaders; using elliptical lens edges", exception);
            }
        });
    }

    /**
     * Called inside ScopeLensRenderer's RenderState, before its target is attached to scene colour.
     */
    static Lookup prepare(class_6367 ocular, int stencil, int screenWidth, int screenHeight,
                          float minU, float minV, float maxU, float maxV) {
        if (maskShader == null || seedShader == null || distanceShader == null) return null;
        // Padding supplies exterior seeds without treating the eye-box or screen edge as lens geometry.
        int x = (int) Math.max(0, Math.min(screenWidth, Math.floor((double) minU * screenWidth) - 2));
        int y = (int) Math.max(0, Math.min(screenHeight, Math.floor((double) minV * screenHeight) - 2));
        int right = (int) Math.max(0, Math.min(screenWidth, Math.ceil((double) maxU * screenWidth) + 2));
        int top = (int) Math.max(0, Math.min(screenHeight, Math.ceil((double) maxV * screenHeight) + 2));
        int width = right - x;
        int height = top - y;
        if (width <= 0 || height <= 0) return null;
        float scale = Math.min(1f, (float) MAX_SIZE / Math.max(width, height));
        int mapWidth = Math.min(MAX_SIZE, Math.max(1, (int) Math.ceil(width * scale)));
        int mapHeight = Math.min(MAX_SIZE, Math.max(1, (int) Math.ceil(height * scale)));

        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
        for (int i = 0; i < TARGETS.length; i++) {
            if (TARGETS[i] == null) {
                TARGETS[i] = new class_6367(MAX_SIZE, MAX_SIZE, false, class_310.field_1703);
                // Packed integer seed coordinates must never be interpolated.
                TARGETS[i].method_58226(GL11.GL_NEAREST);
            }
        }
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableBlend();
        GL11.glDisable(GL11.GL_DITHER);
        RenderSystem.disableCull();
        RenderSystem.colorMask(true, true, true, true);
        ocular.method_1235(false);
        RenderSystem.viewport(0, 0, screenWidth, screenHeight);
        RenderSystem.enableScissor(x, y, width, height);
        RenderSystem.clearColor(0, 0, 0, 0);
        RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT, class_310.field_1703);
        GL11.glEnable(GL11.GL_STENCIL_TEST);
        RenderSystem.stencilOp(GL11.GL_KEEP, GL11.GL_KEEP, GL11.GL_KEEP);
        RenderSystem.setShader(() -> maskShader);
        // Eye-box inversion changes the ocular ID to its complement. Their union is the full ocular,
        // including its texture-alpha silhouette, independently of the current aiming progress.
        RenderSystem.stencilFunc(GL11.GL_EQUAL, stencil, 0xFF);
        drawQuad();
        RenderSystem.stencilFunc(GL11.GL_EQUAL, ~stencil & 0xFF, 0xFF);
        drawQuad();
        RenderSystem.disableScissor();
        GL11.glDisable(GL11.GL_STENCIL_TEST);

        TARGETS[0].method_1235(false);
        RenderSystem.viewport(0, 0, mapWidth, mapHeight);
        RenderSystem.setShaderTexture(0, ocular.method_30277());
        RenderSystem.setShader(() -> seedShader);
        seedShader.method_35785("SourceSize").method_1255((float) screenWidth, (float) screenHeight);
        seedShader.method_35785("MapSize").method_1255((float) mapWidth, (float) mapHeight);
        seedShader.method_35785("MaskRect").method_1254((float) x, (float) y, (float) width, (float) height);
        drawQuad();

        int source = 0;
        for (int step = Integer.highestOneBit(Math.max(mapWidth, mapHeight) - 1); step > 0; step >>= 1) {
            flood(source, 1 - source, mapWidth, mapHeight, width, height, step);
            source = 1 - source;
        }
        // JFA+1 reduces errors where several edges/corners compete for the nearest seed.
        flood(source, 1 - source, mapWidth, mapHeight, width, height, 1);
        source = 1 - source;
        return new Lookup(TARGETS[source].method_30277(), x, y, width, height, mapWidth, mapHeight);
    }

    private static void flood(int source, int destination, int width, int height,
                              int pixelWidth, int pixelHeight, int step) {
        TARGETS[destination].method_1235(false);
        RenderSystem.viewport(0, 0, width, height);
        RenderSystem.setShaderTexture(0, TARGETS[source].method_30277());
        RenderSystem.setShader(() -> distanceShader);
        distanceShader.method_35785("MapSize").method_1255((float) width, (float) height);
        distanceShader.method_35785("PixelScale").method_1255((float) pixelWidth / width, (float) pixelHeight / height);
        distanceShader.method_35785("JumpStep").method_35649(step);
        drawQuad();
    }

    private static void drawQuad() {
        class_287 builder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
        builder.method_22912(-1, -1, 0);
        builder.method_22912(1, -1, 0);
        builder.method_22912(1, 1, 0);
        builder.method_22912(-1, 1, 0);
        class_286.method_43433(builder.method_60800());
    }

    static void close() {
        for (int i = 0; i < TARGETS.length; i++) {
            if (TARGETS[i] != null) TARGETS[i].method_1238();
            TARGETS[i] = null;
        }
    }

    record Lookup(int texture, int x, int y, int width, int height, int mapWidth, int mapHeight) {
    }
}
