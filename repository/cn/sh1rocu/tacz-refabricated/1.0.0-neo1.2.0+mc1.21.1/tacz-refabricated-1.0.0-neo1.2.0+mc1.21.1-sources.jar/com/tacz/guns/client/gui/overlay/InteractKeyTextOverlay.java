package com.tacz.guns.client.gui.overlay;

import com.tacz.guns.api.item.IAmmo;
import com.tacz.guns.api.item.IAttachment;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.block.AbstractGunSmithTableBlock;
import com.tacz.guns.block.AmmoStorageBlock;
import com.tacz.guns.block.GunDisplayCaseBlock;
import com.tacz.guns.block.GunDisplayCaseSlotHelper;
import com.tacz.guns.block.entity.GunDisplayCaseBlockEntity;
import com.tacz.guns.client.input.InteractKey;
import com.tacz.guns.config.client.RenderConfig;
import com.tacz.guns.config.util.GunPegboardItemConfigRead;
import com.tacz.guns.config.util.InteractKeyConfigRead;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_746;
import net.minecraft.class_9080;
import net.minecraft.class_9779;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;

public class InteractKeyTextOverlay implements class_9080.class_9081 {
    public static final InteractKeyTextOverlay INSTANCE = new InteractKeyTextOverlay();

    @Override
    public void render(class_332 graphics, @NotNull class_9779 deltaTracker) {
        int width = graphics.method_51421();
        int height = graphics.method_51443();

        if (RenderConfig.DISABLE_INTERACT_HUD_TEXT.get()) {
            return;
        }
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null || player.method_7325()) {
            return;
        }
        class_239 hitResult = mc.field_1765;
        if (hitResult == null) {
            return;
        }
        if (hitResult instanceof class_3965 blockHitResult) {
            renderBlockText(graphics, width, height, blockHitResult, player, mc);
            return;
        }
        if (hitResult instanceof class_3966 entityHitResult) {
            renderEntityText(graphics, width, height, entityHitResult, mc);
        }
    }

    private static void renderBlockText(class_332 graphics, int width, int height, class_3965 blockHitResult, class_746 player, class_310 mc) {
        class_2338 blockPos = blockHitResult.method_17777();
        class_2680 block = player.method_37908().method_8320(blockPos);
        if (block.method_26204() instanceof GunDisplayCaseBlock) {
            renderDisplayCaseText(graphics, width, height, blockHitResult, player, mc, block);
            return;
        }
        if (block.method_26204() instanceof AmmoStorageBlock && IGun.mainHandHoldGun(player)) {
            renderText(graphics, width, height, mc.field_1772, InteractKey.INTERACT_KEY.method_16007().getString(),
                    class_2561.method_43471("gui.tacz.interact_key.text.ammo_storage_pickup"));
            return;
        }
        if (InteractKeyConfigRead.canInteractBlock(block)) {
            boolean mainHandHoldGun = IGun.mainHandHoldGun(player);
            boolean hasGunSmithTableFilterItem = hasGunSmithTableFilterItem(block, player);
            boolean willFilterByHand = RenderConfig.AUTO_SELECT_GUN_SMITH_TABLE_FILTER.get() && hasGunSmithTableFilterItem;
            if (mainHandHoldGun) {
                renderText(graphics, width, height, mc.field_1772, InteractKey.INTERACT_KEY.method_16007().getString(), willFilterByHand ? class_2561.method_43471("gui.tacz.interact_key.text.gun_smith_table_filter") : null);
            } else if (hasGunSmithTableFilterItem) {
                renderText(graphics, width, height, mc.field_1772, mc.field_1690.field_1904.method_16007().getString(), willFilterByHand ? class_2561.method_43471("gui.tacz.interact_key.text.gun_smith_table_filter") : null);
            }
        }
    }

    private static void renderDisplayCaseText(class_332 graphics, int width, int height, class_3965 blockHitResult, class_746 player, class_310 mc, class_2680 block) {
        if (!IGun.mainHandHoldGun(player) || block.method_11654(GunDisplayCaseBlock.LOCKED)) {
            return;
        }
        int slot = GunDisplayCaseSlotHelper.getSlot(block, blockHitResult.method_17777(), blockHitResult.method_17784());
        if (slot < 0 || !(player.method_37908().method_8321(blockHitResult.method_17777()) instanceof GunDisplayCaseBlockEntity displayCase)) {
            return;
        }
        boolean occupied = !displayCase.getItem(slot).method_7960();
        boolean canPlaceHeld = GunPegboardItemConfigRead.canPlace(player.method_6047());
        if (occupied || canPlaceHeld) {
            renderText(graphics, width, height, mc.field_1772, InteractKey.INTERACT_KEY.method_16007().getString(), null);
        }
    }

    private static void renderEntityText(class_332 graphics, int width, int height, class_3966 entityHitResult, class_310 mc) {
        if (mc.field_1724 == null || !IGun.mainHandHoldGun(mc.field_1724)) {
            return;
        }
        class_1297 entity = entityHitResult.method_17782();
        if (InteractKeyConfigRead.canInteractEntity(entity)) {
            renderText(graphics, width, height, mc.field_1772, InteractKey.INTERACT_KEY.method_16007().getString(), null);
        }
    }

    private static boolean hasGunSmithTableFilterItem(class_2680 block, class_746 player) {
        if (!(block.method_26204() instanceof AbstractGunSmithTableBlock)) {
            return false;
        }
        class_1799 stack = player.method_6047();
        class_1792 item = stack.method_7909();
        return item instanceof IGun || item instanceof IAttachment || item instanceof IAmmo;
    }

    private static void renderText(class_332 graphics, int width, int height, class_327 font, String keyName, class_2561 subtitle) {
        class_2561 title = class_2561.method_43469("gui.tacz.interact_key.text.desc", StringUtils.capitalize(keyName));
        graphics.method_51439(font, title, (int) ((width - font.method_27525(title)) / 2.0f), (int) (height / 2.0f - 25), class_124.field_1054.method_532(), false);
        if (subtitle != null) {
            graphics.method_51439(font, subtitle, (int) ((width - font.method_27525(subtitle)) / 2.0f), (int) (height / 2.0f - 14), class_124.field_1080.method_532(), false);
        }
    }
}