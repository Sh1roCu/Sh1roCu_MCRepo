package com.tacz.guns.client.gui.overlay;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9080;
import net.minecraft.class_9779;

public class DisplayCaseLockHintOverlay implements class_9080.class_9081 {
    private static final int DISPLAY_TICKS = 40;
    private static final int Y_OFFSET = 32;
    private static class_2561 message = class_2561.method_43473();
    private static int ticksRemaining;

    public static final DisplayCaseLockHintOverlay INSTANCE = new DisplayCaseLockHintOverlay();

    public static void show(class_2561 component) {
        message = component;
        ticksRemaining = DISPLAY_TICKS;
    }

    @Override
    public void render(class_332 graphics, class_9779 deltaTracker) {
        int width = graphics.method_51421();
        int height = graphics.method_51443();
        if (ticksRemaining <= 0) {
            return;
        }
        class_310 minecraft = class_310.method_1551();
        class_327 font = minecraft.field_1772;
        graphics.method_51439(font, message, (int) ((width - font.method_27525(message)) / 2.0F), (int) (height / 2.0F + Y_OFFSET), class_124.field_1054.method_532(), false);
    }

    public static void onClientTick(class_310 client) {
        if (/*event.phase == TickEvent.Phase.END &&*/ ticksRemaining > 0) {
            ticksRemaining--;
        }
    }
}
