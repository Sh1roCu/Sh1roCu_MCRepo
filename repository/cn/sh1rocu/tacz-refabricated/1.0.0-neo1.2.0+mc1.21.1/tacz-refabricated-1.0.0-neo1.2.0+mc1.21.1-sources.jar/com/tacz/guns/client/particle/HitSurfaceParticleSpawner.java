package com.tacz.guns.client.particle;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.client.resource.pojo.display.ammo.HitSurfaceParticle;
import com.tacz.guns.config.client.RenderConfig;
import com.tacz.guns.util.ColorHex;
import org.apache.commons.lang3.StringUtils;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import net.minecraft.class_1657;
import net.minecraft.class_2223;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2388;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5743;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_702;
import net.minecraft.class_703;
import java.util.List;

public final class HitSurfaceParticleSpawner {
    private static final int MAX_BLOCK_PARTICLE_COUNT = 32;
    private static final int MAX_DISPLAY_PARTICLE_COUNT_PER_HIT = 64;
    private static final float DEFAULT_SURFACE_OFFSET = 0.03f;
    private static final float DEFAULT_RANDOM_OFFSET = 0.01f;
    private static final int DEFAULT_BLOCK_PARTICLE_COUNT = 3;
    private static final float DEFAULT_BLOCK_NORMAL_SPEED = 0.14f;
    private static final float DEFAULT_BLOCK_RANDOM_SPEED = 0.015f;
    private static final float DEFAULT_BLOCK_SPREAD_ANGLE = 30.0f;
    private static final String DUST = "minecraft:dust";
    private static final String DUST_COLOR_TRANSITION = "minecraft:dust_color_transition";
    private static final String BLOCK = "minecraft:block";
    private static final String FALLING_DUST = "minecraft:falling_dust";
    private static final String ITEM = "minecraft:item";

    private HitSurfaceParticleSpawner() {
    }

    public static void spawn(class_638 level, class_243 hitPos, class_2350 direction, class_2338 blockPos, String ammoId, String gunId, String gunDisplayId, boolean incendiary) {
        if (!RenderConfig.HIT_PARTICLE_ENABLE.get() || !isCloseEnough(hitPos)) {
            return;
        }
        class_2680 blockState = level.method_8320(blockPos);
        class_702 particleEngine = class_310.method_1551().field_1713;
        class_5819 random = level.field_9229;
        Integer blockParticleCount = getAmmoBlockParticleCount(ammoId);
        spawnBlockParticles(particleEngine, random, blockState, hitPos, direction, blockParticleCount, incendiary);
        if (!RenderConfig.HIT_EXTRA_PARTICLE_ENABLE.get()) {
            return;
        }
        List<HitSurfaceParticle> particles = getDisplayParticles(ammoId, gunId, gunDisplayId);
        if (particles == null || particles.isEmpty()) {
            return;
        }
        int remainingCount = MAX_DISPLAY_PARTICLE_COUNT_PER_HIT;
        for (HitSurfaceParticle particle : particles) {
            remainingCount -= spawnDisplayParticle(particleEngine, random, blockState, hitPos, direction, particle, remainingCount);
            if (remainingCount <= 0) {
                return;
            }
        }
    }

    private static boolean isCloseEnough(class_243 hitPos) {
        int maxDistance = RenderConfig.HIT_PARTICLE_MAX_DISTANCE.get();
        if (maxDistance <= 0) {
            return true;
        }
        class_1657 player = class_310.method_1551().field_1724;
        double maxDistanceSqr = (double) maxDistance * (double) maxDistance;
        return player != null && player.method_5707(hitPos) <= maxDistanceSqr;
    }

    private static void spawnBlockParticles(class_702 particleEngine, class_5819 random, class_2680 blockState, class_243 hitPos, class_2350 direction, @Nullable Integer configuredCount, boolean incendiary) {
        int count = configuredCount == null ? DEFAULT_BLOCK_PARTICLE_COUNT : Math.min(configuredCount, MAX_BLOCK_PARTICLE_COUNT);
        if (count <= 0) {
            return;
        }
        class_2394 options = incendiary ? class_2398.field_11239 : new class_2388(class_2398.field_11217, blockState);
        for (int i = 0; i < count; i++) {
            class_243 pos = randomPosition(random, hitPos, direction, DEFAULT_SURFACE_OFFSET, DEFAULT_RANDOM_OFFSET);
            class_243 speed = randomVelocity(random,
                    direction,
                    DEFAULT_BLOCK_NORMAL_SPEED,
                    DEFAULT_BLOCK_RANDOM_SPEED,
                    DEFAULT_BLOCK_SPREAD_ANGLE);
            particleEngine.method_3056(options, pos.field_1352, pos.field_1351, pos.field_1350, speed.field_1352, speed.field_1351, speed.field_1350);
        }
    }

    @Nullable
    private static Integer getAmmoBlockParticleCount(String ammoId) {
        try {
            return TimelessAPI.getClientAmmoIndex(class_2960.method_12829(ammoId))
                    .map(ammoIndex -> ammoIndex.getHitBlockParticleCount())
                    .orElse(null);
        } catch (Exception ignored) {
            return null;
        }
    }

    @Nullable
    private static List<HitSurfaceParticle> getDisplayParticles(String ammoId, String gunId, String gunDisplayId) {
        try {
            class_2960 gunDisplayLocation = class_2960.method_12829(gunDisplayId);
            class_2960 gunLocation = class_2960.method_12829(gunId);
            var gunDisplay = TimelessAPI.getGunDisplay(gunDisplayLocation, gunLocation);
            if (gunDisplay.isPresent() && gunDisplay.get().getHitSurfaceParticles() != null) {
                return gunDisplay.get().getHitSurfaceParticles();
            }
            return TimelessAPI.getClientAmmoIndex(class_2960.method_12829(ammoId))
                    .map(ammoIndex -> ammoIndex.getHitSurfaceParticles())
                    .orElse(null);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static int spawnDisplayParticle(class_702 particleEngine, class_5819 random, class_2680 blockState, class_243 hitPos, class_2350 direction, HitSurfaceParticle particle, int maxCount) {
        class_2394 options = parseParticle(blockState, particle);
        if (options == null || maxCount <= 0) {
            return 0;
        }
        int count = Math.min(randomCount(random, particle), maxCount);
        int spawned = 0;
        for (int i = 0; i < count; i++) {
            class_243 pos = randomPosition(random, hitPos, direction, particle.getSurfaceOffset(), particle.getRandomOffset());
            class_243 speed = randomVelocity(random, direction, particle.getNormalSpeed(), particle.getRandomSpeed(), particle.getSpreadAngle());
            class_703 result = particleEngine.method_3056(options, pos.field_1352, pos.field_1351, pos.field_1350, speed.field_1352, speed.field_1351, speed.field_1350);
            if (result != null) {
                applyParticleOverrides(result, particle);
                spawned++;
            }
        }
        return spawned;
    }

    private static int randomCount(class_5819 random, HitSurfaceParticle particle) {
        int min = particle.getCountMin();
        int max = particle.getCountMax();
        if (max < min) {
            int swap = min;
            min = max;
            max = swap;
        }
        if (max == min) {
            return min;
        }
        return min + random.method_43048(max - min + 1);
    }

    @Nullable
    private static class_2394 parseParticle(class_2680 blockState, HitSurfaceParticle particle) {
        String name = particle.getName();
        if (StringUtils.isBlank(name)) {
            return null;
        }
        String trimmedName = name.trim();
        boolean hasArguments = trimmedName.split("\\s+", 2).length > 1;
        if (hasArguments) {
            try {
                return class_2223.method_9418(new StringReader(trimmedName), com.tacz.guns.client.util.ClientRegistryAccess.registries());
            } catch (CommandSyntaxException ignored) {
                return null;
            }
        }
        String particleId = normalizeParticleId(trimmedName);
        if (BLOCK.equals(particleId)) {
            return new class_2388(class_2398.field_11217, blockState);
        }
        if (FALLING_DUST.equals(particleId)) {
            return new class_2388(class_2398.field_11206, blockState);
        }
        if (DUST.equals(particleId)) {
            float[] color = colorOrDefault(particle.getColor(), 1.0f, 0.35f, 0.1f);
            return new class_2390(new Vector3f(color[0], color[1], color[2]), positiveScale(particle));
        }
        if (DUST_COLOR_TRANSITION.equals(particleId)) {
            float[] color = colorOrDefault(particle.getColor(), 1.0f, 0.35f, 0.1f);
            Vector3f fromColor = new Vector3f(color[0], color[1], color[2]);
            Vector3f toColor = new Vector3f(color[0] * 0.25f, color[1] * 0.25f, color[2] * 0.25f);
            return new class_5743(fromColor, toColor, positiveScale(particle));
        }
        if (ITEM.equals(particleId)) {
            return null;
        }
        try {
            return class_2223.method_9418(new StringReader(trimmedName), com.tacz.guns.client.util.ClientRegistryAccess.registries());
        } catch (CommandSyntaxException ignored) {
            return null;
        }
    }

    private static String normalizeParticleId(String particleName) {
        String firstToken = particleName.split("\\s+", 2)[0];
        class_2960 id = class_2960.method_12829(firstToken);
        if (id == null) {
            return firstToken;
        }
        return id.toString();
    }

    private static float positiveScale(HitSurfaceParticle particle) {
        Float scale = particle.getScale();
        return scale == null ? 1.0f : Math.max(scale, 0.0f);
    }

    private static float[] colorOrDefault(@Nullable String color, float red, float green, float blue) {
        if (StringUtils.isBlank(color)) {
            return new float[]{red, green, blue};
        }
        return ColorHex.colorTextToRbgFloatArray(color);
    }

    private static void applyParticleOverrides(class_703 result, HitSurfaceParticle particle) {
        result.method_3077(particle.getLifeTime());
        String color = particle.getColor();
        if (StringUtils.isNotBlank(color)) {
            float[] rgb = ColorHex.colorTextToRbgFloatArray(color);
            result.method_3084(rgb[0], rgb[1], rgb[2]);
        }
        Float scale = particle.getScale();
        if (scale != null && scale > 0 && !usesScaleInParticleOptions(particle)) {
            result.method_3087(scale);
        }
    }

    private static boolean usesScaleInParticleOptions(HitSurfaceParticle particle) {
        String name = particle.getName();
        if (StringUtils.isBlank(name)) {
            return false;
        }
        String particleId = normalizeParticleId(name.trim());
        return DUST.equals(particleId) || DUST_COLOR_TRANSITION.equals(particleId);
    }

    private static class_243 randomPosition(class_5819 random, class_243 hitPos, class_2350 direction, float surfaceOffset, float randomOffset) {
        class_243 normal = class_243.method_24954(direction.method_10163());
        double offsetX = randomOffset == 0 ? 0 : random.method_43059() * randomOffset;
        double offsetY = randomOffset == 0 ? 0 : random.method_43059() * randomOffset;
        double offsetZ = randomOffset == 0 ? 0 : random.method_43059() * randomOffset;
        return hitPos.method_1019(normal.method_1021(surfaceOffset)).method_1031(offsetX, offsetY, offsetZ);
    }

    private static class_243 randomVelocity(class_5819 random, class_2350 direction, float normalSpeed, float randomSpeed, float spreadAngle) {
        class_243 normal = class_243.method_24954(direction.method_10163()).method_1029();
        class_243 tangent = Math.abs(normal.field_1351) > 0.9 ? new class_243(1, 0, 0) : normal.method_1036(new class_243(0, 1, 0)).method_1029();
        class_243 bitangent = normal.method_1036(tangent).method_1029();
        double spread = Math.tan(Math.toRadians(spreadAngle));
        class_243 cone = normal
                .method_1019(tangent.method_1021(random.method_43059() * spread))
                .method_1019(bitangent.method_1021(random.method_43059() * spread))
                .method_1029()
                .method_1021(normalSpeed);
        class_243 randomVector = new class_243(random.method_43059(), random.method_43059(), random.method_43059()).method_1021(randomSpeed);
        return cone.method_1019(randomVector);
    }
}
