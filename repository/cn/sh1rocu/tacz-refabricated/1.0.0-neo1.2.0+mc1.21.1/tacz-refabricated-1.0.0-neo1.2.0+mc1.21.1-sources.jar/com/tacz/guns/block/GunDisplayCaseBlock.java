package com.tacz.guns.block;

import com.mojang.serialization.MapCodec;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.block.entity.GunDisplayCaseBlockEntity;
import com.tacz.guns.config.util.GunPegboardItemConfigRead;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_9062;

public class GunDisplayCaseBlock extends class_2237 {
    public static final MapCodec<GunDisplayCaseBlock> CODEC = method_54094(GunDisplayCaseBlock::new);

    public static final class_2753 FACING = class_2741.field_12481;
    public static final class_2746 LOCKED = class_2746.method_11825("locked");
    public static final class_2746 LEFT = class_2746.method_11825("left");
    public static final class_2746 RIGHT = class_2746.method_11825("right");
    public static final class_2746 UP = class_2746.method_11825("up");
    public static final class_2746 DOWN = class_2746.method_11825("down");
    private static final int MAX_GROUP_TOGGLE = 512;
    private static final int LOCK_UPDATE_FLAGS = class_2248.field_31031 | class_2248.field_31028;

    private static final class_265 NORTH_LOCKED_SHAPE = class_2248.method_9541(0, 0, 4, 16, 16, 16);
    private static final class_265 SOUTH_LOCKED_SHAPE = class_2248.method_9541(0, 0, 0, 16, 16, 12);
    private static final class_265 WEST_LOCKED_SHAPE = class_2248.method_9541(4, 0, 0, 16, 16, 16);
    private static final class_265 EAST_LOCKED_SHAPE = class_2248.method_9541(0, 0, 0, 12, 16, 16);
    private static final class_265 NORTH_BACK_PANEL_SHAPE = class_2248.method_9541(0, 0, 13, 16, 16, 16);
    private static final class_265 SOUTH_BACK_PANEL_SHAPE = class_2248.method_9541(0, 0, 0, 16, 16, 3);
    private static final class_265 WEST_BACK_PANEL_SHAPE = class_2248.method_9541(13, 0, 0, 16, 16, 16);
    private static final class_265 EAST_BACK_PANEL_SHAPE = class_2248.method_9541(0, 0, 0, 3, 16, 16);
    private static final class_265 NORTH_OPEN_SHAPE = class_259.method_17786(
            NORTH_BACK_PANEL_SHAPE,
            class_2248.method_9541(0, 0, 4, 1, 16, 16),
            class_2248.method_9541(15, 0, 4, 16, 16, 16),
            class_2248.method_9541(0, 0, 4, 16, 1, 16),
            class_2248.method_9541(0, 15, 4, 16, 16, 16)
    );
    private static final class_265 SOUTH_OPEN_SHAPE = class_259.method_17786(
            SOUTH_BACK_PANEL_SHAPE,
            class_2248.method_9541(0, 0, 0, 1, 16, 12),
            class_2248.method_9541(15, 0, 0, 16, 16, 12),
            class_2248.method_9541(0, 0, 0, 16, 1, 12),
            class_2248.method_9541(0, 15, 0, 16, 16, 12)
    );
    private static final class_265 WEST_OPEN_SHAPE = class_259.method_17786(
            WEST_BACK_PANEL_SHAPE,
            class_2248.method_9541(4, 0, 0, 16, 16, 1),
            class_2248.method_9541(4, 0, 15, 16, 16, 16),
            class_2248.method_9541(4, 0, 0, 16, 1, 16),
            class_2248.method_9541(4, 15, 0, 16, 16, 16)
    );
    private static final class_265 EAST_OPEN_SHAPE = class_259.method_17786(
            EAST_BACK_PANEL_SHAPE,
            class_2248.method_9541(0, 0, 0, 12, 16, 1),
            class_2248.method_9541(0, 0, 15, 12, 16, 16),
            class_2248.method_9541(0, 0, 0, 12, 1, 16),
            class_2248.method_9541(0, 15, 0, 12, 16, 16)
    );

    public GunDisplayCaseBlock() {
        this(class_2251.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_11537).method_9629(0.5F, 1200.0F).method_22488().method_50012(class_3619.field_15971));
    }

    public GunDisplayCaseBlock(class_2251 properties) {
        super(properties);
        method_9590(field_10647.method_11664()
                .method_11657(FACING, class_2350.field_11043)
                .method_11657(LOCKED, true)
                .method_11657(LEFT, false)
                .method_11657(RIGHT, false)
                .method_11657(UP, false)
                .method_11657(DOWN, false));
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, LOCKED, LEFT, RIGHT, UP, DOWN);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new GunDisplayCaseBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 context) {
        class_1937 level = context.method_8045();
        class_2338 pos = context.method_8037();
        class_2350 clickedFace = context.method_8038();
        class_2338 clickedPos = pos.method_10093(clickedFace.method_10153());
        class_2680 clickedState = level.method_8320(clickedPos);
        boolean clickedDisplayCase = clickedState.method_26204() instanceof GunDisplayCaseBlock;
        class_2350 facing = getPlacementFacing(context, clickedState, clickedDisplayCase);
        class_2680 state = method_9564().method_11657(FACING, facing);
        if (context.method_8046()) {
            return state;
        }
        Set<class_2338> forceConnectedPositions = clickedDisplayCase ? collectConnectedCases(level, clickedPos, facing) : null;
        return updateConnections(level, pos, state, forceConnectedPositions);
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 facingState, class_1936 level, class_2338 currentPos, class_2338 facingPos) {
        class_2746 property = propertyForDirection(state.method_11654(FACING), direction);
        if (property != null && state.method_11654(property) && !connectsTo(state, facingState)) {
            return state.method_11657(property, false);
        }
        return state;
    }

    @Override
    public void method_9615(class_2680 state, class_1937 level, class_2338 pos, class_2680 oldState, boolean movedByPiston) {
        super.method_9615(state, level, pos, oldState, movedByPiston);
        if (!level.method_8608() && !oldState.method_27852(state.method_26204())) {
            syncConnectedNeighbors(level, pos, state);
        }
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_1269 result = interact(state, level, pos, player, hand, hit);
        return switch (result) {
            case field_5812, field_51370 -> class_9062.field_47728;
            case field_21466 -> class_9062.field_47729;
            case field_33562 -> class_9062.field_47730;
            case field_5814 -> class_9062.field_47733;
            default -> class_9062.field_47731;
        };
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hit) {
        return interact(state, level, pos, player, class_1268.field_5808, hit);
    }

    private class_1269 interact(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_1799 held = player.method_5998(hand);
        boolean holdingGun = held.method_7909() instanceof IGun;
        if (player.method_5715()) {
            if (player.method_6047().method_7909() instanceof IGun) {
                return class_1269.field_5811;
            }
            toggleLockFromInteraction(level, pos, state);
            return class_1269.method_29236(level.method_8608());
        }
        if (state.method_11654(LOCKED)) {
            return held.method_7960() || holdingGun ? class_1269.method_29236(level.method_8608()) : class_1269.field_5811;
        }

        int slot = GunDisplayCaseSlotHelper.getSlot(state, pos, hit.method_17784());
        if (slot < 0) {
            return class_1269.field_5811;
        }
        class_2586 blockEntity = level.method_8321(pos);
        if (!(blockEntity instanceof GunDisplayCaseBlockEntity displayCase)) {
            return class_1269.field_5811;
        }
        if (level.method_8608()) {
            return class_1269.field_5812;
        }

        class_1799 stored = displayCase.getItem(slot);
        if (stored.method_7960()) {
            if (!held.method_7960() && GunPegboardItemConfigRead.canPlace(held) && displayCase.setItem(slot, held)) {
                if (!player.method_31549().field_7477) {
                    held.method_7934(1);
                }
                level.method_8396(null, pos, class_3417.field_14667, class_3419.field_15245, 1.0F, 1.0F);
                return class_1269.field_21466;
            }
            return held.method_7960() ? class_1269.field_21466 : class_1269.field_5811;
        }

        if (displayCase.rotateItem(slot)) {
            level.method_8396(null, pos, class_3417.field_15038, class_3419.field_15245, 1.0F, 1.0F);
            return class_1269.field_21466;
        }
        return class_1269.field_5811;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        if (state.method_11654(LOCKED)) {
            return switch (state.method_11654(FACING)) {
                case field_11035 -> SOUTH_LOCKED_SHAPE;
                case field_11039 -> WEST_LOCKED_SHAPE;
                case field_11034 -> EAST_LOCKED_SHAPE;
                case field_11043 -> NORTH_LOCKED_SHAPE;
                default -> class_259.method_1077();
            };
        }
        return switch (state.method_11654(FACING)) {
            case field_11035 -> SOUTH_BACK_PANEL_SHAPE;
            case field_11039 -> WEST_BACK_PANEL_SHAPE;
            case field_11034 -> EAST_BACK_PANEL_SHAPE;
            case field_11043 -> NORTH_BACK_PANEL_SHAPE;
            default -> class_259.method_1077();
        };
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        if (state.method_11654(LOCKED)) {
            return method_9530(state, level, pos, context);
        }
        return switch (state.method_11654(FACING)) {
            case field_11035 -> SOUTH_OPEN_SHAPE;
            case field_11039 -> WEST_OPEN_SHAPE;
            case field_11034 -> EAST_OPEN_SHAPE;
            case field_11043 -> NORTH_OPEN_SHAPE;
            default -> class_259.method_1077();
        };
    }

    @Override
    public void method_9536(class_2680 oldState, class_1937 level, class_2338 pos, class_2680 newState, boolean movedByPiston) {
        if (!oldState.method_27852(newState.method_26204())) {
            class_2586 blockEntity = level.method_8321(pos);
            if (blockEntity instanceof GunDisplayCaseBlockEntity displayCase) {
                displayCase.dropAllItems();
            }
        }
        super.method_9536(oldState, level, pos, newState, movedByPiston);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    private class_2680 updateConnections(class_1936 level, class_2338 pos, class_2680 state, @Nullable Set<class_2338> forceConnectedPositions) {
        class_2350 facing = state.method_11654(FACING);
        return state
                .method_11657(LEFT, shouldAutoConnectTo(level, pos, state, leftOf(facing), forceConnectedPositions))
                .method_11657(RIGHT, shouldAutoConnectTo(level, pos, state, rightOf(facing), forceConnectedPositions))
                .method_11657(UP, shouldAutoConnectTo(level, pos, state, class_2350.field_11036, forceConnectedPositions))
                .method_11657(DOWN, shouldAutoConnectTo(level, pos, state, class_2350.field_11033, forceConnectedPositions));
    }

    private static class_2350 getPlacementFacing(class_1750 context, class_2680 clickedState, boolean clickedDisplayCase) {
        if (clickedDisplayCase) {
            return clickedState.method_11654(FACING);
        }
        class_2350 clickedFace = context.method_8038();
        return clickedFace.method_10166() == class_2350.class_2351.field_11052 ? context.method_8042().method_10153() : clickedFace;
    }

    private static boolean shouldAutoConnectTo(class_1936 level, class_2338 pos, class_2680 state, class_2350 direction, @Nullable Set<class_2338> forceConnectedPositions) {
        class_2338 neighborPos = pos.method_10093(direction);
        class_2680 neighborState = level.method_8320(neighborPos);
        if (!connectsTo(state, neighborState)) {
            return false;
        }
        if (forceConnectedPositions != null && forceConnectedPositions.contains(neighborPos)) {
            return true;
        }
        class_2746 neighborProperty = propertyForDirection(neighborState.method_11654(FACING), direction.method_10153());
        return neighborProperty != null && neighborState.method_11654(neighborProperty);
    }

    private static Set<class_2338> collectConnectedCases(class_1936 level, class_2338 start, class_2350 facing) {
        ArrayDeque<class_2338> queue = new ArrayDeque<>();
        Set<class_2338> checked = new HashSet<>();
        Set<class_2338> connected = new HashSet<>();
        queue.add(start);
        while (!queue.isEmpty() && checked.size() < MAX_GROUP_TOGGLE) {
            class_2338 pos = queue.removeFirst();
            if (!checked.add(pos)) {
                continue;
            }
            class_2680 state = level.method_8320(pos);
            if (!(state.method_26204() instanceof GunDisplayCaseBlock) || state.method_11654(FACING) != facing) {
                continue;
            }
            connected.add(pos);
            queueConnectedCases(queue, pos, state, facing);
        }
        return connected;
    }

    private static void syncConnectedNeighbors(class_1937 level, class_2338 pos, class_2680 state) {
        class_2350 facing = state.method_11654(FACING);
        syncConnectedNeighbor(level, pos, state, leftOf(facing), LEFT);
        syncConnectedNeighbor(level, pos, state, rightOf(facing), RIGHT);
        syncConnectedNeighbor(level, pos, state, class_2350.field_11036, UP);
        syncConnectedNeighbor(level, pos, state, class_2350.field_11033, DOWN);
    }

    private static void syncConnectedNeighbor(class_1937 level, class_2338 pos, class_2680 state, class_2350 direction, class_2746 property) {
        if (!state.method_11654(property)) {
            return;
        }
        class_2338 neighborPos = pos.method_10093(direction);
        class_2680 neighborState = level.method_8320(neighborPos);
        if (!connectsTo(state, neighborState)) {
            return;
        }
        class_2746 neighborProperty = propertyForDirection(neighborState.method_11654(FACING), direction.method_10153());
        if (neighborProperty != null && !neighborState.method_11654(neighborProperty)) {
            level.method_8652(neighborPos, neighborState.method_11657(neighborProperty, true), LOCK_UPDATE_FLAGS);
        }
    }

    private static boolean connectsTo(class_2680 state, class_2680 neighbor) {
        return neighbor.method_26204() instanceof GunDisplayCaseBlock && neighbor.method_11654(FACING) == state.method_11654(FACING);
    }

    private static class_2746 propertyForDirection(class_2350 facing, class_2350 direction) {
        if (direction == class_2350.field_11036) {
            return UP;
        }
        if (direction == class_2350.field_11033) {
            return DOWN;
        }
        if (direction == leftOf(facing)) {
            return LEFT;
        }
        if (direction == rightOf(facing)) {
            return RIGHT;
        }
        return null;
    }

    private static class_2350 leftOf(class_2350 facing) {
        return facing.method_10160();
    }

    private static class_2350 rightOf(class_2350 facing) {
        return facing.method_10170();
    }

    public void toggleLockFromInteraction(class_1937 level, class_2338 pos, class_2680 state) {
        if (level.method_8608()) {
            return;
        }
        toggleLinkedCases(level, pos, !state.method_11654(LOCKED));
        level.method_8396(null, pos, class_3417.field_14567, class_3419.field_15245, 0.8F, state.method_11654(LOCKED) ? 1.1F : 0.9F);
    }

    private void toggleLinkedCases(class_1937 level, class_2338 start, boolean locked) {
        class_2680 startState = level.method_8320(start);
        if (!(startState.method_26204() instanceof GunDisplayCaseBlock)) {
            return;
        }
        class_2350 facing = startState.method_11654(FACING);
        ArrayDeque<class_2338> queue = new ArrayDeque<>();
        Set<class_2338> visited = new HashSet<>();
        queue.add(start);
        while (!queue.isEmpty() && visited.size() < MAX_GROUP_TOGGLE) {
            class_2338 pos = queue.removeFirst();
            if (!visited.add(pos)) {
                continue;
            }
            class_2680 state = level.method_8320(pos);
            if (!(state.method_26204() instanceof GunDisplayCaseBlock) || state.method_11654(FACING) != facing) {
                continue;
            }
            if (state.method_11654(LOCKED) != locked) {
                level.method_8652(pos, state.method_11657(LOCKED, locked), LOCK_UPDATE_FLAGS);
            }
            queueConnectedCases(queue, pos, state, facing);
        }
    }

    private static void queueConnectedCases(ArrayDeque<class_2338> queue, class_2338 pos, class_2680 state, class_2350 facing) {
        if (state.method_11654(LEFT)) {
            queue.add(pos.method_10093(leftOf(facing)));
        }
        if (state.method_11654(RIGHT)) {
            queue.add(pos.method_10093(rightOf(facing)));
        }
        if (state.method_11654(UP)) {
            queue.add(pos.method_10084());
        }
        if (state.method_11654(DOWN)) {
            queue.add(pos.method_10074());
        }
    }
}
