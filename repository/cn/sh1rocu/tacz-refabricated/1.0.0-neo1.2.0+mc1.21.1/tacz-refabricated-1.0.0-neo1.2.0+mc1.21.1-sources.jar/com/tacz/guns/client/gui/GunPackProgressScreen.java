package com.tacz.guns.client.gui;

import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_333;
import net.minecraft.class_3536;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;

public class GunPackProgressScreen extends class_437 implements class_3536 {
    private @Nullable class_2561 header;
    private @Nullable class_2561 stage;
    private int progress;
    private boolean stop;

    public GunPackProgressScreen() {
        super(class_333.field_18967);
    }

    @Override
    protected void method_25426() {
        class_4185 button = class_4185.method_46430(
                class_2561.method_43471("gui.tacz.client_gun_pack_downloader.background_download"), b -> this.method_15411()
        ).method_46434((field_22789 - 200) / 2, 120, 200, 20).method_46431();
        this.method_37063(button);
    }

    @Override
    public void method_25394(@NotNull class_332 gui, int mouseX, int mouseY, float partialTick) {
        if (this.stop) {
            Screens.getClient(this).method_1507(null);
        } else {
            this.method_25420(gui, mouseX, mouseY, partialTick);
            if (this.header != null) {
                gui.method_27534(this.field_22793, this.header, this.field_22789 / 2, 70, 16777215);
            }
            if (this.stage != null && this.progress > 0) {
                class_5250 text = this.stage.method_27661().method_27693(" " + this.progress + "%");
                gui.method_27534(this.field_22793, text, this.field_22789 / 2, 90, 16777215);
            }
            super.method_25394(gui, mouseX, mouseY, partialTick);
        }
    }


    @Override
    public void method_15412(class_2561 component) {
        this.method_15413(component);
    }

    @Override
    public void method_15413(class_2561 header) {
        this.header = class_2561.method_43471("gui.tacz.client_gun_pack_downloader.downloading");
    }

    @Override
    public void method_15414(class_2561 component) {
        this.stage = component;
        this.method_15410(0);
    }

    @Override
    public void method_15410(int progress) {
        this.progress = progress;
    }

    @Override
    public void method_15411() {
        this.stop = true;
    }
}
