package com.tacz.guns.client.gui.overlay;

import com.mojang.blaze3d.systems.RenderSystem;
import com.tacz.guns.api.client.gameplay.IClientPlayerGunOperator;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.config.client.RenderConfig;
import com.tacz.guns.util.time.GunTime;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.class_9080;
import net.minecraft.class_9779;
import org.jetbrains.annotations.NotNull;

public class KillAmountOverlay implements class_9080.class_9081 {
    private static long killTimestamp = -1L;
    private static int killAmount = 0;

    public static final KillAmountOverlay INSTANCE = new KillAmountOverlay();

    @Override
    public void render(class_332 graphics, @NotNull class_9779 deltaTracker) {
        int width = graphics.method_51421();
        int height = graphics.method_51443();

        if (!RenderConfig.KILL_AMOUNT_ENABLE.get()) {
            return;
        }
        int timeout = (int) (RenderConfig.KILL_AMOUNT_DURATION_SECOND.get() * 1000);
        float colorCount = 30;

        long remainTime = GunTime.nowMillis() - killTimestamp;
        if (!GunTime.isWithin(killTimestamp, timeout)) {
            return;
        }
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (!(player instanceof IClientPlayerGunOperator) || player.method_7325()) {
            return;
        }
        class_1799 stack = player.method_6047();
        if (!(stack.method_7909() instanceof IGun)) {
            return;
        }

        String text;
        if (killAmount < 10) {
            text = "\u2620 x 0" + killAmount;
        } else {
            text = "\u2620 x " + killAmount;
        }
        int fontWith = mc.field_1772.method_1727(text);
        double fadeOutTime = timeout / 3.0 * 2;
        float hue = (1 - Math.min((killAmount / colorCount), 1)) * 0.15f;
        int alpha = 0xFF;
        if (remainTime > fadeOutTime) {
            alpha = 0xFF - (int) ((remainTime - fadeOutTime) / (timeout - fadeOutTime) * 0xF0);
        }
        int color = class_3532.method_15369(hue, 0.75f, 1) + (alpha << 24);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        class_4587 poseStack = graphics.method_51448();

        poseStack.method_22903();
        {
            poseStack.method_22905(0.5f, 0.5f, 1);
            graphics.method_25303(mc.field_1772, text, (int) (width - fontWith / 2.0f), (height - 45) * 2 - 1, color);
        }
        poseStack.method_22909();
        RenderSystem.disableBlend();
    }

    public static void markTimestamp() {
        int timeout = (int) (RenderConfig.KILL_AMOUNT_DURATION_SECOND.get() * 1000);
        if (!GunTime.isWithin(killTimestamp, timeout)) {
            killAmount = 0;
        }
        killTimestamp = GunTime.nowMillis();
        killAmount += 1;
    }

    public static void resetTimestamp() {
        killTimestamp = -1L;
        killAmount = 0;
    }
}
