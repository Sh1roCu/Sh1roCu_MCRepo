package com.tacz.guns.client.model.functional;

import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.item.IAttachment;
import com.tacz.guns.api.item.attachment.AttachmentType;
import com.tacz.guns.client.model.BedrockAttachmentModel;
import com.tacz.guns.client.model.BedrockGunModel;
import com.tacz.guns.client.model.IFunctionalRenderer;
import com.tacz.guns.client.renderer.item.AttachmentItemRenderer;
import com.tacz.guns.client.renderer.item.ItemPreviewRenderContext;
import com.tacz.guns.client.resource.index.ClientAttachmentVariantIndex;
import com.tacz.guns.client.resource.index.ClientSlotAdapterIndex;
import com.tacz.guns.util.RenderDistance;
import com.tacz.guns.util.RenderHelper;
import com.tacz.guns.util.SlotAdapterHelper;
import org.apache.commons.lang3.tuple.Pair;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import javax.annotation.Nullable;
import net.minecraft.class_1047;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_811;
import java.util.EnumMap;
import java.util.function.Consumer;

public class AttachmentRender implements IFunctionalRenderer {
    private final BedrockGunModel bedrockGunModel;
    private final AttachmentType type;

    public AttachmentRender(BedrockGunModel bedrockGunModel, AttachmentType type) {
        this.bedrockGunModel = bedrockGunModel;
        this.type = type;
    }

    /**
     * 旧入口在光影手部 pass 中选择 hand buffer；内部调用优先显式传递 bufferSource。
     */
    public static void renderAttachment(class_1799 attachmentItem, class_1799 gunItem, AttachmentType type, class_4587 poseStack, class_811 transformType, int light, int overlay) {
        renderAttachment(attachmentItem, gunItem, type, poseStack, transformType, light, overlay, RenderHelper.getBufferSource(transformType));
    }

    public static void renderAttachment(class_1799 attachmentItem, class_1799 gunItem, AttachmentType type, class_4587 poseStack, class_811 transformType, int light, int overlay, class_4597 bufferSource) {
        renderAttachment(attachmentItem, gunItem, type, poseStack, transformType, light, overlay, bufferSource, null);
    }

    /**
     * 瞄具的槽位转接器可延后到枪体的模板测试窗口绘制，同时继承 AR 枪体层的模板设置。
     */
    public static void renderAttachment(class_1799 attachmentItem, class_1799 gunItem, AttachmentType type, class_4587 poseStack, class_811 transformType, int light, int overlay, class_4597 bufferSource, @Nullable Consumer<IFunctionalRenderer> deferredSlotAdapters) {
        if (attachmentItem.method_7960()) {
            return;
        }
        poseStack.method_22904(0, -1.5, 0);
        if (attachmentItem.method_7909() instanceof IAttachment iAttachment) {
            class_2960 attachmentId = iAttachment.getAttachmentId(attachmentItem);
            TimelessAPI.getClientAttachmentIndex(attachmentId).ifPresentOrElse(attachmentIndex -> {
                BedrockAttachmentModel model = attachmentIndex.getAttachmentModel();
                class_2960 texture = attachmentIndex.getModelTexture();
                ClientAttachmentVariantIndex variant = TimelessAPI.getClientAttachmentVariantIndex(attachmentItem).orElse(null);
                if (variant != null && variant.isReplaceMode() && variant.getAttachmentModel() != null && variant.getModelTexture() != null) {
                    model = variant.getAttachmentModel();
                    texture = variant.getModelTexture();
                }
                ClientSlotAdapterIndex slotAdapter = getSlotAdapter(gunItem, type, attachmentId);
                if (slotAdapter != null) {
                    // 我真受不了这个傻逼function renderer了。。只能先这样了
                    if (deferredSlotAdapters != null && transformType.method_29998() && attachmentIndex.isScope()) {
                        class_4587 adapterPose = new class_4587();
                        adapterPose.method_23760().method_23761().set(poseStack.method_23760().method_23761());
                        adapterPose.method_23760().method_23762().set(poseStack.method_23760().method_23762());
                        deferredSlotAdapters.accept((stack, consumer, context, packedLight, packedOverlay) ->
                                renderSlotAdapter(slotAdapter, gunItem, adapterPose, context, packedLight, packedOverlay, bufferSource));
                    } else {
                        poseStack.method_22903();
                        renderSlotAdapter(slotAdapter, gunItem, poseStack, transformType, light, overlay, bufferSource);
                        poseStack.method_22909();
                    }
                    applyMountOffset(poseStack, slotAdapter.getMountOffset());
                }
                if (variant != null && variant.isOverlayMode()) {
                    renderVariantOverlay(variant, attachmentItem, gunItem, poseStack, transformType, light, overlay, bufferSource);
                    applyMountOffset(poseStack, variant.getMountOffset());
                }
                // 这里是枪械里的配件渲染，没有模型材质就不渲染
                if (model != null && texture != null) {
                    // 调用低模
                    Pair<BedrockAttachmentModel, class_2960> lodModel = attachmentIndex.getLodModel();
                    // 有低模、在高模渲染范围外、不是第一人称
                    if (lodModel != null && !RenderDistance.inRenderHighPolyModelDistance(poseStack) && !transformType.method_29998()) {
                        model = lodModel.getLeft();
                        texture = lodModel.getRight();
                    }
                    float alpha = ItemPreviewRenderContext.alpha();
                    class_1921 renderType = ItemPreviewRenderContext.isPreview() ? class_1921.method_23580(texture) : class_1921.method_23576(texture);
                    model.render(attachmentItem, gunItem, poseStack, transformType, renderType, light, overlay, alpha, bufferSource);
                }
            }, () -> {
                // 没有对应的 attachmentIndex，渲染黑紫材质以提醒
                class_4588 buffer = bufferSource.getBuffer(class_1921.method_23580(class_1047.method_4539()));
                AttachmentItemRenderer.SLOT_ATTACHMENT_MODEL.method_2828(poseStack, buffer, light, overlay, net.minecraft.class_5253.class_5254.method_27764((int)(255 * ItemPreviewRenderContext.alpha()), 255, 255, 255));
            });
        }
    }

    private static ClientSlotAdapterIndex getSlotAdapter(class_1799 gunItem, AttachmentType type, class_2960 attachmentId) {
        class_2960 adapterId = SlotAdapterHelper.getEffectiveSlotAdapter(gunItem, type, attachmentId);
        return adapterId == null ? null : TimelessAPI.getClientSlotAdapterIndex(adapterId).orElse(null);
    }

    private static void renderSlotAdapter(ClientSlotAdapterIndex adapter, class_1799 gunItem, class_4587 poseStack, class_811 transformType, int light, int overlay, class_4597 bufferSource) {
        BedrockAttachmentModel model = adapter.getAdapterModel();
        class_2960 texture = adapter.getModelTexture();
        if (model == null || texture == null) {
            return;
        }
        float alpha = ItemPreviewRenderContext.alpha();
        class_1921 renderType = ItemPreviewRenderContext.isPreview() ? class_1921.method_23580(texture) : class_1921.method_23576(texture);
        model.render(class_1799.field_8037, gunItem, poseStack, transformType, renderType, light, overlay, alpha, bufferSource);
    }

    private static void applyMountOffset(class_4587 poseStack, Vector3f offset) {
        if (offset != null) {
            poseStack.method_46416(offset.x() / 16.0F, -offset.y() / 16.0F, offset.z() / 16.0F);
        }
    }

    private static void renderVariantOverlay(ClientAttachmentVariantIndex variant, class_1799 attachmentItem, class_1799 gunItem, class_4587 poseStack, class_811 transformType, int light, int overlay, class_4597 bufferSource) {
        BedrockAttachmentModel model = variant.getAttachmentModel();
        class_2960 texture = variant.getModelTexture();
        if (model == null || texture == null) {
            return;
        }
        float alpha = ItemPreviewRenderContext.alpha();
        class_1921 renderType = ItemPreviewRenderContext.isPreview() ? class_1921.method_23580(texture) : class_1921.method_23576(texture);
        model.render(attachmentItem, gunItem, poseStack, transformType, renderType, light, overlay, alpha, bufferSource);
    }

    @Override
    public void render(class_4587 poseStack, class_4588 vertexBuffer, class_811 transformType, int light, int overlay) {
        render(poseStack, vertexBuffer, transformType, light, overlay, RenderHelper.getBufferSource(transformType));
    }

    @Override
    public void render(class_4587 poseStack, class_4588 vertexBuffer, class_811 transformType, int light, int overlay, class_4597 bufferSource) {
        EnumMap<AttachmentType, class_1799> currentAttachmentItem = bedrockGunModel.getCurrentAttachmentItem();
        class_1799 attachmentItem = currentAttachmentItem.get(type);
        if (attachmentItem != null && !attachmentItem.method_7960()) {
            Matrix3f normal = new Matrix3f(poseStack.method_23760().method_23762());
            Matrix4f pose = new Matrix4f(poseStack.method_23760().method_23761());
            //和枪械模型共用顶点缓冲的都需要代理到渲染结束后渲染
            bedrockGunModel.delegateRender((poseStack1, vertexBuffer1, transformType1, light1, overlay1) -> {
                class_4587 poseStack2 = new class_4587();
                poseStack2.method_23760().method_23762().mul(normal);
                poseStack2.method_23760().method_23761().mul(pose);
                // 渲染配件
                renderAttachment(attachmentItem, bedrockGunModel.getCurrentGunItem(), type, poseStack2, transformType, light, overlay, bufferSource);
            });
        }
    }
}