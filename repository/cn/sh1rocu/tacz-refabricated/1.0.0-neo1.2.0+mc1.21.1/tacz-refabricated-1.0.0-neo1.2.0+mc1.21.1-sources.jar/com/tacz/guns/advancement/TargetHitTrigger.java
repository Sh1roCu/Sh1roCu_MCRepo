package com.tacz.guns.advancement;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.class_2048;
import net.minecraft.class_2096;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;

public class TargetHitTrigger extends class_4558<TargetHitTrigger.TriggerInstance> {
    public static final TargetHitTrigger INSTANCE = new TargetHitTrigger();

    @Override
    public Codec<TriggerInstance> method_54937() {
        return TriggerInstance.CODEC;
    }

    public void trigger(class_3222 player, double distance) {
        this.method_22510(player, instance -> instance.distance().method_9047(distance));
    }

    public record TriggerInstance(Optional<class_5258> player,
                                  class_2096.class_2099 distance) implements class_4558.class_8788 {
        public static final Codec<TriggerInstance> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                class_2048.field_47250.optionalFieldOf("player").forGetter(TriggerInstance::comp_2029),
                class_2096.class_2099.field_45762.optionalFieldOf("distance", class_2096.class_2099.field_9705).forGetter(TriggerInstance::distance)).apply(instance, TriggerInstance::new));
    }
}