package com.tacz.guns.block.entity;

import com.tacz.guns.block.GunDisplayCaseBlock;
import com.tacz.guns.init.ModBlocks;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

public class GunDisplayCaseBlockEntity extends class_2586 implements GunDisplayBlockEntity {
    public static final int GRID_SIZE = 4;
    public static final int SLOT_COUNT = GRID_SIZE * GRID_SIZE;
    public static final class_2591<GunDisplayCaseBlockEntity> TYPE = class_2591.class_2592.method_20528(GunDisplayCaseBlockEntity::new, ModBlocks.GUN_DISPLAY_CASE).method_11034(null);
    private static final String ITEMS_TAG = "Items";
    private static final String SLOT_TAG = "Slot";
    private static final String ITEM_TAG = "Item";
    private static final String ROTATIONS_TAG = "Rotations";

    private final class_1799[] items = new class_1799[SLOT_COUNT];
    private final byte[] rotations = new byte[SLOT_COUNT];
    private final DisplayGunSlot[] displaySlots = new DisplayGunSlot[SLOT_COUNT];

    public GunDisplayCaseBlockEntity(class_2338 pos, class_2680 state) {
        super(TYPE, pos, state);
        for (int i = 0; i < items.length; i++) {
            items[i] = class_1799.field_8037;
        }
    }

    @Override
    public class_1799 getItem(int slot) {
        return isValidSlot(slot) ? items[slot] : class_1799.field_8037;
    }

    @Override
    public int getRotation(int slot) {
        return isValidSlot(slot) ? rotations[slot] & 7 : 0;
    }

    @Override
    public DisplayGunSlot getDisplaySlot(int slot) {
        if (!isValidSlot(slot)) throw new IndexOutOfBoundsException(slot);
        DisplayGunSlot handle = displaySlots[slot];
        if (handle == null) displaySlots[slot] = handle = new DisplayGunSlot(this, slot);
        return handle;
    }

    @Override
    public int getGridSize() {
        return GRID_SIZE;
    }

    @Override
    public class_2350 getSlotFacing(int slot) {
        return method_11010().method_11654(GunDisplayCaseBlock.FACING);
    }

    @Override
    public boolean isDisplayGlowing() {
        return true;
    }

    @Override
    public class_2586 getBlockEntity() {
        return this;
    }

    private void displaySlotChanged(int slot) {
        if (displaySlots[slot] != null) displaySlots[slot].changed();
    }

    public boolean setItem(int slot, class_1799 stack) {
        if (!isValidSlot(slot) || !items[slot].method_7960()) {
            return false;
        }
        class_1799 stored = stack.method_7972();
        stored.method_7939(1);
        items[slot] = stored;
        rotations[slot] = 0;
        displaySlotChanged(slot);
        update();
        return true;
    }

    public boolean rotateItem(int slot) {
        if (!isValidSlot(slot) || items[slot].method_7960()) {
            return false;
        }
        rotations[slot] = (byte) ((rotations[slot] + 1) & 7);
        if (displaySlots[slot] != null) displaySlots[slot].transformed();
        update();
        return true;
    }

    public boolean dropItem(int slot) {
        if (!isValidSlot(slot) || items[slot].method_7960() || field_11863 == null) {
            return false;
        }
        class_2350 facing = method_11010().method_11654(GunDisplayCaseBlock.FACING);
        class_2248.method_9577(field_11863, field_11867.method_10093(facing), items[slot]);
        items[slot] = class_1799.field_8037;
        rotations[slot] = 0;
        displaySlotChanged(slot);
        update();
        return true;
    }

    public boolean removeItem(int slot) {
        if (!isValidSlot(slot) || items[slot].method_7960()) {
            return false;
        }
        items[slot] = class_1799.field_8037;
        rotations[slot] = 0;
        displaySlotChanged(slot);
        update();
        return true;
    }

    public void dropAllItems() {
        if (field_11863 == null) {
            return;
        }
        class_2350 facing = method_11010().method_11654(GunDisplayCaseBlock.FACING);
        for (int i = 0; i < SLOT_COUNT; i++) {
            if (!items[i].method_7960()) {
                class_2248.method_9577(field_11863, field_11867.method_10093(facing), items[i]);
                items[i] = class_1799.field_8037;
                rotations[i] = 0;
                displaySlotChanged(i);
            }
        }
        update();
    }

    private void update() {
        method_5431();
        if (field_11863 != null) {
            class_2680 state = method_11010();
            field_11863.method_8413(field_11867, state, state, class_2248.field_31036);
        }
    }

    private static boolean isValidSlot(int slot) {
        return slot >= 0 && slot < SLOT_COUNT;
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        class_1799[] previousItems = items.clone();
        byte[] previousRotations = rotations.clone();
        for (int i = 0; i < items.length; i++) {
            items[i] = class_1799.field_8037;
            rotations[i] = 0;
        }
        if (tag.method_10573(ITEMS_TAG, class_2520.field_33259)) {
            class_2499 list = tag.method_10554(ITEMS_TAG, class_2520.field_33260);
            for (int i = 0; i < list.size(); i++) {
                class_2487 entry = list.method_10602(i);
                int slot = entry.method_10571(SLOT_TAG) & 255;
                if (isValidSlot(slot) && entry.method_10573(ITEM_TAG, class_2520.field_33260)) {
                    items[slot] = class_1799.method_57359(registries, entry.method_10562(ITEM_TAG));
                }
            }
        }
        if (tag.method_10573(ROTATIONS_TAG, class_2520.field_33257)) {
            byte[] saved = tag.method_10547(ROTATIONS_TAG);
            System.arraycopy(saved, 0, rotations, 0, Math.min(saved.length, rotations.length));
        }
        for (int i = 0; i < displaySlots.length; i++) {
            DisplayGunSlot handle = displaySlots[i];
            if (handle == null) continue;
            if (!class_1799.method_7973(previousItems[i], items[i])) handle.changed();
            else if (previousRotations[i] != rotations[i]) handle.transformed();
        }
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11007(tag, registries);
        class_2499 list = new class_2499();
        for (int i = 0; i < items.length; i++) {
            if (!items[i].method_7960()) {
                class_2487 entry = new class_2487();
                entry.method_10567(SLOT_TAG, (byte) i);
                entry.method_10566(ITEM_TAG, items[i].method_57375(registries));
                list.add(entry);
            }
        }
        tag.method_10566(ITEMS_TAG, list);
        tag.method_10570(ROTATIONS_TAG, rotations);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        class_2487 tag = super.method_16887(registries);
        method_11007(tag, registries);
        return tag;
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    public class_238 getDisplayRenderBoundingBox() {
        return new class_238(net.minecraft.class_243.method_24954(field_11867.method_10069(-2, -2, -2)), net.minecraft.class_243.method_24954(field_11867.method_10069(3, 3, 3)));
    }
}
