package com.tacz.guns.client.gameplay;

import cn.sh1rocu.tacz.api.LogicalSide;
import com.tacz.guns.api.TimelessAPI;
import com.tacz.guns.api.event.common.GunDrawEvent;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.client.renderer.item.AnimateGeoItemRenderer;
import com.tacz.guns.client.sound.SoundPlayManager;
import com.tacz.guns.network.message.ClientMessagePlayerDrawGun;
import com.tacz.guns.resource.modifier.AttachmentPropertyManager;
import com.tacz.guns.util.time.GunTime;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class LocalPlayerDraw {
    private final LocalPlayerDataHolder data;
    private final class_746 player;
    public boolean readyToDraw = false;

    public LocalPlayerDraw(LocalPlayerDataHolder data, class_746 player) {
        this.data = data;
        this.player = player;
    }

    public void draw(class_1799 lastItem) {
        // 重置各种参数
        this.resetData();

        // 获取各种数据
        class_1799 currentItem = player.method_6047();
        long drawTime = GunTime.nowMillis() - data.clientDrawTimestamp;
        IGun currentGun = IGun.getIGunOrNull(currentItem);
        IGun lastGun = IGun.getIGunOrNull(lastItem);

        // 计算 draw 时长和 putAway 时长
        if (drawTime >= 0) {
            drawTime = getDrawTime(lastItem, lastGun, drawTime);
        }
        long putAwayTime = Math.abs(drawTime);

        // 发包通知服务器
        if (class_310.method_1551().field_1761 != null) {
            class_310.method_1551().field_1761.method_2911();
        }
        ClientPlayNetworking.send(ClientMessagePlayerDrawGun.INSTANCE);
        GunDrawEvent.CALLBACK.invoker().post(new GunDrawEvent(player, lastItem, currentItem, LogicalSide.CLIENT));

//        // 不处于收枪状态时才能收枪
//        if (drawTime >= 0) {
//            doPutAway(lastItem, putAwayTime);
//        }

        // 异步放映抬枪动画
        if (currentGun != null) {
            doDraw(currentItem, putAwayTime);
            // 刷新配件数据
            AttachmentPropertyManager.postChangeEvent(player, currentItem);
        }
    }

    private void doDraw(class_1799 currentItem, long putAwayTime) {
        TimelessAPI.getGunDisplay(currentItem).ifPresent(display -> {
            // 取消预定中的 draw 行为
            if (data.drawFuture != null) {
                data.drawFuture.cancel(false);
            }
            // 根据 put away time 预定 draw 行为（仅播放音效，状态机的初始化为了保证一致性已经移动）
//            data.drawFuture = LocalPlayerDataHolder.SCHEDULED_EXECUTOR_SERVICE.schedule(() -> {
//                ((BlockableEventLoopAccessor) Minecraft.getInstance()).tacz$submitAsync(() -> {
//                    SoundPlayManager.stopPlayGunSound();
//                    SoundPlayManager.playDrawSound(player, display);
//                });
//            }, putAwayTime, TimeUnit.MILLISECONDS);
        });
    }

    private void doPutAway(class_1799 lastItem, long putAwayTime) {
        if (BuiltinItemRendererRegistry.INSTANCE.get(lastItem.method_7909()) instanceof AnimateGeoItemRenderer<?, ?> renderer) {
            renderer.tryExit(lastItem, putAwayTime);
            TimelessAPI.getGunDisplay(lastItem).ifPresent(display -> {
                SoundPlayManager.stopPlayGunSound();
                SoundPlayManager.playPutAwaySound(player, display);
            });
        }
    }

    private long getDrawTime(class_1799 lastItem, IGun lastGun, long drawTime) {
        if (BuiltinItemRendererRegistry.INSTANCE.get(lastItem.method_7909()) instanceof AnimateGeoItemRenderer<?, ?> renderer) {
            long putAwayTime = renderer.getPutAwayTime(lastItem);
            if (drawTime > putAwayTime) {
                drawTime = putAwayTime;
            }
            data.clientDrawTimestamp = GunTime.nowMillis() + drawTime;
        } else {
            drawTime = 0;
            data.clientDrawTimestamp = GunTime.nowMillis();
        }
        return drawTime;
    }

    private void resetData() {
        data.autoReloadSuppressed = false;
        // 锁上状态锁
        data.lockState(operator -> operator.getSynDrawCoolDown() > 0);
        // 重置客户端的 shoot 时间戳
        data.isShootRecorded = true;
        data.clientShootTimestamp = -1;
        data.chargeProgress = 0;
        data.isCharging = false;
        // 重置客户端瞄准状态
        data.clientIsAiming = false;
        data.clientAimingProgress = 0;
        LocalPlayerDataHolder.oldAimingProgress = 0;
        // 重置拉栓状态
        data.isBolting = false;
        data.clientReloadStarting = false;
        // 更新切枪时间戳
        if (data.clientDrawTimestamp == -1) {
            data.clientDrawTimestamp = GunTime.nowMillis();
        }
    }
}
