package com.tacz.guns.client.gui.components.smith;

import com.mojang.blaze3d.systems.RenderSystem;
import com.tacz.guns.GunMod;
import org.jetbrains.annotations.NotNull;

import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public class ResultButton extends class_4185 {
    private static final class_2960 TEXTURE = class_2960.method_60655(GunMod.MOD_ID, "textures/gui/gun_smith_table.png");
    private final class_1799 stack;
    private boolean isSelected = false;

    public ResultButton(int pX, int pY, class_1799 stack, class_4185.class_4241 onPress) {
        super(pX, pY, 94, 16, class_2561.method_43473(), onPress, field_40754);
        this.stack = stack;
    }

    @Override
    protected void method_48579(@NotNull class_332 gui, int pMouseX, int pMouseY, float pPartialTick) {
        RenderSystem.enableDepthTest();

        if (isSelected) {
            if (method_25367()) {
                gui.method_25290(TEXTURE, this.method_46426() - 1, this.method_46427() - 1, 52, 229, this.field_22758 + 2, this.field_22759 + 2, 256, 256);
            } else {
                gui.method_25290(TEXTURE, this.method_46426(), this.method_46427(), 53, 230, this.field_22758, this.field_22759, 256, 256);
            }
        } else {
            if (method_25367()) {
                gui.method_25290(TEXTURE, this.method_46426() - 1, this.method_46427() - 1, 52, 211, this.field_22758 + 2, this.field_22759 + 2, 256, 256);
            } else {
                gui.method_25290(TEXTURE, this.method_46426(), this.method_46427(), 53, 212, this.field_22758, this.field_22759, 256, 256);
            }
        }
        class_310 mc = class_310.method_1551();
        gui.method_51427(stack, this.method_46426() + 1, this.method_46427());

        class_2561 hoverName = this.stack.method_7964();
        method_52718(gui, mc.field_1772, hoverName, this.method_46426() + 20, this.method_46427() + 4, this.method_46426() + 92, this.method_46427() + 13, 0xFFFFFF);
    }

    @Override
    public void method_25306() {
        this.isSelected = true;
        this.field_22767.onPress(this);
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public void renderTooltips(Consumer<class_1799> consumer) {
        if (this.method_25367() && !this.stack.method_7960()) {
            consumer.accept(this.stack);
        }
    }
}
