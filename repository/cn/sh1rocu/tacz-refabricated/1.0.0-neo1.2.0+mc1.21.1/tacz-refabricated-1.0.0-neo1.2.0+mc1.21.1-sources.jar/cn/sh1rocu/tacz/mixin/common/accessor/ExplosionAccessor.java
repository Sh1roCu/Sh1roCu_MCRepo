package cn.sh1rocu.tacz.mixin.common.accessor;

import net.minecraft.class_1282;
import net.minecraft.class_1927;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1927.class)
public interface ExplosionAccessor {
    @Accessor("damageSource")
    class_1282 tacz$getDamageSource();
}
