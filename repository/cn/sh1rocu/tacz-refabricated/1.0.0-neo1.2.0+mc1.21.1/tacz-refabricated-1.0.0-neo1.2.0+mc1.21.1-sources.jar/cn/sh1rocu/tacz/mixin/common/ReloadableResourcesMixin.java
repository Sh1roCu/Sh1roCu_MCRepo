package cn.sh1rocu.tacz.mixin.common;

import cn.sh1rocu.tacz.util.neoforge.EventHooks;
import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.class_2170;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_5350;
import net.minecraft.class_7659;
import net.minecraft.class_7699;
import net.minecraft.class_7780;

@Mixin(class_5350.class)
public abstract class ReloadableResourcesMixin {
    @Unique
    private static class_5350 tacz$serverResources;

    @Inject(method = "method_58296", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/packs/resources/SimpleReloadInstance;create(Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/List;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture;Z)Lnet/minecraft/server/packs/resources/ReloadInstance;", shift = At.Shift.BEFORE))
    private static void tacz$loadResources(CallbackInfoReturnable<CompletableFuture<class_5350>> cir, @Local class_5350 reloadableServerResources) {
        tacz$serverResources = reloadableServerResources;
    }

    @ModifyArg(method = "method_58296", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/packs/resources/SimpleReloadInstance;create(Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/List;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Ljava/util/concurrent/CompletableFuture;Z)Lnet/minecraft/server/packs/resources/ReloadInstance;"))
    private static List<class_3302> tacz$addReloadListener(List<class_3302> original, @Local(argsOnly = true) class_7780<class_7659> registryAccess) {
        ArrayList<class_3302> listeners = new ArrayList<>(original);
        listeners.addAll(EventHooks.onResourceReload(tacz$serverResources, registryAccess.method_45926()));
        return listeners;
    }

    @Inject(method = "loadResources", at = @At(value = "TAIL"))
    private static void tacz$finishedLoadResources(class_3300 resourceManager, class_7780<class_7659> registries, class_7699 enabledFeatures, class_2170.class_5364 commandSelection, int functionCompilationLevel, Executor backgroundExecutor, Executor gameExecutor, CallbackInfoReturnable<CompletableFuture<class_5350>> cir) {
        tacz$serverResources = null;
    }
}