package cn.sh1rocu.tacz.mixin.common;

import cn.sh1rocu.tacz.util.neoforge.EventHooks;
import net.minecraft.class_2535;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_8792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3324.class)
public class PlayerListMixin {
    @Inject(method = "placeNewPlayer", at = @At("TAIL"))
    private void $tacz$placeNewPlayer(class_2535 connection, class_3222 player, class_8792 cookie, CallbackInfo ci) {
        EventHooks.firePlayerLoggedIn(player);
    }

    @Inject(method = "remove", at = @At("HEAD"))
    private void tacz$remove(class_3222 player, CallbackInfo ci) {
        EventHooks.firePlayerLoggedOut(player);
    }
}
