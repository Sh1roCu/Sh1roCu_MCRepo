package cn.sh1rocu.tacz.mixin.compat.tweakeroo;

import net.minecraft.class_1792;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1792.class)
public class ItemMixin {

}
