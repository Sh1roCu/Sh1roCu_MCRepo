package cn.sh1rocu.tacz.mixin.compat.controllable;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.mrcrayfish.controllable.client.binding.context.BindingContext;
import com.tacz.guns.api.item.IGun;
import com.tacz.guns.compat.controllable.ControllableInner;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;

// From TACZ-NeoForge
@Pseudo
@Mixin(value = BindingContext.class, remap = false)
public abstract class BindingContextMixin {
    @ModifyReturnValue(method = "isActive", at = @At("RETURN"))
    private boolean tacz$controllableCompat(boolean original) {
        var instance = BindingContext.class.cast(this);
        if (!(instance instanceof ControllableInner.GunKeyConflict)) return original;
        var player = class_310.method_1551().field_1724;
        if (player == null) return original;
        return original && IGun.mainHandHoldGun(player);
    }
}