package cn.sh1rocu.tacz.api.mixin;

import cn.sh1rocu.tacz.util.neoforge.LazyOptional;
import net.minecraft.class_2350;
import cn.sh1rocu.tacz.util.itemhandler.IItemHandler;
import org.jetbrains.annotations.Nullable;

public interface ItemHandlerCapability {

    default LazyOptional<IItemHandler> tacz$getItemHandler(@Nullable class_2350 facing) {
        return LazyOptional.empty();
    }

    default void tacz$invalidateItemHandler() {
    }

    default void tacz$reviveItemHandler() {
    }
}