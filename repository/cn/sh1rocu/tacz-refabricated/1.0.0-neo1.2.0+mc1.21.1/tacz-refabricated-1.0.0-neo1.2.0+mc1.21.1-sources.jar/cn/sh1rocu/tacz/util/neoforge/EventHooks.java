package cn.sh1rocu.tacz.util.neoforge;

import cn.sh1rocu.tacz.api.event.AddReloadListenerEvent;
import cn.sh1rocu.tacz.api.event.PlayerEvent;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_3302;
import net.minecraft.class_5350;
import net.minecraft.class_5455;

public class EventHooks {
    public static void firePlayerLoggedIn(class_1657 player) {
        PlayerEvent.LOGGED_IN.invoker().post(new PlayerEvent.PlayerLoggedInEvent(player));
    }

    public static void firePlayerLoggedOut(class_1657 player) {
        PlayerEvent.LOGGED_OUT.invoker().post(new PlayerEvent.PlayerLoggedOutEvent(player));
    }

    public static List<class_3302> onResourceReload(class_5350 serverResources, class_5455 registryAccess) {
        AddReloadListenerEvent event = new AddReloadListenerEvent(serverResources, registryAccess);
        AddReloadListenerEvent.CALLBACK.invoker().post(event);
        return event.getListeners();
    }
}
