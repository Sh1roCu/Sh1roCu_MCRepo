package cn.sh1rocu.tacz.api.extension;


import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

public interface IItem {
    default boolean tacz$onEntitySwing(class_1799 stack, class_1309 entity) {
        return false;
    }

    @Environment(EnvType.CLIENT)
    BuiltinItemRendererRegistry.DynamicItemRenderer getCustomRenderer();
}
