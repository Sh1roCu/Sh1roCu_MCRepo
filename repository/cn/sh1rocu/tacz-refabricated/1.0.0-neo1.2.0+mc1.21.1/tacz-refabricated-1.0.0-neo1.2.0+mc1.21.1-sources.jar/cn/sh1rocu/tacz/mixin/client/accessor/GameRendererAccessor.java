package cn.sh1rocu.tacz.mixin.client.accessor;

import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_757.class)
public interface GameRendererAccessor {
    @Invoker("getFov")
    double tacz$getFov(class_4184 camera, float tickDelta, boolean useFovSetting);

    @Invoker("bobHurt")
    void tacz$bobHurt(class_4587 poseStack, float tickDelta);

    @Invoker("bobView")
    void tacz$bobView(class_4587 poseStack, float tickDelta);
}
