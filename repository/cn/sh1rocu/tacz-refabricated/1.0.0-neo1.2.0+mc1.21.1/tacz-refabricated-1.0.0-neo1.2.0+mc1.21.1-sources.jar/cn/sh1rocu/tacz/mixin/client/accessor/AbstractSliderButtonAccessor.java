package cn.sh1rocu.tacz.mixin.client.accessor;

import net.minecraft.class_2960;
import net.minecraft.class_357;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_357.class)
public interface AbstractSliderButtonAccessor {
    @Invoker("getSprite")
    class_2960 tacz$getSprite();

    @Invoker("getHandleSprite")
    class_2960 tacz$getHandleSprite();
}
