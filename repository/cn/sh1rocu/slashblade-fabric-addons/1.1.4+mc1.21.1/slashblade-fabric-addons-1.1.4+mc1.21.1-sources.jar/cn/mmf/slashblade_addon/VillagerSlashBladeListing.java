package cn.mmf.slashblade_addon;

import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.init.SBItems;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3853;
import net.minecraft.class_5819;
import net.minecraft.class_9306;
import net.minecraft.class_9329;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class VillagerSlashBladeListing extends BasicItemListing {
    private final class_2960 bladeName;

    public VillagerSlashBladeListing(int emeralds, class_2960 bladeName, int maxTrades, int xp, float mult) {
        super(emeralds, SBItems.SLASHBLADE.method_7854(), maxTrades, xp, mult);
        this.bladeName = bladeName;
    }

    public class_2960 getBladeName() {
        return bladeName;
    }

    @Override
    public @Nullable class_1914 method_7246(class_1297 entity, class_5819 random) {
        class_1937 level = entity.method_37908();
        class_1799 blade = SlashBlade.getSlashBladeDefinitionRegistry(level).method_10223(this.getBladeName()).getBlade(entity.method_56673());
        class_9306 cost = new class_9306(price.method_41409(), price.method_7947(), class_9329.field_49597, price);

        return new class_1914(cost, Optional.empty(), blade, maxTrades, xp, priceMult);
    }
}

class BasicItemListing implements class_3853.class_1652 {
    protected final class_1799 price;
    protected final class_1799 price2;
    protected final class_1799 forSale;
    protected final int maxTrades;
    protected final int xp;
    protected final float priceMult;

    public BasicItemListing(class_1799 price, class_1799 price2, class_1799 forSale, int maxTrades, int xp, float priceMult) {
        this.price = price;
        this.price2 = price2;
        this.forSale = forSale;
        this.maxTrades = maxTrades;
        this.xp = xp;
        this.priceMult = priceMult;
    }

    public BasicItemListing(class_1799 price, class_1799 forSale, int maxTrades, int xp, float priceMult) {
        this(price, class_1799.field_8037, forSale, maxTrades, xp, priceMult);
    }

    public BasicItemListing(int emeralds, class_1799 forSale, int maxTrades, int xp, float mult) {
        this(new class_1799(class_1802.field_8687, emeralds), forSale, maxTrades, xp, mult);
    }

    public BasicItemListing(int emeralds, class_1799 forSale, int maxTrades, int xp) {
        this(new class_1799(class_1802.field_8687, emeralds), forSale, maxTrades, xp, 1.0F);
    }

    @Nullable
    @Override
    public class_1914 method_7246(class_1297 p_219693_, class_5819 p_219694_) {
        class_9306 cost = new class_9306(price.method_41409(), price.method_7947(), class_9329.field_49597, price);
        Optional<class_9306> optionalSecondCost = price2.method_7960() ? Optional.empty() : Optional.of(new class_9306(price2.method_41409(), price2.method_7947(), class_9329.field_49597, price2));
        return new class_1914(cost, optionalSecondCost, forSale, maxTrades, xp, priceMult);
    }
}
