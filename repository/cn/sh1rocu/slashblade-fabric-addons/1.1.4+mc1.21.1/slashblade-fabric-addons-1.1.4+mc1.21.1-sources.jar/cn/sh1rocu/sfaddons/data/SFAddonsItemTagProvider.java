package cn.sh1rocu.sfaddons.data;

import cn.mmf.energyblade.Energyblade;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3489;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class SFAddonsItemTagProvider extends FabricTagProvider.ItemTagProvider {
    public SFAddonsItemTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 provider) {
        this.getOrCreateTagBuilder(class_3489.field_42611).add(
                Energyblade.FORGE_ENERGY_BLADE
        );
    }
}
