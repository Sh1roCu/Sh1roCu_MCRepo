package cn.mmf.slashblade_addon.client;

import cn.mmf.slashblade_addon.SlashBladeAddon;
import cn.mmf.slashblade_addon.compat.SBATofuCraftItems;
import mods.flammpfeil.slashblade.client.renderer.model.BladeModel;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroupEntries;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_7923;
import java.util.HashSet;
import java.util.Set;

@Environment(EnvType.CLIENT)
public class SJAPClientHandler {
    public static void doClientStuff() {
        if (FabricLoader.getInstance().isModLoaded("tofucraft")) {
            class_5272.method_27879(SBATofuCraftItems.getItem(SBATofuCraftItems.TOFUISHI_SLASHBLADE),
                    class_2960.method_60654("slashblade:user"), (p_174564_, p_174565_, p_174566_, p_174567_) -> {
                        BladeModel.user = p_174566_;
                        return 0;
                    });
            class_5272.method_27879(SBATofuCraftItems.getItem(SBATofuCraftItems.TOFUMETAL_SLASHBLADE),
                    class_2960.method_60654("slashblade:user"), (p_174564_, p_174565_, p_174566_, p_174567_) -> {
                        BladeModel.user = p_174566_;
                        return 0;
                    });
            class_5272.method_27879(SBATofuCraftItems.getItem(SBATofuCraftItems.TOFUDIAMOND_SLASHBLADE),
                    class_2960.method_60654("slashblade:user"), (p_174564_, p_174565_, p_174566_, p_174567_) -> {
                        BladeModel.user = p_174566_;
                        return 0;
                    });
        }
    }

    private static final Set<class_1792> blades = new HashSet<>() {{
        add(SBATofuCraftItems.getItem(SBATofuCraftItems.TOFUISHI_SLASHBLADE));
        add(SBATofuCraftItems.getItem(SBATofuCraftItems.TOFUMETAL_SLASHBLADE));
        add(SBATofuCraftItems.getItem(SBATofuCraftItems.TOFUDIAMOND_SLASHBLADE));
    }};

    public static void Baked(ModelLoadingPlugin.Context plugin) {
        if (FabricLoader.getInstance().isModLoaded("tofucraft")) {
            plugin.modifyModelAfterBake().register((SJAPClientHandler::Baked));
        }

    }

    private static class_1087 Baked(class_1087 bakedModel, ModelModifier.AfterBake.Context context) {
        for (class_1792 blade : blades) {
            class_1091 modelLoc = new class_1091(class_7923.field_41178.method_10221(blade), "inventory");
            class_1091 id = context.topLevelId();
            if (id != null && id.equals(modelLoc)) {
                return bakeBlade(bakedModel, context.loader());
            }
        }
        return bakedModel;
    }

    private static class_1087 bakeBlade(class_1087 bakedModel, class_1088 bakery) {
        return new BladeModel(bakedModel, bakery);
    }

    public static void addCreative(class_1761 itemGroup, FabricItemGroupEntries entries) {
        if (FabricLoader.getInstance().isModLoaded("tofucraft")) {
            if (itemGroup == SlashBladeAddon.SJAP_TAB) {
                entries.method_45421(SBATofuCraftItems.getItem(SBATofuCraftItems.TOFUISHI_SLASHBLADE));
                entries.method_45421(SBATofuCraftItems.getItem(SBATofuCraftItems.TOFUMETAL_SLASHBLADE));
                entries.method_45421(SBATofuCraftItems.getItem(SBATofuCraftItems.TOFUDIAMOND_SLASHBLADE));
            }
        }
    }
}
