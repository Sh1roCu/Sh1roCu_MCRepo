package cn.mmf.slashblade_addon.compat.botania;

import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.event.SlashBladeEvent;
import mods.flammpfeil.slashblade.registry.SpecialEffectsRegistry;
import mods.flammpfeil.slashblade.registry.specialeffects.SpecialEffect;
import net.minecraft.class_1657;
import vazkii.botania.api.mana.ManaItemHandler;
import vazkii.botania.common.item.BotaniaItems;

public class ManaRapair extends SpecialEffect {

    public ManaRapair() {
        super(0, true, false);
        SlashBladeEvent.UPDATE.register(this::onSlashBladeUpdate);
    }

    public void onSlashBladeUpdate(SlashBladeEvent.UpdateEvent event) {
        ISlashBladeState state = event.getSlashBladeState();
        if (state.hasSpecialEffect(SpecialEffectsRegistry.SPECIAL_EFFECT.method_10221(SBABotaniaCompat.MANA_REPAIR))) {
            if (!(event.getEntity() instanceof class_1657 player)) {
                return;
            }

            if (!event.isSelected())
                return;

            if (!ManaItemHandler.instance().requestManaExactForTool(BotaniaItems.terraSword.method_7854(),
                    player, 100, true))
                return;

            event.getBlade().method_7974(event.getBlade().method_7919() - 1);
        }
    }
}
