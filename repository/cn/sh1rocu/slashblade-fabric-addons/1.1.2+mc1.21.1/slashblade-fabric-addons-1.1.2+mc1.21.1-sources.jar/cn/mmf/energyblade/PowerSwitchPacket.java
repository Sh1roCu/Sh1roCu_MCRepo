package cn.mmf.energyblade;

import cn.mmf.energyblade.energy.FEBladeStorage;
import cn.sh1rocu.sfaddons.util.ItemEnergyStorageHelper;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9279;

public record PowerSwitchPacket(String message) implements class_8710 {
    private static final class_2960 ID = class_2960.method_60655(Energyblade.MODID, "power_switch");
    public static final class_9154<PowerSwitchPacket> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, PowerSwitchPacket> STREAM_CODEC = class_9139.method_56434(
            class_9135.field_48554,
            PowerSwitchPacket::message,
            PowerSwitchPacket::new
    );

    public static void toBytes(class_2540 buf, String message) {
        buf.method_10814(message);
    }

    public static void handle(PowerSwitchPacket packet, ServerPlayNetworking.Context context) {
        var message = packet.message();
        var player = context.player();
        context.server().execute(() -> {
            if (player.method_7325())
                return;

            class_1799 mainHandItem = player.method_6047();
            if (CapabilitySlashBlade.getBladeState(mainHandItem).isEmpty())
                return;

            ItemEnergyStorageHelper.fromStack(mainHandItem).ifPresent(energy -> {
                if (energy instanceof FEBladeStorage bladeFE) {
                    try (Transaction tx = Transaction.openOuter()) {
                        if (!bladeFE.isPowered() && bladeFE.extract(bladeFE.getPowerupExtract(), tx) == bladeFE.getPowerupExtract()) {
                            bladeFE.setPowered(true);
                            class_3218 serverLevel = player.method_51469();
                            var random = serverLevel.field_9229;
                            for (int i = 0; i < 32; ++i) {
                                double xDist = (random.method_43057() * 2.0F - 1.0F);
                                double yDist = (random.method_43057() * 2.0F - 1.0F);
                                double zDist = (random.method_43057() * 2.0F - 1.0F);
                                if (!(xDist * xDist + yDist * yDist + zDist * zDist > 1.0D)) {
                                    double x = player.method_23316(xDist / 4.0D);
                                    double y = player.method_23323(0.5D + yDist / 4.0D);
                                    double z = player.method_23324(zDist / 4.0D);
                                    serverLevel.method_14199(class_2398.field_11214, x, y, z, 0, xDist, yDist + 0.2D, zDist,
                                            1);
                                }
                            }
                            player.method_17356(class_3417.field_14896.comp_349(), class_3419.field_15248, 2.5F, 1F);
                            tx.commit();
                        } else {
                            bladeFE.setPowered(false);
                            class_9279.method_57452(CapabilitySlashBlade.BLADESTATE_COMPONENT, mainHandItem, tag -> {
                                tag.method_10562("Energy").method_10556("isPowered", false);
                            });
                            player.method_17356(class_3417.field_14627, class_3419.field_15248, 1F, 1F);
                        }
                    }
                }
            });
        });
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
