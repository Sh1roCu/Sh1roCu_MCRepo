package cn.mmf.slashblade_addon.entity;

import mods.flammpfeil.slashblade.entity.EntityDrive;
import mods.flammpfeil.slashblade.entity.Projectile;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_3966;

public class EntityWaterDrive extends EntityDrive {

    public EntityWaterDrive(class_1299<? extends Projectile> entityTypeIn, class_1937 worldIn) {
        super(entityTypeIn, worldIn);
    }

    @Override
    protected void method_7454(class_3966 result) {
        super.method_7454(result);
        class_1297 entity = result.method_17782();
        if (entity.method_5809() && entity.method_5805())
            entity.method_46395();
    }

}
