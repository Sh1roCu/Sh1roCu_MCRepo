package cn.mmf.slashblade_addon.registry;

import cn.mmf.slashblade_addon.SlashBladeAddon;
import cn.mmf.slashblade_addon.specialeffect.BurstDrive;
import mods.flammpfeil.slashblade.registry.SpecialEffectsRegistry;
import mods.flammpfeil.slashblade.registry.specialeffects.SpecialEffect;
import net.minecraft.class_2378;

public class SBASpecialEffectsRegistry {
    public static void init() {

    }

    public static final SpecialEffect BURST_DRIVE = register("burst_drive", new BurstDrive());

    private static SpecialEffect register(String name, SpecialEffect specialEffect) {
        return class_2378.method_10230(SpecialEffectsRegistry.SPECIAL_EFFECT, SlashBladeAddon.prefix(name), specialEffect);
    }
}
