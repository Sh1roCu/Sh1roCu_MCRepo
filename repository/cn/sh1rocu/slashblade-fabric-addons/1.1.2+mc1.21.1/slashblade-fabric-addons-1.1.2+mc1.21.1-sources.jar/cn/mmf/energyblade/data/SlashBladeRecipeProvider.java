package cn.mmf.energyblade.data;

import mods.flammpfeil.slashblade.init.SBItems;
import mods.flammpfeil.slashblade.recipe.RequestDefinition;
import mods.flammpfeil.slashblade.recipe.SlashBladeIngredient;
import mods.flammpfeil.slashblade.recipe.SlashBladeShapedRecipeBuilder;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags;
import net.minecraft.class_1856;
import net.minecraft.class_7225;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class SlashBladeRecipeProvider extends FabricRecipeProvider {
    public SlashBladeRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    public void method_10419(class_8790 consumer) {
        SlashBladeShapedRecipeBuilder.shaped(BuiltInSlashBladeRegistry.HF_BLADE.method_29177())
                .pattern("SLJ")
                .pattern("LBL")
                .pattern("JLS")
                .define('B',
                        SlashBladeIngredient
                                .of(RequestDefinition.Builder.newInstance().refineCount(10).build()).toVanilla())
                .define('S', class_1856.method_8091(SBItems.proudsoul_sphere))
                .define('J', class_1856.method_8106(ConventionalItemTags.STORAGE_BLOCKS_REDSTONE))
                .define('L', class_1856.method_8106(ConventionalItemTags.STORAGE_BLOCKS_IRON))
                .method_33530(method_32807(SBItems.slashblade), method_10426(SBItems.slashblade)).method_10431(consumer);

    }

}
