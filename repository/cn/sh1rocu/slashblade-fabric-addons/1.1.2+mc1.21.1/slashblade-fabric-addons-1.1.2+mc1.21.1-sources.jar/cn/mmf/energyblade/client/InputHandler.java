package cn.mmf.energyblade.client;

import cn.mmf.energyblade.PowerSwitchPacket;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class InputHandler {
    public static final class_304 KEY_CHARGE = new class_304("key.slahblade_fabric_addons.energyblade.charge_switch",
            /*KeyConflictContext.IN_GAME, KeyModifier.SHIFT, */class_3675.class_307.field_1668, GLFW.GLFW_KEY_V,
            "key.category.slashblade");

    @Environment(EnvType.CLIENT)
    public static void onPlayerPostTick(int key, int scancode, int action, int mods) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null)
            return;

        if (player.method_6047().method_7960() || CapabilitySlashBlade.getBladeState(player.method_6047()).isEmpty())
            return;

        if (InputHandler.KEY_CHARGE.method_1434()) {
            ClientPlayNetworking.send(new PowerSwitchPacket("triggered"));
        }
    }
}
