package cn.mmf.energyblade.data;

import cn.mmf.energyblade.Energyblade;
import mods.flammpfeil.slashblade.client.renderer.CarryType;
import mods.flammpfeil.slashblade.item.SwordType;
import mods.flammpfeil.slashblade.registry.SlashArtsRegistry;
import mods.flammpfeil.slashblade.registry.slashblade.PropertiesDefinition;
import mods.flammpfeil.slashblade.registry.slashblade.RenderDefinition;
import mods.flammpfeil.slashblade.registry.slashblade.SlashBladeDefinition;
import net.minecraft.class_5321;
import net.minecraft.class_7891;
import net.minecraft.class_7923;
import java.util.List;

public class BuiltInSlashBladeRegistry {
    public static final class_5321<SlashBladeDefinition> HF_BLADE = register("hf_blade");

    public static void registerAll(class_7891<SlashBladeDefinition> bootstrap) {

        bootstrap.method_46838(HF_BLADE, new SlashBladeDefinition(class_7923.field_41178.method_10221(Energyblade.FORGE_ENERGY_BLADE),
                Energyblade.prefix("hf_blade"),
                RenderDefinition.Builder.newInstance()
                        .textureName(Energyblade.prefix("model/hf_blade.png"))
                        .modelName(Energyblade.prefix("model/hf_blade.obj"))
                        .standbyRenderType(CarryType.PSO2).build(),
                PropertiesDefinition.Builder.newInstance().baseAttackModifier(7.0F).maxDamage(50)
                        .defaultSwordType(List.of(SwordType.BEWITCHED))
                        .slashArtsType(SlashArtsRegistry.SLASH_ARTS.method_10221(SlashArtsRegistry.CIRCLE_SLASH)).build(),
                List.of()));

    }

    private static class_5321<SlashBladeDefinition> register(String id) {
        class_5321<SlashBladeDefinition> loc = class_5321.method_29179(SlashBladeDefinition.REGISTRY_KEY,
                Energyblade.prefix(id));
        return loc;
    }
}
