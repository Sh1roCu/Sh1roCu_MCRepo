package cn.mmf.energyblade;

import cn.mmf.energyblade.item.ItemFEBlade;
import cn.sh1rocu.sfaddons.SFAddons;
import com.mojang.logging.LogUtils;
import mods.flammpfeil.slashblade.item.ItemTierSlashBlade;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.slf4j.Logger;

public class Energyblade {
    public static final String MODID = "energyblade";
    private static final Logger LOGGER = LogUtils.getLogger();

    public static class_2960 prefix(String path) {
        return SFAddons.prefix(path).method_45138(MODID + "/");
    }

    // FE能量拔刀剑
    // Fabric使用TechReborn的EnergyAPI 单位为E
    public static final class_1792 FORGE_ENERGY_BLADE = class_2378.method_10230(class_7923.field_41178, prefix("forge_energy_blade"),
            new ItemFEBlade(new ItemTierSlashBlade(40, 4F), 4, -2.4F, (new class_1792.class_1793())));

    public static void init() {
        NetworkPacketHandler.registerMessage();
    }

    public static Logger getLogger() {
        return LOGGER;
    }

}
