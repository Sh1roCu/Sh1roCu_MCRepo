package cn.mmf.slashblade_addon;

import cn.mmf.slashblade_addon.compat.SBATofuCraftItems;
import cn.mmf.slashblade_addon.compat.botania.SBABotaniaCompat;
import cn.mmf.slashblade_addon.registry.SBAComboStateRegistry;
import cn.mmf.slashblade_addon.registry.SBAEntitiesRegistry;
import cn.mmf.slashblade_addon.registry.SBASlashArtsRegistry;
import cn.mmf.slashblade_addon.registry.SBASpecialEffectsRegistry;
import cn.sh1rocu.sfaddons.SFAddons;
import com.mojang.logging.LogUtils;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.init.SBItems;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.slf4j.Logger;

public class SlashBladeAddon {
    public static final String MODID = "slashblade_addon";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final class_1761 SJAP_TAB = class_2378.method_10230(class_7923.field_44687, prefix("sjap_tab"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemGroup.slashblade_addon.sjap_tab"))
                    .method_47320(
                            () -> {
                                class_1799 stack = new class_1799(SBItems.slashblade);
                                CapabilitySlashBlade.getBladeState(stack).ifPresent(s -> {
                                    s.setModel(prefix("model/murakumo/model.obj"));
                                    s.setTexture(prefix("model/murakumo/texture.png"));
                                });
                                return stack;
                            }


                    ).method_47324());

    public static void init() {
        register();

        SBASlashArtsRegistry.init();
        SBAComboStateRegistry.init();
        SBASpecialEffectsRegistry.init();
        if (FabricLoader.getInstance().isModLoaded("botania")) {
            SBABotaniaCompat.init();
        }

        CommonEventHandler.onVillagerTrades();
        CommonEventHandler.onWandererTrades();
    }

    public static class_2960 prefix(String path) {
        return SFAddons.prefix(path).method_45138(MODID + "/");
    }

    private static void register() {
        if (FabricLoader.getInstance().isModLoaded("tofucraft")) {
            SBATofuCraftItems.init();
        }
        SBAEntitiesRegistry.init();
    }
}
