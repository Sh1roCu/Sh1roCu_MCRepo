package cn.mmf.slashblade_addon;

import cn.mmf.slashblade_addon.data.SlashBladeAddonBuiltInRegistry;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.class_3852;
import net.minecraft.class_3853;

public class CommonEventHandler {
    public static void onVillagerTrades() {
        addVillageTrade(class_3852.field_17065, 2,
                new VillagerSlashBladeListing(4, SlashBladeAddonBuiltInRegistry.TOYAKO.method_29177(), 3, 5, 0.05F));
    }

    public static void onWandererTrades() {
        TradeOfferHelper.registerWanderingTraderOffers(1, rareTrades ->
                rareTrades.add(new VillagerSlashBladeListing(4, SlashBladeAddonBuiltInRegistry.TOYAKO.method_29177(), 3, 5, 0.05F)));
    }

    private static void addVillageTrade(class_3852 profession, int level,
                                        class_3853.class_1652 listing) {
        TradeOfferHelper.registerVillagerOffers(profession, level, trades ->
                trades.add(listing));
    }
}
