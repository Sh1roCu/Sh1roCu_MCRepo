package cn.mmf.slashblade_addon.compat.botania;

import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.event.SlashBladeEvent;
import mods.flammpfeil.slashblade.registry.SpecialEffectsRegistry;
import mods.flammpfeil.slashblade.registry.specialeffects.SpecialEffect;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_3419;
import vazkii.botania.api.mana.ManaItemHandler;
import vazkii.botania.common.entity.ManaBurstEntity;
import vazkii.botania.common.handler.BotaniaSounds;
import vazkii.botania.common.item.BotaniaItems;
import vazkii.botania.common.item.equipment.tool.terrasteel.TerraBladeItem;

public class ManaBurst extends SpecialEffect {

    public ManaBurst() {
        super(10, true, false);
        SlashBladeEvent.DO_SLASH.register(this::onDoingSlash);
    }

    public void onDoingSlash(SlashBladeEvent.DoSlashEvent event) {
        ISlashBladeState state = event.getSlashBladeState();
        if (state.hasSpecialEffect(SpecialEffectsRegistry.SPECIAL_EFFECT.method_10221(SBABotaniaCompat.MANA_BURST))) {
            if (!(event.getUser() instanceof class_1657 player)) {
                return;
            }

            int level = player.field_7520;

            if (SpecialEffect.isEffective(SpecialEffectsRegistry.SPECIAL_EFFECT.method_10221(SBABotaniaCompat.MANA_BURST), level)) {
                if (!ManaItemHandler.instance().requestManaExactForTool(BotaniaItems.terraSword.method_7854(),
                        player, 100, true))
                    return;
                ManaBurstEntity burst = TerraBladeItem.getBurst(player, BotaniaItems.terraSword.method_7854());
                player.method_37908().method_8649(burst);
                player.method_20235(player.method_6047().method_7909(), class_1304.field_6173);
                player.method_37908().method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), BotaniaSounds.terraBlade, class_3419.field_15248, 1F, 1F);
            }
        }
    }
}
