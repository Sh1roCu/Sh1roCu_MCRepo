package cn.mmf.slashblade_addon.entity;

import cn.mmf.slashblade_addon.registry.SBAEntitiesRegistry;
import mods.flammpfeil.slashblade.entity.Projectile;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class GaleSwordsEntity extends BlisteringSwordsEntity {
	public GaleSwordsEntity(class_1299<? extends Projectile> entityTypeIn, class_1937 worldIn) {
		super(entityTypeIn, worldIn);
	}

	public static GaleSwordsEntity createInstance(class_1937 worldIn) {
		return new GaleSwordsEntity(SBAEntitiesRegistry.GaleSwords, worldIn);
	}

	@Override
	protected void method_24920(class_3965 blockraytraceresult) {
		super.method_24920(blockraytraceresult);
		this.method_37908().method_8437(this, this.method_23317(), this.method_23318(), this.method_23321(), 1, class_1937.class_7867.field_40888);
		burst();
	}

	@Override
	protected void method_7454(class_3966 result) {
		super.method_7454(result);
		this.method_37908().method_8437(this, this.method_23317(), this.method_23318(), this.method_23321(), 1, class_1937.class_7867.field_40888);
		burst();
	}
}
