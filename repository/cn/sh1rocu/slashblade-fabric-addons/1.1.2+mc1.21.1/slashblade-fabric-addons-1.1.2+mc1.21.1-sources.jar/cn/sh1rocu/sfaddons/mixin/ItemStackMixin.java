package cn.sh1rocu.sfaddons.mixin;

import cn.sh1rocu.sfaddons.api.extension.IDamageable;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1799.class)
public abstract class ItemStackMixin {
    @Shadow
    public abstract class_1792 getItem();

    @Inject(method = "isDamageableItem", at = @At("HEAD"), cancellable = true)
    private void sf$isDamageable(CallbackInfoReturnable<Boolean> cir) {
        if (this.getItem() instanceof IDamageable damageable)
            cir.setReturnValue(damageable.isDamageable((class_1799) (Object) this));
    }
}