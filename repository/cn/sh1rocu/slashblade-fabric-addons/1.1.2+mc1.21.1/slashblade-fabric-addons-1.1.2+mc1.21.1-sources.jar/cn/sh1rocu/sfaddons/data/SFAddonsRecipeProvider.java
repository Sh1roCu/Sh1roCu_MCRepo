package cn.sh1rocu.sfaddons.data;

import cn.mmf.energyblade.data.SlashBladeRecipeProvider;
import cn.mmf.slashblade_addon.data.SlashBladeAddonRecipeProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_7225;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class SFAddonsRecipeProvider extends FabricRecipeProvider {
    private final CompletableFuture<class_7225.class_7874> registryFuture;

    public SFAddonsRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
        this.registryFuture = registriesFuture;
    }

    @Override
    public void method_10419(class_8790 consumer) {
        // SJAP
        new SlashBladeAddonRecipeProvider(output, registryFuture).method_10419(consumer);
        // EnergyBlade(HF Blade)
        new SlashBladeRecipeProvider(output, registryFuture).method_10419(consumer);
    }
}
