package cn.sh1rocu.sfaddons.data;

import mods.flammpfeil.slashblade.event.drop.EntityDropEntry;
import mods.flammpfeil.slashblade.registry.slashblade.SlashBladeDefinition;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricDynamicRegistryProvider;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class DynamicRegistry extends FabricDynamicRegistryProvider {
    public DynamicRegistry(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void configure(class_7225.class_7874 registries, Entries entries) {
        entries.addAll(registries.method_46762(SlashBladeDefinition.REGISTRY_KEY));
        entries.addAll(registries.method_46762(EntityDropEntry.REGISTRY_KEY));
    }

    @Override
    public String method_10321() {
        return "SFAddons dynamic registry";
    }
}
