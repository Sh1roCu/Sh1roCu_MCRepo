package cn.sh1rocu.sfaddons.api.extension;

import net.minecraft.class_1799;
import net.minecraft.class_9334;

public interface IDamageable {
    default boolean isDamageable(class_1799 stack) {
        return stack.method_57826(class_9334.field_50072) && !stack.method_57826(class_9334.field_49630) && stack.method_57826(class_9334.field_49629);
    }
}