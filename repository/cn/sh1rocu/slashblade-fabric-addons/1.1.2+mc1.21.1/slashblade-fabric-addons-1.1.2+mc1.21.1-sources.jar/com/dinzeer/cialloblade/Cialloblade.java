package com.dinzeer.cialloblade;

import cn.sh1rocu.sfaddons.SFAddons;
import com.dinzeer.cialloblade.se.SERegsitry;
import com.dinzeer.cialloblade.sound.SoundRegsitry;
import com.mojang.logging.LogUtils;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import mods.flammpfeil.slashblade.init.SBItems;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.slf4j.Logger;

public class Cialloblade {

    public static final String MODID = "cialloblade";
    private static final Logger LOGGER = LogUtils.getLogger();

    public static class_2960 prefix(String path) {
        return SFAddons.prefix(path).method_45138(MODID + "/");
    }

    public static final class_1761 CIALLO_TAB = class_2378.method_10230(class_7923.field_44687, prefix("ciallo_tab"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemGroup.cialloblade.ciallo_tab"))
                    .method_47320(
                            () -> {
                                class_1799 stack = new class_1799(SBItems.slashblade);
                                CapabilitySlashBlade.getBladeState(stack).ifPresent(s -> {
                                    s.setModel(prefix("model/ciallo/blademaster.obj"));
                                    s.setTexture(prefix("model/ciallo/ciallo.png"));
                                });
                                return stack;
                            }


                    ).method_47324());


    public static void init() {
        SERegsitry.init();
        // 注册声音
        SoundRegsitry.init();

    }
}
