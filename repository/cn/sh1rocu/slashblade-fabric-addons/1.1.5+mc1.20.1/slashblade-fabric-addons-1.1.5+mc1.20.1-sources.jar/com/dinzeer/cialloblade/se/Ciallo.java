package com.dinzeer.cialloblade.se;

import com.dinzeer.cialloblade.sound.SoundRegsitry;
import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.event.SlashBladeEvent;
import mods.flammpfeil.slashblade.registry.ComboStateRegistry;
import mods.flammpfeil.slashblade.registry.SpecialEffectsRegistry;
import mods.flammpfeil.slashblade.registry.specialeffects.SpecialEffect;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3419;

public class Ciallo extends SpecialEffect {
    public Ciallo() {
        super(30);
    }

    public static void onHitEntity(SlashBladeEvent.HitEvent event) {
        ISlashBladeState state = event.getSlashBladeState();
        if (state.hasSpecialEffect(SpecialEffectsRegistry.SPECIAL_EFFECT.method_10221(SERegsitry.CIALLO))) {
            if (!(event.getUser() instanceof class_1657 player)) return;
            if (SpecialEffect.isEffective(SERegsitry.CIALLO, player.field_7520)) {
                class_1937 world = player.method_37908();

                if (player.method_6051().method_43048(2) == 1) {
                    world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), SoundRegsitry.DOCIALLO, class_3419.field_15248,
                            player.method_6051().method_43057(), 1.0F);
                } else {
                    world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), SoundRegsitry.DOCIALLO2, class_3419.field_15248,
                            player.method_6051().method_43057(), 1.0F);
                }

            }
        }
    }

    public static void onUpdate(SlashBladeEvent.UpdateEvent event) {
        ISlashBladeState state = event.getSlashBladeState();
        if (state.hasSpecialEffect(SpecialEffectsRegistry.SPECIAL_EFFECT.method_10221(SERegsitry.CIALLO))) {
            if (!(event.getEntity() instanceof class_1657 player)) return;
            if (SpecialEffect.isEffective(SERegsitry.CIALLO, player.field_7520)) {
                if (state.getProudSoulCount() < 1000) {
                    class_1937 world = player.method_37908();
                    state.setProudSoulCount(1000);

                    world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), SoundRegsitry.DOCIALLO, class_3419.field_15248,
                            player.method_6051().method_43057(), 1.0F);

                }
            }
        }
    }

    public static void doSlash(SlashBladeEvent.DoSlashEvent event) {
        ISlashBladeState state = event.getSlashBladeState();
        if (state.hasSpecialEffect(SpecialEffectsRegistry.SPECIAL_EFFECT.method_10221(SERegsitry.CIALLO))) {
            if (!(event.getUser() instanceof class_1657 player)) return;
            if (SpecialEffect.isEffective(SERegsitry.CIALLO, player.field_7520)) {
                class_1937 world = player.method_37908();

                if (state.getComboSeq() == (ComboStateRegistry.getId(ComboStateRegistry.WAVE_EDGE_VERTICAL))) {

                    world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), SoundRegsitry.DOSLASH, class_3419.field_15248,
                            player.method_6051().method_43057(), 1.0F);

                }
                if (state.getComboSeq() == (ComboStateRegistry.getId(ComboStateRegistry.AERIAL_RAVE_A1))) {

                    world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), SoundRegsitry.SENPAI, class_3419.field_15248,
                            player.method_6051().method_43057(), 1.0F);

                }

                if (player.method_5715()) {

                    world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), SoundRegsitry.DOCIALLO2, class_3419.field_15248,
                            player.method_6051().method_43057(), 1.0F);

                }

            }
        }
    }
}