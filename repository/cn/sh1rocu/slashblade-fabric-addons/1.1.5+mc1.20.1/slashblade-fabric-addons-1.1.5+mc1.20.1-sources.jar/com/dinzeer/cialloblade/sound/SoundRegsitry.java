package com.dinzeer.cialloblade.sound;

import static com.dinzeer.cialloblade.Cialloblade.MODID;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class SoundRegsitry {
    public static void init() {

    }

    public static final class_3414 DOCIALLO
            = register("dociallo", class_3414.method_47908(new class_2960(MODID, "dociallo")));

    public static final class_3414 DOSLASH
            = register("doslash", class_3414.method_47908(new class_2960(MODID, "doslash")));
    public static final class_3414 DOCIALLO2
            = register("dociallo2", class_3414.method_47908(new class_2960(MODID, "dociallo2")));
    public static final class_3414 SENPAI
            = register("senpai", class_3414.method_47908(new class_2960(MODID, "senpai")));


    public static class_3414 register(String name, class_3414 soundEvent) {
        return class_2378.method_10230(class_7923.field_41172, new class_2960(MODID, name), soundEvent);
    }
}
