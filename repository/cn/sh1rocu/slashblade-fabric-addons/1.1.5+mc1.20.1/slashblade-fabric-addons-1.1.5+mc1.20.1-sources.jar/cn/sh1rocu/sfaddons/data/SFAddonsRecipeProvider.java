package cn.sh1rocu.sfaddons.data;

import cn.mmf.energyblade.data.SlashBladeRecipeProvider;
import cn.mmf.slashblade_addon.data.SlashBladeAddonRecipeProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_2444;
import java.util.function.Consumer;

public class SFAddonsRecipeProvider extends FabricRecipeProvider {
    public SFAddonsRecipeProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void method_10419(Consumer<class_2444> consumer) {
        // SJAP
        new SlashBladeAddonRecipeProvider(output).method_10419(consumer);
        // EnergyBlade(HF Blade)
        new SlashBladeRecipeProvider(output).method_10419(consumer);
    }
}
