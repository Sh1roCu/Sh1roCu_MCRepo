package cn.sh1rocu.sfaddons.api.extension;

import net.minecraft.class_1792;
import net.minecraft.class_1799;

public interface IDamageable {
    default boolean isDamageable(class_1799 stack) {
        return ((class_1792) this).method_7846();
    }
}