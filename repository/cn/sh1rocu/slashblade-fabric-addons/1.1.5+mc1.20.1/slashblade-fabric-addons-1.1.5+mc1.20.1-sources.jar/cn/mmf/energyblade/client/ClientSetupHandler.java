package cn.mmf.energyblade.client;

import cn.mmf.energyblade.Energyblade;
import cn.mmf.energyblade.item.ItemFEBlade;
import mods.flammpfeil.slashblade.SlashBlade;
import mods.flammpfeil.slashblade.client.renderer.model.BladeModel;
import mods.flammpfeil.slashblade.item.ItemSlashBlade;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.minecraft.class_1091;
import net.minecraft.class_5272;
import net.minecraft.class_7923;

import static mods.flammpfeil.slashblade.client.ClientHandler.bakeBlade;

@Environment(EnvType.CLIENT)
public class ClientSetupHandler {
    public static void setModelUser() {
        class_7923.field_41178.method_10235().stream().filter(loc -> loc.method_12832().startsWith(Energyblade.MODID + "/")).forEach(res -> {
            if (class_7923.field_41178.method_10223(res) instanceof ItemSlashBlade blade) {
                class_5272.method_27879(blade, SlashBlade.prefix("user"), (stack, level, entity, seed) -> {
                    BladeModel.user = entity;
                    return 0;
                });
            }
        });
    }

    public static void registerKeyMapping() {
        KeyBindingHelper.registerKeyBinding(InputHandler.KEY_CHARGE);
    }


    public static void baked(ModelLoadingPlugin.Context plugin) {
        class_7923.field_41178.method_10220().filter(item -> item instanceof ItemFEBlade).forEach(item -> {
            plugin.modifyModelAfterBake().register((bakedModel, context) -> {
                class_1091 modelLoc = new class_1091(class_7923.field_41178.method_10221(item), "inventory");
                if (context.id() instanceof class_1091 contextModelId && contextModelId.equals(modelLoc)) {
                    return bakeBlade(bakedModel, context.loader());
                }
                return bakedModel;
            });
        });
    }
}
