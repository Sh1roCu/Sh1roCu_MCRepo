package cn.mmf.slashblade_addon.entity;

import mods.flammpfeil.slashblade.entity.Projectile;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3966;

public class LightingSwordEntity extends BlisteringSwordsEntity {

    public LightingSwordEntity(class_1299<? extends Projectile> entityTypeIn, class_1937 worldIn) {
        super(entityTypeIn, worldIn);
    }

    @Override
    protected void method_7454(class_3966 result) {
        class_1297 entity = result.method_17782();
        class_1937 level = entity.method_37908();
        if (!level.method_8608()) {
            class_2338 blockpos = entity.method_24515();
            if (this.method_37908().method_8311(blockpos)) {
                class_1538 lightningbolt = class_1299.field_6112.method_5883(this.method_37908());
                if (lightningbolt != null) {
                    lightningbolt.method_29495(class_243.method_24955(blockpos));
                    lightningbolt.method_6961(this.method_24921() instanceof class_3222 ? (class_3222) this.method_24921() : null);
                    this.method_37908().method_8649(lightningbolt);
                    this.method_5783(class_3417.field_14896, 5.0F, 1.0F);
                }
            }
        }

        super.method_7454(result);
    }

}
