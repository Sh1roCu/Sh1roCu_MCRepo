package cn.mmf.slashblade_addon.data;

import cn.mmf.slashblade_addon.SlashBladeAddon;
import mods.flammpfeil.slashblade.event.drop.EntityDropEntry;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7891;

public class SBAEntityDropRegistry {
	public static final class_5321<EntityDropEntry> RAVEN_DARKRAVEN = register("raven_darkraven");
	
	public static final class_5321<EntityDropEntry> GHAST_MURAKUMO = register("ghast_murakumo");

	public static void registerAll(class_7891<EntityDropEntry> bootstrap) {
		bootstrap.method_46838(RAVEN_DARKRAVEN, new EntityDropEntry(new class_2960("twilightforest", "raven"),
				SlashBladeAddon.prefix("dark_raven"), 0.05F, true));
		
		bootstrap.method_46838(GHAST_MURAKUMO, new EntityDropEntry(new class_2960("twilightforest", "ur_ghast"),
				SlashBladeAddon.prefix("murakumo"), 1.00F, false));
	}

	private static class_5321<EntityDropEntry> register(String id) {
		return class_5321.method_29179(EntityDropEntry.REGISTRY_KEY, SlashBladeAddon.prefix(id));
	}
}
