package cn.mmf.slashblade_addon.data;

import cn.mmf.slashblade_addon.SlashBladeAddon;
import mods.flammpfeil.slashblade.data.SlashBladeRecipeProvider;
import mods.flammpfeil.slashblade.data.builtin.SlashBladeBuiltInRegistry;
import mods.flammpfeil.slashblade.init.SBItems;
import mods.flammpfeil.slashblade.item.SwordType;
import mods.flammpfeil.slashblade.recipe.RequestDefinition;
import mods.flammpfeil.slashblade.recipe.SlashBladeIngredient;
import mods.flammpfeil.slashblade.recipe.SlashBladeShapedRecipeBuilder;
import mods.flammpfeil.slashblade.registry.slashblade.EnchantmentDefinition;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.fabricmc.fabric.api.resource.conditions.v1.DefaultResourceConditions;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalItemTags;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1847;
import net.minecraft.class_1856;
import net.minecraft.class_1893;
import net.minecraft.class_2444;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import vazkii.botania.common.item.BotaniaItems;

import java.util.function.Consumer;

public class SlashBladeAddonRecipeProvider extends FabricRecipeProvider {
    public SlashBladeAddonRecipeProvider(FabricDataOutput output) {
        super(output);
    }

    public void method_10419(Consumer<class_2444> consumer) {
        SlashBladeShapedRecipeBuilder
                .shaped(SlashBladeAddonBuiltInRegistry.HF_MURASAMA.method_29177()).pattern(" RI").pattern("RBG")
                .pattern("SL ").define('S', SBItems.PROUDSOUL_TRAPEZOHEDRON).define('I', ConventionalItemTags.IRON_INGOTS)
                .define('G', class_1802.field_8054).define('R', SlashBladeRecipeProvider.STORAGE_BLOCKS_REDSTONE)
                .define('L', class_1802.field_8865)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeBuiltInRegistry.MURAMASA.method_29177()).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE))
                .method_17972(consumer, SlashBladeAddon.prefix("murasama_blade"));

        SlashBladeShapedRecipeBuilder
                .shaped(SlashBladeAddonBuiltInRegistry.WANDERER_HF.method_29177())
                .pattern("  I")
                .pattern("QI ")
                .pattern("BC ")
                .define('C', SBItems.PROUDSOUL_TRAPEZOHEDRON)
                .define('I', ConventionalItemTags.REDSTONE_DUSTS)
                .define('Q', ConventionalItemTags.QUARTZ)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeAddonBuiltInRegistry.WANDERER.method_29177()).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE))
                .method_17972(consumer, SlashBladeAddon.prefix("wanderer_hf"));

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.WANDERER.method_29177())
                .pattern("  I")
                .pattern("QI ")
                .pattern("BC ")
                .define('C', class_1802.field_8557)
                .define('I', SBItems.PROUDSOUL_INGOT)
                .define('Q', ConventionalItemTags.QUARTZ)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeBuiltInRegistry.DOUTANUKI.method_29177()).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        // TODO: TofuCraft Fabric移植
//        SmithingTransformRecipeBuilder
//                .smithing(Ingredient.of(TofuItems.TOFU_UPGRADE_SMITHING_TEMPLATE),
//                        Ingredient.of(getItem(SBATofuCraftItems.TOFUMETAL_SLASHBLADE)),
//                        Ingredient.of(TofuBlocks.DIAMONDTOFU), RecipeCategory.COMBAT,
//                        getItem(SBATofuCraftItems.TOFUDIAMOND_SLASHBLADE))
//                .unlocks("has_item", has(getItem(SBATofuCraftItems.TOFUMETAL_SLASHBLADE)))
//                .save(withConditions(consumer, DefaultResourceConditions.allModsLoaded("tofucraft")), SlashBladeAddon.prefix("tofu_diamond_blade"));
//        SlashBladeShapedRecipeBuilder.shaped(SBATofuCraftItems.TOFUMETAL_SLASHBLADE).pattern(" ST")
//                .pattern("ST ").pattern("WR ").define('S', TofuItems.TOFUISHI)
//                .define('R',SlashBladeRecipeProvider.STRING).define('W', Items.STICK)
//                .define('T', TofuItems.TOFUMETAL)
//                .unlockedBy(getHasName(SBItems.SLASHBLADE_WOOD), has(SBItems.SLASHBLADE_WOOD))
//                .save(withConditions(consumer, DefaultResourceConditions.allModsLoaded("tofucraft"), SBATofuCraftItems.TOFUMETAL_SLASHBLADE));
//        SlashBladeShapedRecipeBuilder.shaped(SBATofuCraftItems.TOFUISHI_SLASHBLADE).pattern(" SS")
//                .pattern("SS ").pattern("WR ").define('S', TofuItems.TOFUISHI)
//                .define('R', SlashBladeRecipeProvider.STRING).define('W', SlashBladeRecipeProvider.RODS_WOODEN)
//                .unlockedBy(getHasName(SBItems.SLASHBLADE_WOOD), has(SBItems.SLASHBLADE_WOOD))
//                .save(withConditions(consumer, DefaultResourceConditions.allModsLoaded("tofucraft"), SBATofuCraftItems.TOFUISHI_SLASHBLADE));

        SlashBladeShapedRecipeBuilder
                .shaped(SlashBladeAddonBuiltInRegistry.TERRA_BLADE.method_29177()).pattern("ZCO").pattern(" BG")
                .pattern("Q X").define('G', SBItems.PROUDSOUL).define('X', SBItems.PROUDSOUL_SPHERE)
                .define('Q', BotaniaItems.terraSword).define('Z', BotaniaItems.vineBall)
                .define('C', BotaniaItems.thornChakram).define('O', BotaniaItems.gaiaIngot)
                .define('B', SBItems.SLASHBLADE).method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE))
                .method_17972(withConditions(consumer, DefaultResourceConditions.allModsLoaded("botania")), SlashBladeAddonBuiltInRegistry.TERRA_BLADE.method_29177());

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.KAMUY_NONE.method_29177()).pattern("SNS")
                .pattern("IBI").pattern("SDS").define('S', SBItems.PROUDSOUL_SPHERE)
                .define('I', SBItems.PROUDSOUL_INGOT).define('N', ConventionalItemTags.QUARTZ).define('D', class_1802.field_8529)
                .define('B',
                        SlashBladeIngredient
                                .of(RequestDefinition.Builder.newInstance().killCount(100).refineCount(1).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.KAMUY_WATER.method_29177()).pattern("SNS")
                .pattern("ABQ").pattern("SDS").define('S', SBItems.PROUDSOUL_SPHERE).define('A', class_1802.field_8081)
                .define('Q', class_1802.field_8246).define('N', SlashBladeRecipeProvider.STORAGE_BLOCKS_LAPIS)
                .define('D', class_1802.field_8705)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeAddonBuiltInRegistry.KAMUY_NONE.method_29177()).killCount(500)
                                .proudSoul(5000).refineCount(20).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.KAMUY_LIGHTING.method_29177()).pattern("SNS")
                .pattern("ABQ").pattern("SDS").define('S', SBItems.PROUDSOUL_SPHERE)
                .define('A', SlashBladeRecipeProvider.STORAGE_BLOCKS_GOlD).define('Q', SlashBladeRecipeProvider.STORAGE_BLOCKS_DIAMOND)
                .define('N', SlashBladeRecipeProvider.STORAGE_BLOCKS_IRON).define('D', SlashBladeRecipeProvider.STORAGE_BLOCKS_EMERALD)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeAddonBuiltInRegistry.KAMUY_NONE.method_29177()).killCount(500)
                                .proudSoul(5000).refineCount(20).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.KAMUY_FIRE.method_29177()).pattern("SNS")
                .pattern("ABQ").pattern("SDS").define('S', SBItems.PROUDSOUL_SPHERE).define('A', class_1802.field_8814)
                .define('Q', SlashBladeRecipeProvider.RODS_BLAZE).define('N', SlashBladeRecipeProvider.STORAGE_BLOCKS_REDSTONE)
                .define('D', class_1802.field_8187)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeAddonBuiltInRegistry.KAMUY_NONE.method_29177()).killCount(500)
                                .proudSoul(5000).refineCount(20).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        // nihil
        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.NIHIL.method_29177()).pattern("SIS")
                .pattern("IBI").pattern("SIS").define('S', SBItems.PROUDSOUL_SPHERE)
                .define('I', SBItems.PROUDSOUL_INGOT).define('B', SlashBladeIngredient.of(RequestDefinition.Builder.newInstance().build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.NIHILEX.method_29177()).pattern("SNS")
                .pattern("IBI").pattern("SDS").define('S', SBItems.PROUDSOUL_SPHERE)
                .define('I', SBItems.PROUDSOUL_INGOT).define('N', class_1802.field_8137).define('D', class_1802.field_8603)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeAddonBuiltInRegistry.NIHIL.method_29177()).killCount(1000).proudSoul(100)
                                .refineCount(1).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.NIHILUL.method_29177()).pattern("SNS")
                .pattern("DBD").pattern("SYS").define('S', SlashBladeIngredient.of(RequestDefinition.Builder.newInstance().build()).toVanilla())
                .define('Y',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeBuiltInRegistry.YAMATO.method_29177()).build()).toVanilla())
                .define('N', class_1802.field_8137).define('D', class_1802.field_8603)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeAddonBuiltInRegistry.NIHILEX.method_29177()).killCount(3000).proudSoul(6500)
                                .refineCount(3).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.CRIMSONCHERRY.method_29177()).pattern("DUD")
                .pattern("DED").pattern("DDD")
                .define('E',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeAddonBuiltInRegistry.NIHIL.method_29177()).build()).toVanilla())
                .define('D', class_1802.field_8603)
                .define('U',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeAddonBuiltInRegistry.NIHILEX.method_29177()).killCount(3000).proudSoul(6500)
                                .refineCount(3).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.NIHILBX.method_29177()).pattern("DDD")
                .pattern("CSU").pattern("DDD").define('S', SlashBladeIngredient.of(RequestDefinition.Builder.newInstance().build()).toVanilla()).define('D', class_1802.field_8603)
                .define('C',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeAddonBuiltInRegistry.CRIMSONCHERRY.method_29177()).killCount(3000)
                                .proudSoul(6500).refineCount(3).build()).toVanilla())
                .define('U',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeAddonBuiltInRegistry.NIHILUL.method_29177()).killCount(3000).proudSoul(6500)
                                .refineCount(3).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        // WA
        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.KATANA.method_29177()).pattern("  P")
                .pattern(" B ").pattern("S  ").define('P', SBItems.PROUDSOUL_INGOT).define('S', class_1802.field_8371)
                .define('B',
                        SlashBladeIngredient.of(SBItems.SLASHBLADE_SILVERBAMBOO,
                                RequestDefinition.Builder.newInstance().addSwordType(SwordType.BROKEN).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE_SILVERBAMBOO), method_10426(SBItems.SLASHBLADE_SILVERBAMBOO))
                .method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.TACHI.method_29177()).pattern("  P")
                .pattern(" B ").pattern("S  ").define('P', SBItems.PROUDSOUL_SPHERE).define('S', class_1802.field_8371)
                .define('B',
                        SlashBladeIngredient.of(SBItems.SLASHBLADE_SILVERBAMBOO,
                                RequestDefinition.Builder.newInstance().addSwordType(SwordType.BROKEN).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE_SILVERBAMBOO), method_10426(SBItems.SLASHBLADE_SILVERBAMBOO))
                .method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.BLUE.method_29177()).pattern("BCI")
                .pattern("CI ").pattern("SL ").define('B', class_1802.field_8345).define('C', class_1802.field_8797)
                .define('I', SBItems.PROUDSOUL_INGOT).define('S', class_1802.field_8600).define('L', class_1802.field_8276)
                .method_33530(method_32807(SBItems.PROUDSOUL_INGOT), method_10426(SBItems.PROUDSOUL_INGOT)).method_10431(consumer);

        // BladeMaster
        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.GREEN_MIST.method_29177()).pattern("PRE")
                .pattern("RE ").pattern("BGC").define('P', SBItems.PROUDSOUL_SPHERE).define('R', class_1802.field_8793)
                .define('E', class_1802.field_8733).define('G', class_1802.field_8494).define('C', class_1802.field_42694)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeBuiltInRegistry.MURAMASA.method_29177()).killCount(1000).proudSoul(10000)
                                .refineCount(25)
                                .addEnchantment(new EnchantmentDefinition(
                                        class_7923.field_41176.method_10221(class_1893.field_9103), 3))
                                .build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.AQUABLAZE.method_29177()).pattern("PRW")
                .pattern("RL ").pattern("BGC").define('P', SBItems.PROUDSOUL_SPHERE).define('R', class_1802.field_8793)
                .define('W', class_1802.field_8705).define('L', class_1802.field_8187).define('G', class_1802.field_8494)
                .define('C', class_1802.field_42694)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeBuiltInRegistry.MURAMASA.method_29177()).killCount(1000).proudSoul(10000)
                                .refineCount(25)
                                .addEnchantment(new EnchantmentDefinition(
                                        class_7923.field_41176.method_10221(class_1893.field_9095), 1))
                                .build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.MOONLIGHT_CHERRY.method_29177()).pattern("PRQ")
                .pattern("RL ").pattern("BGC").define('P', SBItems.PROUDSOUL_SPHERE).define('R', class_1802.field_8793)
                .define('Q', class_1802.field_20402).define('L', class_1802.field_8801).define('G', class_1802.field_8494)
                .define('C', class_1802.field_42694)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeBuiltInRegistry.MURAMASA.method_29177()).killCount(1000).proudSoul(10000)
                                .refineCount(25)
                                .addEnchantment(new EnchantmentDefinition(
                                        class_7923.field_41176.method_10221(class_1893.field_9097), 1))
                                .build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        // Dark Raven:Snow Crow
        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.SNOW_CROW.method_29177()).pattern(" FQ")
                .pattern("SQ ").pattern("B  ").define('F', class_1802.field_8153).define('S', class_1802.field_8543)
                .define('Q', class_1802.field_20402)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeBuiltInRegistry.DOUTANUKI.method_29177()).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        // Fluorescent Bar
        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.FLUORESCENT_BAR.method_29177()).pattern(" PS")
                .pattern("PGP").pattern("SP ").define('P', class_1802.field_8407).define('G', class_1802.field_8280)
                .define('S', SBItems.PROUDSOUL).method_33530(method_32807(SBItems.PROUDSOUL), method_10426(SBItems.PROUDSOUL))
                .method_10431(consumer);

        // Frost Wolf
        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.FROSTY_CHERRY.method_29177()).pattern(" ID")
                .pattern("SP ").pattern("BQ ").define('I', class_1802.field_8426).define('D', class_1802.field_8345)
                .define('S', class_1802.field_8246).define('P', SBItems.PROUDSOUL_SPHERE).define('Q', class_1802.field_8155)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeBuiltInRegistry.DOUTANUKI.method_29177()).refineCount(10)
                                .addEnchantment(new EnchantmentDefinition(
                                        class_7923.field_41176.method_10221(class_1893.field_9095), 1))
                                .build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.FROST_WOLF.method_29177()).pattern(" ID")
                .pattern("SP ").pattern("BQ ").define('I', class_1802.field_8426).define('D', class_1802.field_8345)
                .define('S', class_1802.field_8246).define('P', SBItems.PROUDSOUL_SPHERE).define('Q', class_1802.field_8155)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeBuiltInRegistry.MURAMASA.method_29177()).refineCount(25)
                                .addEnchantment(new EnchantmentDefinition(
                                        class_7923.field_41176.method_10221(class_1893.field_9095), 1))
                                .build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.YUKARI.method_29177()).pattern("ISI")
                .pattern("SBS").pattern("ISI").define('I', SBItems.PROUDSOUL_INGOT)
                .define('S', SBItems.PROUDSOUL_SPHERE)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeBuiltInRegistry.TUKUMO.method_29177()).killCount(1000)
                                .addEnchantment(new EnchantmentDefinition(
                                        class_7923.field_41176.method_10221(class_1893.field_9124), 1))
                                .build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.KIRISAYA.method_29177()).pattern("DID")
                .pattern("SBS").pattern("IDI").define('D', class_1802.field_8144).define('I', class_1802.field_8463)
                .define('S', SBItems.PROUDSOUL_SPHERE)
                .define('B',
                        SlashBladeIngredient.of(SBItems.SLASHBLADE_SILVERBAMBOO, RequestDefinition.Builder.newInstance()
                                .proudSoul(10000).killCount(1000).refineCount(1).addSwordType(SwordType.BROKEN)
                                .addEnchantment(new EnchantmentDefinition(
                                        class_7923.field_41176.method_10221(class_1893.field_9118), 3))
                                .build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE_SILVERBAMBOO), method_10426(SBItems.SLASHBLADE_SILVERBAMBOO))
                .method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.LAEMMLE.method_29177()).pattern("XGO")
                .pattern("GBG").pattern("QGX").define('G', ConventionalItemTags.GOLD_INGOTS)
                .define('X', class_1856.method_8101(class_1844.method_8061(new class_1799(class_1802.field_8574), class_1847.field_8993)))
                .define('Q', SlashBladeRecipeProvider.STORAGE_BLOCKS_QUARTZ).define('O', SlashBladeRecipeProvider.OBSIDIAN)
                .define('B',
                        SlashBladeIngredient.of(RequestDefinition.Builder.newInstance()
                                .name(SlashBladeBuiltInRegistry.MURAMASA.method_29177()).build()).toVanilla())
                .method_33530(method_32807(SBItems.SLASHBLADE), method_10426(SBItems.SLASHBLADE)).method_10431(consumer);

        SlashBladeShapedRecipeBuilder.shaped(SlashBladeAddonBuiltInRegistry.TBOEN.method_29177()).pattern("SSS")
                .pattern("SBS").pattern("SSS").define('S', SBItems.PROUDSOUL).define('B', SBItems.SLASHBLADE_WHITE)
                .method_33530(method_32807(SBItems.SLASHBLADE_WHITE), method_10426(SBItems.SLASHBLADE_WHITE)).method_10431(consumer);

    }

    public class_1792 getItem(class_2960 item) {
        return class_7923.field_41178.method_10223(item);
    }

}
