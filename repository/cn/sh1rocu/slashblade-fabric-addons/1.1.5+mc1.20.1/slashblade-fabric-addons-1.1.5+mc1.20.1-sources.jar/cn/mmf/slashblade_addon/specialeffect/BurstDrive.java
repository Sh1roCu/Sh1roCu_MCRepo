package cn.mmf.slashblade_addon.specialeffect;

import cn.mmf.slashblade_addon.registry.SBASpecialEffectsRegistry;
import mods.flammpfeil.slashblade.capability.slashblade.ISlashBladeState;
import mods.flammpfeil.slashblade.event.SlashBladeEvent;
import mods.flammpfeil.slashblade.registry.SpecialEffectsRegistry;
import mods.flammpfeil.slashblade.registry.specialeffects.SpecialEffect;
import mods.flammpfeil.slashblade.slasharts.Drive;
import net.minecraft.class_1657;
import net.minecraft.class_243;

public class BurstDrive extends SpecialEffect {

    public BurstDrive() {
        super(30, false, false);
    }

    public static void onDoingSlash(SlashBladeEvent.DoSlashEvent event) {
        ISlashBladeState state = event.getSlashBladeState();
        if (state.hasSpecialEffect(SpecialEffectsRegistry.SPECIAL_EFFECT.method_10221(SBASpecialEffectsRegistry.BURST_DRIVE))) {
            if (!(event.getUser() instanceof class_1657)) {
                return;
            }

            class_1657 player = (class_1657) event.getUser();

            int level = player.field_7520;
            int colorCode = event.getSlashBladeState().getColorCode();
            if (SpecialEffect.isEffective(SBASpecialEffectsRegistry.BURST_DRIVE, level)) {
                Drive.doSlash(player, event.getRoll(), event.getYRot(), 10, colorCode, class_243.field_1353, false, event.getDamage(), null, 1.5f);
            }
        }
    }
}
