package cn.mmf.slashblade_addon.entity;

import mods.flammpfeil.slashblade.entity.EntityAbstractSummonedSword;
import mods.flammpfeil.slashblade.entity.Projectile;
import mods.flammpfeil.slashblade.util.KnockBacks;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3966;
import org.joml.Vector3f;

public class SpiralEdgeSwordsEntity extends EntityAbstractSummonedSword {
    private static final class_2940<Boolean> IT_FIRED = class_2945.method_12791(SpiralEdgeSwordsEntity.class, class_2943.field_13323);
    private static final class_2940<Float> SPEED = class_2945.method_12791(SpiralEdgeSwordsEntity.class, class_2943.field_13320);
    private static final class_2940<Vector3f> OFFSET = class_2945.method_12791(SpiralEdgeSwordsEntity.class, class_2943.field_42237);

    public SpiralEdgeSwordsEntity(class_1299<? extends Projectile> entityTypeIn, class_1937 worldIn) {
        super(entityTypeIn, worldIn);
        this.setPierce((byte) 5);
    }

    @Override
    protected void method_5693() {
        super.method_5693();

        this.field_6011.method_12784(IT_FIRED, false);
        this.field_6011.method_12784(SPEED, 3.0f);
        this.field_6011.method_12784(OFFSET, class_243.field_1353.method_46409());
    }

    public void doFire() {
        this.method_5841().method_12778(IT_FIRED, true);
    }

    public boolean itFired() {
        return this.method_5841().method_12789(IT_FIRED);
    }

    public void setSpeed(float speed) {
        this.method_5841().method_12778(SPEED, speed);
    }

    public float getSpeed() {
        return this.method_5841().method_12789(SPEED);
    }

    public void setOffset(class_243 offset) {
        this.method_5841().method_12778(OFFSET, offset.method_46409());
    }

    public class_243 getOffset() {
        return new class_243(this.method_5841().method_12789(OFFSET));
    }

    @Override
    public void method_5773() {
        if (!itFired() && method_37908().method_8608() && method_5854() == null) {
            method_5873(this.method_24921(), true);
        }

        super.method_5773();
    }

    @Override
    public void method_5842() {
        if (itFired()) {
            faceEntityStandby();
            class_1297 target = method_5854();
            this.method_5848();

            this.field_6012 = 0;
            class_243 dir = this.method_5828(1.0f);

            if (target != null) {
                dir = this.method_19538().method_1020(target.method_19538()).method_18805(1, 0, 1).method_1029();
            }
            this.method_7485(dir.field_1352, dir.field_1351, dir.field_1350, this.getSpeed(), 1.0f);
            if (target instanceof class_3222) {
                ((class_3222) target).method_17356(class_3417.field_14550, class_3419.field_15248, 1.0F, 1.0F);
            }
            return;
        }

        this.method_18799(class_243.field_1353);
        // TODO
        // if (canUpdate())
        this.method_5670();

        faceEntityStandby();

        if (field_6012 >= getDelay()) doFire();
    }

    private void faceEntityStandby() {
        if (this.method_5854() == null) {
            doFire();
            return;
        }
        int countPerRound = 24;
        double degPerRound = 360.0 / countPerRound;
        double degYaw = (getDelay() * degPerRound) - ((int) ((getDelay() * degPerRound) / 360.0)) * 360.0;
        double yaw = Math.toRadians(degYaw - 180);

        class_243 dir = this.getOffset();

        // yaw
        dir = dir.method_1024((float) -yaw);
        dir = dir.method_1029().method_1021(2);

        dir = dir.method_1019(this.method_5854().method_19538());

        this.field_6004 = this.method_36455();
        this.field_5982 = this.method_36454();

        method_33574(dir);
        method_5710((float) (-degYaw), 0);
    }

    @Override
    protected void method_7454(class_3966 result) {
        class_1297 targetEntity = result.method_17782();
        if (targetEntity instanceof class_1309) KnockBacks.cancel.action.accept((class_1309) targetEntity);

        super.method_7454(result);
    }
}
