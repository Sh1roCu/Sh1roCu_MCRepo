package cn.mmf.slashblade_addon.specialattacks;

import cn.mmf.slashblade_addon.entity.GaleSwordsEntity;
import cn.mmf.slashblade_addon.registry.SBAEntitiesRegistry;
import mods.flammpfeil.slashblade.capability.concentrationrank.CapabilityConcentrationRank;
import mods.flammpfeil.slashblade.capability.concentrationrank.IConcentrationRank;
import mods.flammpfeil.slashblade.capability.slashblade.CapabilitySlashBlade;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3417;
import net.minecraft.class_5819;

public class GaleSwords {
    public static void doSlash(class_1309 playerIn, boolean critical, double damage, float speed) {
        if (playerIn.method_37908().method_8608())
            return;

        CapabilitySlashBlade.BLADESTATE.maybeGet(playerIn.method_6047()).ifPresent((state) -> {

            class_1937 worldIn = playerIn.method_37908();

            int rank = CapabilityConcentrationRank.RANK_POINT.maybeGet(playerIn)
                    .map(r -> r.getRank(worldIn.method_8510()).level).orElse(0);
            int count = IConcentrationRank.ConcentrationRanks.S.level <= rank ? 10 : 6;

            for (int i = 0; i < count; i++) {
                GaleSwordsEntity ss = new GaleSwordsEntity(SBAEntitiesRegistry.BlisteringSwords, worldIn);

                worldIn.method_8649(ss);

                ss.setSpeed(speed);
                ss.setIsCritical(critical);
                ss.method_7432(playerIn);
                ss.setColor(0xf7892d);
                ss.setRoll(0);
                ss.setDamage(damage);
                // force riding
                ss.method_5873(playerIn, true);

                ss.setDelay(20 + i);

                boolean isRight = ss.getDelay() % 2 == 0;
                class_5819 random = worldIn.method_8409();

                double xOffset = random.method_43058() * 2.5 * (isRight ? 1 : -1);
                double yOffset = random.method_43057() * 2;
                double zOffset = random.method_43057() * 0.5;

                ss.method_33574(playerIn.method_19538().method_1031(xOffset, yOffset, zOffset));
                ss.setOffset(new class_243(xOffset, yOffset, zOffset));

                playerIn.method_5783(class_3417.field_14890, 0.2F, 1.45F);
            }
        });
    }
}
