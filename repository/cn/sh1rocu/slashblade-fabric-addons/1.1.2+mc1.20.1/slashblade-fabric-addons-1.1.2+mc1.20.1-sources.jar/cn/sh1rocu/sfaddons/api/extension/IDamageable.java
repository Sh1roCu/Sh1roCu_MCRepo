package cn.sh1rocu.sfaddons.api.extension;

import net.minecraft.class_1799;
import net.minecraft.class_2487;

public interface IDamageable {
    default boolean isDamageable(class_1799 stack) {
        if (!stack.method_7960() && stack.method_7909().method_7841() > 0) {
            class_2487 compoundTag = stack.method_7969();
            return compoundTag == null || !compoundTag.method_10577("Unbreakable");
        } else {
            return false;
        }
    }
}