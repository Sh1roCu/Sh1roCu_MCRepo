package cn.mmf.slashblade_addon.compat;

import cn.mmf.slashblade_addon.SlashBladeAddon;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class SBATofuCraftItems {
    public static final class_2960 TOFUISHI_SLASHBLADE = new class_2960(SlashBladeAddon.MODID, "slashblade_tofu_ishi");
    public static final class_2960 TOFUMETAL_SLASHBLADE = new class_2960(SlashBladeAddon.MODID, "slashblade_tofu_metal");
    public static final class_2960 TOFUDIAMOND_SLASHBLADE = new class_2960(SlashBladeAddon.MODID, "slashblade_tofu_diamond");

    public static void init() {
        // TODO: TofuCraft Fabric移植
//        register(TOFUISHI_SLASHBLADE,
//                new TofuSlashBladeItem(TofuItemTier.SOLID, 3, -2.4F, 200, new Item.Properties()).setTexture(SlashBladeAddon.prefix("model/tofuishi_katana.png")));
//        register(TOFUMETAL_SLASHBLADE,
//                new TofuSlashBladeItem(TofuItemTier.METAL, 5, -2.4F, 500, new Item.Properties()).setTexture(SlashBladeAddon.prefix("model/tofumetal_katana.png")));
//        register(BuiltInRegistries.ITEM, TOFUDIAMOND_SLASHBLADE,
//                new TofuSlashBladeItem(TofuItemTier.TOFUDIAMOND, 9, -2.4F, 1200, new Item.Properties()).setTexture(SlashBladeAddon.prefix("model/tofudiamond_katana.png")));

    }

    public static class_1792 getItem(class_2960 item) {
        return class_7923.field_41178.method_10223(item);
    }

    private static class_1792 register(class_2960 id, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, id, item);
    }
}
